"""Telegram bot: linking, welcome, guided commands and real model interaction.

How identity works (and why nothing secret ever travels through Telegram)
------------------------------------------------------------------------
Two supported paths, both stored on ``telegram_links``:

1. **One-time link code (verified).** A signed-in user opens *Profile → Telegram*, asks the site
   for a one-time code, and sends ``/start <code>`` to the bot. The code is short-lived and
   single-use; consuming it proves the human controls both accounts, and the numeric Telegram id is
   stored on their platform account.
2. **Numeric id set in the profile (declared).** The user types their numeric Telegram id in
   *Profile → Telegram*. The bot then accepts that id — which is what the owner asked for: a user
   who registered their number on the site is recognised the moment they press Start. Claims are
   one-to-one (a Telegram id can belong to exactly one account) and are labelled
   ``verified_via="profile"`` so the admin panel and the audit trail never present a declared id as
   a proven one.

From then on every message is resolved through ``telegram_links`` to the platform account, so the
bot acts *as that user*: same permissions, same balance, same rate limits, same model access rules,
same usage history. An id that is **not** registered on the site is refused with instructions — it
can never use somebody else's account.

Nothing is bypassed: a Telegram message runs through ``ai_service.stream_chat`` exactly like a web
request, so it is charged to the same ledger, refused when the balance is empty and recorded in the
same usage table (module ``telegram``).

The bot token itself can be entered in **Admin → Settings → Telegram** (stored encrypted in the
database) or left in ``NEXA_TELEGRAM_BOT_TOKEN``; the database wins, and the polling worker picks a
new token up without a restart.

Transports: long polling (default — works behind NAT, no public URL needed) and webhook (for
production domains). Both call the same handler.
"""
from __future__ import annotations

import datetime as dt
import html
import math
import json
import secrets
from typing import Any

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.errors import NexaError, ValidationError
from app.core.logging import get_logger
from app.db.session import SessionLocal
from app.models.chat import Conversation, Message, MessageRole
from app.models.provider import Model
from app.models.telegram import TelegramLink
from app.models.billing import CreditAccount
from app.models.user import User
from app.services import access as access_service
from app.services import ai as ai_service
from app.services import settings_store
from app.services import variants as variant_service

log = get_logger(__name__)

LINK_CODE_TTL_MINUTES = 15
MAX_TELEGRAM_MESSAGE = 4000          # Telegram's own limit is 4096
MODELS_PER_PAGE = 10
BOT_TOKEN_SETTING_KEY = "telegram.bot_token"

#: The bot token most recently seen in the database (or a webhook/test call). Kept in a module
#: variable because every API/DTO helper below is sync and has no ``db`` handle: the polling loop
#: and the admin endpoints refresh it, and `bot_token()` falls back to the environment.
_runtime_token: str = ""

HELP_TEXT = (
    "🤖 <b>Nexa AI</b> — راهنمای سریع / quick guide\n"
    "━━━━━━━━━━━━━━━━━━━━\n"
    "💬 <b>گفتگو</b> — هر پیام متنی مستقیماً به مدل انتخاب‌شده می‌رود و از اعتبار شما کسر می‌شود.\n"
    "🧠 /models — فهرست مدل‌ها و انتخاب آن‌ها\n"
    "🎛 /variants — نسخه‌های یک مدل (هرکدام با پرامپت سیستمی خودش)\n"
    "🆕 /new — گفتگوی تازه\n"
    "💳 /balance — اعتبار حساب\n"
    "📊 /usage — آخرین مصرف‌ها\n"
    "👤 /status — وضعیت حساب و مدل فعلی\n"
    "🔢 /whoami — شناسهٔ عددی تلگرام شما\n"
    "🧭 /menu — دکمه‌های میان‌بر\n"
    "❓ /help — همین راهنما\n\n"
    "English: any other text message goes to the selected model; /help repeats this guide and /menu "
    "shows the shortcut buttons."
)
WELCOME_TEXT = (
    "👋 <b>{name}</b> عزیز، خوش آمدید!\n"
    "━━━━━━━━━━━━━━━━━━━━\n"
    "✅ حساب سایت شما شناسایی و به این گفتگو وصل شد.\n"
    "🧠 مدل پیش‌فرض: <b>{model}</b>\n"
    "💳 اعتبار فعلی: <b>{balance}</b> credits\n"
    "🔐 نوع تأیید هویت: {verified}\n\n" + HELP_TEXT
)
MODELS_PER_PAGE_LEGACY = 20

LINK_REQUIRED_TEXT = (
    "🔒 <b>این شناسهٔ تلگرام روی سایت ثبت نشده است</b>\n"
    "━━━━━━━━━━━━━━━━━━━━\n"
    "برای استفاده از ربات، اول باید شمارهٔ عددی تلگرام خودتان را در سایت ثبت کنید:\n\n"
    "۱) وارد سایت شوید → <b>پروفایل</b> → بخش <b>تلگرام</b>\n"
    "۲) شناسهٔ عددی خود را وارد کنید (همین عدد در پیام /whoami برایتان نشان داده می‌شود) یا دکمهٔ\n"
    "   «ساخت کد اتصال» را بزنید و <code>/start &lt;کد&gt;</code> را همین‌جا بفرستید.\n"
    "۳) سپس دوباره <code>/start</code> را بفرستید.\n\n"
    "This Telegram account is not registered on the site yet. Open the site → Profile → Telegram, "
    "save your numeric id (or create a link code and send <code>/start &lt;code&gt;</code>), then send "
    "<code>/start</code> again."
)

MENU_TEXT = (
    "🧭 <b>منوی Nexa AI</b>\n"
    "━━━━━━━━━━━━━━━━━━━━\n"
    "یکی از گزینه‌ها را انتخاب کنید / pick an option:"
)


# ---------------------------------------------------------------- credentials ----
def refresh_token(db: Session | None = None) -> str:
    """Load the bot token from the settings table (encrypted) or fall back to the environment."""
    global _runtime_token
    if db is not None:
        try:
            stored = settings_store.get_secret(db, BOT_TOKEN_SETTING_KEY)
        except Exception as exc:  # noqa: BLE001 - a broken setting must never kill the bot loop
            log.warning("could not read the stored Telegram token: %s", exc)
            stored = ""
        if stored:
            _runtime_token = stored.strip()
            return _runtime_token
    _runtime_token = ""
    return ""


def api_base() -> str:
    return (settings.telegram_api_base or "https://api.telegram.org").rstrip("/")


def bot_token() -> str:
    return (_runtime_token or settings.telegram_bot_token or "").strip()


def token_source() -> str:
    if _runtime_token:
        return "database"
    if settings.telegram_bot_token:
        return "environment"
    return "none"


def is_configured(db: Session | None = None) -> bool:
    if db is not None:
        refresh_token(db)
    if not bot_token():
        return False
    if db is not None:
        enabled = settings_store.get_value(db, "telegram.enabled", settings.telegram_enabled)
        return bool(enabled)
    return bool(settings.telegram_enabled) or bool(_runtime_token)


def bot_username(db: Session | None = None) -> str:
    if db is not None:
        stored = str(settings_store.get_value(db, "telegram.bot_username", "") or "")
        if stored:
            return stored.lstrip("@")
    return (settings.telegram_bot_username or "").lstrip("@")


async def call_api(method: str, payload: dict[str, Any], *, timeout: float = 40.0) -> dict[str, Any]:
    """Call one Telegram Bot API method. Raises ValidationError with the real reason."""
    if not bot_token():
        raise ValidationError(
            "The Telegram bot token is not configured. Enter it under Admin → Settings → Telegram "
            "(or set NEXA_TELEGRAM_BOT_TOKEN)."
        )
    url = f"{api_base()}/bot{bot_token()}/{method}"
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(url, json=payload)
    except Exception as exc:  # noqa: BLE001
        raise ValidationError(f"Telegram is unreachable: {type(exc).__name__}: {exc}") from exc
    try:
        data = response.json()
    except Exception:  # noqa: BLE001
        raise ValidationError(f"Telegram answered HTTP {response.status_code} with a non-JSON body.") from None
    if not data.get("ok"):
        raise ValidationError(f"Telegram refused {method}: {data.get('description') or data}")
    return data.get("result") or {}


#: Last delivery problem reported by Telegram (chat blocked the bot, chat not found, …). The admin
#: status card shows it so an operator can see *why* nothing arrives instead of guessing.
LAST_DELIVERY_ERROR: dict[str, Any] = {}


def _record_delivery_error(method: str, chat_id: int | str, error: Exception) -> None:
    LAST_DELIVERY_ERROR.clear()
    LAST_DELIVERY_ERROR.update({"method": method, "chat_id": chat_id, "error": str(error)[:300],
                                "at": dt.datetime.now(dt.timezone.utc).isoformat()})
    log.warning("telegram %s to chat %s failed: %s", method, chat_id, error)


async def send_message(
    chat_id: int | str,
    text: str,
    *,
    markdown: bool = True,
    reply_to: int | None = None,
    keyboard: list[list[dict[str, str]]] | None = None,
) -> bool:
    """Deliver one message. Returns False when Telegram refuses *this chat*.

    Telegram only lets a bot write to a chat that has started it, so a refusal here is normal
    (“chat not found”, “bot was blocked by the user”). Raising would abort the whole update — and with
    it the answer to the next user — so the failure is logged, remembered for the admin card, and
    reported as ``False``. Real configuration errors (bad token, bad HTML) are still visible: they come
    back through :func:`call_api` for the endpoints that test the bot.
    """
    payload: dict[str, Any] = {
        "chat_id": chat_id,
        "text": text[:MAX_TELEGRAM_MESSAGE],
        "disable_web_page_preview": True,
    }
    if markdown:
        payload["parse_mode"] = "HTML"
    if reply_to:
        payload["reply_parameters"] = json.dumps({"message_id": reply_to})
    if keyboard is not None:
        payload["reply_markup"] = json.dumps({"inline_keyboard": keyboard})
    try:
        await call_api("sendMessage", payload)
    except NexaError as exc:
        message = str(exc)
        if "not configured" in message or "unreachable" in message:
            raise
        _record_delivery_error("sendMessage", chat_id, exc)
        return False
    LAST_DELIVERY_ERROR.clear()
    return True


async def edit_message(
    chat_id: int | str, message_id: int, text: str, *, keyboard: list[list[dict[str, str]]] | None = None
) -> bool:
    payload: dict[str, Any] = {"chat_id": chat_id, "message_id": message_id, "text": text[:MAX_TELEGRAM_MESSAGE], "parse_mode": "HTML"}
    if keyboard is not None:
        payload["reply_markup"] = json.dumps({"inline_keyboard": keyboard})
    try:
        await call_api("editMessageText", payload)
    except NexaError as exc:
        message = str(exc)
        if "not configured" in message or "unreachable" in message:
            raise
        # “message is not modified” is the normal answer when a user taps the button they are already
        # on; it is not a failure worth showing anyone.
        if "not modified" not in message:
            _record_delivery_error("editMessageText", chat_id, exc)
        return False
    return True


async def answer_callback(callback_id: str, text: str = "", *, alert: bool = False) -> None:
    try:
        await call_api("answerCallbackQuery", {"callback_query_id": callback_id, "text": text[:180], "show_alert": alert}, timeout=15)
    except NexaError:
        pass


async def send_typing(chat_id: int | str) -> None:
    try:
        await call_api("sendChatAction", {"chat_id": chat_id, "action": "typing"}, timeout=10)
    except NexaError:
        pass


async def get_me() -> dict[str, Any]:
    return await call_api("getMe", {})


async def delete_webhook() -> dict[str, Any]:
    return await call_api("deleteWebhook", {"drop_pending_updates": False})


async def get_webhook_info() -> dict[str, Any]:
    return await call_api("getWebhookInfo", {})


async def set_my_commands() -> dict[str, Any]:
    """Publish the command list so Telegram shows a clean menu button."""
    commands = [
        {"command": "menu", "description": "🧭 منو / menu"},
        {"command": "models", "description": "🧠 مدل‌ها / models"},
        {"command": "variants", "description": "🎛 نسخه‌ها / variants"},
        {"command": "new", "description": "🆕 گفتگوی تازه / new chat"},
        {"command": "status", "description": "👤 وضعیت حساب / account"},
        {"command": "balance", "description": "💳 اعتبار / balance"},
        {"command": "usage", "description": "📊 مصرف / usage"},
        {"command": "whoami", "description": "🔢 شناسهٔ عددی من / my numeric id"},
        {"command": "help", "description": "❓ راهنما / help"},
    ]
    return await call_api("setMyCommands", {"commands": commands})


def _button(text: str, data: str) -> dict[str, str]:
    return {"text": text, "callback_data": data[:64]}


def _url_button(text: str, url: str) -> dict[str, str]:
    return {"text": text, "url": url}


def main_keyboard(db: Session, user: User | None) -> list[list[dict[str, str]]]:
    rows = [
        [_button("🧠 مدل‌ها / Models", "menu:models"), _button("🎛 نسخه‌ها / Variants", "menu:variants")],
        [_button("💳 اعتبار / Balance", "menu:balance"), _button("📊 مصرف / Usage", "menu:usage")],
        [_button("👤 وضعیت / Status", "menu:status"), _button("🆕 گفتگوی تازه / New chat", "menu:new")],
        [_button("❓ راهنما / Help", "menu:help")],
    ]
    site = (settings.public_base_url or "").strip()
    if site:
        rows.append([_url_button("🌐 باز کردن سایت / Open the site", site)])
    return rows


def _models_keyboard(models: list[Model], state: dict[str, Any], page: int = 1) -> list[list[dict[str, str]]]:
    pages = max(1, math.ceil(len(models) / MODELS_PER_PAGE))
    page = min(max(page, 1), pages)
    start = (page - 1) * MODELS_PER_PAGE
    window = models[start:start + MODELS_PER_PAGE]
    rows: list[list[dict[str, str]]] = []
    for number, model in enumerate(window, start=start + 1):
        mark = "✅ " if model.id == state.get("model_id") else ""
        label = f"{mark}{number}. {model.display_name}"[:60]
        rows.append([_button(label, f"model:{model.id}")])
    nav: list[dict[str, str]] = []
    if page > 1:
        nav.append(_button("⬅️ قبلی / prev", f"models:{page - 1}"))
    if page < pages:
        nav.append(_button("بعدی ➡️ / next", f"models:{page + 1}"))
    if nav:
        rows.append(nav)
    rows.append([_button("🔁 تازه‌سازی / refresh", "menu:models"), _button("🧭 منو / menu", "menu:home")])
    return rows


def _variants_keyboard(variants: list[Any], state: dict[str, Any]) -> list[list[dict[str, str]]]:
    rows: list[list[dict[str, str]]] = []
    raw_mark = "✅ " if not state.get("variant_id") else ""
    rows.append([_button(f"{raw_mark}0. مدل خام / raw model", "variant:0")])
    for index, variant in enumerate(variants, start=1):
        mark = "✅ " if variant.id == state.get("variant_id") else ""
        label = f"{mark}{index}. {variant.name}"[:60]
        rows.append([_button(label, f"variant:{variant.id}")])
    rows.append([_button("🧭 منو / menu", "menu:home")])
    return rows


# ---------------------------------------------------------------- linking -------
def create_link_code(db: Session, *, user: User) -> dict[str, Any]:
    """Create (or refresh) the one-time code the user sends as `/start <code>`."""
    code = f"{secrets.randbelow(1_000_000):06d}{secrets.token_hex(3)}"
    expires_at = dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=LINK_CODE_TTL_MINUTES)
    store = settings_store
    state_key = f"telegram.link_code.{user.id}"
    store.set_value(
        db, state_key, {"code": code, "expires_at": expires_at.isoformat()}, actor=user, commit=False,
    )
    db.commit()
    username = bot_username(db)
    return {
        "code": code,
        "expires_at": expires_at,
        "expires_in_minutes": LINK_CODE_TTL_MINUTES,
        "bot_username": username,
        "deep_link": f"https://t.me/{username}?start={code}" if username else None,
        "instructions": (
            f"Open @{username} in Telegram and send /start {code}" if username
            else f"Open your bot in Telegram and send /start {code}"
        ),
    }


def link_status(db: Session, *, user: User) -> dict[str, Any]:
    link = db.scalars(select(TelegramLink).where(TelegramLink.user_id == user.id)).first()
    pending = settings_store.get_value(db, f"telegram.link_code.{user.id}", {}) or {}
    expires = pending.get("expires_at")
    pending_valid = bool(
        pending.get("code") and expires and dt.datetime.fromisoformat(str(expires)) > dt.datetime.now(dt.timezone.utc)
    )
    return {
        "linked": link is not None,
        "enabled": bool(link.enabled) if link else False,
        "telegram_user_id": link.telegram_user_id if link else None,
        "telegram_username": link.telegram_username if link else None,
        "linked_at": link.linked_at if link else None,
        "last_message_at": link.last_message_at if link else None,
        "message_count": link.message_count if link else 0,
        "verified_via": getattr(link, "verified_via", None) if link else None,
        "numeric_id": link.telegram_user_id if link else None,
        "pending_code": bool(pending_valid),
        "bot_configured": is_configured(db),
        "bot_username": bot_username(db),
        "how_it_works": (
            "Set your numeric Telegram id here (or create a one-time code and send /start <code> to the bot). "
            "The bot only answers Telegram ids that are registered on the site."
        ),
    }


def set_numeric_id(db: Session, *, user: User, telegram_user_id: int) -> dict[str, Any]:
    """Register the numeric Telegram id typed in the profile (declared, not proven).

    The bot then recognises this account the moment the user presses Start. The mapping is
    one-to-one: an id already claimed by another account is refused, so two accounts can never share
    one Telegram identity (and nobody's credits can be spent under somebody else's chat).
    """
    telegram_user_id = int(telegram_user_id)
    if telegram_user_id <= 0 or telegram_user_id > 9_999_999_999_999:
        raise ValidationError("That does not look like a Telegram user id (a positive number such as 123456789).")
    existing = db.scalars(select(TelegramLink).where(TelegramLink.telegram_user_id == telegram_user_id)).first()
    if existing is not None and existing.user_id != user.id:
        raise ValidationError(
            "This Telegram id is already registered on another account. If it is yours, unlink it there first "
            "or contact the administrator."
        )
    link = db.scalars(select(TelegramLink).where(TelegramLink.user_id == user.id)).first()
    if link is not None and link.telegram_user_id and int(link.telegram_user_id) != telegram_user_id:
        # A code-verified link is a *proven* identity. Quietly moving it to a typed-in number would
        # keep the “proven” badge while pointing at an id nobody verified, so the user is asked to
        # unlink first — the badge must always describe reality.
        if getattr(link, "verified_via", None) == "code":
            raise ValidationError(
                "This account is already linked to a Telegram id that was proven with a one-time code: "
                f"{int(link.telegram_user_id)}. Unlink it first if you really want to declare a different id.",
                details={"reason": "code_verified_link", "telegram_user_id": int(link.telegram_user_id)},
            )
    if link is None:
        link = TelegramLink(user_id=user.id, telegram_user_id=telegram_user_id, chat_id=0, enabled=True,
                            verified_via="profile")
        db.add(link)
    else:
        link.telegram_user_id = telegram_user_id
        link.enabled = True
        if getattr(link, "verified_via", None) != "code":
            link.verified_via = "profile"
    db.commit()
    return link_status(db, user=user)


def unlink(db: Session, *, user: User) -> dict[str, Any]:
    link = db.scalars(select(TelegramLink).where(TelegramLink.user_id == user.id)).first()
    if link is not None:
        db.delete(link)
        db.commit()
    return link_status(db, user=user)


def consume_link_code(db: Session, *, code: str, telegram_user_id: int, chat_id: int,
                      username: str | None = None, first_name: str | None = None) -> User | None:
    code = (code or "").strip()
    if not code:
        return None
    rows = db.scalars(select(User)).all()
    match: User | None = None
    for candidate in rows:
        pending = settings_store.get_value(db, f"telegram.link_code.{candidate.id}")
        if isinstance(pending, dict) and pending.get("code") == code:
            expires = pending.get("expires_at")
            if expires and dt.datetime.fromisoformat(str(expires)) < dt.datetime.now(dt.timezone.utc):
                continue
            match = candidate
            break
    if match is None:
        return None
    existing = db.scalars(select(TelegramLink).where(TelegramLink.telegram_user_id == telegram_user_id)).first()
    if existing is not None and existing.user_id != match.id:
        raise ValidationError("This Telegram account is already linked to another user.")
    link = db.scalars(select(TelegramLink).where(TelegramLink.user_id == match.id)).first()
    if link is None:
        link = TelegramLink(user_id=match.id, telegram_user_id=telegram_user_id, chat_id=chat_id,
                            telegram_username=username, telegram_first_name=first_name, enabled=True,
                            verified_via="code")
        db.add(link)
    else:
        link.telegram_user_id = telegram_user_id
        link.chat_id = chat_id
        link.telegram_username = username
        link.telegram_first_name = first_name
        link.enabled = True
        link.verified_via = "code"
    settings_store.set_value(db, f"telegram.link_code.{match.id}", None, actor=match, commit=False)
    db.commit()
    return match


def resolve_user(db: Session, telegram_user_id: int) -> tuple[User | None, TelegramLink | None]:
    link = db.scalars(select(TelegramLink).where(TelegramLink.telegram_user_id == telegram_user_id)).first()
    if link is None or not link.enabled:
        return None, link
    return link.user, link


def _state(link: TelegramLink) -> dict[str, Any]:
    return dict(link.state or {})


def _save_state(db: Session, link: TelegramLink, state: dict[str, Any]) -> None:
    link.state = state
    db.commit()


def _accessible_models(db: Session, user: User, limit: int | None = None) -> list[Model]:
    """Every model this user may use, in a stable order.

    This used to stop after 12 entries with nothing telling the user that a cap existed:
    a catalogue larger than that simply could not be reached from the bot. The full list
    is returned now and ``/models`` paginates it, always printing the real total.
    """
    rows = db.scalars(access_service.visible_models_query(user).order_by(Model.sort_order, Model.id)).all()
    models = access_service.filter_models_for_user(db, user, list(rows))
    return models[:limit] if limit is not None else models


def _balance_text(db: Session, user: User) -> str:
    from app.services.pricing import micro_to_credits

    account = db.scalars(select(CreditAccount).where(CreditAccount.user_id == user.id)).first()
    if account is None:
        return "0"
    return f"{micro_to_credits(account.balance_micro):,}"


def _conversation_for(db: Session, user: User, model: Model, link: TelegramLink) -> Conversation:
    state = _state(link)
    conversation_id = state.get("conversation_id")
    conversation = db.get(Conversation, conversation_id) if conversation_id else None
    if conversation is None or conversation.user_id != user.id or conversation.model_id != model.id:
        conversation = Conversation(
            user_id=user.id,
            title=f"Telegram · {model.display_name}"[:60],
            module="telegram",
            model_id=model.id,
        )
        db.add(conversation)
        db.flush()
        state["conversation_id"] = conversation.id
        _save_state(db, link, state)
        db.commit()
    return conversation


def _history(db: Session, conversation: Conversation, limit: int = 12) -> list[ai_service.ChatMessage]:
    rows = db.scalars(
        select(Message).where(Message.conversation_id == conversation.id).order_by(Message.id.desc()).limit(limit)
    ).all()
    history: list[ai_service.ChatMessage] = []
    for row in reversed(list(rows)):
        if row.role in (MessageRole.USER, MessageRole.ASSISTANT) and row.content:
            history.append(ai_service.ChatMessage(role=row.role, content=row.content))
    return history


def _verified_label(link: TelegramLink) -> str:
    kind = (getattr(link, "verified_via", "") or "").lower()
    if kind == "code":
        return "✅ کد یک‌بارمصرف / one-time code"
    if kind == "profile":
        return "🔖 ثبت‌شده در پروفایل / registered in the profile"
    return "—"


def _current_model(db: Session, user: User, link: TelegramLink) -> Model | None:
    models = _accessible_models(db, user)
    state = _state(link)
    return next((m for m in models if m.id == state.get("model_id")), models[0] if models else None)


async def _send_menu(chat_id: int | str, db: Session, user: User | None) -> None:
    await send_message(chat_id, MENU_TEXT, keyboard=main_keyboard(db, user))


async def _send_models(chat_id: int | str, db: Session, user: User, link: TelegramLink, page: int = 1,
                       *, edit: int | None = None) -> None:
    models = _accessible_models(db, user)
    if not models:
        await send_message(chat_id, "⚠️ هیچ مدلی برای حساب شما منتشر نشده است / no model is published for your account.")
        return
    state = _state(link)
    pages = max(1, math.ceil(len(models) / MODELS_PER_PAGE))
    page = min(max(page, 1), pages)
    start = (page - 1) * MODELS_PER_PAGE
    current = state.get("model_id") or (models[0].id if models else None)
    lines = ["🧠 <b>مدل‌های در دسترس / available models</b>", "━━━━━━━━━━━━━━━━━━━━"]
    for number, model in enumerate(models[start:start + MODELS_PER_PAGE], start=start + 1):
        mark = "✅" if model.id == current else "▫️"
        lines.append(f"{mark} <b>{number}.</b> {html.escape(model.display_name)} — <code>{html.escape(model.provider_model_id)}</code>")
    lines.append("")
    lines.append(f"📄 صفحه {page} از {pages} · مجموع {len(models)} مدل / page {page} of {pages}, {len(models)} models")
    lines.append("روی یکی از دکمه‌ها بزنید تا انتخاب شود / tap a button to select it.")
    text = "\n".join(lines)
    keyboard = _models_keyboard(models, state, page)
    if edit:
        await edit_message(chat_id, edit, text, keyboard=keyboard)
    else:
        await send_message(chat_id, text, keyboard=keyboard)


async def _send_variants(chat_id: int | str, db: Session, user: User, link: TelegramLink,
                         *, edit: int | None = None) -> None:
    model = _current_model(db, user, link)
    if model is None:
        await send_message(chat_id, "ابتدا یک مدل انتخاب کنید / select a model first (/models).")
        return
    variants = variant_service.list_variants(db, model_id=model.id, actor=user)
    if not variants:
        await send_message(chat_id, f"برای «{html.escape(model.display_name)}» نسخه‌ای تعریف نشده است.\n"
                                    "No variant is defined for this model.")
        return
    state = _state(link)
    lines = [f"🎛 <b>نسخه‌های {html.escape(model.display_name)}</b>", "━━━━━━━━━━━━━━━━━━━━"]
    for index, variant in enumerate(variants, start=1):
        mark = "✅" if variant.id == state.get("variant_id") else "▫️"
        emoji = f"{variant.emoji} " if variant.emoji else ""
        lines.append(f"{mark} <b>{index}.</b> {emoji}{html.escape(variant.name)}")
        if variant.description:
            lines.append(f"     <i>{html.escape(variant.description[:80])}</i>")
    text = "\n".join(lines)
    keyboard = _variants_keyboard(variants, state)
    if edit:
        await edit_message(chat_id, edit, text, keyboard=keyboard)
    else:
        await send_message(chat_id, text, keyboard=keyboard)


async def _send_status(chat_id: int | str, db: Session, user: User, link: TelegramLink) -> None:
    model = _current_model(db, user, link)
    state = _state(link)
    variant_name = "—"
    if state.get("variant_id"):
        variant = next((v for v in variant_service.list_variants(db, model_id=model.id, actor=user)
                        if v.id == state["variant_id"]), None) if model else None
        variant_name = variant.name if variant else "—"
    await send_message(
        chat_id,
        "👤 <b>وضعیت حساب / account status</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"📧 <code>{html.escape(user.email)}</code>\n"
        f"🧠 مدل / model: <b>{html.escape(model.display_name if model else '—')}</b>\n"
        f"🎛 نسخه / variant: <b>{html.escape(variant_name)}</b>\n"
        f"💳 اعتبار / balance: <b>{_balance_text(db, user)}</b> credits\n"
        f"🔐 تأیید / verified: {_verified_label(link)}\n"
        f"🔢 شناسهٔ عددی / numeric id: <code>{link.telegram_user_id}</code>\n"
        f"✉️ پیام‌ها / messages: {link.message_count or 0}",
        keyboard=main_keyboard(db, user),
    )


async def _send_usage(chat_id: int | str, db: Session, user: User) -> None:
    from app.models.billing import UsageRecord
    from app.services.pricing import micro_to_credits

    rows = db.scalars(
        select(UsageRecord).where(UsageRecord.user_id == user.id).order_by(UsageRecord.id.desc()).limit(8)
    ).all()
    if not rows:
        await send_message(chat_id, "هنوز مصرفی ثبت نشده / no usage recorded yet.")
        return
    lines = ["📊 <b>آخرین مصرف‌ها / recent usage</b>", "━━━━━━━━━━━━━━━━━━━━"]
    for row in rows:
        lines.append(
            f"• <code>{html.escape(row.operation or '')}</code> — {html.escape(row.provider_model_id or '')} — "
            f"<b>{micro_to_credits(row.charged_micro or 0)}</b> credits — {row.created_at:%Y-%m-%d %H:%M}"
        )
    await send_message(chat_id, "\n".join(lines))


def _numeric_id_help(telegram_user_id: int) -> str:
    return (
        "🔢 <b>شناسهٔ عددی تلگرام شما / your numeric Telegram id</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"<code>{telegram_user_id}</code>\n\n"
        "این عدد را در سایت → <b>پروفایل</b> → بخش <b>تلگرام</b> ذخیره کنید تا ربات همیشه شما را بشناسد.\n"
        "Save this number on the site → Profile → Telegram so the bot always recognises you."
    )


# ---------------------------------------------------------------- the handler -----
async def handle_message(db: Session, update: dict[str, Any]) -> str:
    """Handle one plain message (text). Returns a short label for logs/tests."""
    message = update.get("message") or update.get("edited_message") or {}
    chat = message.get("chat") or {}
    sender = message.get("from") or {}
    chat_id = chat.get("id")
    telegram_user_id = sender.get("id")
    text = (message.get("text") or "").strip()
    if not chat_id or not telegram_user_id or not text:
        return "ignored"

    if not is_configured(db):
        log.warning("telegram update received while the bot is not configured")
        return "not_configured"

    command, _, argument = text.partition(" ")
    command = command.split("@")[0].lower()

    # --- /start with a link code ------------------------------------------------
    if command == "/start":
        argument = argument.strip()
        if argument:
            user = consume_link_code(
                db,
                code=argument,
                telegram_user_id=int(telegram_user_id),
                chat_id=int(chat_id),
                username=sender.get("username"),
                first_name=sender.get("first_name"),
            )
            if user is None:
                await send_message(chat_id, "❌ کد اتصال نامعتبر یا منقضی شده است. کد تازه بسازید.\n"
                                            "Invalid or expired link code — create a new one on the site.",
                                   keyboard=[[_button("🧭 منو / menu", "menu:home")]])
                return "bad_link_code"
            link = db.scalars(select(TelegramLink).where(TelegramLink.user_id == user.id)).first()
            models = _accessible_models(db, user)
            model_name = models[0].display_name if models else "—"
            if link is not None and models:
                state = _state(link)
                state["model_id"] = models[0].id
                _save_state(db, link, state)
            await send_message(
                chat_id,
                WELCOME_TEXT.format(
                    name=html.escape(user.display_name or user.email),
                    model=html.escape(model_name),
                    balance=_balance_text(db, user),
                    verified=_verified_label(link) if link else "—",
                ),
                keyboard=main_keyboard(db, user),
            )
            return "linked"

        user, link = resolve_user(db, int(telegram_user_id))
        if user is not None and link is not None:
            await send_message(
                chat_id,
                WELCOME_TEXT.format(
                    name=html.escape(user.display_name or user.email),
                    model=html.escape(_current_model(db, user, link).display_name if _current_model(db, user, link) else "—"),
                    balance=_balance_text(db, user),
                    verified=_verified_label(link),
                ),
                keyboard=main_keyboard(db, user),
            )
            return "welcome"
        await send_message(chat_id, LINK_REQUIRED_TEXT, keyboard=[[_button("🔢 شناسهٔ من / my id", "menu:whoami")]])
        return "unlinked"

    user, link = resolve_user(db, int(telegram_user_id))
    if user is None or link is None:
        # `/whoami` must work *before* linking — it is how the user learns the number to save.
        if command in ("/whoami", "/id"):
            await send_message(chat_id, _numeric_id_help(int(telegram_user_id)))
            return "whoami_unlinked"
        if command in ("/help", "/menu", "/start"):
            await send_message(chat_id, LINK_REQUIRED_TEXT, keyboard=[[_button("🔢 شناسهٔ من / my id", "menu:whoami")]])
            return "unlinked"
        await send_message(chat_id, LINK_REQUIRED_TEXT, keyboard=[[_button("🔢 شناسهٔ من / my id", "menu:whoami")]])
        return "unlinked"

    link.last_message_at = dt.datetime.now(dt.timezone.utc)
    link.message_count = (link.message_count or 0) + 1
    if not link.chat_id:
        link.chat_id = int(chat_id)      # the profile-declared link only learns the chat here
    db.commit()

    if command in ("/help", "/commands"):
        await send_message(chat_id, HELP_TEXT, keyboard=main_keyboard(db, user))
        return "help"

    if command in ("/menu", "/start"):
        await _send_menu(chat_id, db, user)
        return "menu"

    if command in ("/whoami", "/id"):
        await send_message(chat_id, _numeric_id_help(link.telegram_user_id))
        return "whoami"

    if command in ("/status", "/account"):
        await _send_status(chat_id, db, user, link)
        return "status"

    if command == "/balance":
        await send_message(chat_id, f"💳 اعتبار شما / your balance: <b>{_balance_text(db, user)}</b> credits",
                           keyboard=main_keyboard(db, user))
        return "balance"

    if command == "/usage":
        await _send_usage(chat_id, db, user)
        return "usage"

    if command in ("/models", "/model"):
        try:
            page = int(argument.strip()) if argument.strip() else 1
        except ValueError:
            page = 1
        await _send_models(chat_id, db, user, link, page)
        return "models"

    if command == "/use":
        models = _accessible_models(db, user)
        try:
            index = int(argument.strip())
        except ValueError:
            await send_message(chat_id, "شمارهٔ مدل را بفرستید، مثلاً /use 2\nSend the number, e.g. /use 2")
            return "use_bad"
        if not 1 <= index <= len(models):
            await send_message(
                chat_id,
                f"شمارهٔ نامعتبر — بین ۱ تا {len(models)} (همان شماره‌ای که /models نشان می‌دهد).\n"
                f"Invalid number — pick 1…{len(models)}, exactly as numbered by /models.",
            )
            return "use_bad"
        model = models[index - 1]
        state = _state(link)
        state["model_id"] = model.id
        state.pop("conversation_id", None)
        state.pop("variant_id", None)
        _save_state(db, link, state)
        variants = variant_service.list_variants(db, model_id=model.id, actor=user)
        extra = ""
        if variants:
            names = ", ".join(f"{v.name}" for v in variants[:8])
            extra = f"\n🎛 نسخه‌ها / variants: {html.escape(names)}\nبا /variants انتخاب کنید."
        await send_message(
            chat_id,
            f"✅ مدل انتخاب شد / model selected: <b>{html.escape(model.display_name)}</b>{extra}",
            keyboard=[[_button("🧠 مدل‌ها / models", "menu:models"), _button("🎛 نسخه‌ها / variants", "menu:variants")]],
        )
        return "use"

    if command == "/variants":
        await _send_variants(chat_id, db, user, link)
        return "variants"

    if command == "/usev":
        state = _state(link)
        model = _current_model(db, user, link)
        if model is None:
            await send_message(chat_id, "ابتدا یک مدل انتخاب کنید / select a model first.")
            return "usev"
        variants = variant_service.list_variants(db, model_id=model.id, actor=user)
        try:
            index = int(argument.strip())
        except ValueError:
            await send_message(chat_id, "شمارهٔ نسخه را بفرستید، مثلاً /usev 1")
            return "usev_bad"
        if index == 0:
            state.pop("variant_id", None)
            state.pop("conversation_id", None)
            _save_state(db, link, state)
            await send_message(chat_id, "✅ حالت خام مدل فعال شد / raw model selected.")
            return "usev"
        if not 1 <= index <= len(variants):
            await send_message(chat_id, f"شمارهٔ نامعتبر. بین ۱ تا {len(variants)}.")
            return "usev_bad"
        variant = variants[index - 1]
        state["variant_id"] = variant.id
        state.pop("conversation_id", None)
        _save_state(db, link, state)
        await send_message(
            chat_id,
            f"✅ نسخه انتخاب شد / variant selected: <b>{html.escape(variant.name)}</b>\n"
            f"🧩 پرامپت سیستمی / system prompt: {len(variant.system_prompt or '')} کاراکتر",
        )
        return "usev"

    if command == "/new":
        state = _state(link)
        state.pop("conversation_id", None)
        _save_state(db, link, state)
        await send_message(chat_id, "🆕 گفتگوی تازه آماده است. پیام بعدی شما شروع می‌کند.\nNew conversation ready.")
        return "new"

    if command.startswith("/"):
        await send_message(chat_id, "دستور ناشناخته — /help را بفرستید.\nUnknown command — send /help.",
                           keyboard=main_keyboard(db, user))
        return "unknown_command"

    # --- free text: a real model call, charged to the same account -----------
    return await _run_chat(db, user=user, link=link, chat_id=int(chat_id), text=text)


async def _run_chat(db: Session, *, user: User, link: TelegramLink, chat_id: int, text: str) -> str:
    models = _accessible_models(db, user)
    if not models:
        await send_message(chat_id, "⚠️ برای حساب شما مدلی منتشر نشده است. با مدیر تماس بگیرید.\n"
                                    "No model is published for your account — contact the administrator.")
        return "no_model"
    state = _state(link)
    model = next((m for m in models if m.id == state.get("model_id")), models[0])
    variant = None
    if state.get("variant_id"):
        try:
            variant = variant_service.resolve_for_request(db, model=model, user=user, variant_id=state["variant_id"])
        except ValidationError as exc:
            state.pop("variant_id", None)
            _save_state(db, link, state)
            await send_message(chat_id, f"⚠️ {html.escape(exc.detail)}")
    conversation = _conversation_for(db, user, model, link)
    if variant is not None:
        conversation.variant_id = variant.id
        db.commit()

    await send_typing(chat_id)
    try:
        ref = ai_service.resolve_model(db, user=user, model_id=model.id, operation="chat")
    except NexaError as exc:
        # Log *why* a message was refused (model, reason, balance): an operator reading the log should
        # never have to guess which model the bot picked for a user.
        log.info(
            "telegram: model %s (%s) refused for user %s: %s",
            model.id, model.provider_model_id, user.id, exc,
        )
        await send_message(chat_id, f"⛔️ {html.escape(exc.detail)}")
        return "not_allowed"

    user_message = Message(
        conversation_id=conversation.id,
        user_id=user.id,
        role=MessageRole.USER,
        content=text,
        model_id=model.id,
    )
    db.add(user_message)
    db.flush()

    answer_parts: list[str] = []
    charge_note = ""
    error_note = ""
    async for event in ai_service.stream_chat(
        db,
        user=user,
        model_ref=ref,
        messages=_history(db, conversation) or [ai_service.ChatMessage(role="user", content=text)],
        system=variant_service.system_prompt_for(variant),
        temperature=float(variant.default_temperature) if variant and variant.default_temperature is not None else None,
        max_tokens=variant.default_max_tokens if variant else None,
        module="telegram",
        conversation_id=conversation.id,
        variant_id=variant.id if variant else None,
        idempotency_key=f"telegram:{user_message.id}",
    ):
        if event.type == "delta":
            answer_parts.append(event.data.get("text", ""))
        elif event.type == "done":
            from app.services.pricing import micro_to_credits

            charged = event.data.get("charged_micro") or 0
            charge_note = f"\n\n— {micro_to_credits(charged)} credits" if charged else ""
        elif event.type == "error":
            error_note = event.data.get("message") or "provider failure"

    answer = "".join(answer_parts).strip()
    assistant = Message(
        conversation_id=conversation.id,
        user_id=user.id,
        role=MessageRole.ASSISTANT,
        content=answer,
        model_id=model.id,
        error_category=None if answer else error_note or "unknown",
    )
    db.add(assistant)
    conversation.message_count = (conversation.message_count or 0) + 1
    db.commit()

    if not answer:
        await send_message(chat_id, f"⚠️ پاسخ سرویس‌دهنده دریافت نشد / no answer from the provider:\n{html.escape(error_note)}")
        return "provider_error"
    await send_message(chat_id, html.escape(answer) + charge_note)


async def handle_callback(db: Session, update: dict[str, Any]) -> str:
    """Handle an inline-keyboard tap (menu navigation, model/variant selection)."""
    query = update.get("callback_query") or {}
    data = (query.get("data") or "").strip()
    message = query.get("message") or {}
    chat_id = (message.get("chat") or {}).get("id")
    sender = query.get("from") or {}
    telegram_user_id = sender.get("id")
    message_id = message.get("message_id")
    callback_id = query.get("id") or ""
    if not data or not chat_id or not telegram_user_id:
        return "ignored"
    if not is_configured(db):
        return "not_configured"

    if data == "menu:whoami":
        await answer_callback(callback_id, "🔢")
        await send_message(chat_id, _numeric_id_help(int(telegram_user_id)))
        return "cb_whoami"

    user, link = resolve_user(db, int(telegram_user_id))
    if user is None or link is None:
        await answer_callback(callback_id, "🔒 ابتدا در سایت ثبت کنید / register on the site first", alert=True)
        await send_message(chat_id, LINK_REQUIRED_TEXT, keyboard=[[_button("🔢 شناسهٔ من / my id", "menu:whoami")]])
        return "cb_unlinked"

    link.last_message_at = dt.datetime.now(dt.timezone.utc)
    if not link.chat_id:
        link.chat_id = int(chat_id)
    db.commit()
    await answer_callback(callback_id, "✅")

    if data == "menu:home":
        await send_message(chat_id, MENU_TEXT, keyboard=main_keyboard(db, user))
        return "cb_menu"
    if data == "menu:models":
        await _send_models(chat_id, db, user, link, 1, edit=message_id)
        return "cb_models"
    if data.startswith("models:"):
        try:
            page = int(data.split(":", 1)[1])
        except ValueError:
            page = 1
        await _send_models(chat_id, db, user, link, page, edit=message_id)
        return "cb_models_page"
    if data.startswith("model:"):
        try:
            model_id = int(data.split(":", 1)[1])
        except ValueError:
            return "cb_model_bad"
        models = _accessible_models(db, user)
        model = next((m for m in models if m.id == model_id), None)
        if model is None:
            await send_message(chat_id, "این مدل برای حساب شما در دسترس نیست / that model is not available to you.")
            return "cb_model_denied"
        state = _state(link)
        state["model_id"] = model.id
        state.pop("conversation_id", None)
        state.pop("variant_id", None)
        _save_state(db, link, state)
        await send_message(
            chat_id,
            f"✅ مدل انتخاب شد / model selected: <b>{html.escape(model.display_name)}</b>\n"
            "پیام بعدی شما به این مدل می‌رود / your next message goes to this model.",
            keyboard=main_keyboard(db, user),
        )
        return "cb_model"
    if data == "menu:variants":
        await _send_variants(chat_id, db, user, link, edit=message_id)
        return "cb_variants"
    if data.startswith("variant:"):
        try:
            variant_id = int(data.split(":", 1)[1])
        except ValueError:
            return "cb_variant_bad"
        state = _state(link)
        model = _current_model(db, user, link)
        if model is None:
            return "cb_variant_nomodel"
        if variant_id == 0:
            state.pop("variant_id", None)
            state.pop("conversation_id", None)
            _save_state(db, link, state)
            await send_message(chat_id, "✅ حالت خام مدل فعال شد / raw model selected.", keyboard=main_keyboard(db, user))
            return "cb_variant_raw"
        variants = variant_service.list_variants(db, model_id=model.id, actor=user)
        variant = next((v for v in variants if v.id == variant_id), None)
        if variant is None:
            await send_message(chat_id, "این نسخه دیگر موجود نیست / that variant no longer exists.")
            return "cb_variant_missing"
        state["variant_id"] = variant.id
        state.pop("conversation_id", None)
        _save_state(db, link, state)
        await send_message(
            chat_id,
            f"✅ نسخه انتخاب شد / variant selected: <b>{html.escape(variant.name)}</b>",
            keyboard=main_keyboard(db, user),
        )
        return "cb_variant"
    if data == "menu:status":
        await _send_status(chat_id, db, user, link)
        return "cb_status"
    if data == "menu:balance":
        await send_message(chat_id, f"💳 اعتبار شما / your balance: <b>{_balance_text(db, user)}</b> credits",
                           keyboard=main_keyboard(db, user))
        return "cb_balance"
    if data == "menu:usage":
        await _send_usage(chat_id, db, user)
        return "cb_usage"
    if data == "menu:help":
        await send_message(chat_id, HELP_TEXT, keyboard=main_keyboard(db, user))
        return "cb_help"
    if data == "menu:new":
        state = _state(link)
        state.pop("conversation_id", None)
        _save_state(db, link, state)
        await send_message(chat_id, "🆕 گفتگوی تازه آماده است / new conversation ready.")
        return "cb_new"
    return "cb_unknown"


async def handle_update(db: Session, update: dict[str, Any]) -> str:
    """Process one Telegram update (message or inline-keyboard tap)."""
    if update.get("callback_query"):
        return await handle_callback(db, update)
    return await handle_message(db, update)


# ---------------------------------------------------------------- transports -----
async def process_updates(offset: int | None = None, *, limit: int = 20, timeout: int = 30) -> tuple[int, int]:
    """One getUpdates round. Returns (next_offset, handled_count)."""
    payload: dict[str, Any] = {
        "timeout": timeout, "limit": limit,
        "allowed_updates": ["message", "edited_message", "callback_query"],
    }
    if offset is not None:
        payload["offset"] = offset
    updates = await call_api("getUpdates", payload, timeout=timeout + 15)
    handled = 0
    next_offset = offset or 0
    for update in updates:
        next_offset = max(next_offset, int(update.get("update_id", 0)) + 1)
        db = SessionLocal()
        try:
            result = await handle_update(db, update)
            handled += 1
            log.info("telegram update %s -> %s", update.get("update_id"), result)
        except Exception as exc:  # noqa: BLE001
            db.rollback()
            log.exception("telegram update failed: %s", exc)
        finally:
            db.close()
    return next_offset, handled


def _token_fingerprint(db: Session) -> str:
    refresh_token(db)
    token = bot_token()
    return token[-8:] if token else ""


async def run_polling(stop_event) -> None:  # noqa: ANN001
    """Long-polling loop (used by the worker when NEXA_TELEGRAM_MODE=polling).

    The bot token is re-read from the settings table on every idle cycle, so an operator who enters
    or rotates it in **Admin → Settings → Telegram** is served immediately — without restarting the
    service. The command list is published once per token so Telegram shows a tidy menu button.
    """
    offset: int | None = None
    announced = ""
    get_me_announced = ""
    failures = 0
    while not stop_event.is_set():
        db = SessionLocal()
        try:
            fingerprint = _token_fingerprint(db)
        finally:
            db.close()
        if not fingerprint:
            await _sleep(stop_event, 5)
            continue
        db = SessionLocal()
        try:
            enabled = bool(settings_store.get_value(db, "telegram.enabled", settings.telegram_enabled))
        finally:
            db.close()
        if not enabled:
            # A token exists but the operator switched the bot off in the panel: stay idle (and keep
            # checking) instead of answering messages the operator disabled.
            await _sleep(stop_event, 5)
            continue
        if fingerprint != announced:
            # `getMe` decides whether the token works; the two housekeeping calls are cosmetic and a
            # failure in either (an older Bot API that lacks setMyCommands, a transient 5xx) must never
            # delay answering messages.
            try:
                me = await get_me()
            except NexaError as exc:
                log.warning("telegram polling: %s", exc)
                await _sleep(stop_event, 5)
                continue
            get_me_announced = str(me.get("username") or "")
            log.info("telegram polling: connected as @%s", get_me_announced)
            for call, label in ((delete_webhook(), "deleteWebhook"), (set_my_commands(), "setMyCommands")):
                try:
                    await call
                except NexaError as exc:
                    log.warning("telegram polling: %s failed (not fatal): %s", label, exc)
            announced = fingerprint
        try:
            offset, handled = await process_updates(offset)
            if handled:
                log.info("telegram: handled %s update(s)", handled)
            failures = 0
        except NexaError as exc:
            # Back off gently: a single dropped long-poll must be retried within a second or two, while
            # a real outage must not hammer the API.
            failures += 1
            delay = min(1.5**failures, 20.0)
            log.warning("telegram polling: %s (retrying in %.1fs)", exc, delay)
            await _sleep(stop_event, delay)
        except Exception as exc:  # noqa: BLE001
            failures += 1
            log.exception("telegram polling crashed: %s", exc)
            await _sleep(stop_event, min(2.0**failures, 30.0))


async def _sleep(stop_event, seconds: float) -> None:  # noqa: ANN001
    """Sleep for `seconds`, waking early when the stop signal fires.

    The stop signal arrives as a `threading.Event` from both entry points (the worker
    process and the API's inline worker), and as an `asyncio.Event` from async callers.
    `threading.Event.wait()` returns a *bool* and cannot be awaited: awaiting it raised
    "object bool can't be used in 'await' expression", which killed the polling loop at
    the first transient network error. Both kinds are handled here.
    """
    import asyncio
    import inspect
    import threading

    if stop_event is None:
        await asyncio.sleep(seconds)
        return

    waiter = getattr(stop_event, "wait", None)
    if waiter is None:
        await asyncio.sleep(seconds)
        return

    if isinstance(stop_event, threading.Event):
        # Never call the blocking wait on the loop thread.
        await asyncio.get_running_loop().run_in_executor(None, waiter, seconds)
        return

    try:
        outcome = waiter(seconds)
    except TypeError:
        # asyncio.Event.wait() takes no timeout and returns a coroutine.
        outcome = waiter()

    if inspect.isawaitable(outcome):
        try:
            await asyncio.wait_for(outcome, timeout=seconds)
        except asyncio.TimeoutError:
            pass
        return


async def set_webhook(url: str) -> dict[str, Any]:
    payload: dict[str, Any] = {"url": url, "allowed_updates": ["message", "edited_message", "callback_query"]}
    secret = settings_store_secret_webhook()
    if secret:
        payload["secret_token"] = secret
    return await call_api("setWebhook", payload)


def settings_store_secret_webhook() -> str:
    """Webhook secret from the environment (the value is also accepted from the settings table)."""
    return settings.telegram_webhook_secret or ""

