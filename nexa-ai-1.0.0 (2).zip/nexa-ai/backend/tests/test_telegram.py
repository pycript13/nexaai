"""Telegram bot: linking, welcome, guided commands and real (billed) model interaction.

These tests run against a *fake Telegram Bot API server* (`tests/tools/fake_telegram.py`),
which behaves like the real one for the methods the bot uses (``getMe``, ``getUpdates``,
``sendMessage``, ``sendChatAction``, ``setWebhook``, ``deleteWebhook``) and records every
message the bot sends. Nothing is mocked inside the platform: the service builds real HTTP
requests, the updates are parsed from real JSON, the chat calls go through the ordinary chat
pipeline (provider transport mocked at the network edge like every other test) and the charge
lands on the ordinary ledger.
"""
from __future__ import annotations

import json
import re
import threading
import uuid

import httpx
import pytest
from sqlalchemy import select

from app.core.config import settings
from app.models.billing import UsageRecord
from app.models.telegram import TelegramLink
from app.models.user import User
from tests.conftest import create_provider_and_model, grant_credits
from tests.tools.fake_telegram import FakeTelegramServer


@pytest.fixture()
def telegram(monkeypatch: pytest.MonkeyPatch):
    """Start the fake Bot API server and point the platform at it."""
    server = FakeTelegramServer()
    port = server.start()
    monkeypatch.setattr(settings, "telegram_enabled", True)
    monkeypatch.setattr(settings, "telegram_bot_token", "123456:TEST-TOKEN")
    monkeypatch.setattr(settings, "telegram_bot_username", "nexa_test_bot")
    monkeypatch.setattr(settings, "telegram_api_base", f"http://127.0.0.1:{port}")
    monkeypatch.setattr(settings, "telegram_mode", "polling")
    yield server
    server.stop()


def _unique_telegram_id() -> int:
    """A Telegram id nobody claimed yet.

    One Telegram id may be linked to exactly one platform account (enforced by ``set_numeric_id`` and
    ``consume_link_code``), and the test database is shared by the whole run — so hard-coded ids made a
    later test answer as the *previous* test's account. Every call returns a fresh id.
    """
    import random
    import uuid

    return 500_000_000 + (uuid.uuid4().int + random.randint(0, 999)) % 400_000_000


def _send(server: FakeTelegramServer, text: str, *, telegram_user_id: int, chat_id: int | None = None,
          username: str = "tester") -> None:
    server.push_update({
        "update_id": server.next_update_id(),
        "message": {
            "message_id": server.next_message_id(),
            "from": {"id": telegram_user_id, "is_bot": False, "first_name": "Test", "username": username},
            "chat": {"id": chat_id or telegram_user_id, "type": "private"},
            "date": 1700000000,
            "text": text,
        },
    })


def _poll(server: FakeTelegramServer, db) -> list[str]:
    """Run one polling round and return the texts the bot sent."""
    import asyncio

    from app.services import telegram as telegram_service

    before = len(server.sent)
    # The real polling loop confirms each batch by passing the next offset; without it
    # the Bot API (and this fake) redelivers every earlier update, which made tests that
    # send several commands order-dependent.
    next_offset, _ = asyncio.run(
        telegram_service.process_updates(server.offset, limit=20, timeout=1)
    )
    server.offset = next_offset
    return [m["text"] for m in server.sent[before:]]


def test_bot_status_reports_configuration(user_client, telegram: FakeTelegramServer) -> None:
    body = user_client.get("/api/v1/telegram/status").json()
    assert body["linked"] is False
    assert body["bot_configured"] is True          # the fixture configured it
    assert body["bot_username"] == "nexa_test_bot"


def test_link_code_flow_and_welcome_message(user_client, db, telegram: FakeTelegramServer, monkeypatch) -> None:
    user = db.scalars(select(User).where(User.email == user_client.email)).first()
    code_response = user_client.post("/api/v1/telegram/link-code")
    assert code_response.status_code == 201, code_response.text
    body = code_response.json()
    assert body["code"]
    assert body["deep_link"].endswith(body["code"])

    telegram_user_id = 555001
    _send(telegram, f"/start {body['code']}", telegram_user_id=telegram_user_id)
    sent = _poll(telegram, db)

    assert sent, "the bot must answer /start"
    welcome = "\n".join(sent)
    assert "خوش آمدید" in welcome or "Welcome" in welcome
    assert "/help" in welcome, "the welcome message must carry the usage guide"

    db.expire_all()
    link = db.scalars(select(TelegramLink).where(TelegramLink.telegram_user_id == telegram_user_id)).first()
    assert link is not None
    assert link.user_id == user.id
    assert link.enabled is True
    assert link.message_count >= 0

    status = user_client.get("/api/v1/telegram/status").json()
    assert status["linked"] is True
    assert status["telegram_user_id"] == telegram_user_id


def test_an_unlinked_telegram_user_gets_instructions_and_no_access(user_client, db, telegram: FakeTelegramServer) -> None:
    _send(telegram, "سلام، جواب بده", telegram_user_id=_unique_telegram_id())
    sent = _poll(telegram, db)
    assert sent and ("کد اتصال" in sent[0] or "not linked" in sent[0].lower())
    assert db.scalars(select(UsageRecord).where(UsageRecord.module == "telegram")).first() is None


def test_a_link_code_is_single_use_and_expires(user_client, db, telegram: FakeTelegramServer) -> None:
    first_id = _unique_telegram_id()
    second_id = _unique_telegram_id()
    code = user_client.post("/api/v1/telegram/link-code").json()["code"]
    _send(telegram, f"/start {code}", telegram_user_id=first_id)
    assert _poll(telegram, db), "first use links the account"

    # second use of the same code must be refused, and must not create a second link
    _send(telegram, f"/start {code}", telegram_user_id=second_id)
    sent = _poll(telegram, db)
    assert sent and any("نامعتبر" in text or "Invalid" in text for text in sent)
    assert db.scalars(select(TelegramLink).where(TelegramLink.telegram_user_id == second_id)).first() is None


def _walk_models(server: FakeTelegramServer, db, telegram_user_id: int, needle: str) -> tuple[str, int | None, int]:
    """Ask for /models page by page until `needle` shows up (returns text, number, pages)."""
    page = 1
    pages = 1
    while page <= pages and page <= 25:
        _send(server, f"/models {page}", telegram_user_id=telegram_user_id)
        text = "\n".join(_poll(server, db))
        match = re.search(r"صفحه (\d+) از (\d+)", text)
        if match:
            pages = int(match.group(2))
        number = None
        for line in text.splitlines():
            if needle in line:
                found = re.search(r"(\d+)\.", line)
                number = int(found.group(1)) if found else None
        if number is not None:
            return text, number, pages
        page += 1
    return text, None, pages


def test_help_and_models_commands(user_client, db, telegram: FakeTelegramServer) -> None:
    provider, model = create_provider_and_model(db, published=True, display_name="Test Chat Model")
    telegram_user_id = _unique_telegram_id()
    code = user_client.post("/api/v1/telegram/link-code").json()["code"]
    _send(telegram, f"/start {code}", telegram_user_id=telegram_user_id)
    _poll(telegram, db)

    _send(telegram, "/help", telegram_user_id=telegram_user_id)
    help_text = "\n".join(_poll(telegram, db))
    assert "/balance" in help_text and "/models" in help_text

    models_text, number, pages = _walk_models(telegram, db, telegram_user_id, "Test Chat Model")
    assert number is not None, f"the model must be reachable through /models pagination, saw: {models_text}"
    # A cap must never be silent: every page states the page count and the real total.
    assert re.search(r"صفحه \d+ از \d+ · مجموع (\d+) مدل", models_text), models_text

    # The printed number works with /use, including on later pages.
    _send(telegram, f"/use {number}", telegram_user_id=telegram_user_id)
    used = "\n".join(_poll(telegram, db))
    assert "Test Chat Model" in used, used


def test_models_pagination_lists_every_model_and_use_rejects_an_out_of_range_number(
    user_client, db, telegram: FakeTelegramServer
) -> None:
    created = [
        create_provider_and_model(db, published=True, display_name=f"Paginated Model {index}")[1]
        for index in range(1, 4)
    ]
    telegram_user_id = _unique_telegram_id()
    code = user_client.post("/api/v1/telegram/link-code").json()["code"]
    _send(telegram, f"/start {code}", telegram_user_id=telegram_user_id)
    _poll(telegram, db)

    # every created model is reachable, i.e. nothing is silently dropped
    reachable = []
    for model in created:
        _text, number, _pages = _walk_models(telegram, db, telegram_user_id, model.display_name)
        reachable.append(number)
    assert all(number is not None for number in reachable), reachable
    assert reachable == sorted(reachable), "numbering must match the list order"

    # The upper bound quoted by the refusal must be the total the listing itself shows —
    # never a hard-coded number (the accessible catalogue can hold any number of models).
    _send(telegram, "/models", telegram_user_id=telegram_user_id)
    listing = "\n".join(_poll(telegram, db))
    total = re.search(r"مجموع (\d+) مدل", listing)
    assert total, listing
    expected_bound = total.group(1)

    _send(telegram, "/use 99999", telegram_user_id=telegram_user_id)
    refused = "\n".join(_poll(telegram, db))
    assert "نامعتبر" in refused and "بین" in refused
    assert expected_bound in refused, f"the refusal must state the real upper bound ({expected_bound}): {refused}"


def test_a_message_reaches_the_model_and_is_charged(user_client, db, telegram: FakeTelegramServer,
                                                   mock_provider_transport) -> None:
    captured: dict = {}

    def handler(request):  # noqa: ANN001
        captured["body"] = json.loads(request.content.decode())
        return httpx.Response(200, content=(
            'data: {"id":"x","object":"chat.completion.chunk","choices":[{"index":0,"delta":{"content":"سلام "},"finish_reason":null}]}\n\n'
            'data: {"id":"x","object":"chat.completion.chunk","choices":[{"index":0,"delta":{"content":"از ربات"},"finish_reason":null}]}\n\n'
            'data: {"id":"x","object":"chat.completion.chunk","choices":[{"index":0,"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":9,"completion_tokens":4}}\n\n'
            "data: [DONE]\n\n"
        ), headers={"content-type": "text/event-stream"})

    mock_provider_transport(handler)
    provider, model = create_provider_and_model(db, published=True)
    grant_credits(db, user_client.email, 10.0)

    telegram_user_id = _unique_telegram_id()
    code = user_client.post("/api/v1/telegram/link-code").json()["code"]
    _send(telegram, f"/start {code}", telegram_user_id=telegram_user_id)
    _poll(telegram, db)

    _send(telegram, "یک جمله بگو", telegram_user_id=telegram_user_id)
    sent = _poll(telegram, db)
    assert any("از ربات" in text for text in sent), sent
    assert any("credits" in text for text in sent), "the answer must state what it cost"

    db.expire_all()
    record = db.scalars(
        select(UsageRecord).where(UsageRecord.module == "telegram").order_by(UsageRecord.id.desc())
    ).first()
    assert record is not None
    assert record.user_id is not None
    # the bot answers with *some* accessible model — other tests in this file also publish
    # models, so the exact one is intentionally not pinned here
    assert record.model_id is not None
    assert (record.charged_micro or 0) > 0, "a Telegram message must be charged like a web message"
    assert captured["body"]["stream"] is True


def test_switching_off_a_variant_is_honoured_in_telegram(user_client, admin_client, db,
                                                         telegram: FakeTelegramServer,
                                                         mock_provider_transport) -> None:
    def handler(request):  # noqa: ANN001
        return httpx.Response(200, content=(
            'data: {"choices":[{"delta":{"content":"ok"},"finish_reason":null}]}\n\n'
            "data: [DONE]\n\n"
        ), headers={"content-type": "text/event-stream"})

    mock_provider_transport(handler)
    provider, model = create_provider_and_model(db, published=True)
    grant_credits(db, user_client.email, 10.0)

    variant = admin_client.post(
        f"/api/v1/admin/model-variants/models/{model.id}",
        json={"name": "Telegram coder", "system_prompt": "You only write code.", "scope": "system",
              "enabled": False},
    ).json()["variant"]
    assert variant["enabled"] is False

    telegram_user_id = _unique_telegram_id()
    code = user_client.post("/api/v1/telegram/link-code").json()["code"]
    _send(telegram, f"/start {code}", telegram_user_id=telegram_user_id)
    _poll(telegram, db)

    _send(telegram, "/usev 1", telegram_user_id=telegram_user_id)
    sent = "\n".join(_poll(telegram, db))
    assert "نامعتبر" in sent or "Invalid" in sent, "a disabled variant must not be selectable: " + sent

# --------------------------------------------------------------- resilience ------
def test_sleep_accepts_both_stop_signal_kinds() -> None:
    """Regression: `await threading.Event.wait()` raised "object bool can't be used in
    'await' expression", which killed the polling loop at the first network error."""
    import asyncio
    import threading
    import time

    from app.services.telegram import _sleep

    asyncio.run(_sleep(threading.Event(), 0.01))
    asyncio.run(_sleep(asyncio.Event(), 0.01))
    asyncio.run(_sleep(None, 0.01))

    event = threading.Event()

    async def wakes_early() -> float:
        asyncio.get_running_loop().call_later(0.05, event.set)
        started = time.time()
        await _sleep(event, 5)
        return time.time() - started

    elapsed = asyncio.run(wakes_early())
    assert elapsed < 1.5, f"a set stop signal must interrupt the sleep immediately (took {elapsed:.2f}s)"


def test_polling_survives_a_transient_failure_and_keeps_answering(
    user_client, db, telegram: FakeTelegramServer, monkeypatch
) -> None:
    """One failed getUpdates must not end polling; the next update is still handled."""
    import asyncio
    import threading

    from app.services import telegram as telegram_service

    telegram_user_id = _unique_telegram_id()
    code = user_client.post("/api/v1/telegram/link-code").json()["code"]
    _send(telegram, f"/start {code}", telegram_user_id=telegram_user_id)
    _poll(telegram, db)

    calls = {"n": 0}
    real_call = telegram_service.call_api

    async def flaky(method, payload=None, **kwargs):  # noqa: ANN001, ANN201
        if method == "getUpdates":
            calls["n"] += 1
            if calls["n"] == 1:
                raise telegram_service.NexaError("Telegram is unreachable: ConnectError", category="connectivity")
        return await real_call(method, payload, **kwargs)

    monkeypatch.setattr(telegram_service, "call_api", flaky)

    _send(telegram, "/balance", telegram_user_id=telegram_user_id)
    stop = threading.Event()
    sent_before = len(telegram.sent)

    async def run_briefly() -> None:
        task = asyncio.create_task(telegram_service.run_polling(stop))
        for _ in range(60):
            if len(telegram.sent) > sent_before:
                break
            await asyncio.sleep(0.1)
        stop.set()
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

    asyncio.run(run_briefly())
    assert len(telegram.sent) > sent_before, "the bot stopped answering after one network error"
    assert calls["n"] >= 2, "polling must retry after a failure"
