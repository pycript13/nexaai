"""Round-12 contracts: sign-up that actually signs in, panel-managed Telegram credentials, the
registration gate on the bot, the host guard, and the confirmation rule for admin-created users.

Every one of these was a real defect found while fixing “my friend cannot create an account” and
“there is no field to enter the bot token”:
"""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.telegram import TelegramLink
from app.models.user import User
from app.services import settings_store, telegram as telegram_service
from tests.tools.fake_telegram import FakeTelegramServer


#: Settings rows this module writes. The suite shares one database, so a value left behind would
#: change what a later test sees (that is exactly how `test_bot_status_reports_configuration` broke).
TELEGRAM_SETTING_KEYS = (
    "telegram.bot_token",
    "telegram.enabled",
    "telegram.webhook_secret",
    "telegram.bot_username",
)


@pytest.fixture(autouse=True)
def _clean_telegram_settings():
    """Remove the panel-written Telegram settings after each test in this module."""
    from app.db.session import SessionLocal
    from app.models.admin import AppSetting

    yield
    with SessionLocal() as session:
        for row in session.scalars(select(AppSetting).where(AppSetting.key.in_(TELEGRAM_SETTING_KEYS))).all():
            session.delete(row)
        session.commit()
        telegram_service.refresh_token(session)


@pytest.fixture()
def telegram(monkeypatch: pytest.MonkeyPatch):
    """A fake Bot API server, so `is_configured()` is true without network access."""
    server = FakeTelegramServer()
    port = server.start()
    monkeypatch.setattr(settings, "telegram_enabled", True)
    monkeypatch.setattr(settings, "telegram_bot_token", "123456:TEST-TOKEN")
    monkeypatch.setattr(settings, "telegram_bot_username", "nexa_test_bot")
    monkeypatch.setattr(settings, "telegram_api_base", f"http://127.0.0.1:{port}")
    monkeypatch.setattr(settings, "telegram_mode", "polling")
    yield server
    server.stop()

REGISTER_PAYLOAD = {
    "email": "round12-signup@example.org",
    "display_name": "Round Twelve",
    "password": "Round12-Passphrase-2026",
    "locale": "fa",
}


# ----------------------------------------------------------------- sign-up ----
def test_register_requires_both_consents(client: TestClient) -> None:
    """The screen used to send only `accept_terms`; the API needs the privacy flag as well."""
    partial = client.post("/api/v1/auth/register", json={**REGISTER_PAYLOAD, "accept_terms": True})
    assert partial.status_code == 422
    assert partial.json()["error"]["details"]["fields"]["accept_privacy"] == "Field required"


def test_register_signs_the_new_account_in(client: TestClient) -> None:
    """A visitor handed the link must land *inside* the app, not back on the sign-in screen."""
    response = client.post(
        "/api/v1/auth/register",
        json={**REGISTER_PAYLOAD, "accept_terms": True, "accept_privacy": True},
    )
    assert response.status_code == 201, response.text
    body = response.json()
    assert body["signed_in"] is True
    assert body["csrf_token"]
    assert body["verification_required"] is False
    assert "session" in response.cookies or "nexa_session" in response.cookies

    # The very next request is authenticated — that is what the SPA relies on.
    me = client.get("/api/v1/auth/me")
    assert me.status_code == 200
    assert me.json()["user"]["email"] == REGISTER_PAYLOAD["email"]

    # And the account can sign in again after signing out (the second half of the report).
    client.post("/api/v1/auth/logout", json={})
    again = client.post(
        "/api/v1/auth/login",
        json={"email": REGISTER_PAYLOAD["email"], "password": REGISTER_PAYLOAD["password"]},
    )
    assert again.status_code == 200


def test_registration_policy_is_public(client: TestClient) -> None:
    """The form shows the real password policy instead of letting the API reject it silently."""
    meta = client.get("/api/v1/meta/config").json()
    assert meta["registration_mode"] in ("open", "invite_only", "closed")
    assert bool(meta["registration_enabled"]) == (meta["registration_mode"] != "closed")
    assert isinstance(meta["password_min_length"], int) and meta["password_min_length"] >= 8


# --------------------------------------------------- host guard (Codespaces) --
def _guarded_client(allowed: list[str], *, allow_dev: bool = False) -> TestClient:
    """A minimal app carrying the real guard, so the middleware is exercised as deployed."""
    from fastapi import FastAPI

    from app.core.host_guard import HostGuardMiddleware

    app = FastAPI()
    app.add_middleware(HostGuardMiddleware, allowed_hosts=allowed, allow_dev_hosts=allow_dev)

    @app.get("/readyz")
    def readyz() -> dict[str, str]:  # pragma: no cover - trivial
        return {"status": "ok"}

    return TestClient(app)


def test_dev_forwarded_host_is_accepted() -> None:
    """A GitHub Codespaces / tunnel URL must serve the app: that is the link a friend receives."""
    client = _guarded_client(["nexa.example.com"], allow_dev=True)
    for host in ("8081-abc123.app.github.dev", "8081-abc.e2b.app", "nexa.example.com:8080"):
        response = client.get("/readyz", headers={"host": host})
        assert response.status_code == 200, f"{host} was refused: {response.text}"


def test_unknown_host_is_refused_with_an_actionable_error() -> None:
    client = _guarded_client(["nexa.example.com"], allow_dev=False)
    response = client.get("/readyz", headers={"host": "not-my-host.example.com"})
    assert response.status_code == 400
    error = response.json()["error"]
    assert error["code"] == "host_not_allowed"
    assert "not-my-host.example.com" in error["message"]
    assert error["details"]["allowed_hosts"] == ["nexa.example.com"]
    assert "NEXA_TRUSTED_HOSTS" in error["details"]["how_to_fix"]
    # The dev suffix must NOT be accepted when dev hosts are switched off (production).
    assert client.get("/readyz", headers={"host": "8081-abc123.app.github.dev"}).status_code == 400


# ------------------------------------------------- panel-set Telegram token ---
def _admin_headers(admin_client) -> dict[str, str]:  # noqa: ANN001
    """The session's CSRF token: every sensitive admin write must carry it."""
    return dict(admin_client.headers)


def test_admin_can_store_the_bot_token_without_touching_env(admin_client, db: Session, monkeypatch, telegram) -> None:
    """The operator enters the token in Admin → Settings → Telegram; nothing is edited on disk."""
    calls: list[str] = []

    async def fake_get_me() -> dict:
        calls.append("getMe")
        return {"id": 42, "username": "nexa_unit_bot", "first_name": "Nexa"}

    async def fake_commands() -> dict:
        calls.append("setMyCommands")
        return {"ok": True}

    monkeypatch.setattr(telegram_service, "get_me", fake_get_me)
    monkeypatch.setattr(telegram_service, "set_my_commands", fake_commands)

    saved = admin_client.put(
        "/api/v1/admin/telegram/token", json={"token": "424242:AAF-this-is-a-valid-looking-token"}
    )
    assert saved.status_code == 200, saved.text
    body = saved.json()
    assert body["configured"] is True
    assert body["token"]["source"] == "database"          # the panel, not the environment file
    assert body["token"]["hint"].startswith("…")          # masked, never the value
    assert "424242:AAF" not in saved.text

    # Encrypted at rest, and the API never echoes it back.
    stored = settings_store._row(db, telegram_service.BOT_TOKEN_SETTING_KEY)
    assert stored is not None and stored.is_secret is True
    assert "AAF-this-is-a-valid-looking-token" not in str(stored.value_json)

    tested = admin_client.post("/api/v1/admin/telegram/test")
    assert tested.status_code == 200, tested.text
    assert tested.json()["bot"]["username"] == "nexa_unit_bot"
    assert tested.json()["token_source"] == "database"
    assert tested.json()["commands_registered"] is True
    assert calls == ["getMe", "setMyCommands"]

    cleared = admin_client.put("/api/v1/admin/telegram/token", json={"clear": True})
    assert cleared.status_code == 200
    assert cleared.json()["token"]["source"] == "environment"


def test_admin_token_must_look_like_a_token(admin_client) -> None:
    response = admin_client.put("/api/v1/admin/telegram/token", json={"token": "nope"})
    assert response.status_code == 422
    assert "BotFather" in response.json()["error"]["message"]


def test_telegram_enable_switch_is_stored(admin_client, db: Session) -> None:
    off = admin_client.put("/api/v1/admin/telegram/enabled", json={"enabled": False})
    assert off.status_code == 200
    assert off.json()["enabled"] is False and off.json()["enabled_source"] == "database"
    on = admin_client.put("/api/v1/admin/telegram/enabled", json={"enabled": True})
    assert on.json()["enabled"] is True


# ------------------------------------------------- the bot answers only known ids
def test_webhook_fails_closed_without_a_secret(client: TestClient, telegram) -> None:
    """An unauthenticated update would let anyone impersonate a registered Telegram id."""
    response = client.post(
        "/api/v1/telegram/webhook",
        json={"update_id": 1, "message": {"chat": {"id": 1}, "from": {"id": 1}, "text": "/start"}},
    )
    assert response.status_code == 422
    assert response.json()["error"]["details"]["reason"] == "webhook_secret_required"


def test_webhook_rejects_a_wrong_secret(client: TestClient, db: Session, telegram) -> None:
    settings_store.set_secret(db, "telegram.webhook_secret", "s3cret-value-for-tests")
    response = client.post(
        "/api/v1/telegram/webhook",
        json={"update_id": 1, "message": {"chat": {"id": 1}, "from": {"id": 1}, "text": "/start"}},
        headers={"x-telegram-bot-api-secret-token": "wrong"},
    )
    assert response.status_code in (401, 403)


def test_registered_id_is_recognised_and_strangers_are_not(user_client, db: Session, telegram) -> None:
    """The gate itself: an id saved in the profile is served, everybody else gets instructions."""
    user = db.scalars(select(User).where(User.email == user_client.email)).first()
    assert user is not None
    registered = 612345678

    saved = user_client.post("/api/v1/telegram/numeric-id", json={"telegram_user_id": registered})
    assert saved.status_code == 200, saved.text
    assert saved.json()["telegram_user_id"] == registered
    assert saved.json()["verified_via"] == "profile"

    import asyncio

    known = asyncio.run(
        telegram_service.handle_message(
            db,
            {
                "update_id": 99,
                "message": {
                    "message_id": 5,
                    "chat": {"id": registered, "type": "private"},
                    "from": {"id": registered, "is_bot": False, "first_name": "Round"},
                    "text": "/start",
                },
            },
        )
    )
    assert known == "welcome", "a registered id must be greeted and given the guide"

    stranger = asyncio.run(
        telegram_service.handle_message(
            db,
            {
                "update_id": 100,
                "message": {
                    "message_id": 6,
                    "chat": {"id": 999000777, "type": "private"},
                    "from": {"id": 999000777, "is_bot": False, "first_name": "Nobody"},
                    "text": "/start",
                },
            },
        )
    )
    assert stranger == "unlinked", "an id that is not registered on the site must not get in"


def test_a_numeric_id_belongs_to_exactly_one_account(user_client, second_user_client, db: Session) -> None:
    claimed = user_client.post("/api/v1/telegram/numeric-id", json={"telegram_user_id": 611111111})
    assert claimed.status_code == 200
    stolen = second_user_client.post("/api/v1/telegram/numeric-id", json={"telegram_user_id": 611111111})
    assert stolen.status_code == 422
    assert "another account" in stolen.json()["error"]["message"]


def test_a_code_verified_link_cannot_be_moved_silently(user_client, db: Session, telegram) -> None:
    """The “proven” badge must keep describing reality."""
    code = user_client.post("/api/v1/telegram/link-code").json()
    user = db.scalars(select(User).where(User.email == user_client.email)).first()
    assert user is not None
    linked = telegram_service.consume_link_code(db, code=code["code"], telegram_user_id=600000001, chat_id=600000001)
    assert linked is not None and linked.id == user.id
    db.expire_all()
    link = db.scalars(select(TelegramLink).where(TelegramLink.user_id == user.id)).first()
    assert link is not None and link.verified_via == "code"

    moved = user_client.post("/api/v1/telegram/numeric-id", json={"telegram_user_id": 600000002})
    assert moved.status_code == 422
    assert moved.json()["error"]["details"]["reason"] == "code_verified_link"


# ------------------------------------------------------ admin-created users ----
def test_creating_a_user_requires_confirmation_and_can_carry_any_role(admin_client, db: Session) -> None:
    base = {
        "email": "round12-created@example.org",
        "display_name": "Created By Admin",
        "roles": ["user", "support_agent"],
        "initial_credit_micro": 2_500_000,
    }
    unconfirmed = admin_client.post("/api/v1/admin/users", json=base)
    assert unconfirmed.status_code == 422, "a sensitive write without confirmation must be refused"

    created = admin_client.post("/api/v1/admin/users", json={**base, "confirm": True})
    assert created.status_code == 201, created.text
    payload = created.json()
    assert payload["generated_password"] and payload["generated_password"].startswith("Nx-")
    assert sorted(role["slug"] for role in payload["user"]["roles"]) == ["support_agent", "user"]

    user = db.scalars(select(User).where(User.email == base["email"])).first()
    assert user is not None and user.must_change_password is True
    from app.services import ledger as ledger_service

    assert ledger_service.balance_of(db, user.id) == 2_500_000

    # The password is shown once and never stored in clear text.
    assert payload["generated_password"] not in (user.password_hash or "")


def test_first_contact_greeting_carries_the_usage_guide() -> None:
    """The welcome must teach the commands, because that is the whole onboarding."""
    text = telegram_service.WELCOME_TEXT.format(name="X", model="m", balance="1", verified="ok")
    for command in ("/models", "/balance", "/usage", "/status", "/menu", "/help"):
        assert command in text


def test_mask_secret_never_reveals_the_head() -> None:
    from app.core.crypto import mask_secret

    token = "8441353245:AAH-super-secret-part"
    masked = mask_secret(token)
    assert masked == "…" + token[-4:]
    assert "8441353245" not in masked
    assert masked != token


# --------------------------------------------------------- invitations --------
def test_invitation_only_registration_works_end_to_end(admin_client, client: TestClient, db: Session) -> None:
    """`registration.mode = invite_only` used to be a dead end: nothing could issue a token."""
    from app.services import settings_store

    settings_store.set_value(db, "registration.mode", "invite_only")
    try:
        blocked = client.post(
            "/api/v1/auth/register",
            json={**REGISTER_PAYLOAD, "email": "no-invite@example.org", "accept_terms": True, "accept_privacy": True},
        )
        assert blocked.status_code == 422
        assert "invitation" in blocked.json()["error"]["message"].lower()

        issued = admin_client.post(
            "/api/v1/admin/users/invitations",
            json={"email": "guest@example.org", "expires_days": 7, "note": "for the pilot team"},
        )
        assert issued.status_code == 201, issued.text
        body = issued.json()
        assert body["token"] and body["link"].endswith(body["token"])
        assert body["link"].startswith("http") and "/register?invite=" in body["link"]

        listing = admin_client.get("/api/v1/admin/users/invitations").json()
        active = [item for item in listing["items"] if item["email"] == "guest@example.org"]
        assert active and active[0]["status"] == "active" and active[0]["used"] is False

        registered = client.post(
            "/api/v1/auth/register",
            json={
                **REGISTER_PAYLOAD,
                "email": "guest@example.org",
                "accept_terms": True,
                "accept_privacy": True,
                "invitation_token": body["token"],
            },
        )
        assert registered.status_code == 201, registered.text
        assert registered.json()["signed_in"] is True

        # single use
        again = client.post(
            "/api/v1/auth/register",
            json={
                **REGISTER_PAYLOAD,
                "email": "guest2@example.org",
                "accept_terms": True,
                "accept_privacy": True,
                "invitation_token": body["token"],
            },
        )
        assert again.status_code == 422
        assert "already been used" in again.json()["error"]["message"]

        used = admin_client.get("/api/v1/admin/users/invitations").json()
        entry = [item for item in used["items"] if item["email"] == "guest@example.org"][0]
        assert entry["status"] == "used"
    finally:
        settings_store.set_value(db, "registration.mode", "open")


def test_a_revoked_invitation_cannot_be_used(admin_client, client: TestClient, db: Session) -> None:
    issued = admin_client.post("/api/v1/admin/users/invitations", json={"email": "revoked@example.org"})
    assert issued.status_code == 201
    invitation_id = admin_client.get("/api/v1/admin/users/invitations").json()["items"][0]["id"]
    revoked = admin_client.delete(f"/api/v1/admin/users/invitations/{invitation_id}")
    assert revoked.status_code == 200

    from app.services import settings_store

    settings_store.set_value(db, "registration.mode", "invite_only")
    try:
        attempt = client.post(
            "/api/v1/auth/register",
            json={
                **REGISTER_PAYLOAD,
                "email": "revoked@example.org",
                "accept_terms": True,
                "accept_privacy": True,
                "invitation_token": issued.json()["token"],
            },
        )
        assert attempt.status_code == 422
        assert "revoked" in attempt.json()["error"]["message"]
    finally:
        settings_store.set_value(db, "registration.mode", "open")


def test_an_ordinary_user_cannot_issue_invitations(user_client) -> None:
    response = user_client.post("/api/v1/admin/users/invitations", json={"email": "sneaky@example.org"})
    assert response.status_code == 403


# ------------------------------- the deployment owns which policies may be selected ----
def test_a_forbidden_registration_policy_is_refused(monkeypatch: pytest.MonkeyPatch, admin_client, db: Session) -> None:
    """A deployment that forbids ``closed`` must not have a panel that silently re-closes it.

    The sign-up page is the whole point of round 12: an operator may restrict which policies the
    console can select (``NEXA_ALLOWED_REGISTRATION_MODES``), and the API must enforce that rule
    instead of writing a value it will then refuse to serve.
    """
    monkeypatch.setattr(settings, "allowed_registration_modes", "open,invite_only")
    try:
        refused = admin_client.patch(
            "/api/v1/admin/settings/registration.mode", json={"value": "closed", "confirm": True}
        )
        assert refused.status_code == 422, refused.text
        details = refused.json()["error"]["details"]
        assert details["requested"] == "closed"
        assert details["allowed"] == ["invite_only", "open"]
        assert "NEXA_ALLOWED_REGISTRATION_MODES" in details["changed_by"]

        allowed = admin_client.patch(
            "/api/v1/admin/settings/registration.mode", json={"value": "invite_only", "confirm": True}
        )
        assert allowed.status_code == 200, allowed.text
        assert allowed.json()["value"] == "invite_only"
    finally:
        settings_store.set_value(db, "registration.mode", "open")


def test_the_policy_that_is_served_is_never_a_forbidden_one(monkeypatch: pytest.MonkeyPatch, client: TestClient, db: Session) -> None:
    """A stale database row must never re-open (or re-close) a policy the deployment forbids."""
    settings_store.set_value(db, "registration.mode", "closed")
    monkeypatch.setattr(settings, "allowed_registration_modes", "open")
    try:
        config = client.get("/api/v1/auth/config").json()
        assert config["registration_mode"] == "open"
        assert config["registration_enabled"] is True
        assert config["allowed_registration_modes"] == ["open"]
        meta = client.get("/api/v1/meta/config").json()
        assert meta["registration_mode"] == "open"
        assert meta["registration_enabled"] is True
    finally:
        settings_store.set_value(db, "registration.mode", "open")


def test_an_unknown_policy_list_falls_back_to_all_three(monkeypatch: pytest.MonkeyPatch) -> None:
    """Typo or emptiness must never make the sign-up page a dead end."""
    for raw in ("", "   ", "banana", "open,banana"):
        monkeypatch.setattr(settings, "allowed_registration_modes", raw)
        allowed = settings.allowed_registration_mode_set
        assert allowed, f"{raw!r} left an empty policy set"
        assert allowed <= {"open", "invite_only", "closed"}
        assert settings.effective_registration_mode("closed") in allowed
    monkeypatch.setattr(settings, "allowed_registration_modes", "")
    assert settings.allowed_registration_mode_set == {"open", "invite_only", "closed"}
