/**
 * Proves the whole UI path: pick a sub-model in the chat composer, send a message,
 * watch the stream, then ask the provider upstream what it actually received.
 */
const puppeteer = require("puppeteer-core");
const BASE = process.env.BASE_URL || "http://127.0.0.1:8081";
const UPSTREAM = process.env.UPSTREAM_URL || "http://127.0.0.1:9099";

(async () => {
  const browser = await puppeteer.launch({ executablePath: "/usr/bin/chromium", args: ["--no-sandbox", "--disable-gpu"] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 1000 });
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
  await page.type('input[type="email"]', process.env.NEXA_EMAIL || "admin@example.com");
  await page.type('input[type="password"]', process.env.NEXA_PASSWORD);
  await Promise.all([page.waitForNavigation({ waitUntil: "networkidle2" }).catch(() => {}), page.click('button[type="submit"]')]);

  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle2" });
  await new Promise((r) => setTimeout(r, 1500));

  // Choose the sub-model that the feature check created.
  const chosen = await page.evaluate(() => {
    const selects = [...document.querySelectorAll("select")];
    const picker = selects.find((select) =>
      [...select.options].some((option) => option.textContent.includes("Code assistant")),
    );
    if (!picker) return null;
    const option = [...picker.options].find((item) => item.textContent.includes("Code assistant"));
    picker.value = option.value;
    picker.dispatchEvent(new Event("change", { bubbles: true }));
    return option.textContent.trim();
  });
  console.log("selected sub-model ->", chosen);

  await new Promise((r) => setTimeout(r, 600));
  await page.type("textarea", "write a python function to reverse a string");
  await new Promise((r) => setTimeout(r, 300));
  await page.evaluate(() => {
    const send = [...document.querySelectorAll("button")].find((button) =>
      (button.textContent || "").includes("ارسال") || (button.textContent || "").includes("Send"),
    );
    send.click();
  });

  // wait for the streamed answer to land in the thread
  await new Promise((r) => setTimeout(r, 4000));
  const thread = await page.evaluate(() => (document.querySelector(".chat-thread") || {}).innerText || "");
  console.log("thread text ->", thread.replace(/\s+/g, " ").slice(0, 220));
  await page.screenshot({ path: process.env.OUT || "/home/user/responsive-shots/features/chat-stream-with-variant.png", fullPage: true });

  const upstream = await fetch(`${UPSTREAM}/__requests`).then((r) => r.json());
  const last = [...upstream.requests].reverse().find((r) => String(r.path).endsWith("/chat/completions"));
  const messages = (last.body || {}).messages || [];
  console.log("upstream messages ->", JSON.stringify(messages).slice(0, 260));
  console.log("system prompt applied ->", messages[0]?.role === "system" && messages[0]?.content.includes("only write code"));
  console.log("answer streamed          ->", thread.includes("recovered") || thread.includes("demo") || thread.includes("Nexa AI"));
  await browser.close();
})().catch((error) => {
  console.error("FAILED:", error.message);
  process.exit(1);
});
