/**
 * Preview verifier: drives the running Nexa AI preview with a real browser.
 *
 * It signs in, walks the main screens in the light, dark and glass themes plus a phone
 * viewport, captures screenshots and reports every console error and failed request.
 * Nothing here ships with the product — it only proves the UI it was built to verify.
 */
const puppeteer = require("puppeteer-core");
const fs = require("fs");
const path = require("path");

const BASE = process.env.PREVIEW_URL || "http://127.0.0.1:8081";
const EMAIL = process.env.PREVIEW_EMAIL || "admin@example.com";
const PASSWORD = process.env.PREVIEW_PASSWORD || "Nexa-Preview-Admin-2026!";
const OUT = process.env.SHOT_DIR || "/home/user/preview-shots";

// `GET /api/v1/auth/me` is called before sign-in to detect an existing session; the 401 it
// answers with is the correct, expected "not signed in yet" reply, not a defect.
const AUTH_PROBE_ALLOWED = /\/api\/v1\/auth\/me\b/;
const problems = [];
const shots = [];

async function shot(page, name, fullPage = true) {
  const file = path.join(OUT, `${name}.png`);
  await page.screenshot({ path: file, fullPage });
  const size = fs.statSync(file).size;
  shots.push(`${name}.png (${(size / 1024).toFixed(0)} kB)`);
}

async function main() {
  fs.mkdirSync(OUT, { recursive: true });
  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium",
    headless: true,
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--font-render-hinting=none", "--lang=fa-IR", "--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 950, deviceScaleFactor: 1 });

  page.on("console", (message) => {
    if (message.type() === "error" && !/401 \(Unauthorized\)/.test(message.text())) {
      problems.push(`console: ${message.text().slice(0, 300)}`);
    }
  });
  page.on("pageerror", (error) => problems.push(`pageerror: ${String(error).slice(0, 300)}`));
  page.on("requestfailed", (request) => {
    const url = request.url();
    if (!url.includes("favicon")) problems.push(`request failed: ${url} (${request.failure()?.errorText})`);
  });
  page.on("response", (response) => {
    if (response.status() === 401 && response.url().includes("/auth/me")) return; // expected session probe before sign-in
    if (response.status() >= 400 && !response.url().includes("favicon")) {
      problems.push(`http ${response.status()}: ${response.url()}`);
    }
  });

  // ---------------------------------------------------------------- login page
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
  await page.waitForSelector(".auth__card", { timeout: 15000 });
  await new Promise((resolve) => setTimeout(resolve, 700));
  await shot(page, "01-login-light");

  // ---------------------------------------------------------------- sign in
  await page.type('input[type="email"]', EMAIL);
  await page.type('input[type="password"]', PASSWORD);
  await Promise.all([
    page.waitForFunction(() => window.location.pathname.startsWith("/app"), { timeout: 20000 }),
    page.click('button[type="submit"]'),
  ]);
  await page.waitForSelector(".hero", { timeout: 20000 });
  await new Promise((resolve) => setTimeout(resolve, 1200));
  await shot(page, "02-dashboard-light");

  // ---------------------------------------------------------------- dark theme
  await page.evaluate(() => localStorage.setItem("nexa.theme", "dark"));
  await page.reload({ waitUntil: "networkidle2" });
  await page.waitForSelector(".hero", { timeout: 20000 });
  await new Promise((resolve) => setTimeout(resolve, 900));
  await shot(page, "03-dashboard-dark");

  // ---------------------------------------------------------------- glass theme
  await page.evaluate(() => localStorage.setItem("nexa.theme", "glass"));
  await page.reload({ waitUntil: "networkidle2" });
  await page.waitForSelector(".hero", { timeout: 20000 });
  await new Promise((resolve) => setTimeout(resolve, 900));
  await shot(page, "04-dashboard-glass");

  // back to light for the guided walk-through
  await page.evaluate(() => localStorage.setItem("nexa.theme", "light"));

  const screens = [
    ["/app/chat", "05-chat", ".chat-layout"],
    ["/app/models", "06-models", ".card, .table-wrap, .empty"],
    ["/app/images", "07-images", ".card, .empty"],
    ["/app/billing", "08-billing", ".card, .kv, .empty"],
    ["/app/payments", "09-payments", ".card, .table-wrap, .empty"],
    ["/app/usage", "10-usage", ".card, .empty"],
    ["/app/files", "11-files", ".card, .empty"],
    ["/app/security", "12-security", ".card"],
    ["/app/admin", "13-admin-overview", ".card, .stat"],
    ["/app/admin/providers", "14-admin-providers", ".card, .table-wrap, .empty"],
    ["/app/admin/models", "15-admin-models", ".card, .table-wrap, .empty"],
    ["/app/admin/payments", "16-admin-payments", ".card, .table-wrap, .empty"],
    ["/app/admin/audit", "17-admin-audit", ".card, .table-wrap, .empty"],
    ["/app/admin/settings", "18-admin-settings", ".card"],
    ["/app/admin/system", "19-admin-system", ".card, .kv"],
  ];

  for (const [route, name, selector] of screens) {
    await page.goto(`${BASE}${route}`, { waitUntil: "networkidle2" });
    try {
      await page.waitForSelector(selector, { timeout: 15000 });
    } catch (error) {
      problems.push(`${route}: expected content (${selector}) never rendered`);
    }
    await new Promise((resolve) => setTimeout(resolve, 900));
    const leaked = await page.evaluate(() => {
      const text = document.body.innerText || "";
      const hits = [];
      if (text.includes("[object Object]")) hits.push("[object Object]");
      if (/\bundefined\b/.test(text)) hits.push("undefined");
      if (/\bNaN\b/.test(text)) hits.push("NaN");
      return hits;
    });
    if (leaked.length) problems.push(`${route}: rendered text leaks ${leaked.join(", ")}`);
    await shot(page, name);
    if (["/app/models", "/app/billing", "/app/admin/providers"].includes(route)) {
      const plain = path.join(OUT, `${name}-viewport.png`);
      await page.screenshot({ path: plain, fullPage: false });
      shots.push(`${name}-viewport.png`);
    }
  }

  // ---------------------------------------------------------------- chat round trip
  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle2" });
  await page.waitForSelector(".composer textarea", { timeout: 15000 });

  // a chat needs a model: wait for the catalogue to arrive, then pick the first entry
  try {
    await page.waitForFunction(
      () => Boolean(document.querySelector('.composer select option[value]:not([value=""])')),
      { timeout: 20000 },
    );
  } catch (error) {
    problems.push("chat: the model selector never received a model from /api/v1/models");
  }
  const chosen = await page.evaluate(() => {
    const select = document.querySelector(".composer select");
    if (!select) return null;
    const option = Array.from(select.options).find((item) => item.value);
    if (!option) return null;
    select.value = option.value;
    select.dispatchEvent(new Event("change", { bubbles: true }));
    return option.textContent;
  });
  if (!chosen) problems.push("chat: the model selector offered no model");
  else console.log("chat model:", chosen);

  const box = await page.$(".composer textarea");
  if (box) {
    await box.click();
    await page.keyboard.type("Preview check: reply with a short greeting.");
    const sendButton = await page.evaluateHandle(() => {
      const buttons = Array.from(document.querySelectorAll(".composer button"));
      return buttons.find((button) => /send|ارسال/i.test(button.textContent || "")) || null;
    });
    const found = await sendButton.evaluate((element) => Boolean(element));
    if (found) {
      await sendButton.asElement().click();
      try {
        await page.waitForFunction(
          () => Array.from(document.querySelectorAll(".bubble--assistant")).some((node) => (node.textContent || "").includes("mock-answer")),
          { timeout: 30000 },
        );
      } catch (error) {
        problems.push("chat: no assistant answer arrived within 30s");
      }
      await new Promise((resolve) => setTimeout(resolve, 800));
      await shot(page, "20-chat-conversation");
    } else {
      problems.push("chat: send button not found in the composer");
    }
  }

  // ---------------------------------------------------------------- language switch (through the UI)
  await page.goto(`${BASE}/app`, { waitUntil: "networkidle2" });
  await page.waitForSelector(".hero", { timeout: 20000 });
  const openedMenu = await page.evaluate(() => {
    const button = document.querySelector(".user-chip .iconbtn");
    if (!button) return false;
    button.click();
    return true;
  });
  if (!openedMenu) problems.push("language menu: the language button was not found");
  await new Promise((resolve) => setTimeout(resolve, 400));
  const switched = await page.evaluate(() => {
    const button = Array.from(document.querySelectorAll(".lang-row button")).find((node) =>
      /english/i.test(node.textContent || ""),
    );
    if (!button) return false;
    button.click();
    return true;
  });
  if (!switched) problems.push("language menu: the English option was not found");
  await new Promise((resolve) => setTimeout(resolve, 1200));
  const dir = await page.evaluate(() => document.documentElement.dir);
  if (dir !== "ltr") problems.push(`english locale rendered dir=${dir}`);
  await shot(page, "24-dashboard-en-ltr");

  // back to Persian for the remaining checks
  await page.evaluate(() => {
    const button = document.querySelector(".user-chip .iconbtn");
    if (button) button.click();
  });
  await new Promise((resolve) => setTimeout(resolve, 400));
  await page.evaluate(() => {
    const button = Array.from(document.querySelectorAll(".lang-row button")).find((node) =>
      /فارسی/.test(node.textContent || ""),
    );
    if (button) button.click();
  });
  await new Promise((resolve) => setTimeout(resolve, 800));

  // ---------------------------------------------------------------- mobile
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await page.goto(`${BASE}/app`, { waitUntil: "networkidle2" });
  await page.waitForSelector(".hero", { timeout: 20000 });
  await new Promise((resolve) => setTimeout(resolve, 900));
  await shot(page, "21-mobile-dashboard");

  const drawerButton = await page.$(".topbar__menu");
  if (drawerButton) {
    await drawerButton.click();
    await new Promise((resolve) => setTimeout(resolve, 700));
    await shot(page, "22-mobile-drawer");
  } else {
    problems.push("mobile: the drawer button is not visible at 390px");
  }

  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
  await new Promise((resolve) => setTimeout(resolve, 700));
  await shot(page, "23-mobile-login");

  await browser.close();

  console.log(JSON.stringify({ base: BASE, shots, problems }, null, 2));
  if (problems.length) process.exitCode = 1;
}

main().catch((error) => {
  console.error("verifier crashed:", error);
  process.exit(2);
});
