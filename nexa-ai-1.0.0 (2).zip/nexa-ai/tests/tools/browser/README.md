# Browser checks (headless Chromium via `puppeteer-core`)

Optional, developer-facing checks that drive the **running** application in a real browser. They are
not part of the pytest suites (they need a browser binary and a live server); they exist because two
rounds of operator-reported bugs — a dialog with two close buttons and no save, and an admin screen
that crashed — were invisible to API tests and only reproducible in a browser.

```bash
# a live server (SQLite preview stack, or your own deployment)
npm install puppeteer-core                 # in this folder, or anywhere on NODE_PATH
BASE=http://127.0.0.1:8080 \
EMAIL=admin@example.com PASSWORD='…' \
CHROME=/usr/bin/chromium \
node check-admin-pages.cjs                # every admin + workspace route, phone + desktop
BASE=… EMAIL=… PASSWORD=… node check-model-dialog.cjs   # the model dialog, end to end
```

What `check-admin-pages.cjs` asserts: no console errors, no failed `/api/v1/*` calls, no horizontal
overflow at 390×844 and 1440×900, and that the role-permission editor really renders its checkboxes.

What `check-model-dialog.cjs` asserts: the model-edit dialog contains exactly **one** dismiss control
and exactly **one** save button, that typing a change and pressing Save persists it (re-read from the
server after a reload), and that the platform owner is never shown the “credits needed” message in the
catalogue. Screenshots and a `report.json` land in `SHOT_DIR` (default `/tmp/nexa-browser-shots`).

## The round-12 checks

The four scripts below are the ones the round-12 report quotes. They run against a live server and a
real browser, and each of them exits non-zero with the exact reason when something regressed.

| Script | What it proves |
| --- | --- |
| `check-register.cjs` | a stranger handed the link can create an account and sign in (phone + desktop, fa + en) |
| `check-round12.cjs` | the admin console: Telegram card, user creation with roles from the panel, the one-time password really signs in, 403s for ordinary accounts, the profile's Telegram gate |
| `check-alignment.cjs` | every control in the same container shares a height and a baseline at 390 / 768 / 1440 px (`--self-test` injects a 14 px offset and requires the checker to report it) |
| `check-round12b.cjs` | the command palette (Ctrl/⌘ K, permission-aware, four languages) and the registration-policy card (a real change, verified through `/api/v1/auth/config`) |
| `check-telegram-bot.cjs` | the bot with a real token: the webhook secret is enforced, a stranger is refused, a registered id is greeted with its real data, buttons and commands work |

```bash
npm install puppeteer-core
BASE=http://127.0.0.1:8080 EMAIL=admin@example.com PASSWORD='…' node check-round12b.cjs
node check-alignment.cjs http://127.0.0.1:8080 admin@example.com '…'      # or positional arguments
```

`CHROME=/usr/bin/chromium` (or the path to your Chrome/Chromium) and `SHOT_DIR` (default
`/tmp/nexa-*`) are honoured by all of them.

## The rest of the harnesses quoted in `docs/TEST_REPORT.md`

| Script | Round it belongs to |
| --- | --- |
| `check-chat-reasoning.cjs` | reasoning models: the chain of thought is separated from the answer (streaming included) |
| `check-sync-ux.cjs` | provider sync: counts, drafts, and the button that opens the imported models |
| `variant-stream-check.cjs` | sub-model variants: the variant's system prompt really reaches the provider |
| `user-flow-check.cjs` | the workspace journey of an ordinary account (chat, images, files, billing …) |
| `mobile-audit.cjs` | responsiveness measured at five phone/tablet widths (overflow, tap targets, text size) |
| `page-recheck.cjs` | re-checks a single page that a sweep reported (used to separate a real defect from a screenshot hiccup) |
| `verify-preview.cjs` | a quick end-to-end sanity pass over a running preview |
