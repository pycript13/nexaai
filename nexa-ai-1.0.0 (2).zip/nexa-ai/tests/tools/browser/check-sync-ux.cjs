// The admin path that was reported as "the provider connects but the models never arrive":
//   Admin -> Providers -> Sync  must show a readable result and lead to the imported drafts,
//   Admin -> Models?published=false must list them.
const puppeteer = require("puppeteer-core");
const fs = require("fs");

const BASE = process.env.BASE_URL || "http://127.0.0.1:8081";
const SHOT_DIR = process.env.SHOT_DIR || "/home/user/preview-shots-20261014";
const ADMIN = { email: "admin@example.com", password: "Nexa-Preview-Admin-2026!" };

(async () => {
  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium",
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader"],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 1000 });
  const problems = [];

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
  await page.type('input[type="email"]', ADMIN.email);
  await page.type('input[type="password"]', ADMIN.password);
  await Promise.all([
    page.waitForNavigation({ waitUntil: "networkidle2" }).catch(() => {}),
    page.click('button[type="submit"]'),
  ]);

  await page.goto(`${BASE}/app/admin/providers`, { waitUntil: "networkidle2" });
  await new Promise((r) => setTimeout(r, 1500));

  // press Sync on the provider that answers the non-standard model-list shape
  const clicked = await page.evaluate(() => {
    const rows = [...document.querySelectorAll("tbody tr")];
    const row = rows.find((r) => /Shapes Test/.test(r.innerText));
    if (!row) return null;
    // the admin UI runs in the operator's own language (fa here): match both labels, else take the
    // last button in the row, which is the sync action in every locale
    const buttons = [...row.querySelectorAll("button")];
    const button = buttons.find((b) => /sync|همگام/i.test(b.innerText)) || buttons[buttons.length - 1];
    if (!button) return null;
    button.click();
    return row.innerText.split("\n")[0];
  });
  if (!clicked) problems.push("the sync button was not found on the provider row");
  await new Promise((r) => setTimeout(r, 3000));

  const card = await page.evaluate(() => {
    const cards = [...document.querySelectorAll("section, div.card, .card")];
    const target = cards.find((c) => /Model synchronisation/.test(c.innerText));
    return target ? target.innerText : null;
  });
  console.log("sync card:", JSON.stringify(card));
  if (!card) problems.push("the synchronisation result card did not appear");
  else {
    if (!/imported|refreshed|at the provider/.test(card)) problems.push("the card shows no counts");
    if (!/Open the unpublished models/.test(card)) problems.push("the card does not link to the drafts");
  }
  await page.screenshot({ path: `${SHOT_DIR}/50-provider-sync-result.png` });

  // follow the link the card offers
  const went = await page.evaluate(() => {
    const button = [...document.querySelectorAll("button")].find((b) => /Open the unpublished models/.test(b.innerText));
    if (!button) return false;
    button.click();
    return true;
  });
  if (!went) problems.push("the 'Open the unpublished models' button was missing");
  await new Promise((r) => setTimeout(r, 2500));
  const models = await page.evaluate(() => ({
    url: location.pathname + location.search,
    body: document.body.innerText.slice(0, 1200),
    drafts: [...document.querySelectorAll("tbody tr")].filter((r) => /shape-test/i.test(r.innerText)).length,
  }));
  console.log("after the link:", models.url, "| draft rows:", models.drafts);
  if (models.drafts < 2) problems.push("the imported models are not listed on the models page");
  await page.screenshot({ path: `${SHOT_DIR}/51-models-waiting-for-verification.png` });

  fs.mkdirSync(SHOT_DIR, { recursive: true });
  console.log(JSON.stringify({ problems }, null, 2));
  await browser.close();
  process.exit(problems.length ? 1 : 0);
})().catch((error) => {
  console.error("checker crashed:", error);
  process.exit(2);
});
