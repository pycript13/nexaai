/**
 * Checks the *normal user* experience of the running preview in a real browser.
 *
 * A registered account with an empty balance must still see an honest, actionable screen:
 * the catalogue explains why the model is not usable, and the chat page repeats that exact
 * reason with a link to Billing instead of claiming that no model exists at all.
 *
 * Usage: node user-flow-check.cjs
 */
const puppeteer = require("puppeteer-core");
const fs = require("fs");
const path = require("path");

const BASE = process.env.PREVIEW_URL || "http://127.0.0.1:8081";
const EMAIL = process.env.PREVIEW_USER_EMAIL || "demo.user@example.com";
const PASSWORD = process.env.PREVIEW_USER_PASSWORD || "Demo-User-Passw0rd!";
const OUT = process.env.SHOT_DIR || "/home/user/preview-shots-20261014";

const problems = [];
const shots = [];

async function shot(page, name) {
  const file = path.join(OUT, `${name}.png`);
  await page.screenshot({ path: file, fullPage: true });
  shots.push(`${name}.png (${(fs.statSync(file).size / 1024).toFixed(0)} kB)`);
}

async function main() {
  fs.mkdirSync(OUT, { recursive: true });
  const browser = await puppeteer.launch({
    executablePath: process.env.CHROME_PATH || "/usr/bin/chromium",
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"],
    defaultViewport: { width: 1440, height: 950 },
  });
  const page = await browser.newPage();
  page.on("pageerror", (error) => problems.push(`pageerror: ${String(error).slice(0, 200)}`));
  page.on("console", (message) => {
    if (message.type() === "error" && !/401 \(Unauthorized\)/.test(message.text())) {
      problems.push(`console: ${message.text().slice(0, 200)}`);
    }
  });

  // ---- sign in as the seeded normal user -------------------------------------
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
  await page.type('input[type="email"]', EMAIL);
  await page.type('input[type="password"]', PASSWORD);
  await Promise.all([
    page.waitForNavigation({ waitUntil: "networkidle2" }).catch(() => {}),
    page.click('button[type="submit"]'),
  ]);
  await new Promise((r) => setTimeout(r, 1500));

  const headerText = await page.evaluate(() => document.body.innerText);
  if (/Super Admin/i.test(headerText) || /مدیر کل/.test(headerText)) {
    problems.push(`${EMAIL} signed in with administrator rights — the normal-user check is meaningless`);
  }

  // ---- the chat page must state the *real* reason, with a Billing link --------
  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle2" });
  await new Promise((r) => setTimeout(r, 2000));
  const chatText = await page.evaluate(() => document.body.innerText);
  await shot(page, "30-user-chat-blocked");

  const expected = /balance is empty|Add credits|اعتبار/i;
  if (!expected.test(chatText)) {
    problems.push("chat: no explanation for the unavailable model was rendered");
  }
  if (!/(No model is usable|هیچ مدلی با حساب شما قابل استفاده نیست)/.test(chatText)) {
    problems.push("chat: the blocked-model headline is missing (the old text blamed the administrator)");
  }
  if (!/billing|صورت‌حساب|صورتحساب/i.test(chatText)) {
    problems.push("chat: the explanation does not link to Billing");
  }

  // ---- the catalogue agrees with the API --------------------------------------
  await page.goto(`${BASE}/app/models`, { waitUntil: "networkidle2" });
  await new Promise((r) => setTimeout(r, 1200));
  const catalogText = await page.evaluate(() => document.body.innerText);
  await shot(page, "31-user-catalog");
  if (!/Mock Chat Large/i.test(catalogText)) {
    problems.push("catalog: the published model is not listed for the normal user");
  }

  // ---- a manual top-up must credit nothing until an administrator approves ----
  await page.goto(`${BASE}/app/payments`, { waitUntil: "networkidle2" });
  await new Promise((r) => setTimeout(r, 1200));
  await shot(page, "32-user-payments");
  const paymentsText = await page.evaluate(() => document.body.innerText);
  if (/بودجه.*(افزایش|واریز شد)/.test(paymentsText) && !/در انتظار بررسی|awaiting/i.test(paymentsText)) {
    problems.push("payments: a credit appears to have been granted without administrator approval");
  }

  // ---- phone width on the same account ----------------------------------------
  await page.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true });
  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle2" });
  await new Promise((r) => setTimeout(r, 1500));
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  if (overflow > 2) problems.push(`chat on a 390px phone overflows horizontally by ${overflow}px`);
  await shot(page, "33-user-chat-phone");

  await browser.close();
  console.log(JSON.stringify({ base: BASE, account: EMAIL, shots, problems }, null, 2));
  process.exit(problems.length ? 1 : 0);
}

main().catch((error) => {
  console.error("user-flow-check failed:", error);
  process.exit(2);
});
