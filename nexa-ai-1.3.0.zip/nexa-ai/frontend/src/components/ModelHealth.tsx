/**
 * Model health probe UI — when a user selects a model we ask the backend to verify
 * it with one tiny real request (billed to the platform, cached briefly) and show
 * the verdict next to the selection: answering, or exactly why not + switch hint.
 */
import { useCallback, useRef, useState } from "react";

import { api } from "../api/client";
import { useI18n } from "../state/app";

export type ModelHealthState =
  | { status: "checking" }
  | { status: "ok"; latency_ms: number }
  | { status: "fail"; message?: string };

type ProbeResponse = { ok: boolean; message?: string; latency_ms?: number };

export function useModelHealth() {
  const [health, setHealth] = useState<Record<number, ModelHealthState>>({});
  const inFlight = useRef<Set<number>>(new Set());

  const probe = useCallback(async (modelId: number, force = false) => {
    if (!modelId || inFlight.current.has(modelId)) return;
    inFlight.current.add(modelId);
    setHealth((prev) => (force || !prev[modelId] ? { ...prev, [modelId]: { status: "checking" } } : prev));
    try {
      const result = await api.post<ProbeResponse>(`/api/v1/models/${modelId}/check`);
      setHealth((prev) => ({
        ...prev,
        [modelId]: result.ok
          ? { status: "ok", latency_ms: result.latency_ms ?? 0 }
          : { status: "fail", message: result.message || "" },
      }));
    } catch (error) {
      setHealth((prev) => ({
        ...prev,
        [modelId]: { status: "fail", message: error instanceof Error ? error.message : String(error) },
      }));
    } finally {
      inFlight.current.delete(modelId);
    }
  }, []);

  return { health, probe };
}

export function ModelHealthBadge({ state, onRecheck }: { state?: ModelHealthState; onRecheck?: () => void }) {
  const { t } = useI18n();
  if (!state) return null;
  if (state.status === "checking") {
    return <span className="model-health model-health--checking" role="status">⏳ {t("modelHealth.checking")}</span>;
  }
  if (state.status === "ok") {
    return (
      <span className="model-health model-health--ok" role="status">
        🟢 {t("modelHealth.ok")} ({state.latency_ms}ms)
      </span>
    );
  }
  return (
    <span className="model-health model-health--fail" role="alert">
      🔴 {t("modelHealth.fail")} {t("modelHealth.switchHint")}
      {state.message ? <span className="model-health__detail"> {state.message}</span> : null}
      {onRecheck ? (
        <button type="button" className="model-health__recheck" onClick={onRecheck}>
          {t("modelHealth.recheck")}
        </button>
      ) : null}
    </span>
  );
}
