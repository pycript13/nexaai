import React from "react";
import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import { LandingGate } from "./pages/Landing";
import { AppLayout } from "./components/layout";
import { Button, Card } from "./components/ui";
import { SplashLoader } from "./components/splash";
import { Icon } from "./components/icons";
import { useApp } from "./state/app";
import { Login } from "./pages/Login";
import { Register } from "./pages/Register";
import { ForgotPassword } from "./pages/ForgotPassword";
import { ResetPassword } from "./pages/ResetPassword";
import { VerifyEmail } from "./pages/VerifyEmail";
import { Dashboard } from "./pages/Dashboard";
import { Chat } from "./pages/Chat";
import { Coding } from "./pages/Coding";
import { Images } from "./pages/Images";
import { Documents } from "./pages/Documents";
import { DataAnalysis } from "./pages/DataAnalysis";
import { Translation } from "./pages/Translation";
import { Audio } from "./pages/Audio";
import { Video } from "./pages/Video";
import { Models } from "./pages/Models";
import { ModelDetail } from "./pages/ModelDetail";
import { Files } from "./pages/Files";
import { Jobs } from "./pages/Jobs";
import { Billing } from "./pages/Billing";
import { Payments } from "./pages/Payments";
import { Subscriptions } from "./pages/Subscriptions";
import { Usage } from "./pages/Usage";
import { Profile } from "./pages/Profile";
import { Security } from "./pages/Security";
import { Activity } from "./pages/Activity";
import { Forbidden } from "./pages/Forbidden";
import { NotFound } from "./pages/NotFound";
import { AdminDashboard } from "./pages/admin/AdminDashboard";
import { AdminUsers } from "./pages/admin/AdminUsers";
import { AdminRoles } from "./pages/admin/AdminRoles";
import { AdminProviders } from "./pages/admin/AdminProviders";
import { AdminModels } from "./pages/admin/AdminModels";
import { AdminPricing } from "./pages/admin/AdminPricing";
import { AdminPayments } from "./pages/admin/AdminPayments";
import { AdminPlans } from "./pages/admin/AdminPlans";
import { AdminJobs } from "./pages/admin/AdminJobs";
import { AdminSettings } from "./pages/admin/AdminSettings";
import { AdminAudit } from "./pages/admin/AdminAudit";
import { AdminSecurity } from "./pages/admin/AdminSecurity";
import { AdminSystem } from "./pages/admin/AdminSystem";
import { AdminErrors } from "./pages/admin/AdminErrors";
import { AdminBackups } from "./pages/admin/AdminBackups";

interface BoundaryState {
  error: Error | null;
}

/**
 * Never leave the operator in front of a blank page: a render error is caught,
 * shown with the technical detail, and the shell stays usable.
 */
class ErrorBoundary extends React.Component<{ children: React.ReactNode }, BoundaryState> {
  state: BoundaryState = { error: null };

  static getDerivedStateFromError(error: Error): BoundaryState {
    return { error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo): void {
    // eslint-disable-next-line no-console
    console.error("Unhandled UI error", error, info.componentStack);
  }

  render(): React.ReactNode {
    const { error } = this.state;
    if (!error) return this.props.children;
    return (
      <div className="boundary">
        <Card
          icon="alert"
          title="This screen hit an unexpected error"
          subtitle="The rest of the application is unaffected — no data was lost, and nothing was charged."
          danger
        >
          <pre className="boundary__detail" dir="ltr">
            {error.message}
          </pre>
          <div className="row">
            <Button variant="primary" onClick={() => this.setState({ error: null })}>
              <Icon name="refresh" size={16} />
              Try again
            </Button>
            <Button variant="subtle" onClick={() => window.location.assign("/app")}>
              <Icon name="dashboard" size={16} />
              Back to dashboard
            </Button>
          </div>
        </Card>
      </div>
    );
  }
}

function RequireAuth({ children }: { children: React.ReactNode }): JSX.Element {
  const { user, ready } = useApp();
  const location = useLocation();
  if (!ready) return <SplashLoader />;
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  return <>{children}</>;
}

export function RequirePermission({
  permissions,
  mode = "all",
  children,
}: {
  permissions: string[];
  /** "all" (default) requires every permission, "any" requires at least one. */
  mode?: "all" | "any";
  children: React.ReactNode;
}): JSX.Element {
  const { user, ready, hasPermission } = useApp();
  if (!ready) return <SplashLoader />;
  if (!user) return <Navigate to="/login" replace />;
  const allowed = mode === "any" ? permissions.some((permission) => hasPermission(permission)) : hasPermission(permissions);
  if (!allowed) {
    return (
      <Forbidden
        required={permissions}
        message="Your role does not include the permission required for this page."
      />
    );
  }
  return <>{children}</>;
}

export default function App(): JSX.Element {
  return (
    <ErrorBoundary>
      <Routes>
      <Route path="/" element={<LandingGate />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/verify-email" element={<VerifyEmail />} />

      <Route
        path="/app"
        element={
          <RequireAuth>
            <AppLayout />
          </RequireAuth>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="chat" element={<Chat />} />
        <Route path="coding" element={<Coding />} />
        <Route path="images" element={<Images />} />
        <Route path="documents" element={<Documents />} />
        <Route path="data" element={<DataAnalysis />} />
        <Route path="translation" element={<Translation />} />
        <Route path="audio" element={<Audio />} />
        <Route path="video" element={<Video />} />
        <Route path="models" element={<Models />} />
        <Route path="models/:modelId" element={<ModelDetail />} />
        <Route path="files" element={<Files />} />
        <Route path="jobs" element={<Jobs />} />
        <Route path="billing" element={<Billing />} />
        <Route path="payments" element={<Payments />} />
        <Route path="subscriptions" element={<Subscriptions />} />
        <Route path="usage" element={<Usage />} />
        <Route path="profile" element={<Profile />} />
        <Route path="security" element={<Security />} />
        <Route path="activity" element={<Activity />} />

        <Route
          path="admin"
          element={
            <RequirePermission
              mode="any"
              permissions={["users.read", "providers.read", "models.read", "pricing.manage", "payments.read", "reports.read", "audit.read", "backups.manage"]}
            >
              <AdminDashboard />
            </RequirePermission>
          }
        />
        <Route
          path="admin/users"
          element={
            <RequirePermission permissions={["users.read"]}>
              <AdminUsers />
            </RequirePermission>
          }
        />
        <Route
          path="admin/roles"
          element={
            <RequirePermission permissions={["roles.manage"]}>
              <AdminRoles />
            </RequirePermission>
          }
        />
        <Route
          path="admin/providers"
          element={
            <RequirePermission permissions={["providers.manage"]}>
              <AdminProviders />
            </RequirePermission>
          }
        />
        <Route
          path="admin/models"
          element={
            <RequirePermission permissions={["models.manage"]}>
              <AdminModels />
            </RequirePermission>
          }
        />
        <Route
          path="admin/pricing"
          element={
            <RequirePermission permissions={["pricing.manage"]}>
              <AdminPricing />
            </RequirePermission>
          }
        />
        <Route
          path="admin/payments"
          element={
            <RequirePermission permissions={["payments.read"]}>
              <AdminPayments />
            </RequirePermission>
          }
        />
        <Route
          path="admin/plans"
          element={
            <RequirePermission permissions={["subscriptions.manage"]}>
              <AdminPlans />
            </RequirePermission>
          }
        />
        <Route
          path="admin/jobs"
          element={
            <RequirePermission permissions={["jobs.manage"]}>
              <AdminJobs />
            </RequirePermission>
          }
        />
        <Route
          path="admin/settings"
          element={
            <RequirePermission permissions={["settings.manage"]}>
              <AdminSettings />
            </RequirePermission>
          }
        />
        <Route
          path="admin/audit"
          element={
            <RequirePermission permissions={["audit.read"]}>
              <AdminAudit />
            </RequirePermission>
          }
        />
        <Route
          path="admin/security"
          element={
            <RequirePermission permissions={["security.read"]}>
              <AdminSecurity />
            </RequirePermission>
          }
        />
        <Route
          path="admin/system"
          element={
            <RequirePermission permissions={["settings.manage"]}>
              <AdminSystem />
            </RequirePermission>
          }
        />
        <Route
          path="admin/errors"
          element={
            <RequirePermission permissions={["audit.read"]}>
              <AdminErrors />
            </RequirePermission>
          }
        />
        <Route
          path="admin/backups"
          element={
            <RequirePermission permissions={["backups.manage"]}>
              <AdminBackups />
            </RequirePermission>
          }
        />
        <Route path="*" element={<NotFound />} />
      </Route>

      <Route path="/" element={<Navigate to="/app" replace />} />
      <Route path="*" element={<NotFound />} />
      </Routes>
    </ErrorBoundary>
  );
}
