#!/usr/bin/env node
/**
 * Round-16 UI: the router-platform dashboard, the elevated model cards and the standard
 * chat timeline, verified live against the served bundle.
 *
 *   * bundle proof: the served JS/CSS carry the spend chart, price block, provider tile
 *     and day-separator styles;
 *   * chat: a real mock round trip produces a day separator («امروز»/«Today») above the
 *     first bubble of the day;
 *   * dashboard: five KPI cards, a dense 30-point SVG spend chart (one hover column per
 *     day, native <title> tooltips), top-model bars and a recent-activity trace table;
 *   * the new GET /api/v1/dashboard/summary answers with the documented shape and
 *     rejects silly windows with 422;
 *   * models: provider tile, emphasised per-1M price block, context in K, and a working
 *     sort control (cheapest input really orders the page ascending);
 *   * on a 390px phone none of the three pages scrolls sideways, the KPI grid collapses
 *     to one column and the chart fits the viewport.
 *
 * Usage: node check-round16.cjs [baseUrl] <email> <password>
 */
const BASE = (process.argv[2] || "http://127.0.0.1:8081").replace(/\/$/, "");
const EMAIL = process.argv[3] || "";
const PASSWORD = process.argv[4] || "";

const puppeteer = require("puppeteer-core");
const problems = [];
const ok = (m) => console.log(`  ✓ ${m}`);
const fail = (m) => {
  problems.push(m);
  console.log(`  ✗ ${m}`);
};
const check = (c, m) => (c ? ok(m) : fail(m));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const norm = (t) => (t || "").replace(/\u200c/g, "").replace(/\s+/g, " ").trim();

const setValue = async (page, selector, value) => {
  await page.evaluate(
    (sel, val) => {
      const node = document.querySelector(sel);
      const proto = node instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value").set.call(node, val);
      node.dispatchEvent(new Event("input", { bubbles: true }));
      node.dispatchEvent(new Event("change", { bubbles: true }));
    },
    selector,
    value,
  );
};

(async () => {
  // ------------------------------------------------------- bundle-level proof
  const html = await (await fetch(`${BASE}/login`)).text();
  const jsName = (html.match(/assets\/(index-[^"]+\.js)/) || [])[1];
  const cssName = (html.match(/assets\/(index-[^"]+\.css)/) || [])[1];
  const js = jsName ? await (await fetch(`${BASE}/assets/${jsName}`)).text() : "";
  const css = cssName ? await (await fetch(`${BASE}/assets/${cssName}`)).text() : "";
  check(
    js.includes("spend-chart") && js.includes("price-block") && js.includes("day-sep") && js.includes("model-tile"),
    "the served bundle carries the round-16 dashboard, model cards and day separators",
  );
  check(
    css.includes(".spend-chart__line") && css.includes(".price-block__value") && css.includes(".day-sep") && css.includes(".model-tile"),
    "the served CSS carries the round-16 styles",
  );

  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium",
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader"],
  });
  const page = await browser.newPage();
  await page.setCacheEnabled(false);
  const consoleErrors = [];
  page.on("pageerror", (e) => consoleErrors.push(String(e).slice(0, 140)));
  await page.setViewport({ width: 1440, height: 900 });
  await page.goto(`${BASE}/login`, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.waitForSelector('input[type="email"]', { timeout: 45000 });
  await page.type('input[type="email"]', EMAIL);
  await page.type('input[type="password"]', PASSWORD);
  await page.waitForFunction(() => !document.querySelector(".splash-stage"), { timeout: 30000 });
  await page.click('button[type="submit"]');
  await page.waitForFunction(() => location.pathname.startsWith("/app"), { timeout: 45000 });
  ok("signed in");

  // ---------------------------------------------- chat: a real round trip + day separator
  await page.goto(`${BASE}/app/chat`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector(".chat-layout", { timeout: 30000 });
  await page.waitForSelector(".composer__input", { timeout: 15000 });
  // the model list arrives asynchronously — wait for the mock option instead of racing it
  await page
    .waitForFunction(
      () => {
        const select = document.querySelector(".composer select");
        return select && [...select.options].some((o) => /mock/i.test(o.textContent || ""));
      },
      { timeout: 20000 },
    )
    .catch(() => {});
  const picked = await page.evaluate(() => {
    const select = document.querySelector(".composer select");
    if (!select) return null;
    const option = [...select.options].find((o) => /mock/i.test(o.textContent || ""));
    if (!option) return null;
    Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value").set.call(select, option.value);
    select.dispatchEvent(new Event("change", { bubbles: true }));
    return option.textContent;
  });
  check(!!picked, `the composer offers a mock model (${picked ? picked.trim().slice(0, 40) : "none"})`);

  const marker = `r16-${Date.now().toString().slice(-6)}`;
  await setValue(page, ".composer__input", marker);
  await page.click('.composer button.btn--primary, .composer .row button:not([variant])');
  await page.waitForFunction(
    (m) => [...document.querySelectorAll(".bubble--assistant")].some((b) => (b.textContent || "").includes(m)),
    { timeout: 45000 },
    marker,
  );
  ok("the mock model answered (a real billed turn for the dashboard)");
  // the day separator appears once the post-send reload lands and bubbles carry created_at
  await page
    .waitForFunction(() => !!document.querySelector(".day-sep span"), { timeout: 20000 })
    .catch(() => {});
  const sep = await page.evaluate(() => {
    const node = document.querySelector(".day-sep span");
    return node ? node.textContent : "";
  });
  check(
    /امروز|today|آمروز|\d/.test(norm(sep)) && norm(sep).length > 0,
    `a day separator labels the timeline (“${norm(sep) || "missing"}”)`,
  );

  // --------------------------------------------------------- the new dashboard
  await page.goto(`${BASE}/app`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector(".grid--5", { timeout: 30000 });
  await sleep(1500); // let every useApi settle

  const dash = await page.evaluate(() => {
    const stats = [...document.querySelectorAll(".grid--5 .stat")];
    const svg = document.querySelector("svg.spend-chart");
    return {
      statCount: stats.length,
      statValues: stats.map((s) => (s.querySelector(".stat__value")?.textContent || "").trim()),
      statLabels: stats.map((s) => (s.querySelector(".stat__label")?.textContent || "").trim()),
      chart: svg
        ? {
            paths: svg.querySelectorAll("path").length,
            hoverColumns: svg.querySelectorAll("rect.spend-chart__hover").length,
            titles: svg.querySelectorAll("title").length,
            width: svg.getBoundingClientRect().width,
          }
        : null,
      emptyChart: !!document.querySelector(".card .empty, .empty-state"),
      topbars: document.querySelectorAll(".topbar").length,
      topbarFills: [...document.querySelectorAll(".topbar__fill")].map((f) => f.style.width),
      traceRows: document.querySelectorAll(".table--stack tbody tr").length,
    };
  });
  check(dash.statCount === 5, `five KPI cards are rendered (${dash.statCount})`);
  check(
    dash.statValues.every((v) => v.length > 0 && v !== "—"),
    `every KPI shows a real value (${dash.statValues.join(" | ").slice(0, 80)})`,
  );
  if (dash.chart) {
    check(dash.chart.paths >= 2, "the spend chart draws an area + a line");
    check(dash.chart.hoverColumns === 30, `the chart owns one hover column per day (${dash.chart.hoverColumns})`);
    check(dash.chart.titles === 30, `every day carries a native <title> tooltip (${dash.chart.titles})`);
  } else {
    check(dash.emptyChart, "with no usage at all the chart card shows an empty state (not a broken SVG)");
  }
  check(dash.topbars >= 1 || dash.emptyChart, `top-model bars are rendered (${dash.topbars})`);
  check(dash.traceRows >= 1 || dash.emptyChart, `the recent-activity table lists traces (${dash.traceRows})`);

  // ---------------------------------------------------- the summary endpoint itself
  const api = await page.evaluate(async () => {
    const good = await fetch("/api/v1/dashboard/summary?days=30", { credentials: "include" });
    const goodBody = good.ok ? await good.json() : null;
    const bad = await fetch("/api/v1/dashboard/summary?days=3", { credentials: "include" });
    return { status: good.status, badStatus: bad.status, body: goodBody };
  });
  check(api.status === 200, `GET /api/v1/dashboard/summary answers 200 (${api.status})`);
  check(api.badStatus === 422, `a silly window is rejected with 422 (${api.badStatus})`);
  if (api.body) {
    const k = api.body.kpis || {};
    check(
      typeof k.spent_today_micro === "number" && typeof k.spent_window_micro === "number"
        && typeof k.requests_window === "number" && typeof k.tokens_window === "number",
      "the KPI block carries the documented numeric fields",
    );
    check(Array.isArray(api.body.daily) && api.body.daily.length === 30, `the daily series is dense (30 points: ${api.body.daily?.length})`);
    check(Array.isArray(api.body.top_models) && Array.isArray(api.body.recent), "top_models and recent traces are arrays");
    check(api.body.recent.length >= 1, `the round trip above shows up in recent traces (${api.body.recent.length})`);
  }

  // ------------------------------------------------------------- model cards
  await page.goto(`${BASE}/app/models`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector(".model-tile", { timeout: 30000 });
  await sleep(600);
  const modelsView = await page.evaluate(() => {
    const tiles = [...document.querySelectorAll(".model-tile")];
    const prices = [...document.querySelectorAll(".price-block")].map((block) =>
      [...block.querySelectorAll(".price-block__value")].map((v) => (v.textContent || "").trim()),
    );
    const sortSelect = [...document.querySelectorAll("select")].find((s) =>
      [...s.options].some((o) => /ارزان|cheapest/i.test(o.textContent || "")),
    );
    return {
      tileCount: tiles.length,
      tileLetters: tiles.slice(0, 3).map((tile) => tile.textContent.trim()),
      prices,
      hasSort: !!sortSelect,
      sortOptions: sortSelect ? [...sortSelect.options].map((o) => o.textContent.trim()) : [],
    };
  });
  check(modelsView.tileCount >= 1, `every model card carries a provider tile (${modelsView.tileCount})`);
  check(modelsView.tileLetters.every((l) => /^[A-Z\u0621-\u064A\u06A1-\u06FF]$/.test(l) || l === "?"), `tiles show the provider initial (${modelsView.tileLetters.join(",")})`);
  check(
    modelsView.prices.length >= 1 && modelsView.prices[0].length >= 2 && modelsView.prices[0].every((v) => v.length > 0),
    "the price block emphasises input/output/context values",
  );
  check(modelsView.hasSort, "a sort control is offered");

  if (modelsView.hasSort && modelsView.prices.length >= 2) {
    const sorted = await page.evaluate(() => {
      const select = [...document.querySelectorAll("select")].find((s) =>
        [...s.options].some((o) => /ارزان|cheapest/i.test(o.textContent || "")),
      );
      const option = [...select.options].find((o) => /ارزان|cheapest/i.test(o.textContent || ""));
      Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value").set.call(select, option.value);
      select.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    });
    check(sorted, "selecting «cheapest input» does not crash the page");
    await sleep(500);
    const inputs = await page.evaluate(() =>
      [...document.querySelectorAll(".price-block")].map((block) =>
        parseFloat((block.querySelector(".price-block__value")?.textContent || "0").replace(/[^\d.]/g, "")) || 0,
      ),
    );
    const ascending = inputs.every((v, i) => i === 0 || inputs[i - 1] <= v);
    check(ascending, `cheapest-first really orders the page (${inputs.join(" ≤ ")})`);
  }

  // --------------------------------------------------------------- phone pass
  await page.setViewport({ width: 390, height: 844 });
  await sleep(400);

  const phonePage = async (path, probe) => {
    await page.goto(`${BASE}${path}`, { waitUntil: "domcontentloaded" });
    await sleep(1600);
    const result = await page.evaluate(probe);
    return result;
  };

  const phoneDash = await phonePage("/app", () => {
    const grid = document.querySelector(".grid--5");
    const columns = grid ? getComputedStyle(grid).gridTemplateColumns.split(" ").length : 0;
    const svg = document.querySelector("svg.spend-chart");
    return {
      overflow: document.documentElement.scrollWidth - window.innerWidth,
      columns,
      chartWidth: svg ? Math.round(svg.getBoundingClientRect().width) : 0,
      tableOverflow: (() => {
        const wrap = document.querySelector(".table-wrap");
        return wrap ? wrap.scrollWidth - wrap.clientWidth : 0;
      })(),
    };
  });
  check(phoneDash.overflow <= 1, `the phone dashboard never scrolls sideways (${phoneDash.overflow}px)`);
  check(phoneDash.columns === 1, `the KPI grid collapses to one column (${phoneDash.columns})`);
  check(phoneDash.chartWidth === 0 || phoneDash.chartWidth <= 390, `the chart fits the phone viewport (${phoneDash.chartWidth}px)`);
  check(phoneDash.tableOverflow <= 1, `the traces table scrolls inside its own wrapper (${phoneDash.tableOverflow}px)`);

  const phoneModels = await phonePage("/app/models", () => ({
    overflow: document.documentElement.scrollWidth - window.innerWidth,
    tiles: document.querySelectorAll(".model-tile").length,
    priceBlocks: document.querySelectorAll(".price-block").length,
  }));
  check(phoneModels.overflow <= 1, `the phone catalog never scrolls sideways (${phoneModels.overflow}px)`);
  check(phoneModels.tiles >= 1 && phoneModels.priceBlocks >= 1, "tiles and price blocks survive the phone layout");

  const phoneChat = await phonePage("/app/chat", () => ({
    overflow: document.documentElement.scrollWidth - window.innerWidth,
    composerInside: (() => {
      const c = document.querySelector(".composer");
      if (!c) return false;
      const r = c.getBoundingClientRect();
      return r.right <= window.innerWidth + 1 && r.left >= -1;
    })(),
  }));
  check(phoneChat.overflow <= 1, `the phone chat never scrolls sideways (${phoneChat.overflow}px)`);
  check(phoneChat.composerInside, "the composer stays inside the phone viewport");

  check(consoleErrors.length === 0, `no page errors during the whole flow (${consoleErrors.length})`);
  consoleErrors.slice(0, 3).forEach((e) => console.log(`    ! ${e}`));

  await browser.close();
  console.log(`\nPROBLEMS: ${problems.length}`);
  problems.forEach((p) => console.log(`  - ${p}`));
  process.exit(problems.length ? 1 : 0);
})().catch((error) => {
  console.error("CHECKER CRASHED:", error.message);
  process.exit(2);
});
