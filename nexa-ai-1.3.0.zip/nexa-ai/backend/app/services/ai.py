"""AI orchestration: model resolution, provider invocation, metering, admin tests.

Ordering guarantees
* Access control and quota checks run **before** any provider traffic.
* Streaming responses charge only for the tokens the provider actually reported;
  if the provider reports no usage we store ``usage_source='estimated'`` and mark
  the pricing as uncertain — never a fabricated exact number.
* Admin tests never touch a user balance, are always audited and are capped by
  configurable per-request/per-day spending limits.
"""
from __future__ import annotations

import asyncio
import datetime as dt
import json
import time
import uuid
from collections.abc import AsyncIterator
from dataclasses import asdict, dataclass, field
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.errors import (
    CATEGORY_LABELS,
    ConfigurationError,
    NotFound,
    ProviderError,
    RateLimited,
    ValidationError,
    hints_for,
)
from app.core.logging import get_logger
from app.models.admin import AdminModelTest
from app.models.billing import UsageStatus
from app.models.provider import Model, Provider, ProviderHealthSample
from app.models.user import User
from app.providers.base import (
    ChatMessage,
    ChatRequest,
    ChatResponse,
    ProviderAdapter,
)
from app.providers.capabilities import Operation
from app.providers.http import estimate_tokens
from app.providers.registry import adapter_for_provider
from app.services import access as access_service
from app.services import pricing as pricing_service
from app.services import usage as usage_service

log = get_logger(__name__)


@dataclass
class ModelRef:
    model: Model
    provider: Provider
    adapter: ProviderAdapter
    decision: access_service.AccessDecision


def resolve_model(
    db: Session,
    *,
    user: User | None,
    model_id: int | None = None,
    provider_slug: str | None = None,
    provider_model_id: str | None = None,
    operation: str = Operation.CHAT.value,
    is_admin_test: bool = False,
    admin_user: User | None = None,
    require_enabled_provider: bool = True,
) -> ModelRef:
    stmt = select(Model).join(Provider, Provider.id == Model.provider_id)
    if model_id is not None:
        stmt = stmt.where(Model.id == model_id)
    elif provider_slug and provider_model_id:
        stmt = stmt.where(Provider.slug == provider_slug, Model.provider_model_id == provider_model_id)
    else:
        raise ValidationError("Specify either model_id or provider_slug + provider_model_id.")
    model = db.scalars(stmt).first()
    if model is None:
        raise NotFound(
            "The requested model is not registered in the catalog.",
            details={"model_id": model_id, "provider_slug": provider_slug, "provider_model_id": provider_model_id},
        )
    provider = model.provider
    if provider is None:  # pragma: no cover - FK protected
        raise NotFound("Model provider is missing.")

    from app.models.provider import ModelAvailability

    if model.availability == ModelAvailability.DISABLED and not is_admin_test:
        raise ConfigurationError(
            f"Model '{model.display_name}' is marked unavailable by an administrator (availability: disabled). "
            "Enable it under Admin → Models → Lifecycle before it can serve requests.",
            details={"model_id": model.id, "availability": model.availability, "reason": "model_disabled"},
        )
    if model.availability == ModelAvailability.UNTESTED and not is_admin_test and not access_service.is_platform_owner(user):
        raise ConfigurationError(
            f"Model '{model.display_name}' has not been verified yet (availability: untested). "
            "Run an administrative test under Admin → Models (it is audited and billed to the platform) — "
            "that marks the model verified — and publish it so users can spend credits on it.",
            details={"model_id": model.id, "availability": model.availability, "reason": "model_not_verified"},
        )

    decision = access_service.evaluate_model_access(
        db, user, model, operation=operation, is_admin_test=is_admin_test, admin_user=admin_user
    )
    if not decision.allowed:
        from app.core.errors import InsufficientBalance, ModelNotUsable

        if decision.code == "insufficient_balance":
            raise InsufficientBalance(
                decision.reason or "Insufficient credit balance for this request.",
                details={"code": decision.code, **decision.details},
            )
        raise ModelNotUsable(
            decision.reason or "This model is not available to your account.",
            details={"code": decision.code, **decision.details},
        )
    adapter = adapter_for_provider(provider, require_key=require_enabled_provider)
    if not adapter.supports(operation):
        from app.providers.base import UnsupportedOperation

        raise UnsupportedOperation(operation, provider=provider.name, model=model.display_name)
    return ModelRef(model=model, provider=provider, adapter=adapter, decision=decision)


def record_health(db: Session, provider: Provider, *, operation: str, success: bool, latency_ms: int | None,
                  error_category: str | None = None, status_code: int | None = None) -> None:
    db.add(
        ProviderHealthSample(
            provider_id=provider.id,
            operation=operation,
            success=success,
            latency_ms=latency_ms,
            error_category=error_category,
            status_code=status_code,
        )
    )
    provider.last_test_at = dt.datetime.now(dt.timezone.utc)
    provider.last_test_status = "ok" if success else "error"
    if not success:
        provider.last_error_category = error_category
        provider.last_error_at = dt.datetime.now(dt.timezone.utc)


# --------------------------------------------------------------- chat (sync) --
async def run_chat(
    db: Session,
    *,
    user: User,
    model_ref: ModelRef,
    messages: list[ChatMessage],
    system: str | None = None,
    temperature: float | None = None,
    max_tokens: int | None = None,
    top_p: float | None = None,
    json_mode: bool = False,
    tools: list[dict] | None = None,
    module: str = "chat",
    conversation_id: int | None = None,
    variant_id: int | None = None,
    idempotency_key: str | None = None,
    job_id: int | None = None,
    timeout: float | None = None,
) -> tuple[ChatResponse, usage_service.UsageOutcome]:
    model, provider, adapter = model_ref.model, model_ref.provider, model_ref.adapter
    # A job-scoped idempotency key makes every usage row of a background job unique
    # per job and operation, so retries that already charged cannot charge twice.
    key = idempotency_key or (f"job:{job_id}:chat" if job_id else f"chat:{uuid.uuid4().hex}")
    estimated = access_service.estimate_max_charge_micro(
        db, model, user, prompt_tokens_estimate=sum(estimate_tokens(m.text()) for m in messages),
        max_output_tokens=max_tokens or model.max_output_tokens or 1024,
    )
    access_service.enforce_quotas(db, user, model, estimated_charge_micro=estimated)
    access_service.ensure_balance_for_request(db, user, model, estimated_charge_micro=estimated)

    request = ChatRequest(
        model=model.provider_model_id,
        messages=messages,
        system=system,
        temperature=temperature,
        top_p=top_p,
        max_tokens=max_tokens,
        json_mode=json_mode,
        tools=tools,
        timeout=timeout,
    )
    started = time.perf_counter()
    try:
        response = await adapter.chat(request)  # type: ignore[misc]
    except ProviderError as error:
        record_health(db, provider, operation="chat", success=False, latency_ms=int((time.perf_counter() - started) * 1000),
                      error_category=error.category, status_code=error.upstream_status)
        usage_service.record_usage(
            db, user=user, model=model, provider=provider, operation="chat", module=module,
            status=UsageStatus.FAILED, idempotency_key=key, error_category=error.category,
            latency_ms=int((time.perf_counter() - started) * 1000), conversation_id=conversation_id, variant_id=variant_id,
            job_id=job_id, charge=True, metadata={"error_message": error.detail[:300]},
        )
        db.commit()
        raise
    latency_ms = int((time.perf_counter() - started) * 1000)
    record_health(db, provider, operation="chat", success=True, latency_ms=latency_ms)

    prompt_tokens = response.prompt_tokens
    completion_tokens = response.completion_tokens
    usage_source = response.usage_source
    if prompt_tokens is None:
        prompt_tokens = sum(estimate_tokens(m.text()) for m in messages)
        usage_source = "estimated"
    if completion_tokens is None:
        completion_tokens = estimate_tokens(response.text)
        usage_source = "estimated" if usage_source != "provider_reported" else "provider_reported"

    outcome = usage_service.record_usage(
        db, user=user, model=model, provider=provider, operation="chat", module=module,
        status=UsageStatus.SUCCEEDED, idempotency_key=key, prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens, usage_source=usage_source, latency_ms=latency_ms,
        provider_request_id=response.provider_request_id, conversation_id=conversation_id, variant_id=variant_id, job_id=job_id,
    )
    db.commit()
    return response, outcome


# ------------------------------------------------------------ chat (stream) --
@dataclass
class StreamEvent:
    type: str                     # "delta" | "usage" | "error" | "done"
    data: dict[str, Any] = field(default_factory=dict)


PROBE_CACHE_SECONDS = 120


async def probe_model(db: Session, *, user: User | None, model: Model, timeout: float = 25.0) -> dict[str, Any]:
    """One tiny, real request that answers a single question: can this model reply *now*?

    Runs when a user selects a model (web or Telegram) so a busy / rate-limited /
    misconfigured model is announced *before* the user writes a prompt into the void.
    The probe is billed to the platform, never to the user, and its verdict is cached
    for two minutes so repeated selections do not hammer the provider.
    """
    from app.services import settings_store

    cache_key = f"model_probe:{model.id}"
    cached = settings_store.get_value(db, cache_key, None)
    if isinstance(cached, dict) and cached.get("at"):
        age = time.time() - float(cached["at"])
        if age < PROBE_CACHE_SECONDS:
            return {**cached, "cached": True, "model_id": model.id}

    provider = model.provider
    try:
        adapter = adapter_for_provider(provider, require_key=True)
    except Exception as exc:  # noqa: BLE001 - a configuration problem is a probe verdict too
        detail = getattr(exc, "detail", str(exc))
        record_health(db, provider, operation="model_probe", success=False, latency_ms=0,
                      error_category="configuration_error")
        db.commit()
        verdict = {"ok": False, "category": "configuration_error",
                   "category_label": CATEGORY_LABELS.get("configuration_error", "configuration_error"),
                   "message": detail, "latency_ms": 0, "hints": hints_for("configuration_error"),
                   "at": time.time()}
        settings_store.set_value(db, cache_key, verdict)
        return {**verdict, "model_id": model.id, "cached": False}

    request = ChatRequest(
        model=model.provider_model_id,
        messages=[ChatMessage(role="user", content="Reply with the single word: ok")],
        max_tokens=8, stream=False, timeout=timeout,
    )
    started = time.perf_counter()
    try:
        response = await adapter.chat(request)  # type: ignore[misc]
    except ProviderError as error:
        latency_ms = int((time.perf_counter() - started) * 1000)
        record_health(db, provider, operation="model_probe", success=False, latency_ms=latency_ms,
                      error_category=error.category, status_code=error.upstream_status)
        usage_service.record_usage(
            db, user=user, model=model, provider=provider, operation="model_probe", module="system",
            status=UsageStatus.FAILED, idempotency_key=f"probe:{model.id}:{int(time.time())}",
            error_category=error.category, latency_ms=latency_ms, bill_to_platform=True,
        )
        db.commit()
        verdict = {"ok": False, "category": error.category,
                   "category_label": CATEGORY_LABELS.get(error.category, error.category),
                   "message": error.detail, "latency_ms": latency_ms,
                   "hints": hints_for(error.category), "at": time.time()}
        settings_store.set_value(db, cache_key, verdict)
        return {**verdict, "model_id": model.id, "cached": False}
    latency_ms = int((time.perf_counter() - started) * 1000)
    record_health(db, provider, operation="model_probe", success=True, latency_ms=latency_ms)
    usage_service.record_usage(
        db, user=user, model=model, provider=provider, operation="model_probe", module="system",
        status=UsageStatus.SUCCEEDED,
        idempotency_key=f"probe:{model.id}:{int(time.time())}",
        prompt_tokens=response.prompt_tokens, completion_tokens=response.completion_tokens,
        usage_source=response.usage_source or "provider_reported", latency_ms=latency_ms,
        provider_request_id=response.provider_request_id, bill_to_platform=True,
    )
    db.commit()
    verdict = {"ok": True, "category": None, "category_label": None,
               "message": (response.text or "").strip()[:80], "latency_ms": latency_ms,
               "hints": [], "at": time.time()}
    settings_store.set_value(db, cache_key, verdict)
    return {**verdict, "model_id": model.id, "cached": False}


async def stream_chat(
    db: Session,
    *,
    user: User,
    model_ref: ModelRef,
    messages: list[ChatMessage],
    system: str | None = None,
    temperature: float | None = None,
    max_tokens: int | None = None,
    top_p: float | None = None,
    module: str = "chat",
    conversation_id: int | None = None,
    variant_id: int | None = None,
    idempotency_key: str | None = None,
    timeout: float | None = None,
) -> AsyncIterator[StreamEvent]:
    model, provider, adapter = model_ref.model, model_ref.provider, model_ref.adapter
    key = idempotency_key or f"stream:{uuid.uuid4().hex}"
    estimated = access_service.estimate_max_charge_micro(
        db, model, user, prompt_tokens_estimate=sum(estimate_tokens(m.text()) for m in messages),
        max_output_tokens=max_tokens or model.max_output_tokens or 1024,
    )
    access_service.enforce_quotas(db, user, model, estimated_charge_micro=estimated)
    access_service.ensure_balance_for_request(db, user, model, estimated_charge_micro=estimated)

    request = ChatRequest(
        model=model.provider_model_id, messages=messages, system=system, temperature=temperature,
        top_p=top_p, max_tokens=max_tokens, stream=True, timeout=timeout,
    )
    text_parts: list[str] = []
    reported: dict[str, int] | None = None
    provider_request_id: str | None = None
    finish_reason: str | None = None
    started = time.perf_counter()
    failure: ProviderError | None = None
    cancelled = False
    error_payload: dict[str, Any] | None = None
    done_payload: dict[str, Any] | None = None
    provider_stream = adapter.stream_chat(request)
    try:
        async for chunk in provider_stream:  # type: ignore[misc]
            if chunk.provider_request_id:
                provider_request_id = chunk.provider_request_id
            if chunk.finish_reason:
                finish_reason = chunk.finish_reason
            if chunk.delta:
                text_parts.append(chunk.delta)
                yield StreamEvent("delta", {"text": chunk.delta})
            if chunk.reasoning_delta:
                yield StreamEvent("reasoning", {"text": chunk.reasoning_delta})
            if chunk.usage:
                reported = {
                    "prompt_tokens": int(chunk.usage.get("prompt_tokens") or 0),
                    "completion_tokens": int(chunk.usage.get("completion_tokens") or 0),
                }
    except ProviderError as error:
        failure = error
        record_health(db, provider, operation="chat_stream", success=False,
                      latency_ms=int((time.perf_counter() - started) * 1000), error_category=error.category,
                      status_code=error.upstream_status)
    except (asyncio.CancelledError, GeneratorExit):
        # The consumer pressed Stop (or the client went away). The bookkeeping below runs,
        # then the cancellation propagates upward untouched: swallowing it would hang the
        # server task, and yielding during cleanup would raise
        # RuntimeError("async generator ignored GeneratorExit").
        cancelled = True
        raise
    finally:
        latency_ms = int((time.perf_counter() - started) * 1000)
        full_text = "".join(text_parts)
        try:
            await provider_stream.aclose()  # release the provider connection deterministically
        except BaseException:  # noqa: BLE001 - best-effort cleanup; the original cancellation still propagates
            pass
        if cancelled:
            # A stopped stream is charged for what was actually produced — the user chose to
            # stop, but the provider already generated those tokens — and it is permanently
            # marked as cancelled, never as a clean success. Provider health is deliberately
            # not recorded: a user stopping says nothing about the provider's reliability.
            usage_service.record_usage(
                db, user=user, model=model, provider=provider, operation="chat_stream", module=module,
                status=UsageStatus.CANCELLED if full_text else UsageStatus.FAILED, idempotency_key=key,
                error_category="user_stopped", latency_ms=latency_ms, provider_request_id=provider_request_id,
                conversation_id=conversation_id, variant_id=variant_id,
                charge=bool(full_text), charge_on_failure=True,
                prompt_tokens=reported["prompt_tokens"] if reported else sum(estimate_tokens(m.text()) for m in messages),
                completion_tokens=reported["completion_tokens"] if reported else (estimate_tokens(full_text) if full_text else None),
                usage_source="provider_reported" if reported else ("estimated" if full_text else "unavailable"),
            )
            db.commit()
        elif failure is not None:
            usage_service.record_usage(
                db, user=user, model=model, provider=provider, operation="chat_stream", module=module,
                status=UsageStatus.PARTIAL if full_text else UsageStatus.FAILED, idempotency_key=key,
                error_category=failure.category, latency_ms=latency_ms, provider_request_id=provider_request_id,
                conversation_id=conversation_id, variant_id=variant_id, charge=bool(full_text),
                prompt_tokens=reported["prompt_tokens"] if reported else None,
                completion_tokens=reported["completion_tokens"] if reported else (estimate_tokens(full_text) if full_text else None),
                usage_source="provider_reported" if reported else ("estimated" if full_text else "unavailable"),
            )
            db.commit()
            error_payload = {
                "category": failure.category,
                "category_label": CATEGORY_LABELS.get(failure.category, failure.category),
                "message": failure.detail,
                "retryable": failure.retryable,
                "partial_text": full_text,
                "hints": hints_for(failure.category),
            }
        else:
            prompt_tokens = reported["prompt_tokens"] if reported else sum(estimate_tokens(m.text()) for m in messages)
            completion_tokens = reported["completion_tokens"] if reported else estimate_tokens(full_text)
            usage_source = "provider_reported" if reported else "estimated"
            record_health(db, provider, operation="chat_stream", success=True, latency_ms=latency_ms)
            outcome = usage_service.record_usage(
                db, user=user, model=model, provider=provider, operation="chat_stream", module=module,
                status=UsageStatus.SUCCEEDED, idempotency_key=key, prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens, usage_source=usage_source, latency_ms=latency_ms,
                provider_request_id=provider_request_id, conversation_id=conversation_id, variant_id=variant_id,
            )
            db.commit()
            done_payload = {
                "text": full_text,
                "finish_reason": finish_reason,
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "usage_source": usage_source,
                "charged_micro": outcome.usage.charged_micro,
                "provider_cost_uncertain": outcome.usage.pricing_uncertain,
                "balance_after_micro": outcome.charge.balance_after_micro if outcome.charge else None,
                "latency_ms": latency_ms,
                "provider_request_id": provider_request_id,
                "notes": outcome.notes,
            }
    # The terminal events are yielded *outside* the finally block: a generator that yields
    # during its own cleanup swallows CancelledError and turns aclose() into a RuntimeError.
    if error_payload is not None:
        yield StreamEvent("error", error_payload)
    elif done_payload is not None:
        yield StreamEvent("done", done_payload)



# --------------------------------------------------------- admin model test --
async def admin_test_model(
    db: Session,
    *,
    admin: User,
    model: Model,
    operation: str,
    payload: dict[str, Any],
) -> dict[str, Any]:
    """Run an administrative model test (spec §9).

    * Hidden / restricted / internal models can be tested without publishing them.
    * A disabled model or a disabled provider is refused (no silent enable).
    * Cost is recorded on the test + usage row with ``is_admin_test=True`` and is
      never billed to a user balance.
    """
    if not access_service.has_permission(admin, "models.test"):
        from app.core.errors import PermissionDenied

        raise PermissionDenied("You do not have permission to run model tests (models.test).")

    provider = model.provider
    if provider is None:
        raise NotFound("Model has no provider.")
    if not provider.enabled:
        raise ValidationError(
            f"Provider '{provider.name}' is disabled. Enable it first — administrative tests never silently enable a provider."
        )
    if not model.enabled:
        raise ValidationError(
            f"Model '{model.display_name}' is disabled. Enable it first — administrative tests never silently enable a model."
        )
    # The administrative test is the platform's *verification* tool, so it may probe an operation
    # the model has not declared yet — a freshly synced model declares nothing at all (capabilities
    # are never guessed), and an admin who wants to know whether a model can stream must be able to
    # ask. Until this was relaxed the answer was "declare the capability first, then verify it",
    # which is impossible in the other order and dead-ended the whole provider flow.
    #
    # What is *not* relaxed: the user-facing path still enforces the capability list
    # (`services/access.py`), nothing here writes capabilities or publishes the model, the provider
    # must still be enabled and authenticate, and the test is audited and costed separately.
    declared_capabilities = list(model.capabilities or [])
    capability_warning: str | None = None
    if operation not in declared_capabilities:
        capability_warning = (
            f"The model declares {declared_capabilities or 'no capabilities'}, so this "
            f"'{operation}' probe is a verification run: nothing is declared or published by it. "
            "Declare the capability under Admin → Models → Edit once the test confirms it."
        )

    # spending controls
    day_spent = usage_service.admin_test_spend_today_micro(db, admin.id)
    if settings.admin_test_daily_limit_micro and day_spent >= settings.admin_test_daily_limit_micro:
        raise RateLimited(
            "Daily administrative test budget exhausted.",
            retry_after=3600,
            details={"scope": "admin_test_daily", "spent_micro": day_spent, "limit_micro": settings.admin_test_daily_limit_micro},
        )

    test = AdminModelTest(
        admin_user_id=admin.id,
        provider_id=provider.id,
        model_id=model.id,
        provider_model_id=model.provider_model_id,
        operation=operation,
        used_model_visibility=model.visibility,
        bypassed_user_restrictions=True,
        request_summary=_summarize_payload(operation, payload),
        request_params=_safe_params(payload),
        # stored with the test so the history explains why an undeclared operation was run
        diagnostics=([capability_warning] if capability_warning else None),
    )
    db.add(test)
    db.flush()

    adapter = adapter_for_provider(provider, require_key=True)
    if not adapter.supports(operation):
        test.success = False
        test.error_category = "unsupported_operation"
        test.error_message = f"Provider adapter '{provider.provider_type}' does not implement '{operation}'."
        test.diagnostics = hints_for("unsupported_operation")
        db.commit()
        return _admin_test_result(test, model, provider, None)

    started = time.perf_counter()
    response_text: str | None = None
    meta: dict[str, Any] = {}
    error: ProviderError | None = None
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    usage_source = "unavailable"
    request_id: str | None = None

    try:
        if operation in (Operation.CHAT.value, Operation.STREAMING.value):
            messages = _messages_from_payload(payload)
            request = ChatRequest(
                model=model.provider_model_id,
                messages=messages,
                system=payload.get("system"),
                temperature=_opt_float(payload.get("temperature")),
                max_tokens=_opt_int(payload.get("max_tokens")) or 256,
                top_p=_opt_float(payload.get("top_p")),
                json_mode=bool(payload.get("json_mode")),
            )
            if operation == Operation.STREAMING.value:
                collected: list[str] = []
                reported: dict[str, int] | None = None
                async for chunk in adapter.stream_chat(request):  # type: ignore[misc]
                    if chunk.delta:
                        collected.append(chunk.delta)
                    if chunk.usage:
                        reported = chunk.usage
                    request_id = chunk.provider_request_id or request_id
                response_text = "".join(collected)
                if reported:
                    prompt_tokens = int(reported.get("prompt_tokens") or 0)
                    completion_tokens = int(reported.get("completion_tokens") or 0)
                    usage_source = "provider_reported"
                else:
                    prompt_tokens = estimate_tokens(" ".join(m.text() for m in messages))
                    completion_tokens = estimate_tokens(response_text)
                    usage_source = "estimated"
                meta["streamed"] = True
            else:
                result = await adapter.chat(request)  # type: ignore[misc]
                response_text = result.text
                prompt_tokens = result.prompt_tokens
                completion_tokens = result.completion_tokens
                usage_source = result.usage_source
                request_id = result.provider_request_id
                meta.update(
                    {
                        "finish_reason": result.finish_reason,
                        "model": result.model,
                        "tool_calls": bool(result.tool_calls),
                    }
                )
                if prompt_tokens is None:
                    prompt_tokens = estimate_tokens(" ".join(m.text() for m in messages))
                    completion_tokens = estimate_tokens(result.text)
                    usage_source = "estimated"
        elif operation == Operation.IMAGE_GENERATION.value:
            from app.providers.base import ImageGenerationRequest

            result_i = await adapter.generate_image(  # type: ignore[misc]
                ImageGenerationRequest(
                    model=model.provider_model_id,
                    prompt=str(payload.get("prompt") or payload.get("input") or ""),
                    n=int(payload.get("n") or 1),
                    size=payload.get("size"),
                    quality=payload.get("quality"),
                    response_format="b64_json",
                )
            )
            request_id = result_i.provider_request_id
            response_text = f"Generated {len(result_i.images)} image(s)."
            meta.update({"images": len(result_i.images), "latency_ms": result_i.latency_ms, "usage_source": result_i.usage_source})
            usage_source = result_i.usage_source
        elif operation == Operation.EMBEDDINGS.value:
            from app.providers.base import EmbeddingRequest

            result_e = await adapter.embed(  # type: ignore[misc]
                EmbeddingRequest(model=model.provider_model_id, inputs=[str(payload.get("input") or "nexa test")])
            )
            response_text = f"Embedding vector length: {len(result_e.vectors[0]) if result_e.vectors else 0}"
            prompt_tokens = result_e.total_tokens
            usage_source = result_e.usage_source
            request_id = result_e.provider_request_id
        elif operation == Operation.AUDIO_TRANSCRIPTION.value:
            from app.providers.base import TranscriptionRequest

            file_id = payload.get("file_id")
            if not file_id:
                raise ValidationError("Provide a file_id (upload an audio file first) for transcription tests.")
            from app.models.files import StoredFile
            from app.services.files import absolute_path_for

            stored = db.get(StoredFile, int(file_id))
            if stored is None:
                raise NotFound("The specified file was not found.")
            result_t = await adapter.transcribe(  # type: ignore[misc]
                TranscriptionRequest(model=model.provider_model_id, file_path=str(absolute_path_for(stored)))
            )
            response_text = result_t.text
            usage_source = result_t.usage_source
            request_id = result_t.provider_request_id
            meta["duration_seconds"] = result_t.duration_seconds
        elif operation == Operation.SPEECH_GENERATION.value:
            from app.providers.base import SpeechRequest

            result_s = await adapter.synthesize(  # type: ignore[misc]
                SpeechRequest(
                    model=model.provider_model_id,
                    text=str(payload.get("input") or "Nexa AI speech test."),
                    voice=payload.get("voice"),
                )
            )
            response_text = f"Synthesized {len(result_s.audio_bytes)} bytes of audio ({result_s.mime_type})."
            usage_source = result_s.usage_source
            meta["audio_bytes"] = len(result_s.audio_bytes)
        else:
            raise ValidationError(f"Administrative testing is not implemented for operation '{operation}'.")
    except ProviderError as exc:
        error = exc
    except ValidationError:
        raise
    except Exception as exc:  # noqa: BLE001 - surfaced as an internal test failure
        error = ProviderError(f"Test failed: {type(exc).__name__}: {exc}", category="internal_error", provider=provider.name)

    latency_ms = int((time.perf_counter() - started) * 1000)
    cost_micro: int | None = None
    cost_uncertain = True
    if error is None:
        quote = pricing_service.resolve_price(db, model, user=None, operation=operation)
        breakdown = pricing_service.compute_charge(
            quote,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            requests=1,
            images=int(meta.get("images") or 0),
            audio_seconds=meta.get("duration_seconds"),
            access_tier=model.access_tier,
        )
        cost_micro = breakdown.provider_cost_micro
        cost_uncertain = breakdown.provider_cost_micro is None or quote.provider_cost_uncertain
        if cost_micro is None:
            cost_micro = 0
        if settings.admin_test_max_cost_per_request_micro and cost_micro > settings.admin_test_max_cost_per_request_micro:
            test.diagnostics = (test.diagnostics or []) + [
                f"Per-request admin test budget of {settings.admin_test_max_cost_per_request_micro} micro-credits was exceeded; "
                "the request completed but review your provider pricing configuration."
            ]
        test.success = True
        test.response_text = (response_text or "")[:20000]
        test.response_meta = meta
        test.prompt_tokens = prompt_tokens
        test.completion_tokens = completion_tokens
        test.usage_source = usage_source
    else:
        test.success = False
        test.error_category = error.category
        test.error_message = error.detail[:2000]
        test.diagnostics = hints_for(error.category)
        test.response_text = (response_text or "")[:20000] if response_text else None
    test.latency_ms = latency_ms
    test.provider_request_id = request_id
    test.provider_cost_micro = cost_micro
    test.cost_uncertain = cost_uncertain

    # record usage separately from user billing
    usage_service.record_usage(
        db,
        user=admin,
        model=model,
        provider=provider,
        operation=operation,
        status=UsageStatus.SUCCEEDED if error is None else UsageStatus.FAILED,
        module="admin_test",
        idempotency_key=f"admintest:{test.id}",
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        usage_source=usage_source,
        images=int(meta.get("images") or 0),
        latency_ms=latency_ms,
        provider_request_id=request_id,
        error_category=error.category if error else None,
        is_admin_test=True,
        admin_test_id=test.id,
        charge=False,
        metadata={"provider_cost_micro": cost_micro, "cost_uncertain": cost_uncertain},
    )
    model.last_tested_at = dt.datetime.now(dt.timezone.utc)
    model.last_test_status = "ok" if error is None else "error"
    model.last_test_latency_ms = latency_ms
    model.last_test_error_category = error.category if error else None
    model.last_test_message = (error.detail[:400] if error else f"Test succeeded ({operation}).")
    if error is None and model.availability in ("untested", "disabled", "offline"):
        model.availability = "available"
    elif error is not None and error.category in ("authentication", "connectivity", "upstream_server_error", "timeout"):
        model.availability = "degraded"
    record_health(db, provider, operation=f"admin_test:{operation}", success=error is None, latency_ms=latency_ms,
                  error_category=error.category if error else None)
    db.commit()
    return _admin_test_result(test, model, provider, error)


def _admin_test_result(test: AdminModelTest, model: Model, provider: Provider, error: ProviderError | None) -> dict[str, Any]:
    return {
        "test_id": test.id,
        "success": bool(test.success),
        "operation": test.operation,
        "model": {"id": model.id, "display_name": model.display_name, "provider_model_id": model.provider_model_id,
                  "visibility": model.visibility, "access_tier": model.access_tier, "enabled": model.enabled},
        "provider": {"id": provider.id, "name": provider.name, "enabled": provider.enabled, "type": provider.provider_type},
        "response_text": test.response_text,
        "response_meta": test.response_meta or {},
        "latency_ms": test.latency_ms,
        "provider_request_id": test.provider_request_id,
        "prompt_tokens": test.prompt_tokens,
        "completion_tokens": test.completion_tokens,
        "usage_source": test.usage_source,
        "provider_cost_micro": test.provider_cost_micro,
        "provider_cost_display": pricing_service.micro_to_display(test.provider_cost_micro) if test.provider_cost_micro is not None else None,
        "cost_uncertain": test.cost_uncertain,
        "error_category": test.error_category,
        "error_category_label": CATEGORY_LABELS.get(test.error_category or "", None),
        "error_message": test.error_message,
        "diagnostics": test.diagnostics or [],
        "billed_to_user": False,
        "declared_capabilities": list(model.capabilities or []),
        "capability_verified": test.operation in (model.capabilities or []),
        "capability_warning": next(
            (line for line in (test.diagnostics or []) if line.startswith("The model declares")), None
        ),
        "suggested_capabilities": (
            [test.operation] if test.success and test.operation not in (model.capabilities or []) else []
        ),
        "note": "Administrative test: cost recorded on the platform, never charged to a user balance.",
        "created_at": test.created_at.isoformat() if test.created_at else None,
    }


def _messages_from_payload(payload: dict[str, Any]) -> list[ChatMessage]:
    raw_messages = payload.get("messages")
    if isinstance(raw_messages, list) and raw_messages:
        out: list[ChatMessage] = []
        for item in raw_messages:
            if not isinstance(item, dict):
                continue
            content = item.get("content")
            if isinstance(content, list):
                out.append(ChatMessage(role=str(item.get("role", "user")), content=content))
            else:
                out.append(ChatMessage(role=str(item.get("role", "user")), content=str(content or "")))
        return out
    text = str(payload.get("input") or payload.get("prompt") or "").strip()
    if not text:
        raise ValidationError("Provide 'input' (or a non-empty 'messages' array) for the test request.")
    return [ChatMessage(role="user", content=text)]


def _summarize_payload(operation: str, payload: dict[str, Any]) -> str:
    text = str(payload.get("input") or payload.get("prompt") or payload.get("messages") or "")
    return f"[{operation}] {text[:400]}"


def _safe_params(payload: dict[str, Any]) -> dict[str, Any]:
    allowed = {"input", "prompt", "system", "temperature", "max_tokens", "top_p", "json_mode", "n", "size",
               "quality", "voice", "file_id", "model_params", "image_url"}
    out = {k: v for k, v in payload.items() if k in allowed}
    if "messages" in payload and isinstance(payload["messages"], list):
        out["messages"] = [
            {"role": m.get("role"), "content": str(m.get("content"))[:500]} for m in payload["messages"][:20] if isinstance(m, dict)
        ]
    return out


def _opt_float(value: Any) -> float | None:
    try:
        return float(value) if value is not None and value != "" else None
    except (TypeError, ValueError):
        return None


def _opt_int(value: Any) -> int | None:
    try:
        return int(value) if value is not None and value != "" else None
    except (TypeError, ValueError):
        return None


def provider_health_summary(db: Session, provider_id: int, *, hours: int = 24) -> dict[str, Any]:
    since = dt.datetime.now(dt.timezone.utc) - dt.timedelta(hours=hours)
    samples = db.scalars(
        select(ProviderHealthSample).where(ProviderHealthSample.provider_id == provider_id, ProviderHealthSample.created_at >= since)
    ).all()
    if not samples:
        return {"samples": 0, "success_rate": None, "avg_latency_ms": None, "p95_latency_ms": None, "error_categories": {}}
    successes = [s for s in samples if s.success]
    latencies = sorted(s.latency_ms for s in samples if s.latency_ms)
    categories: dict[str, int] = {}
    for sample in samples:
        if sample.error_category:
            categories[sample.error_category] = categories.get(sample.error_category, 0) + 1
    p95 = latencies[int(len(latencies) * 0.95) - 1] if latencies else None
    return {
        "samples": len(samples),
        "success_rate": round(len(successes) / len(samples), 4),
        "avg_latency_ms": int(sum(latencies) / len(latencies)) if latencies else None,
        "p95_latency_ms": p95,
        "error_categories": categories,
        "window_hours": hours,
    }
