import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

/**
 * Development server configuration.
 *
 * The frontend never calls `localhost` from the browser: every API request uses a
 * relative `/api/...` URL and Vite proxies it to the backend. That keeps the app
 * working behind the public-IP HTTP mode, Nginx and the Docker Compose stack alike.
 */
export default defineConfig({
  plugins: [react()],
  server: {
    host: "0.0.0.0",
    port: 5173,
    strictPort: false,
    // allowedHosts must include the sandbox/preview domains and a public IP
    allowedHosts: true,
    proxy: {
      "/api": {
        target: process.env.VITE_PROXY_TARGET || "http://127.0.0.1:8000",
        changeOrigin: true,
        secure: false,
      },
    },
  },
  preview: { host: "0.0.0.0", port: 4173 },
  build: { outDir: "dist", sourcemap: false, chunkSizeWarningLimit: 1200 },
});
