import React from "react";
import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import { LandingGate } from "./pages/Landing";
const Studio = React.lazy(() => import("./pages/Studio"));
import { AppLayout } from "./components/layout";
import { Button, Card } from "./components/ui";
import { SplashLoader } from "./components/splash";
import { Icon } from "./components/icons";
import { useApp } from "./state/app";
import { Login } from "./pages/Login";
import { Register } from "./pages/Register";
import { ForgotPassword } from "./pages/ForgotPassword";
import { ResetPassword } from "./pages/ResetPassword";
import { VerifyEmail } from "./pages/VerifyEmail";
const Dashboard = React.lazy(() => import("./pages/Dashboard").then((m) => ({ default: m.Dashboard })));
const DataOverview = React.lazy(() => import("./pages/DataOverview"));
const Coding = React.lazy(() => import("./pages/Coding").then((m) => ({ default: m.Coding })));
const Images = React.lazy(() => import("./pages/Images").then((m) => ({ default: m.Images })));
const Documents = React.lazy(() => import("./pages/Documents").then((m) => ({ default: m.Documents })));
const DataAnalysis = React.lazy(() => import("./pages/DataAnalysis").then((m) => ({ default: m.DataAnalysis })));
const Translation = React.lazy(() => import("./pages/Translation").then((m) => ({ default: m.Translation })));
const Audio = React.lazy(() => import("./pages/Audio").then((m) => ({ default: m.Audio })));
const Video = React.lazy(() => import("./pages/Video").then((m) => ({ default: m.Video })));
const Models = React.lazy(() => import("./pages/Models").then((m) => ({ default: m.Models })));
const ModelDetail = React.lazy(() => import("./pages/ModelDetail").then((m) => ({ default: m.ModelDetail })));
const Files = React.lazy(() => import("./pages/Files").then((m) => ({ default: m.Files })));
const Jobs = React.lazy(() => import("./pages/Jobs").then((m) => ({ default: m.Jobs })));
const Billing = React.lazy(() => import("./pages/Billing").then((m) => ({ default: m.Billing })));
const Payments = React.lazy(() => import("./pages/Payments").then((m) => ({ default: m.Payments })));
const Subscriptions = React.lazy(() => import("./pages/Subscriptions").then((m) => ({ default: m.Subscriptions })));
const Usage = React.lazy(() => import("./pages/Usage").then((m) => ({ default: m.Usage })));
const Profile = React.lazy(() => import("./pages/Profile").then((m) => ({ default: m.Profile })));
const Security = React.lazy(() => import("./pages/Security").then((m) => ({ default: m.Security })));
const Activity = React.lazy(() => import("./pages/Activity").then((m) => ({ default: m.Activity })));
import { Forbidden } from "./pages/Forbidden";
import { NotFound } from "./pages/NotFound";
const AdminDashboard = React.lazy(() => import("./pages/admin/AdminDashboard").then((m) => ({ default: m.AdminDashboard })));
const AdminUsers = React.lazy(() => import("./pages/admin/AdminUsers").then((m) => ({ default: m.AdminUsers })));
const AdminRoles = React.lazy(() => import("./pages/admin/AdminRoles").then((m) => ({ default: m.AdminRoles })));
const AdminProviders = React.lazy(() => import("./pages/admin/AdminProviders").then((m) => ({ default: m.AdminProviders })));
const AdminModels = React.lazy(() => import("./pages/admin/AdminModels").then((m) => ({ default: m.AdminModels })));
const AdminPricing = React.lazy(() => import("./pages/admin/AdminPricing").then((m) => ({ default: m.AdminPricing })));
const AdminPayments = React.lazy(() => import("./pages/admin/AdminPayments").then((m) => ({ default: m.AdminPayments })));
const AdminGrants = React.lazy(() => import("./pages/admin/AdminGrants").then((m) => ({ default: m.AdminGrants })));
const SharedChats = React.lazy(() => import("./pages/SharedChats").then((m) => ({ default: m.SharedChats })));
const SharedLink = React.lazy(() => import("./pages/SharedLink").then((m) => ({ default: m.SharedLink })));
const AdminPlans = React.lazy(() => import("./pages/admin/AdminPlans").then((m) => ({ default: m.AdminPlans })));
const AdminJobs = React.lazy(() => import("./pages/admin/AdminJobs").then((m) => ({ default: m.AdminJobs })));
const AdminSettings = React.lazy(() => import("./pages/admin/AdminSettings").then((m) => ({ default: m.AdminSettings })));
const AdminAudit = React.lazy(() => import("./pages/admin/AdminAudit").then((m) => ({ default: m.AdminAudit })));
const AdminSecurity = React.lazy(() => import("./pages/admin/AdminSecurity").then((m) => ({ default: m.AdminSecurity })));
const AdminSystem = React.lazy(() => import("./pages/admin/AdminSystem").then((m) => ({ default: m.AdminSystem })));
const AdminErrors = React.lazy(() => import("./pages/admin/AdminErrors").then((m) => ({ default: m.AdminErrors })));
const AdminBackups = React.lazy(() => import("./pages/admin/AdminBackups").then((m) => ({ default: m.AdminBackups })));

interface BoundaryState {
  error: Error | null;
}

/**
 * Never leave the operator in front of a blank page: a render error is caught,
 * shown with the technical detail, and the shell stays usable.
 */
class ErrorBoundary extends React.Component<{ children: React.ReactNode }, BoundaryState> {
  state: BoundaryState = { error: null };

  static getDerivedStateFromError(error: Error): BoundaryState {
    return { error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo): void {
    // eslint-disable-next-line no-console
    console.error("Unhandled UI error", error, info.componentStack);
  }

  render(): React.ReactNode {
    const { error } = this.state;
    if (!error) return this.props.children;
    return (
      <div className="boundary">
        <Card
          icon="alert"
          title="This screen hit an unexpected error"
          subtitle="The rest of the application is unaffected — no data was lost, and nothing was charged."
          danger
        >
          <pre className="boundary__detail" dir="ltr">
            {error.message}
          </pre>
          <div className="row">
            <Button variant="primary" onClick={() => this.setState({ error: null })}>
              <Icon name="refresh" size={16} />
              Try again
            </Button>
            <Button variant="subtle" onClick={() => window.location.assign("/app")}>
              <Icon name="dashboard" size={16} />
              Back to dashboard
            </Button>
          </div>
        </Card>
      </div>
    );
  }
}

function RequireAuth({ children }: { children: React.ReactNode }): JSX.Element {
  const { user, ready } = useApp();
  const location = useLocation();
  if (!ready) return <SplashLoader />;
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  return <>{children}</>;
}

export function RequirePermission({
  permissions,
  mode = "all",
  children,
}: {
  permissions: string[];
  /** "all" (default) requires every permission, "any" requires at least one. */
  mode?: "all" | "any";
  children: React.ReactNode;
}): JSX.Element {
  const { user, ready, hasPermission } = useApp();
  if (!ready) return <SplashLoader />;
  if (!user) return <Navigate to="/login" replace />;
  const allowed = mode === "any" ? permissions.some((permission) => hasPermission(permission)) : hasPermission(permissions);
  if (!allowed) {
    return (
      <Forbidden
        required={permissions}
        message="Your role does not include the permission required for this page."
      />
    );
  }
  return <>{children}</>;
}

export default function App(): JSX.Element {
  return (
    <ErrorBoundary>
      <React.Suspense fallback={<SplashLoader />}>
      <Routes>
      <Route path="/" element={<LandingGate />} />
      <Route path="/login" element={<Login />} />
      <Route path="/share/:token" element={<SharedLink />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/verify-email" element={<VerifyEmail />} />

      <Route
        path="/app"
        element={
          <RequireAuth>
            <AppLayout />
          </RequireAuth>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="chat" element={<DataOverview />} />
        <Route path="studio" element={<Studio />} />
        <Route path="shared" element={<SharedChats />} />
        <Route path="coding" element={<Coding />} />
        <Route path="images" element={<Images />} />
        <Route path="documents" element={<Documents />} />
        <Route path="data" element={<DataAnalysis />} />
        <Route path="translation" element={<Translation />} />
        <Route path="audio" element={<Audio />} />
        <Route path="video" element={<Video />} />
        <Route path="models" element={<Models />} />
        <Route path="models/:modelId" element={<ModelDetail />} />
        <Route path="files" element={<Files />} />
        <Route path="jobs" element={<Jobs />} />
        <Route path="billing" element={<Billing />} />
        <Route path="payments" element={<Payments />} />
        <Route path="subscriptions" element={<Subscriptions />} />
        <Route path="usage" element={<Usage />} />
        <Route path="profile" element={<Profile />} />
        <Route path="security" element={<Security />} />
        <Route path="activity" element={<Activity />} />

        <Route
          path="admin"
          element={
            <RequirePermission
              mode="any"
              permissions={["users.read", "providers.read", "models.read", "pricing.manage", "payments.read", "reports.read", "audit.read", "backups.manage"]}
            >
              <AdminDashboard />
            </RequirePermission>
          }
        />
        <Route
          path="admin/users"
          element={
            <RequirePermission permissions={["users.read"]}>
              <AdminUsers />
            </RequirePermission>
          }
        />
        <Route
          path="admin/roles"
          element={
            <RequirePermission permissions={["roles.manage"]}>
              <AdminRoles />
            </RequirePermission>
          }
        />
        <Route
          path="admin/providers"
          element={
            <RequirePermission permissions={["providers.manage"]}>
              <AdminProviders />
            </RequirePermission>
          }
        />
        <Route
          path="admin/models"
          element={
            <RequirePermission permissions={["models.manage"]}>
              <AdminModels />
            </RequirePermission>
          }
        />
        <Route
          path="admin/pricing"
          element={
            <RequirePermission permissions={["pricing.manage"]}>
              <AdminPricing />
            </RequirePermission>
          }
        />
        <Route
          path="admin/grants"
          element={
            <RequirePermission permissions={["credits.manage"]}>
              <AdminGrants />
            </RequirePermission>
          }
        />
        <Route
          path="admin/payments"
          element={
            <RequirePermission permissions={["payments.read"]}>
              <AdminPayments />
            </RequirePermission>
          }
        />
        <Route
          path="admin/plans"
          element={
            <RequirePermission permissions={["subscriptions.manage"]}>
              <AdminPlans />
            </RequirePermission>
          }
        />
        <Route
          path="admin/jobs"
          element={
            <RequirePermission permissions={["jobs.manage"]}>
              <AdminJobs />
            </RequirePermission>
          }
        />
        <Route
          path="admin/settings"
          element={
            <RequirePermission permissions={["settings.manage"]}>
              <AdminSettings />
            </RequirePermission>
          }
        />
        <Route
          path="admin/audit"
          element={
            <RequirePermission permissions={["audit.read"]}>
              <AdminAudit />
            </RequirePermission>
          }
        />
        <Route
          path="admin/security"
          element={
            <RequirePermission permissions={["security.read"]}>
              <AdminSecurity />
            </RequirePermission>
          }
        />
        <Route
          path="admin/system"
          element={
            <RequirePermission permissions={["settings.manage"]}>
              <AdminSystem />
            </RequirePermission>
          }
        />
        <Route
          path="admin/errors"
          element={
            <RequirePermission permissions={["audit.read"]}>
              <AdminErrors />
            </RequirePermission>
          }
        />
        <Route
          path="admin/backups"
          element={
            <RequirePermission permissions={["backups.manage"]}>
              <AdminBackups />
            </RequirePermission>
          }
        />
        <Route path="*" element={<NotFound />} />
      </Route>

      <Route path="/" element={<Navigate to="/app" replace />} />
      <Route path="*" element={<NotFound />} />
      </Routes>
      </React.Suspense>
    </ErrorBoundary>
  );
}
