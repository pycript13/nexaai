import React, { useState } from "react";
import { api } from "../api/client";
import type { Job } from "../api/types";
import { Badge, Button, Card, ErrorNotice, Field, useApi } from "../components/ui";
import { JobCard, ModuleNotice, useCatalog } from "./shared";
import { ModelNotice } from "./moduleHelpers";
import { useApp, useI18n } from "../state/app";

export function Video(): JSX.Element {
  const { t } = useI18n();
  const { notify } = useApp();
  const catalog = useCatalog();
  const [modelId, setModelId] = useState<number | null>(null);
  const [prompt, setPrompt] = useState("");
  const [aspect, setAspect] = useState("");
  const [duration, setDuration] = useState<number | "">("");
  const [job, setJob] = useState<Job | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);

  const models = (catalog.data?.items || []).filter((model) => model.accessible && model.capabilities.includes("video_generation"));
  React.useEffect(() => {
    if (modelId === null && models.length > 0) setModelId(models[0].id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [models.length]);

  const jobs = useApi<{ items: Job[] }>(() => api.get("/api/v1/jobs", { job_type: "video_generation", page_size: 5 }), [job?.id]);

  const submit = async () => {
    setBusy(true);
    setError(null);
    try {
      const response = await api.post<{ job: Job }>("/api/v1/modules/video/generate", {
        model_id: modelId,
        prompt,
        aspect_ratio: aspect || undefined,
        duration_seconds: duration === "" ? undefined : Number(duration),
      });
      setJob(response.job);
      notify("success", "Video job queued. Rendering happens at the provider and is charged on success.");
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.video")}</h1>
          <p>Video generation is asynchronous: the job is tracked, and it is charged only when the provider returns an output.</p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      <ModuleNotice capability="video" title={t("nav.video")} />

      <div className="grid grid--2">
        <Card title="New video job">
          <ModelNotice models={models} value={modelId} onChange={setModelId} capability="video_generation" />
          {models.length === 0 && (
            <p className="muted">
              No model with the <code>video_generation</code> capability is available. Video providers are usually
              asynchronous and must be configured by an administrator first.
            </p>
          )}
          <Field label="Prompt">
            <textarea value={prompt} onChange={(event) => setPrompt(event.target.value)} />
          </Field>
          <div className="grid grid--2">
            <Field label="Aspect ratio (optional)">
              <input value={aspect} onChange={(event) => setAspect(event.target.value)} placeholder="16:9" dir="ltr" />
            </Field>
            <Field label="Duration seconds (optional)">
              <input
                type="number"
                min={1}
                value={duration}
                onChange={(event) => setDuration(event.target.value === "" ? "" : Number(event.target.value))}
              />
            </Field>
          </div>
          <Button type="button" onClick={submit} loading={busy} disabled={!modelId || !prompt.trim() || busy}>
            Queue job
          </Button>
        </Card>

        <Card title="Latest jobs">
          {!jobs.data || jobs.data.items.length === 0 ? (
            <p className="muted">{t("status.empty")}</p>
          ) : (
            <div className="stack">
              {jobs.data.items.map((item) => (
                <JobCard key={item.id} job={item} />
              ))}
            </div>
          )}
        </Card>
      </div>

      {job && <JobCard job={job} />}
    </div>
  );
}
