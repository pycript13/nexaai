import React, { useState } from "react";
import { api, ApiError } from "../api/client";
import type { Job, StoredFile } from "../api/types";
import { Badge, Button, Card, ErrorNotice, Field } from "../components/ui";
import { Markdown } from "../components/Markdown";
import { ModuleNotice, NoModelsHint, useCatalog, UsageLine } from "./shared";
import { ModelNotice } from "./moduleHelpers";
import { useApp, useI18n } from "../state/app";

export function Documents(): JSX.Element {
  const { t } = useI18n();
  const { notify } = useApp();
  const catalog = useCatalog();
  const [files, setFiles] = useState<StoredFile[]>([]);
  const [fileIds, setFileIds] = useState<number[]>([]);
  const [modelId, setModelId] = useState<number | null>(null);
  const [mode, setMode] = useState("summarize");
  const [question, setQuestion] = useState("");
  const [targetLanguage, setTargetLanguage] = useState("English");
  const [asyncJob, setAsyncJob] = useState(false);
  const [result, setResult] = React.useState<any>(null);
  const [job, setJob] = useState<Job | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);

  const models = (catalog.data?.items || []).filter((model) => model.accessible && model.capabilities.includes("chat"));
  React.useEffect(() => {
    if (modelId === null && models.length > 0) setModelId(models[0].id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [models.length]);

  const loadFiles = async () => {
    const data = await api.get<{ items: StoredFile[] }>("/api/v1/files", { page_size: 50 });
    setFiles(data.items);
  };
  React.useEffect(() => {
    loadFiles().catch(setError);
  }, []);

  const upload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append("file", file);
    setBusy(true);
    try {
      const response = await api.upload<{ file: StoredFile }>("/api/v1/files", form);
      notify("success", `Uploaded ${response.file.original_name}`);
      await loadFiles();
      setFileIds((current) => [...current, response.file.id]);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
      event.target.value = "";
    }
  };

  const run = async () => {
    setBusy(true);
    setError(null);
    setResult(null);
    setJob(null);
    try {
      const payload = {
        model_id: modelId,
        file_ids: fileIds,
        mode,
        question: mode === "ask" ? question : undefined,
        target_language: mode === "translate" ? targetLanguage : undefined,
        async_job: asyncJob || mode === "index",
      };
      if (payload.async_job) {
        const response = await api.post<{ job: Job }>("/api/v1/modules/documents/process", payload);
        setJob(response.job);
        notify("info", "The document job was queued in the background.");
      } else {
        setResult(await api.post("/api/v1/modules/documents/process", payload));
      }
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.documents")}</h1>
          <p>Upload documents (PDF, DOCX, XLSX, CSV, TXT) and summarise, question, extract or translate them with a configured model.</p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      {!catalog.loading && models.length === 0 && <NoModelsHint />}
      <ModuleNotice capability="documents" title={t("nav.documents")} />

      <div className="grid grid--2">
        <Card title="Documents">
          <Field label={t("action.upload")} hint="Files are stored privately and served only through the authenticated API.">
            <input type="file" onChange={upload} disabled={busy} />
          </Field>
          {files.length === 0 ? (
            <p className="muted">No files uploaded yet.</p>
          ) : (
            <ul className="stack" style={{ listStyle: "none", padding: 0, margin: 0 }}>
              {files.map((file) => (
                <li key={file.id} className="row row--between">
                  <label className="checkbox">
                    <input
                      type="checkbox"
                      checked={fileIds.includes(file.id)}
                      onChange={(event) =>
                        setFileIds((current) =>
                          event.target.checked ? [...current, file.id] : current.filter((id) => id !== file.id),
                        )
                      }
                    />
                    <span>
                      {file.original_name} <span className="muted small">({file.extension})</span>
                    </span>
                  </label>
                  <Badge tone="neutral">{file.kind}</Badge>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card title="Process">
          <ModelNotice models={models} value={modelId} onChange={setModelId} />
          <Field label="Mode">
            <select value={mode} onChange={(event) => setMode(event.target.value)}>
              <option value="summarize">summarise</option>
              <option value="ask">ask a question</option>
              <option value="extract">extract structured data</option>
              <option value="translate">translate</option>
              <option value="index">index for retrieval (no model call)</option>
            </select>
          </Field>
          {mode === "ask" && (
            <Field label="Question">
              <textarea value={question} onChange={(event) => setQuestion(event.target.value)} />
            </Field>
          )}
          {mode === "translate" && (
            <Field label="Target language">
              <input value={targetLanguage} onChange={(event) => setTargetLanguage(event.target.value)} />
            </Field>
          )}
          <label className="checkbox" style={{ marginBottom: "0.8rem" }}>
            <input type="checkbox" checked={asyncJob} onChange={(event) => setAsyncJob(event.target.checked)} />
            <span>Run as a background job (recommended for long documents)</span>
          </label>
          <Button type="button" onClick={run} loading={busy} disabled={fileIds.length === 0 || busy}>
            Run
          </Button>
        </Card>
      </div>

      {job && (
        <Card title={`Job #${job.id}`} actions={<Badge tone="warning">{job.status}</Badge>}>
          <p className="muted">Track it in {t("nav.jobs")}.</p>
        </Card>
      )}

      {result && (
        <Card title="Result" actions={result.usage ? <Badge tone="info">charged {result.usage.charged_micro}</Badge> : undefined}>
          {result.mode && <p className="muted small">mode: {result.mode}</p>}
          <Markdown text={result.result || JSON.stringify(result, null, 2)} />
          {result.documents?.length ? (
            <p className="muted small">
              context strategy per document:{" "}
              {result.documents
                .map((doc: any) => `${doc.name} → ${doc.context?.strategy || "n/a"}`)
                .join(" · ")}
            </p>
          ) : null}
          <UsageLine usage={result.usage} />
        </Card>
      )}
    </div>
  );
}
