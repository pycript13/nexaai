import React, { useState } from "react";
import { api } from "../api/client";
import type { Job, StoredFile } from "../api/types";
import { Badge, Button, Card, ErrorNotice, Field } from "../components/ui";
import { ModuleNotice, useCatalog } from "./shared";
import { ModelNotice } from "./moduleHelpers";
import { useApp, useI18n } from "../state/app";

export function Audio(): JSX.Element {
  const { t } = useI18n();
  const { notify } = useApp();
  const catalog = useCatalog();
  const [tab, setTab] = useState<"transcribe" | "speak">("transcribe");
  const [modelId, setModelId] = useState<number | null>(null);
  const [fileId, setFileId] = useState<number | null>(null);
  const [language, setLanguage] = useState("");
  const [text, setText] = useState("");
  const [voice, setVoice] = useState("");
  const [asyncJob, setAsyncJob] = useState(false);
  const [files, setFiles] = useState<StoredFile[]>([]);
  const [result, setResult] = useState<any>(null);
  const [job, setJob] = useState<Job | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);

  const audioModels = (catalog.data?.items || []).filter(
    (model) => model.accessible && (tab === "transcribe" ? model.capabilities.includes("audio_transcription") : model.capabilities.includes("speech_generation")),
  );

  React.useEffect(() => {
    if (!audioModels.some((model) => model.id === modelId)) setModelId(audioModels.length ? audioModels[0].id : null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab, audioModels.length]);

  React.useEffect(() => {
    api
      .get<{ items: StoredFile[] }>("/api/v1/files", { page_size: 50 })
      .then((data) => setFiles(data.items))
      .catch(() => undefined);
  }, [result]);

  const upload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append("file", file);
    setBusy(true);
    try {
      const response = await api.upload<{ file: StoredFile }>("/api/v1/files", form);
      setFileId(response.file.id);
      notify("success", `Uploaded ${response.file.original_name}`);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
      event.target.value = "";
    }
  };

  const run = async () => {
    setBusy(true);
    setError(null);
    setResult(null);
    setJob(null);
    try {
      if (tab === "transcribe") {
        const response = await api.post<any>("/api/v1/modules/audio/transcribe", {
          model_id: modelId,
          file_id: fileId,
          language: language || undefined,
          async_job: asyncJob,
        });
        if (response.job) setJob(response.job);
        else setResult(response);
      } else {
        setResult(await api.post("/api/v1/modules/audio/speak", { model_id: modelId, text, voice: voice || undefined }));
      }
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.audio")}</h1>
          <p>Transcription and speech synthesis use a configured audio model; long files can run as background jobs.</p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      <ModuleNotice capability="audio" title={t("nav.audio")} />

      <div className="tabs">
        <button className={`tab ${tab === "transcribe" ? "tab--active" : ""}`} onClick={() => setTab("transcribe")} type="button">
          Transcribe
        </button>
        <button className={`tab ${tab === "speak" ? "tab--active" : ""}`} onClick={() => setTab("speak")} type="button">
          Text to speech
        </button>
      </div>

      <div className="grid grid--2">
        <Card title={tab === "transcribe" ? "Transcription" : "Speech synthesis"}>
          <ModelNotice
            models={audioModels}
            value={modelId}
            onChange={setModelId}
            capability={tab === "transcribe" ? "audio_transcription" : "speech_generation"}
          />
          {audioModels.length === 0 && (
            <p className="muted">
              No model with the <code>{tab === "transcribe" ? "audio_transcription" : "speech_generation"}</code>{" "}
              capability is available to your account.
            </p>
          )}
          {tab === "transcribe" ? (
            <>
              <Field label="Audio file" hint="Supported: flac, m4a, mp3, ogg, wav, webm">
                <input type="file" accept=".mp3,.wav,.m4a,.ogg,.flac,.webm" onChange={upload} disabled={busy} />
              </Field>
              <Field label="Or choose an uploaded file">
                <select value={fileId ?? ""} onChange={(event) => setFileId(event.target.value ? Number(event.target.value) : null)}>
                  <option value="">—</option>
                  {files.map((file) => (
                    <option key={file.id} value={file.id}>
                      {file.original_name}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Language hint (optional)">
                <input value={language} onChange={(event) => setLanguage(event.target.value)} placeholder="fa, en, ar…" dir="ltr" />
              </Field>
              <label className="checkbox" style={{ marginBottom: "0.7rem" }}>
                <input type="checkbox" checked={asyncJob} onChange={(event) => setAsyncJob(event.target.checked)} />
                <span>Run as a background job</span>
              </label>
            </>
          ) : (
            <>
              <Field label="Text to speak" hint="Nexa AI produces spoken audio; it does not sing or create music.">
                <textarea value={text} onChange={(event) => setText(event.target.value)} />
              </Field>
              <Field label="Voice (optional)">
                <input value={voice} onChange={(event) => setVoice(event.target.value)} dir="ltr" />
              </Field>
            </>
          )}
          <Button type="button" onClick={run} loading={busy} disabled={!modelId || busy || (tab === "transcribe" ? !fileId : !text.trim())}>
            {tab === "transcribe" ? "Transcribe" : "Synthesise"}
          </Button>
        </Card>

        <Card title="Output">
          {job && (
            <div className="stack">
              <Badge tone="warning">job #{job.id} · {job.status}</Badge>
              <p className="muted">Track progress under {t("nav.jobs")}.</p>
            </div>
          )}
          {!job && !result && <p className="muted">{t("status.empty")}</p>}
          {result?.text && (
            <>
              <p className="muted small">{result.duration_seconds ? `${result.duration_seconds.toFixed?.(1) ?? result.duration_seconds}s` : ""}</p>
              <p>{result.text}</p>
            </>
          )}
          {result?.file_id && (
            <div className="stack">
              <audio controls src={result.download_url || `/api/v1/files/${result.file_id}/download`} />
              <p className="muted small">
                {result.bytes} bytes · {result.duration_note || ""}
              </p>
            </div>
          )}
          {result?.usage && <p className="muted small">charged {result.usage.charged_micro} micro-credits</p>}
        </Card>
      </div>
    </div>
  );
}
