import React, { useState } from "react";
import { api } from "../api/client";
import { Badge, Button, Card, DataTable, ErrorNotice, Field, SuccessNotice, useApi } from "../components/ui";
import { formatDateTime } from "../utils/format";
import { useApp, useI18n } from "../state/app";

interface SessionRecord {
  id: number;
  current: boolean;
  user_agent: string | null;
  ip_address: string | null;
  created_at: string;
  last_seen_at: string;
  expires_at: string;
  revoked_at: string | null;
  revoked_reason: string | null;
  active: boolean;
}

export function Security(): JSX.Element {
  const { t, locale } = useI18n();
  const { notify, refreshMe } = useApp();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const sessions = useApi<{ items: SessionRecord[] }>(() => api.get("/api/v1/auth/sessions"), []);

  const changePassword = async (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);
    setNotice(null);
    if (next !== confirm) {
      setError(new Error("The two new passwords do not match."));
      return;
    }
    setBusy(true);
    try {
      const response = await api.post<{ sessions_revoked?: number; message?: string }>("/api/v1/auth/password", {
        current_password: current,
        new_password: next,
      });
      setNotice(
        `${response.message || "Password updated."} ${
          response.sessions_revoked !== undefined ? `${response.sessions_revoked} other session(s) were signed out.` : ""
        }`,
      );
      setCurrent("");
      setNext("");
      setConfirm("");
      sessions.reload();
      await refreshMe();
      notify("success", t("common.saved"));
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const revoke = async (sessionId: number) => {
    setBusy(true);
    setError(null);
    try {
      await api.del(`/api/v1/auth/sessions/${sessionId}`);
      notify("success", "Session revoked");
      sessions.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const revokeAll = async () => {
    setBusy(true);
    setError(null);
    try {
      await api.del("/api/v1/auth/sessions");
      notify("success", "All other sessions were signed out");
      sessions.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.security")}</h1>
          <p>Sessions are tracked server-side; changing your password revokes every other session.</p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      {notice && <SuccessNotice message={notice} />}

      <div className="grid grid--2">
        <Card title="Change password">
          <form onSubmit={changePassword}>
            <Field label={t("label.currentPassword")}>
              <input type="password" value={current} onChange={(event) => setCurrent(event.target.value)} required />
            </Field>
            <Field label={t("label.newPassword")} hint="Use a long passphrase; it is hashed with Argon2 on the server.">
              <input type="password" value={next} onChange={(event) => setNext(event.target.value)} required />
            </Field>
            <Field label="Repeat new password">
              <input type="password" value={confirm} onChange={(event) => setConfirm(event.target.value)} required />
            </Field>
            <Button type="submit" loading={busy} disabled={busy}>
              Update password
            </Button>
          </form>
        </Card>

        <Card title="Security posture">
          <ul className="stack" style={{ paddingInlineStart: "1.1rem" }}>
            <li>Passwords are hashed with Argon2 and never logged.</li>
            <li>Sessions use httpOnly cookies with CSRF tokens for mutating requests.</li>
            <li>Provider API keys are encrypted at rest and only ever shown masked.</li>
            <li>Failed sign-ins and permission denials are recorded as security events.</li>
            <li>Uploads are validated by extension and magic bytes, and stored outside the web root.</li>
          </ul>
        </Card>
      </div>

      <Card
        title="Active sessions"
        actions={
          <Button variant="danger" type="button" onClick={revokeAll} disabled={busy}>
            Sign out everywhere else
          </Button>
        }
      >
        <DataTable
          rows={sessions.data?.items || []}
          loading={sessions.loading}
          columns={[
            { key: "id", header: "#", render: (row) => row.id },
            {
              key: "agent",
              header: "Client",
              render: (row) => (
                <span>
                  {row.user_agent || "unknown"} {row.current ? <Badge tone="success">this session</Badge> : null}
                </span>
              ),
            },
            { key: "ip", header: "IP", render: (row) => <span className="mono">{row.ip_address || "—"}</span> },
            { key: "last", header: "Last seen", render: (row) => formatDateTime(row.last_seen_at, locale) },
            {
              key: "status",
              header: t("label.status"),
              render: (row) => (row.active ? <Badge tone="success">active</Badge> : <Badge tone="danger">{row.revoked_reason || "revoked"}</Badge>),
            },
            {
              key: "actions",
              header: t("label.actions"),
              render: (row) => (
                <Button variant="ghost" type="button" disabled={busy || !row.active} onClick={() => revoke(row.id)}>
                  Revoke
                </Button>
              ),
            },
          ]}
        />
      </Card>
    </div>
  );
}
