import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api, ApiError } from "../api/client";
import { useApp, useI18n } from "../state/app";
import { Button, ErrorNotice, Field } from "../components/ui";
import { AuthShell } from "../components/auth";
import { Icon } from "../components/icons";

export function Login(): JSX.Element {
  const { login, meta } = useApp();
  const { t } = useI18n();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  const [resetSent, setResetSent] = useState<string | null>(null);
  const [resetBusy, setResetBusy] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await login(email, password);
      navigate("/app", { replace: true });
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const requestReset = async () => {
    setResetBusy(true);
    setError(null);
    try {
      const response = await api.post<{ message?: string }>("/api/v1/auth/password/reset-request", { email });
      setResetSent(response?.message || "If the address exists, a reset link has been prepared.");
    } catch (caught) {
      setError(caught);
    } finally {
      setResetBusy(false);
    }
  };

  return (
    <AuthShell title={t("login.title")} subtitle={t("login.subtitle")}>
      {error ? <ErrorNotice error={error} /> : null}
      {resetSent ? (
        <div className="alert alert--success" role="status">
          <div className="alert__body">
            <Icon name="check" size={18} />
            <div>
              <strong>{resetSent}</strong>
              <p className="alert__hint">
                Delivery depends on the configured mail transport; if email is not configured the administrator can
                reset the password manually under Admin → Users.
              </p>
            </div>
          </div>
        </div>
      ) : null}

      <form onSubmit={submit}>
        <Field label={t("label.email")}>
          <input
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            required
            autoComplete="username"
            dir="ltr"
            placeholder="you@example.com"
          />
        </Field>
        <Field label={t("label.password")}>
          <span style={{ position: "relative", display: "block" }}>
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              required
              autoComplete="current-password"
              style={{ paddingInlineEnd: "3rem" }}
            />
            <button
              type="button"
              className="iconbtn iconbtn--ghost"
              style={{ position: "absolute", insetInlineEnd: "4px", top: "50%", translate: "0 -50%", width: 32, height: 32 }}
              onClick={() => setShowPassword((value) => !value)}
              aria-label={t("label.password")}
            >
              <Icon name="eye" size={16} />
            </button>
          </span>
        </Field>
        <Button type="submit" loading={busy} disabled={busy} className="btn--block">
          {t("action.login")}
        </Button>
      </form>

      <div className="row row--between" style={{ marginTop: "0.95rem" }}>
        <Link to="/forgot-password">{t("login.forgot")}</Link>
        <span className="muted small">
          {t("login.noAccount")}{" "}
          {meta?.registration_enabled === false ? <em>{t("common.requiresAdmin")}</em> : <Link to="/register">{t("action.register")}</Link>}
        </span>
      </div>
      <div className="row" style={{ marginTop: "0.7rem" }}>
        <Button variant="ghost" type="button" onClick={requestReset} loading={resetBusy} disabled={!email || resetBusy}>
          {t("login.forgot")}
        </Button>
      </div>
    </AuthShell>
  );
}
