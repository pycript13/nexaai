import { useState } from "react";
import { api } from "../../api/client";
import type { Pagination as PaginationMeta } from "../../api/types";
import { Badge, Button, Card, DataTable, ErrorNotice, Field, Modal, Pagination, Spinner, StatusBadge, useApi } from "../../components/ui";
import { formatDateTime } from "../../utils/format";
import { useI18n } from "../../state/app";

/**
 * Provider/request failures recorded by the gateway.
 *
 * `GET /api/v1/admin/errors` answers usage rows that carry an `error_category`
 * (`{id, category, operation, status, model_id, provider_id, user_id, is_admin_test,
 * created_at, metadata}`) plus `categories: [{category, count}]`.  The screen used to assume an
 * HTTP-error log (`code`, `message`, `path`, …) and rendered `{value}` for each category entry —
 * an object — which crashed the whole page with React error #31.  It now renders the real shape
 * and treats an unexpected one as "no data" instead of failing to paint.
 */
interface ErrorRecord {
  id: number;
  category?: string | null;
  operation?: string | null;
  status?: string | null;
  model_id?: number | null;
  provider_id?: number | null;
  user_id?: number | null;
  is_admin_test?: boolean;
  created_at: string;
  metadata?: Record<string, unknown> | null;
}

interface CategoryCount {
  category: string;
  count: number;
}

function categoryEntries(raw: unknown): CategoryCount[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((entry) => {
      if (typeof entry === "string") return { category: entry, count: 0 };
      if (entry && typeof entry === "object") {
        const record = entry as Record<string, unknown>;
        return {
          category: String(record.category ?? record.code ?? record.slug ?? ""),
          count: Number(record.count ?? record.total ?? 0) || 0,
        };
      }
      return null;
    })
    .filter((entry): entry is CategoryCount => Boolean(entry && entry.category));
}

export function AdminErrors(): JSX.Element {
  const { t, locale } = useI18n();
  const [page, setPage] = useState(1);
  const [category, setCategory] = useState("");
  const errors = useApi<{ items: ErrorRecord[]; pagination: PaginationMeta; categories?: unknown }>(
    () => api.get("/api/v1/admin/errors", { page, page_size: 25, category: category || undefined }),
    [page, category],
  );
  const [selected, setSelected] = useState<ErrorRecord | null>(null);

  if (errors.loading && !errors.data) return <Spinner />;
  const categories = categoryEntries(errors.data?.categories);

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.errors")}</h1>
          <p>{t("admin.errorsNote")}</p>
        </div>
        <Button variant="subtle" type="button" onClick={errors.reload}>
          {t("action.refresh")}
        </Button>
      </div>

      {errors.error ? <ErrorNotice error={errors.error} onRetry={errors.reload} /> : null}

      <Card title={t("action.filter")}>
        <Field label={t("admin.ui.category")}>
          <select value={category} onChange={(event) => { setPage(1); setCategory(event.target.value); }}>
            <option value="">{t("common.all")}</option>
            {categories.map((entry) => (
              <option key={entry.category} value={entry.category}>
                {entry.category}
                {entry.count ? ` · ${entry.count}` : ""}
              </option>
            ))}
          </select>
        </Field>
      </Card>

      <Card title={t("admin.ui.recentErrors")}>
        <DataTable
          rows={errors.data?.items || []}
          empty={<p className="muted">{t("admin.noErrors")}</p>}
          columns={[
            { key: "created", header: t("label.when"), render: (row) => formatDateTime(row.created_at, locale) },
            { key: "category", header: t("admin.ui.category"), render: (row) => <Badge tone="warning">{row.category || "—"}</Badge> },
            { key: "operation", header: t("label.operation"), render: (row) => <span className="mono">{row.operation || "—"}</span> },
            { key: "status", header: t("label.status"), render: (row) => <StatusBadge value={row.status} /> },
            { key: "model", header: t("label.model"), render: (row) => row.model_id ?? "—" },
            { key: "provider", header: t("label.provider"), render: (row) => row.provider_id ?? "—" },
            { key: "user", header: t("admin.ui.userId"), render: (row) => row.user_id ?? "—" },
            {
              key: "admin_test",
              header: t("admin.administrativeTest"),
              render: (row) => (row.is_admin_test ? t("common.yes") : t("common.no")),
            },
            {
              key: "actions",
              header: t("label.actions"),
              render: (row) => (
                <Button variant="ghost" type="button" onClick={() => setSelected(row)}>
                  {t("label.detail")}
                </Button>
              ),
            },
          ]}
        />
        <Pagination meta={errors.data?.pagination} onChange={setPage} />
      </Card>

      <Modal
        open={Boolean(selected)}
        wide
        title={selected ? `${selected.category || ""} · ${selected.operation || ""}` : ""}
        onClose={() => setSelected(null)}
        footer={
          <Button variant="subtle" type="button" onClick={() => setSelected(null)}>
            {t("action.close")}
          </Button>
        }
      >
        {selected ? (
          <div className="stack">
            <div className="kv">
              <div>
                <span>{t("label.when")}</span>
                <span>{formatDateTime(selected.created_at, locale)}</span>
              </div>
              <div>
                <span>{t("label.status")}</span>
                <span>{selected.status || "—"}</span>
              </div>
              <div>
                <span>{t("label.model")}</span>
                <span className="mono">{String(selected.model_id ?? "—")}</span>
              </div>
              <div>
                <span>{t("label.provider")}</span>
                <span className="mono">{String(selected.provider_id ?? "—")}</span>
              </div>
            </div>
            <pre className="md__code">{JSON.stringify(selected.metadata || {}, null, 2)}</pre>
          </div>
        ) : null}
      </Modal>
    </div>
  );
}
