import { Link } from "react-router-dom";
import { api } from "../../api/client";
import { Badge, Card, ErrorNotice, Spinner, Stat, useApi } from "../../components/ui";
import { BarChart } from "../../components/charts";
import { formatCredits, formatDateTime, formatNumber } from "../../utils/format";
import { useI18n } from "../../state/app";

interface DashboardPayload {
  users: Record<string, number>;
  ai: Record<string, unknown>;
  usage: Record<string, number>;
  finance: Record<string, unknown>;
  recent_errors: { id: number; code: string; message: string; created_at: string; count?: number }[];
  recent_audit: { id: number; action: string; summary: string; actor: string | null; created_at: string }[];
  deployment: Record<string, unknown>;
}

export function AdminDashboard(): JSX.Element {
  const { t, locale } = useI18n();
  const dashboard = useApi<DashboardPayload>(() => api.get("/api/v1/admin/dashboard"), []);

  if (dashboard.loading) return <Spinner />;
  if (dashboard.error) return <ErrorNotice error={dashboard.error} onRetry={dashboard.reload} />;
  const data = dashboard.data!;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.dashboard")}</h1>
          <p>{t("admin.overview")}</p>
        </div>
      </div>

      <div className="grid grid--4">
        <Stat label={t("admin.ui.users")} value={formatNumber(data.users?.total ?? 0)} hint={`${data.users?.active ?? 0} active`} />
        <Stat label={t("admin.ui.providers")} value={formatNumber(Number(data.ai?.providers ?? 0))} hint={`${data.ai?.enabled_providers ?? 0} enabled`} />
        <Stat label={t("admin.ui.models")} value={formatNumber(Number(data.ai?.models ?? 0))} hint={`${data.ai?.published_models ?? 0} published`} />
        <Stat
          label={t("admin.ui.requests24h")}
          value={formatNumber(data.usage?.requests_24h ?? 0)}
          hint={`${data.usage?.failures_24h ?? 0} failures`}
        />
      </div>

      <div className="grid grid--2">
        <Card title={t("admin.ui.finance")} subtitle={t("admin.ui.financeNote")}>
          <div className="kv">
            <div>
              <span>{t("label.balance")} in circulation</span>
              <span className="mono">{formatCredits(Number(data.finance?.credits_outstanding_micro ?? 0))}</span>
            </div>
            <div>
              <span>{t("admin.charged30")}</span>
              <span className="mono">{formatCredits(Number(data.finance?.charged_30d_micro ?? 0))}</span>
            </div>
            <div>
              <span>{t("admin.providerCost30")}</span>
              <span className="mono">{formatCredits(Number(data.finance?.provider_cost_30d_micro ?? 0))}</span>
            </div>
            <div>
              <span>{t("admin.pendingPayments")}</span>
              <span>
                {formatNumber(Number(data.finance?.pending_payments ?? 0))}{" "}
                <Link to="/app/admin/payments">review</Link>
              </span>
            </div>
            <div>
              <span>{t("admin.ledgerConsistency")}</span>
              <span>
                {Number(data.finance?.ledger_inconsistencies ?? 0) === 0 ? (
                  <Badge tone="success">consistent</Badge>
                ) : (
                  <Badge tone="danger">{String(data.finance?.ledger_inconsistencies)} inconsistent accounts</Badge>
                )}
              </span>
            </div>
          </div>
        </Card>

        <Card title={t("admin.ui.deployment")} subtitle={t("admin.ui.runtimeNote")}>
          <div className="kv">
            {Object.entries(data.deployment || {}).map(([key, value]) => (
              <div key={key}>
                <span>{key}</span>
                <span>{typeof value === "string" || typeof value === "number" ? String(value) : JSON.stringify(value)}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card title={t("admin.ui.usageByModule")}>
        <BarChart
          data={Object.entries(data.usage || {})
            .filter(([key]) => key.startsWith("charged_by_module") || key.includes("by_module"))
            .map(([key, value]) => ({ label: key, value: Number(value) }))}
          format={(value) => formatCredits(value)}
        />
      </Card>

      <div className="grid grid--2">
        <Card
          title={t("admin.ui.recentErrors")}
          actions={<Link to="/app/admin/errors">{t("common.all")}</Link>}
        >
          {data.recent_errors?.length ? (
            <ul className="stack" style={{ listStyle: "none", padding: 0, margin: 0 }}>
              {data.recent_errors.map((error) => (
                <li key={error.id}>
                  <Badge tone="danger">{error.code}</Badge> <span>{error.message}</span>{" "}
                  <span className="muted small">{formatDateTime(error.created_at, locale)}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="muted">{t("admin.noErrors")}</p>
          )}
        </Card>
        <Card title={t("admin.ui.recentActions")} actions={<Link to="/app/admin/audit">{t("common.all")}</Link>}>
          {data.recent_audit?.length ? (
            <ul className="stack" style={{ listStyle: "none", padding: 0, margin: 0 }}>
              {data.recent_audit.map((entry) => (
                <li key={entry.id}>
                  <Badge tone="info">{entry.action}</Badge> <span>{entry.summary}</span>{" "}
                  <span className="muted small">
                    {entry.actor || "system"} · {formatDateTime(entry.created_at, locale)}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="muted">{t("admin.noAudit")}</p>
          )}
        </Card>
      </div>
    </div>
  );
}
