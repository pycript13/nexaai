import React, { useState } from "react";
import { api } from "../../api/client";
import { Badge, Button, Card, ConfirmCheckbox, Field, Spinner, useApi } from "../../components/ui";
import { formatCredits, formatDateTime } from "../../utils/format";
import { useApp } from "../../state/app";

interface Campaign {
  id: number;
  title: string;
  kind: string;
  cadence: string;
  amount_micro: number;
  amount_credits: number;
  target_type: string;
  target_ref: Record<string, unknown>;
  reason: string;
  active: boolean;
  next_run_at: string | null;
  last_run_at: string | null;
  runs_count: number;
  total_granted_micro: number;
  total_recipients: number;
  created_at: string | null;
}

const CADENCE_FA: Record<string, string> = {
  once: "یک‌باره (پاداش)",
  daily: "روزانه",
  weekly: "هفتگی",
  monthly: "ماهانه",
};
const TARGET_FA: Record<string, string> = {
  all: "همهٔ کاربران فعال",
  role: "گروه (نقش)",
  plan: "مشترکان یک پلن",
  users: "کاربران مشخص",
  user: "یک کاربر",
};

export function AdminGrants(): JSX.Element {
  const { notify } = useApp();
  const campaigns = useApi<{ items: Campaign[] }>(() => api.get("/api/v1/admin/billing/grant-campaigns"), []);
  const [form, setForm] = useState({
    title: "",
    cadence: "once",
    amount_credits: "10",
    target_type: "all",
    role: "user",
    plan_id: "",
    user_ids: "",
    reason: "",
  });
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const targetRef = (): Record<string, unknown> => {
    if (form.target_type === "role") return { role: form.role.trim() };
    if (form.target_type === "plan") return { plan_id: Number(form.plan_id) };
    if (form.target_type === "users")
      return { user_ids: form.user_ids.split(/[,\s]+/).filter(Boolean).map((x) => Number(x)).filter((n) => n > 0) };
    return {};
  };

  const create = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const response = await api.post<{ campaign: Campaign }>("/api/v1/admin/billing/grant-campaigns", {
        title: form.title || "هدیهٔ کردیت",
        cadence: form.cadence,
        amount_credits: Number(form.amount_credits),
        target_type: form.target_type,
        target_ref: targetRef(),
        reason: form.reason,
        confirm: true,
      });
      const c = response.campaign;
      notify(
        "success",
        form.cadence === "once"
          ? `پاداش پرداخت شد: ${formatCredits(c.total_granted_micro)} به ${c.total_recipients} کاربر`
          : "کمپین دوره‌ای ساخته و اولین دوره پرداخت شد",
      );
      setForm({ ...form, title: "", reason: "" });
      setConfirmed(false);
      campaigns.reload();
    } catch (caught) {
      setError((caught as Error)?.message || "خطا در ساخت کمپین");
    } finally {
      setBusy(false);
    }
  };

  const act = async (campaign: Campaign, action: "run" | "toggle") => {
    setBusy(true);
    try {
      if (action === "run") {
        const r = await api.post<{ run: { recipients: number; granted_micro: number } }>(
          `/api/v1/admin/billing/grant-campaigns/${campaign.id}/run-now`,
          { confirm: true },
        );
        notify("success", `پرداخت شد: ${formatCredits(r.run.granted_micro)} به ${r.run.recipients} کاربر`);
      } else {
        await api.patch(`/api/v1/admin/billing/grant-campaigns/${campaign.id}`, {
          active: !campaign.active,
          confirm: true,
        });
        notify("success", campaign.active ? "کمپین متوقف شد" : "کمپین فعال شد");
      }
      campaigns.reload();
    } catch (caught) {
      notify("error", (caught as Error)?.message || "خطا");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="page">
      <header className="page__head">
        <div>
          <h1>🎁 کمپین‌های کردیت و پاداش</h1>
          <p className="muted">
            پاداش یک‌باره به مناسبت‌ها، یا اعتبار دوره‌ای روزانه/هفتگی/ماهانه — برای همه، یک گروه (نقش)، مشترکان یک
            پلن، یا کاربران مشخص. هر پرداخت در دفترکل ثبت و هر دوره فقط یک‌بار اجرا می‌شود.
          </p>
        </div>
      </header>

      <Card title="کمپین جدید" icon="gift">
        <form className="form-grid" onSubmit={create}>
          <Field label="عنوان">
            <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="مثلاً: پاداش نوروز" />
          </Field>
          <Field label="نوع">
            <select value={form.cadence} onChange={(e) => setForm({ ...form, cadence: e.target.value })}>
              {Object.entries(CADENCE_FA).map(([value, label]) => (
                <option key={value} value={value}>{label}</option>
              ))}
            </select>
          </Field>
          <Field label="مبلغ برای هر کاربر (کردیت)">
            <input type="number" min="0" step="any" value={form.amount_credits}
              onChange={(e) => setForm({ ...form, amount_credits: e.target.value })} required />
          </Field>
          <Field label="گیرندگان">
            <select value={form.target_type} onChange={(e) => setForm({ ...form, target_type: e.target.value })}>
              {Object.entries(TARGET_FA).map(([value, label]) => (
                <option key={value} value={value}>{label}</option>
              ))}
            </select>
          </Field>
          {form.target_type === "role" && (
            <Field label="نام نقش (گروه)">
              <input value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} dir="ltr" placeholder="user" />
            </Field>
          )}
          {form.target_type === "plan" && (
            <Field label="شناسهٔ پلن">
              <input type="number" value={form.plan_id} onChange={(e) => setForm({ ...form, plan_id: e.target.value })} dir="ltr" />
            </Field>
          )}
          {form.target_type === "users" && (
            <Field label="شناسهٔ کاربران (با کاما جدا کنید)">
              <input value={form.user_ids} onChange={(e) => setForm({ ...form, user_ids: e.target.value })} dir="ltr" placeholder="12, 15, 20" />
            </Field>
          )}
          <Field label="دلیل / مناسبت (در دفترکل کاربر دیده می‌شود)">
            <input value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} placeholder="مثلاً: هدیهٔ نوروز 🌸" />
          </Field>
          <ConfirmCheckbox checked={confirmed} onChange={setConfirmed}
            label="مطمئنم — این کردیت واقعی به حساب کاربران واریز می‌شود" />
          {error ? <p className="alert alert--danger small">{error}</p> : null}
          <div className="row">
            <Button type="submit" disabled={!confirmed || busy}>
              {form.cadence === "once" ? "پرداخت پاداش" : "ساخت کمپین دوره‌ای"}
            </Button>
            {busy ? <Spinner /> : null}
          </div>
        </form>
      </Card>

      <Card title="کمپین‌ها" icon="list">
        {campaigns.loading ? <Spinner /> : null}
        {!campaigns.loading && !(campaigns.data?.items || []).length ? (
          <p className="muted">هنوز کمپینی ساخته نشده است.</p>
        ) : null}
        <div className="stack">
          {(campaigns.data?.items || []).map((campaign) => (
            <div key={campaign.id} className="variant-item">
              <div className="variant-item__head">
                <div className="variant-item__title">
                  <strong>{campaign.title}</strong>
                  <span className="muted small">
                    {CADENCE_FA[campaign.cadence]} · {formatCredits(campaign.amount_micro)} برای هر نفر · {TARGET_FA[campaign.target_type]}
                  </span>
                </div>
                <Badge tone={campaign.active ? "success" : "muted"}>{campaign.active ? "فعال" : "تمام‌شده/متوقف"}</Badge>
              </div>
              <div className="variant-item__meta">
                <span>دوره‌های اجرا: <strong>{campaign.runs_count}</strong></span>
                <span>مجموع پرداخت: <strong>{formatCredits(campaign.total_granted_micro)}</strong> به {campaign.total_recipients} نفر</span>
                {campaign.next_run_at ? <span>اجرای بعدی: {formatDateTime(campaign.next_run_at)}</span> : null}
                {campaign.last_run_at ? <span>آخرین اجرا: {formatDateTime(campaign.last_run_at)}</span> : null}
              </div>
              {campaign.reason ? <p className="small muted">{campaign.reason}</p> : null}
              <div className="row">
                <Button variant="ghost" type="button" disabled={busy} onClick={() => act(campaign, "run")}>
                  اجرای همین حالا
                </Button>
                {campaign.cadence !== "once" ? (
                  <Button variant="ghost" type="button" disabled={busy} onClick={() => act(campaign, "toggle")}>
                    {campaign.active ? "توقف" : "فعال‌سازی"}
                  </Button>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
