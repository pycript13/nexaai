import React, { useEffect, useMemo, useState } from "react";
import { api } from "../../api/client";
import type { AdminModelRecord, Pagination as PaginationMeta } from "../../api/types";
import { Badge, Button, Card, ConfirmCheckbox, DataTable, ErrorNotice, Field, Modal, Pagination, Spinner, StatusBadge, useApi } from "../../components/ui";
import { formatCredits, formatDateTime } from "../../utils/format";
import { useApp, useI18n } from "../../state/app";
import { AdminVariantBoard } from "../../components/variants";
import { useSearchParams } from "react-router-dom";
import type { TranslationKey } from "../../locales";

const OPERATIONS = [
  "chat",
  "streaming",
  "embeddings",
  "image_generation",
  "image_understanding",
  "audio_transcription",
  "speech_generation",
  "video_generation",
  "rerank",
  "document_understanding",
];

/**
 * The catalogue values stay English (they are the exact identifiers the API stores and the
 * gateway enforces); only their *labels* are translated, so an operator sees Persian while the
 * request stays machine-readable.
 */
const VISIBILITY_LABEL: Record<string, TranslationKey> = {
  public: "option.visibility.public",
  paid: "option.visibility.paid",
  subscription: "option.visibility.subscription",
  restricted: "option.visibility.restricted",
  internal: "option.visibility.internal",
  hidden: "option.visibility.hidden",
  archived: "option.visibility.archived",
};
const TIER_LABEL: Record<string, TranslationKey> = {
  free: "option.tier.free",
  credit: "option.tier.credit",
  subscription: "option.tier.subscription",
  restricted: "option.tier.restricted",
  internal: "option.tier.internal",
};
const AVAILABILITY_LABEL: Record<string, TranslationKey> = {
  untested: "option.availability.untested",
  available: "option.availability.available",
  degraded: "option.availability.degraded",
  disabled: "option.availability.disabled",
};

/** The fields whose change is a commercial/state decision (money or reach), not a label edit. */
const SENSITIVE_FIELDS = [
  "visibility",
  "access_tier",
  "availability",
  "published",
  "enabled",
  "capabilities",
  "selling_input_per_mtok",
  "selling_output_per_mtok",
  "selling_per_request",
  "selling_per_image",
  "selling_per_audio_minute",
];

interface EditForm {
  display_name: string;
  description: string;
  sort_order: string;
  capabilities: string[];
  visibility: string;
  access_tier: string;
  availability: string;
  published: boolean;
  enabled: boolean;
  selling_input_per_mtok: string;
  selling_output_per_mtok: string;
  selling_per_request: string;
  selling_per_image: string;
  selling_per_audio_minute: string;
}

function editFormFrom(model: AdminModelRecord): EditForm {
  return {
    display_name: String(model.display_name ?? ""),
    description: String(model.description ?? ""),
    sort_order: model.sort_order === null || model.sort_order === undefined ? "" : String(model.sort_order),
    capabilities: [...(model.capabilities || [])],
    visibility: String(model.visibility ?? "hidden"),
    access_tier: String(model.access_tier ?? "credit"),
    availability: String(model.availability ?? "untested"),
    published: Boolean(model.published),
    enabled: Boolean(model.enabled),
    selling_input_per_mtok: numeric(model.selling_input_per_mtok),
    selling_output_per_mtok: numeric(model.selling_output_per_mtok),
    selling_per_request: numeric(model.selling_per_request),
    selling_per_image: numeric(model.selling_per_image),
    selling_per_audio_minute: numeric(model.selling_per_audio_minute),
  };
}

/** Prices arrive as numbers or as decimal strings; an empty box means "no price of this kind". */
function numeric(value: unknown): string {
  if (value === null || value === undefined || value === "") return "";
  return String(value);
}

/** Only what actually changed is sent, so a save never rewrites a field the operator did not touch. */
function buildPatch(original: EditForm, current: EditForm): Record<string, unknown> {
  const patch: Record<string, unknown> = {};
  if (current.display_name !== original.display_name) patch.display_name = current.display_name;
  if (current.description !== original.description) patch.description = current.description;
  if (current.sort_order.trim() !== original.sort_order.trim()) {
    patch.sort_order = current.sort_order.trim() === "" ? null : Number(current.sort_order);
  }
  if ([...current.capabilities].sort().join(",") !== [...original.capabilities].sort().join(",")) {
    patch.capabilities = current.capabilities;
  }
  if (current.visibility !== original.visibility) patch.visibility = current.visibility;
  if (current.access_tier !== original.access_tier) patch.access_tier = current.access_tier;
  if (current.availability !== original.availability) patch.availability = current.availability;
  if (current.published !== original.published) patch.published = current.published;
  if (current.enabled !== original.enabled) patch.enabled = current.enabled;
  for (const key of [
    "selling_input_per_mtok",
    "selling_output_per_mtok",
    "selling_per_request",
    "selling_per_image",
    "selling_per_audio_minute",
  ] as const) {
    const before = original[key].trim();
    const after = current[key].trim();
    if (before !== after) patch[key] = after === "" ? null : Number(after);
  }
  return patch;
}

export function AdminModels(): JSX.Element {
  const { t, locale } = useI18n();
  const { notify, hasPermission } = useApp();
  const [page, setPage] = useState(1);
  // Filters can arrive in the URL (e.g. the provider page links to ?published=false after a sync)
  const [searchParams] = useSearchParams();
  const [filters, setFilters] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {};
    for (const key of ["published", "visibility", "availability", "search", "provider_id"]) {
      const value = searchParams.get(key);
      if (value) initial[key] = value;
    }
    return initial;
  });
  const models = useApi<{ items: AdminModelRecord[]; pagination: PaginationMeta; counts?: Record<string, number> }>(
    () => api.get("/api/v1/admin/models", { page, page_size: 20, ...filters }),
    [page, JSON.stringify(filters)],
  );
  const providers = useApi<{ items: { id: number; name: string; enabled: boolean }[] }>(() => api.get("/api/v1/admin/providers"), []);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({
    provider_id: "",
    provider_model_id: "",
    display_name: "",
    capabilities: ["chat"] as string[],
    visibility: "hidden",
    access_tier: "credit",
    input_price: "3",
    output_price: "15",
  });
  const [selected, setSelected] = useState<AdminModelRecord | null>(null);
  const [editForm, setEditForm] = useState<EditForm | null>(null);
  const [testForm, setTestForm] = useState({ operation: "chat", input: "Reply with the single word: pong" });
  const [testResult, setTestResult] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [confirmed, setConfirmed] = useState(false);
  const [saveNotice, setSaveNotice] = useState<string | null>(null);

  const openEditor = (row: AdminModelRecord) => {
    setSelected(row);
    setEditForm(editFormFrom(row));
    setTestResult(null);
    setError(null);
    setConfirmed(false);
    setSaveNotice(null);
  };

  const closeEditor = () => {
    setSelected(null);
    setEditForm(null);
    setTestResult(null);
    setError(null);
    setConfirmed(false);
    setSaveNotice(null);
  };

  /** The pending change, as it will be sent (empty object → nothing to save). */
  const pendingPatch = useMemo(() => {
    if (!selected || !editForm) return {} as Record<string, unknown>;
    return buildPatch(editFormFrom(selected), editForm);
  }, [selected, editForm]);
  const pendingKeys = Object.keys(pendingPatch);
  const touchesSensitive = pendingKeys.some((key) => SENSITIVE_FIELDS.includes(key));
  const needsConfirm = touchesSensitive && !confirmed;

  const createModel = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.post("/api/v1/admin/models", {
        provider_id: Number(form.provider_id),
        provider_model_id: form.provider_model_id,
        display_name: form.display_name,
        capabilities: form.capabilities,
        visibility: form.visibility,
        access_tier: form.access_tier,
        published: false,
        selling_input_per_mtok: form.input_price ? Number(form.input_price) : undefined,
        selling_output_per_mtok: form.output_price ? Number(form.output_price) : undefined,
      });
      notify("success", t("admin.models.createdNote"));
      setCreating(false);
      models.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const runTest = async () => {
    if (!selected) return;
    setBusy(true);
    setError(null);
    setTestResult(null);
    try {
      const result = await api.post(`/api/v1/admin/models/${selected.id}/test`, {
        operation: testForm.operation,
        input: testForm.input,
      });
      setTestResult(result);
      notify("success", t("admin.models.testDone"));
      models.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  /**
   * The single save path of the dialog: send exactly the changed fields, then re-read the model so
   * the screen shows what the server stored (never a local guess).
   */
  const saveModel = async () => {
    if (!selected || !editForm) return;
    if (!pendingKeys.length) {
      closeEditor();
      return;
    }
    if (needsConfirm) {
      // The gate stays — but a disabled button that never says why is what made the dialog feel
      // broken, so the click explains itself instead.
      setSaveNotice(t("admin.saveNeedsConfirm"));
      return;
    }
    setBusy(true);
    setError(null);
    setSaveNotice(null);
    try {
      await api.patch(`/api/v1/admin/models/${selected.id}`, { ...pendingPatch, confirm: true });
      notify("success", t("admin.models.savedNote"));
      models.reload();
      const refreshed = await api.get<{ model: AdminModelRecord }>(`/api/v1/admin/models/${selected.id}`);
      setSelected(refreshed.model);
      setEditForm(editFormFrom(refreshed.model));
      setConfirmed(false);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (models.loading && !models.data) return <Spinner />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.models")}</h1>
          <p>{t("admin.models.subtitle")}</p>
        </div>
        <div className="row">
          <Button type="button" onClick={() => setCreating(true)}>
            {t("admin.models.add")}
          </Button>
          <Button variant="subtle" type="button" onClick={models.reload}>
            {t("action.refresh")}
          </Button>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}

      <Card title={t("action.filter")}>
        <div className="grid grid--4">
          <Field label={t("action.search")}>
            <input value={filters.search || ""} onChange={(event) => { setPage(1); setFilters({ ...filters, search: event.target.value }); }} />
          </Field>
          <Field label={t("label.visibility")}>
            <select value={filters.visibility || ""} onChange={(event) => { setPage(1); setFilters({ ...filters, visibility: event.target.value }); }}>
              <option value="">{t("common.all")}</option>
              {Object.keys(VISIBILITY_LABEL).map((value) => (
                <option key={value} value={value}>{t(VISIBILITY_LABEL[value])}</option>
              ))}
            </select>
          </Field>
          <Field label={t("label.availability")}>
            <select value={filters.availability || ""} onChange={(event) => { setPage(1); setFilters({ ...filters, availability: event.target.value }); }}>
              <option value="">{t("common.all")}</option>
              {Object.keys(AVAILABILITY_LABEL).map((value) => (
                <option key={value} value={value}>{t(AVAILABILITY_LABEL[value])}</option>
              ))}
            </select>
          </Field>
          <Field label={t("label.published")}>
            <select value={filters.published || ""} onChange={(event) => { setPage(1); setFilters({ ...filters, published: event.target.value }); }}>
              <option value="">{t("common.all")}</option>
              <option value="true">{t("option.published.yes")}</option>
              <option value="false">{t("option.published.no")}</option>
            </select>
          </Field>
        </div>
      </Card>

      <Card title={t("nav.admin.models")}>
        <DataTable
          rows={models.data?.items || []}
          columns={[
            { key: "name", header: t("label.model"), render: (row) => String(row.display_name) },
            { key: "id", header: t("label.providerModelId"), render: (row) => <span className="mono">{String(row.provider_model_id)}</span> },
            { key: "visibility", header: t("label.visibility"), render: (row) => <Badge tone={row.visibility === "public" ? "success" : "neutral"}>{t(VISIBILITY_LABEL[String(row.visibility)] || "option.visibility.hidden")}</Badge> },
            { key: "published", header: t("label.published"), render: (row) => <StatusBadge value={row.published ? "published" : "hidden"} /> },
            { key: "tier", header: t("label.tier"), render: (row) => <Badge tone="info">{t(TIER_LABEL[String(row.access_tier)] || "option.tier.credit")}</Badge> },
            { key: "availability", header: t("label.availability"), render: (row) => <StatusBadge value={row.availability} /> },
            { key: "test", header: t("label.lastTest"), render: (row) => <StatusBadge value={row.last_test_status || "untested"} /> },
            { key: "capabilities", header: t("label.capabilities"), render: (row) => (row.capabilities || []).slice(0, 3).join(", ") },
            {
              key: "actions",
              header: t("label.actions"),
              render: (row) => (
                <Button variant="ghost" type="button" onClick={() => openEditor(row)}>
                  {t("action.edit")}
                </Button>
              ),
            },
          ]}
        />
        <Pagination meta={models.data?.pagination} onChange={setPage} />
      </Card>

      <Modal
        open={creating}
        wide
        title={t("admin.models.addTitle")}
        onClose={() => setCreating(false)}
        footer={
          <>
            <Button variant="subtle" type="button" onClick={() => setCreating(false)} disabled={busy}>
              {t("action.cancel")}
            </Button>
            <Button type="submit" form="model-create" loading={busy} disabled={busy}>
              {t("action.create")}
            </Button>
          </>
        }
      >
        <form id="model-create" onSubmit={createModel}>
          <Field label={t("label.provider")}>
            <select value={form.provider_id} onChange={(event) => setForm({ ...form, provider_id: event.target.value })} required>
              <option value="">—</option>
              {(providers.data?.items || []).map((provider) => (
                <option key={provider.id} value={provider.id}>
                  {provider.name} {provider.enabled ? "" : t("admin.providerDisabledSuffix")}
                </option>
              ))}
            </select>
          </Field>
          <Field label={t("label.providerModelId")} hint={t("admin.models.providerIdHint")}>
            <input value={form.provider_model_id} onChange={(event) => setForm({ ...form, provider_model_id: event.target.value })} dir="ltr" required />
          </Field>
          <Field label={t("label.displayName")}>
            <input value={form.display_name} onChange={(event) => setForm({ ...form, display_name: event.target.value })} required />
          </Field>
          <Field label={t("label.capabilities")} hint={t("admin.capabilitiesHint")}>
            <div className="grid grid--3">
              {OPERATIONS.map((operation) => (
                <label key={operation} className="checkbox">
                  <input
                    type="checkbox"
                    checked={form.capabilities.includes(operation)}
                    onChange={(event) =>
                      setForm((current) => ({
                        ...current,
                        capabilities: event.target.checked
                          ? [...current.capabilities, operation]
                          : current.capabilities.filter((item) => item !== operation),
                      }))
                    }
                  />
                  <span className="mono">{operation}</span>
                </label>
              ))}
            </div>
          </Field>
          <div className="grid grid--3">
            <Field label={t("label.visibility")}>
              <select value={form.visibility} onChange={(event) => setForm({ ...form, visibility: event.target.value })}>
                {Object.keys(VISIBILITY_LABEL).map((value) => (
                  <option key={value} value={value}>{t(VISIBILITY_LABEL[value])}</option>
                ))}
              </select>
            </Field>
            <Field label={t("label.tier")}>
              <select value={form.access_tier} onChange={(event) => setForm({ ...form, access_tier: event.target.value })}>
                {Object.keys(TIER_LABEL).map((value) => (
                  <option key={value} value={value}>{t(TIER_LABEL[value])}</option>
                ))}
              </select>
            </Field>
            <Field label={t("label.inputPricePerMtok")}>
              <input type="number" step="0.01" value={form.input_price} onChange={(event) => setForm({ ...form, input_price: event.target.value })} />
            </Field>
          </div>
          <Field label={t("label.outputPricePerMtok")}>
            <input type="number" step="0.01" value={form.output_price} onChange={(event) => setForm({ ...form, output_price: event.target.value })} />
          </Field>
        </form>
      </Modal>

      <Modal
        open={Boolean(selected)}
        wide
        title={selected ? String(selected.display_name) : ""}
        onClose={closeEditor}
        footer={
          <>
            <Button variant="subtle" type="button" onClick={closeEditor} disabled={busy}>
              {t("action.cancel")}
            </Button>
            <Button type="button" onClick={saveModel} loading={busy} disabled={busy || !pendingKeys.length}>
              {t("action.save")}
            </Button>
          </>
        }
      >
        {selected && editForm && (
          <div className="stack">
            <div className="row row--between" style={{ gap: "0.6rem", flexWrap: "wrap" }}>
              <ConfirmCheckbox
                checked={confirmed}
                onChange={(value) => {
                  setConfirmed(value);
                  if (value) setSaveNotice(null);
                }}
                label={t("admin.confirmSensitive")}
              />
              <span className="muted small">
                {pendingKeys.length
                  ? t("admin.models.unsavedCount").replace("{count}", String(pendingKeys.length))
                  : t("admin.models.noChanges")}
              </span>
            </div>
            {saveNotice ? (
              <p className="field__error" role="alert">
                {saveNotice}
              </p>
            ) : null}

            <div className="alert alert--success">
              <div>
                <strong>{t("admin.models.ownerNote")}</strong>
                <p>{t("admin.impersonationNote")}</p>
              </div>
            </div>

            <Card title={t("admin.lifecycle")} subtitle={t("admin.lifecycleNote")}>
              <div className="grid grid--3">
                <Field label={t("label.visibility")}>
                  <select
                    value={editForm.visibility}
                    onChange={(event) => setEditForm({ ...editForm, visibility: event.target.value })}
                    disabled={busy}
                  >
                    {Object.keys(VISIBILITY_LABEL).map((value) => (
                      <option key={value} value={value}>{t(VISIBILITY_LABEL[value])}</option>
                    ))}
                  </select>
                </Field>
                <Field label={t("label.tier")}>
                  <select
                    value={editForm.access_tier}
                    onChange={(event) => setEditForm({ ...editForm, access_tier: event.target.value })}
                    disabled={busy}
                  >
                    {Object.keys(TIER_LABEL).map((value) => (
                      <option key={value} value={value}>{t(TIER_LABEL[value])}</option>
                    ))}
                  </select>
                </Field>
                <Field label={t("label.availability")}>
                  <select
                    value={editForm.availability}
                    onChange={(event) => setEditForm({ ...editForm, availability: event.target.value })}
                    disabled={busy}
                  >
                    {Object.keys(AVAILABILITY_LABEL).map((value) => (
                      <option key={value} value={value}>{t(AVAILABILITY_LABEL[value])}</option>
                    ))}
                  </select>
                </Field>
              </div>
              <div className="grid grid--2">
                <Field label={t("label.published")} hint={t("admin.publishHint")}>
                  <select
                    value={editForm.published ? "true" : "false"}
                    onChange={(event) => setEditForm({ ...editForm, published: event.target.value === "true" })}
                    disabled={busy || !hasPermission("models.publish")}
                  >
                    <option value="false">{t("option.published.no")}</option>
                    <option value="true">{t("option.published.yes")}</option>
                  </select>
                </Field>
                <Field label={t("label.enabled")} hint={t("admin.enabledHint")}>
                  <select
                    value={editForm.enabled ? "true" : "false"}
                    onChange={(event) => setEditForm({ ...editForm, enabled: event.target.value === "true" })}
                    disabled={busy}
                  >
                    <option value="true">{t("common.yes")}</option>
                    <option value="false">{t("common.no")}</option>
                  </select>
                </Field>
              </div>
            </Card>

            <Card title={t("admin.basicsTitle")} subtitle={t("admin.basicsNote")}>
              <div className="grid grid--3">
                <Field label={t("label.displayName")}>
                  <input
                    value={editForm.display_name}
                    onChange={(event) => setEditForm({ ...editForm, display_name: event.target.value })}
                    disabled={busy}
                  />
                </Field>
                <Field label={t("label.sortOrder")} hint={t("admin.sortOrderHint")}>
                  <input
                    type="number"
                    value={editForm.sort_order}
                    onChange={(event) => setEditForm({ ...editForm, sort_order: event.target.value })}
                    disabled={busy}
                  />
                </Field>
                <Field label={t("label.providerModelId")} hint={t("admin.providerIdLockedHint")}>
                  <input value={String(selected.provider_model_id)} dir="ltr" readOnly disabled />
                </Field>
              </div>
              <Field label={t("label.description")}>
                <textarea
                  value={editForm.description}
                  onChange={(event) => setEditForm({ ...editForm, description: event.target.value })}
                  disabled={busy}
                />
              </Field>
              <Field label={t("label.capabilities")} hint={t("admin.capabilitiesHint")}>
                <div className="grid grid--3">
                  {OPERATIONS.map((operation) => (
                    <label key={operation} className="checkbox">
                      <input
                        type="checkbox"
                        checked={editForm.capabilities.includes(operation)}
                        onChange={(event) =>
                          setEditForm((current) =>
                            current
                              ? {
                                  ...current,
                                  capabilities: event.target.checked
                                    ? [...current.capabilities, operation]
                                    : current.capabilities.filter((item) => item !== operation),
                                }
                              : current,
                          )
                        }
                        disabled={busy}
                      />
                      <span className="mono">{operation}</span>
                    </label>
                  ))}
                </div>
              </Field>
            </Card>

            <Card title={t("admin.pricesTitle")} subtitle={t("admin.pricesNote")}>
              <div className="grid grid--3">
                <Field label={t("label.inputPricePerMtok")}>
                  <input
                    type="number"
                    step="0.01"
                    value={editForm.selling_input_per_mtok}
                    onChange={(event) => setEditForm({ ...editForm, selling_input_per_mtok: event.target.value })}
                    disabled={busy}
                  />
                </Field>
                <Field label={t("label.outputPricePerMtok")}>
                  <input
                    type="number"
                    step="0.01"
                    value={editForm.selling_output_per_mtok}
                    onChange={(event) => setEditForm({ ...editForm, selling_output_per_mtok: event.target.value })}
                    disabled={busy}
                  />
                </Field>
                <Field label={t("label.perRequestCredits")}>
                  <input
                    type="number"
                    step="0.01"
                    value={editForm.selling_per_request}
                    onChange={(event) => setEditForm({ ...editForm, selling_per_request: event.target.value })}
                    disabled={busy}
                  />
                </Field>
                <Field label={t("label.perImageCredits")}>
                  <input
                    type="number"
                    step="0.01"
                    value={editForm.selling_per_image}
                    onChange={(event) => setEditForm({ ...editForm, selling_per_image: event.target.value })}
                    disabled={busy}
                  />
                </Field>
                <Field label={t("label.perAudioMinuteCredits")}>
                  <input
                    type="number"
                    step="0.01"
                    value={editForm.selling_per_audio_minute}
                    onChange={(event) => setEditForm({ ...editForm, selling_per_audio_minute: event.target.value })}
                    disabled={busy}
                  />
                </Field>
              </div>
              <p className="muted small">{t("admin.pricesNote")}</p>
            </Card>

            <Card title={t("admin.administrativeTest")} subtitle={t("admin.testCardNote")}>
              <div className="grid grid--3">
                <Field label={t("label.operation")}>
                  <select value={testForm.operation} onChange={(event) => setTestForm({ ...testForm, operation: event.target.value })}>
                    {OPERATIONS.map((operation) => (
                      <option key={operation} value={operation}>{operation}</option>
                    ))}
                  </select>
                </Field>
                <Field label={t("label.input")}>
                  <textarea value={testForm.input} onChange={(event) => setTestForm({ ...testForm, input: event.target.value })} />
                </Field>
                <div style={{ alignSelf: "end" }}>
                  <Button type="button" onClick={runTest} loading={busy} disabled={!hasPermission("models.test")}>
                    {t("action.test")}
                  </Button>
                </div>
              </div>
              {testResult && (
                <div className="stack">
                  <div className="row">
                    <Badge tone={testResult.test?.status === "ok" ? "success" : "danger"}>{testResult.test?.status}</Badge>
                    <span className="muted small">
                      {t("admin.chargedToPlatform")} {formatCredits(testResult.test?.cost_micro ?? 0)} ·{" "}
                      {t("admin.billedToUser")}: {String(testResult.test?.billed_to_user ?? false)}
                    </span>
                  </div>
                  <pre className="md__code">{JSON.stringify(testResult, null, 2).slice(0, 6000)}</pre>
                </div>
              )}
            </Card>

            <Card title={t("admin.testHistory")} subtitle={t("admin.testHistoryNote")}>
              <ModelTests modelId={selected.id} />
            </Card>

            <Card title={t("label.detail")}>
              <div className="kv">
                <div>
                  <span>{t("label.updated")}</span>
                  <span>{formatDateTime(String(selected.updated_at || ""), locale)}</span>
                </div>
                <div>
                  <span>{t("label.published")}</span>
                  <span>{selected.published ? t("common.yes") : t("common.no")}</span>
                </div>
                <div>
                  <span>{t("label.enabled")}</span>
                  <span>{selected.enabled ? t("common.yes") : t("common.no")}</span>
                </div>
                <div>
                  <span>{t("label.providerModelId")}</span>
                  <span className="mono">{String(selected.provider_model_id)}</span>
                </div>
              </div>
            </Card>
          </div>
        )}
      </Modal>

      <AdminVariantBoard />
    </div>
  );
}

function ModelTests({ modelId }: { modelId: number }): JSX.Element {
  const { t, locale } = useI18n();
  const tests = useApi<{ items: any[] }>(() => api.get(`/api/v1/admin/models/${modelId}/tests`), [modelId]);
  if (tests.loading) return <Spinner />;
  return (
    <DataTable
      rows={tests.data?.items || []}
      empty={<p className="muted">{t("admin.noTests")}</p>}
      columns={[
        { key: "created", header: t("label.when"), render: (row) => formatDateTime(row.created_at, locale) },
        { key: "operation", header: t("label.operation"), render: (row) => <span className="mono">{row.operation}</span> },
        { key: "status", header: t("label.status"), render: (row) => <StatusBadge value={row.status} /> },
        { key: "bypass", header: t("label.bypassedRules"), render: (row) => (row.bypassed_user_restrictions ? t("common.yes") : t("common.no")) },
        { key: "cost", header: t("label.platformCost"), render: (row) => formatCredits(row.cost_micro || 0) },
        { key: "summary", header: t("label.summary"), render: (row) => row.response_summary || row.error_message || "—" },
      ]}
    />
  );
}
