import { useState } from "react";
import { api } from "../../api/client";
import { Badge, Button, Card, ConfirmCheckbox, ErrorNotice, Field, Spinner, useApi } from "../../components/ui";
import { useApp, useI18n } from "../../state/app";
import { TelegramAdminCard } from "../../components/telegram-admin";
import { RegistrationPolicyCard } from "../../components/registration-policy";

/** The API returns a flat list; the page groups it by `category` for display. */
interface SettingRow {
  key: string;
  value: unknown;
  category?: string | null;
  label?: string | null;
  description?: string | null;
  is_public?: boolean;
  is_secret?: boolean;
  has_value?: boolean;
  masked?: string;
  updated_at?: string | null;
}

export function AdminSettings(): JSX.Element {
  const { t } = useI18n();
  const { notify, hasPermission } = useApp();
  const settings = useApi<{ items: SettingRow[]; read_only_note: string; environment: Record<string, unknown> }>(
    () => api.get("/api/v1/admin/settings"),
    [],
  );
  const [edits, setEdits] = useState<Record<string, string>>({});
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const save = async (key: string) => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const raw = edits[key];
      let value: unknown = raw;
      if (raw === "true" || raw === "false") value = raw === "true";
      else if (raw !== "" && !Number.isNaN(Number(raw))) value = Number(raw);
      const response = await api.patch<{ message?: string; restart_required?: boolean }>(`/api/v1/admin/settings/${key}`, {
        value,
        confirm: confirmed,
      });
      setNotice(
        `${response.message || `${key} updated.`}${response.restart_required ? " A restart is required for the change to take effect." : ""}`,
      );
      notify("success", `${key} updated`);
      settings.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (settings.loading) return <Spinner />;
  if (settings.error) return <ErrorNotice error={settings.error} onRetry={settings.reload} />;

  const groups = Object.entries(
    (settings.data?.items || []).reduce<Record<string, SettingRow[]>>((accumulator, row) => {
      const key = row.category || "general";
      (accumulator[key] ||= []).push(row);
      return accumulator;
    }, {}),
  ).sort(([left], [right]) => left.localeCompare(right));

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.settings")}</h1>
          <p>{t("admin.settingsNote")}</p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      {notice && (
        <div className="alert alert--success">
          <div>
            <strong>{notice}</strong>
          </div>
        </div>
      )}
      <div className="alert alert--warning">
        <div>
          <strong>{t("admin.readOnlyConfig")}</strong>
          <p>{settings.data?.read_only_note}</p>
        </div>
      </div>

      {/* The consequence of this switch is who can get in at all, so it is a real control with the
          effective policy read back from the API — not a text box somebody has to guess at. */}
      <RegistrationPolicyCard />

      <ConfirmCheckbox checked={confirmed} onChange={setConfirmed} label={t("admin.confirmSensitive")} />

      {groups.length === 0 ? (
        <Card title={t("status.empty")}>
          <p className="muted">{t("status.empty")}</p>
        </Card>
      ) : (
        groups.map(([category, rows]) => (
          <Card
            key={category}
            icon="sliders"
            title={t(`settings.category.${category}` as never) === `settings.category.${category}`
              ? category
              : t(`settings.category.${category}` as never)}
            subtitle={t("admin.settingCount").replace("{count}", String(rows.length))}
          >
            <div className="grid grid--2">
              {rows.map((item) => {
                const editable = hasPermission("settings.manage") && !item.is_secret;
                const value = edits[item.key] ?? (typeof item.value === "object" ? JSON.stringify(item.value) : String(item.value ?? ""));
                return (
                  <div key={item.key} className="stack stack--tight">
                    <Field
                      label={item.label || item.key}
                      hint={item.is_secret ? t("admin.secretManagedElsewhere") : item.description || undefined}
                    >
                      {item.is_secret ? (
                        <div className="row">
                          <input readOnly dir="ltr" value={item.masked || "——"} />
                          <Badge tone={item.has_value ? "success" : "neutral"}>
                            {item.has_value ? t("admin.secretStored") : t("admin.secretEmpty")}
                          </Badge>
                        </div>
                      ) : (
                        <input
                          value={value}
                          onChange={(event) => setEdits({ ...edits, [item.key]: event.target.value })}
                          disabled={!editable}
                        />
                      )}
                    </Field>
                    <div className="row row--between">
                      <span className="muted small mono">{item.key}</span>
                      <div className="row">
                        {item.is_public ? (
                          <Badge tone="info">{t("admin.settingPublic")}</Badge>
                        ) : (
                          <Badge tone="neutral">{t("admin.settingAdminOnly")}</Badge>
                        )}
                        {item.is_secret ? (
                          <Badge tone="warning">{t("admin.settingSecret")}</Badge>
                        ) : (
                          <Button
                            variant="subtle"
                            type="button"
                            onClick={() => save(item.key)}
                            disabled={!confirmed || busy || !editable}
                          >
                            {t("action.save")}
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        ))
      )}

      <TelegramAdminCard />

      <Card title={t("admin.ui.environmentReadOnly")}>
        <div className="kv">
          {Object.entries(settings.data?.environment || {}).map(([key, value]) => (
            <div key={key}>
              <span>{key}</span>
              <span className="mono">{String(value)}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
