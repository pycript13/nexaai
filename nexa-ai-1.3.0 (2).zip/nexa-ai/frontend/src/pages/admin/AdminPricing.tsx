import { useState } from "react";
import { api } from "../../api/client";
import { Badge, Button, Card, ConfirmCheckbox, DataTable, ErrorNotice, Field, Spinner, useApi } from "../../components/ui";
import { MICRO, formatCredits, fromMicro, toMicro } from "../../utils/format";
import { useApp, useI18n } from "../../state/app";

interface PricingRule {
  id: number;
  scope: string;
  scope_ref_id: number | null;
  name?: string;
  currency: string;
  input_per_mtok_micro: number | null;
  output_per_mtok_micro: number | null;
  per_request_micro: number | null;
  per_image_micro: number | null;
  per_audio_minute_micro: number | null;
  minimum_charge_micro: number | null;
  markup_percent: number | null;
  version: number;
  active: boolean;
}

export function AdminPricing(): JSX.Element {
  const { t } = useI18n();
  const { notify } = useApp();
  // The API answers `{rules, unit_note, global_daily_spend_limit_micro, platform_spend_today_micro}`.
  // This page used to read `data.items`, so the rules table rendered empty without any error —
  // pinned now by backend/tests/test_ui_contracts.py::test_admin_pricing_rules_keep_their_shape.
  const rules = useApi<{
    rules?: PricingRule[];
    items?: PricingRule[];
    unit_note?: string;
    global_daily_spend_limit_micro?: number | null;
    platform_spend_today_micro?: number | null;
  }>(() => api.get("/api/v1/admin/billing/pricing"), []);
  const ruleRows = rules.data?.rules ?? rules.data?.items ?? [];
  const [editing, setEditing] = useState<PricingRule | null>(null);
  const [form, setForm] = useState<Record<string, string>>({});
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);

  /** Per-token columns are stored in micro-credits per 1M tokens but edited in credits. */
  const PER_TOKEN_KEYS = ["input_per_mtok_micro", "output_per_mtok_micro"];

  const open = (rule: PricingRule) => {
    setEditing(rule);
    setForm({
      input_per_mtok_micro: fromMicro(rule.input_per_mtok_micro),
      output_per_mtok_micro: fromMicro(rule.output_per_mtok_micro),
      per_request_micro: String(rule.per_request_micro ?? ""),
      per_image_micro: String(rule.per_image_micro ?? ""),
      per_audio_minute_micro: String(rule.per_audio_minute_micro ?? ""),
      minimum_charge_micro: String(rule.minimum_charge_micro ?? ""),
      markup_percent: String(rule.markup_percent ?? ""),
    });
    setConfirmed(false);
    setError(null);
  };

  const save = async () => {
    if (!editing) return;
    setBusy(true);
    setError(null);
    try {
      const payload: Record<string, number | null> = {};
      Object.entries(form).forEach(([key, value]) => {
        if (value === "") {
          payload[key] = null;
        } else if (PER_TOKEN_KEYS.includes(key)) {
          // the operator types credits per 1M tokens; the API stores micro-credits per 1M
          payload[key] = toMicro(Number(value));
        } else {
          payload[key] = Number(value);
        }
      });
      await api.patch(`/api/v1/admin/billing/pricing/${editing.id}`, { ...payload, confirm: confirmed });
      notify("success", "Pricing rule updated. A new version was recorded.");
      rules.reload();
      setEditing(null);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (rules.loading) return <Spinner />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.pricing")}</h1>
          <p>
            {t("admin.pricingNote")}
          </p>
          {rules.data?.unit_note ? <p className="muted small">{rules.data.unit_note}</p> : null}
          <p className="muted small">
            {t("admin.platformSpendToday")} {formatCredits(rules.data?.platform_spend_today_micro ?? 0)}{" "}
            {t("admin.creditsWord")}
            {(rules.data?.global_daily_spend_limit_micro ?? 0) > 0
              ? ` ${t("admin.ofAllowed")} ${formatCredits(rules.data?.global_daily_spend_limit_micro ?? 0)} ${t("admin.allowedWord")}`
              : ` ${t("admin.noDailyLimit")}`}
          </p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}

      <Card title={t("admin.pricingRules")}>
        <DataTable
          rows={ruleRows}
          columns={[
            { key: "scope", header: t("admin.colScope"), render: (row) => <Badge tone={row.scope === "global" ? "info" : "neutral"}>{row.scope}</Badge> },
            { key: "ref", header: t("admin.colReference"), render: (row) => row.scope_ref_id ?? "—" },
            { key: "input", header: t("admin.colInputPerMtok"), render: (row) => (row.input_per_mtok_micro === null ? "—" : formatCredits(row.input_per_mtok_micro)) },
            { key: "output", header: t("admin.colOutputPerMtok"), render: (row) => (row.output_per_mtok_micro === null ? "—" : formatCredits(row.output_per_mtok_micro)) },
            { key: "request", header: "Per request", render: (row) => (row.per_request_micro === null ? "—" : formatCredits(row.per_request_micro)) },
            { key: "image", header: "Per image", render: (row) => (row.per_image_micro === null ? "—" : formatCredits(row.per_image_micro)) },
            { key: "markup", header: "Markup %", render: (row) => row.markup_percent ?? "—" },
            { key: "version", header: "Version", render: (row) => row.version },
            { key: "active", header: t("label.status"), render: (row) => <Badge tone={row.active ? "success" : "warning"}>{row.active ? "active" : "inactive"}</Badge> },
            {
              key: "actions",
              header: t("label.actions"),
              render: (row) => (
                <Button variant="ghost" type="button" onClick={() => open(row)}>
                  {t("action.edit")}
                </Button>
              ),
            },
          ]}
        />
      </Card>

      {editing && (
        <Card
          title={`Edit rule #${editing.id} (${editing.scope})`}
          actions={
            <div className="row">
              <Button variant="ghost" type="button" onClick={() => setEditing(null)}>
                {t("action.cancel")}
              </Button>
              <Button type="button" onClick={save} loading={busy} disabled={!confirmed}>
                {t("action.save")}
              </Button>
            </div>
          }
        >
          <ConfirmCheckbox checked={confirmed} onChange={setConfirmed} label={t("admin.confirmSensitive")} />
          <div className="grid grid--3" style={{ marginTop: "0.6rem" }}>
            {Object.keys(form).map((key) => (
              <Field
                key={key}
                label={key}
                hint={
                  PER_TOKEN_KEYS.includes(key)
                    ? "credits per 1,000,000 tokens (e.g. 0.28)"
                    : key.endsWith("_micro")
                      ? `micro-credits (1 credit = ${MICRO.toLocaleString()})`
                      : undefined
                }
              >
                <input value={form[key]} onChange={(event) => setForm({ ...form, [key]: event.target.value })} dir="ltr" />
              </Field>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
