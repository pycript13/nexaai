import { useState } from "react";
import { api } from "../../api/client";
import type { Job, Pagination as PaginationMeta } from "../../api/types";
import { Badge, Button, Card, DataTable, ErrorNotice, Field, Pagination, Spinner, Stat, StatusBadge, useApi } from "../../components/ui";
import { formatCredits, formatDateTime } from "../../utils/format";
import { useApp, useI18n } from "../../state/app";

export function AdminJobs(): JSX.Element {
  const { t, locale } = useI18n();
  const { notify } = useApp();
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState("");
  const jobs = useApi<{ items: Job[]; pagination: PaginationMeta; queue: Record<string, number> }>(
    () => api.get("/api/v1/admin/jobs", { page, page_size: 20, status: status || undefined }),
    [page, status],
  );
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);

  const retry = async (jobId: number) => {
    setBusy(true);
    setError(null);
    try {
      await api.post(`/api/v1/admin/jobs/${jobId}/retry`, {});
      notify("success", `Job ${jobId} requeued`);
      jobs.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (jobs.loading && !jobs.data) return <Spinner />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.jobs")}</h1>
          <p>{t("admin.jobsNote")}</p>
        </div>
        <Button variant="subtle" type="button" onClick={jobs.reload}>
          {t("action.refresh")}
        </Button>
      </div>

      {error ? <ErrorNotice error={error} /> : null}

      <div className="grid grid--4">
        {Object.entries(jobs.data?.queue || {}).map(([key, value]) => (
          <Stat key={key} label={key} value={value} />
        ))}
      </div>

      <Card title={t("action.filter")}>
        <Field label={t("label.status")}>
          <select value={status} onChange={(event) => { setPage(1); setStatus(event.target.value); }}>
            <option value="">{t("common.all")}</option>
            <option value="pending">pending</option>
            <option value="running">running</option>
            <option value="succeeded">succeeded</option>
            <option value="failed">failed</option>
            <option value="cancelled">cancelled</option>
          </select>
        </Field>
      </Card>

      <Card title={t("jobs.queue")}>
        <DataTable
          rows={jobs.data?.items || []}
          loading={jobs.loading}
          columns={[
            { key: "id", header: "#", render: (row) => row.id },
            { key: "type", header: "Type", render: (row) => <span className="mono">{row.type}</span> },
            { key: "user", header: "User", render: (row) => row.user_id ?? "—" },
            { key: "status", header: t("label.status"), render: (row) => <StatusBadge value={row.status} /> },
            { key: "progress", header: "Progress", render: (row) => `${row.progress}%` },
            { key: "attempts", header: "Attempts", render: (row) => `${row.attempts}/${row.max_attempts ?? "?"}` },
            { key: "error", header: "Error", render: (row) => (row.error_category ? <Badge tone="danger">{row.error_category}</Badge> : "—") },
            { key: "charged", header: t("label.charged"), render: (row) => formatCredits(row.charged_micro || 0) },
            { key: "created", header: t("label.created"), render: (row) => formatDateTime(row.created_at, locale) },
            {
              key: "actions",
              header: t("label.actions"),
              render: (row) =>
                row.status === "failed" ? (
                  <Button variant="ghost" type="button" onClick={() => retry(row.id)} disabled={busy}>
                    {t("action.retry")}
                  </Button>
                ) : (
                  "—"
                ),
            },
          ]}
        />
        <Pagination meta={jobs.data?.pagination} onChange={setPage} />
      </Card>
    </div>
  );
}
