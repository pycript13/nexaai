import React, { useMemo, useState } from "react";
import { api } from "../../api/client";
import type { ProviderRecord } from "../../api/types";
import { Badge, Button, ErrorNotice, Modal, Spinner } from "../../components/ui";
import { useApp, useI18n } from "../../state/app";

export interface CatalogEntry {
  provider_model_id: string;
  display_name: string;
  description: string;
  context_window: number | null;
  price_input_per_mtok: number | null;
  price_output_per_mtok: number | null;
  is_free: boolean;
  tags: string[];
  imported: boolean;
  imported_model_id: number | null;
}

interface CatalogResponse {
  summary: Record<string, number>;
  entries: CatalogEntry[];
}

const FILTERS = ["all", "free", "paid", "vision", "tools", "reasoning", "coding", "new"] as const;

export function ProviderCatalog({ provider, onClose, onImported }: {
  provider: ProviderRecord;
  onClose: () => void;
  onImported: () => void;
}): JSX.Element {
  const { t } = useI18n();
  const { notify } = useApp();
  const [data, setData] = useState<CatalogResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("all");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [publish, setPublish] = useState(true);
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await api.get<CatalogResponse>(`/api/v1/admin/providers/${provider.id}/catalog`));
    } catch (caught) {
      setError(caught);
    } finally {
      setLoading(false);
    }
  }, [provider.id]);

  React.useEffect(() => { void load(); }, [load]);

  const visible = useMemo(() => {
    const needle = search.trim().toLowerCase();
    return (data?.entries || []).filter((entry) => {
      if (filter === "free" && !entry.is_free) return false;
      if (filter === "paid" && (entry.is_free || entry.price_input_per_mtok === null)) return false;
      if (filter === "new" && entry.imported) return false;
      if (!["all", "free", "paid", "new"].includes(filter) && !entry.tags.includes(filter)) return false;
      if (needle && !`${entry.display_name} ${entry.provider_model_id}`.toLowerCase().includes(needle)) return false;
      return true;
    });
  }, [data, search, filter]);

  const toggle = (id: string) => setSelected((current) => {
    const next = new Set(current);
    if (next.has(id)) next.delete(id); else next.add(id);
    return next;
  });

  const selectVisible = () => setSelected((current) => {
    const next = new Set(current);
    for (const entry of visible) if (!entry.imported) next.add(entry.provider_model_id);
    return next;
  });

  const doImport = async () => {
    setImporting(true);
    try {
      const res = await api.post<{ created: number; updated: number; message: string }>(
        `/api/v1/admin/providers/${provider.id}/catalog/import`,
        { provider_model_ids: [...selected], publish },
      );
      setResult(res.message);
      notify("success", res.message);
      setSelected(new Set());
      onImported();
      await load();
    } catch (caught) {
      setError(caught);
    } finally {
      setImporting(false);
    }
  };

  return (
    <Modal
      open
      wide
      title={`${t("admin.catalog.title")} — ${provider.name}`}
      onClose={onClose}
      footer={(
        <>
          <span className="muted small" style={{ marginInlineEnd: "auto" }}>
            {selected.size} {t("admin.catalog.selected")}
          </span>
          <label className="row small" style={{ gap: "0.4rem" }}>
            <input type="checkbox" checked={publish} onChange={(e) => setPublish(e.target.checked)} />
            {t("admin.catalog.publish")}
          </label>
          <Button variant="subtle" type="button" onClick={onClose}>{t("action.close")}</Button>
          <Button type="button" loading={importing} disabled={!selected.size || importing} onClick={doImport}>
            {t("admin.catalog.import")} ({selected.size})
          </Button>
        </>
      )}
    >
      {loading ? <Spinner /> : error ? <ErrorNotice error={error} onRetry={load} /> : (
        <div className="stack">
          <div className="pill-list">
            <Badge tone="info">{data?.summary.total ?? 0} {t("admin.catalog.total")}</Badge>
            <Badge tone="success">{data?.summary.free ?? 0} {t("admin.catalog.free")}</Badge>
            <Badge tone="neutral">{data?.summary.paid ?? 0} {t("admin.catalog.paid")}</Badge>
            <Badge tone="neutral">{data?.summary.vision ?? 0} vision</Badge>
            <Badge tone="neutral">{data?.summary.tools ?? 0} tools</Badge>
            <Badge tone="neutral">{data?.summary.reasoning ?? 0} reasoning</Badge>
            <Badge tone="neutral">{data?.summary.coding ?? 0} coding*</Badge>
            <Badge tone="warning">{data?.summary.already_imported ?? 0} {t("admin.catalog.imported")}</Badge>
          </div>
          <p className="muted small">{t("admin.catalog.hint")}</p>
          {result ? <p className="small"><Badge tone="success">{result}</Badge></p> : null}
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t("admin.catalog.search")}
            aria-label={t("admin.catalog.search")}
          />
          <div className="pill-list" role="group" aria-label={t("action.filter")}>
            {FILTERS.map((key) => (
              <button
                key={key}
                type="button"
                className={`chip${filter === key ? " chip--active" : ""}`}
                onClick={() => setFilter(key)}
              >
                {t(`admin.catalog.f_${key}`)}
              </button>
            ))}
            <Button variant="subtle" type="button" onClick={selectVisible} disabled={!visible.length}>
              {t("admin.catalog.selectVisible")}
            </Button>
            <Button variant="ghost" type="button" onClick={() => setSelected(new Set())} disabled={!selected.size}>
              {t("admin.catalog.clear")}
            </Button>
          </div>
          <div className="catalog-list">
            {visible.map((entry) => (
              <label key={entry.provider_model_id} className={`catalog-row${entry.imported ? " catalog-row--imported" : ""}`}>
                <input
                  type="checkbox"
                  checked={selected.has(entry.provider_model_id)}
                  disabled={entry.imported}
                  onChange={() => toggle(entry.provider_model_id)}
                />
                <span className="catalog-row__main">
                  <span className="catalog-row__name">{entry.display_name}</span>
                  <span className="mono small muted" dir="ltr">{entry.provider_model_id}</span>
                </span>
                <span className="pill-list">
                  {entry.is_free
                    ? <Badge tone="success">{t("admin.catalog.free")}</Badge>
                    : entry.price_input_per_mtok !== null
                      ? <Badge tone="neutral">${entry.price_input_per_mtok} / ${entry.price_output_per_mtok} · 1M</Badge>
                      : <Badge tone="warning">{t("admin.catalog.unpriced")}</Badge>}
                  {entry.tags.filter((tag) => !["free", "paid", "unpriced"].includes(tag)).map((tag) => (
                    <Badge key={tag} tone="info">{tag}{tag === "coding" ? "*" : ""}</Badge>
                  ))}
                  {entry.context_window ? <Badge tone="neutral">{Math.round(entry.context_window / 1000)}K ctx</Badge> : null}
                  {entry.imported ? <Badge tone="warning">{t("admin.catalog.imported")}</Badge> : null}
                </span>
              </label>
            ))}
            {!visible.length ? <p className="muted">{t("status.empty")}</p> : null}
          </div>
        </div>
      )}
    </Modal>
  );
}
