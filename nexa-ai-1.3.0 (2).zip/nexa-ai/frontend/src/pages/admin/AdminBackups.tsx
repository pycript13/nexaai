import { useState } from "react";
import { api } from "../../api/client";
import { Badge, Button, Card, ConfirmCheckbox, ErrorNotice, Field, Spinner, Stat, useApi } from "../../components/ui";
import { formatBytes, formatDateTime } from "../../utils/format";
import { useApp, useI18n } from "../../state/app";

interface BackupRecord {
  /** The file name — the inventory endpoint reports files, so that is the identity. */
  id: string;
  filename: string;
  size_bytes: number;
  status: string;
  created_at: string;
  verified?: boolean;
  verified_at?: string | null;
  sha256?: string | null;
  notes?: string | null;
}

export function AdminBackups(): JSX.Element {
  const { t, locale } = useI18n();
  const { notify } = useApp();
  const backups = useApi<{ items: BackupRecord[]; directory: string; last_verified?: string | null; restore_note?: string }>(
    // Read-only inventory: the page used to call `/backup/run` (a POST-only route) and
    // answered 404 on every visit, so the history never rendered.
    () => api.get("/api/v1/admin/backups"),
    [],
  );
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [result, setResult] = useState<any>(null);

  const runBackup = async () => {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const response = await api.post("/api/v1/admin/backup/run", { confirm: confirmed });
      setResult(response);
      if (response?.started === false) {
        // SQLite deployment or a missing script: the API explains the correct manual step
        // instead of pretending a backup happened — the toast must not contradict it.
        notify("warning", response.reason || "Backup was not started");
      } else if (response?.success === false) {
        notify("error", `Backup script exited with code ${response.exit_code ?? "?"}`);
      } else {
        notify("success", "Backup completed and verified");
      }
      backups.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (backups.loading && !backups.data) return <Spinner />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.backups")}</h1>
          <p>
            {t("admin.backupNote")}
          </p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      {result && (
        <Card title={t("admin.ui.backupResult")}>
          <pre className="md__code">{JSON.stringify(result, null, 2)}</pre>
        </Card>
      )}

      <div className="grid grid--4">
        <Stat label={t("admin.ui.backups")} value={backups.data?.items?.length ?? 0} />
        <Stat label={t("admin.ui.directory")} value={backups.data?.directory || "—"} />
        <Stat label={t("admin.ui.lastVerified")} value={formatDateTime(backups.data?.last_verified, locale)} />
        <Stat
          label={t("admin.ui.latestSize")}
          value={formatBytes(backups.data?.items?.[0]?.size_bytes)}
        />
      </div>

      <Card title={t("admin.ui.runBackup")}>
        <ConfirmCheckbox checked={confirmed} onChange={setConfirmed} label={t("admin.confirmSensitive")} />
        <div className="row" style={{ marginTop: "0.6rem" }}>
          <Button type="button" onClick={runBackup} loading={busy} disabled={!confirmed || busy}>
            {t("admin.runBackup")}
          </Button>
        </div>
        <p className="muted small">{backups.data?.restore_note}</p>
      </Card>

      <Card title={t("admin.ui.backupHistory")}>
        {(backups.data?.items || []).length === 0 ? (
          <p className="muted">{t("admin.noBackups")}</p>
        ) : (
          <div className="table-wrap table-wrap--stack">
            <table className="table table--stack">
              <thead>
                <tr>
                  <th>{t("label.fileName")}</th>
                  <th>Size</th>
                  <th>{t("label.status")}</th>
                  <th>{t("label.created")}</th>
                  <th>{t("admin.colVerified")}</th>
                </tr>
              </thead>
              <tbody>
                {(backups.data?.items || []).map((backup) => (
                  <tr key={backup.id}>
                    <td className="mono" data-label={t("label.fileName")}>{backup.filename}</td>
                    <td data-label={t("label.size")}>{formatBytes(backup.size_bytes)}</td>
                    <td data-label={t("label.status")}>
                      <Badge tone={backup.status === "completed" ? "success" : "warning"}>{backup.status}</Badge>
                    </td>
                    <td data-label={t("label.created")}>{formatDateTime(backup.created_at, locale)}</td>
                    <td data-label={t("label.verified")} title={backup.notes || backup.sha256 || undefined}>
                      {backup.verified ? t("common.yes") : t("common.no")}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
