/**
 * The public face of Nexa AI — a luxury storefront for the platform.
 *
 * Server-side nothing: it renders from translations and links into the real
 * product (register, sign in, the live model directory). Signed-in visitors
 * never see it; the route gate sends them straight to the app.
 */
import { Link, Navigate } from "react-router-dom";

import { Icon, LogoMark, type IconName } from "../components/icons";
import type { TranslationKey } from "../locales";
import { useApp, useI18n } from "../state/app";

const FEATURES: { icon: IconName; title: TranslationKey; text: TranslationKey }[] = [
  { icon: "chat", title: "landing.f1t", text: "landing.f1d" },
  { icon: "brain", title: "landing.f2t", text: "landing.f2d" },
  { icon: "image", title: "landing.f3t", text: "landing.f3d" },
  { icon: "shield", title: "landing.f4t", text: "landing.f4d" },
  { icon: "wallet", title: "landing.f5t", text: "landing.f5d" },
  { icon: "layers", title: "landing.f6t", text: "landing.f6d" },
];

export function LandingGate(): JSX.Element {
  const { user, ready } = useApp();
  if (!ready) return <></>;
  if (user) return <Navigate to="/app" replace />;
  return <Landing />;
}

export default function Landing(): JSX.Element {
  const { t } = useI18n();
  return (
    <main className="landing">
      <header className="landing__nav">
        <Link to="/" className="brand">
          <LogoMark />
          <span className="brand__text">
            <strong>{t("app.name")}</strong>
            <small>{t("app.tagline")}</small>
          </span>
        </Link>
        <nav className="landing__actions">
          <Link className="btn btn--ghost" to="/login">{t("landing.login")}</Link>
          <Link className="btn" to="/register">{t("landing.register")}</Link>
        </nav>
      </header>

      <section className="landing__hero">
        <span className="landing__mark"><LogoMark size={84} /></span>
        <span className="landing__eyebrow">{t("landing.eyebrow")}</span>
        <h1 className="landing__title">
          {t("landing.titleA")} <span className="landing__title-accent">{t("landing.titleAccent")}</span> {t("landing.titleB")}
        </h1>
        <p className="landing__subtitle">{t("landing.subtitle")}</p>
        <div className="landing__cta">
          <Link className="btn" to="/register">{t("landing.ctaStart")}</Link>
          <Link className="btn btn--ghost" to="/login">{t("landing.ctaEnter")}</Link>
        </div>
        <div className="landing__stats">
          <div className="landing__stat"><strong>{t("landing.stat1v")}</strong><span>{t("landing.stat1l")}</span></div>
          <div className="landing__stat"><strong>{t("landing.stat2v")}</strong><span>{t("landing.stat2l")}</span></div>
          <div className="landing__stat"><strong>{t("landing.stat3v")}</strong><span>{t("landing.stat3l")}</span></div>
          <div className="landing__stat"><strong>{t("landing.stat4v")}</strong><span>{t("landing.stat4l")}</span></div>
        </div>
      </section>

      <h2 className="landing__section-title">{t("landing.featuresTitle")}</h2>
      <p className="landing__section-sub">{t("landing.featuresSub")}</p>
      <section className="landing__grid">
        {FEATURES.map((feature) => (
          <article key={feature.title} className="card card--hover landing__feature">
            <span className="landing__feature-icon"><Icon name={feature.icon} size={24} /></span>
            <h3>{t(feature.title)}</h3>
            <p>{t(feature.text)}</p>
          </article>
        ))}
      </section>

      <section className="card landing__closing">
        <h2>{t("landing.closingTitle")}</h2>
        <p>{t("landing.closingText")}</p>
        <div className="landing__cta">
          <Link className="btn" to="/register">{t("landing.ctaStart")}</Link>
        </div>
      </section>

      <footer className="landing__footer">
        <span>{t("app.name")} — {t("landing.footerTag")}</span>
        <span>{t("landing.footerNote")}</span>
      </footer>
    </main>
  );
}
