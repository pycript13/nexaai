import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../api/client";
import { Button, ErrorNotice, Field } from "../components/ui";
import { AuthShell } from "../components/auth";

export function ResetPassword(): JSX.Element {
  const navigate = useNavigate();
  const [token, setToken] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);
    if (password !== confirm) {
      setError(new Error("The two passwords do not match."));
      return;
    }
    setBusy(true);
    try {
      await api.post("/api/v1/auth/password/reset", { token, new_password: password });
      setDone(true);
      setTimeout(() => navigate("/login"), 1500);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthShell title="Choose a new password" subtitle="Paste the one-time token you received, then set a new password.">
      {error ? <ErrorNotice error={error} /> : null}
      {done && (
        <div className="alert alert--success" role="status">
          <div className="alert__body">
            <div>
              <strong>Password updated.</strong>
              <p className="alert__hint">All other sessions were signed out. Redirecting to sign in…</p>
            </div>
          </div>
        </div>
      )}
      <form onSubmit={submit}>
        <Field label="Reset token" hint="The token from the email or from the administrator.">
          <input value={token} onChange={(e) => setToken(e.target.value)} required dir="ltr" />
        </Field>
        <Field label="New password">
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required autoComplete="new-password" />
        </Field>
        <Field label="Repeat new password">
          <input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required autoComplete="new-password" />
        </Field>
        <Button type="submit" loading={busy} disabled={busy} className="btn--block">
          Update password
        </Button>
      </form>
      <p style={{ marginTop: "0.95rem" }}>
        <Link to="/login">Back to sign in</Link>
      </p>
    </AuthShell>
  );
}
