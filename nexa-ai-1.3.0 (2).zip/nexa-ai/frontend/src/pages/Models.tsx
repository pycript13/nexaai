import React, { useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api/client";
import type { CatalogModel, CatalogResponse } from "../api/types";
import { Badge, Card, ErrorNotice, Field, Pagination, Spinner, useApi } from "../components/ui";
import { Icon } from "../components/icons";
import { formatCredits, localized } from "../utils/format";
import { useI18n } from "../state/app";
import { accessReason } from "./shared";
import { ModelHealthBadge, useModelHealth } from "../components/ModelHealth";

export function Models(): JSX.Element {
  const { t, locale } = useI18n();
  const { health: modelHealth, probe: probeModel } = useModelHealth();
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState("default");
  const catalog = useApi<CatalogResponse>(
    () => api.get<CatalogResponse>("/api/v1/models", { page, page_size: 20, ...filters }),
    [page, JSON.stringify(filters)],
  );
  const categories = useApi<{ items: { slug: string; name: string; name_fa?: string; model_count?: number }[] }>(
    () => api.get("/api/v1/models/categories"),
    [],
  );

  // OpenRouter-style ordering over the current page (the server keeps filtering + paging).
  const items = React.useMemo(() => {
    const list = [...(catalog.data?.items || [])];
    if (sort === "cheapest") {
      list.sort((a, b) => (a.pricing?.input_credits_per_mtok ?? Number.MAX_VALUE) - (b.pricing?.input_credits_per_mtok ?? Number.MAX_VALUE));
    } else if (sort === "name") {
      list.sort((a, b) => a.display_name.localeCompare(b.display_name, locale));
    } else if (sort === "context") {
      list.sort((a, b) => (b.context_window ?? 0) - (a.context_window ?? 0));
    }
    return list;
  }, [catalog.data, sort, locale]);

  if (catalog.loading) return <Spinner />;
  if (catalog.error) return <ErrorNotice error={catalog.error} onRetry={catalog.reload} />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.catalog")}</h1>
          <p>
            The catalog is filtered server-side: hidden, unpublished, internal and disabled models never appear here,
            and access tiers are enforced on every request.
          </p>
        </div>
      </div>

      <div className="pill-list" role="group" aria-label={t("action.filter")}>
        {[
          { key: "all", label: t("common.all"), apply: () => setFilters((f) => ({ ...f, tier: "", capability: "" })) },
          { key: "free", label: t("admin.catalog.free"), apply: () => setFilters((f) => ({ ...f, tier: "free", capability: "" })) },
          { key: "vision", label: t("admin.catalog.f_vision"), apply: () => setFilters((f) => ({ ...f, capability: "image_understanding", tier: "" })) },
          { key: "tools", label: t("admin.catalog.f_tools"), apply: () => setFilters((f) => ({ ...f, capability: "tools", tier: "" })) },
          { key: "reasoning", label: t("admin.catalog.f_reasoning"), apply: () => setFilters((f) => ({ ...f, capability: "reasoning", tier: "" })) },
        ].map((chip) => (
          <button
            key={chip.key}
            type="button"
            className="chip"
            onClick={() => { setPage(1); chip.apply(); }}
          >
            {chip.label}
          </button>
        ))}
      </div>

      <Card title={t("action.filter")}>
        <div className="grid grid--4">
          <Field label={t("action.search")}>
            <input
              value={filters.search || ""}
              onChange={(event) => {
                setPage(1);
                setFilters({ ...filters, search: event.target.value });
              }}
            />
          </Field>
          <Field label={t("label.capabilities")}>
            <select
              value={filters.capability || ""}
              onChange={(event) => {
                setPage(1);
                setFilters({ ...filters, capability: event.target.value });
              }}
            >
              <option value="">{t("common.all")}</option>
              {(catalog.data?.capabilities || []).map((capability: string) => (
                <option key={capability} value={capability}>
                  {localized(catalog.data?.operation_labels?.[capability], locale, capability)}
                </option>
              ))}
            </select>
          </Field>
          <Field label={t("label.tier")}>
            <select
              value={filters.tier || ""}
              onChange={(event) => {
                setPage(1);
                setFilters({ ...filters, tier: event.target.value });
              }}
            >
              <option value="">{t("common.all")}</option>
              {(catalog.data?.tiers || []).map((tier: string) => (
                <option key={tier} value={tier}>
                  {tier}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Category">
            <select
              value={filters.category || ""}
              onChange={(event) => {
                setPage(1);
                setFilters({ ...filters, category: event.target.value });
              }}
            >
              <option value="">{t("common.all")}</option>
              {(categories.data?.items || []).map((category) => (
                <option key={category.slug} value={category.slug}>
                  {category.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label={t("models.sort")} hint={t("models.sortPageHint")}>
            <select value={sort} onChange={(event) => setSort(event.target.value)}>
              <option value="default">{t("models.sortDefault")}</option>
              <option value="cheapest">{t("models.sortCheapest")}</option>
              <option value="name">{t("models.sortName")}</option>
              <option value="context">{t("models.sortContext")}</option>
            </select>
          </Field>
        </div>
      </Card>

      {(catalog.data?.items || []).length === 0 ? (
        <Card title={t("status.empty")}>
          <p className="muted">
            No model matches these filters. If you expected models here, an administrator has not published one yet.
          </p>
        </Card>
      ) : (
        <div className="router-list">
          {items.map((model) => (
            <div key={model.id} className="router-row">
              <span className="model-tile" aria-hidden="true">{(model.provider || "?").charAt(0).toUpperCase()}</span>
              <span className="router-row__main">
                <Link className="router-row__name" to={`/app/models/${model.id}`}>{model.display_name}</Link>
                <span className="mono small muted" dir="ltr">{model.provider} · {model.provider_model_id}</span>
                <span className="pill-list" style={{ marginTop: "0.3rem" }}>
                  {model.access_tier === "free" ? <Badge tone="success">{t("admin.catalog.free")}</Badge> : null}
                  {(model.capabilities || []).slice(0, 4).map((capability) => (
                    <Badge key={capability} tone="info">{capability}</Badge>
                  ))}
                  {model.supports_vision ? <Badge tone="neutral">vision</Badge> : null}
                  {model.supports_tools ? <Badge tone="neutral">tools</Badge> : null}
                  {model.supports_streaming ? <Badge tone="neutral">stream</Badge> : null}
                  <Badge tone={model.availability === "available" ? "success" : "warning"}>{model.availability}</Badge>
                  {model.accessible ? null : <Badge tone="warning">{accessReason(t, model, "short")}</Badge>}
                </span>
              </span>
              <span className="router-row__prices">
                <span className="router-row__price">
                  <span className="price-block__label">Input / 1M</span>
                  <span className="price-block__value mono">{formatCredits((model.pricing?.input_credits_per_mtok ?? 0) * 1_000_000)}</span>
                </span>
                <span className="router-row__price">
                  <span className="price-block__label">Output / 1M</span>
                  <span className="price-block__value mono">{formatCredits((model.pricing?.output_credits_per_mtok ?? 0) * 1_000_000)}</span>
                </span>
                <span className="router-row__price">
                  <span className="price-block__label">{t("models.context")}</span>
                  <span className="price-block__value mono">{model.context_window ? `${Math.round(model.context_window / 1000)}K` : "—"}</span>
                </span>
              </span>
              <span className="row">
                <button
                  type="button"
                  className="btn btn--ghost"
                  onClick={() => void probeModel(model.id, true)}
                >
                  {t("modelHealth.check")}
                </button>
                <ModelHealthBadge state={modelHealth[model.id]} />
                <Link className="btn btn--subtle" to={`/app/chat?model=${model.id}`}>{t("nav.chat")}</Link>
                <Link className="btn btn--ghost" to={`/app/models/${model.id}`}>{t("label.detail")}</Link>
              </span>
            </div>
          ))}
        </div>
      )}
      <Pagination meta={catalog.data?.pagination} onChange={setPage} />
    </div>
  );
}
