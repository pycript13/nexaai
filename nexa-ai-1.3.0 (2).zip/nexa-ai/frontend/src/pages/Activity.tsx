import { api } from "../api/client";
import { Badge, Card, DataTable, ErrorNotice, Spinner, useApi } from "../components/ui";
import { formatDateTime } from "../utils/format";
import { useI18n } from "../state/app";

interface ActivityEntry {
  id: number;
  event: string;
  description: string | null;
  ip_address: string | null;
  created_at: string;
}

export function Activity(): JSX.Element {
  const { t, locale } = useI18n();
  const activity = useApi<{ items: ActivityEntry[] }>(() => api.get("/api/v1/auth/activity"), []);

  if (activity.loading) return <Spinner />;
  if (activity.error) return <ErrorNotice error={activity.error} onRetry={activity.reload} />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.activity")}</h1>
          <p>Security-relevant events for your account, recorded server-side.</p>
        </div>
      </div>

      <Card title="Recent activity">
        <DataTable
          rows={activity.data?.items || []}
          empty={<p className="muted">{t("status.empty")}</p>}
          columns={[
            { key: "created", header: t("label.created"), render: (row) => formatDateTime(row.created_at, locale) },
            { key: "event", header: "Event", render: (row) => <Badge tone="info">{row.event}</Badge> },
            { key: "description", header: "Description", render: (row) => row.description || "—" },
            { key: "ip", header: "IP", render: (row) => <span className="mono">{row.ip_address || "—"}</span> },
          ]}
        />
      </Card>
    </div>
  );
}
