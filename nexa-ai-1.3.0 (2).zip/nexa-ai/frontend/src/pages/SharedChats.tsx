import React, { useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api/client";
import { Badge, Button, Card, Spinner, useApi } from "../components/ui";
import { useApp, useI18n } from "../state/app";

interface SharedItem {
  id: number;
  title: string;
  share_id: number;
  permission: string;
  owner_email: string | null;
  shared_at: string | null;
  message_count: number;
  updated_at: string;
}

/** Conversations other people share with me — open one and work together. */
export function SharedChats(): JSX.Element {
  const { t } = useI18n();
  const { notify } = useApp();
  const shared = useApi<{ items: SharedItem[] }>(() => api.get("/api/v1/chat/shared"), []);
  const [busy, setBusy] = useState(false);

  const leave = async (item: SharedItem) => {
    setBusy(true);
    try {
      await api.del(`/api/v1/chat/shared/${item.share_id}`);
      notify("success", "از فهرست شما حذف شد");
      shared.reload();
    } catch (caught) {
      notify("error", (caught as Error)?.message || "خطا");
    } finally {
      setBusy(false);
    }
  };

  const items = shared.data?.items || [];
  return (
    <div className="page">
      <header className="page__head">
        <div>
          <h1>🤝 {t("nav.shared")}</h1>
          <p className="muted">گفتگوهایی که دیگران با شما به اشتراک گذاشته‌اند. با دسترسی «ویرایش» می‌توانید در همان گفتگو پیام بفرستید و با هم روی آن کار کنید؛ هزینهٔ هر پیام با فرستندهٔ خودش حساب می‌شود.</p>
        </div>
      </header>
      <Card title={t("nav.shared")} icon="users">
        {shared.loading ? <Spinner /> : null}
        {!shared.loading && !items.length ? (
          <p className="muted">هنوز گفتگویی با شما به اشتراک گذاشته نشده است. از صاحب گفتگو بخواهید از دکمهٔ «اشتراک» کنار گفتگو، ایمیل شما را اضافه کند.</p>
        ) : null}
        <div className="stack">
          {items.map((item) => (
            <div key={item.share_id} className="variant-item">
              <div className="variant-item__head">
                <div className="variant-item__title">
                  <strong dir="auto">{item.title}</strong>
                  <span className="muted small">
                    از طرف {item.owner_email || "—"} · {item.message_count} پیام
                  </span>
                </div>
                <Badge tone={item.permission === "edit" ? "success" : "neutral"}>
                  {item.permission === "edit" ? "قابل ویرایش" : "فقط مشاهده"}
                </Badge>
              </div>
              <div className="row">
                <Link className="btn btn--primary" to={`/app/studio?conversation=${item.id}`}>
                  باز کردن گفتگو
                </Link>
                <Button variant="ghost" type="button" disabled={busy} onClick={() => leave(item)}>
                  حذف از فهرست من
                </Button>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
