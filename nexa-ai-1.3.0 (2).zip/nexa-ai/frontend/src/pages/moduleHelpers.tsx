import type { CatalogModel } from "../api/types";
import { ModelPicker } from "./shared";

/** Model picker limited to models that are really usable for a capability. */
export function ModelNotice({
  models,
  value,
  onChange,
  capability = "chat",
}: {
  models: CatalogModel[];
  value: number | null;
  onChange: (value: number | null) => void;
  capability?: string;
}): JSX.Element {
  const filtered = models.filter((model) => model.capabilities.includes(capability));
  return <ModelPicker models={filtered} value={value} onChange={onChange} capability={capability} />;
}
