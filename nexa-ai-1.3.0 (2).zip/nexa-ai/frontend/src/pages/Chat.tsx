/**
 * Chat workspace — a full commercial chat shell with real token streaming.
 *
 * Round 15 turns the page from "two cards side by side" into a real chat product:
 * a conversation rail (search, pin, rename, delete, previews), a full-height thread with
 * per-message tools (copy, edit & re-run, regenerate, delete), a suggestion hero, a
 * jump-to-latest control and a clean glass composer. Every feature is backed by a real API
 * endpoint (`PATCH/DELETE /chat/conversations/{id}`, `POST /chat/messages/{id}/resubmit`,
 * `POST /chat/conversations/{id}/regenerate`, `DELETE /chat/messages/{id}`).
 *
 * Streaming uses `fetch` + a ReadableStream reader (not EventSource) so the session
 * cookie and CSRF header are sent exactly like every other API call. Server-sent
 * events carry meta / delta / usage / error / done frames.
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { api, ApiError, downloadFile, getCsrfToken } from "../api/client";
import { ModelHealthBadge, useModelHealth } from "../components/ModelHealth";
import type { CatalogModel, ChatMessageRecord, Conversation, Paged } from "../api/types";
import { Badge, Button, Card, EmptyState, ErrorNotice, Field, IconButton, useApi } from "../components/ui";
import { Icon } from "../components/icons";
import { Markdown } from "../components/Markdown";
import { accessReason, NoModelsHint, useCatalog, UsageLine } from "./shared";
import { formatCredits, formatDateTime, relativeTime } from "../utils/format";
import { useApp, useI18n } from "../state/app";
import { VariantPicker } from "../components/variants";
import type { Variant } from "../components/variants";

const REASONING_BLOCK_RE = /<\s*(?:think|thinking|reasoning)\b[^>]*>[\s\S]*?(?:<\s*\/\s*(?:think|thinking|reasoning)\s*>|$)/gi;

/** The rail preview mirrors the visible answer — reasoning blocks never leak into it. */
function visiblePreview(preview: string | null | undefined): string {
  return (preview || "").replace(REASONING_BLOCK_RE, "").replace(/\s+/g, " ").trim();
}

/** Reasoning text of a stored message: either its own `reasoning` part or an inline `<think>` block. */
function reasoningTextOf(message: ChatMessageRecord): string | null {
  const parts = (message.content_parts || []) as Array<{ type?: string; text?: string }>;
  const fromParts = parts.filter((part) => part?.type === "reasoning").map((part) => part.text || "").join("\n\n");
  if (fromParts.trim()) return fromParts;
  const inline = /<\s*(?:think|thinking|reasoning)\b[^>]*>([\s\S]*?)(?:<\s*\/\s*(?:think|thinking|reasoning)\s*>|$)/i.exec(message.content || "");
  return inline?.[1]?.trim() || null;
}

interface ChatTurn {
  role: string;
  content: string;
  errorCategory?: string | null;
  errorMessage?: string | null;
  reasoning?: string | null;
  prompt_tokens?: number | null;
  completion_tokens?: number | null;
  charged_micro?: number;
  usage_source?: string;
  status?: string | null;
  id?: number;
  created_at?: string;
  variantCount?: number;
  variantPos?: number;
  variantIds?: number[];
}

function startOfLocalDay(date: Date): number {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
}

function sameLocalDay(isoA: string, isoB: string): boolean {
  const a = new Date(isoA);
  const b = new Date(isoB);
  if (Number.isNaN(a.getTime()) || Number.isNaN(b.getTime())) return true;
  return startOfLocalDay(a) === startOfLocalDay(b);
}

/**
 * Standard chat day separators: «Today» / «Yesterday» / a medium localized date,
 * rendered only where the local calendar day actually changes.
 */
function daySeparatorLabel(iso: string, locale: string, today: string, yesterday: string): string | null {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return null;
  const diff = Math.round((startOfLocalDay(new Date()) - startOfLocalDay(date)) / 86_400_000);
  if (diff === 0) return today;
  if (diff === 1) return yesterday;
  try {
    return new Intl.DateTimeFormat(locale, { dateStyle: "medium" }).format(date);
  } catch {
    return date.toISOString().slice(0, 10);
  }
}

export function Chat(): JSX.Element {
  const { t, locale } = useI18n();
  const { notify, meta, user } = useApp();
  const [params, setParams] = useSearchParams();
  const catalog = useCatalog();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [turns, setTurns] = useState<ChatTurn[]>([]);
  const [variantSel, setVariantSel] = useState<Record<string, number>>({});
  const [modelId, setModelId] = useState<number | null>(null);
  const { health: modelHealth, probe: probeModel, markFailed: markModelFailed, markOk: markModelOk } = useModelHealth();
  const [variantId, setVariantId] = useState<number | null>(null);
  const [input, setInput] = useState("");
  const [systemPrompt, setSystemPrompt] = useState("");
  const [temperature, setTemperature] = useState(0.7);
  const [useStream, setUseStream] = useState(true);
  const [streaming, setStreaming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const threadRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);

  // --- rail state -------------------------------------------------------------
  const [query, setQuery] = useState("");
  const [sideOpen, setSideOpen] = useState(false);
  const [renamingId, setRenamingId] = useState<number | null>(null);
  const [renameText, setRenameText] = useState("");
  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);
  // --- thread state -----------------------------------------------------------
  const [editing, setEditing] = useState<{ id: number; text: string } | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [atBottom, setAtBottom] = useState(true);

  const catalogModels = useMemo(() => catalog.data?.items || [], [catalog.data]);
  const usableModels = useMemo(() => catalogModels.filter((model) => model.accessible), [catalogModels]);
  // Why the model is not usable (balance empty, subscription missing, …) — straight from the API.
  const blockedModel = useMemo(() => catalogModels.find((model) => !model.accessible) || null, [catalogModels]);
  const activeModel = useMemo(
    () => usableModels.find((model) => model.id === modelId) || null,
    [usableModels, modelId],
  );
  const activeConversation = useMemo(
    () => conversations.find((conversation) => conversation.id === activeId) || null,
    [conversations, activeId],
  );

  // Sub-models of the selected model: fetched from the real API and re-fetched when
  // the user switches model. A disabled variant stays visible but is not selectable.
  const variants = useApi<{ items: Variant[] }>(
    () => (modelId ? api.get<{ items: Variant[] }>(`/api/v1/models/${modelId}/variants`) : Promise.resolve({ items: [] })),
    [modelId],
  );
  const modelVariants = variants.data?.items || [];
  const activeVariant = modelVariants.find((variant) => variant.id === variantId) || null;

  useEffect(() => {
    if (!modelVariants.length) {
      setVariantId(null);
      return;
    }
    const preferred = modelVariants.find((variant) => variant.is_default && variant.enabled) || null;
    setVariantId((current) =>
      current !== null && modelVariants.some((variant) => variant.id === current && variant.enabled)
        ? current
        : preferred?.id ?? null,
    );
  }, [variants.data]);

  const loadConversations = async (search?: string) => {
    const data = await api.get<Paged<Conversation>>("/api/v1/chat/conversations", {
      page_size: 50,
      ...(search && search.trim() ? { search: search.trim() } : {}),
    });
    setConversations(data.items);
    return data.items;
  };

  // Server-side search (title + message text), lightly debounced.
  useEffect(() => {
    const handle = window.setTimeout(() => {
      loadConversations(query).catch(setError);
    }, query ? 250 : 0);
    return () => window.clearTimeout(handle);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  useEffect(() => {
    if (modelId === null && usableModels.length > 0) {
      const preferred = Number(params.get("model") || 0);
      setModelId(preferred && usableModels.some((model) => model.id === preferred) ? preferred : usableModels[0].id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [usableModels]);

  useEffect(() => {
    if (modelId) void probeModel(modelId);
    // probeModel is stable; probing is cached server-side for two minutes
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modelId]);

  useEffect(() => {
    const requested = Number(params.get("conversation") || 0);
    if (requested) openConversation(requested);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (threadRef.current && atBottom) threadRef.current.scrollTop = threadRef.current.scrollHeight;
  }, [turns, streaming]);

  // The chat route is immersive: the global footer steps aside so the thread can own the
  // viewport height without the document growing a second scrollbar (see layout.css). The
  // deployment banner (when this install shows one) stays visible — its height is measured
  // into --chat-offset so the page height stays exact in every environment.
  useEffect(() => {
    document.body.classList.add("route-chat");
    const banner = document.querySelector<HTMLElement>(".banner");
    const setOffset = () => {
      const height = banner?.getBoundingClientRect().height || 0;
      document.body.style.setProperty("--chat-offset", `${Math.round(height)}px`);
    };
    setOffset();
    const observer = typeof ResizeObserver !== "undefined" && banner ? new ResizeObserver(setOffset) : null;
    if (banner && observer) observer.observe(banner);
    window.addEventListener("resize", setOffset);
    return () => {
      observer?.disconnect();
      window.removeEventListener("resize", setOffset);
      document.body.style.removeProperty("--chat-offset");
      document.body.classList.remove("route-chat");
    };
  }, []);

  // The composer grows with its content, up to a sane cap.
  useEffect(() => {
    const el = inputRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 180)}px`;
  }, [input]);

  const onThreadScroll = () => {
    const el = threadRef.current;
    if (!el) return;
    setAtBottom(el.scrollHeight - el.scrollTop - el.clientHeight < 90);
  };

  const jumpToLatest = () => {
    const el = threadRef.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
    setAtBottom(true);
  };

  const openConversation = async (id: number, syncSettings = true) => {
    setError(null);
    setActiveId(id);
    setEditing(null);
    setAtBottom(true);
    const detail = await api.get<{ conversation: Conversation & { system_prompt?: string | null; settings?: Record<string, unknown> }; messages: ChatMessageRecord[] }>(`/api/v1/chat/conversations/${id}`);
    setTurns(
      detail.messages.map((message) => ({
        id: message.id,
        role: message.role,
        content: message.content,
        created_at: message.created_at,
        prompt_tokens: message.prompt_tokens,
        completion_tokens: message.completion_tokens,
        charged_micro: message.charged_micro ?? undefined,
        errorCategory: message.status === "stopped" ? null : message.error_category,
        errorMessage: message.status === "stopped" ? null : message.error_message,
        status: message.status,
        reasoning: reasoningTextOf(message),
      })),
    );
    if (detail.conversation.model_id) setModelId(detail.conversation.model_id);
    if (syncSettings) {
      setSystemPrompt(detail.conversation.system_prompt || "");
      const savedTemperature = Number((detail.conversation.settings as Record<string, unknown> | undefined)?.temperature);
      if (Number.isFinite(savedTemperature) && savedTemperature >= 0 && savedTemperature <= 2) setTemperature(savedTemperature);
    }
    setParams((current) => {
      current.set("conversation", String(id));
      return current;
    });
  };

  const newConversation = () => {
    setActiveId(null);
    setTurns([]);
    setError(null);
    setEditing(null);
    setSystemPrompt("");
    setSideOpen(false);
    setParams((current) => {
      current.delete("conversation");
      return current;
    });
    window.setTimeout(() => inputRef.current?.focus(), 60);
  };

  const send = async (stream = true, overrideText?: string) => {
    const message = (overrideText ?? input).trim();
    if (!modelId || !message || busy) return;
    setError(null);
    setInput("");
    setAtBottom(true);
    const localTurns: ChatTurn[] = [...turns, { role: "user", content: message }];
    setTurns(localTurns);
    setBusy(true);
    setStreaming(stream);
    // the closure cannot see state updates made while streaming — track the conversation here
    let convoId = activeId;

    try {
      if (stream) {
        const controller = new AbortController();
        abortRef.current = controller;
        const response = await fetch("/api/v1/chat/stream", {
          method: "POST",
          credentials: "include",
          signal: controller.signal,
          headers: {
            "Content-Type": "application/json",
            Accept: "text/event-stream",
            "X-CSRF-Token": getCsrfToken() || "",
          },
          body: JSON.stringify({
            model_id: modelId,
            message,
            conversation_id: activeId,
            variant_id: variantId ?? undefined,
            system: systemPrompt || undefined,
            temperature,
          }),
        });
        if (!response.ok || !response.body) {
          const payload = await response.json().catch(() => null);
          throw new ApiError(response.status, payload?.error || { code: "stream_failed", message: "The stream could not be opened." });
        }
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let assistant = "";
        let reasoning = "";
        let event = "";
        setTurns((current) => [...current, { role: "assistant", content: "" }]);
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";
          for (const line of lines) {
            if (line.startsWith("event:")) {
              event = line.slice(6).trim();
              continue;
            }
            if (!line.startsWith("data:")) continue;
            const raw = line.slice(5).trim();
            if (!raw) continue;
            let payload: any = null;
            try {
              payload = JSON.parse(raw);
            } catch {
              continue;
            }
            if (event === "meta" && payload?.conversation_id) {
              convoId = payload.conversation_id;
              setActiveId(payload.conversation_id);
              setParams((current) => {
                current.set("conversation", String(payload.conversation_id));
                return current;
              });
            } else if (event === "delta" && typeof payload?.text === "string") {
              assistant += payload.text;
              setTurns((current) => {
                const copy = [...current];
                // spread the previous turn: replacing the object would wipe the reasoning that
                // arrived before the first visible delta (reasoning models stream thinking first)
                copy[copy.length - 1] = { ...copy[copy.length - 1], role: "assistant", content: assistant };
                return copy;
              });
            } else if (event === "reasoning" && typeof payload?.text === "string") {
              // reasoning models stream their chain of thought (either in a separate `reasoning`
              // field or inline in the answer) — keep it in its own panel, never in the reply text
              reasoning += payload.text;
              setTurns((current) => {
                const copy = [...current];
                copy[copy.length - 1] = { ...copy[copy.length - 1], reasoning };
                return copy;
              });
            } else if (event === "usage") {
              setTurns((current) => {
                const copy = [...current];
                copy[copy.length - 1] = {
                  ...copy[copy.length - 1],
                  prompt_tokens: payload.prompt_tokens,
                  completion_tokens: payload.completion_tokens,
                  charged_micro: payload.charged_micro,
                  usage_source: payload.usage_source,
                };
                return copy;
              });
            } else if (event === "error") {
              setTurns((current) => {
                const copy = [...current];
                copy[copy.length - 1] = {
                  ...copy[copy.length - 1],
                  role: "assistant",
                  content: assistant,
                  errorCategory: payload?.category || "upstream_server_error",
                  errorMessage: payload?.message || null,
                  charged_micro: 0,
                };
                return copy;
              });
              notify("error", payload?.message || t("status.error"), payload?.category_label);
            } else if (event === "stopped") {
              // the server kept the partial answer and marked it stopped — mirror that here
              setTurns((current) => {
                const copy = [...current];
                const last = copy[copy.length - 1];
                if (last && last.role === "assistant") {
                  copy[copy.length - 1] = {
                    ...last,
                    id: payload?.assistant_message_id ?? last.id,
                    content: assistant || last.content,
                    status: "stopped",
                  };
                }
                return copy;
              });
            } else if (event === "done" && (payload?.message_id || payload?.assistant_message_id)) {
              setTurns((current) => {
                const copy = [...current];
                const last = copy[copy.length - 1];
                copy[copy.length - 1] = {
                  ...last,
                  id: payload.message_id ?? payload.assistant_message_id,
                  content: last.role === "assistant" && !last.content ? (payload.text || "") : last.content,
                  errorCategory: payload.empty_answer ? "empty_answer" : last.errorCategory,
                  errorMessage: payload.empty_answer ? payload.empty_answer : last.errorMessage,
                };
                return copy;
              });
            }
          }
        }
      } else {
        const response = await api.post<{
          conversation: Conversation;
          message: {
            id: number; content: string; content_parts?: Array<{ type?: string; text?: string }> | null;
            error_message?: string | null; error_category?: string | null;
          };
          usage: { prompt_tokens: number; completion_tokens: number; charged_micro: number; usage_source: string };
        }>("/api/v1/chat/completions", {
          model_id: modelId,
          message,
          conversation_id: activeId,
          variant_id: variantId ?? undefined,
          system: systemPrompt || undefined,
          temperature,
        });
        convoId = response.conversation.id;
        setActiveId(response.conversation.id);
        setTurns((current) => [
          ...current,
          {
            role: "assistant",
            id: response.message.id,
            content: response.message.content,
            // a non-streaming reply carries its reasoning in `content_parts`; without this the
            // reasoning panel would only appear after a page reload
            reasoning: reasoningTextOf({
              id: response.message.id,
              role: "assistant",
              content: response.message.content,
              created_at: "",
              content_parts: response.message.content_parts,
            }),
            errorMessage: response.message.error_message,
            errorCategory: response.message.error_category,
            prompt_tokens: response.usage.prompt_tokens,
            completion_tokens: response.usage.completion_tokens,
            charged_micro: response.usage.charged_micro,
            usage_source: response.usage.usage_source,
          },
        ]);
      }
      await loadConversations(query);
      // Reload the persisted conversation so every message carries its server id — that is what
      // unlocks the per-message tools (edit & re-run, delete) and shows the stored cost. The
      // settings panel keeps its local values (syncSettings=false): they were already sent.
      if (convoId && !(abortRef.current?.signal.aborted ?? false)) await openConversation(convoId, false);
    } catch (caught) {
      if ((caught as Error)?.name === "AbortError") {
        // Stop pressed: the partial answer stays on screen, visibly marked as stopped,
        // with Continue/Regenerate offered — never silently dropped or shown as complete.
        setTurns((current) => {
          const copy = [...current];
          const last = copy[copy.length - 1];
          if (last && last.role === "assistant") copy[copy.length - 1] = { ...last, status: "stopped" };
          return copy;
        });
      } else {
        setError(caught);
        // The real attempt just told the truth (rate limit, provider down…):
        // the health badge must stop claiming the model answers.
        if (modelId) markModelFailed(modelId, caught instanceof Error ? caught.message : String(caught));
      }
    } finally {
      abortRef.current = null;
      setStreaming(false);
      setBusy(false);
    }
  };

  const stop = () => {
    abortRef.current?.abort();
    setStreaming(false);
    setBusy(false);
  };

  const regenerate = async () => {
    if (!activeId) return;
    setBusy(true);
    setError(null);
    try {
      await api.post<{ message?: { content: string; id: number; charged_micro?: number } }>(
        `/api/v1/chat/conversations/${activeId}/regenerate`,
      );
      setVariantSel({}); // a fresh draft exists now — show the newest variant, not a remembered one
      await openConversation(activeId);
      await loadConversations(query);
      notify("success", t("chat.regenerated"));
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  // --- conversation rail actions (all real API calls) --------------------------
  const patchConversation = async (id: number, body: Record<string, unknown>) => {
    setError(null);
    try {
      await api.patch(`/api/v1/chat/conversations/${id}`, body);
      await loadConversations(query);
    } catch (caught) {
      setError(caught);
    }
  };

  const startRename = (conversation: Conversation) => {
    setRenamingId(conversation.id);
    setRenameText(conversation.title || "");
    setConfirmDeleteId(null);
  };

  const commitRename = async () => {
    if (renamingId === null) return;
    const title = renameText.trim();
    const id = renamingId;
    setRenamingId(null);
    if (!title) return;
    await patchConversation(id, { title });
    if (activeId === id) {
      const conversation = conversations.find((entry) => entry.id === id);
      if (conversation) conversation.title = title;
    }
    notify("success", t("chat.saved"));
  };

  const removeConversation = async (id: number) => {
    setConfirmDeleteId(null);
    try {
      await api.del(`/api/v1/chat/conversations/${id}`);
      if (activeId === id) newConversation();
      await loadConversations(query);
      notify("success", t("chat.convoDeleted"));
    } catch (caught) {
      setError(caught);
    }
  };

  // --- per-message actions ------------------------------------------------------
  const copyTurn = async (turn: ChatTurn, key: string) => {
    try {
      await navigator.clipboard.writeText(turn.content || "");
      setCopiedKey(key);
      window.setTimeout(() => setCopiedKey((current) => (current === key ? null : current)), 1400);
      notify("success", t("chat.copied"));
    } catch {
      notify("error", t("status.error"));
    }
  };

  const resubmit = async (messageId: number, content: string) => {
    const text = content.trim();
    if (!text || !activeId) return;
    setBusy(true);
    setError(null);
    try {
      await api.post(`/api/v1/chat/messages/${messageId}/resubmit`, { content: text });
      setEditing(null);
      await openConversation(activeId);
      await loadConversations(query);
      notify("success", t("chat.edited"));
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const removeMessage = async (messageId: number) => {
    if (!activeId) return;
    setError(null);
    try {
      await api.del(`/api/v1/chat/messages/${messageId}`);
      await openConversation(activeId);
      notify("success", t("chat.deleted"));
    } catch (caught) {
      setError(caught);
    }
  };

  const saveSettings = async () => {
    setSettingsOpen(false);
    if (activeId) {
      await patchConversation(activeId, { system_prompt: systemPrompt, settings: { temperature } });
      notify("success", t("chat.settingsSaved"));
    }
  };

  const suggestions = [t("chat.suggest1"), t("chat.suggest2"), t("chat.suggest3"), t("chat.suggest4")];
  // Consecutive assistant messages are the variants of one answer (regeneration keeps
  // every draft): collapse each run to the selected variant and let the user page
  // between them. Selection also activates the variant server-side, so follow-up
  // questions build on the version the user is looking at.
  const visibleTurns = useMemo<ChatTurn[]>(() => {
    const out: ChatTurn[] = [];
    let i = 0;
    while (i < turns.length) {
      const turn = turns[i];
      if (turn.role === "assistant" && turn.id) {
        const group: ChatTurn[] = [turn];
        let j = i + 1;
        while (j < turns.length && turns[j].role === "assistant" && turns[j].id) {
          group.push(turns[j]);
          j += 1;
        }
        if (group.length > 1) {
          const key = String(group[0].id);
          const activePos = group.findIndex((member) => member.status !== "superseded");
          const sel = Math.min(variantSel[key] ?? (activePos >= 0 ? activePos : group.length - 1), group.length - 1);
          out.push({
            ...group[sel],
            variantCount: group.length,
            variantPos: sel,
            variantIds: group.map((member) => member.id as number),
          });
          i = j;
          continue;
        }
      }
      out.push(turn);
      i += 1;
    }
    return out;
  }, [turns, variantSel]);

  const switchVariant = (turn: ChatTurn, delta: number) => {
    if (!turn.variantIds || turn.variantPos === undefined) return;
    const pos = turn.variantPos + delta;
    if (pos < 0 || pos >= turn.variantIds.length) return;
    setVariantSel((current) => ({ ...current, [String(turn.variantIds?.[0])]: pos }));
    const targetId = turn.variantIds[pos];
    void api.post(`/api/v1/chat/messages/${targetId}/activate-variant`).catch(() => notify("error", t("status.error")));
  };

  const lastAssistantIndex = useMemo(() => {
    for (let index = visibleTurns.length - 1; index >= 0; index -= 1) {
      if (visibleTurns[index]?.role === "assistant") return index;
    }
    return -1;
  }, [visibleTurns]);

  return (
    <div className="page page--chat">
      <div className="page-head page-head--chat">
        <div>
          <h1>{t("nav.chat")}</h1>
          <p>{meta?.features?.streaming ? t("chat.taglineStream") : t("chat.taglineNoStream")}</p>
        </div>
        <div className="row">
          <Button variant="subtle" type="button" onClick={newConversation}>
            <Icon name="plus" size={15} />
            {t("chat.newConversation")}
          </Button>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      {!catalog.loading && usableModels.length === 0 && (
        <NoModelsHint reason={blockedModel ? accessReason(t, blockedModel) : null} />
      )}

      <div className={`chat-layout${sideOpen ? " chat-layout--side-open" : ""}`}>
        {/* ------------------------------------------------ conversation rail */}
        <aside className="chat-side" aria-label={t("chat.conversations")}>
          <Button className="chat-side__new" type="button" onClick={newConversation}>
            <Icon name="plus" size={15} />
            {t("chat.newConversation")}
          </Button>
          <div className="chat-side__search">
            <Icon name="search" size={14} />
            <input
              type="search"
              value={query}
              placeholder={t("chat.search")}
              onChange={(event) => setQuery(event.target.value)}
            />
          </div>
          {conversations.length === 0 ? (
            <EmptyState icon="chat" hint={query ? t("chat.searchEmpty") : t("chat.newConversation")} />
          ) : (
            <ul className="chat-side__list">
              {conversations.map((conversation) => (
                <li
                  key={conversation.id}
                  className={`convo${activeId === conversation.id ? " convo--active" : ""}${confirmDeleteId === conversation.id ? " convo--confirm" : ""}`}
                >
                  {renamingId === conversation.id ? (
                    <div className="convo__rename">
                      <input
                        autoFocus
                        value={renameText}
                        placeholder={t("chat.renamePlaceholder")}
                        onChange={(event) => setRenameText(event.target.value)}
                        onKeyDown={(event) => {
                          if (event.key === "Enter") commitRename();
                          if (event.key === "Escape") setRenamingId(null);
                        }}
                      />
                      <IconButton label={t("action.save")} icon="check" onClick={commitRename} />
                      <IconButton label={t("action.cancel")} icon="close" onClick={() => setRenamingId(null)} />
                    </div>
                  ) : (
                    <>
                      <button
                        className="convo__open"
                        type="button"
                        onClick={() => {
                          openConversation(conversation.id);
                          setSideOpen(false);
                        }}
                      >
                        <span className="convo__title" dir="auto">
                          {conversation.pinned ? <Icon name="pin" size={12} aria-label={t("chat.pin")} /> : null}
                          {conversation.title || `#${conversation.id}`}
                        </span>
                        {conversation.last_message_preview ? (
                          <span className="convo__preview" dir="auto">{visiblePreview(conversation.last_message_preview)}</span>
                        ) : null}
                        <span className="convo__meta">
                          <span>{relativeTime(conversation.updated_at)}</span>
                          {typeof conversation.message_count === "number" ? <span>· {conversation.message_count}</span> : null}
                        </span>
                      </button>
                      <span className="convo__tools">
                        {confirmDeleteId === conversation.id ? (
                          <>
                            <IconButton label={t("chat.delete")} icon="check" className="iconbtn--danger" onClick={() => removeConversation(conversation.id)} />
                            <IconButton label={t("action.cancel")} icon="close" onClick={() => setConfirmDeleteId(null)} />
                          </>
                        ) : (
                          <>
                            <IconButton
                              label={conversation.pinned ? t("chat.unpin") : t("chat.pin")}
                              icon="pin"
                              onClick={() => patchConversation(conversation.id, { pinned: !conversation.pinned })}
                            />
                            <IconButton label={t("chat.rename")} icon="pencil" onClick={() => startRename(conversation)} />
                            <IconButton label={t("chat.delete")} icon="trash" onClick={() => setConfirmDeleteId(conversation.id)} />
                          </>
                        )}
                      </span>
                    </>
                  )}
                </li>
              ))}
            </ul>
          )}
        </aside>
        <div className="chat-side__backdrop" onClick={() => setSideOpen(false)} aria-hidden />

        {/* ---------------------------------------------------------- thread */}
        <section className="chat-main">
          <div className="chat-bar">
            <IconButton
              className="chat-bar__side-toggle"
              label={t("chat.conversations")}
              icon="menu"
              onClick={() => setSideOpen(true)}
            />
            <div className="chat-bar__title">
              <strong dir="auto">{activeConversation?.title || t("chat.newConversation")}</strong>
              <Badge tone={streaming ? "info" : busy ? "warning" : "neutral"}>
                {streaming ? t("chat.streaming") : busy ? t("chat.working") : t("chat.idle")}
              </Badge>
              {activeModel ? (
                <Link className="chat-bar__model" to={`/app/models/${activeModel.id}`} title={activeModel.provider || undefined}>
                  <Icon name="sparkles" size={12} />
                  {activeModel.display_name}
                </Link>
              ) : null}
            </div>
            <div className="chat-bar__actions">
              <IconButton label={t("chat.settings")} icon="sliders" onClick={() => setSettingsOpen((value) => !value)} />
              {activeId ? (
                <IconButton label={t("chat.regenerate")} icon="refresh" onClick={regenerate} disabled={busy} />
              ) : null}
              {activeId ? (
                <IconButton
                  label={t("chat.export")}
                  icon="download"
                  onClick={() =>
                    downloadFile(`/api/v1/chat/conversations/${activeId}/export?format=markdown`, `conversation-${activeId}.md`)
                  }
                />
              ) : null}
            </div>
          </div>

          {settingsOpen ? (
            <div className="chat-settings">
              <Field label={t("chat.systemPrompt")} hint={t("chat.systemPromptHint")}>
                <textarea
                  value={systemPrompt}
                  rows={3}
                  onChange={(event) => setSystemPrompt(event.target.value)}
                />
              </Field>
              <div className="chat-settings__row">
                <label className="field">
                  <span className="field__label">{t("chat.temperature")} · {temperature.toFixed(1)}</span>
                  <input
                    type="range"
                    min={0}
                    max={2}
                    step={0.1}
                    value={temperature}
                    onChange={(event) => setTemperature(Number(event.target.value))}
                  />
                </label>
                <label className="chat-settings__stream">
                  <input type="checkbox" checked={useStream} onChange={(event) => setUseStream(event.target.checked)} />
                  <span>{t("chat.streamMode")}</span>
                </label>
                <Button variant="subtle" type="button" onClick={saveSettings}>
                  {t("chat.saveSettings")}
                </Button>
              </div>
              {activeId ? null : <p className="muted small">{t("chat.settingsHintNew")}</p>}
            </div>
          ) : null}

          <div className="chat-thread" ref={threadRef} onScroll={onThreadScroll}>
            {turns.length === 0 ? (
              <div className="chat-hero">
                <div className="chat-hero__orb" aria-hidden>
                  <Icon name="sparkles" size={30} />
                </div>
                <h2>{t("chat.heroTitle")}</h2>
                <p className="muted">{t("chat.heroHint")}</p>
                <div className="chat-hero__chips">
                  {suggestions.map((suggestion) => (
                    <button
                      key={suggestion}
                      type="button"
                      onClick={() => {
                        setInput(suggestion);
                        inputRef.current?.focus();
                      }}
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              visibleTurns.map((turn, index) => {
                const isUser = turn.role === "user";
                const kind = isUser ? "user" : turn.errorCategory ? "error" : "assistant";
                const key = turn.id ?? `local-${index}`;
                const activeEdit = editing && editing.id === turn.id ? editing : null;
                const tokens = (turn.prompt_tokens || 0) + (turn.completion_tokens || 0);
                const previous = index > 0 ? visibleTurns[index - 1] : null;
                const dayLabel = turn.created_at
                  && (!previous || !previous.created_at || !sameLocalDay(turn.created_at, previous.created_at))
                  ? daySeparatorLabel(turn.created_at, locale, t("chat.day.today"), t("chat.day.yesterday"))
                  : null;
                return (
                  <React.Fragment key={key}>
                    {dayLabel ? (
                      <div className="day-sep" role="separator">
                        <span>{dayLabel}</span>
                      </div>
                    ) : null}
                    <div className={`bubble bubble--${kind}`}>
                    <div className="bubble__who">
                      <span className={`bubble__avatar bubble__avatar--${isUser ? "user" : "model"}`} aria-hidden>
                        <Icon name={isUser ? "user" : "sparkles"} size={13} />
                      </span>
                      {isUser ? (user?.display_name || user?.email || t("chat.role.user")) : (activeModel?.display_name || meta?.app_name || t("app.name"))}
                    </div>
                    {turn.role === "assistant" && turn.reasoning ? (
                      <details className="bubble__reasoning">
                        <summary>
                          <Icon name="sparkles" size={13} /> {t("chat.reasoning")}
                        </summary>
                        <pre>{turn.reasoning}</pre>
                      </details>
                    ) : null}
                    {turn.role === "assistant" ? (
                      turn.content ? (
                        <Markdown text={turn.content} />
                      ) : streaming && index === visibleTurns.length - 1 ? (
                        <span className="typing" aria-label={t("chat.thinking")}>
                          <i />
                          <i />
                          <i />
                        </span>
                      ) : turn.errorMessage ? (
                        <p className="bubble__note">
                          <Icon name="alert" size={14} /> {turn.errorMessage}
                        </p>
                      ) : (
                        <p className="bubble__note">{t("chat.empty_answer")}</p>
                      )
                    ) : activeEdit ? (
                      <div className="bubble__edit">
                        <textarea
                          autoFocus
                          value={activeEdit.text}
                          rows={3}
                          onChange={(event) => setEditing({ id: turn.id as number, text: event.target.value })}
                          onKeyDown={(event) => {
                            if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) resubmit(turn.id as number, activeEdit.text);
                            if (event.key === "Escape") setEditing(null);
                          }}
                        />
                        <div className="row">
                          <Button type="button" onClick={() => resubmit(turn.id as number, activeEdit.text)} disabled={busy}>
                            {t("chat.editSend")}
                          </Button>
                          <Button variant="ghost" type="button" onClick={() => setEditing(null)}>
                            {t("action.cancel")}
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <p dir="auto" className="bubble__text">{turn.content}</p>
                    )}
                    <div className="bubble__meta">
                      <span>{isUser ? t("chat.role.user") : t("chat.role.assistant")}</span>
                      {turn.created_at && <span title={formatDateTime(turn.created_at, locale)}>{relativeTime(turn.created_at)}</span>}
                      {tokens > 0 ? <span>{tokens} {t("chat.tokens")}</span> : null}
                      {turn.charged_micro ? <span>{formatCredits(turn.charged_micro)} {t("label.credits")}</span> : null}
                      {turn.errorCategory && <Badge tone="danger">{turn.errorCategory}</Badge>}
                      {turn.status === "stopped" && <Badge tone="warning">{t("chat.stopped")}</Badge>}
                    </div>
                    {turn.status === "stopped" && index === lastAssistantIndex ? (
                      <div className="row" style={{ gap: 8, marginTop: 8 }}>
                        <Button variant="subtle" type="button" onClick={() => void send(true, t("chat.continuePrompt"))} disabled={busy || !modelId}>
                          {t("chat.continue")}
                        </Button>
                        <Button variant="ghost" type="button" onClick={regenerate} disabled={busy || !activeId}>
                          {t("chat.regenerate")}
                        </Button>
                      </div>
                    ) : null}
                    {turn.variantCount && turn.variantCount > 1 ? (
                      <div className="row" style={{ gap: 6, marginTop: 8, alignItems: "center" }}>
                        <Button variant="subtle" type="button" aria-label={t("chat.variantPrev")} onClick={() => switchVariant(turn, -1)} disabled={(turn.variantPos ?? 0) <= 0}>
                          ‹
                        </Button>
                        <span aria-live="polite">{(turn.variantPos ?? 0) + 1} / {turn.variantCount}</span>
                        <Button variant="subtle" type="button" aria-label={t("chat.variantNext")} onClick={() => switchVariant(turn, 1)} disabled={(turn.variantPos ?? 0) >= turn.variantCount - 1}>
                          ›
                        </Button>
                      </div>
                    ) : null}
                    <div className="bubble__tools">
                      <IconButton
                        label={t("chat.copy")}
                        icon={copiedKey === String(key) ? "check" : "copy"}
                        onClick={() => copyTurn(turn, String(key))}
                      />
                      {isUser && turn.id ? (
                        <IconButton
                          label={t("chat.edit")}
                          icon="pencil"
                          onClick={() => setEditing({ id: turn.id as number, text: turn.content })}
                        />
                      ) : null}
                      {!isUser && index === lastAssistantIndex && activeId ? (
                        <IconButton label={t("chat.regenerate")} icon="refresh" onClick={regenerate} disabled={busy} />
                      ) : null}
                      {turn.id && activeId ? (
                        <IconButton label={t("chat.deleteMessage")} icon="trash" onClick={() => removeMessage(turn.id as number)} />
                      ) : null}
                    </div>
                    </div>
                  </React.Fragment>
                );
              })
            )}
            {!atBottom && turns.length > 0 ? (
              <button className="chat-jump" type="button" onClick={jumpToLatest} aria-label={t("chat.jumpLatest")}>
                <Icon name="chevron-down" size={16} />
              </button>
            ) : null}
          </div>

          {/* ------------------------------------------------------- composer */}
          <div className="composer">
            <div className="composer__models">
              <label className="field" style={{ marginBottom: 0 }}>
                <span className="field__label">{t("label.model")}</span>
                <select value={modelId ?? ""} onChange={(event) => { const next = event.target.value ? Number(event.target.value) : null; setModelId(next); if (next) void probeModel(next, true); }}>
                  <option value="">—</option>
                  {usableModels.map((model) => (
                    <option key={model.id} value={model.id}>
                      {model.display_name} · {model.provider}
                    </option>
                  ))}
                </select>
              </label>
              {modelId ? (
                <ModelHealthBadge
                  state={modelHealth[modelId]}
                  onRecheck={() => void probeModel(modelId, true)}
                />
              ) : null}
              <VariantPicker variants={modelVariants} value={variantId} onChange={setVariantId} />
              {activeVariant ? (
                <p className="muted small composer__variant">
                  <Icon name="sparkles" size={13} />
                  {activeVariant.emoji ? `${activeVariant.emoji} ` : ""}
                  {activeVariant.name}
                  {activeVariant.has_system_prompt ? ` · ${t("variant.systemPrompt")}: ${activeVariant.system_prompt_chars}` : ""}
                </p>
              ) : null}
              <Link className="composer__pricing" to="/app/models">
                <Icon name="receipt" size={13} />
                {t("chat.pricingLink")}
              </Link>
            </div>
            <textarea
              ref={inputRef}
              className="composer__input"
              value={input}
              rows={1}
              placeholder={t("chat.placeholder")}
              aria-label={t("chat.placeholder")}
              onChange={(event) => setInput(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey) {
                  event.preventDefault();
                  send(useStream);
                }
              }}
            />
            <div className="composer__row">
              <span className="composer__hint">
                {t("chat.composerHint")}
                {input.length > 0 ? ` · ${input.length}` : ""}
              </span>
              <div className="row">
                {streaming ? (
                  <Button variant="danger" type="button" onClick={stop}>
                    <Icon name="close" size={15} />
                    {t("chat.stop")}
                  </Button>
                ) : null}
                <Button type="button" onClick={() => send(useStream)} loading={busy && streaming} disabled={!modelId || !input.trim() || busy}>
                  <Icon name="bolt" size={16} />
                  {t("action.send")}
                </Button>
              </div>
            </div>
            <UsageLine usage={{ charged_micro: turns.reduce((sum, turn) => sum + (turn.charged_micro || 0), 0) }} />
          </div>
        </section>
      </div>
    </div>
  );
}

