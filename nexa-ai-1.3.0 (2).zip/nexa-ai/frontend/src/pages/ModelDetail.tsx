import { Link, useParams } from "react-router-dom";
import { api } from "../api/client";
import type { CatalogModel } from "../api/types";
import { Badge, Card, ErrorNotice, Spinner, useApi } from "../components/ui";
import { formatCredits } from "../utils/format";
import { useApp, useI18n } from "../state/app";
import { accessReasonForCode } from "./shared";
import { VariantManager } from "../components/variants";

interface ModelDetailResponse {
  model: CatalogModel;
  access: { allowed: boolean; code: string; reason?: string; requires_payment?: boolean };
  pricing: {
    currency: string;
    pricing_model: string;
    input_credits_per_mtok: number | null;
    output_credits_per_mtok: number | null;
    per_request_credits: number | null;
    per_image_credits: number | null;
    per_audio_minute_credits: number | null;
    minimum_charge_credits: number | null;
    notes?: string[];
  };
}

export function ModelDetail(): JSX.Element {
  const { modelId } = useParams();
  const { t } = useI18n();
  const { hasPermission } = useApp();
  const detail = useApi<ModelDetailResponse>(() => api.get(`/api/v1/models/${modelId}`), [modelId]);

  if (detail.loading) return <Spinner />;
  if (detail.error) return <ErrorNotice error={detail.error} onRetry={detail.reload} />;
  if (!detail.data) return <p className="muted">{t("status.empty")}</p>;

  const { model, access, pricing } = detail.data;
  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{model.display_name}</h1>
          <p>
            {model.provider} · <span className="mono">{model.provider_model_id}</span>
          </p>
        </div>
        <div className="row">
          <Badge tone={access.allowed ? "success" : "warning"}>
            {access.allowed ? t("status.available") : accessReasonForCode(t, access.code, access.reason, "short")}
          </Badge>
          <Link className="btn" to={`/app/chat?model=${model.id}`}>
            {t("nav.chat")}
          </Link>
        </div>
      </div>

      {!access.allowed && (
        <div className="alert alert--error">
          <div>
            <strong>{accessReasonForCode(t, access.code, access.reason)}</strong>
            {access.requires_payment ? (
              <p className="alert__hint">
                {t("access.paymentHintPrefix")} <Link to="/app/billing">{t("nav.billing")}</Link>
                {t("access.paymentHintSuffix")}
              </p>
            ) : null}
          </div>
        </div>
      )}

      <div className="grid grid--2">
        <Card title={t("label.detail")}>
          <div className="kv">
            <div>
              <span>{t("label.provider")}</span>
              <span>{model.provider}</span>
            </div>
            <div>
              <span>{t("label.capabilities")}</span>
              <span>{model.capabilities.join(", ") || "—"}</span>
            </div>
            <div>
              <span>Input modalities</span>
              <span>{model.input_modalities.join(", ") || "—"}</span>
            </div>
            <div>
              <span>Output modalities</span>
              <span>{model.output_modalities.join(", ") || "—"}</span>
            </div>
            <div>
              <span>Context window</span>
              <span>{model.context_window ? `${model.context_window.toLocaleString()} tokens` : "—"}</span>
            </div>
            <div>
              <span>Max output</span>
              <span>{model.max_output_tokens ? `${model.max_output_tokens.toLocaleString()} tokens` : "—"}</span>
            </div>
            <div>
              <span>{t("label.tier")}</span>
              <span>{model.access_tier}</span>
            </div>
            <div>
              <span>{t("label.availability")}</span>
              <span>{model.availability}</span>
            </div>
            <div>
              <span>Streaming / tools / vision</span>
              <span>
                {String(model.supports_streaming)} / {String(model.supports_tools)} / {String(model.supports_vision)}
              </span>
            </div>
          </div>
        </Card>

        <Card title={t("label.cost")} subtitle={`Pricing model: ${pricing.pricing_model} · currency ${pricing.currency}`}>
          <div className="kv">
            <div>
              <span>Input / 1M tokens</span>
              <span className="mono">{pricing.input_credits_per_mtok ?? "—"} credits</span>
            </div>
            <div>
              <span>Output / 1M tokens</span>
              <span className="mono">{pricing.output_credits_per_mtok ?? "—"} credits</span>
            </div>
            <div>
              <span>Per request</span>
              <span className="mono">{pricing.per_request_credits ?? "—"}</span>
            </div>
            <div>
              <span>Per image</span>
              <span className="mono">{pricing.per_image_credits ?? "—"}</span>
            </div>
            <div>
              <span>Per audio minute</span>
              <span className="mono">{pricing.per_audio_minute_credits ?? "—"}</span>
            </div>
            <div>
              <span>Minimum charge</span>
              <span className="mono">{formatCredits((pricing.minimum_charge_credits ?? 0) * 1_000_000)} credits</span>
            </div>
          </div>
          {pricing.notes?.length ? <p className="muted small">{pricing.notes.join(" ")}</p> : null}
        </Card>
      </div>

      <VariantManager
        modelId={model.id}
        modelName={model.display_name}
        canManageSystem={hasPermission("models.manage") || hasPermission("models.test")}
      />
    </div>
  );
}
