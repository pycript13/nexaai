import { api } from "../api/client";
import { Badge, Card, ErrorNotice, Spinner, StatusBadge, useApi } from "../components/ui";
import { formatCredits, formatDateTime } from "../utils/format";
import { useI18n } from "../state/app";

interface SubscriptionsResponse {
  subscriptions: {
    id: number;
    plan: string | null;
    plan_slug: string | null;
    status: string;
    current_period_start: string | null;
    current_period_end: string | null;
    cancel_at_period_end: boolean;
    renewal_count: number;
  }[];
  available_plans: {
    id: number;
    slug: string;
    name: string;
    name_fa?: string;
    description: string;
    price_micro_monthly: number;
    included_credit_micro: number;
    daily_request_limit: number | null;
    monthly_token_limit: number | null;
    features: Record<string, unknown>;
  }[];
  purchase_note: string;
}

export function Subscriptions(): JSX.Element {
  const { t, locale } = useI18n();
  const data = useApi<SubscriptionsResponse>(() => api.get("/api/v1/billing/subscriptions"), []);

  if (data.loading) return <Spinner />;
  if (data.error) return <ErrorNotice error={data.error} onRetry={data.reload} />;
  const payload = data.data!;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.subscriptions")}</h1>
          <p>{payload.purchase_note}</p>
        </div>
      </div>

      <Card title="My subscriptions">
        {payload.subscriptions.length === 0 ? (
          <p className="muted">You have no subscription yet.</p>
        ) : (
          <div className="grid grid--2">
            {payload.subscriptions.map((subscription) => (
              <div key={subscription.id} className="card" style={{ padding: "0.8rem" }}>
                <div className="row row--between">
                  <strong>{subscription.plan}</strong>
                  <StatusBadge value={subscription.status} />
                </div>
                <div className="kv" style={{ marginTop: "0.5rem" }}>
                  <div>
                    <span>Period start</span>
                    <span>{formatDateTime(subscription.current_period_start, locale)}</span>
                  </div>
                  <div>
                    <span>Period end</span>
                    <span>{formatDateTime(subscription.current_period_end, locale)}</span>
                  </div>
                  <div>
                    <span>Renewals</span>
                    <span>{subscription.renewal_count}</span>
                  </div>
                  <div>
                    <span>Cancel at period end</span>
                    <span>{subscription.cancel_at_period_end ? t("common.yes") : t("common.no")}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card title="Available plans" subtitle="Plan activation is performed by an administrator after payment approval in this deployment.">
        <div className="grid grid--3">
          {payload.available_plans.map((plan) => (
            <div key={plan.id} className="card" style={{ padding: "0.9rem" }}>
              <h3>{plan.name}</h3>
              <p className="muted small">{plan.description}</p>
              <p>
                <strong>{formatCredits(plan.price_micro_monthly)}</strong> credits / month
              </p>
              <p className="muted small">Included credit: {formatCredits(plan.included_credit_micro)} credits</p>
              <div className="pill-list">
                {plan.daily_request_limit ? <Badge tone="info">{plan.daily_request_limit} requests/day</Badge> : null}
                {plan.monthly_token_limit ? <Badge tone="info">{plan.monthly_token_limit.toLocaleString()} tokens/month</Badge> : null}
                {Object.entries(plan.features || {}).map(([key, value]) => (
                  <Badge key={key} tone="neutral">
                    {key}: {String(value)}
                  </Badge>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
