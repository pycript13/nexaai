import React, { useState } from "react";
import { api } from "../api/client";
import type { StoredFile } from "../api/types";
import { BarChart } from "../components/charts";
import { Badge, Button, Card, ErrorNotice, Field, Stat } from "../components/ui";
import { Markdown } from "../components/Markdown";
import { ModuleNotice, NoModelsHint, useCatalog, UsageLine } from "./shared";
import { useApp, useI18n } from "../state/app";

export function DataAnalysis(): JSX.Element {
  const { t } = useI18n();
  const { notify } = useApp();
  const catalog = useCatalog();
  const [files, setFiles] = useState<StoredFile[]>([]);
  const [fileId, setFileId] = useState<number | null>(null);
  const [modelId, setModelId] = useState<number | null>(null);
  const [question, setQuestion] = useState("");
  const [narrative, setNarrative] = useState(true);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);

  const models = (catalog.data?.items || []).filter((model) => model.accessible && model.capabilities.includes("chat"));

  const load = async () => {
    const data = await api.get<{ items: StoredFile[] }>("/api/v1/files", { page_size: 50, kind: "upload" });
    const tabular = data.items.filter((file) => ["csv", "tsv", "xlsx"].includes(file.extension));
    setFiles(tabular);
    return tabular;
  };
  React.useEffect(() => {
    load().catch(setError);
  }, []);
  React.useEffect(() => {
    if (modelId === null && models.length > 0) setModelId(models[0].id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [models.length]);

  const upload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append("file", file);
    setBusy(true);
    try {
      const response = await api.upload<{ file: StoredFile }>("/api/v1/files", form);
      notify("success", `Uploaded ${response.file.original_name}`);
      const tabular = await load();
      setFileId(tabular.length ? tabular[tabular.length - 1].id : response.file.id);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
      event.target.value = "";
    }
  };

  const run = async () => {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      setResult(
        await api.post("/api/v1/modules/data/analyze", {
          file_id: fileId,
          model_id: narrative ? modelId : undefined,
          question: question || undefined,
          narrative,
        }),
      );
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const numeric = (result?.statistics?.columns || []).filter((column: any) => column.type === "numeric");

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.data")}</h1>
          <p>Statistics are computed on the server from the uploaded file; the model only writes the narrative.</p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      <ModuleNotice capability="data" title={t("nav.data")} />

      <div className="grid grid--2">
        <Card title="Dataset">
          <Field label="Upload a CSV, TSV or XLSX file">
            <input type="file" accept=".csv,.tsv,.xlsx" onChange={upload} disabled={busy} />
          </Field>
          <Field label="Existing dataset">
            <select value={fileId ?? ""} onChange={(event) => setFileId(event.target.value ? Number(event.target.value) : null)}>
              <option value="">—</option>
              {files.map((file) => (
                <option key={file.id} value={file.id}>
                  {file.original_name}
                </option>
              ))}
            </select>
          </Field>
          <label className="checkbox" style={{ marginBottom: "0.6rem" }}>
            <input type="checkbox" checked={narrative} onChange={(event) => setNarrative(event.target.checked)} />
            <span>Ask a configured model for a narrative summary</span>
          </label>
          {narrative && (
            <>
              <Field label={t("label.model")}>
                <select value={modelId ?? ""} onChange={(event) => setModelId(event.target.value ? Number(event.target.value) : null)}>
                  <option value="">—</option>
                  {models.map((model) => (
                    <option key={model.id} value={model.id}>
                      {model.display_name}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Question (optional)">
                <textarea value={question} onChange={(event) => setQuestion(event.target.value)} />
              </Field>
            </>
          )}
          {narrative && models.length === 0 && <NoModelsHint />}
          <Button type="button" onClick={run} loading={busy} disabled={!fileId || busy || (narrative && !modelId)}>
            Analyse
          </Button>
        </Card>

        <Card title="Summary">
          {!result ? (
            <p className="muted">Upload a dataset to see server-computed statistics.</p>
          ) : (
            <div className="stack">
              <div className="grid grid--3">
                <Stat label="Rows" value={result.statistics.row_count} />
                <Stat label="Columns" value={result.statistics.column_count} />
                <Stat label="Numeric columns" value={numeric.length} />
              </div>
              <p className="muted small">{result.computed_locally?.note}</p>
            </div>
          )}
        </Card>
      </div>

      {result && (
        <Card title="Column statistics">
          <div className="table-wrap table-wrap--stack">
            <table className="table table--stack">
              <thead>
                <tr>
                  <th>Column</th>
                  <th>Type</th>
                  <th>Non-null</th>
                  <th>Distinct</th>
                  <th>Min</th>
                  <th>Max</th>
                  <th>Mean</th>
                  <th>Median</th>
                </tr>
              </thead>
              <tbody>
                {result.statistics.columns.map((column: any) => (
                  <tr key={column.name}>
                    <td data-label="Column">{column.name}</td>
                    <td data-label="Type">
                      <Badge tone={column.type === "numeric" ? "info" : "neutral"}>{column.type}</Badge>
                    </td>
                    <td data-label="Non-null">{column.non_null}</td>
                    <td data-label="Distinct">{column.distinct}</td>
                    <td className="mono" data-label="Min">{column.min ?? "—"}</td>
                    <td className="mono" data-label="Max">{column.max ?? "—"}</td>
                    <td className="mono" data-label="Mean">{column.mean ?? "—"}</td>
                    <td className="mono" data-label="Median">{column.median ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {result && numeric.length > 0 && (
        <Card title="Numeric distribution (mean)">
          <BarChart
            data={numeric.map((column: any) => ({ label: column.name, value: Number(column.mean) || 0 }))}
            format={(value) => value.toFixed(2)}
          />
        </Card>
      )}

      {result?.narrative && (
        <Card title="Model narrative" actions={result.usage ? <Badge tone="info">charged {result.usage.charged_micro}</Badge> : undefined}>
          <Markdown text={result.narrative} />
          <UsageLine usage={result.usage} />
        </Card>
      )}
    </div>
  );
}
