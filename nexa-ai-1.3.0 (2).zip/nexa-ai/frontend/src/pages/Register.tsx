import React, { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { ApiError } from "../api/client";
import { useApp, useI18n } from "../state/app";
import { Button, ErrorNotice, Field, SuccessNotice } from "../components/ui";
import { AuthShell } from "../components/auth";
import { Icon } from "../components/icons";
import type { TranslationKey } from "../locales";

/**
 * Sign-up.
 *
 * This screen used to be the reason "my friend cannot create an account": it sent only
 * `accept_terms`, while `POST /auth/register` requires **both** acceptances (they are the audit
 * trail the platform must keep). FastAPI answered `422 validation_error` with
 * `{"accept_privacy": "Field required"}` for every visitor, for every language. The form now sends
 * both flags from one honest consent checkbox, shows the field-level error if the API still refuses
 * something, supports the three registration modes the operator can configure (`open`,
 * `invite_only`, `closed`) and reads the server's own wording for the password policy.
 */
export function Register(): JSX.Element {
  const { register, meta } = useApp();
  const { t, locale, setLocale, locales } = useI18n();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [form, setForm] = useState({ email: "", display_name: "", password: "", confirm: "", company: "" });
  const [accepted, setAccepted] = useState(false);
  const [inviteToken, setInviteToken] = useState(searchParams.get("invite") || "");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState<unknown>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const mode = meta?.registration_mode || "open";
  const minLength = meta?.password_min_length || 10;

  useEffect(() => {
    if (mode === "invite_only" && !inviteToken) setInviteToken(searchParams.get("invite") || "");
  }, [mode, inviteToken, searchParams]);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);
    setNotice(null);
    setFieldErrors({});
    const local: Record<string, string> = {};
    if (!form.email.trim()) local.email = t("field.required");
    if (!form.display_name.trim()) local.display_name = t("field.required");
    if (form.password.length < minLength) local.password = t("register.passwordHint").replace("{min}", String(minLength));
    if (form.password !== form.confirm) local.confirm = t("register.passwordMismatch");
    if (!accepted) local.accept_privacy = t("register.consentRequired");
    if (Object.keys(local).length) {
      // Validate before the round-trip so the visitor is never shown a bare 422 for an empty box.
      setFieldErrors(local);
      return;
    }
    if (mode === "invite_only" && !inviteToken.trim()) {
      setFieldErrors({ invitation_token: t("register.inviteRequired") });
      return;
    }
    setBusy(true);
    try {
      const result = await register({
        email: form.email.trim(),
        display_name: form.display_name.trim(),
        password: form.password,
        locale,
        company: form.company.trim() || undefined,
        accept_terms: accepted,
        accept_privacy: accepted,
        invitation_token: mode === "invite_only" ? inviteToken.trim() : undefined,
      });
      if (result.needsVerification) {
        setNotice(t("register.verificationSent"));
      } else {
        navigate("/app", { replace: true });
      }
    } catch (caught) {
      if (caught instanceof ApiError) {
        const fields = (caught.details as { fields?: Record<string, unknown> } | undefined)?.fields;
        if (fields && typeof fields === "object") {
          setFieldErrors(
            Object.fromEntries(Object.entries(fields).map(([key, value]) => [key, Array.isArray(value) ? value.join(" ") : String(value)])),
          );
        }
      }
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (mode === "closed") {
    return (
      <AuthShell title={t("register.title")} subtitle={t("register.subtitle")}>
        <div className="alert alert--warning" role="status">
          <div className="alert__body">
            <Icon name="alert" size={18} />
            <div>
              <strong>{t("register.closedTitle")}</strong>
              <p className="alert__hint">{t("register.closedHint")}</p>
            </div>
          </div>
        </div>
        <div className="row row--between" style={{ marginTop: "0.95rem" }}>
          <Link to="/login">{t("action.login")}</Link>
        </div>
      </AuthShell>
    );
  }

  return (
    <AuthShell title={t("register.title")} subtitle={t("register.subtitle")}>
      {mode === "invite_only" ? (
        <p className="muted small">{t("register.inviteModeNote")}</p>
      ) : null}
      {error ? <ErrorNotice error={error} /> : null}
      {notice ? <SuccessNotice message={notice} /> : null}

      <form onSubmit={submit} noValidate>
        <Field label={t("label.email")} error={fieldErrors.email}>
          <input
            type="email"
            dir="ltr"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            required
            autoComplete="email"
            placeholder="you@example.com"
          />
        </Field>
        <Field label={t("label.displayName")} error={fieldErrors.display_name}>
          <input
            type="text"
            value={form.display_name}
            onChange={(e) => setForm({ ...form, display_name: e.target.value })}
            required
            autoComplete="name"
          />
        </Field>
        <Field label={t("label.company")}>
          <input type="text" value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} autoComplete="organization" />
        </Field>
        <Field
          label={t("label.password")}
          hint={t("register.passwordHint").replace("{min}", String(minLength))}
          error={fieldErrors.password}
        >
          <input
            type="password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            required
            autoComplete="new-password"
            minLength={minLength}
          />
        </Field>
        <Field label={t("register.repeatPassword")} error={fieldErrors.confirm}>
          <input
            type="password"
            value={form.confirm}
            onChange={(e) => setForm({ ...form, confirm: e.target.value })}
            required
            autoComplete="new-password"
          />
        </Field>
        {mode === "invite_only" ? (
          <Field label={t("register.inviteToken")} hint={t("register.inviteTokenHint")} error={fieldErrors.invitation_token}>
            <input
              value={inviteToken}
              onChange={(e) => setInviteToken(e.target.value)}
              dir="ltr"
              required
              placeholder="XXXX-XXXX"
            />
          </Field>
        ) : null}
        <Field label={t("language.label")}>
          <select value={locale} onChange={(e) => setLocale(e.target.value as typeof locale)}>
            {locales.map((entry) => (
              <option key={entry.code} value={entry.code}>
                {entry.nativeLabel}
              </option>
            ))}
          </select>
        </Field>
        <label className="checkbox" style={{ marginBottom: "0.9rem", alignItems: "flex-start" }}>
          <input type="checkbox" checked={accepted} onChange={(e) => setAccepted(e.target.checked)} required />
          <span>
            {t("register.consent")
              .replace("{terms}", String(meta?.terms_version || "—"))
              .replace("{privacy}", String(meta?.privacy_version || "—"))}
          </span>
        </label>
        {fieldErrors.accept_privacy || fieldErrors.accept_terms ? (
          <p className="field__error">{t("register.consentRequired")}</p>
        ) : null}
        <Button type="submit" loading={busy} disabled={busy || !accepted} className="btn--block">
          {t("action.register")}
        </Button>
      </form>

      <div className="row row--between" style={{ marginTop: "0.95rem" }}>
        <Link to="/login">{t("action.login")}</Link>
        <Link to="/verify-email" className="muted small">
          {t("register.verifyExisting")}
        </Link>
      </div>
    </AuthShell>
  );
}

export const REGISTER_TEXT_KEYS = [
  "register.passwordMismatch",
  "register.inviteRequired",
] as TranslationKey[];
