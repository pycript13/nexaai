import { Link } from "react-router-dom";
import { useI18n } from "../state/app";
import { Card } from "../components/ui";

export function NotFound(): JSX.Element {
  const { t } = useI18n();
  return (
    <Card title={`404 — ${t("error.notFound")}`}>
      <p className="muted">The page you requested does not exist in this build.</p>
      <Link to="/app">{t("nav.dashboard")}</Link>
    </Card>
  );
}
