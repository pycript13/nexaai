import React, { useState } from "react";
import { api } from "../api/client";
import { Badge, Button, Card, CopyButton, ErrorNotice, Field, SuccessNotice, useApi } from "../components/ui";
import { formatDateTime } from "../utils/format";
import { useApp, useI18n } from "../state/app";
import { TelegramUserCard } from "../components/telegram-user";

export function Profile(): JSX.Element {
  const { user, refreshMe, meta } = useApp();
  const { t, locale, setLocale, locales } = useI18n();
  const [displayName, setDisplayName] = useState(user?.display_name || "");
  const [errors, setErrors] = useState<unknown>(null);
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);

  const save = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setErrors(null);
    try {
      await api.patch("/api/v1/auth/me", { display_name: displayName, locale });
      await refreshMe();
      setSaved(true);
    } catch (caught) {
      setErrors(caught);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.profile")}</h1>
          <p>Account details are stored on the server; the interface language is remembered per account.</p>
        </div>
      </div>

      {errors ? <ErrorNotice error={errors} /> : null}
      {saved && <SuccessNotice message={t("common.saved")} />}

      <div className="grid grid--2">
        <Card title={t("nav.profile")}>
          <form onSubmit={save}>
            <Field label={t("label.email")}>
              <input value={user?.email || ""} disabled dir="ltr" />
            </Field>
            <Field label={t("label.displayName")}>
              <input value={displayName} onChange={(event) => setDisplayName(event.target.value)} />
            </Field>
            <Field label={t("language.label")}>
              <select value={locale} onChange={(event) => setLocale(event.target.value as typeof locale)}>
                {locales.map((entry) => (
                  <option key={entry.code} value={entry.code}>
                    {entry.nativeLabel}
                  </option>
                ))}
              </select>
            </Field>
            <Button type="submit" loading={busy} disabled={busy}>
              {t("action.save")}
            </Button>
          </form>
        </Card>

        <Card title="Account">
          <div className="kv">
            <div>
              <span>{t("label.status")}</span>
              <span>{user?.status}</span>
            </div>
            <div>
              <span>Email verified</span>
              <span>{user?.email_verified ? t("common.yes") : t("common.no")}</span>
            </div>
            <div>
              <span>{t("label.role")}</span>
              <span>{(user?.roles || []).map((role) => (typeof role === "string" ? role : role.name || role.slug)).join(", ") || "—"}</span>
            </div>
            <div>
              <span>{t("label.permissions")}</span>
              <span>{(user?.permissions || []).length}</span>
            </div>
            <div>
              <span>{t("label.created")}</span>
              <span>{formatDateTime(user?.created_at, locale)}</span>
            </div>
            <div>
              <span>Last sign-in</span>
              <span>{formatDateTime(user?.last_login_at, locale)}</span>
            </div>
            <div>
              <span>{t("label.credits")}</span>
              <span>{meta?.credit_display_name}</span>
            </div>
            <div>
              <span>Terms / privacy version</span>
              <span>
                {meta?.terms_version} / {meta?.privacy_version}
              </span>
            </div>
          </div>
        </Card>
      </div>

      <Card title={t("label.permissions")} subtitle="Effective permissions granted by your roles.">
        <div className="pill-list">
          {(user?.permissions || []).sort().map((permission) => (
            <span key={permission} className="badge badge--neutral mono">
              {permission}
            </span>
          ))}
        </div>
      </Card>

      <TelegramUserCard />
    </div>
  );
}
