/** Shared building blocks for the workspace pages. */
import React from "react";
import { Link } from "react-router-dom";
import { api } from "../api/client";
import type { CatalogModel, Job, ModuleCapability, Paged } from "../api/types";
import { Badge, Card, EmptyState, Spinner, useApi } from "../components/ui";
import { formatCredits } from "../utils/format";
import { useI18n } from "../state/app";
import type { TranslationKey } from "../locales";

export function useCatalog(params: Record<string, string | number | boolean | undefined> = {}) {
  return useApi<Paged<CatalogModel>>(
    () => api.get<Paged<CatalogModel>>("/api/v1/models", { page_size: 100, ...params }),
    [JSON.stringify(params)],
  );
}

export function useModuleCapabilities() {
  return useApi<{ modules: Record<string, ModuleCapability> }>(() => api.get("/api/v1/modules/capabilities"), []);
}

/** Reason codes the API can return in `model.access_code` (see backend/app/services/access.py). */
export const ACCESS_REASON_CODES = [
  "insufficient_balance", "subscription_required", "plan_upgrade_required", "model_restricted",
  "model_not_available", "model_offline", "model_disabled", "internal_only",
  "operation_unsupported", "provider_disabled", "provider_missing",
] as const;

/**
 * Localised explanation of why a catalogue model is not usable.
 *
 * The API sends `access_code` (stable, language-free) plus `access_reason` (an English sentence).
 * Showing the English sentence inside a Persian/Arabic/Kurdish interface was a visible gap, so the
 * code is translated here and the server wording is only the fallback for an unknown code.
 */
export function accessReasonForCode(
  t: (key: TranslationKey) => string,
  code?: string | null,
  fallback?: string | null,
  variant: "short" | "hint" = "hint",
): string {
  if (code && (ACCESS_REASON_CODES as readonly string[]).includes(code)) {
    const key = (variant === "short" ? `access.${code}` : `access.${code}.hint`) as TranslationKey;
    const text = t(key);
    if (text && text !== key) return text;
  }
  return (fallback || "").trim() || t("access.locked");
}

/** Localised explanation of why a catalogue model is not usable. */
export function accessReason(
  t: (key: TranslationKey) => string,
  model: CatalogModel,
  variant: "short" | "hint" = "hint",
): string {
  return accessReasonForCode(t, model.access_code, model.access_reason, variant);
}

export function ModelPicker({
  models,
  value,
  onChange,
  label,
  capability,
}: {
  models: CatalogModel[];
  value: number | null;
  onChange: (value: number | null) => void;
  label?: string;
  capability?: string;
}): JSX.Element {
  const { t } = useI18n();
  const options = capability ? models.filter((model) => model.capabilities.includes(capability)) : models;
  return (
    <label className="field">
      <span className="field__label">{label || t("label.model")}</span>
      <select value={value === null ? "" : String(value)} onChange={(event) => onChange(event.target.value ? Number(event.target.value) : null)}>
        <option value="">—</option>
        {options.map((model) => (
          <option key={model.id} value={model.id} disabled={!model.accessible}>
            {model.display_name} · {model.provider} {model.accessible ? "" : `(${accessReason(t, model, "short")})`}
          </option>
        ))}
      </select>
      <span className="field__hint">
        {options.length === 0
          ? t("chat.noModels")
          : t("label.modelsUsable").replace("{count}", String(options.filter((model) => model.accessible).length))}
      </span>
    </label>
  );
}

export function ModuleNotice({
  capability,
  title,
}: {
  capability: string;
  title?: string;
}): JSX.Element | null {
  const { t } = useI18n();
  const { data, loading } = useModuleCapabilities();
  if (loading) return <Spinner />;
  const module = data?.modules?.[capability];
  if (!module) {
    return (
      <div className="alert alert--error">
        <div>
          <strong>{title || capability}</strong>
          <p>This module is not exposed by the backend build you are running.</p>
        </div>
      </div>
    );
  }
  if (module.available) return null;
  return (
    <div className="alert alert--error" role="alert">
      <div>
        <strong>{title || module.label} is not operational yet</strong>
        <p>{module.message || "No configured model can perform this operation."}</p>
        <p className="alert__hint">
          Ask an administrator to add a provider and publish a model with the <code>{module.operations.join(", ")}</code>{" "}
          capability — see <Link to="/app/models">{t("nav.catalog")}</Link>.
        </p>
      </div>
    </div>
  );
}

export function JobCard({ job }: { job: Job }): JSX.Element {
  const { t } = useI18n();
  return (
    <Card
      title={`#${job.id} · ${job.type}`}
      actions={<Badge tone={job.status === "succeeded" ? "success" : job.status === "failed" ? "danger" : "warning"}>{job.status}</Badge>}
    >
      <div className="kv">
        <div>
          <span>{t("job.status")}</span>
          <span>
            {job.status} · {job.progress}% · attempts {job.attempts}
          </span>
        </div>
        {job.error_category && (
          <div>
            <span>{job.error_category}</span>
            <span>{job.error_message}</span>
          </div>
        )}
        {typeof job.charged_micro === "number" && job.charged_micro > 0 && (
          <div>
            <span>{t("label.charged")}</span>
            <span>{formatCredits(job.charged_micro)} credits</span>
          </div>
        )}
      </div>
      {job.result ? <pre className="md__code">{JSON.stringify(job.result, null, 2).slice(0, 4000)}</pre> : null}
    </Card>
  );
}

export function UsageLine({
  usage,
}: {
  usage?: { prompt_tokens?: number | null; completion_tokens?: number | null; charged_micro?: number; usage_source?: string } | null;
}): JSX.Element | null {
  const { t } = useI18n();
  if (!usage) return null;
  return (
    <p className="muted small">
      {t("label.tokens")}: {usage.prompt_tokens ?? "—"} in / {usage.completion_tokens ?? "—"} out · {t("label.charged")}:{" "}
      {formatCredits(usage.charged_micro ?? 0)} credits
      {usage.usage_source ? ` · source: ${usage.usage_source}` : ""}
    </p>
  );
}

export function NoModelsHint({ reason }: { reason?: string | null } = {}): JSX.Element {
  const { t } = useI18n();
  // Two very different situations used to share one message: a catalogue with nothing published
  // (an administrator's job) and a catalogue whose models are visible but not *accessible* to this
  // account (usually an empty credit balance — the API sends the exact reason). Telling a normal
  // user to "ask an administrator to publish a model" in the second case sent them to the wrong
  // place, so the API's own wording is shown here.
  if (reason) {
    return (
      <EmptyState
        title={t("chat.noAccessibleModels")}
        hint={reason}
        action={
          <>
            <Link className="btn" to="/app/billing">{t("nav.billing")}</Link>
            <Link className="btn btn--ghost" to="/app/models">{t("nav.catalog")}</Link>
          </>
        }
      />
    );
  }
  return (
    <EmptyState
      title={t("chat.noModels")}
      hint="Administrators configure providers under Admin → Providers, then verify and publish models under Admin → Models."
      action={<Link className="btn" to="/app/models">{t("nav.catalog")}</Link>}
    />
  );
}
