import { useState } from "react";
import { api } from "../api/client";
import type { Pagination as PaginationMeta } from "../api/types";
import { Badge, Card, DataTable, ErrorNotice, Pagination, Spinner, Stat, useApi } from "../components/ui";
import { BarChart } from "../components/charts";
import { formatCredits, formatDateTime } from "../utils/format";
import { useI18n } from "../state/app";

interface UsageRecord {
  id: number;
  operation: string;
  module: string;
  status: string;
  model?: string | null;
  provider?: string | null;
  prompt_tokens?: number | null;
  completion_tokens?: number | null;
  charged_micro: number;
  provider_cost_micro?: number | null;
  usage_source?: string;
  latency_ms?: number | null;
  error_category?: string | null;
  created_at: string;
}

export function Usage(): JSX.Element {
  const { t, locale } = useI18n();
  const [page, setPage] = useState(1);
  const usage = useApi<{ items: UsageRecord[]; pagination: PaginationMeta; totals: Record<string, number> }>(
    () => api.get("/api/v1/billing/usage", { page, page_size: 20 }),
    [page],
  );

  if (usage.loading) return <Spinner />;
  if (usage.error) return <ErrorNotice error={usage.error} onRetry={usage.reload} />;

  const byModule = (usage.data?.items || []).reduce<Record<string, number>>((accumulator, record) => {
    accumulator[record.module] = (accumulator[record.module] || 0) + record.charged_micro;
    return accumulator;
  }, {});

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.usage")}</h1>
          <p>
            Every request is recorded with its provider-reported usage when available; estimates are labelled
            <code> estimated</code> instead of being presented as exact.
          </p>
        </div>
      </div>

      <div className="grid grid--4">
        <Stat label="Requests (page)" value={usage.data?.items.length ?? 0} />
        <Stat label="Charged (page)" value={formatCredits((usage.data?.items || []).reduce((sum, item) => sum + item.charged_micro, 0))} />
        <Stat
          label="Provider cost (page)"
          value={formatCredits((usage.data?.items || []).reduce((sum, item) => sum + (item.provider_cost_micro || 0), 0))}
        />
        <Stat
          label="Failures (page)"
          value={(usage.data?.items || []).filter((item) => item.status !== "succeeded").length}
          tone={(usage.data?.items || []).some((item) => item.status !== "succeeded") ? "danger" : undefined}
        />
      </div>

      {usage.data?.totals && (
        <Card title="Lifetime totals">
          <div className="kv">
            {Object.entries(usage.data.totals).map(([key, value]) => (
              <div key={key}>
                <span>{key}</span>
                <span className="mono">{value.toLocaleString(locale)}</span>
              </div>
            ))}
          </div>
        </Card>
      )}

      <Card title="Charges by module (this page)">
        <BarChart
          data={Object.entries(byModule).map(([label, value]) => ({ label, value }))}
          format={(value) => `${formatCredits(value)} credits`}
        />
      </Card>

      <Card title="Usage records">
        <DataTable
          rows={usage.data?.items || []}
          columns={[
            { key: "created", header: t("label.created"), render: (row) => formatDateTime(row.created_at, locale) },
            { key: "module", header: "Module", render: (row) => <Badge tone="info">{row.module}</Badge> },
            { key: "operation", header: "Operation", render: (row) => <span className="mono">{row.operation}</span> },
            { key: "model", header: t("label.model"), render: (row) => row.model || "—" },
            {
              key: "tokens",
              header: t("label.tokens"),
              render: (row) => `${row.prompt_tokens ?? "—"} / ${row.completion_tokens ?? "—"}`,
            },
            { key: "charged", header: t("label.charged"), render: (row) => formatCredits(row.charged_micro) },
            { key: "source", header: "Usage source", render: (row) => row.usage_source || "—" },
            {
              key: "status",
              header: t("label.status"),
              render: (row) => <Badge tone={row.status === "succeeded" ? "success" : "danger"}>{row.error_category || row.status}</Badge>,
            },
          ]}
        />
        <Pagination meta={usage.data?.pagination} onChange={setPage} />
      </Card>
    </div>
  );
}
