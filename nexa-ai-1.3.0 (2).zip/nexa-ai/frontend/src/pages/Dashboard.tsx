import { Link } from "react-router-dom";
import { api } from "../api/client";
import type {
  Balance,
  CatalogModel,
  DashboardDailyPoint,
  DashboardSummary,
  Job,
  ModuleCapability,
  Paged,
} from "../api/types";
import { Badge, Card, EmptyState, Progress, Stat, StatusBadge, useApi } from "../components/ui";
import { Icon, type IconName } from "../components/icons";
import { formatCredits, formatDateTime, humanize } from "../utils/format";
import { useApp, useI18n } from "../state/app";
import { accessReason } from "./shared";

const QUICK_ACTIONS: { to: string; key: "nav.chat" | "nav.images" | "nav.documents" | "nav.data"; icon: IconName }[] = [
  { to: "/app/chat", key: "nav.chat", icon: "chat" },
  { to: "/app/images", key: "nav.images", icon: "image" },
  { to: "/app/documents", key: "nav.documents", icon: "document" },
  { to: "/app/data", key: "nav.data", icon: "data" },
];

const MODULE_ICONS: Record<string, IconName> = {
  chat: "chat",
  coding: "code",
  image_generation: "image",
  document: "document",
  translation: "translate",
  audio: "audio",
  video: "video",
  embedding: "brain",
  rerank: "list",
  data_analysis: "data",
  telegram: "chat",
};

/**
 * Hand-rolled SVG area chart (no chart library — the bundle stays lean and the preview
 * works offline). Every day owns an invisible hover column with a native <title> tooltip,
 * so the exact spend and request count are readable on desktop and by screen readers.
 */
function SpendChart({ daily, creditsLabel, requestsLabel }: {
  daily: DashboardDailyPoint[];
  creditsLabel: string;
  requestsLabel: string;
}): JSX.Element {
  const w = 640;
  const h = 160;
  const padX = 10;
  const padTop = 12;
  const padBottom = 10;
  const innerW = w - padX * 2;
  const innerH = h - padTop - padBottom;
  const max = Math.max(...daily.map((point) => point.charged_micro), 1);
  const step = daily.length > 1 ? innerW / (daily.length - 1) : innerW;
  const x = (i: number): number => padX + i * step;
  const y = (value: number): number => padTop + innerH - (value / max) * innerH;

  const line = daily
    .map((point, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(point.charged_micro).toFixed(1)}`)
    .join(" ");
  const baseline = (padTop + innerH).toFixed(1);
  const area = `${line} L${x(daily.length - 1).toFixed(1)},${baseline} L${x(0).toFixed(1)},${baseline} Z`;
  const tickIndexes = daily.length > 2 ? [0, Math.floor((daily.length - 1) / 2), daily.length - 1] : [0];

  const chart = (
    <svg className="spend-chart" viewBox={`0 0 ${w} ${h}`} role="img" aria-label={creditsLabel}>
      <defs>
        <linearGradient id="spendFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="var(--brand)" stopOpacity="0.32" />
          <stop offset="100%" stopColor="var(--brand)" stopOpacity="0.02" />
        </linearGradient>
      </defs>
      <line className="spend-chart__axis" x1={padX} y1={padTop} x2={w - padX} y2={padTop} />
      <line className="spend-chart__axis" x1={padX} y1={padTop + innerH / 2} x2={w - padX} y2={padTop + innerH / 2} />
      <path d={area} fill="url(#spendFill)" />
      <path className="spend-chart__line" d={line} />
      {daily.map((point, i) =>
        point.charged_micro > 0 ? (
          <circle key={`dot-${point.day}`} className="spend-chart__dot" cx={x(i)} cy={y(point.charged_micro)} r="3" />
        ) : null,
      )}
      {daily.map((point, i) => (
        <rect
          key={`hover-${point.day}`}
          className="spend-chart__hover"
          x={x(i) - step / 2}
          y={0}
          width={step}
          height={h}
          rx="4"
        >
          <title>{`${point.day} · ${formatCredits(point.charged_micro)} ${creditsLabel} · ${point.requests} ${requestsLabel}`}</title>
        </rect>
      ))}
    </svg>
  );

  return (
    <div>
      <span className="spend-chart__max">{`${formatCredits(max)} ${creditsLabel}`}</span>
      {chart}
      <div className="spend-chart__labels">
        {tickIndexes.map((i) => (
          <span key={`tick-${daily[i].day}`}>{daily[i].day.slice(5)}</span>
        ))}
      </div>
    </div>
  );
}

export function Dashboard(): JSX.Element {
  const { t, locale } = useI18n();
  const { user, meta } = useApp();
  const balance = useApi<Balance>(() => api.get("/api/v1/billing/balance"), []);
  const summary = useApi<DashboardSummary>(() => api.get("/api/v1/dashboard/summary", { days: 30 }), []);
  const capabilities = useApi<{ modules: Record<string, ModuleCapability> }>(() => api.get("/api/v1/modules/capabilities"), []);
  const models = useApi<Paged<CatalogModel>>(() => api.get("/api/v1/models", { page_size: 8 }), []);
  const jobs = useApi<Paged<Job>>(() => api.get("/api/v1/jobs", { page_size: 5 }), []);

  const modules = capabilities.data?.modules || {};
  const moduleEntries = Object.entries(modules);
  const operational = moduleEntries.filter(([, value]) => value.available);
  const unavailable = moduleEntries.filter(([, value]) => !value.available);
  const ready = moduleEntries.length > 0 ? operational.length : 0;

  const kpis = summary.data?.kpis;
  const daily = summary.data?.daily || [];
  const hasSpend = daily.some((point) => point.charged_micro > 0 || point.requests > 0);
  const topModels = summary.data?.top_models || [];
  const topMax = Math.max(...topModels.map((model) => model.charged_micro), 1);
  const recent = summary.data?.recent || [];

  const spentToday = kpis?.spent_today_micro ?? balance.data?.spent_today_micro ?? 0;
  const dailyLimit = kpis?.daily_spend_limit_micro ?? null;
  const todayHint = dailyLimit
    ? `${Math.min(100, Math.round((spentToday / dailyLimit) * 100))}% ${t("dash.ofDailyLimit")} (${formatCredits(dailyLimit)})`
    : t("label.credits");

  return (
    <div className="stack">
      <section className="hero">
        <div className="hero__content">
          <span className="eyebrow">
            <Icon name="sparkles" size={14} />
            {meta?.app_name || t("app.name")}
          </span>
          <h1 className="hero__title">
            {t("hero.welcome")}
            {user?.display_name ? `، ${user.display_name}` : user?.email ? `، ${user.email}` : ""}
          </h1>
          <p className="hero__text">
            {t("app.tagline")} · {operational.length}/{moduleEntries.length || "—"} {t("label.modules")}
            {unavailable.length > 0 ? ` · ${unavailable.length} ${t("common.notConfigured")}` : ""}
          </p>
        </div>
        <div className="row">
          <span className="muted small">{t("hero.quickActions")}:</span>
          {QUICK_ACTIONS.map((action) => (
            <Link key={action.to} className="chip" to={action.to}>
              <Icon name={action.icon} size={15} />
              {t(action.key)}
            </Link>
          ))}
        </div>
      </section>

      <div className="grid grid--5">
        <Stat
          icon="wallet"
          label={t("billing.balance")}
          value={`${balance.data?.balance_display ?? formatCredits(kpis?.balance_micro ?? 0)} ${balance.data?.credit_display_name ?? t("label.credits")}`}
          hint={balance.data?.is_frozen ? t("warning.deploymentTitle") : t("billing.manualNote")}
          tone={balance.data?.is_frozen ? "danger" : undefined}
        />
        <Stat
          icon="chart-line"
          label={`${t("nav.usage")} · ${t("label.today")}`}
          value={formatCredits(spentToday)}
          hint={todayHint}
          tone={dailyLimit && spentToday >= dailyLimit ? "warning" : undefined}
        />
        <Stat
          icon="data"
          label={t("dash.spentWindow")}
          value={formatCredits(kpis?.spent_window_micro ?? 0)}
          hint={t("label.credits")}
        />
        <Stat
          icon="bolt"
          label={t("dash.requestsWindow")}
          value={(kpis?.requests_window ?? 0).toLocaleString(locale)}
          hint={t("dash.requests")}
        />
        <Stat
          icon="brain"
          label={t("dash.tokensWindow")}
          value={(kpis?.tokens_window ?? 0).toLocaleString(locale)}
          hint={t("label.tokens")}
        />
      </div>

      <div className="grid grid--2">
        <Card
          icon="chart-line"
          title={t("dash.spendTrend")}
          subtitle={t("dash.spendTrendHint")}
          actions={<Link to="/app/usage">{t("nav.usage")}</Link>}
        >
          {summary.loading ? (
            <Progress value={0} max={100} label={t("status.loading")} />
          ) : !hasSpend ? (
            <EmptyState
              icon="chart-line"
              title={t("status.empty")}
              hint={t("dash.noUsage")}
              action={<Link className="btn btn--primary" to="/app/chat">{t("nav.chat")}</Link>}
            />
          ) : (
            <SpendChart daily={daily} creditsLabel={t("label.credits")} requestsLabel={t("dash.requests")} />
          )}
        </Card>

        <Card
          icon="brain"
          title={t("dash.topModels")}
          subtitle={t("dash.topModelsHint")}
          actions={<Link to="/app/models">{t("nav.catalog")}</Link>}
        >
          {summary.loading ? (
            <Progress value={0} max={100} label={t("status.loading")} />
          ) : topModels.length === 0 ? (
            <EmptyState icon="brain" title={t("status.empty")} hint={t("dash.noUsage")} />
          ) : (
            <div className="stack stack--tight">
              {topModels.map((model) => (
                <div className="topbar" key={model.name}>
                  <span className="topbar__name" title={model.name}>{model.name}</span>
                  <span className="topbar__track">
                    <span
                      className="topbar__fill"
                      style={{ width: `${Math.max((model.charged_micro / topMax) * 100, 2)}%` }}
                    />
                  </span>
                  <span className="topbar__value mono small">
                    {formatCredits(model.charged_micro)} · {model.requests.toLocaleString(locale)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      <Card
        icon="list"
        title={t("dash.recentActivity")}
        subtitle={t("dash.recentHint")}
        actions={<Link to="/app/usage">{t("common.all")}</Link>}
      >
        {summary.loading ? (
          <Progress value={0} max={100} label={t("status.loading")} />
        ) : recent.length === 0 ? (
          <EmptyState icon="list" title={t("status.empty")} hint={t("dash.noUsage")} />
        ) : (
          <div className="table-wrap table-wrap--stack">
            <table className="table table--stack">
              <thead>
                <tr>
                  <th>{t("dash.colWhen")}</th>
                  <th>{t("label.model")}</th>
                  <th>{t("dash.colModule")}</th>
                  <th>{t("label.tokens")}</th>
                  <th>{t("label.credits")}</th>
                  <th>{t("dash.colLatency")}</th>
                  <th>{t("label.status")}</th>
                </tr>
              </thead>
              <tbody>
                {recent.map((row) => (
                  <tr key={row.id}>
                    <td className="muted small" data-label={t("dash.colWhen")}>
                      {row.created_at ? formatDateTime(row.created_at, locale) : "—"}
                    </td>
                    <td data-label={t("label.model")}>{row.model}</td>
                    <td data-label={t("dash.colModule")}>
                      <span className="row" style={{ gap: "0.4rem" }}>
                        <Icon name={MODULE_ICONS[row.module] || "bolt"} size={14} />
                        {humanize(row.operation)}
                      </span>
                    </td>
                    <td className="mono" data-label={t("label.tokens")}>{row.total_tokens.toLocaleString(locale)}</td>
                    <td className="mono" data-label={t("label.credits")}>{formatCredits(row.charged_micro)}</td>
                    <td className="mono" data-label={t("dash.colLatency")}>
                      {row.latency_ms != null ? `${row.latency_ms.toLocaleString(locale)} ms` : "—"}
                    </td>
                    <td data-label={t("label.status")}><StatusBadge value={row.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <div className="grid grid--2">
        <Card
          icon="cpu"
          title={t("label.modules")}
          subtitle="Reported by the backend from the real provider/model configuration."
        >
          {capabilities.loading ? (
            <Progress value={0} max={100} label={t("status.loading")} />
          ) : moduleEntries.length === 0 ? (
            <EmptyState icon="cpu" hint={t("common.notConfigured")} />
          ) : (
            <div className="stack stack--tight">
              <Progress
                value={operational.length}
                max={moduleEntries.length}
                label={`${operational.length}/${moduleEntries.length}`}
                tone={operational.length === moduleEntries.length ? "success" : "warning"}
              />
              <ul className="stack stack--tight" style={{ listStyle: "none", padding: 0, margin: "0.4rem 0 0" }}>
                {moduleEntries.map(([key, module]) => (
                  <li key={key} className="row row--between">
                    <span className="row" style={{ gap: "0.5rem" }}>
                      <Icon name={MODULE_ICONS[key] || "bolt"} size={16} />
                      {module.label}
                    </span>
                    {module.available ? (
                      <Badge tone="success">{module.options.length}</Badge>
                    ) : (
                      <Badge tone="warning">{t("common.notConfigured")}</Badge>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </Card>

        <Card
          icon="list"
          title={t("nav.jobs")}
          subtitle="Background work (images, audio, video, documents, exports)."
          actions={<Link to="/app/jobs">{t("common.all")}</Link>}
        >
          {jobs.loading ? (
            <EmptyState icon="list" hint={t("status.loading")} />
          ) : jobs.data && jobs.data.items.length === 0 ? (
            <EmptyState icon="list" title={t("status.empty")} hint={t("nav.jobs")} />
          ) : (
            <ul className="stack stack--tight" style={{ listStyle: "none", padding: 0, margin: 0 }}>
              {(jobs.data?.items || []).map((job) => (
                <li key={job.id} className="row row--between">
                  <span className="row" style={{ gap: "0.5rem" }}>
                    <Icon name="bolt" size={15} />
                    <span className="mono small">#{job.id}</span>
                    {job.type}
                  </span>
                  <Badge tone={job.status === "succeeded" ? "success" : job.status === "failed" ? "danger" : "warning"}>
                    {job.status}
                  </Badge>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <Card
        icon="brain"
        title={t("nav.catalog")}
        subtitle="Priced and permission-filtered server-side."
        actions={<Link to="/app/models">{t("common.all")}</Link>}
      >
        {models.data && models.data.items.length === 0 ? (
          <EmptyState icon="brain" hint={t("chat.noModels")} />
        ) : (
          <div className="table-wrap table-wrap--stack">
            <table className="table table--stack">
              <thead>
                <tr>
                  <th>{t("label.model")}</th>
                  <th>{t("label.provider")}</th>
                  <th>{t("label.tier")}</th>
                  <th>Input / 1M</th>
                  <th>{t("label.status")}</th>
                </tr>
              </thead>
              <tbody>
                {(models.data?.items || []).map((model) => (
                  <tr key={model.id}>
                    <td data-label={t("label.model")}>
                      <Link to={`/app/models/${model.id}`}>{model.display_name}</Link>
                    </td>
                    <td className="muted" data-label={t("label.provider")}>{model.provider}</td>
                    <td data-label={t("label.tier")}>
                      <Badge tone={model.access_tier === "free" ? "success" : "info"}>{model.access_tier}</Badge>
                    </td>
                    <td className="mono" data-label="Input / 1M">{model.pricing?.input_credits_per_mtok ?? "—"}</td>
                    <td data-label={t("label.status")}>
                      {model.accessible ? (
                        <Badge tone="success">{t("status.available")}</Badge>
                      ) : (
                        <Badge tone="warning">{accessReason(t, model, "short")}</Badge>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
