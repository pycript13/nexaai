import React, { useState } from "react";
import { api, downloadFile } from "../api/client";
import type { StoredFile } from "../api/types";
import { Badge, Button, Card, ErrorNotice, Field } from "../components/ui";
import { ModuleNotice, useCatalog } from "./shared";
import { ModelNotice } from "./moduleHelpers";
import { useApp, useI18n } from "../state/app";

export function Images(): JSX.Element {
  const { t } = useI18n();
  const { notify } = useApp();
  const catalog = useCatalog();
  const [tab, setTab] = useState<"generate" | "analyze">("generate");
  const [modelId, setModelId] = useState<number | null>(null);
  const [prompt, setPrompt] = useState("");
  const [n, setN] = useState(1);
  const [size, setSize] = useState("");
  const [quality, setQuality] = useState("");
  const [fileId, setFileId] = useState<number | null>(null);
  const [question, setQuestion] = useState("Describe this image in detail.");
  const [files, setFiles] = useState<StoredFile[]>([]);
  const [images, setImages] = useState<{ file_id: number; name: string }[]>([]);
  const [analysis, setAnalysis] = useState<any>(null);
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);

  const generationModels = (catalog.data?.items || []).filter((model) => model.accessible && model.capabilities.includes("image_generation"));
  const visionModels = (catalog.data?.items || []).filter(
    (model) => model.accessible && (model.capabilities.includes("image_understanding") || model.supports_vision),
  );
  const models = tab === "generate" ? generationModels : visionModels;

  React.useEffect(() => {
    if (!models.some((model) => model.id === modelId)) setModelId(models.length ? models[0].id : null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab, models.length]);

  React.useEffect(() => {
    api
      .get<{ items: StoredFile[] }>("/api/v1/files", { page_size: 50, kind: "generated" })
      .then((data) => setFiles(data.items))
      .catch(() => undefined);
  }, [images]);

  const generate = async () => {
    setBusy(true);
    setError(null);
    try {
      const response = await api.post<{ images: { file_id: number; name: string }[]; usage: any; warnings?: string[] }>(
        "/api/v1/modules/image/generate",
        { model_id: modelId, prompt, n, size: size || undefined, quality: quality || undefined },
      );
      setImages(response.images);
      notify("success", `${response.images.length} image(s) generated.`);
      if (response.warnings?.length) response.warnings.forEach((warning) => notify("warning", warning));
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const analyze = async () => {
    setBusy(true);
    setError(null);
    setAnalysis(null);
    try {
      setAnalysis(await api.post("/api/v1/modules/image/analyze", { model_id: modelId, file_id: fileId, question }));
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.images")}</h1>
          <p>Generation and analysis require a provider model that really performs them.</p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      <ModuleNotice capability="images" title={t("nav.images")} />

      <div className="tabs">
        <button className={`tab ${tab === "generate" ? "tab--active" : ""}`} onClick={() => setTab("generate")} type="button">
          Generate
        </button>
        <button className={`tab ${tab === "analyze" ? "tab--active" : ""}`} onClick={() => setTab("analyze")} type="button">
          Analyse an image
        </button>
      </div>

      <div className="grid grid--2">
        <Card title={tab === "generate" ? "Generate an image" : "Analyse an image"}>
          <ModelNotice models={models} value={modelId} onChange={setModelId} capability={tab === "generate" ? "image_generation" : "chat"} />
          {models.length === 0 && (
            <p className="muted">
              No model with <code>{tab === "generate" ? "image_generation" : "image_understanding"}</code> capability is
              available to your account.
            </p>
          )}
          {tab === "generate" ? (
            <>
              <Field label="Prompt">
                <textarea value={prompt} onChange={(event) => setPrompt(event.target.value)} />
              </Field>
              <div className="grid grid--3">
                <Field label="Count">
                  <input type="number" min={1} max={4} value={n} onChange={(event) => setN(Number(event.target.value))} />
                </Field>
                <Field label="Size (optional)">
                  <input value={size} onChange={(event) => setSize(event.target.value)} placeholder="1024x1024" dir="ltr" />
                </Field>
                <Field label="Quality (optional)">
                  <input value={quality} onChange={(event) => setQuality(event.target.value)} placeholder="standard" dir="ltr" />
                </Field>
              </div>
              <Button type="button" onClick={generate} loading={busy} disabled={!modelId || !prompt.trim() || busy}>
                Generate
              </Button>
            </>
          ) : (
            <>
              <Field label="Image file">
                <select value={fileId ?? ""} onChange={(event) => setFileId(event.target.value ? Number(event.target.value) : null)}>
                  <option value="">—</option>
                  {files.map((file) => (
                    <option key={file.id} value={file.id}>
                      {file.original_name}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Question">
                <textarea value={question} onChange={(event) => setQuestion(event.target.value)} />
              </Field>
              <Button type="button" onClick={analyze} loading={busy} disabled={!modelId || !fileId || busy}>
                Analyse
              </Button>
            </>
          )}
        </Card>

        <Card title="Gallery" subtitle="Images are private files served through the authenticated API.">
          {files.length === 0 && images.length === 0 ? (
            <p className="muted">{t("status.empty")}</p>
          ) : (
            <div className="grid grid--3">
              {(images.length ? images.map((item) => item.file_id) : files.map((file) => file.id)).map((id) => (
                <div key={id} className="stack">
                  <img className="thumb" alt={`generated-${id}`} src={`/api/v1/files/${id}/download`} />
                  <Button
                    variant="ghost"
                    type="button"
                    onClick={() => downloadFile(`/api/v1/files/${id}/download`, `image-${id}.png`)}
                  >
                    {t("action.download")}
                  </Button>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      {analysis && (
        <Card title="Analysis" actions={<Badge tone="info">charged {analysis.usage?.charged_micro ?? 0}</Badge>}>
          <p>{analysis.analysis}</p>
        </Card>
      )}
    </div>
  );
}
