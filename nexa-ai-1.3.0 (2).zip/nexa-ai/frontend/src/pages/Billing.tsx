import { Link } from "react-router-dom";
import { api } from "../api/client";
import type { Balance, LedgerEntry, Pagination as PaginationMeta } from "../api/types";
import { Badge, Card, DataTable, ErrorNotice, Pagination, Spinner, Stat, useApi } from "../components/ui";
import { Donut } from "../components/charts";
import { formatCredits, formatDateTime } from "../utils/format";
import { useI18n } from "../state/app";
import { useState } from "react";

const ENTRY_LABEL: Record<string, string> = {
  deposit: "Deposit",
  usage_charge: "Usage charge",
  admin_grant: "Administrator grant",
  adjustment: "Adjustment",
  refund: "Refund",
  subscription_credit: "Subscription credit",
};

export function Billing(): JSX.Element {
  const { t, locale } = useI18n();
  const [page, setPage] = useState(1);
  const balance = useApi<Balance>(() => api.get("/api/v1/billing/balance"), []);
  const ledger = useApi<{ items: LedgerEntry[]; pagination: PaginationMeta }>(
    () => api.get("/api/v1/billing/ledger", { page, page_size: 20 }),
    [page],
  );

  if (balance.loading) return <Spinner />;
  if (balance.error) return <ErrorNotice error={balance.error} onRetry={balance.reload} />;
  const data = balance.data!;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.billing")}</h1>
          <p>
            Credits are stored as integer micro-credits and every balance change has an immutable ledger entry. Nothing is
            credited from a redirect alone.
          </p>
        </div>
        <div className="row">
          <Link className="btn" to="/app/payments">
            {t("billing.addCredits")}
          </Link>
          <Link className="btn btn--subtle" to="/app/usage">
            {t("nav.usage")}
          </Link>
        </div>
      </div>

      <div className="grid grid--4">
        <Stat
          label={t("billing.balance")}
          value={`${data.balance_display} ${data.credit_display_name}`}
          hint={`1 ${data.credit_display_name} = ${data.credit_usd_rate} USD`}
          tone={data.is_frozen ? "danger" : undefined}
        />
        <Stat label="Deposited (lifetime)" value={formatCredits(data.lifetime_deposited_micro)} />
        <Stat label="Spent today" value={formatCredits(data.spent_today_micro)} hint={`Limit: ${data.daily_spend_limit_micro ? formatCredits(data.daily_spend_limit_micro) : "none"}`} />
        <Stat label="Spent this month" value={formatCredits(data.spent_month_micro)} hint={`Limit: ${data.monthly_spend_limit_micro ? formatCredits(data.monthly_spend_limit_micro) : "none"}`} />
      </div>

      {data.is_frozen && (
        <div className="alert alert--error">
          <div>
            <strong>This account is frozen.</strong>
            <p>New AI requests and payments are blocked until an administrator unfreezes the account.</p>
          </div>
        </div>
      )}

      <div className="grid grid--2">
        <Card title="Lifetime activity">
          <Donut
            segments={[
              { label: "Spent", value: data.lifetime_spent_micro, color: "#f97316" },
              { label: "Deposited", value: data.lifetime_deposited_micro, color: "#4f46e5" },
            ]}
          />
          <p className="muted small">
            Deposit statistics come from approved payments only (micro-credits, exact integers).
          </p>
        </Card>
        <Card title={t("nav.subscriptions")} subtitle="Plan-based quotas and premium model access.">
          {data.subscription ? (
            <div className="kv">
              {Object.entries(data.subscription).map(([key, value]) => (
                <div key={key}>
                  <span>{key}</span>
                  <span>{String(value)}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="muted">
              No active subscription. <Link to="/app/subscriptions">See the plans</Link>.
            </p>
          )}
        </Card>
      </div>

      <Card title={t("billing.ledger")} subtitle="Append-only: entries can never be edited or deleted from the UI or the API.">
        <DataTable
          rows={ledger.data?.items || []}
          loading={ledger.loading}
          columns={[
            { key: "created", header: t("label.created"), render: (row) => formatDateTime(row.created_at, locale) },
            { key: "type", header: "Type", render: (row) => <Badge tone={row.amount_micro < 0 ? "warning" : "success"}>{ENTRY_LABEL[row.type] || row.type}</Badge> },
            { key: "description", header: "Description", render: (row) => <span>{row.description}</span> },
            {
              key: "amount",
              header: t("label.amount"),
              render: (row) => (
                <span className="mono" style={{ color: row.amount_micro < 0 ? "var(--danger)" : "var(--success)" }}>
                  {row.amount_micro > 0 ? "+" : ""}
                  {formatCredits(row.amount_micro)}
                </span>
              ),
            },
            { key: "balance", header: "Balance after", render: (row) => <span className="mono">{formatCredits(row.balance_after_micro)}</span> },
          ]}
        />
        <Pagination meta={ledger.data?.pagination} onChange={setPage} />
      </Card>
    </div>
  );
}
