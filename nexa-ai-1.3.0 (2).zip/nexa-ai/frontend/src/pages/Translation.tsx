import React, { useState } from "react";
import { api } from "../api/client";
import { Button, Card, ErrorNotice, Field } from "../components/ui";
import { ModuleNotice, NoModelsHint, useCatalog, UsageLine } from "./shared";
import { ModelNotice } from "./moduleHelpers";
import { useI18n } from "../state/app";

const LANGUAGES = [
  "Persian",
  "English",
  "Arabic",
  "Kurdish (Sorani)",
  "Turkish",
  "French",
  "German",
  "Spanish",
  "Russian",
  "Chinese",
];

export function Translation(): JSX.Element {
  const { t } = useI18n();
  const catalog = useCatalog();
  const [modelId, setModelId] = useState<number | null>(null);
  const [text, setText] = useState("");
  const [batch, setBatch] = useState("");
  const [source, setSource] = useState("auto");
  const [target, setTarget] = useState("English");
  const [tone, setTone] = useState("");
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);

  const models = (catalog.data?.items || []).filter((model) => model.accessible && model.capabilities.includes("chat"));
  React.useEffect(() => {
    if (modelId === null && models.length > 0) setModelId(models[0].id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [models.length]);

  const run = async () => {
    setBusy(true);
    setError(null);
    try {
      const texts = batch.trim() ? batch.split("\n").filter((line) => line.trim()) : undefined;
      setResult(
        await api.post("/api/v1/modules/translation/translate", {
          model_id: modelId,
          text: texts ? undefined : text,
          texts,
          source_language: source,
          target_language: target,
          tone: tone || undefined,
        }),
      );
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.translation")}</h1>
          <p>Translation is performed by the configured chat model. Language detection is only claimed when a source language is provided.</p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      {!catalog.loading && models.length === 0 && <NoModelsHint />}
      <ModuleNotice capability="translation" title={t("nav.translation")} />

      <div className="grid grid--2">
        <Card title="Input">
          <ModelNotice models={models} value={modelId} onChange={setModelId} />
          <div className="grid grid--2">
            <Field label="Source language">
              <select value={source} onChange={(event) => setSource(event.target.value)}>
                <option value="auto">auto (not independently detected)</option>
                {LANGUAGES.map((language) => (
                  <option key={language} value={language}>
                    {language}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Target language">
              <select value={target} onChange={(event) => setTarget(event.target.value)}>
                {LANGUAGES.map((language) => (
                  <option key={language} value={language}>
                    {language}
                  </option>
                ))}
              </select>
            </Field>
          </div>
          <Field label="Tone (optional)">
            <input value={tone} onChange={(event) => setTone(event.target.value)} placeholder="formal, neutral…" />
          </Field>
          <Field label="Single text">
            <textarea value={text} onChange={(event) => setText(event.target.value)} />
          </Field>
          <Field label="Batch (one item per line, max 50)">
            <textarea value={batch} onChange={(event) => setBatch(event.target.value)} />
          </Field>
          <Button type="button" onClick={run} loading={busy} disabled={!modelId || busy || (!text.trim() && !batch.trim())}>
            Translate
          </Button>
        </Card>

        <Card title="Translation">
          {!result ? (
            <p className="muted">Results appear here.</p>
          ) : (
            <div className="stack">
              {(result.items || []).map((item: any, index: number) => (
                <div className="bubble bubble--assistant" key={index}>
                  <p className="muted small">{item.source}</p>
                  <p>{item.translation}</p>
                  {item.detected_source_language ? (
                    <p className="muted small">detected source: {item.detected_source_language}</p>
                  ) : (
                    <p className="muted small">{item.detection_note}</p>
                  )}
                </div>
              ))}
              <UsageLine usage={result.usage} />
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
