import React, { useState } from "react";
import { api } from "../api/client";
import { Badge, Button, Card, ErrorNotice, Field } from "../components/ui";
import { Markdown } from "../components/Markdown";
import { ModelNotice } from "./moduleHelpers";
import { ModuleNotice, NoModelsHint, useCatalog, UsageLine } from "./shared";
import { useI18n } from "../state/app";

const MODES = ["generate", "explain", "refactor", "debug", "review", "test"];

export function Coding(): JSX.Element {
  const { t } = useI18n();
  const catalog = useCatalog();
  const [modelId, setModelId] = useState<number | null>(null);
  const [mode, setMode] = useState("generate");
  const [prompt, setPrompt] = useState("");
  const [code, setCode] = useState("");
  const [language, setLanguage] = useState("");
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);

  const models = (catalog.data?.items || []).filter((model) => model.accessible && model.capabilities.includes("chat"));
  React.useEffect(() => {
    if (modelId === null && models.length > 0) setModelId(models[0].id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [models.length]);

  const run = async () => {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      setResult(
        await api.post("/api/v1/modules/coding/assist", {
          model_id: modelId,
          mode,
          prompt,
          code: code || undefined,
          language: language || undefined,
        }),
      );
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.coding")}</h1>
          <p>
            Code is generated or reviewed by a configured chat model. Nexa AI never executes generated code on the
            server; review and run it in your own environment.
          </p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      {!catalog.loading && models.length === 0 && <NoModelsHint />}
      <ModuleNotice capability="coding" title={t("nav.coding")} />

      <div className="grid grid--2">
        <Card title="Request">
          <ModelNotice models={models} value={modelId} onChange={setModelId} />
          <Field label="Mode">
            <select value={mode} onChange={(event) => setMode(event.target.value)}>
              {MODES.map((entry) => (
                <option key={entry} value={entry}>
                  {entry}
                </option>
              ))}
            </select>
          </Field>
          <Field label="What should the model do?">
            <textarea value={prompt} onChange={(event) => setPrompt(event.target.value)} />
          </Field>
          <Field label="Language / runtime (optional)">
            <input value={language} onChange={(event) => setLanguage(event.target.value)} placeholder="python, typescript, bash…" />
          </Field>
          <Field label="Existing code (optional)">
            <textarea value={code} onChange={(event) => setCode(event.target.value)} style={{ minHeight: 160 }} dir="ltr" />
          </Field>
          <Button type="button" onClick={run} loading={busy} disabled={!modelId || !prompt.trim() || busy}>
            {t("action.send")}
          </Button>
        </Card>

        <Card title="Result" actions={result?.usage ? <Badge tone="info">charged {result.usage.charged_micro}</Badge> : undefined}>
          {!result ? (
            <p className="muted">The model response appears here. Nothing is executed server-side.</p>
          ) : (
            <>
              <Markdown text={result.response || ""} />
              <UsageLine usage={result.usage} />
              <p className="muted small">{result.safety_note}</p>
            </>
          )}
        </Card>
      </div>
    </div>
  );
}
