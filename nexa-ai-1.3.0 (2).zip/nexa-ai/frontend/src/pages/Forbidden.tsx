import { useI18n } from "../state/app";
import { Card } from "../components/ui";

export function Forbidden({ required, message }: { required?: string[]; message?: string }): JSX.Element {
  const { t } = useI18n();
  return (
    <Card title={t("error.permissionTitle")}>
      <p>{message || t("error.permissionBody")}</p>
      {required && required.length > 0 && (
        <p className="muted small">
          Required permission{required.length > 1 ? "s" : ""}: <code className="mono">{required.join(", ")}</code>
        </p>
      )}
      <p className="muted small">
        The navigation only shows pages your role can use; this page was opened by direct URL or by a stale session.
      </p>
    </Card>
  );
}
