import React, { useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api/client";
import { Button, ErrorNotice, Field } from "../components/ui";
import { AuthShell } from "../components/auth";

export function VerifyEmail(): JSX.Element {
  const [token, setToken] = useState("");
  const [email, setEmail] = useState("");
  const [error, setError] = useState<unknown>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const verify = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const response = await api.post<{ message?: string }>("/api/v1/auth/email/verify", { token });
      setStatus(response?.message || "Email verified.");
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const requestNew = async () => {
    setBusy(true);
    setError(null);
    try {
      const response = await api.post<{ message?: string; verification_token?: string | null }>(
        "/api/v1/auth/email/verify-request",
        { email },
      );
      setStatus(
        response?.verification_token
          ? `${response.message} Verification token (email delivery not configured): ${response.verification_token}`
          : response?.message || "Request received.",
      );
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthShell title="Verify your email address" subtitle="Confirm the address that was used to register the account.">
      {error ? <ErrorNotice error={error} /> : null}
      {status && (
        <div className="alert alert--success" role="status">
          <div className="alert__body">
            <div>
              <strong>{status}</strong>
            </div>
          </div>
        </div>
      )}
      <form onSubmit={verify}>
        <Field label="Verification token">
          <input value={token} onChange={(e) => setToken(e.target.value)} required dir="ltr" />
        </Field>
        <Button type="submit" loading={busy} disabled={busy} className="btn--block">
          Verify email
        </Button>
      </form>
      <hr />
      <Field label="Request a new token">
        <input type="email" dir="ltr" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
      </Field>
      <Button variant="ghost" type="button" onClick={requestNew} disabled={!email || busy} className="btn--block">
        Send a new verification token
      </Button>
      <p style={{ marginTop: "0.95rem" }}>
        <Link to="/login">Back to sign in</Link>
      </p>
    </AuthShell>
  );
}
