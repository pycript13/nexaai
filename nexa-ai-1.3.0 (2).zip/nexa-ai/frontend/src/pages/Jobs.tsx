import { useState } from "react";
import { api } from "../api/client";
import type { Job, Pagination as PaginationMeta } from "../api/types";
import { Badge, Button, Card, DataTable, ErrorNotice, Pagination, Spinner, Stat, useApi } from "../components/ui";
import { formatCredits, formatDateTime } from "../utils/format";
import { useApp, useI18n } from "../state/app";

export function Jobs(): JSX.Element {
  const { t, locale } = useI18n();
  const { notify } = useApp();
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState("");
  const [selected, setSelected] = useState<Job | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const jobs = useApi<{ items: Job[]; pagination: PaginationMeta }>(
    () => api.get("/api/v1/jobs", { page, page_size: 20, status: status || undefined }),
    [page, status],
  );

  const cancel = async (jobId: number) => {
    setBusy(true);
    setError(null);
    try {
      await api.post(`/api/v1/jobs/${jobId}/cancel`);
      notify("success", `Job ${jobId} cancelled`);
      jobs.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (jobs.loading) return <Spinner />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.jobs")}</h1>
          <p>Jobs are stored in the database, claimed atomically by the worker and charged only on success.</p>
        </div>
        <Button variant="subtle" type="button" onClick={jobs.reload}>
          {t("action.refresh")}
        </Button>
      </div>

      {error ? <ErrorNotice error={error} /> : null}

      <div className="grid grid--4">
        <Stat label="Total" value={jobs.data?.pagination?.total ?? 0} />
        <Stat label="Running" value={(jobs.data?.items || []).filter((job) => job.status === "running").length} />
        <Stat label="Failed" value={(jobs.data?.items || []).filter((job) => job.status === "failed").length} tone="danger" />
        <Stat
          label={t("label.charged")}
          value={formatCredits((jobs.data?.items || []).reduce((sum, job) => sum + (job.charged_micro || 0), 0))}
        />
      </div>

      <Card title={t("action.filter")}>
        <label className="field">
          <span className="field__label">{t("label.status")}</span>
          <select value={status} onChange={(event) => setStatus(event.target.value)}>
            <option value="">{t("common.all")}</option>
            <option value="pending">pending</option>
            <option value="running">running</option>
            <option value="succeeded">succeeded</option>
            <option value="failed">failed</option>
            <option value="cancelled">cancelled</option>
          </select>
        </label>
      </Card>

      <Card title={t("jobs.queue")}>
        <DataTable
          rows={jobs.data?.items || []}
          columns={[
            { key: "id", header: "#", render: (row) => row.id },
            { key: "type", header: "Type", render: (row) => <span className="mono">{row.type}</span> },
            {
              key: "status",
              header: t("label.status"),
              render: (row) => (
                <Badge tone={row.status === "succeeded" ? "success" : row.status === "failed" ? "danger" : "warning"}>{row.status}</Badge>
              ),
            },
            { key: "progress", header: "Progress", render: (row) => `${row.progress}%` },
            { key: "attempts", header: "Attempts", render: (row) => row.attempts },
            { key: "charged", header: t("label.charged"), render: (row) => formatCredits(row.charged_micro || 0) },
            { key: "created", header: t("label.created"), render: (row) => formatDateTime(row.created_at, locale) },
            {
              key: "actions",
              header: t("label.actions"),
              render: (row) => (
                <div className="row">
                  <Button variant="ghost" type="button" onClick={() => setSelected(row)}>
                    {t("label.detail")}
                  </Button>
                  {row.status === "pending" && (
                    <Button variant="danger" type="button" onClick={() => cancel(row.id)} disabled={busy}>
                      {t("action.cancel")}
                    </Button>
                  )}
                </div>
              ),
            },
          ]}
        />
        <Pagination meta={jobs.data?.pagination} onChange={setPage} />
      </Card>

      {selected && (
        <Card title={`#${selected.id} · ${selected.type}`} actions={<Badge tone="info">{selected.status}</Badge>}>
          <div className="kv">
            <div>
              <span>{t("label.created")}</span>
              <span>{formatDateTime(selected.created_at, locale)}</span>
            </div>
            <div>
              <span>Finished</span>
              <span>{formatDateTime(selected.finished_at, locale)}</span>
            </div>
            {selected.error_category && (
              <div>
                <span>{selected.error_category}</span>
                <span>{selected.error_message}</span>
              </div>
            )}
          </div>
          {selected.result ? <pre className="md__code">{JSON.stringify(selected.result, null, 2).slice(0, 4000)}</pre> : null}
        </Card>
      )}
    </div>
  );
}
