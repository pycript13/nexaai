import React from "react";
import { useParams } from "react-router-dom";
import { api } from "../api/client";
import { Card, Spinner, useApi } from "../components/ui";

interface SharedLinkView {
  title: string;
  permission: string;
  messages: { role: string; content: string; created_at: string }[];
}

/** Public read-only view of a conversation shared via link (no account needed). */
export function SharedLink(): JSX.Element {
  const { token } = useParams();
  const view = useApi<SharedLinkView>(() => api.get(`/api/v1/chat/shared/link/${token}`), [token]);
  if (view.loading) return <Spinner />;
  if (view.error || !view.data) {
    return (
      <div className="page" style={{ maxWidth: 640, margin: "3rem auto" }}>
        <Card title="لینک در دسترس نیست" icon="lock">
          <p className="muted">این لینک اشتراک منقضی یا لغو شده است.</p>
        </Card>
      </div>
    );
  }
  return (
    <div className="page" style={{ maxWidth: 820, margin: "2rem auto" }}>
      <Card title={view.data.title} icon="share">
        <div className="stack">
          {view.data.messages.map((message, index) => (
            <div key={index} className={message.role === "user" ? "msg msg--user" : "msg"}>
              <strong>{message.role === "user" ? "کاربر" : message.role === "assistant" ? "دستیار" : message.role}</strong>
              <p dir="auto" style={{ whiteSpace: "pre-wrap" }}>{message.content}</p>
            </div>
          ))}
          {!view.data.messages.length ? <p className="muted">هنوز پیامی در این گفتگو نیست.</p> : null}
        </div>
      </Card>
    </div>
  );
}
