import React, { useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api/client";
import { useApp } from "../state/app";
import { Button, ErrorNotice, Field, SuccessNotice } from "../components/ui";
import { AuthShell } from "../components/auth";

export function ForgotPassword(): JSX.Element {
  const { meta } = useApp();
  const [email, setEmail] = useState("");
  const [token, setToken] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const response = await api.post<{ message?: string; reset_token?: string | null; email_delivery_configured?: boolean }>(
        "/api/v1/auth/password/reset-request",
        { email },
      );
      setMessage(response?.message || "Request received.");
      setToken(response?.reset_token || null);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthShell
      title="Reset your password"
      subtitle={`Enter the email address of your ${meta?.app_name || "Nexa AI"} account. The reset token is delivered by the configured mail transport.`}
    >
      {error ? <ErrorNotice error={error} /> : null}
      {message && (
        <div className="alert alert--success" role="status">
          <div className="alert__body">
            <div>
              <strong>{message}</strong>
              {token ? (
                <>
                  <p className="alert__hint">
                    Email delivery is not configured, so the one-time token is shown here. Use it on the reset page.
                  </p>
                  <code className="mono">{token}</code>
                </>
              ) : null}
            </div>
          </div>
        </div>
      )}
      <form onSubmit={submit}>
        <Field label="Email">
          <input type="email" dir="ltr" value={email} onChange={(e) => setEmail(e.target.value)} required placeholder="you@example.com" />
        </Field>
        <Button type="submit" loading={busy} disabled={busy} className="btn--block">
          Request reset token
        </Button>
      </form>
      <p style={{ marginTop: "0.95rem" }}>
        <Link to="/reset-password">I already have a token</Link> · <Link to="/login">Back to sign in</Link>
      </p>
    </AuthShell>
  );
}
