import React, { useState } from "react";
import { api, downloadFile } from "../api/client";
import type { Pagination as PaginationMeta, StoredFile } from "../api/types";
import { Badge, Button, Card, DataTable, ErrorNotice, Field, Pagination, Spinner, Stat, useApi } from "../components/ui";
import { formatBytes, formatDateTime } from "../utils/format";
import { useApp, useI18n } from "../state/app";

interface StorageSummary {
  used_bytes: number;
  quota_bytes: number;
  retention_days: number | null;
  malware_scanning: { enabled: boolean; note?: string };
  by_kind: Record<string, { count: number; bytes: number }>;
}

export function Files(): JSX.Element {
  const { t, locale } = useI18n();
  const { notify } = useApp();
  const [page, setPage] = useState(1);
  const list = useApi<{ items: StoredFile[]; pagination: PaginationMeta; storage: StorageSummary }>(
    () => api.get("/api/v1/files", { page, page_size: 20 }),
    [page],
  );
  const [kind, setKind] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);

  const upload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append("file", file);
    form.append("kind", kind || "upload");
    setBusy(true);
    setError(null);
    try {
      await api.upload("/api/v1/files", form);
      notify("success", `Uploaded ${file.name}`);
      list.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
      event.target.value = "";
    }
  };

  const extract = async (fileId: number) => {
    setBusy(true);
    setError(null);
    try {
      const response = await api.post<{ text: string; characters: number }>(`/api/v1/files/${fileId}/extract`);
      notify("success", `Extracted ${response.characters} characters`);
      list.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const remove = async (fileId: number) => {
    if (!window.confirm(t("common.confirmDelete"))) return;
    setBusy(true);
    try {
      await api.del(`/api/v1/files/${fileId}`);
      notify("success", t("common.deleted"));
      list.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (list.loading) return <Spinner />;

  const storage = list.data?.storage;
  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.files")}</h1>
          <p>Files are stored outside the web root and served only through the authenticated API with ownership checks.</p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}

      <div className="grid grid--4">
        <Stat label={t("files.quota")} value={`${formatBytes(storage?.used_bytes)} / ${formatBytes(storage?.quota_bytes)}`} />
        <Stat label="Retention" value={storage?.retention_days ? `${storage.retention_days} days` : "keep"} />
        <Stat
          label="Malware scanning"
          value={storage?.malware_scanning?.enabled ? "enabled" : "not configured"}
          tone={storage?.malware_scanning?.enabled ? "success" : "warning"}
          hint={storage?.malware_scanning?.note}
        />
        <Stat label="Files" value={list.data?.pagination?.total ?? list.data?.items.length ?? 0} />
      </div>

      <Card title={t("action.upload")}>
        <div className="grid grid--2">
          <Field label="File" hint="Type and size are validated server-side; extensions are allow-listed.">
            <input type="file" onChange={upload} disabled={busy} />
          </Field>
          <Field label="Kind">
            <select value={kind} onChange={(event) => setKind(event.target.value)}>
              <option value="">upload</option>
              <option value="attachment">attachment</option>
              <option value="receipt">receipt</option>
            </select>
          </Field>
        </div>
      </Card>

      <Card title={t("nav.files")}>
        <DataTable
          rows={list.data?.items || []}
          columns={[
            { key: "name", header: "Name", render: (row) => <span>{row.original_name}</span> },
            { key: "kind", header: "Kind", render: (row) => <Badge tone="neutral">{row.kind}</Badge> },
            { key: "size", header: "Size", render: (row) => formatBytes(row.size_bytes) },
            { key: "created", header: t("label.created"), render: (row) => formatDateTime(row.created_at, locale) },
            { key: "private", header: "Private", render: (row) => (row.is_private ? "yes" : "no") },
            {
              key: "actions",
              header: t("label.actions"),
              render: (row) => (
                <div className="row">
                  <Button variant="ghost" type="button" onClick={() => downloadFile(`/api/v1/files/${row.id}/download`, row.original_name)}>
                    {t("action.download")}
                  </Button>
                  <Button variant="ghost" type="button" onClick={() => extract(row.id)} disabled={busy}>
                    Extract text
                  </Button>
                  <Button variant="danger" type="button" onClick={() => remove(row.id)} disabled={busy}>
                    {t("action.delete")}
                  </Button>
                </div>
              ),
            },
          ]}
        />
        <Pagination meta={list.data?.pagination} onChange={setPage} />
      </Card>
    </div>
  );
}
