import React, { useState } from "react";
import { api } from "../api/client";
import type { Pagination as PaginationMeta, Payment } from "../api/types";
import { Badge, Button, Card, DataTable, ErrorNotice, Field, Pagination, Spinner, StatusBadge, useApi } from "../components/ui";
import { formatCredits, formatDateTime, humanize, toMicro } from "../utils/format";
import { useApp, useI18n } from "../state/app";

/**
 * `/billing/payment-methods` returns objects keyed by slug, because the server owns
 * the list of methods and their configuration:
 *   methods:  { manual_bank_transfer: { enabled, status, instructions, verification, ... } }
 *   gateways: { stripe: { configured, live_verified, note, webhook_secret_configured } }
 */
interface MethodConfig {
  enabled: boolean;
  status?: string;
  instructions?: string | null;
  account?: string | null;
  assets?: string[];
  wallets?: Record<string, string>;
  min_confirmations?: number;
  verification?: string;
}

interface GatewayConfig {
  configured: boolean;
  live_verified?: boolean;
  test_mode?: boolean;
  note?: string;
  webhook_secret_configured?: boolean;
}

interface PaymentMethods {
  methods: Record<string, MethodConfig>;
  gateways: Record<string, GatewayConfig>;
  minimum_topup_micro: number;
  maximum_topup_micro: number;
  credit_usd_rate: number;
}

interface MethodEntry extends MethodConfig {
  slug: string;
  label: string;
}

interface GatewayEntry extends GatewayConfig {
  slug: string;
  label: string;
}

function toEntries<T extends object>(source: Record<string, T> | undefined, labelPrefix = ""): (T & { slug: string; label: string })[] {
  return Object.entries(source || {}).map(([slug, value]) => ({
    ...value,
    slug,
    label: `${labelPrefix}${humanize(slug)}`,
  }));
}

export function Payments(): JSX.Element {
  const { t, locale } = useI18n();
  const { notify } = useApp();
  const [page, setPage] = useState(1);
  const methods = useApi<PaymentMethods>(() => api.get("/api/v1/billing/payment-methods"), []);
  const history = useApi<{ items: Payment[]; pagination: PaginationMeta }>(
    () => api.get("/api/v1/billing/payments", { page, page_size: 20 }),
    [page],
  );
  const [form, setForm] = useState({
    amount_credits: "10",
    method: "manual_bank_transfer",
    payer_name: "",
    bank_reference: "",
    crypto_asset: "USDT",
    crypto_network: "TRC20",
    crypto_tx_hash: "",
    note: "",
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [created, setCreated] = useState<Payment | null>(null);
  const [nextSteps, setNextSteps] = useState<string | null>(null);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    setCreated(null);
    try {
      const response = await api.post<{ payment: Payment; next_steps: string }>("/api/v1/billing/payments", {
        amount_micro: toMicro(Number(form.amount_credits)),
        method: form.method,
        payer_name: form.payer_name || undefined,
        bank_reference: form.method === "manual_bank_transfer" ? form.bank_reference || undefined : undefined,
        crypto_asset: form.method === "crypto" ? form.crypto_asset : undefined,
        crypto_network: form.method === "crypto" ? form.crypto_network : undefined,
        crypto_tx_hash: form.method === "crypto" ? form.crypto_tx_hash || undefined : undefined,
        note: form.note || undefined,
      });
      setCreated(response.payment);
      setNextSteps(response.next_steps);
      notify("success", `Payment request ${response.payment.reference} submitted for review.`);
      history.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (methods.loading) return <Spinner />;
  const methodList: MethodEntry[] = toEntries(methods.data?.methods);
  const gatewayList: GatewayEntry[] = toEntries(methods.data?.gateways);
  const enabledMethods = methodList.filter((method) => method.enabled);
  const selectedMethod = methodList.find((method) => method.slug === form.method);

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.payments")}</h1>
          <p>{t("billing.manualNote")}</p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      {created && (
        <div className="alert alert--success">
          <div>
            <strong>Request {created.reference} is {created.status}.</strong>
            <p>{nextSteps}</p>
          </div>
        </div>
      )}

      <div className="grid grid--2">
        <Card title={t("billing.addCredits")} subtitle={`Minimum ${formatCredits(methods.data?.minimum_topup_micro ?? 0)} · maximum ${formatCredits(methods.data?.maximum_topup_micro ?? 0)} credits`}>
          <form onSubmit={submit}>
            <Field label={`Amount in credits (1 credit = ${methods.data?.credit_usd_rate ?? 1} USD)`}>
              <input
                type="number"
                min={1}
                step="0.5"
                value={form.amount_credits}
                onChange={(event) => setForm({ ...form, amount_credits: event.target.value })}
                required
              />
            </Field>
            <Field label={t("label.method")} hint={selectedMethod?.status ? `status: ${humanize(selectedMethod.status)}` : undefined}>
              <select value={form.method} onChange={(event) => setForm({ ...form, method: event.target.value })}>
                {enabledMethods.length === 0 ? <option value="">{t("status.empty")}</option> : null}
                {enabledMethods.map((method) => (
                  <option key={method.slug} value={method.slug}>
                    {method.label}
                  </option>
                ))}
              </select>
            </Field>

            {form.method === "manual_bank_transfer" && (
              <>
                <Field label="Payer name">
                  <input value={form.payer_name} onChange={(event) => setForm({ ...form, payer_name: event.target.value })} />
                </Field>
                <Field label="Bank reference / tracking number" hint="Used by the administrator to match your transfer.">
                  <input value={form.bank_reference} onChange={(event) => setForm({ ...form, bank_reference: event.target.value })} dir="ltr" />
                </Field>
                {methodList.find((method) => method.slug === "manual_bank_transfer")?.instructions && (
                  <p className="muted small">{methodList.find((method) => method.slug === "manual_bank_transfer")?.instructions}</p>
                )}
              </>
            )}

            {form.method === "crypto" && (
              <>
                <div className="grid grid--2">
                  <Field label="Asset">
                    <input value={form.crypto_asset} onChange={(event) => setForm({ ...form, crypto_asset: event.target.value })} dir="ltr" />
                  </Field>
                  <Field label="Network">
                    <input value={form.crypto_network} onChange={(event) => setForm({ ...form, crypto_network: event.target.value })} dir="ltr" />
                  </Field>
                </div>
                <Field label="Transaction hash">
                  <input value={form.crypto_tx_hash} onChange={(event) => setForm({ ...form, crypto_tx_hash: event.target.value })} dir="ltr" />
                </Field>
              </>
            )}

            <Field label={t("label.notes")}>
              <textarea value={form.note} onChange={(event) => setForm({ ...form, note: event.target.value })} />
            </Field>
            <Button type="submit" loading={busy} disabled={busy}>
              Submit for review
            </Button>
          </form>
        </Card>

        <Card title="Available methods" subtitle="Configured by the administrator; unavailable methods are shown as disabled, never hidden silently.">
          <ul className="stack" style={{ listStyle: "none", padding: 0, margin: 0 }}>
            {methodList.map((method) => (
              <li key={method.slug} className="row row--between">
                <span>
                  {method.label}
                  {method.verification ? <span className="muted small"> · {humanize(method.verification)}</span> : null}
                </span>
                {method.enabled ? <Badge tone="success">enabled</Badge> : <Badge tone="warning">not configured</Badge>}
              </li>
            ))}
          </ul>
          <h3 style={{ marginTop: "1rem" }}>Gateways</h3>
          <ul className="stack" style={{ listStyle: "none", padding: 0, margin: 0 }}>
            {gatewayList.map((gateway) => (
              <li key={gateway.slug} className="stack stack--tight">
                <div className="row row--between">
                  <span>
                    {gateway.label} {gateway.test_mode ? <Badge tone="info">test mode</Badge> : null}
                  </span>
                  {gateway.configured ? (
                    <Badge tone="success">{gateway.live_verified ? "configured · live verified" : "configured"}</Badge>
                  ) : (
                    <Badge tone="warning">not configured</Badge>
                  )}
                </div>
                {gateway.note ? <p className="muted small">{gateway.note}</p> : null}
              </li>
            ))}
          </ul>
          <p className="muted small">
            A gateway redirect never credits your balance: only the server-side verification callback can, and it is
            recorded in the ledger.
          </p>
        </Card>
      </div>

      <Card title="My payment requests">
        <DataTable
          rows={history.data?.items || []}
          loading={history.loading}
          columns={[
            { key: "reference", header: "Reference", render: (row) => <span className="mono">{row.reference}</span> },
            { key: "amount", header: t("label.amount"), render: (row) => formatCredits(row.amount_micro) },
            { key: "method", header: t("label.method"), render: (row) => row.method },
            { key: "status", header: t("label.status"), render: (row) => <StatusBadge value={row.status} /> },
            { key: "created", header: t("label.created"), render: (row) => formatDateTime(row.created_at, locale) },
            { key: "reviewed", header: "Reviewed", render: (row) => (row.reviewed_at ? formatDateTime(row.reviewed_at, locale) : "—") },
            { key: "note", header: "Reviewer note", render: (row) => row.review_note || "—" },
          ]}
        />
        <Pagination meta={history.data?.pagination} onChange={setPage} />
      </Card>
    </div>
  );
}
