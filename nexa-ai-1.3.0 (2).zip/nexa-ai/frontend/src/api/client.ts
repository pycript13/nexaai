/**
 * Thin fetch wrapper around the Nexa AI backend.
 *
 * * Always uses relative URLs (`/api/v1/...`) so the same build works behind
 *   Nginx, the Docker Compose stack, the Vite dev proxy and the public-IP mode.
 * * Sends `credentials: "include"` so the httpOnly session cookie is used.
 * * Echoes the CSRF token (returned by /auth/login and /auth/me) in
 *   `X-CSRF-Token` — required for every cookie-authenticated mutating request.
 */
import type { ApiErrorBody } from "./types";

const BASE = (import.meta.env.VITE_API_BASE_URL as string | undefined) || "";

export class ApiError extends Error {
  status: number;
  body: ApiErrorBody;
  constructor(status: number, body: ApiErrorBody) {
    super(body?.message || `Request failed with status ${status}`);
    this.status = status;
    this.body = body;
  }
  get code(): string {
    return this.body?.code || "error";
  }
  get category(): string {
    return this.body?.category || "";
  }
  get details(): Record<string, unknown> {
    return (this.body?.details as Record<string, unknown>) || {};
  }
  /** Machine-readable explanation for configuration/authentication problems. */
  get guidance(): string {
    const details = this.details as Record<string, unknown>;
    const hints: string[] = [];
    if (this.category === "configuration_error") {
      hints.push("An administrator must finish configuring this feature.");
    }
    if (this.category === "authentication") {
      hints.push("Check the provider API key in Admin → Providers.");
    }
    if (details?.code === "insufficient_balance") {
      hints.push("Top up your credit balance under Account → Billing.");
    }
    if (details?.required_permission) {
      hints.push(`Missing permission: ${String(details.required_permission)}`);
    }
    /**
     * Provider failures carry the endpoint that was called and the operator hints the API
     * generated (DNS? firewall? TLS? key?). Showing them turns "Provider connectivity
     * failure:" into something a person can act on. The API knows more than the toast did.
     */
    if (typeof details?.endpoint === "string" && details.endpoint) {
      hints.push(`Endpoint: ${details.endpoint}`);
    }
    const backendHints = Array.isArray(details?.hints)
      ? (details.hints as unknown[]).filter((hint): hint is string => typeof hint === "string" && hint.length > 0)
      : [];
    hints.push(...backendHints);
    if (this.body?.retryable) hints.push("This error is usually temporary — retry shortly.");
    if (hints.length === 0 && this.body?.category_label) hints.push(this.body.category_label);
    return hints.join(" ");
  }
}

let csrfToken: string | null = null;
let onUnauthorized: (() => void) | null = null;

/**
 * The backend sets the CSRF token in a JavaScript-readable cookie (`nexa_csrf`)
 * *and* returns it in the login/register response body. Reading the cookie as a
 * fallback is what keeps mutations working after a page reload or a restored tab,
 * when the in-memory copy is gone but the session cookie is still valid.
 */
const CSRF_COOKIE = "nexa_csrf";

export function readCookie(name: string): string | null {
  if (typeof document === "undefined") return null;
  const match = document.cookie
    .split(";")
    .map((part) => part.trim())
    .find((part) => part.startsWith(`${name}=`));
  if (!match) return null;
  return decodeURIComponent(match.slice(name.length + 1));
}

export function setCsrfToken(token: string | null): void {
  csrfToken = token;
}

/** Current CSRF token: the in-memory copy first, then the session cookie. */
export function getCsrfToken(): string | null {
  return csrfToken || readCookie(CSRF_COOKIE);
}

export function setUnauthorizedHandler(handler: (() => void) | null): void {
  onUnauthorized = handler;
}

type RequestOptions = {
  method?: string;
  body?: unknown;
  query?: Record<string, string | number | boolean | undefined | null>;
  formData?: FormData;
  signal?: AbortSignal;
  raw?: boolean;
};

function buildUrl(path: string, query?: RequestOptions["query"]): string {
  const url = `${BASE}${path}`;
  if (!query) return url;
  const params = new URLSearchParams();
  Object.entries(query).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") params.set(key, String(value));
  });
  const qs = params.toString();
  return qs ? `${url}?${qs}` : url;
}

async function parse(response: Response): Promise<any> {
  const text = await response.text();
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    return { error: { code: "invalid_response", message: text.slice(0, 400) } };
  }
}

export async function request<T = any>(path: string, options: RequestOptions = {}): Promise<T> {
  const headers: Record<string, string> = { Accept: "application/json" };
  const method = (options.method || "GET").toUpperCase();
  let body: BodyInit | undefined;

  if (options.formData) {
    body = options.formData;
  } else if (options.body !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(options.body);
  }
  const token = getCsrfToken();
  if (token && method !== "GET" && method !== "HEAD") {
    headers["X-CSRF-Token"] = token;
  }

  let response: Response;
  try {
    response = await fetch(buildUrl(path, options.query), {
      method,
      headers,
      body,
      credentials: "include",
      signal: options.signal,
    });
  } catch (error) {
    throw new ApiError(0, {
      code: "network_error",
      category: "connectivity",
      message:
        "The API could not be reached from this browser. Check that the backend is running and that you opened the site through the correct address.",
      details: { reason: String(error) },
    });
  }

  if (response.status === 204) return null as T;
  const payload = await parse(response);

  if (!response.ok) {
    const errorBody: ApiErrorBody = payload?.error || {
      code: `http_${response.status}`,
      message: response.statusText || "Request failed",
    };
    // A stale in-memory token (e.g. after the session was re-created in another
    // tab) is recovered once from the cookie; the rejected request never ran, so
    // replaying it cannot duplicate a mutation.
    const code = (errorBody as { code?: string }).code;
    if (
      response.status === 403 &&
      code === "csrf_failed" &&
      method !== "GET" &&
      method !== "HEAD" &&
      options.formData === undefined && // a consumed FormData body cannot be replayed
      csrfToken !== null &&
      readCookie(CSRF_COOKIE) &&
      csrfToken !== readCookie(CSRF_COOKIE)
    ) {
      csrfToken = null;
      return request<T>(path, options);
    }
    if (response.status === 401 && onUnauthorized) onUnauthorized();
    throw new ApiError(response.status, errorBody);
  }

  const newToken = response.headers.get("x-csrf-token");
  if (newToken) csrfToken = newToken;
  if (payload && typeof payload === "object" && typeof payload.csrf_token === "string") {
    csrfToken = payload.csrf_token;
  }
  return payload as T;
}

export const api = {
  get: <T = any>(path: string, query?: RequestOptions["query"]) => request<T>(path, { query }),
  post: <T = any>(path: string, body?: unknown, query?: RequestOptions["query"]) =>
    request<T>(path, { method: "POST", body, query }),
  patch: <T = any>(path: string, body?: unknown) => request<T>(path, { method: "PATCH", body }),
  put: <T = any>(path: string, body?: unknown) => request<T>(path, { method: "PUT", body }),
  del: <T = any>(path: string, query?: RequestOptions["query"]) => request<T>(path, { method: "DELETE", query }),
  upload: <T = any>(path: string, formData: FormData) => request<T>(path, { method: "POST", formData }),
};

/** Download a file through the authenticated API (never a public URL). */
export async function downloadFile(path: string, filename: string): Promise<void> {
  const response = await fetch(buildUrl(path), { credentials: "include" });
  if (!response.ok) {
    const payload = await parse(response);
    throw new ApiError(response.status, payload?.error || { code: "download_failed", message: "Download failed" });
  }
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}
