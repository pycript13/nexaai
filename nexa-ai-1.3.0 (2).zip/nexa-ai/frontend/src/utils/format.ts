/** Formatting helpers. Money is always transported as integer micro-credits. */
export const MICRO = 1_000_000;

export function formatCredits(micro: number | null | undefined, digits = 4): string {
  if (micro === null || micro === undefined) return "—";
  const value = micro / MICRO;
  const fixed = value.toFixed(digits);
  return fixed.replace(/\.?0+$/, "") || "0";
}

export function toMicro(credits: number): number {
  return Math.round(credits * MICRO);
}

/** Inverse of {@link toMicro} — used to show stored micro-credits inside an input. */
export function fromMicro(micro: number | null | undefined): string {
  if (micro === null || micro === undefined) return "";
  const credits = micro / MICRO;
  // 6 decimals is the resolution of a micro-credit; trailing zeros are trimmed so an
  // operator editing a price sees "0.28" rather than "0.280000".
  return String(Number(credits.toFixed(6)));
}

export function formatDateTime(value?: string | null, locale = "fa-IR"): string {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  try {
    return new Intl.DateTimeFormat(locale, { dateStyle: "short", timeStyle: "short" }).format(date);
  } catch {
    return date.toISOString();
  }
}

export function formatBytes(bytes?: number | null): string {
  if (!bytes && bytes !== 0) return "—";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let value = bytes;
  let index = 0;
  while (value >= 1024 && index < units.length - 1) {
    value /= 1024;
    index += 1;
  }
  return `${value.toFixed(index === 0 ? 0 : 1)} ${units[index]}`;
}

export function percent(value?: number | null, digits = 1): string {
  if (value === null || value === undefined) return "—";
  return `${(value * 100).toFixed(digits)}%`;
}

export function formatNumber(value?: number | null): string {
  if (value === null || value === undefined) return "—";
  return new Intl.NumberFormat().format(value);
}

export function relativeTime(value?: string | null): string {
  if (!value) return "—";
  const then = new Date(value).getTime();
  if (Number.isNaN(then)) return "—";
  const seconds = Math.round((Date.now() - then) / 1000);
  const table: [number, Intl.RelativeTimeFormatUnit][] = [
    [60, "second"],
    [3600, "minute"],
    [86400, "hour"],
    [604800, "day"],
    [2592000, "week"],
    [31536000, "month"],
  ];
  const formatter = new Intl.RelativeTimeFormat(undefined, { numeric: "auto" });
  for (const [limit, unit] of table) {
    if (Math.abs(seconds) < limit) {
      const divisor = limit / (unit === "second" ? 60 : 60);
      return formatter.format(-Math.round(seconds / divisor), unit);
    }
  }
  return formatter.format(-Math.round(seconds / 31536000), "year");
}

export function truncate(text: string | null | undefined, length = 120): string {
  if (!text) return "";
  return text.length > length ? `${text.slice(0, length)}…` : text;
}


/**
 * Resolve a value that the API may return either as a plain string or as a
 * per-locale map (`{ fa, en, ar, ckb }` — e.g. `operation_labels` in the model
 * catalogue). Rendering such an object directly is a React crash, so every
 * localized field goes through this helper.
 */
export function localized(value: unknown, locale: string, fallback = ""): string {
  if (typeof value === "string") return value;
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  if (value && typeof value === "object") {
    const map = value as Record<string, unknown>;
    for (const key of [locale, "en", "fa", "ar", "ckb"]) {
      const candidate = map[key];
      if (typeof candidate === "string" && candidate.trim()) return candidate;
    }
    const first = Object.values(map).find((candidate) => typeof candidate === "string" && candidate.trim());
    if (typeof first === "string") return first;
  }
  return fallback;
}

/** Human-readable label for a snake_case API slug (used for payment methods). */
export function humanize(slug: string): string {
  return slug
    .split(/[._-]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}
