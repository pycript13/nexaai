import { en, type TranslationKey } from "./en";
import { fa } from "./fa";
import { ar } from "./ar";
import { ckb } from "./ckb";

export type LocaleCode = "fa" | "en" | "ar" | "ckb";

export interface LocaleMeta {
  code: LocaleCode;
  label: string;
  nativeLabel: string;
  direction: "rtl" | "ltr";
}

export const LOCALES: LocaleMeta[] = [
  { code: "fa", label: "Persian", nativeLabel: "فارسی", direction: "rtl" },
  { code: "en", label: "English", nativeLabel: "English", direction: "ltr" },
  { code: "ar", label: "Arabic", nativeLabel: "العربية", direction: "rtl" },
  { code: "ckb", label: "Kurdish (Sorani)", nativeLabel: "کوردی", direction: "rtl" },
];

export const dictionaries: Record<LocaleCode, Record<TranslationKey, string>> = { fa, en, ar, ckb };

export function isLocale(value: string | null | undefined): value is LocaleCode {
  return value === "fa" || value === "en" || value === "ar" || value === "ckb";
}

export type { TranslationKey };
