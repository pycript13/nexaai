/**
 * Registration policy — one explicit control instead of a raw text box.
 *
 * The sign-up page is the first thing a person the operator shared the link with sees, so the most
 * consequential setting of the console deserves a real control: the three policies are shown as
 * buttons, the *effective* policy comes from the API (`/api/v1/auth/config`, the same endpoint the
 * sign-in screen reads), and a policy this deployment forbids (`NEXA_ALLOWED_REGISTRATION_MODES`)
 * is rendered disabled with the reason instead of failing later with a 422.
 *
 * The card also publishes the very link that was missing in the bug report — “send this to someone
 * and they can create an account” — with a copy button.
 */
import { useState } from "react";
import { api } from "../api/client";
import { Badge, Card, CopyButton, ErrorNotice, Spinner, useApi } from "./ui";
import { Icon } from "./icons";
import { useApp, useI18n } from "../state/app";
import type { TranslationKey } from "../locales";

interface AuthConfig {
  registration_mode: "open" | "invite_only" | "closed";
  registration_enabled: boolean;
  allowed_registration_modes?: string[];
  password_min_length: number;
}

const POLICIES: Array<{ value: string; labelKey: TranslationKey; hintKey: TranslationKey; icon: string }> = [
  { value: "open", labelKey: "admin.registration.mode.open", hintKey: "admin.registration.mode.openHint", icon: "check" },
  { value: "invite_only", labelKey: "admin.registration.mode.invite", hintKey: "admin.registration.mode.inviteHint", icon: "document" },
  { value: "closed", labelKey: "admin.registration.mode.closed", hintKey: "admin.registration.mode.closedHint", icon: "lock" },
];

export function RegistrationPolicyCard(): JSX.Element {
  const { t } = useI18n();
  const { notify, hasPermission } = useApp();
  const config = useApi<AuthConfig>(() => api.get("/api/v1/auth/config"), []);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [saved, setSaved] = useState<string | null>(null);

  const signUpLink = `${window.location.origin}/register`;

  const apply = async (value: string) => {
    setBusy(value);
    setError(null);
    setSaved(null);
    try {
      await api.patch("/api/v1/admin/settings/registration.mode", { value, confirm: true });
      setSaved(value);
      notify("success", t("admin.registration.saved"));
      config.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(null);
    }
  };

  if (config.loading) return <Spinner />;
  if (config.error) return <ErrorNotice error={config.error} onRetry={config.reload} />;

  const current = config.data?.registration_mode || "open";
  const allowed = new Set(config.data?.allowed_registration_modes || POLICIES.map((entry) => entry.value));
  const canEdit = hasPermission("settings.manage");
  const restricted = allowed.size < POLICIES.length;

  return (
    <Card icon="shield" title={t("admin.registration.title")} subtitle={t("admin.registration.note")}>
      {error ? <ErrorNotice error={error} /> : null}

      <div className="policy" role="radiogroup" aria-label={t("admin.registration.title")}>
        {POLICIES.map((policy) => {
          const isCurrent = policy.value === current;
          const isAllowed = allowed.has(policy.value);
          return (
            <button
              key={policy.value}
              type="button"
              role="radio"
              aria-checked={isCurrent}
              className={`policy__option ${isCurrent ? "policy__option--active" : ""}`}
              disabled={!isAllowed || !canEdit || busy !== null || isCurrent}
              title={isAllowed ? undefined : t("admin.registration.locked")}
              onClick={() => apply(policy.value)}
            >
              <span className="policy__head">
                <span className="policy__label">{t(policy.labelKey)}</span>
                {isCurrent ? <Badge tone="success">{t("admin.registration.current")}</Badge> : null}
                {!isAllowed ? <Badge tone="neutral">{t("admin.registration.unavailable")}</Badge> : null}
                {busy === policy.value ? <Spinner /> : null}
              </span>
              <span className="policy__hint muted small">{t(policy.hintKey)}</span>
            </button>
          );
        })}
      </div>

      {saved ? (
        <div className="alert alert--success">
          <div>
            <strong>{t("admin.registration.saved")}</strong>
          </div>
        </div>
      ) : null}

      {restricted ? (
        <div className="alert alert--info">
          <div>
            <strong>{t("admin.registration.locked")}</strong>
            <p className="small mono">NEXA_ALLOWED_REGISTRATION_MODES={[...allowed].join(",")}</p>
          </div>
        </div>
      ) : null}

      {!canEdit ? (
        <p className="muted small">{t("admin.registration.needsPermission")}</p>
      ) : null}

      <div className="share-link">
        <div className="share-link__text">
          <strong>{t("admin.registration.shareLink")}</strong>
          <span className="muted small">{t("admin.registration.shareHint")}</span>
          <code className="share-link__url" dir="ltr">
            {signUpLink}
          </code>
        </div>
        <div className="row">
          <CopyButton value={signUpLink} label={t("action.copy")} />
          <a className="btn btn--subtle" href={signUpLink} target="_blank" rel="noreferrer">
            <Icon name="external" size={15} />
            {t("action.open")}
          </a>
        </div>
      </div>

      <p className="muted small">
        {t("admin.registration.passwordRule").replace("{count}", String(config.data?.password_min_length ?? 10))}
      </p>
    </Card>
  );
}
