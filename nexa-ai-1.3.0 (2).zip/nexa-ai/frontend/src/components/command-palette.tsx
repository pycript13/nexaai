/**
 * Command palette (Ctrl/⌘ + K).
 *
 * A commercial console is navigated from the keyboard: every page the account may open, plus the
 * handful of global actions (theme, language, sign out), is reachable by typing a few letters.
 *
 * Two rules keep it honest:
 *   * the list is built from the *same* permission-filtered navigation as the sidebar, so it can
 *     never offer a page the API would refuse;
 *   * actions call the real handlers (the theme and locale setters, the sign-out call) — nothing is
 *     a shortcut to a placeholder.
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { TranslationKey } from "../locales";
import type { ThemeChoice } from "../state/app";
import { useApp, useI18n } from "../state/app";
import { Icon, type IconName } from "./icons";
import { navGroupsFor } from "./layout";

interface PaletteAction {
  id: string;
  label: string;
  hint?: string;
  icon: IconName;
  run: () => void;
}

interface PaletteEntry {
  id: string;
  label: string;
  group: string;
  icon: IconName;
  run: () => void;
  keywords: string;
}

/** Diacritic-insensitive, case-insensitive containment: "sécurité" matches "securite". */
function normalise(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[\u064B-\u0652\u200c\u200f\u200e]/g, "");
}

export function CommandPalette({ open, onClose }: { open: boolean; onClose: () => void }): JSX.Element | null {
  const { t, locale, setLocale, locales } = useI18n();
  const { hasPermission, theme, setTheme, meta, logout } = useApp();
  const routerNavigate = useNavigate();
  const [query, setQuery] = useState("");
  const [active, setActive] = useState(0);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const restoreRef = useRef<HTMLElement | null>(null);

  const entries = useMemo<PaletteEntry[]>(() => {
    const pages: PaletteEntry[] = [];
    for (const group of navGroupsFor(hasPermission)) {
      for (const item of group.items) {
        const label = t(item.labelKey);
        pages.push({
          id: `page:${item.to}`,
          label,
          group: t(group.labelKey),
          icon: item.icon || "dashboard",
          keywords: `${item.to} ${item.labelKey}`,
          run: () => routerNavigate(item.to),
        });
      }
    }

    const themeIcons: Record<string, IconName> = { light: "sun", dark: "moon", glass: "contrast", system: "contrast" };
    const themes: ThemeChoice[] = meta?.enhanced_theme_available
      ? ["light", "dark", "glass"]
      : ["light", "dark"];
    const actions: PaletteAction[] = [
      ...themes
        .filter((value) => value !== theme)
        .map((value) => ({
          id: `theme:${value}`,
          label: `${t("command.theme")} — ${t(`theme.${value}` as TranslationKey)}`,
          icon: themeIcons[value] || "contrast",
          run: () => setTheme(value),
        })),
      ...locales
        .filter((entry) => entry.code !== locale)
        .map((entry) => ({
          id: `locale:${entry.code}`,
          label: t("command.language").replace("{name}", entry.nativeLabel),
          icon: "translate" as const,
          run: () => setLocale(entry.code),
        })),
      {
        id: "action:logout",
        label: t("command.logout"),
        icon: "logout",
        run: () => {
          void logout();
        },
      },
    ];

    return [
      ...pages,
      ...actions.map((action) => ({
        id: action.id,
        label: action.label,
        group: t("command.actions"),
        icon: action.icon,
        run: action.run,
        keywords: action.id,
      })),
    ];
  }, [hasPermission, locale, locales, logout, meta, routerNavigate, setLocale, setTheme, t, theme]);

  const results = useMemo(() => {
    const needle = normalise(query.trim());
    if (!needle) return entries;
    const words = needle.split(/\s+/).filter(Boolean);
    return entries.filter((entry) => {
      const haystack = normalise(`${entry.label} ${entry.group} ${entry.keywords}`);
      return words.every((word) => haystack.includes(word));
    });
  }, [entries, query]);

  useEffect(() => {
    setActive(0);
  }, [query, open]);

  useEffect(() => {
    if (!open) return undefined;
    restoreRef.current = document.activeElement as HTMLElement | null;
    const timer = window.setTimeout(() => inputRef.current?.focus(), 10);
    return () => {
      window.clearTimeout(timer);
      restoreRef.current?.focus?.();
    };
  }, [open]);

  useEffect(() => {
    if (!open) setQuery("");
  }, [open]);

  // Escape must close the palette no matter where the focus is. Handling it only on the panel is not
  // enough: after a click on the list, or before the input receives focus, the key event never
  // reaches the panel — the palette stayed open, which is exactly what the browser check caught.
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        onClose();
      }
    };
    document.addEventListener("keydown", onKey, true);
    return () => document.removeEventListener("keydown", onKey, true);
  }, [open, onClose]);

  if (!open) return null;

  const runAt = (index: number) => {
    const entry = results[index];
    if (!entry) return;
    onClose();
    entry.run();
  };

  const onKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    if (event.key === "Escape") {
      event.preventDefault();
      onClose();
      return;
    }
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      if (results.length === 0) return;
      setActive((current) => {
        const next = event.key === "ArrowDown" ? current + 1 : current - 1;
        return (next + results.length) % results.length;
      });
      return;
    }
    if (event.key === "Home") {
      event.preventDefault();
      setActive(0);
      return;
    }
    if (event.key === "End") {
      event.preventDefault();
      setActive(Math.max(0, results.length - 1));
      return;
    }
    if (event.key === "Enter") {
      event.preventDefault();
      runAt(active);
    }
  };

  // Group headings in place, keeping the flat index for keyboard navigation.
  let lastGroup = "";
  let flatIndex = -1;

  return (
    <div className="palette" role="presentation" onMouseDown={(event) => {
      if (event.target === event.currentTarget) onClose();
    }}>
      <div
        className="palette__panel"
        role="dialog"
        aria-modal="true"
        aria-label={t("command.open")}
        onKeyDown={onKeyDown}
      >
        <div className="palette__search">
          <Icon name="search" size={17} />
          <input
            ref={inputRef}
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={t("command.placeholder")}
            aria-label={t("command.placeholder")}
            role="combobox"
            aria-expanded
            aria-controls="command-results"
            autoComplete="off"
            spellCheck={false}
          />
          <button type="button" className="iconbtn iconbtn--ghost" onClick={onClose} aria-label={t("action.close")}>
            <Icon name="close" size={16} />
          </button>
        </div>

        <div className="palette__list" id="command-results" role="listbox" aria-label={t("action.search")}>
          {results.length === 0 ? (
            <p className="palette__empty">{t("command.empty")}</p>
          ) : (
            results.map((entry, index) => {
              const heading = entry.group !== lastGroup ? entry.group : null;
              lastGroup = entry.group;
              flatIndex = index;
              return (
                <React.Fragment key={entry.id}>
                  {heading ? <p className="palette__section">{heading}</p> : null}
                  <button
                    type="button"
                    role="option"
                    aria-selected={index === active}
                    className={`palette__item ${index === active ? "palette__item--active" : ""}`}
                    onMouseEnter={() => setActive(flatIndex)}
                    onClick={() => runAt(index)}
                  >
                    <span className="palette__icon" aria-hidden>
                      <Icon name={entry.icon} size={16} />
                    </span>
                    <span className="palette__label">{entry.label}</span>
                  </button>
                </React.Fragment>
              );
            })
          )}
        </div>

        <p className="palette__foot">{t("command.hint")}</p>
      </div>
    </div>
  );
}

/** The topbar trigger: a search box that looks like a field but opens the palette. */
export function CommandTrigger({ onOpen }: { onOpen: () => void }): JSX.Element {
  const { t } = useI18n();
  return (
    <button type="button" className="command-trigger" onClick={onOpen} aria-label={t("command.open")}>
      <Icon name="search" size={15} />
      <span className="command-trigger__text">{t("action.search")}</span>
      <kbd className="command-trigger__kbd">Ctrl K</kbd>
    </button>
  );
}
