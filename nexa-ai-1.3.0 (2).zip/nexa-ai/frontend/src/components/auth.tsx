/**
 * Shared shell for every unauthenticated page (sign in, registration, recovery).
 *
 * Left: a live product panel whose chips and metrics come from `/api/v1/meta/config`
 * (the modules this deployment really exposes, the languages it really ships), so it never
 * advertises something the installation cannot do. Right: the form card.
 */
import React from "react";
import { useApp, useI18n } from "../state/app";
import { Icon, LogoMark, type IconName } from "./icons";

const STAGE_CHIPS: { icon: IconName; key: "nav.chat" | "nav.coding" | "nav.images" | "nav.documents" | "nav.data" | "nav.translation" | "nav.audio" | "nav.video" }[] = [
  { icon: "chat", key: "nav.chat" },
  { icon: "code", key: "nav.coding" },
  { icon: "image", key: "nav.images" },
  { icon: "document", key: "nav.documents" },
  { icon: "data", key: "nav.data" },
  { icon: "translate", key: "nav.translation" },
  { icon: "audio", key: "nav.audio" },
  { icon: "video", key: "nav.video" },
];

export function AuthShell({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}): JSX.Element {
  const { meta } = useApp();
  const { t } = useI18n();
  const moduleCount = meta?.modules?.length ?? 0;

  return (
    <div className="auth">
      <section className="auth__stage" aria-hidden="true">
        <div className="auth__brand">
          <LogoMark size={46} />
          <div>
            <strong>{meta?.app_name || t("app.name")}</strong>
            <div className="muted small">{meta?.tagline || t("app.tagline")}</div>
          </div>
        </div>
        <h1 className="auth__hero-title">
          <span className="text-gradient">{meta?.app_name || t("app.name")}</span>
          <br />
          {t("app.tagline")}
        </h1>
        <p className="auth__hero-text">{t("login.heroText")}</p>
        <div className="hero-chips">
          {STAGE_CHIPS.map((chip) => (
            <span className="hero-chip" key={chip.key}>
              <Icon name={chip.icon} size={15} />
              {t(chip.key)}
            </span>
          ))}
        </div>
        <div className="hero-metrics">
          <div className="hero-metric">
            <strong>{moduleCount || "—"}</strong>
            <span>{t("label.modules")}</span>
          </div>
          <div className="hero-metric">
            <strong>{meta?.languages?.length ?? 4}</strong>
            <span>{t("language.label")}</span>
          </div>
          <div className="hero-metric">
            <strong>{meta?.version ? `v${meta.version}` : "—"}</strong>
            <span>{meta?.environment || "—"}</span>
          </div>
        </div>
      </section>

      <section className="auth__panel">
        <div className="auth__card">
          <div className="auth__brand">
            <LogoMark size={40} />
            <div>
              <strong>{meta?.app_name || t("app.name")}</strong>
              <div className="muted small">{meta?.tagline || t("app.tagline")}</div>
            </div>
          </div>

          <h1>{title}</h1>
          {subtitle ? <p className="muted">{subtitle}</p> : null}

          {meta?.security_warning ? (
            <div className="alert alert--warning" role="alert">
              <div className="alert__body">
                <Icon name="alert" size={18} />
                <div>
                  <strong>{t("warning.deploymentTitle")}</strong>
                  <p>{meta.security_warning}</p>
                </div>
              </div>
            </div>
          ) : null}

          {children}

          <p className="auth__footnote">
            <Icon name="shield" size={14} /> {meta?.app_name || t("app.name")} · {meta?.version ? `v${meta.version}` : ""} ·{" "}
            {meta?.deployment_mode}
          </p>
        </div>
      </section>
    </div>
  );
}
