/**
 * Minimal, dependency-free Markdown renderer for model output.
 *
 * Security: the text is escaped by React (never `dangerouslySetInnerHTML`), links
 * are restricted to http/https/mailto, and only a small subset of Markdown is
 * supported (headings, lists — bulleted and numbered, code fences with a copy
 * button, inline code, bold/italic, horizontal rules; tables render as
 * preformatted text). This keeps untrusted model output safe.
 */
import React, { useState } from "react";
import { useI18n } from "../state/app";

function inline(text: string, keyPrefix: string): React.ReactNode[] {
  const nodes: React.ReactNode[] = [];
  const pattern = /(`[^`]+`)|(\*\*[^*]+\*\*)|(\*[^*]+\*)|(\[[^\]]+\]\((https?:\/\/[^\s)]+|mailto:[^\s)]+)\))/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  let index = 0;
  while ((match = pattern.exec(text)) !== null) {
    if (match.index > lastIndex) nodes.push(text.slice(lastIndex, match.index));
    const token = match[0];
    const key = `${keyPrefix}-${index++}`;
    if (token.startsWith("`")) nodes.push(<code key={key}>{token.slice(1, -1)}</code>);
    else if (token.startsWith("**")) nodes.push(<strong key={key}>{token.slice(2, -2)}</strong>);
    else if (token.startsWith("*")) nodes.push(<em key={key}>{token.slice(1, -1)}</em>);
    else {
      const label = token.slice(1, token.indexOf("]"));
      const href = token.slice(token.indexOf("](") + 2, -1);
      nodes.push(
        <a key={key} href={href} target="_blank" rel="noreferrer noopener">
          {label}
        </a>,
      );
    }
    lastIndex = pattern.lastIndex;
  }
  if (lastIndex < text.length) nodes.push(text.slice(lastIndex));
  return nodes;
}

/** A fenced code block with its language tag and a one-click copy button. */
function CodeBlock({ code, lang }: { code: string; lang: string }): JSX.Element {
  const { t } = useI18n();
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1400);
    } catch {
      /* clipboard blocked (insecure context) — the button simply does nothing */
    }
  };
  return (
    <div className="md__codeblock">
      <div className="md__codebar">
        <span className="md__codelang">{lang || "code"}</span>
        <button type="button" className="md__copy" onClick={copy} aria-label={t("action.copy")}>
          {copied ? t("chat.copied") : t("action.copy")}
        </button>
      </div>
      <pre className="md__code" data-lang={lang}>
        <code>{code}</code>
      </pre>
    </div>
  );
}

export function Markdown({ text }: { text: string }): JSX.Element {
  // Reasoning models wrap their chain of thought in <think>/<thinking>/<reasoning>
  // blocks. The chat shows those in a separate reasoning panel (see `reasoningTextOf`
  // in Chat.tsx) — the visible answer must never carry the raw tags, including an
  // unclosed block that is still streaming in.
  const visible = (text || "")
    .replace(/<\s*(?:think|thinking|reasoning)\b[^>]*>[\s\S]*?(?:<\s*\/\s*(?:think|thinking|reasoning)\s*>|$)/gi, "")
    .trim();
  const lines = visible.split("\n");
  const blocks: React.ReactNode[] = [];
  let buffer: string[] = [];
  let mode: "paragraph" | "code" | "list" | "olist" = "paragraph";
  let codeLang = "";
  let key = 0;

  const flush = () => {
    if (buffer.length === 0) return;
    if (mode === "code") {
      blocks.push(<CodeBlock key={`block-${key++}`} code={buffer.join("\n")} lang={codeLang} />);
    } else if (mode === "list") {
      blocks.push(
        <ul key={`block-${key++}`}>
          {buffer.map((item, index) => (
            <li key={index}>{inline(item.replace(/^\s*[-*]\s+/, ""), `li-${key}-${index}`)}</li>
          ))}
        </ul>,
      );
    } else if (mode === "olist") {
      blocks.push(
        <ol key={`block-${key++}`}>
          {buffer.map((item, index) => (
            <li key={index}>{inline(item.replace(/^\s*\d+[.)]\s+/, ""), `oli-${key}-${index}`)}</li>
          ))}
        </ol>,
      );
    } else {
      blocks.push(<p key={`block-${key++}`}>{inline(buffer.join(" "), `p-${key}`)}</p>);
    }
    buffer = [];
  };

  for (const line of lines) {
    if (line.trim().startsWith("```")) {
      if (mode === "code") {
        flush();
        mode = "paragraph";
      } else {
        flush();
        mode = "code";
        codeLang = line.trim().slice(3);
      }
      continue;
    }
    if (mode === "code") {
      buffer.push(line);
      continue;
    }
    if (/^\s*(-{3,}|\*{3,})\s*$/.test(line)) {
      flush();
      mode = "paragraph";
      blocks.push(<hr key={`block-${key++}`} />);
      continue;
    }
    const heading = /^(#{1,4})\s+(.*)$/.exec(line);
    if (heading) {
      flush();
      mode = "paragraph";
      const level = heading[1].length;
      const content = inline(heading[2], `h-${key}`);
      blocks.push(
        level <= 2 ? (
          <h3 key={`block-${key++}`}>{content}</h3>
        ) : (
          <h4 key={`block-${key++}`}>{content}</h4>
        ),
      );
      continue;
    }
    if (/^\s*[-*]\s+/.test(line)) {
      if (mode !== "list") flush();
      mode = "list";
      buffer.push(line);
      continue;
    }
    if (/^\s*\d+[.)]\s+/.test(line)) {
      if (mode !== "olist") flush();
      mode = "olist";
      buffer.push(line);
      continue;
    }
    if (line.trim() === "") {
      flush();
      mode = "paragraph";
      continue;
    }
    if (mode === "list" || mode === "olist") flush();
    mode = "paragraph";
    buffer.push(line);
  }
  flush();
  return <div className="md">{blocks}</div>;
}
