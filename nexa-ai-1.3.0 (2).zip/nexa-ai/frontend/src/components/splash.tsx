/**
 * The 3D splash loader — the same visual language as the first-paint splash in index.html.
 *
 * Used full-screen while the session is being resolved (RequireAuth) and in a compact
 * form wherever a whole view is waiting for its first data. Pure CSS 3D: the cube,
 * rings, glow and particles are transforms on the design-system tokens, so every theme
 * (light/dark/glass) and `prefers-reduced-motion` are respected.
 */
import React from "react";
import { useI18n } from "../state/app";

export function SplashLoader({
  note,
  compact = false,
}: {
  /** Optional one-line status under the cube; defaults to the generic "loading" copy. */
  note?: string;
  /** Smaller stage for in-page use (no brand line). */
  compact?: boolean;
}): JSX.Element {
  const { t } = useI18n();
  return (
    <div className={`splash3d ${compact ? "splash3d--compact" : ""}`} role="status" aria-live="polite">
      <div className="splash3d__stage" aria-hidden="true">
        <span className="splash3d__glow" />
        <span className="splash3d__ring" />
        <span className="splash3d__ring splash3d__ring--b" />
        <span className="splash3d__particle p1" />
        <span className="splash3d__particle p2" />
        <span className="splash3d__particle p3" />
        <span className="splash3d__cube">
          <span className="splash3d__face f-front">
            <svg viewBox="0 0 32 32" fill="none">
              <path d="M9 23V9.5l14 13V9" stroke="white" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </span>
          <span className="splash3d__face f-back" />
          <span className="splash3d__face f-right" />
          <span className="splash3d__face f-left" />
          <span className="splash3d__face f-top" />
          <span className="splash3d__face f-bottom" />
        </span>
      </div>
      {!compact && <strong className="splash3d__brand">{t("app.name")}</strong>}
      <span className="splash3d__note visually-hidden">{note || t("app.loading")}</span>
      {!compact && <span className="splash3d__bar" aria-hidden="true"><i /></span>}
    </div>
  );
}
