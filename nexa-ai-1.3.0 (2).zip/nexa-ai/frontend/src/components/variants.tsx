/**
 * Sub-model (variant) management.
 *
 * A variant is a *child* of a published model: same provider model, but with its own
 * system prompt, sampling defaults and its own on/off switch. The classic use case is a
 * single DeepSeek model exposed twice — one child that chats, one that only writes code.
 *
 * Everything here talks to the real API:
 *   GET    /api/v1/models/{id}/variants
 *   POST   /api/v1/models/{id}/variants
 *   PATCH  /api/v1/models/variants/{id}
 *   DELETE /api/v1/models/variants/{id}
 *   POST   /api/v1/models/variants/{id}/toggle
 */
import React, { useState } from "react";
import { api } from "../api/client";
import { Badge, Button, Card, ConfirmCheckbox, Field, Modal, SuccessNotice, useApi } from "../components/ui";
import { formatDateTime } from "../utils/format";
import { useI18n } from "../state/app";

export interface Variant {
  id: number;
  model_id: number;
  slug: string;
  name: string;
  description: string;
  emoji: string;
  enabled: boolean;
  is_default: boolean;
  scope: "system" | "personal" | string;
  sort_order: number;
  owner_user_id: number | null;
  owner_email?: string | null;
  default_temperature: number | null;
  default_top_p: number | null;
  default_max_tokens: number | null;
  has_system_prompt: boolean;
  system_prompt: string | null;
  system_prompt_chars: number;
  usage_count: number;
  last_used_at: string | null;
  created_at: string;
  model?: { id: number; display_name: string; provider_model_id: string } | null;
}

interface VariantForm {
  name: string;
  emoji: string;
  description: string;
  system_prompt: string;
  default_temperature: string;
  default_max_tokens: string;
  scope: "system" | "personal";
  is_default: boolean;
}

const EMPTY_FORM: VariantForm = {
  name: "",
  emoji: "",
  description: "",
  system_prompt: "",
  default_temperature: "",
  default_max_tokens: "",
  scope: "personal",
  is_default: false,
};

function formFrom(variant: Variant): VariantForm {
  return {
    name: variant.name,
    emoji: variant.emoji || "",
    description: variant.description || "",
    system_prompt: variant.system_prompt || "",
    default_temperature: variant.default_temperature === null ? "" : String(variant.default_temperature),
    default_max_tokens: variant.default_max_tokens === null ? "" : String(variant.default_max_tokens),
    scope: variant.scope === "system" ? "system" : "personal",
    is_default: variant.is_default,
  };
}

function payloadFrom(form: VariantForm): Record<string, unknown> {
  const payload: Record<string, unknown> = {
    name: form.name.trim(),
    emoji: form.emoji.trim() || null,
    description: form.description.trim() || null,
    system_prompt: form.system_prompt.trim() || null,
    scope: form.scope,
    is_default: form.is_default,
  };
  if (form.default_temperature.trim()) payload.default_temperature = Number(form.default_temperature);
  if (form.default_max_tokens.trim()) payload.default_max_tokens = Number(form.default_max_tokens);
  return payload;
}

export function useVariants(modelId?: number | string) {
  return useApi<{ items: Variant[] }>(
    () => api.get<{ items: Variant[] }>(`/api/v1/models/${modelId}/variants`),
    [modelId],
  );
}

/** Compact picker used by the chat composer: "DeepSeek · Code writer". */
export function VariantPicker({
  variants,
  value,
  onChange,
}: {
  variants: Variant[];
  value: number | null;
  onChange: (value: number | null) => void;
}): JSX.Element | null {
  const { t } = useI18n();
  if (!variants.length) return null;
  return (
    <Field label={t("variant.label")} hint={t("variant.pickHint")}>
      <select value={value === null ? "" : String(value)} onChange={(event) => onChange(event.target.value ? Number(event.target.value) : null)}>
        <option value="">{t("variant.none")}</option>
        {variants.map((variant) => (
          <option key={variant.id} value={variant.id} disabled={!variant.enabled}>
            {variant.emoji ? `${variant.emoji} ` : ""}
            {variant.name}
            {variant.enabled ? "" : ` — ${t("variant.disabled")}`}
          </option>
        ))}
      </select>
    </Field>
  );
}

/** Full nested manager: list, create, edit, toggle and delete the child models. */
export function VariantManager({
  modelId,
  modelName,
  canManageSystem = false,
}: {
  modelId: number | string;
  modelName: string;
  canManageSystem?: boolean;
}): JSX.Element {
  const { t } = useI18n();
  const list = useVariants(modelId);
  const [editing, setEditing] = useState<Variant | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState<VariantForm>({ ...EMPTY_FORM, scope: canManageSystem ? "system" : "personal" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const openCreate = () => {
    setForm({ ...EMPTY_FORM, scope: canManageSystem ? "system" : "personal" });
    setEditing(null);
    setError(null);
    setConfirmDelete(false);
    setCreating(true);
  };

  const openEdit = (variant: Variant) => {
    setForm(formFrom(variant));
    setEditing(variant);
    setError(null);
    setConfirmDelete(false);
    setCreating(true);
  };

  const close = () => {
    setCreating(false);
    setEditing(null);
    setError(null);
  };

  const save = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!form.name.trim()) {
      setError(new Error(t("variant.nameRequired")));
      return;
    }
    setBusy(true);
    setError(null);
    try {
      if (editing) {
        await api.patch(`/api/v1/models/variants/${editing.id}`, payloadFrom(form));
        setNotice(t("variant.updated"));
      } else {
        await api.post(`/api/v1/models/${modelId}/variants`, payloadFrom(form));
        setNotice(t("variant.created"));
      }
      close();
      list.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const toggle = async (variant: Variant) => {
    setBusy(true);
    setError(null);
    try {
      await api.post(`/api/v1/models/variants/${variant.id}/toggle`);
      list.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!editing) return;
    setBusy(true);
    setError(null);
    try {
      await api.del(`/api/v1/models/variants/${editing.id}`);
      setNotice(t("variant.deleted"));
      close();
      list.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const items = list.data?.items || [];

  return (
    <Card
      icon="sparkles"
      title={t("variant.subModels")}
      subtitle={`${modelName} — ${t("variant.subModelsHint")}`}
      actions={
        <Button variant="subtle" type="button" onClick={openCreate}>
          {t("variant.create")}
        </Button>
      }
    >
      {notice ? <SuccessNotice message={notice} /> : null}
      {list.error ? <p className="muted small">{t("status.error")}</p> : null}
      {!items.length ? (
        <p className="muted small">{t("variant.empty")}</p>
      ) : (
        <div className="variant-list">
          {items.map((variant) => (
            <div key={variant.id} className={`variant-item${variant.enabled ? "" : " variant-item--off"}`}>
              <div className="variant-item__head">
                <span className="variant-item__emoji" aria-hidden>
                  {variant.emoji || "⌘"}
                </span>
                <div className="variant-item__title">
                  <strong>{variant.name}</strong>
                  <span className="muted small mono">{variant.slug}</span>
                </div>
                <div className="row" style={{ gap: "0.35rem" }}>
                  {variant.is_default ? <Badge tone="info">{t("variant.default")}</Badge> : null}
                  <Badge tone={variant.scope === "system" ? "neutral" : "warning"}>
                    {variant.scope === "system" ? t("variant.scopeSystem") : t("variant.scopePersonal")}
                  </Badge>
                  <Badge tone={variant.enabled ? "success" : "muted"}>
                    {variant.enabled ? t("variant.on") : t("variant.off")}
                  </Badge>
                </div>
              </div>
              {variant.description ? <p className="muted small">{variant.description}</p> : null}
              {variant.system_prompt ? (
                <p className="variant-item__prompt mono small">{variant.system_prompt}</p>
              ) : (
                <p className="muted small">{t("variant.noPrompt")}</p>
              )}
              <div className="variant-item__meta">
                <span>
                  {t("variant.usage")}: <strong>{variant.usage_count}</strong>
                </span>
                <span>
                  {t("variant.promptChars")}: <strong>{variant.system_prompt_chars}</strong>
                </span>
                {variant.default_temperature !== null ? <span>temp {variant.default_temperature}</span> : null}
                {variant.default_max_tokens !== null ? <span>max {variant.default_max_tokens}</span> : null}
                <span>
                  {t("variant.lastUsed")}: {variant.last_used_at ? formatDateTime(variant.last_used_at) : "—"}
                </span>
                {variant.owner_email ? <span className="mono">{variant.owner_email}</span> : null}
              </div>
              <div className="row variant-item__actions">
                <Button variant="ghost" type="button" onClick={() => toggle(variant)} disabled={busy}>
                  {variant.enabled ? t("variant.turnOff") : t("variant.turnOn")}
                </Button>
                <Button variant="subtle" type="button" onClick={() => openEdit(variant)}>
                  {t("action.edit")}
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal
        open={creating}
        title={editing ? `${t("variant.editTitle")}: ${editing.name}` : t("variant.createTitle")}
        onClose={close}
      >
        <form onSubmit={save} className="stack">
          {error ? <p className="alert alert--danger small">{String((error as Error)?.message || error)}</p> : null}
          <div className="grid grid--2">
            <Field label={t("variant.name")} hint={t("variant.nameHint")}>
              <input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} required />
            </Field>
            <Field label={t("variant.emoji")} hint={t("variant.emojiHint")}>
              <input value={form.emoji} maxLength={4} onChange={(event) => setForm({ ...form, emoji: event.target.value })} />
            </Field>
          </div>
          <Field label={t("variant.description")}>
            <input value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} />
          </Field>
          <Field label={t("variant.systemPrompt")} hint={t("variant.systemPromptHint")}>
            <textarea
              rows={5}
              value={form.system_prompt}
              onChange={(event) => setForm({ ...form, system_prompt: event.target.value })}
              placeholder={t("variant.systemPromptPlaceholder")}
            />
          </Field>
          <div className="grid grid--2">
            <Field label={t("variant.temperature")} hint="0 – 2">
              <input
                type="number"
                step="0.05"
                min="0"
                max="2"
                value={form.default_temperature}
                onChange={(event) => setForm({ ...form, default_temperature: event.target.value })}
              />
            </Field>
            <Field label={t("variant.maxTokens")} hint="1 – 200000">
              <input
                type="number"
                min="1"
                max="200000"
                value={form.default_max_tokens}
                onChange={(event) => setForm({ ...form, default_max_tokens: event.target.value })}
              />
            </Field>
          </div>
          <Field label={t("variant.scope")} hint={canManageSystem ? t("variant.scopeHintAdmin") : t("variant.scopeHintUser")}>
            <select
              value={form.scope}
              onChange={(event) => setForm({ ...form, scope: event.target.value as "system" | "personal" })}
            >
              <option value="personal">{t("variant.scopePersonal")}</option>
              {canManageSystem ? <option value="system">{t("variant.scopeSystem")}</option> : null}
            </select>
          </Field>
          <ConfirmCheckbox
            checked={form.is_default}
            onChange={(value) => setForm({ ...form, is_default: value })}
            label={t("variant.makeDefault")}
          />
          {editing ? (
            <ConfirmCheckbox checked={confirmDelete} onChange={setConfirmDelete} label={t("variant.confirmDelete")} />
          ) : null}
          <div className="row">
            <Button type="submit" loading={busy} disabled={busy}>
              {editing ? t("action.save") : t("action.create")}
            </Button>
            {editing ? (
              <Button variant="danger" type="button" onClick={remove} disabled={busy || !confirmDelete}>
                {t("action.delete")}
              </Button>
            ) : null}
            <Button variant="ghost" type="button" onClick={close}>
              {t("action.cancel")}
            </Button>
          </div>
        </form>
      </Modal>
    </Card>
  );
}

/**
 * Admin monitoring board: every variant of every model (including disabled ones and
 * other people's personal variants) with live usage counters and a one-click switch.
 */
export function AdminVariantBoard(): JSX.Element {
  const { t } = useI18n();
  const [filter, setFilter] = useState("");
  const list = useApi<{ items: Variant[]; total: number }>(
    () => api.get<{ items: Variant[]; total: number }>("/api/v1/admin/model-variants"),
    [],
  );
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);

  const toggle = async (variant: Variant) => {
    setBusy(true);
    setError(null);
    try {
      await api.patch(`/api/v1/admin/model-variants/${variant.id}`, { enabled: !variant.enabled });
      list.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const items = (list.data?.items || []).filter((variant) => {
    if (!filter.trim()) return true;
    const needle = filter.trim().toLowerCase();
    return (
      variant.name.toLowerCase().includes(needle) ||
      variant.slug.toLowerCase().includes(needle) ||
      (variant.model?.display_name || "").toLowerCase().includes(needle) ||
      (variant.owner_email || "").toLowerCase().includes(needle)
    );
  });

  const grouped = new Map<string, Variant[]>();
  for (const variant of items) {
    const key = variant.model?.display_name || `#${variant.model_id}`;
    grouped.set(key, [...(grouped.get(key) || []), variant]);
  }

  return (
    <Card
      icon="layers"
      title={t("variant.monitorTitle")}
      subtitle={t("variant.monitorHint")}
      actions={
        <Field label={t("action.search")}>
          <input value={filter} onChange={(event) => setFilter(event.target.value)} />
        </Field>
      }
    >
      {error ? <p className="alert alert--danger small">{String((error as Error)?.message || error)}</p> : null}
      {list.loading ? <p className="muted small">{t("status.loading")}</p> : null}
      {!list.loading && !items.length ? <p className="muted small">{t("variant.empty")}</p> : null}
      {[...grouped.entries()].map(([modelName, variants]) => (
        <div key={modelName} className="variant-group">
          <div className="variant-group__head">
            <strong>{modelName}</strong>
            <span className="muted small">
              {variants.length} {t("variant.children")}
            </span>
          </div>
          {variants.map((variant) => (
            <div key={variant.id} className={`variant-item${variant.enabled ? "" : " variant-item--off"}`}>
              <div className="variant-item__head">
                <span className="variant-item__emoji" aria-hidden>
                  {variant.emoji || "⌘"}
                </span>
                <div className="variant-item__title">
                  <strong>{variant.name}</strong>
                  <span className="muted small mono">{variant.slug}</span>
                </div>
                <div className="row" style={{ gap: "0.35rem" }}>
                  <Badge tone={variant.scope === "system" ? "neutral" : "warning"}>
                    {variant.scope === "system" ? t("variant.scopeSystem") : t("variant.scopePersonal")}
                  </Badge>
                  <Badge tone={variant.enabled ? "success" : "muted"}>
                    {variant.enabled ? t("variant.on") : t("variant.off")}
                  </Badge>
                </div>
              </div>
              <div className="variant-item__meta">
                <span>
                  {t("variant.usage")}: <strong>{variant.usage_count}</strong>
                </span>
                <span>
                  {t("variant.promptChars")}: <strong>{variant.system_prompt_chars}</strong>
                </span>
                <span>{variant.owner_email || t("variant.ownerSystem")}</span>
              </div>
              <div className="row">
                <Button variant="ghost" type="button" onClick={() => toggle(variant)} disabled={busy}>
                  {variant.enabled ? t("variant.turnOff") : t("variant.turnOn")}
                </Button>
              </div>
            </div>
          ))}
        </div>
      ))}
    </Card>
  );
}
