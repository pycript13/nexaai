import { useEffect, useState } from "react";
import { api } from "../api/client";
import { Badge, Button, Card, CopyButton, ErrorNotice, Field, Spinner, useApi } from "./ui";
import { useApp, useI18n } from "../state/app";

interface LinkStatus {
  linked: boolean;
  enabled: boolean;
  telegram_user_id: number | null;
  telegram_username: string | null;
  verified_via: string | null;
  message_count: number;
  last_message_at: string | null;
  pending_code: boolean;
  bot_configured: boolean;
  bot_username: string;
  how_it_works: string;
}

interface LinkCode {
  code: string;
  expires_in_minutes: number;
  bot_username: string;
  deep_link: string | null;
  instructions: string;
}

/**
 * Profile → Telegram.
 *
 * The bot answers only Telegram ids that are registered on the site. There are two ways to register
 * one, and this card offers both:

 * * **numeric id** — the user types the number the bot shows them (`/whoami`) and saves it; the bot
 *   then recognises them the moment they press Start;
 * * **one-time code** — the stronger path: the site issues a short-lived code, the user sends
 *   `/start <code>` from Telegram and the platform stores the id it received, which proves the human
 *   controls both accounts.
 *
 * The card says which of the two is in effect, because they are not the same thing and the platform
 * never pretends otherwise.
 */
export function TelegramUserCard(): JSX.Element {
  const { t } = useI18n();
  const { notify } = useApp();
  const status = useApi<LinkStatus>(() => api.get("/api/v1/telegram/status"), []);
  const [numericId, setNumericId] = useState("");
  const [code, setCode] = useState<LinkCode | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);

  useEffect(() => {
    if (status.data?.telegram_user_id && !numericId) setNumericId(String(status.data.telegram_user_id));
  }, [status.data, numericId]);

  if (status.loading && !status.data) return <Spinner />;
  if (status.error) return <ErrorNotice error={status.error} onRetry={status.reload} />;
  const data = status.data;
  if (!data) return <Spinner />;

  const saveNumericId = async () => {
    setBusy(true);
    setError(null);
    try {
      await api.post("/api/v1/telegram/numeric-id", { telegram_user_id: Number(numericId) });
      notify("success", t("telegram.numericIdSaved"));
      status.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const requestCode = async () => {
    setBusy(true);
    setError(null);
    try {
      setCode(await api.post<LinkCode>("/api/v1/telegram/link-code", {}));
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const unlink = async () => {
    setBusy(true);
    setError(null);
    try {
      await api.del("/api/v1/telegram/link");
      setCode(null);
      setNumericId("");
      notify("success", t("telegram.unlinked"));
      status.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card
      icon="mail"
      title={t("telegram.title")}
      subtitle={t("telegram.subtitle")}
      actions={
        data.linked ? (
          <Badge tone={data.verified_via === "code" ? "success" : "warning"}>
            {data.verified_via === "code" ? t("telegram.verifiedViaCode") : t("telegram.verifiedViaProfile")}
          </Badge>
        ) : (
          <Badge tone="neutral">{t("telegram.notLinked")}</Badge>
        )
      }
    >
      {error ? <ErrorNotice error={error} /> : null}
      {!data.bot_configured ? (
        <div className="alert alert--warning" role="status">
          <div>
            <strong>{t("telegram.botNotConfigured")}</strong>
            <p className="alert__hint">{t("telegram.botNotConfiguredHint")}</p>
          </div>
        </div>
      ) : null}

      <p className="muted small">{t("telegram.howItWorks")}</p>

      <div className="kv">
        <div>
          <span>{t("telegram.numericId")}</span>
          <span className="mono">{data.telegram_user_id || "—"}</span>
        </div>
        <div>
          <span>{t("telegram.bot")}</span>
          <span className="mono">
            {data.bot_username ? (
              <a href={`https://t.me/${data.bot_username}`} target="_blank" rel="noreferrer">
                @{data.bot_username}
              </a>
            ) : (
              "—"
            )}
          </span>
        </div>
        <div>
          <span>{t("telegram.messageCount")}</span>
          <span className="mono">{data.message_count}</span>
        </div>
      </div>

      <div className="grid grid--2" style={{ marginTop: "0.6rem" }}>
        <Field label={t("telegram.numericId")} hint={t("telegram.numericIdHint")}>
          <div className="row">
            <input
              dir="ltr"
              inputMode="numeric"
              value={numericId}
              onChange={(event) => setNumericId(event.target.value.replace(/[^0-9]/g, ""))}
              placeholder="123456789"
            />
            <Button type="button" onClick={saveNumericId} loading={busy} disabled={!numericId.trim()}>
              {t("action.save")}
            </Button>
          </div>
        </Field>
        <div className="row" style={{ alignSelf: "end", gap: "0.5rem" }}>
          <Button variant="subtle" type="button" onClick={requestCode} loading={busy} disabled={!data.bot_configured}>
            {t("telegram.createCode")}
          </Button>
          {data.linked ? (
            <Button variant="ghost" type="button" onClick={unlink} loading={busy}>
              {t("telegram.unlink")}
            </Button>
          ) : null}
        </div>
      </div>

      {code ? (
        <div className="alert alert--success" role="status">
          <div className="stack" style={{ gap: "0.4rem" }}>
            <strong>{t("telegram.codeReady")}</strong>
            <p>{t("telegram.codeInstructions").replace("{minutes}", String(code.expires_in_minutes))}</p>
            <div className="row">
              <code className="mono">/start {code.code}</code>
              <CopyButton value={`/start ${code.code}`} />
              {code.deep_link ? (
                <a className="btn btn--ghost" href={code.deep_link} target="_blank" rel="noreferrer">
                  {t("telegram.openInTelegram")}
                </a>
              ) : null}
            </div>
          </div>
        </div>
      ) : null}

      {data.bot_configured ? (
        <div className="tg-preview">
          <strong>{t("telegram.capabilitiesTitle")}</strong>
          <div>
            <p className="muted small">{t("telegram.capabilitiesBar")}</p>
            {/* The six labels are the bot's literal reply-keyboard buttons — Telegram renders them
                bilingually, so the replica here keeps the exact same strings on purpose. */}
            <div className="tg-preview__keys" aria-hidden="true">
              <span className="tg-preview__key">💬 گفتگو · Chat</span>
              <span className="tg-preview__key">🧠 مدل‌ها · Models</span>
              <span className="tg-preview__key">🗂 سشن‌ها · Sessions</span>
              <span className="tg-preview__key">💳 حساب من · Account</span>
              <span className="tg-preview__key">⚙️ تنظیمات · Settings</span>
              <span className="tg-preview__key">❓ راهنما · Help</span>
            </div>
          </div>
          <div>
            <p className="muted small">{t("telegram.capabilitiesSessions")}</p>
            <div className="tg-preview__cmds">
              {["/new", "/sessions", "/switch", "/rename", "/close", "/stats", "/export", "/retry", "/settings"].map((command) => (
                <code key={command} className="mono">{command}</code>
              ))}
            </div>
          </div>
        </div>
      ) : null}
    </Card>
  );
}
