import { useState } from "react";
import { api } from "../api/client";
import { Badge, Button, Card, ErrorNotice, Field, Spinner, useApi } from "./ui";
import { useApp, useI18n } from "../state/app";

/**
 * Admin → Settings → Telegram.
 *
 * Round 12: the bot token is now edited **here**, stored encrypted in the settings table (never
 * returned by the API — only a masked hint and whether a value exists), and the polling worker picks
 * a new token up within seconds without a service restart. The card also shows the truth about the
 * deployment: how many Telegram ids are registered on the site, how many were *proven* with a
 * one-time code versus merely declared in a profile, and how many messages the bot has handled.
 */
export interface TelegramStatus {
  enabled: boolean;
  enabled_source: string;
  configured: boolean;
  token: { configured: boolean; source: string; hint: string; updated_at: string | null };
  webhook_secret: { configured: boolean; source: string; hint: string };
  mode: string;
  bot_username: string | null;
  api_base: string;
  linked_accounts: number;
  enabled_links: number;
  verified_links: number;
  declared_links: number;
  messages_handled: number;
  how_to: string;
  recent: {
    user_id: number;
    email: string | null;
    telegram_user_id: number | null;
    telegram_username: string | null;
    verified_via: string | null;
    enabled: boolean;
    message_count: number;
  }[];
}

export function TelegramAdminCard(): JSX.Element {
  const { t } = useI18n();
  const { notify, hasPermission } = useApp();
  const status = useApi<TelegramStatus>(() => api.get("/api/v1/admin/telegram/status"), []);
  const [token, setToken] = useState("");
  const [showToken, setShowToken] = useState(false);
  const [webhookSecret, setWebhookSecret] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<unknown>(null);
  const permission = hasPermission("settings.manage");

  if (status.loading && !status.data) return <Spinner />;
  if (status.error) return <ErrorNotice error={status.error} onRetry={status.reload} />;
  const data = status.data;
  if (!data) return <Spinner />;

  const run = async (action: () => Promise<unknown>, successMessage: string) => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await action();
      setNotice(successMessage);
      notify("success", successMessage);
      status.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const saveToken = () =>
    run(async () => {
      await api.put("/api/v1/admin/telegram/token", { token: token.trim() });
      setToken("");
    }, t("admin.telegramTokenSaved"));

  const clearToken = () =>
    run(async () => {
      await api.put("/api/v1/admin/telegram/token", { clear: true });
    }, t("admin.telegramTokenCleared"));

  const test = () =>
    run(async () => {
      const result = await api.post<{ bot?: { username?: string; first_name?: string }; token_source?: string }>(
        "/api/v1/admin/telegram/test",
      );
      setNotice(
        `${t("telegram.testOk")}: @${result.bot?.username || "?"} (${result.bot?.first_name || ""}) — ${t("admin.telegramTokenSource")}: ${result.token_source || "—"}`,
      );
    }, t("telegram.testOk"));

  const toggleEnabled = (next: boolean) =>
    run(async () => {
      await api.put("/api/v1/admin/telegram/enabled", { enabled: next });
    }, next ? t("admin.telegramEnabledNow") : t("admin.telegramDisabledNow"));

  const publishCommands = () =>
    run(async () => {
      await api.post("/api/v1/admin/telegram/commands");
    }, t("admin.telegramCommandsDone"));

  const saveWebhookSecret = () =>
    run(async () => {
      await api.put("/api/v1/admin/telegram/webhook-secret", { secret: webhookSecret.trim() });
      setWebhookSecret("");
    }, t("admin.telegramSecretSaved"));

  return (
    <Card
      icon="mail"
      title={t("admin.telegramTitle")}
      subtitle={t("admin.telegramSubtitle")}
      actions={
        <Badge tone={data.configured && data.enabled ? "success" : data.token.configured ? "warning" : "neutral"}>
          {data.configured && data.enabled
            ? t("admin.telegramRunning")
            : data.token.configured
              ? t("admin.telegramStopped")
              : t("admin.telegramNoToken")}
        </Badge>
      }
    >
      {error ? <ErrorNotice error={error} /> : null}
      {notice ? (
        <div className="alert alert--success" role="status">
          <div>
            <strong>{notice}</strong>
          </div>
        </div>
      ) : null}

      {/* The server also returns an English `how_to` for API clients; the panel shows its own
          translated checklist so the screen never mixes languages. */}
      <ol className="telegram-steps">
        {[1, 2, 3, 4].map((step) => (
          <li key={step}>{t(`admin.telegramStep${step}` as never)}</li>
        ))}
      </ol>

      <Field label={t("admin.telegramToken")} hint={t("admin.telegramTokenHint")}>
        <div className="row">
          <input
            type={showToken ? "text" : "password"}
            dir="ltr"
            value={token}
            onChange={(event) => setToken(event.target.value)}
            placeholder={data.token.configured ? data.token.hint || "••••" : "123456789:AA…"}
            autoComplete="off"
          />
          <Button variant="ghost" type="button" onClick={() => setShowToken((value) => !value)}>
            {showToken ? t("admin.telegramHide") : t("admin.telegramShow")}
          </Button>
        </div>
      </Field>
      <div className="row" style={{ gap: "0.5rem", marginBottom: "0.6rem" }}>
        <Button type="button" onClick={saveToken} loading={busy} disabled={!permission || !token.trim()}>
          {t("admin.telegramSaveToken")}
        </Button>
        <Button type="button" variant="subtle" onClick={test} loading={busy} disabled={!permission || !data.token.configured}>
          {t("telegram.test")}
        </Button>
        <Button
          variant="subtle"
          type="button"
          onClick={() => toggleEnabled(!data.enabled)}
          disabled={!permission || busy || !data.token.configured}
        >
          {data.enabled ? t("admin.telegramDisable") : t("admin.telegramEnable")}
        </Button>
      </div>

      {data.token.configured ? (
        <p className="muted small">
          {t("admin.telegramStored")}: <span className="mono">{data.token.hint || "—"}</span> ·{" "}
          {t("admin.telegramTokenSource")}: <span className="mono">{data.token.source}</span>
          {data.token.source === "environment" ? ` (${t("admin.telegramEnvNote")})` : ""}
        </p>
      ) : (
        <p className="field__error">{t("admin.telegramNoTokenHint")}</p>
      )}

      <div className="kv" style={{ marginTop: "0.6rem" }}>
        <div>
          <span>{t("admin.telegramBot")}</span>
          <span className="mono">
            {data.bot_username ? (
              <a href={`https://t.me/${data.bot_username}`} target="_blank" rel="noreferrer">
                @{data.bot_username}
              </a>
            ) : (
              "—"
            )}
          </span>
        </div>
        <div>
          <span>{t("admin.telegramMode")}</span>
          <span className="mono">{data.mode}</span>
        </div>
        <div>
          <span>{t("admin.telegramLinked")}</span>
          <span className="mono">
            {data.enabled_links} / {data.linked_accounts}
          </span>
        </div>
        <div>
          <span>{t("admin.telegramVerified")}</span>
          <span className="mono">
            {data.verified_links} · {t("admin.telegramDeclared")}: {data.declared_links}
          </span>
        </div>
        <div>
          <span>{t("admin.telegramMessages")}</span>
          <span className="mono">{data.messages_handled}</span>
        </div>
        <div>
          <span>{t("admin.telegramApiBase")}</span>
          <span className="mono">{data.api_base}</span>
        </div>
      </div>

      <div className="grid grid--2" style={{ marginTop: "0.75rem" }}>
        <Field label={t("admin.telegramWebhookSecret")} hint={t("admin.telegramWebhookSecretHint")}>
          <div className="row">
            <input
              type="password"
              dir="ltr"
              value={webhookSecret}
              onChange={(event) => setWebhookSecret(event.target.value)}
              placeholder={data.webhook_secret.configured ? data.webhook_secret.hint : "——"}
              autoComplete="off"
            />
            <Button type="button" variant="subtle" onClick={saveWebhookSecret} loading={busy} disabled={!permission || webhookSecret.trim().length < 16}>
              {t("action.save")}
            </Button>
          </div>
        </Field>
        <div className="row" style={{ alignSelf: "end", gap: "0.5rem" }}>
          <Button variant="subtle" type="button" onClick={publishCommands} loading={busy} disabled={!permission || !data.token.configured}>
            {t("admin.telegramCommands")}
          </Button>
          {data.token.configured ? (
            <Button variant="ghost" type="button" onClick={clearToken} disabled={!permission || busy}>
              {t("admin.telegramClearToken")}
            </Button>
          ) : null}
        </div>
      </div>

      {(data.recent || []).length > 0 ? (
        <table className="table table--stack" style={{ marginTop: "0.75rem" }}>
          <thead>
            <tr>
              <th>{t("label.email")}</th>
              <th>{t("admin.telegram")}</th>
              <th>{t("admin.telegramNumericId")}</th>
              <th>{t("admin.telegramVerifiedVia")}</th>
              <th>{t("admin.telegramMessages")}</th>
            </tr>
          </thead>
          <tbody>
            {data.recent.map((row) => (
              <tr key={row.user_id}>
                <td data-label={t("label.email")}>{row.email || "—"}</td>
                <td data-label={t("admin.telegram")} className="mono">
                  {row.telegram_username ? `@${row.telegram_username}` : "—"}
                </td>
                <td data-label={t("admin.telegramNumericId")} className="mono">
                  {row.telegram_user_id || "—"}
                </td>
                <td data-label={t("admin.telegramVerifiedVia")}>
                  <Badge tone={row.verified_via === "code" ? "success" : "warning"}>
                    {row.verified_via === "code" ? t("telegram.verifiedViaCode") : t("telegram.verifiedViaProfile")}
                  </Badge>
                </td>
                <td data-label={t("admin.telegramMessages")} className="mono">
                  {row.message_count}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p className="muted small">{t("admin.telegramNoLinks")}</p>
      )}
    </Card>
  );
}
