import { useState } from "react";
import { api } from "../api/client";
import { Button, ConfirmCheckbox, CopyButton, ErrorNotice, Field, Modal } from "./ui";
import { useApp, useI18n } from "../state/app";

interface RoleOption {
  slug: string;
  name: string;
  description?: string | null;
  is_system?: boolean;
}

interface CreatedUser {
  user: { id: number; email: string; display_name: string; status: string; roles: string[] };
  generated_password: string | null;
  note: string | null;
}

/**
 * Admin → Users → “Create a user”.
 *
 * The API could always create accounts with any role combination (`POST /api/v1/admin/users`), but
 * the panel had no form for it: the operator could only look at accounts that had registered
 * themselves. This dialog exposes the whole endpoint — e-mail, display name, roles, status, optional
 * password (or a generated one shown exactly once), an initial credit grant that goes through the
 * ledger, per-day quotas and a note.
 */
export function CreateUserModal({
  open,
  onClose,
  onCreated,
  roles,
}: {
  open: boolean;
  onClose: () => void;
  onCreated: () => void;
  roles: RoleOption[];
}): JSX.Element {
  const { t } = useI18n();
  const { notify, user: actor } = useApp();
  const [form, setForm] = useState({
    email: "",
    display_name: "",
    password: "",
    status: "active",
    initial_credit: "0",
    notes: "",
    quota_requests_per_day: "",
  });
  const [selectedRoles, setSelectedRoles] = useState<string[]>(["user"]);
  const [generate, setGenerate] = useState(true);
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [created, setCreated] = useState<CreatedUser | null>(null);

  const reset = () => {
    setForm({ email: "", display_name: "", password: "", status: "active", initial_credit: "0", notes: "", quota_requests_per_day: "" });
    setSelectedRoles(["user"]);
    setGenerate(true);
    setConfirmed(false);
    setError(null);
    setCreated(null);
  };

  const close = () => {
    reset();
    onClose();
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const result = await api.post<CreatedUser>("/api/v1/admin/users", {
        email: form.email.trim().toLowerCase(),
        display_name: form.display_name.trim(),
        password: generate ? null : form.password,
        roles: selectedRoles,
        status: form.status,
        initial_credit_micro: Math.round(Number(form.initial_credit || "0") * 1_000_000),
        quota_requests_per_day: form.quota_requests_per_day ? Number(form.quota_requests_per_day) : null,
        notes: form.notes.trim() || null,
        confirm: confirmed,
      });
      setCreated(result);
      notify("success", t("adminUsers.createdNote"));
      onCreated();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const availableRoles = roles.length ? roles : [{ slug: "user", name: "user" }];

  return (
    <Modal
      open={open}
      wide
      title={t("adminUsers.createTitle")}
      onClose={close}
      footer={
        created ? (
          <Button type="button" onClick={close}>
            {t("action.close")}
          </Button>
        ) : (
          <>
            <Button variant="subtle" type="button" onClick={close} disabled={busy}>
              {t("action.cancel")}
            </Button>
            <Button type="submit" form="create-user-form" loading={busy} disabled={busy || !confirmed}>
              {t("adminUsers.create")}
            </Button>
          </>
        )
      }
    >
      {error ? <ErrorNotice error={error} /> : null}

      {created ? (
        <div className="stack">
          <div className="alert alert--success" role="status">
            <div>
              <strong>{created.user.email}</strong>
              <p className="alert__hint">
                {t("adminUsers.createdRoles")}: {created.user.roles.join(", ")} · {t("adminUsers.status")}:{" "}
                {created.user.status}
              </p>
            </div>
          </div>
          {created.generated_password ? (
            <Field label={t("adminUsers.generatedPassword")} hint={t("adminUsers.generatedPasswordHint")}>
              <div className="row">
                <input readOnly value={created.generated_password} dir="ltr" />
                <CopyButton value={created.generated_password} />
              </div>
            </Field>
          ) : null}
          {created.note ? <p className="muted small">{created.note}</p> : null}
          <p className="muted small">{t("adminUsers.mustChangePassword")}</p>
        </div>
      ) : (
        <form id="create-user-form" onSubmit={submit}>
          <div className="grid grid--2">
            <Field label={t("label.email")}>
              <input
                type="email"
                dir="ltr"
                value={form.email}
                onChange={(event) => setForm({ ...form, email: event.target.value })}
                required
                autoComplete="off"
              />
            </Field>
            <Field label={t("label.displayName")}>
              <input type="text" value={form.display_name} onChange={(event) => setForm({ ...form, display_name: event.target.value })} required />
            </Field>
          </div>

          <Field label={t("adminUsers.roles")} hint={t("adminUsers.rolesHint")}>
            <div className="pill-list">
              {availableRoles.map((role) => (
                <label key={role.slug} className="checkbox" title={role.description || role.name}>
                  <input
                    type="checkbox"
                    checked={selectedRoles.includes(role.slug)}
                    onChange={(event) =>
                      setSelectedRoles((current) =>
                        event.target.checked ? [...current, role.slug] : current.filter((slug) => slug !== role.slug),
                      )
                    }
                  />
                  <span>
                    {role.name} <span className="mono muted small">{role.slug}</span>
                  </span>
                </label>
              ))}
            </div>
          </Field>

          <div className="grid grid--3">
            <Field label={t("adminUsers.status")}>
              <select value={form.status} onChange={(event) => setForm({ ...form, status: event.target.value })}>
                <option value="active">active</option>
                <option value="pending">pending</option>
                <option value="suspended">suspended</option>
                <option value="deactivated">deactivated</option>
              </select>
            </Field>
            <Field label={t("adminUsers.initialCredit")} hint={t("adminUsers.initialCreditHint")}>
              <input
                type="number"
                step="0.5"
                min="0"
                value={form.initial_credit}
                onChange={(event) => setForm({ ...form, initial_credit: event.target.value })}
              />
            </Field>
            <Field label={t("adminUsers.quotaRequests")} hint={t("adminUsers.quotaHint")}>
              <input
                type="number"
                min="0"
                value={form.quota_requests_per_day}
                onChange={(event) => setForm({ ...form, quota_requests_per_day: event.target.value })}
                placeholder="—"
              />
            </Field>
          </div>

          <label className="checkbox" style={{ marginBottom: "0.6rem" }}>
            <input type="checkbox" checked={generate} onChange={(event) => setGenerate(event.target.checked)} />
            <span>{t("adminUsers.generatePassword")}</span>
          </label>
          {!generate ? (
            <Field label={t("label.password")} hint={t("adminUsers.passwordHint")}>
              <input
                type="text"
                dir="ltr"
                value={form.password}
                onChange={(event) => setForm({ ...form, password: event.target.value })}
                required
                autoComplete="off"
              />
            </Field>
          ) : null}

          <Field label={t("adminUsers.notes")}>
            <textarea value={form.notes} onChange={(event) => setForm({ ...form, notes: event.target.value })} />
          </Field>

          <ConfirmCheckbox checked={confirmed} onChange={setConfirmed} label={t("admin.confirmSensitive")} />
          <p className="muted small">
            {t("adminUsers.createNote")}
            {actor?.email ? ` (${t("label.created")}: ${actor.email})` : ""}
          </p>
        </form>
      )}
    </Modal>
  );
}
