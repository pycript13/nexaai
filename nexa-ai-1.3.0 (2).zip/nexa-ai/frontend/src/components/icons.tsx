/**
 * Inline SVG icon set — no icon dependency, no external requests, RTL-aware.
 *
 * Every glyph is a stroked 24×24 path that inherits `currentColor`, so it works in
 * both themes and in forced-colors mode. Icons are decorative: they carry
 * `aria-hidden`, and the accessible name always comes from the surrounding text.
 */
import React from "react";

export type IconName =
  | "dashboard"
  | "chat"
  | "code"
  | "image"
  | "document"
  | "data"
  | "translate"
  | "audio"
  | "mic"
  | "video"
  | "brain"
  | "folder"
  | "attach"
  | "expand"
  | "panel"
  | "gear"
  | "wallet"
  | "share"
  | "gift"
  | "receipt"
  | "sparkles"
  | "user"
  | "shield"
  | "clock"
  | "gauge"
  | "users"
  | "key"
  | "server"
  | "tag"
  | "layers"
  | "list"
  | "sliders"
  | "scroll"
  | "lock"
  | "monitor"
  | "alert"
  | "database"
  | "sun"
  | "moon"
  | "contrast"
  | "languages"
  | "logout"
  | "menu"
  | "close"
  | "plus"
  | "chevron-down"
  | "chevron-end"
  | "check"
  | "copy"
  | "download"
  | "upload"
  | "play"
  | "refresh"
  | "external"
  | "search"
  | "info"
  | "bolt"
  | "cpu"
  | "trash"
  | "eye"
  | "more"
  | "arrow-up-right"
  | "trend-up"
  | "trend-down"
  | "filter"
  | "mail"
  | "chart-line" | "pencil" | "pin";

const PATHS: Record<IconName, React.ReactNode> = {
  dashboard: (
    <>
      <rect x="3" y="3" width="7.5" height="7.5" rx="2" />
      <rect x="13.5" y="3" width="7.5" height="4.5" rx="2" />
      <rect x="13.5" y="10.5" width="7.5" height="10.5" rx="2" />
      <rect x="3" y="13.5" width="7.5" height="7.5" rx="2" />
    </>
  ),
  chat: <path d="M20.5 12a8 8 0 0 1-11.6 7.1L4 20.5l1.4-4.9A8 8 0 1 1 20.5 12Z" />,
  code: (
    <>
      <path d="m9 8-4.5 4L9 16" />
      <path d="m15 8 4.5 4L15 16" />
    </>
  ),
  image: (
    <>
      <rect x="3" y="4.5" width="18" height="15" rx="2.5" />
      <circle cx="8.5" cy="10" r="1.6" />
      <path d="m4 17 4.6-4.3a2 2 0 0 1 2.7 0L20 19.5" />
    </>
  ),
  document: (
    <>
      <path d="M14 3.5H7.5A2.5 2.5 0 0 0 5 6v12a2.5 2.5 0 0 0 2.5 2.5h9A2.5 2.5 0 0 0 19 18V8.5Z" />
      <path d="M14 3.5V8a1 1 0 0 0 1 1h4" />
      <path d="M8.5 13h7M8.5 16.5h4.5" />
    </>
  ),
  data: (
    <>
      <path d="M4 20V9M10 20V4M16 20v-7M22 20H2" />
    </>
  ),
  translate: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M3.5 12h17M12 3.5c2.5 2.4 3.7 5.4 3.7 8.5S14.5 18.1 12 20.5c-2.5-2.4-3.7-5.4-3.7-8.5S9.5 5.9 12 3.5Z" />
    </>
  ),
  mic: (
    <>
      <rect x="9" y="3" width="6" height="11" rx="3" />
      <path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3" />
    </>
  ),
  audio: (
    <>
      <path d="M4 10v4M8 6.5v11M12 4v16M16 7.5v9M20 10.5v3" />
    </>
  ),
  video: (
    <>
      <rect x="3" y="5" width="13" height="14" rx="2.5" />
      <path d="M16 10.5 21 8v8l-5-2.5Z" />
    </>
  ),
  brain: (
    <>
      <path d="M12 5.5a3 3 0 0 0-5.7-1.2A2.8 2.8 0 0 0 4 7.1a3 3 0 0 0 .6 1.8A3 3 0 0 0 4.9 14a3 3 0 0 0 2.3 4.4A3 3 0 0 0 12 19.5Z" />
      <path d="M12 5.5a3 3 0 0 1 5.7-1.2A2.8 2.8 0 0 1 20 7.1a3 3 0 0 1-.6 1.8 3 3 0 0 1-.3 5.1 3 3 0 0 1-2.3 4.4A3 3 0 0 1 12 19.5Z" />
      <path d="M12 5.5v14" />
    </>
  ),
  folder: <path d="M3 7.5A2.5 2.5 0 0 1 5.5 5h3.2a2 2 0 0 1 1.6.8l1 1.4h7.2A2.5 2.5 0 0 1 21 9.7v7.8a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5Z" />,
  attach: <path d="M20.5 12.8 13 20.3a5.3 5.3 0 0 1-7.5-7.5L13 5.3a3.55 3.55 0 0 1 5 5l-7.4 7.4a1.8 1.8 0 0 1-2.5-2.5l6.7-6.7" />,
  expand: <path d="M9 4H4v5M15 4h5v5M9 20H4v-5M15 20h5v-5" />,
  panel: <path d="M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v13a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 18.5ZM9.5 3v18" />,
  gear: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M12 3.5v2.2M12 18.3v2.2M4.9 7.8l1.9 1.1M17.2 15.1l1.9 1.1M4.9 16.2l1.9-1.1M17.2 8.9l1.9-1.1" />
    </>
  ),
  wallet: (
    <>
      <rect x="3" y="6" width="18" height="13" rx="3" />
      <path d="M3 10.5h18M16.5 14.5h1.5" />
    </>
  ),
  share: (
    <>
      <circle cx="6" cy="12" r="2.5" />
      <circle cx="17" cy="5.5" r="2.5" />
      <circle cx="17" cy="18.5" r="2.5" />
      <path d="M8.2 10.8 14.8 6.8M8.2 13.2l6.6 4" />
    </>
  ),
  gift: (
    <>
      <rect x="4" y="10" width="16" height="9" rx="1.5" />
      <path d="M12 10v9M4 14.5h16M12 10a2.8 2.8 0 1 1 2.8-2.8C14.8 9 12 10 12 10Zm0 0a2.8 2.8 0 1 0-2.8-2.8C9.2 9 12 10 12 10Z" />
    </>
  ),
  receipt: (
    <>
      <path d="M6 3.5h12v17l-3-2-3 2-3-2-3 2Z" />
      <path d="M9 8.5h6M9 12h6" />
    </>
  ),
  sparkles: (
    <>
      <path d="M12 4.5l1.6 4.2 4.4 1.6-4.4 1.6L12 16.3l-1.6-4.4L6 10.3l4.4-1.6Z" />
      <path d="M18.5 15.5l.7 1.8 1.8.7-1.8.7-.7 1.8-.7-1.8-1.8-.7 1.8-.7Z" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8.5" r="3.5" />
      <path d="M4.8 20a7.6 7.6 0 0 1 14.4 0" />
    </>
  ),
  shield: (
    <>
      <path d="M12 3.5 5 6v6c0 4 3 7.2 7 8.5 4-1.3 7-4.5 7-8.5V6Z" />
      <path d="m9.2 12 2 2 3.6-3.8" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7.5V12l3 2" />
    </>
  ),
  gauge: (
    <>
      <path d="M4 16a8 8 0 1 1 16 0" />
      <path d="m12 16 3.5-4.5" />
    </>
  ),
  users: (
    <>
      <circle cx="9.5" cy="8.5" r="3.2" />
      <path d="M3.5 19.5a6.3 6.3 0 0 1 12 0M16 5.6a3.2 3.2 0 0 1 0 6M17.5 14.4a6.3 6.3 0 0 1 3 5.1" />
    </>
  ),
  key: (
    <>
      <circle cx="8.5" cy="12" r="3.5" />
      <path d="M12 12h8.5M17.5 12v3M20.5 12v2.5" />
    </>
  ),
  server: (
    <>
      <rect x="3.5" y="4" width="17" height="6.5" rx="2" />
      <rect x="3.5" y="13.5" width="17" height="6.5" rx="2" />
      <path d="M7 7.2h.01M7 16.7h.01" />
    </>
  ),
  tag: (
    <>
      <path d="M12.6 3.5H19a1.5 1.5 0 0 1 1.5 1.5v6.4a2 2 0 0 1-.6 1.4l-6.6 6.6a2 2 0 0 1-2.8 0l-5.4-5.4a2 2 0 0 1 0-2.8l6.2-6.2a2 2 0 0 1 1.3-.5Z" />
      <path d="M16 8h.01" />
    </>
  ),
  layers: (
    <>
      <path d="m12 3.5 8 4.2-8 4.2-8-4.2Z" />
      <path d="m4 12.5 8 4.2 8-4.2M4 16.6l8 4.2 8-4.2" />
    </>
  ),
  list: (
    <>
      <path d="M8.5 6.5h12M8.5 12h12M8.5 17.5h12M3.5 6.5h.01M3.5 12h.01M3.5 17.5h.01" />
    </>
  ),
  sliders: (
    <>
      <path d="M5 8h9M18 8h1M5 16h3M12 16h7" />
      <circle cx="16" cy="8" r="2" />
      <circle cx="10" cy="16" r="2" />
    </>
  ),
  scroll: (
    <>
      <path d="M6.5 4.5h11v15h-11z" />
      <path d="M9.5 8.5h5M9.5 12h5M9.5 15.5h3" />
    </>
  ),
  lock: (
    <>
      <rect x="4.5" y="10" width="15" height="10.5" rx="2.5" />
      <path d="M8.5 10V7.5a3.5 3.5 0 0 1 7 0V10" />
    </>
  ),
  monitor: (
    <>
      <rect x="3" y="4.5" width="18" height="12" rx="2.5" />
      <path d="M9 20.5h6M12 16.5v4" />
    </>
  ),
  alert: (
    <>
      <path d="M10.3 4.9 3.6 16.4A2 2 0 0 0 5.3 19.5h13.4a2 2 0 0 0 1.7-3.1L13.7 4.9a2 2 0 0 0-3.4 0Z" />
      <path d="M12 9.5v4M12 16.5h.01" />
    </>
  ),
  database: (
    <>
      <ellipse cx="12" cy="6.5" rx="7.5" ry="3" />
      <path d="M4.5 6.5v11c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3v-11M4.5 12c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3" />
    </>
  ),
  sun: (
    <>
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2.5v2M12 19.5v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M2.5 12h2M19.5 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4" />
    </>
  ),
  moon: <path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5Z" />,
  contrast: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 3.5v17a8.5 8.5 0 0 0 0-17Z" fill="currentColor" stroke="none" opacity="0.5" />
    </>
  ),
  languages: (
    <>
      <path d="M4 6h8M8 6c0 4-1.6 7.6-4 10" />
      <path d="M5.5 12.5A10 10 0 0 0 11 15.5M12 20l4-9 4 9M13.6 17h4.8" />
    </>
  ),
  logout: (
    <>
      <path d="M15 8.5V6a2 2 0 0 0-2-2H6.5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2H13a2 2 0 0 0 2-2v-2.5" />
      <path d="M10.5 12H21M18 8.5 21.5 12 18 15.5" />
    </>
  ),
  menu: <path d="M4 7h16M4 12h16M4 17h10" />,
  close: <path d="m6 6 12 12M18 6 6 18" />,
  plus: <path d="M12 5v14M5 12h14" />,
  "chevron-down": <path d="m6 9.5 6 6 6-6" />,
  "chevron-end": <path d="m9.5 6 6 6-6 6" />,
  check: <path d="m5 12.5 4.5 4.5L19 7" />,
  copy: (
    <>
      <rect x="9" y="9" width="11" height="11" rx="2.5" />
      <path d="M15 6.5V5.5a2 2 0 0 0-2-2H5.5a2 2 0 0 0-2 2V13a2 2 0 0 0 2 2h1" />
    </>
  ),
  pencil: (
    <>
      <path d="M4 20h4l10.5-10.5a2.1 2.1 0 0 0-3-3L5 17v3z" />
      <path d="M13.5 6.5l3 3" />
    </>
  ),
  pin: (
    <>
      <path d="M9 4h6l-1 6 3.2 3.2c.5.5.1 1.3-.6 1.3H7.4c-.7 0-1.1-.8-.6-1.3L10 10 9 4z" />
      <path d="M12 14.5V20" />
    </>
  ),
  download: <path d="M12 4v11M7.5 11 12 15.5 16.5 11M5 19.5h14" />,
  upload: <path d="M12 15.5V4.5M7.5 9 12 4.5 16.5 9M5 19.5h14" />,
  play: <path d="M8 5.5v13l11-6.5Z" />,
  refresh: (
    <>
      <path d="M20 12a8 8 0 1 1-2.6-5.9" />
      <path d="M20 4.5V10h-5.5" />
    </>
  ),
  external: (
    <>
      <path d="M13.5 4.5H19.5V10.5" />
      <path d="M19.5 4.5 11 13" />
      <path d="M18 14.5v3.5a2 2 0 0 1-2 2H6.5a2 2 0 0 1-2-2V8.5a2 2 0 0 1 2-2H10" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="6.5" />
      <path d="m16 16 4.5 4.5" />
    </>
  ),
  info: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 11v5M12 8h.01" />
    </>
  ),
  bolt: <path d="M13.5 3 6 13.5h5L10.5 21 18 10.5h-5Z" />,
  cpu: (
    <>
      <rect x="7" y="7" width="10" height="10" rx="2.5" />
      <path d="M10.5 3.5V7M13.5 3.5V7M10.5 17v3.5M13.5 17v3.5M3.5 10.5H7M3.5 13.5H7M17 10.5h3.5M17 13.5h3.5" />
    </>
  ),
  trash: (
    <>
      <path d="M4.5 7h15M9.5 7V5a1.5 1.5 0 0 1 1.5-1.5h2A1.5 1.5 0 0 1 14.5 5v2" />
      <path d="M6.5 7l.8 12a2 2 0 0 0 2 1.9h5.4a2 2 0 0 0 2-1.9L17.5 7" />
    </>
  ),
  eye: (
    <>
      <path d="M2.5 12S6 6 12 6s9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z" />
      <circle cx="12" cy="12" r="2.8" />
    </>
  ),
  more: (
    <>
      <circle cx="12" cy="5.5" r="1.4" fill="currentColor" stroke="none" />
      <circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none" />
      <circle cx="12" cy="18.5" r="1.4" fill="currentColor" stroke="none" />
    </>
  ),
  "arrow-up-right": <path d="M7 17 17 7M9 7h8v8" />,
  "trend-up": (
    <>
      <path d="m3.5 16.5 5-5 4 4 8-8" />
      <path d="M15.5 7.5h5v5" />
    </>
  ),
  "trend-down": (
    <>
      <path d="m3.5 7.5 5 5 4-4 8 8" />
      <path d="M15.5 16.5h5v-5" />
    </>
  ),
  filter: <path d="M4 6h16M7 12h10M10 18h4" />,
  mail: (
    <>
      <rect x="3" y="5.5" width="18" height="13" rx="2.5" />
      <path d="m4.5 8 6.6 4.6a1.6 1.6 0 0 0 1.8 0L19.5 8" />
    </>
  ),
  "chart-line": (
    <>
      <path d="M4 19.5h16" />
      <path d="m5.5 15 4-4.5 3.2 3L19 6.5" />
    </>
  ),
};

export function Icon({
  name,
  size = 18,
  strokeWidth = 1.7,
  className = "",
}: {
  name: IconName;
  size?: number;
  strokeWidth?: number;
  className?: string;
}): JSX.Element {
  return (
    <svg
      className={`icon ${className}`.trim()}
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
    >
      {PATHS[name]}
    </svg>
  );
}

/** The product mark: a gradient tile with an N-shaped sparkline. Pure SVG + CSS. */
export function LogoMark({ size = 38, className = "" }: { size?: number; className?: string }): JSX.Element {
  return (
    <span className={`logo-mark ${className}`.trim()} style={{ width: size, height: size }} aria-hidden="true">
      <svg viewBox="0 0 32 32" width={size} height={size} fill="none" aria-hidden="true">
        <path
          d="M9 23V9.5l14 13V9"
          stroke="currentColor"
          strokeWidth="2.6"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle cx="9" cy="9.5" r="2.1" fill="currentColor" />
        <circle cx="23" cy="22.5" r="1.6" fill="currentColor" opacity="0.75" />
      </svg>
    </span>
  );
}
