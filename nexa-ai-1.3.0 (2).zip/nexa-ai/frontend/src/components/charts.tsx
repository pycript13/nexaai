/** Lightweight inline SVG charts (no external chart dependency). */
import React from "react";

export function BarChart({
  data,
  height = 160,
  format,
}: {
  data: { label: string; value: number }[];
  height?: number;
  format?: (value: number) => string;
}): JSX.Element {
  if (data.length === 0) return <p className="muted">—</p>;
  const max = Math.max(...data.map((item) => item.value), 1);
  return (
    <div className="chart">
      {data.map((item) => (
        <div className="chart__row" key={item.label}>
          <span className="chart__label">{item.label}</span>
          <span className="chart__track">
            <span className="chart__bar" style={{ width: `${Math.max((item.value / max) * 100, 1)}%` }} />
          </span>
          <span className="chart__value">{format ? format(item.value) : item.value}</span>
        </div>
      ))}
    </div>
  );
}

export function Sparkline({ points, height = 60 }: { points: number[]; height?: number }): JSX.Element {
  if (points.length === 0) return <p className="muted">—</p>;
  const max = Math.max(...points, 1);
  const min = Math.min(...points, 0);
  const span = max - min || 1;
  const width = 320;
  const step = points.length > 1 ? width / (points.length - 1) : width;
  const path = points
    .map((value, index) => `${index === 0 ? "M" : "L"} ${(index * step).toFixed(1)} ${(height - ((value - min) / span) * height).toFixed(1)}`)
    .join(" ");
  return (
    <svg className="sparkline" viewBox={`0 0 ${width} ${height}`} height={height} role="img" aria-label="trend">
      <path d={path} fill="none" stroke="currentColor" strokeWidth="2" />
    </svg>
  );
}

export function Donut({ segments }: { segments: { label: string; value: number; color: string }[] }): JSX.Element {
  const total = segments.reduce((sum, item) => sum + item.value, 0);
  let offset = 0;
  const radius = 42;
  const circumference = 2 * Math.PI * radius;
  return (
    <div className="donut">
      <svg viewBox="0 0 120 120" width="120" height="120" role="img" aria-label="distribution">
        <circle cx="60" cy="60" r={radius} fill="none" stroke="var(--surface-2)" strokeWidth="16" />
        {total > 0 &&
          segments.map((segment) => {
            const length = (segment.value / total) * circumference;
            const element = (
              <circle
                key={segment.label}
                cx="60"
                cy="60"
                r={radius}
                fill="none"
                stroke={segment.color}
                strokeWidth="16"
                strokeDasharray={`${length} ${circumference - length}`}
                strokeDashoffset={-offset}
                transform="rotate(-90 60 60)"
              />
            );
            offset += length;
            return element;
          })}
      </svg>
      <ul className="donut__legend">
        {segments.map((segment) => (
          <li key={segment.label}>
            <span className="donut__swatch" style={{ background: segment.color }} />
            {segment.label}
            <strong>{total > 0 ? `${Math.round((segment.value / total) * 100)}%` : "—"}</strong>
          </li>
        ))}
      </ul>
    </div>
  );
}
