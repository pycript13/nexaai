/** Small, dependency-free UI primitives used across the whole application. */
import React, { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { ApiError } from "../api/client";
import type { Pagination as PaginationMeta } from "../api/types";
import { useApp, useI18n } from "../state/app";
import { Icon, type IconName } from "./icons";

export function Card({
  title,
  subtitle,
  actions,
  children,
  className = "",
  danger = false,
  icon,
  hover = false,
  accent = false,
  footer,
}: {
  title?: React.ReactNode;
  subtitle?: React.ReactNode;
  actions?: React.ReactNode;
  children?: React.ReactNode;
  className?: string;
  danger?: boolean;
  /** Optional leading glyph for the card title. */
  icon?: IconName;
  /** Lift the card on hover (use for cards that behave like links). */
  hover?: boolean;
  /** Draw the brand gradient hairline on top. */
  accent?: boolean;
  footer?: React.ReactNode;
}): JSX.Element {
  return (
    <section className={`card ${danger ? "card--danger" : ""} ${hover ? "card--hover" : ""} ${accent ? "card--accent" : ""} ${className}`}>
      {(title || actions) && (
        <header className="card__head">
          <div>
            {title && (
              <h2 className="card__title">
                {icon ? <Icon name={icon} size={17} /> : null}
                {title}
              </h2>
            )}
            {subtitle && <p className="card__subtitle">{subtitle}</p>}
          </div>
          {actions && <div className="card__actions">{actions}</div>}
        </header>
      )}
      <div className="card__body">{children}</div>
      {footer && <div className="card__foot">{footer}</div>}
    </section>
  );
}

export function Badge({ children, tone = "neutral" }: { children: React.ReactNode; tone?: string }): JSX.Element {
  return <span className={`badge badge--${tone}`}>{children}</span>;
}

export function StatusBadge({ value }: { value?: string | null }): JSX.Element {
  const tone =
    {
      active: "success",
      succeeded: "success",
      approved: "success",
      ok: "success",
      available: "success",
      enabled: "success",
      published: "success",
      pending: "warning",
      running: "warning",
      awaiting_review: "warning",
      untested: "warning",
      degraded: "warning",
      suspended: "danger",
      failed: "danger",
      cancelled: "danger",
      rejected: "danger",
      disabled: "danger",
      expired: "danger",
      refunded: "info",
      partially_refunded: "info",
      hidden: "info",
    }[String(value || "")] || "neutral";
  return <Badge tone={tone}>{value || "—"}</Badge>;
}

export function Spinner({ label, center = false }: { label?: string; center?: boolean }): JSX.Element {
  const { t } = useI18n();
  return (
    <div className={`spinner ${center ? "spinner--center" : ""}`} role="status" aria-live="polite">
      <span className="spinner__dot" />
      <span>{label || t("status.loading")}</span>
    </div>
  );
}

/** Shimmer placeholders — used instead of a spinner where the layout is already known. */
export function Skeleton({ lines = 3, className = "" }: { lines?: number; className?: string }): JSX.Element {
  const { t } = useI18n();
  return (
    <div className={`stack stack--tight ${className}`} role="status" aria-live="polite" aria-label={t("status.loading")}>
      {Array.from({ length: Math.max(1, lines) }).map((_, index) => (
        <div
          key={index}
          className={index === 0 ? "skeleton skeleton--block" : "skeleton skeleton--line"}
          style={index === 0 ? undefined : { width: `${88 - index * 9}%` }}
        />
      ))}
    </div>
  );
}

export function Progress({
  value,
  max = 100,
  label,
  hint,
  tone,
}: {
  value: number;
  max?: number;
  label?: React.ReactNode;
  hint?: React.ReactNode;
  tone?: "success" | "warning" | "danger";
}): JSX.Element {
  const safeMax = max > 0 ? max : 1;
  const percent = Math.max(0, Math.min(100, (value / safeMax) * 100));
  return (
    <div className={`progress ${tone ? `progress--${tone}` : ""}`}>
      {(label || hint) && (
        <div className="progress__head">
          <span>{label}</span>
          <span>{hint ?? `${percent.toFixed(1)}%`}</span>
        </div>
      )}
      <div
        className="progress__track"
        role="progressbar"
        aria-valuenow={Math.round(percent)}
        aria-valuemin={0}
        aria-valuemax={100}
      >
        <span className="progress__bar" style={{ width: `${percent}%` }} />
      </div>
    </div>
  );
}

export function EmptyState({
  title,
  hint,
  action,
  icon = "sparkles",
}: {
  title?: string;
  hint?: string;
  action?: React.ReactNode;
  icon?: IconName;
}): JSX.Element {
  const { t } = useI18n();
  return (
    <div className="empty">
      <span className="empty__art" aria-hidden>
        <Icon name={icon} size={26} />
      </span>
      <p className="empty__title">{title || t("status.empty")}</p>
      {hint && <p className="empty__hint">{hint}</p>}
      {action}
    </div>
  );
}

export function Avatar({ name, size = 34 }: { name: string; size?: number }): JSX.Element {
  const initials = (name || "?")
    .split(/[\s@._-]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
  return (
    <span className="avatar" style={{ width: size, height: size, fontSize: size * 0.36 }} aria-hidden>
      {initials || "?"}
    </span>
  );
}

export function ErrorNotice({ error, onRetry }: { error: unknown; onRetry?: () => void }): JSX.Element {
  const { t } = useI18n();
  const apiError = error instanceof ApiError ? error : null;
  const message = apiError ? apiError.message : error instanceof Error ? error.message : String(error);
  const guidance = apiError?.guidance;
  return (
    <div className="alert alert--error" role="alert">
      <div className="alert__body">
        <Icon name="alert" size={18} />
        <div>
          <strong>{t("status.error")}</strong>
          <p>{message}</p>
          {guidance ? <p className="alert__hint">{guidance}</p> : null}
          {apiError?.category ? <code className="alert__code">{apiError.category}</code> : null}
        </div>
      </div>
      {onRetry && (
        <button className="btn btn--ghost btn--sm" onClick={onRetry} type="button">
          {t("action.retry")}
        </button>
      )}
    </div>
  );
}

export function SuccessNotice({ message, hint }: { message: string; hint?: string }): JSX.Element {
  return (
    <div className="alert alert--success" role="status">
      <div className="alert__body">
        <Icon name="check" size={18} />
        <div>
          <strong>{message}</strong>
          {hint ? <p className="alert__hint">{hint}</p> : null}
        </div>
      </div>
    </div>
  );
}

export function Button({
  children,
  variant = "primary",
  loading = false,
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "danger" | "subtle"; loading?: boolean }): JSX.Element {
  return (
    <button {...rest} className={`btn btn--${variant} ${rest.className || ""}`} disabled={rest.disabled || loading}>
      {loading ? <span className="btn__spinner" aria-hidden /> : null}
      {children}
    </button>
  );
}

/** Round icon button (topbar, card actions, row tools). */
export function IconButton({
  icon,
  label,
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { icon: IconName; label: string }): JSX.Element {
  return (
    <button {...rest} className={`iconbtn ${rest.className || ""}`} type={rest.type || "button"} aria-label={label} title={label}>
      <Icon name={icon} size={18} />
    </button>
  );
}

export function Field({
  label,
  hint,
  error,
  children,
}: {
  label?: string;
  hint?: string;
  error?: string | null;
  children: React.ReactNode;
}): JSX.Element {
  return (
    <label className="field">
      {label && <span className="field__label">{label}</span>}
      {children}
      {hint && <span className="field__hint">{hint}</span>}
      {error && <span className="field__error">{error}</span>}
    </label>
  );
}

export function Modal({
  open,
  title,
  onClose,
  children,
  footer,
  wide = false,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  footer?: React.ReactNode;
  wide?: boolean;
}): JSX.Element | null {
  const { t } = useI18n();
  useEffect(() => {
    if (!open) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handler);
      document.body.style.overflow = previous;
    };
  }, [open, onClose]);
  if (!open) return null;
  // Rendered through a portal: cards use `backdrop-filter`, which makes them the
  // containing block for `position: fixed` descendants. Without the portal a dialog
  // opened from inside a card would be clipped to that card instead of the viewport.
  return createPortal(
    <div className="modal" role="dialog" aria-modal="true" aria-label={title}>
      <div className="modal__backdrop" onClick={onClose} />
      <div className={`modal__panel ${wide ? "modal__panel--wide" : ""}`}>
        <header className="modal__head">
          <h3>{title}</h3>
          <IconButton icon="close" label={t("action.close")} className="iconbtn--ghost" onClick={onClose} />
        </header>
        <div className="modal__body">{children}</div>
        <footer className="modal__foot">
          {/* Exactly one dismiss control per dialog: when the caller brings its own footer
             (Cancel/Save, Reject/Approve, …) the built-in Close button is not rendered, so a
             dialog can never show two "close" buttons. The header ✕ stays as the fast exit. */}
          {footer ?? (
            <Button variant="subtle" onClick={onClose} type="button">
              {t("action.close")}
            </Button>
          )}
        </footer>
      </div>
    </div>,
    document.body,
  );
}

export function Pagination({
  meta,
  onChange,
}: {
  meta?: PaginationMeta;
  onChange: (page: number) => void;
}): JSX.Element | null {
  const { t } = useI18n();
  if (!meta || meta.pages <= 1) return null;
  return (
    <div className="pagination">
      <Button variant="ghost" disabled={!meta.has_prev} onClick={() => onChange(meta.page - 1)} type="button">
        {t("common.previous")}
      </Button>
      <span>
        {t("common.page")} {meta.page} {t("common.of")} {meta.pages}
      </span>
      <Button variant="ghost" disabled={!meta.has_next} onClick={() => onChange(meta.page + 1)} type="button">
        {t("common.next")}
      </Button>
    </div>
  );
}

export interface Column<T> {
  key: string;
  header: React.ReactNode;
  render: (row: T) => React.ReactNode;
  className?: string;
  /**
   * Field name printed next to the value when the table restacks into cards on a phone.
   * Defaults to `header` whenever that is plain text; set it explicitly for icon or
   * component headers so every stacked row still says what each value means.
   */
  label?: string;
}

/**
 * The field name for the stacked (phone) layout. Returns `undefined` when the column has
 * no textual header — CSS then leaves that cell unlabelled instead of printing an empty
 * label box.
 */
export function columnLabel<T>(column: Column<T>): string | undefined {
  if (column.label) return column.label;
  return typeof column.header === "string" ? column.header : undefined;
}

export function DataTable<T extends { id?: number | string }>({
  columns,
  rows,
  empty,
  loading,
  /** Set to false for tables that must keep the grid layout on phones. */
  stack = true,
}: {
  columns: Column<T>[];
  rows: T[];
  empty?: React.ReactNode;
  loading?: boolean;
  stack?: boolean;
}): JSX.Element {
  if (loading) return <Skeleton lines={4} />;
  if (rows.length === 0) return <>{empty || <EmptyState />}</>;
  return (
    <div className={stack ? "table-wrap table-wrap--stack" : "table-wrap"}>
      <table className={stack ? "table table--stack" : "table"}>
        <thead>
          <tr>
            {columns.map((column) => (
              <th key={column.key} className={column.className}>
                {column.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, index) => (
            <tr key={String(row.id ?? index)}>
              {columns.map((column) => (
                <td key={column.key} className={column.className} data-label={columnLabel(column)}>
                  {column.render(row)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function Stat({
  label,
  value,
  hint,
  tone,
  icon,
  delta,
  deltaTone = "neutral",
}: {
  label: string;
  value: React.ReactNode;
  hint?: string;
  tone?: "success" | "danger" | "warning";
  icon?: IconName;
  delta?: string;
  deltaTone?: "up" | "down" | "neutral";
}): JSX.Element {
  return (
    <div className={`stat ${tone ? `stat--${tone}` : ""}`}>
      {(icon || delta) && (
        <div className="stat__top">
          {icon ? (
            <span className="stat__icon">
              <Icon name={deltaTone === "up" ? "trend-up" : deltaTone === "down" ? "trend-down" : icon} size={19} />
            </span>
          ) : (
            <span />
          )}
          {delta ? <span className={`stat__delta stat__delta--${deltaTone}`}>{delta}</span> : null}
        </div>
      )}
      <span className="stat__label">{label}</span>
      <span className="stat__value">{value}</span>
      {hint && <span className="stat__hint">{hint}</span>}
    </div>
  );
}

/** Hook for GET requests with loading/error/refresh handling. */
export function useApi<T>(
  loader: () => Promise<T>,
  deps: React.DependencyList = [],
): { data: T | null; error: unknown; loading: boolean; reload: () => void } {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(true);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    loader()
      .then((result) => {
        if (!cancelled) setData(result);
      })
      .catch((caught) => {
        if (!cancelled) setError(caught);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);

  const reload = useMemo(() => () => setTick((value) => value + 1), []);
  return { data, error, loading, reload };
}

export function ConfirmCheckbox({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  label: string;
}): JSX.Element {
  return (
    <label className="checkbox">
      <input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} />
      <span>{label}</span>
    </label>
  );
}

export function CopyButton({ value, label }: { value: string; label?: string }): JSX.Element {
  const { t } = useI18n();
  const { notify } = useApp();
  return (
    <Button
      variant="ghost"
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value);
          notify("success", t("action.copy"));
        } catch {
          notify("error", "Clipboard unavailable in this browser context.");
        }
      }}
    >
      <Icon name="copy" size={16} />
      {label || t("action.copy")}
    </Button>
  );
}

/** Accessible on/off switch (used by settings screens). */
export function Switch({
  checked,
  onChange,
  label,
  disabled = false,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  label: string;
  disabled?: boolean;
}): JSX.Element {
  return (
    <label className="switch">
      <input
        type="checkbox"
        checked={checked}
        disabled={disabled}
        onChange={(event) => onChange(event.target.checked)}
      />
      <span className="switch__track" aria-hidden />
      <span>{label}</span>
    </label>
  );
}
