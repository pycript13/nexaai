import { useState } from "react";
import { api } from "../api/client";
import { Badge, Button, Card, CopyButton, DataTable, ErrorNotice, Field, Modal, useApi } from "./ui";
import { useApp, useI18n } from "../state/app";
import { formatDateTime } from "../utils/format";

interface Invitation {
  id: number;
  email: string | null;
  note: string | null;
  created_at: string | null;
  expires_at: string | null;
  expires_days: number;
  used: boolean;
  expired: boolean;
  status: string;
  revoked: boolean;
}

interface CreatedInvitation {
  email: string;
  token: string;
  link: string;
  expires_days: number;
  instructions: string;
  email_sent?: boolean;
  email_note?: string;
}

/**
 * Admin → Users → Invitations.
 *
 * Invitation-only registration existed as a setting but nothing could issue a token, so switching
 * the platform to `invite_only` locked everybody out — the operator could not even invite a friend.
 * This card issues single-use links, shows which ones are still active, and revokes them. The link
 * carries the token as `?invite=…`, which the sign-up form reads automatically.
 */
export function InvitationsCard(): JSX.Element {
  const { t, locale } = useI18n();
  const { notify, hasPermission } = useApp();
  const invitations = useApi<{ items: Invitation[]; total: number }>(
    () => api.get("/api/v1/admin/users/invitations"),
    [],
  );
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [days, setDays] = useState("14");
  const [note, setNote] = useState("");
  const [sendEmail, setSendEmail] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [created, setCreated] = useState<CreatedInvitation | null>(null);

  const canIssue = hasPermission("users.create");

  const issue = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const result = await api.post<CreatedInvitation>("/api/v1/admin/users/invitations", {
        email: email.trim() || null,
        expires_days: Number(days) || 14,
        note: note.trim() || null,
        send_email: sendEmail,
      });
      setCreated(result);
      notify("success", t("invitations.created"));
      invitations.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const revoke = async (item: Invitation) => {
    setBusy(true);
    setError(null);
    try {
      await api.del(`/api/v1/admin/users/invitations/${item.id}`);
      notify("success", t("invitations.revoked"));
      invitations.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const close = () => {
    setOpen(false);
    setCreated(null);
    setEmail("");
    setNote("");
    setSendEmail(false);
    setError(null);
  };

  const items = invitations.data?.items || [];

  return (
    <Card
      icon="users"
      title={t("invitations.title")}
      subtitle={t("invitations.subtitle")}
      actions={
        canIssue ? (
          <Button type="button" onClick={() => setOpen(true)}>
            {t("invitations.create")}
          </Button>
        ) : null
      }
    >
      {invitations.error ? <ErrorNotice error={invitations.error} onRetry={invitations.reload} /> : null}
      <DataTable
        loading={invitations.loading}
        rows={items}
        empty={t("invitations.empty")}
        columns={[
          {
            key: "email",
            header: t("label.email"),
            render: (row) => (row.email && row.email.endsWith("@local") ? <span className="muted">{t("invitations.anonymous")}</span> : row.email || "—"),
          },
          {
            key: "status",
            header: t("label.status"),
            render: (row) => (
              <Badge tone={row.status === "active" ? "success" : row.status === "used" ? "info" : "neutral"}>
                {t(`invitations.status.${row.status}` as never)}
              </Badge>
            ),
          },
          { key: "created", header: t("label.created"), render: (row) => formatDateTime(row.created_at, locale) },
          { key: "expires", header: t("invitations.expires"), render: (row) => formatDateTime(row.expires_at, locale) },
          { key: "note", header: t("adminUsers.notes"), render: (row) => row.note || "—" },
          {
            key: "actions",
            header: t("label.actions"),
            render: (row) =>
              row.status === "active" && canIssue ? (
                <Button variant="ghost" type="button" disabled={busy} onClick={() => revoke(row)}>
                  {t("invitations.revoke")}
                </Button>
              ) : (
                <span className="muted small">—</span>
              ),
          },
        ]}
      />

      <Modal
        open={open}
        title={t("invitations.create")}
        onClose={close}
        footer={
          created ? (
            <Button type="button" onClick={close}>
              {t("action.close")}
            </Button>
          ) : (
            <>
              <Button variant="subtle" type="button" onClick={close} disabled={busy}>
                {t("action.cancel")}
              </Button>
              <Button type="submit" form="invite-form" loading={busy} disabled={busy}>
                {t("invitations.issue")}
              </Button>
            </>
          )
        }
      >
        {error ? <ErrorNotice error={error} /> : null}
        {created ? (
          <div className="stack">
            <div className="alert alert--success" role="status">
              <div>
                <strong>{created.email.endsWith("@local") ? t("invitations.anonymous") : created.email}</strong>
                {/* The server also returns an English `instructions` string for API clients; the panel
                    shows its own translated sentence so the screen stays in one language. */}
                <p className="alert__hint">{t("invitations.createdHint").replace("{days}", String(created.expires_days))}</p>
              </div>
            </div>
            <Field label={t("invitations.link")} hint={t("invitations.linkHint")}>
              <div className="row">
                <input readOnly value={created.link} dir="ltr" />
                <CopyButton value={created.link} />
              </div>
            </Field>
            {created.email_note ? <p className="muted small">{created.email_note}</p> : null}
          </div>
        ) : (
          <form id="invite-form" onSubmit={issue}>
            <Field label={t("label.email")} hint={t("invitations.emailHint")}>
              <input type="email" dir="ltr" value={email} onChange={(event) => setEmail(event.target.value)} />
            </Field>
            <div className="grid grid--2">
              <Field label={t("invitations.expiresDays")}>
                <select value={days} onChange={(event) => setDays(event.target.value)}>
                  {["1", "3", "7", "14", "30", "90"].map((value) => (
                    <option key={value} value={value}>
                      {value}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label={t("adminUsers.notes")}>
                <input type="text" value={note} onChange={(event) => setNote(event.target.value)} />
              </Field>
            </div>
            <label className="checkbox">
              <input type="checkbox" checked={sendEmail} onChange={(event) => setSendEmail(event.target.checked)} />
              <span>{t("invitations.sendEmail")}</span>
            </label>
            <p className="muted small">{t("invitations.note")}</p>
          </form>
        )}
      </Modal>
    </Card>
  );
}
