# Provider configuration

Every AI capability in Nexa AI comes from an **adapter** bound to a provider row you create in
_Admin → AI Infrastructure → Providers_. This document lists the adapters, what each supports, which
credential fields matter and how the platform behaves when something is missing.

## 1. Adapter catalogue

| `provider_type` | Adapter | Typical base URL | Needs API key | Operations |
| --- | --- | --- | --- | --- |
| `openai` | OpenAI | `https://api.openai.com/v1` | yes | chat, streaming, completion, embeddings, image generation, audio transcription, speech |
| `openai_compatible` | OpenAI-compatible | your URL | usually | same as above, subject to the upstream |
| `azure_openai` | Azure OpenAI | `https://<resource>.openai.azure.com` | yes (+ `api_version`) | chat, streaming, completion, embeddings, image generation |
| `openrouter` | OpenRouter | `https://openrouter.ai/api/v1` | yes | chat, streaming, completion, embeddings |
| `groq` | Groq | `https://api.groq.com/openai/v1` | yes | chat, streaming, completion |
| `mistral` | Mistral | `https://api.mistral.ai/v1` | yes | chat, streaming, completion, embeddings |
| `together` | Together | `https://api.together.xyz/v1` | yes | chat, streaming, completion, embeddings, image |
| `deepseek` | DeepSeek | `https://api.deepseek.com/v1` | yes | chat, streaming, completion |
| `ollama` | Ollama (local) | `http://host.docker.internal:11434/v1` | no | chat, streaming, completion, embeddings |
| `anthropic` | Anthropic Messages | `https://api.anthropic.com/v1` | yes | chat, streaming, vision |
| `google` | Google Gemini | `https://generativelanguage.googleapis.com/v1beta` | yes | chat, streaming, vision, embeddings |
| `stability` | Stability AI | `https://api.stability.ai` | yes | image generation |
| `elevenlabs` | ElevenLabs | `https://api.elevenlabs.io` | yes | speech generation |
| `deepgram` | Deepgram | `https://api.deepgram.com` | yes | audio transcription |
| `replicate` | Replicate | `https://api.replicate.com/v1` | yes | image generation, video generation |
| `custom` | generic OpenAI-compatible gateway | your URL | yes | chat, streaming, completion, embeddings, image, audio |

The registry exposes exactly this list at `GET /api/v1/meta/provider-presets`
(`provider_type`, `display_name`, `operations`, `requires_api_key`, `supports_model_listing`,
`documentation_url`, `preset`) and the admin UI renders the form from it.

## 2. Creating a provider

`POST /api/v1/admin/providers` (permission `providers.manage`):

```json
{
  "name": "OpenAI Production",
  "provider_type": "openai",
  "description": "Primary chat + image provider",
  "base_url": "https://api.openai.com/v1",
  "api_key": "sk-…",
  "organization_id": "org-…",
  "project_id": "proj_…",
  "api_version": "",
  "region": "",
  "enabled": true,
  "priority": 10,
  "connect_timeout": 10,
  "read_timeout": 120,
  "max_retries": 2,
  "requests_per_minute": 240,
  "max_concurrency": 4,
  "proxy_url": "",
  "extra_headers": { "X-Custom": "value" },
  "extra_config": {}
}
```

* `api_key` is encrypted with Fernet (`NEXA_ENCRYPTION_KEY`) before it touches the database. API
  responses only ever contain `api_key_hint` (masked, e.g. `sk-********f3a9`) and `has_credentials`.
* `base_url` is validated against the SSRF policy: private/loopback targets require
  `NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=true`, plain HTTP requires
  `NEXA_PROVIDER_ALLOW_INSECURE_HTTP=true`, and `NEXA_PROVIDER_ALLOWED_HOSTS` pins an allowlist.
* `read_timeout` should be raised for slow operations: 120 s+ for image generation, 180 s+ for speech
  and video.
* `requests_per_minute` / `max_concurrency` are enforced client-side by the adapter's HTTP client, in
  addition to any upstream limits.
* `priority` orders providers when several can serve the same model.

Updates use `PATCH /api/v1/admin/providers/{id}`; pass `api_key` to rotate the credential or
`clear_api_key: true` to remove it (the provider then fails with an explicit configuration error
instead of using a stale key — it is never silently reused).

## 3. Connection test and sync

```http
POST /api/v1/admin/providers/{id}/test      {"operation": "list_models"}
POST /api/v1/admin/providers/{id}/sync
```

* **Test** (`providers.test`): calls the adapter's health/list operation, measures latency, records a
  `provider_health_samples` row and writes `last_test_status`, `last_test_message` and
  `last_error_category` on the provider. Success means the endpoint and credential really work.
* **Sync** (`providers.sync`): imports the upstream model list. New models are created
  **hidden, unpublished, untested**; existing rows are updated without touching your prices or
  visibility. The response reports `created`, `updated`, `skipped`, `total_remote` and
  `new_model_ids`, and the run is audited as `provider.synced`.

## 4. Error taxonomy

| HTTP | Category | Meaning | Typical fix |
| --- | --- | --- | --- |
| 401 | `authentication` | wrong/expired credential | rotate the key |
| 403 | `authorization` / `quota_exhausted` | key lacks the scope or the account quota is gone | check the provider dashboard |
| 404 | `model_not_found` | the upstream does not know this model id | fix `provider_model_id` |
| 429 | `rate_limit` / `quota_exhausted` | throttled | lower `requests_per_minute`, retry later |
| 5xx | `upstream_server_error` | provider outage | retry; check the provider status page |
| timeout | `timeout` | read/connect timeout | raise `read_timeout` |
| non-JSON body | `malformed_response` | proxy or captcha in front of the API | fix `base_url` |
| "does not support" | `unsupported_operation` | adapter/model cannot do this | pick another model or provider type |

Diagnostics for the most recent failure are stored on the provider row and shown in the admin UI; the
same taxonomy is used for `error_events`, usage rows and admin tests, so an invalid key is never
confused with a timeout.

## 5. Self-hosted and local providers

| Scenario | Configuration |
| --- | --- |
| Ollama on the same host | `provider_type=ollama`, `base_url=http://127.0.0.1:11434/v1`, `NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=true` |
| Ollama on the Docker host from a container | `base_url=http://host.docker.internal:11434/v1` (Linux: add `extra_hosts: host-gateway`) |
| vLLM / LM Studio / llama.cpp server | `provider_type=openai_compatible`, base URL of the server, API key if it enforces one |
| LiteLLM or another gateway | `provider_type=custom` with the gateway URL; the gateway holds the real provider keys |
| Behind a corporate proxy | `proxy_url=http://proxy:3128` on the provider row |

HTTP (not HTTPS) endpoints require `NEXA_PROVIDER_ALLOW_INSECURE_HTTP=true` and should stay on a
private network.

## 6. Credential hygiene

* Never store keys in `.env` for providers — they belong in provider rows so they can be rotated and
  audited. `.env` is only for platform secrets (signing/envelope keys, SMTP, payment gateways).
* Changing `NEXA_ENCRYPTION_KEY` makes existing provider secrets undecryptable; re-enter them after a
  rotation.
* Every credential change is an audit event (`provider.updated`) with the actor, IP and request id,
  and never contains the secret value.
* Deleting a provider removes its models from the catalogue; models referenced by historic usage rows
  keep their provider id for reporting.

## 7. Verifying end to end

```bash
python3 tests/tools/mock_openai_upstream.py --port 9099 --api-key sk-mock-key   # real HTTP upstream
python3 tests/integration/test_live_stack.py --upstream http://127.0.0.1:9099
```

The live-stack test creates a provider pointing at the double, runs the connection test, syncs models,
prices and publishes one, runs an audited admin test, then drives chat/streaming/image through it and
proves the balance moves by exactly the reported charge. Substitute your real provider URL and key to
repeat the same flow against a paid API.
