# Remote testing (sharing a public-IP deployment)

How to let other people use the platform over the internet **without a domain**, what they can do, and
how to keep the exposure contained. For the HTTPS alternative see
[`PRODUCTION_DEPLOYMENT.md`](PRODUCTION_DEPLOYMENT.md).

## 1. Before you share anything

```
[ ] A real provider is configured, tested, and at least one model is priced, verified and published
[ ] The admin password is not a default and is not shared with testers
[ ] NEXA_REGISTRATION_MODE=invite_only (or closed, creating accounts yourself)
[ ] NEXA_PUBLIC_BASE_URL and NEXA_DEPLOYMENT_MODE=public_ip are correct for this host
[ ] Firewall/security group exposes only the app port (never 5432/6379)
[ ] Provider keys are test keys with their own spend limits, or your budget is monitored
[ ] You accept that traffic is unencrypted — use throw-away data only
```

## 2. Start the instance

```ini
# .env
NEXA_DEPLOYMENT_MODE=public_ip
NEXA_PUBLIC_BASE_URL=http://203.0.113.10:8080
NEXA_PUBLIC_PORT=8080
NEXA_COOKIE_SECURE=false
NEXA_HSTS_ENABLED=false
NEXA_REGISTRATION_MODE=invite_only
```

```bash
docker compose up -d                       # Docker route
sudo bash deployment/linux/install.sh      # native Ubuntu route (Nginx on 8080)
deployment\windows\start_public.bat        # Windows route (prints the LAN/public IP)
sudo ufw allow 8080/tcp                    # + cloud security group
```

Check from outside your own network (phone on mobile data):

```bash
curl -s http://203.0.113.10:8080/healthz
curl -s http://203.0.113.10:8080/api/v1/meta/config | python3 -m json.tool | head -20
```

## 3. What testers should be told

Send them a short message with:

1. the URL (`http://203.0.113.10:8080`);
2. how accounts are created (registration link, or credentials you provide);
3. the plain-HTTP warning — **do not enter personal data, real passwords or anything confidential**;
4. what to test (the modules you enabled) and what is deliberately not enabled (for example
   video generation when no video provider is configured);
5. the admin contact for problems, and where to find the `request_id` shown in error messages.

Suggested tester script:

```
1. Sign up / sign in, switch language (fa/en/ar/ckb) and theme, reload — the choice must persist
2. Open Chat, pick a model, send a message; try the streaming answer and the regenerate button
3. Try an image/audio/document request if the module is available; otherwise read the "no model
   configured" notice
4. Upload a file in Files, view the storage summary, download it again
5. Open Billing → submit a manual payment request (it will stay "awaiting review" — that is correct)
6. Open Usage and Jobs to see what the requests cost and their status
7. Try to reach /app/admin — a normal account must see "Forbidden"
```

## 4. Administrator tasks during a remote test

| Task | Where |
| --- | --- |
| Create/invite accounts | Admin → Users (or hand out the registration link) |
| Approve a payment request | Admin → Payments → review → Confirm → Approve (one ledger entry, once) |
| Grant test credits | Admin → Users → Credits (ledger-recorded) |
| Watch spend | Dashboard + Admin → Users (per-user spend), `usage_records.provider_cost_micro` |
| Watch failures | Admin → Errors (categories), Admin → Security (denials, failed logins) |
| Pause the instance | `docker compose stop web` / `sudo systemctl stop nexa-api nginx` |

Because traffic is unencrypted: assume credentials typed by testers are compromised and ask them to
use throw-away passwords (or pre-create accounts and hand out one-time passwords).

## 5. Containing cost and abuse

* Set per-user daily/monthly spend limits before sharing (Admin → Users → Limits) and keep
  `NEXA_GLOBAL_DAILY_SPEND_LIMIT_MICRO` as a breaker.
* Create test accounts with `is_test_account` where available so their usage is easy to filter.
* Keep provider `requests_per_minute` / `max_concurrency` conservative.
* Watch `Admin → Payments` for bogus submissions and reject with a reason.
* If abuse appears: disable the affected user, revoke their sessions, and (if needed) disable the
  provider row to stop all traffic immediately.

## 6. Automated proof while testers use the instance

```bash
# health and integrity, safe to run anytime
scripts/health_check.sh http://127.0.0.1:8080
cd backend && python -m app.cli doctor
```

### Proving the whole platform end to end without paid credentials

`tests/integration/test_live_stack.py` drives the full commercial path against a *real* running
deployment — admin provider + connection test, model sync (models stay hidden), pricing, publishing,
an audited administrator test of a hidden model, user registration, RBAC refusal on admin endpoints,
a manual payment that is credited only by the approving administrator, a real chat charge, streaming,
image generation with a downloadable file — and it proves the platform really called the upstream by
counting the requests the mock received. It needs a mock OpenAI-compatible upstream, which lives on
`127.0.0.1`, so the deployment's default SSRF policy refuses it. For a test window only:

```bash
# 1. allow the loopback test upstream and plain http:// for it (test window only!)
sudo cp /opt/nexa-ai/.env /opt/nexa-ai/.env.bak
printf 'NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=true\nNEXA_PROVIDER_ALLOW_INSECURE_HTTP=true\n' | sudo tee -a /opt/nexa-ai/.env >/dev/null
sudo systemctl restart nexa-api nexa-worker          # or: deployment/linux/nexa-services.sh restart

# 2. run the mock upstream and the test
python3 tests/tools/mock_openai_upstream.py --port 9099 &
sudo grep '^NEXA_BOOTSTRAP_ADMIN_PASSWORD=' /opt/nexa-ai/.env    # the admin password
python3 tests/integration/test_live_stack.py \
    --base-url http://127.0.0.1:8080 --upstream http://127.0.0.1:9099 \
    --admin-email admin@example.com --admin-password '<that password>'

# 3. undo the test window
sudo cp /opt/nexa-ai/.env.bak /opt/nexa-ai/.env
sudo systemctl restart nexa-api nexa-worker
```

Expected output: `PASSED 37 / 37`. A deployment that marks its cookies `Secure` (the
`NEXA_COOKIE_SECURE=true` setting used behind HTTPS) cannot authenticate over the loopback `http://`
URL — correct browser behaviour — so the script says so and re-sends the cookies itself for the test
client only; the server is untouched.

The live-stack script is read-mostly for existing data: it creates a new provider, its own user and its
own payment, then verifies balances move exactly by the reported amounts.

## 7. Shutting down / converting to HTTPS

```bash
docker compose down            # Docker
sudo systemctl stop nexa-api nexa-worker nginx     # native
```

Then move to the domain path: point DNS at the host, install certificates, set
`NEXA_DEPLOYMENT_MODE=domain_https`, `NEXA_COOKIE_SECURE=true`, `NEXA_HSTS_ENABLED=true`,
`NEXA_PUBLIC_BASE_URL=https://…`, reload Nginx and restart the services. Ask every tester to sign in
again (the cookie rules changed) and rotate any provider key that was used during the HTTP phase if it
was entered over the unencrypted connection.


## Sharing the app without a domain (the fast path)

The installers now ask how the app should be reachable. Choosing *public IP* (Linux:
`--access public`, Windows: option 2) writes a coherent configuration — deployment mode, public
base URL, published port, trusted hosts, CORS — adds the firewall rule, and prints a **SHARE IT WITH
OTHERS** block with:

* the URL to send (`http://<address>:<port>`),
* the three things that stop an outside browser: the host firewall, the cloud security group, and
  NAT/port-forwarding (with the public address and this machine's own address named explicitly),
* the command to re-check at any time:

```bash
sudo bash deployment/linux/check_public_access.sh --port 8080
# domain mode:
sudo bash deployment/linux/check_public_access.sh --scheme https --port 443 --host-header ai.example.com
```

If the address starts with `10.`, `172.16–31.`, `192.168.` or `169.254.`, it is **not** reachable
from the Internet — that is your own network or a container address. Either share the URL inside that
network, forward the port on the router, or use a VPS with a public IPv4 (and then, ideally, a domain
with HTTPS: `--access domain`).

The app itself keeps telling the truth in this mode: with `NEXA_DEPLOYMENT_MODE=public_ip` over
plain HTTP every API response and the UI carry the "traffic is not encrypted" warning, and the
warning disappears by itself once you switch to `--access domain` with a real certificate.


## Daytona: which link do I send people?

A sandbox IP (`172.20.0.63`) is never reachable from the outside — inbound traffic only arrives
through the Daytona preview proxy, and the proxy answers **401** until the sandbox is public or the
link is signed. `deployment/daytona/install-daytona.sh` therefore resolves the link itself and
prints either the working URL or a full diagnosis; `deployment/daytona/preview_link.sh --port 8080`
re-runs that diagnosis at any time from inside the sandbox.

* signed link for a private sandbox (expires): `daytona preview-url <sandbox-name> --port 8080 --expires 86400`
* no-token link for everyone: make the sandbox public (`daytona create --public`, the dashboard's
  Public switch, or `sandbox.set_public(True)`), then open `https://8080-<sandbox-id>.proxy.daytona.work`
* the deployment accepts any `*.proxy.daytona.work/.works/.daytona.io` host, so a refreshed link
  needs no `.env` change

The preview token is **not** port-scoped: whoever holds it can also open the sandbox web terminal
(22222). Share signed links only with people who should have that, and switch the public flag off
after testing.
