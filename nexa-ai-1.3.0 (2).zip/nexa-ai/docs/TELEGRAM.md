# Telegram bot

Nexa AI ships an optional Telegram bot: a verified user of the platform can talk to the same
models from Telegram, and every message is billed to that platform account through the normal
credit ledger. Nothing is free and nothing is anonymous — the bot only answers a Telegram id that
has been **linked to a registered platform account**.

This document is the operator's guide. It was written while the integration was exercised against
the live Telegram Bot API (see `docs/TEST_REPORT.md`, row "Telegram bot, real token").

---

## 1. Do I need it?

No. The bot is off unless a token is configured (`NEXA_TELEGRAM_ENABLED=false` by default), and
the platform works fully without it. Turn it on when you want a second delivery channel.

## 2. Create the bot and get the token

1. Open Telegram, start a chat with [@BotFather](https://t.me/BotFather).
2. Send `/newbot`, choose a name (display name) and a username ending in `bot`
   (e.g. `MyNexaAssistantBot`).
3. BotFather answers with the **token**, e.g. `123456789:AAE…`. Treat it as a password:
   anyone holding it controls the bot.
4. Optional: `/setdescription` and `/setuserpic`. You do **not** need `/setcommands` — at start-up
   the bot publishes its own current command list with `setMyCommands` (19 commands, bilingual), so
   Telegram's native menu button always shows exactly what this build answers.

## 3. Configure the server

Add these lines to the deployment's `.env` (`/opt/nexa-ai/.env` on the Linux installer,
`<install dir>\.env` on Windows) and restart the services:

```ini
NEXA_TELEGRAM_ENABLED=true
NEXA_TELEGRAM_BOT_TOKEN=123456789:AAE…            # the token from BotFather
NEXA_TELEGRAM_BOT_USERNAME=MyNexaAssistantBot     # without the @; used for t.me deep links
NEXA_TELEGRAM_MODE=polling                        # polling | webhook
# Only for webhook mode (see §5): the value Telegram must send back in the secret header
NEXA_TELEGRAM_WEBHOOK_SECRET=
# Optional: a chat id that receives a short "bot is up" notice at start-up
NEXA_TELEGRAM_ADMIN_CHAT_ID=
```

Then make sure **something is doing the polling**:

| Deployment | What runs the bot |
| --- | --- |
| Linux, systemd | the `nexa-worker` service already polls (`deployment/linux/nexa-worker.service`) |
| Linux, no systemd (containers) | `nexa-services.sh` starts the same worker process |
| Windows | `NEXA_INLINE_WORKER=true` in `.env` lets the API process poll — nothing else to start |
| Docker Compose | the `worker` service polls |

Restart and verify:

```bash
# Linux
sudo systemctl restart nexa-api nexa-worker            # or: nexa-services.sh restart
journalctl -u nexa-worker -n 30 | grep -i telegram      # expect: "telegram polling starting"
# any deployment, through the API:
curl -s -X POST http://127.0.0.1:8000/api/v1/admin/telegram/test \
     -H "Cookie: …" -H "X-CSRF-Token: …"                # or use Admin → Settings → Telegram → Test
```

`Admin → Settings → Telegram → Test` (and the endpoint above) performs a real `getMe` call: only a
successful answer proves the token works. The reply states the bot's `@username`, so a wrong token
in a shared `.env` is obvious immediately.

## 4. Linking a Telegram account (the security model)

A Telegram id **cannot use the bot** until it is linked to a platform account:

1. The user signs in at the site and opens **Profile → Telegram**.
2. Presses **Create link code** — a short-lived, one-time code is issued (`/api/v1/telegram/link-code`).
3. The user sends `/start <code>` (or just the code) to the bot.
4. The platform consumes the code, stores the link (`telegram_links`) and replies with a welcome
   message plus a short usage guide.
5. From then on, every message from that chat id is answered **as that platform user**: access
   rules, credit balance, model availability and pricing are exactly the same as on the website.

Unlinked visitors get an explanation and the linking instructions — never a model answer. A user
can unlink at any time from the same screen (`DELETE /api/v1/telegram/link`).

## 5. Transports: polling vs webhook

| | Polling (default) | Webhook |
| --- | --- | --- |
| Needs a public HTTPS URL | no — works behind NAT, containers, a home server | yes |
| How it works | the worker calls `getUpdates` in a loop | Telegram POSTs each update to `/api/v1/telegram/webhook` |
| Configure | `NEXA_TELEGRAM_MODE=polling` | `NEXA_TELEGRAM_MODE=webhook` + `NEXA_TELEGRAM_WEBHOOK_SECRET`, then register the URL (Admin → Settings → Telegram, or `POST /api/v1/admin/telegram/webhook`) |
| Only one consumer | required: two pollers cause `409 Conflict` (Telegram kills the older call) | — |

Polling is the right choice for almost every self-hosted installation, and it is what the shipped
services run. Use a webhook only if you have a public HTTPS endpoint and want the lowest latency.

## 6. Billing

* Every model answer is charged to the linked platform account exactly like a website request, with
  an immutable ledger entry (`usage:` key) and a usage row (`module=telegram`).
* No balance → no answer: the bot replies with the same "add credits" explanation the API returns.
* Administrative tests and the bot are separate: bot traffic is user traffic.
* `/status` shows the balance the user's own account has; there is no hidden free allowance.

## 7. The bot interface

### 7.1 Two buttons and a glass hub (the round-15/16 interface)

Every linked chat keeps a **fixed two-button reply keyboard** — `resize_keyboard` + `is_persistent`,
so it survives app restarts on the phone:

```
[ 💬 گفتگو ]  [ 🧭 منو ]
```

* **💬 گفتگو** clears the desk: any menu card is deleted, the bar is refreshed and the chat becomes
  a clean conversation surface.
* **🧭 منو** opens a **tracked inline hub** — a glass card with `مدل‌ها│سشن‌ها / حساب│تنظیمات /
  راهنما│سشن جدید` plus a site link. Telegram allows exactly one `reply_markup` per message, so
  every navigation step **edits that same card** (or deletes it and opens a new one) instead of
  stacking messages; sections carry «↩️ بازگشت به منو», and since round 16 every nested card opens
  with a breadcrumb («🧭 منو › …») so the user always knows where they are.

After every model answer the bot attaches a two-row action bar:
`🔁 تلاش دوباره · 🆕 سشن جدید` / `🧠 مدل‌ها · 🗂 سشن‌ها`. The same single retry button is attached
to refusals (⛔️) and provider-error warnings (⚠️), and it really replays the last prompt — the
prompt is remembered **before** anything can be refused.

### 7.1.1 Live answers (round 16)

The answer **grows inside one message**, the way the best Telegram AI bots do it: a placeholder
opens after the first ~24 characters with a `▍` cursor, the same message is edited as the model
writes — never faster than every 1.5 s or for fewer than 120 new characters, which stays inside
Telegram's ~30-edits-per-minute-per-chat budget — and the final edit removes the cursor and
attaches the footer and the action row. An answer too long for one message is finalised cleanly at
~3800 characters and continues in a fresh one. If any send or edit is refused, the bot deletes the
half-streamed message and falls back to the classic one-shot delivery, so **the answer is never
lost — only the animation**. Users can turn the whole behaviour off in ⚙️ («پخش زنده», on by
default); the server logs one honest line per streamed turn
(`telegram: live stream to chat … finished: N in-loop edit(s), M chars, fallback=False`).

### 7.2 Sessions — one conversation per model

The bot is **session-based**: up to 20 named sessions per user, each bound to a model (and a variant),
each with its own history, token counters and charged amount. Sessions live in the link state and stay
in sync with the website: the active session's conversation is the same `conversation_id` the web
workspace shows, so a Telegram chat appears in the user's history like any other conversation.

| Command | What happens |
| --- | --- |
| `/new [title]` | fresh session (auto-titled from the first prompt if no title is given) |
| `/sessions` | inline list of sessions, grouped by model, active one ticked |
| `/switch N` | activate session N — the next messages go to that model with that history |
| `/rename title` | rename the active session |
| `/close` | close (delete) the active session |
| `/retry` | send the last prompt of the active session to the provider again (also the 🔁 button under every answer, refusal and error) |
| `/export` | the active session's transcript as a downloadable text file |
| `/stats` | per-session totals: messages, tokens, charged credits |

### 7.3 Models and account

| Command | What happens |
| --- | --- |
| `/models [page]` | the models **this account** may use (paginated, active model ticked ✅) |
| `/use N` | select model N — creates/activates that model's session |
| `/variants` · `/usev N` | sub-model variants of the selected model and their system prompts |
| `/balance` · `/usage` | credit balance and recent ledger/usage rows |
| `/status` · `/whoami` | linked account summary — since round 16 including **today's spend** and, when a daily limit is set, a ▰▱ progress bar against it; the user's numeric Telegram id |
| `/settings` | language (fa/en), cost footer on/off, typing indicator, **live answer stream on/off**, history depth |
| `/start` | greeting + onboarding for a linked account; linking instructions otherwise |
| `/menu` · `/help` | section menu; per-section help (topics: `models`, `sessions`, `commands`, …) |
| any other text | sent to the active session's model, billed like a website request; the answer streams live into one message (§7.1.1) and long answers continue in extra messages (with live streaming off they are split into numbered parts) |

Group/supergroup messages are ignored by design (the bot is a private channel), and a button press
from an unlinked chat id is refused — callbacks are gated exactly like text.

## 8. Troubleshooting

| Symptom | Cause and fix |
| --- | --- |
| `Admin → Settings → Telegram → Test` says "not configured" | `NEXA_TELEGRAM_ENABLED` is not `true`, or the token is missing/empty in the `.env` the service reads |
| Log shows `Conflict: terminated by other getUpdates request` | two pollers with the same token: stop the other one (an old deployment, a local script, or the same bot configured twice) |
| Bot is silent although the token is valid | nothing is polling: check that the worker (or `NEXA_INLINE_WORKER=true`) is running and that the log contains `telegram polling starting` |
| Unlinked users get no model answers | intended: linking is the gate. Create a code in Profile → Telegram |
| Answers never arrive but `/status` works | the account has no credits, or the selected model is not accessible — the bot repeats the API's own reason, with a 🔁 retry button that replays the prompt once the account can pay |
| The answer arrives but never grows live | «پخش زنده» is off in ⚙️, or Telegram refused the edits (rate limit) — the bot logs `fallback=True` and delivers one-shot; nothing is lost |
| Webhook mode: updates are not delivered | the URL must be public HTTPS; a self-signed certificate or a private address will not work — use polling |

## 9. Reference

* Endpoints: `GET/POST /api/v1/telegram/*` (user), `GET /api/v1/admin/telegram/status`,
  `POST /api/v1/admin/telegram/test`, `POST /api/v1/admin/telegram/webhook`.
* Server code: `backend/app/services/telegram.py` (transport, routing, billing),
  `backend/app/services/telegram_menus.py` (bottom bar, inline keyboards, help texts — fa/en) and
  `backend/app/services/telegram_sessions.py` (the per-model session store); polling runs in
  `backend/app/workers/worker.py` / `backend/app/services/inline_worker.py`.
* Demo/verification harness: `backend/tests/tools/telegram_demo_stack.py` (runs the whole flow
  against a local Bot API stub, no real token needed).
* Environment variables: `.env.example` (Telegram section) and `deployment/windows/nexa.env.example`.
