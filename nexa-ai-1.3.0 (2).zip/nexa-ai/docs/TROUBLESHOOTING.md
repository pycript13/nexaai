# Troubleshooting

Symptom → cause → fix. Every command below exists in this repository; paths are relative to the
project root unless stated otherwise. For platform-specific notes see
[`INSTALL_UBUNTU.md`](INSTALL_UBUNTU.md) / [`INSTALL_WINDOWS.md`](INSTALL_WINDOWS.md).

## 1. Start-up and installation

| Symptom | Cause | Fix |
| --- | --- | --- |
| `RuntimeError: NEXA_ENCRYPTION_KEY is not set` | placeholder/empty key in production | `python3 -c "from cryptography.fernet import Fernet;print(Fernet.generate_key().decode())"` → `NEXA_ENCRYPTION_KEY`, restart |
| App refuses to start with SQLite | `NEXA_ENVIRONMENT=production` blocks SQLite | install PostgreSQL and set `NEXA_DATABASE_URL`, or use development mode |
| `ModuleNotFoundError: app` | wrong working directory | run backend commands from `backend/` (`cd backend`) |
| `alembic` cannot find the database | `.env` not loaded | `set -a; source .env; set +a` (or place `.env` in the project root, which is auto-loaded) |
| `Address already in use` (8000/8080) | another process owns the port | `ss -ltnp \| grep 8000` (Linux) / `netstat -ano \| findstr :8000` (Windows) then stop it or change the port |
| `npm run build` fails | missing Node 20 or stale `node_modules` | install Node 20 LTS, `rm -rf node_modules package-lock.json && npm install` |
| `install.sh` aborts at `rsync` | rsync missing | `sudo apt -y install rsync` (the script falls back to `cp -a`) |
| Windows: `python`/`npm` not recognised | not on PATH | reinstall with “Add to PATH”, reopen the terminal |
| Compiling wheels fails on Windows | no C++ toolchain (psycopg2/argon2) | install “Microsoft C++ Build Tools” |
| `pydantic_core._pydantic_core.ValidationError … unable to interpret input` at startup | `.env` has a trailing comment on a value line (`NEXA_COOKIE_SECURE=false  # note`) — pydantic reads the whole text | re-run the installer (it strips them) or put the comment on its own line |
| The API refuses to start with “NEXA_SECRET_KEY is missing or still a placeholder value” | `.env` is a copy of a template | re-run the installer (repairs it, keeps a backup) or `--reset-env` |
| Image/document generation fails with `PermissionError: '/app'` | `NEXA_UPLOAD_DIR` still points at the Docker container path | re-run the installer (sets `<app dir>/uploads`) or edit the line yourself |
| Sign-in fails right after a re-install | the account exists with an older password | `sudo bash deployment/linux/install.sh --reset-admin-password` |
| `psql: error: connection to server on socket "/var/run/postgresql/.s.PGSQL.5432" failed` during the install | `apt` installed PostgreSQL but never started it (normal in containers/images with `policy-rc.d`) | `sudo pg_ctlcluster 17 main start` (or `sudo service postgresql start`), check `pg_isready`, then re-run `sudo bash deployment/linux/install.sh` — current installers start it themselves |
| `invoke-rc.d: policy-rc.d denied execution of start` | the image forbids service auto-start | harmless by itself; start services explicitly (`systemctl start …`, `pg_ctlcluster …`, `redis-server --daemonize yes`) |
| `systemctl: command not found` / `System has not been booted with systemd` | container without systemd | install with `--no-systemd`, then manage the services with `/opt/nexa-ai/deployment/linux/nexa-services.sh {start,stop,restart,status,logs}` |
| `error: the configured Python interpreter version (3.14) is newer than PyO3's maximum supported version (3.13)` / `Failed building wheel for pydantic-core` | the virtualenv was created with Python 3.14, which cannot build the pinned `pydantic-core` wheel | the installer now chooses Python 3.11–3.13 itself and rebuilds a stale venv; to force it: `sudo rm -rf /opt/nexa-ai/venv && sudo bash deployment/linux/install.sh --python /usr/bin/python3`. Staying on 3.14? Use the Docker route |
| `E: Unable to correct problems, you have held broken packages` while installing `nodejs npm` | Node was installed from NodeSource and conflicts with the distribution's `npm` package | keep the existing Node (`node -v`, `npm -v`) and skip `--no-node`; or `apt-get install -y nodejs` from a single source and re-run |
| Sign-in fails right after installing | the administrator already existed (re-run/upgraded server), so the password in `.env` is outdated | `cd /opt/nexa-ai/backend && sudo -u nexa ../venv/bin/python -m app.cli create-admin --email <you> --password '<new>'`; the installer prints the same hint |
| Re-running the installer wiped/kept nothing | an old script or a manual `cp`/`rsync` without excludes | current installer never touches `.env`, `venv/`, `data/`, `uploads/`, `backups/`, `logs/` — restore from `backups/` if needed |

## 2. HTTP and interface

| Symptom | Cause | Fix |
| --- | --- | --- |
| Blank page / 404 on `/` | SPA not built or not served | `cd frontend && npm run build`; ensure `NEXA_SERVE_FRONTEND=true` and `NEXA_FRONTEND_DIST_DIR` points to `frontend/dist` |
| Assets 404 behind Nginx | wrong `root` in the site config | check `deployment/nginx/nexa-host.conf` (`__APP_DIR__` substituted) and `sudo nginx -t` |
| Page loads but every API call fails | API not reachable through the proxy | `curl -s http://127.0.0.1:8000/healthz` and `curl -s http://127.0.0.1:8080/api/v1/health` |
| Sign-in returns CORS/CSRF errors | browser origin not allowed | add the exact origin to `NEXA_CORS_ORIGINS` and match `NEXA_PUBLIC_BASE_URL` |
| Sign-in silently fails after enabling HTTPS flags | `NEXA_COOKIE_SECURE=true` on plain HTTP | finish HTTPS or set it `false` |
| Streaming answers arrive all at once | proxy buffering | keep `proxy_buffering off` (already in both Nginx templates) |
| “Too many requests” while clicking fast | rate limits | raise `NEXA_AUTH_RATE_LIMIT_PER_MINUTE` / `NEXA_API_RATE_LIMIT_PER_MINUTE`, or configure Redis for shared limits |
| `Invalid host header` (400) from `/healthz`, `/readyz` or any route behind Nginx | the proxy sent a `Host` the API does not trust — either `NEXA_TRUSTED_HOSTS` lacks the address you use, or an Nginx location proxies without `proxy_set_header Host $host;` (nginx then sends the upstream name) | add your IP/domain to `NEXA_TRUSTED_HOSTS` and keep the explicit `proxy_set_header Host $host;` in every `location` that uses `proxy_pass` (both shipped templates do) |
| `502 Bad Gateway` from Nginx right after installing | the API is not running (crash, port in use, migrations) | `journalctl -u nexa-api -n 50` or `tail -50 /opt/nexa-ai/logs/api.log`, then `curl http://127.0.0.1:8000/healthz` |
| Language reverts on reload | browser local storage blocked | allow site storage; the locale is also stored on the account |

## 3. Providers and models

| Symptom | Cause | Fix |
| --- | --- | --- |
| `503 not_configured` on any AI call | no enabled provider/model for that capability | Admin → Providers → create/verify; Admin → Models → check `enabled`, `availability`, capability |
| `model_not_verified` | the model was never tested | run an admin test with one of its capabilities (this also sets `available`) |
| Provider test fails with `authentication` | wrong/expired key | rotate the credential in the provider row |
| Test fails with `timeout` | `read_timeout` too low | raise it (120 s+ image, 180 s+ speech/video) |
| Test fails with `unsupported_operation` | adapter or model cannot do it | pick a matching provider type (e.g. `stability`/`replicate` for images) |
| `SSRF policy blocked the request` | private/loopback base URL | set `NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=true` (local testing only) or use a public endpoint |
| Sync imports nothing | upstream has no model-list endpoint | create the model manually (`POST /api/v1/admin/models`) |
| Model missing from the user catalogue | hidden/unpublished/untested/tier | `visibility=public` + `published=true` + `available` + suitable `access_tier` |
| Prices show 0 | model is `unpriced` | set `selling_*` (credits) or `provider_cost_*` (USD); read the `pricing_model`/notes in the response |

### "The connection test is green, but the model is never called (`provider_connectivity`)"

This means the provider answered the model-list request (what the **Test connection** button calls)
but the *actual* call — almost always a streaming `POST /chat/completions` — failed at the transport
level. One command locates it:

```bash
cd /opt/nexa-ai/backend
sudo -u nexa /opt/nexa-ai/venv/bin/python -m app.cli provider-check --provider <slug>
```

It walks every layer with real network calls and prints one JSON report:

| Step | What a failure there means |
| --- | --- |
| `policy` | the SSRF guard refused the base URL (private/loopback address, or plain `http://` while `NEXA_PROVIDER_ALLOW_INSECURE_HTTP=false`) |
| `dns` | this server cannot resolve the provider host — wrong hostname, or the server has no working DNS |
| `tcp` | the host resolved but the connection could not be established: firewall / security group / provider outage / a proxy that must be configured (`proxy_url` on the provider) |
| `tls` | handshake or certificate problem (corporate TLS inspection, expired cert, wrong port) |
| `models` | the provider rejected the key or the path — the report shows the provider's own error body |
| `chat` | a single-token chat call failed; the message carries the endpoint, the exception class and the provider's body |
| `chat_stream` | the streaming call failed even though non-streaming worked (some gateways/proxies break SSE) |

Notes:

* the two chat probes call the provider directly through the adapter: they are **not** billed to any
  user and **not** written to usage history; they do cost whatever the provider charges for one
  one-token request. `--skip-chat` stops after the model list.
* a transient connection failure on a streamed chat is retried automatically (`max_retries`,
  exponential backoff) as long as **nothing has been streamed yet**; after the first token a retry
  could duplicate the answer, so the stream fails with the full diagnosis instead.
* the same symptoms can also mean the model is not ready: `untested` availability, missing
  `capabilities`, `published=false`, or `access_tier` the user does not hold. The chat response says so
  explicitly (`model_not_verified`, `model_not_accessible`) — check that first; `provider-check` is for
  transport-level failures.

## 4. Billing

| Symptom | Cause | Fix |
| --- | --- | --- |
| `402 insufficient_balance` | empty balance | approve a payment or grant credits (ledger-recorded) |
| Payment approval returns 422 | already approved (idempotency) | check the payment status/history; no second entry is created by design |
| Balance did not change after a redirect | redirects are not proof | confirm the webhook/administrator approval path; gateways need signature verification |
| Charge is 0 for a real call | model unpriced or tier `free` | set prices, or confirm the tier was intentional |
| `429` with `spend_limit` | daily/monthly cap | raise the cap on the account/user/plan/grant |
| Ledger and balance disagree | interrupted write (rare) | `cd backend && python -m app.cli doctor` and investigate the reported rows |
| Refund looks like a new row | refunds are compensating entries | expected; history is never rewritten |

## 5. Files and jobs

| Symptom | Cause | Fix |
| --- | --- | --- |
| Upload rejected (extension) | not in `NEXA_ALLOWED_UPLOAD_EXTENSIONS` | extend the list or convert the file |
| Upload rejected (signature) | content does not match the extension | send a genuine file of that type |
| `413 payload_too_large` | over `NEXA_MAX_UPLOAD_MB` | raise the limit **and** Nginx `client_max_body_size` |
| Storage quota error | `NEXA_USER_STORAGE_QUOTA_MB` reached | delete files or raise the quota |
| Download 404 for a generated file | old rows from a pre-fix build | re-run the generation; current builds commit file rows before responding |
| Jobs stay `pending` | no worker and `NEXA_INLINE_WORKER=false` | start `nexa-worker`/`docker compose up -d worker`, or run `python -m app.cli run-jobs --once` |
| Jobs stay `running` forever | crashed worker with a live lease | wait for the lease to expire (`NEXA_JOB_LEASE_SECONDS`) or restart the worker |
| Job retried but fails again | upstream error | inspect `Admin → Jobs` (attempts, error category) and the provider diagnostics |

## 6. Database and maintenance

| Symptom | Cause | Fix |
| --- | --- | --- |
| `Target database is not up to date` | migrations not applied | `cd backend && python -m alembic upgrade head` |
| `relation already exists` during bootstrap | partially applied migration | check `alembic current`, then `alembic stamp` only if the schema truly matches |
| PostgreSQL connection refused | service down or wrong host/password | `systemctl status postgresql`, `psql "$NEXA_DATABASE_URL" -c '\dt'` |
| “Redis configured but unavailable” | Redis not running (optional) | ignore, install Redis, or clear `NEXA_REDIS_URL` |
| Disk filling up | uploads/backups growth | `python -m app.cli maintenance` (retention), prune `backups/`, check `NEXA_FILE_RETENTION_DAYS` |
| Slow admin lists | large tables | use filters/pagination; ensure the indexes from `database/schema.md` exist after migrations |

## 7. Collecting a diagnosis

```bash
# 0. one provider, layer by layer (DNS -> TCP -> TLS -> models -> chat -> stream)
cd backend && python -m app.cli provider-check --provider <slug>

# 1. configuration and integrity (secrets are masked)
cd backend && python -m app.cli doctor

# 2. health of every component
curl -s http://127.0.0.1:8000/api/v1/health/deep | python3 -m json.tool

# 3. recent logs
journalctl -u nexa-api -n 200 --no-pager          # native
docker compose logs --tail=200 api worker         # Docker

# 4. what the database believes
python - <<'PY'
import sqlite3; c = sqlite3.connect("data/nexa.db")
for t in ("users", "models", "providers", "usage_records", "credit_ledger", "files"):
    print(t, c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0])
PY

# 5. per-request trace
#    every error response carries request_id; search it in Admin → Errors or the logs
```

When reporting an issue, include: what you ran, the exact error text, the `request_id`, `doctor`
output, and the deployment mode. Never paste provider keys or `.env` contents.

---

## The install finished, but the URL does not open in my browser

The installer verifies this itself and says so on the last line of the summary:
`[verified: answers from another machine]`, `[NOT reachable from another machine yet]`, or
`[not checked]` (with `--no-public-check`). If it is not reachable, the app is still fine — the
health check and the administrator sign-in passed. What failed is the path from a browser to the port.

```bash
sudo bash /opt/nexa-ai/deployment/linux/check_public_access.sh --port 8080   # exit 0 = open
```

Read its verdict and work through the three layers:

1. **The port on this host** — `sudo ss -ltnp | grep 8080` must show `0.0.0.0:8080`. Only
   `127.0.0.1:8080` means the SPA is served on this machine only; re-run the installer so its
   Nginx site binds every address.
2. **The host firewall** — `sudo ufw status verbose` (or `sudo firewall-cmd --list-ports`). Open:
   `sudo ufw allow 8080/tcp`, or
   `sudo firewall-cmd --add-port=8080/tcp --permanent && sudo firewall-cmd --reload`.
3. **NAT / cloud security group** — if `hostname -I` shows a private address (`10.x`, `172.16-31.x`,
   `192.168.x`, `100.64.x`, `169.254.x`) then this machine does not own the public address a browser
   uses. Whoever runs the NAT (AWS, GCP, Azure, Oracle, Hetzner, OVH, the router) must forward or
   1:1-map inbound TCP 8080 to it. Examples: lighttpd? no — use the cloud console's *Security Group /
   Firewall / Floating IP* settings, or a reverse SSH tunnel (`ssh -R 8080:127.0.0.1:8080 user@vps`),
   or a Cloudflare Tunnel. Installing on a host that has its own public address also works.

Browser-side traps that look identical:

* Chrome/Safari/Edge silently upgrade `http://` to `https://` (*Always use secure connections*).
  Type `http://<address>:8080` explicitly; on the HTTPS attempt the browser shows
  "This site can't provide a secure connection" — that is this trap, not a broken install.
* The port is part of the URL: `http://203.0.113.9` (no `:8080`) will not reach this app.
* A laptop on a different network than the server can never use the LAN address
  (`http://172.20.0.45:8080`) — that address only works inside that network.

Confirm from another machine (not from the server):

```bash
curl -v http://<public-address>:8080/readyz      # HTTP/1.1 200 = the path is open
```
