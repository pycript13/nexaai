# Model management

The catalogue is the contract between administrators and users: it decides what is visible, what may
be used, and what it costs. Three independent axes plus two flags make that explicit.

## 1. The five knobs

| Field | Values | Meaning |
| --- | --- | --- |
| `visibility` | `public`, `hidden` | Does the model appear in the user catalogue? |
| `availability` | `available`, `degraded_offline`, `disabled`, `untested` | Can it actually serve traffic right now? |
| `access_tier` | `free`, `credit`, `subscription`, `restricted`, `internal` | Who may use it and how it is paid for |
| `enabled` | bool | Master switch; a disabled model is refused for everyone |
| `published` | bool | Explicit "this is release-ready" marker |

`access_tier` semantics:

* **free** — the operator pays; usage is recorded with `billed_to_user: false`.
* **credit** — metered against the user's balance (the default).
* **subscription** — requires an active subscription whose plan includes the model.
* **restricted** — requires an explicit grant (user or role) with optional spend caps and expiry.
* **internal** — administrators only; regular users always receive
  `403 model_not_accessible` (`model_not_allowed`).

A user-visible, usable model is therefore `visibility=public` + `published=true` + `enabled=true` +
`availability=available` (or `degraded`) + a tier the user satisfies.

## 2. Importing models

Providers are the source of truth for what exists; Nexa decides what is offered.

```http
POST /api/v1/admin/providers/{provider_id}/sync        # permission providers.sync
```

* New upstream models are created **hidden, unpublished, untested** with `discovered_by_sync = true`.
* Existing rows are updated (capabilities/modalities refreshed) but your prices, visibility, tier and
  publish state are preserved.
* Prefer `POST /api/v1/admin/models` when the upstream has no model-list endpoint (the provider test
  reports `supports_model_listing`), for private/custom deployments, or to register a model variant
  with different capabilities.

`ModelCreate` accepts the full shape: `provider_id`, `provider_model_id`, `display_name`,
`description`, `model_family`, `capabilities[]`, `input_modalities[]`, `output_modalities[]`,
`context_window`, `max_output_tokens`, the `supports_*` booleans, `provider_cost_*` (USD) and the
`selling_*` prices (credits), plus `visibility`, `availability`, `access_tier`, `enabled`,
`published`, `category_ids`, `tag_slugs`, `sort_order`.

## 3. Capabilities and operations

`capabilities` drives which modules may use a model and which operations an administrator can test:

| Operation value | Used by | Notes |
| --- | --- | --- |
| `chat` | chat, coding, translation, documents Q&A, data narrative, image analysis | base capability |
| `streaming` | chat streaming | requires adapter SSE support |
| `completion` | legacy text completion | optional |
| `embeddings` | document indexing and retrieval | needs an embedding model |
| `image_generation` | image module | per-image pricing |
| `image_understanding` | image analysis | also set `supports_vision` |
| `audio_transcription` | audio module | file upload |
| `speech_generation` | audio module | returns a stored audio file |
| `video_generation` | video module | asynchronous job |
| `rerank` | retrieval ranking | adapter-dependent |
| `tools`, `json_mode`, `reasoning`, `document_qa` | feature flags surfaced to the UI | keep them truthful |

The module capability endpoint (`GET /api/v1/modules/capabilities`) reports per-module availability
from the *current* catalogue, so a module with no usable model says so instead of failing later.

## 4. Pricing

Selling prices are **credits**; provider costs are **USD**:

| Column | Unit | Example |
| --- | --- | --- |
| `selling_input_per_mtok` | credits per million input tokens | `3` |
| `selling_output_per_mtok` | credits per million output tokens | `15` |
| `selling_per_request` | credits per request | `0.05` |
| `selling_per_image` | credits per image | `0.25` |
| `selling_per_audio_minute` | credits per audio minute | `1.2` |
| `provider_cost_*` | USD (what you pay upstream) | `0.5`, `1.5`, `0.02` |

Resolution order for the effective price: **user → plan → model → provider → global** pricing rule,
then the model's own `selling_*` columns, then provider cost + markup
(`NEXA_DEFAULT_MARKUP_PERCENT`, default 30%) and finally `unpriced` with a warning. Rules are versioned
and scoped; the response always reports `pricing_model` (scope) and `rule_version`, and usage rows
store the rule id + version for later auditing.

Conversions are exact: per-million-token prices land in **micro-credits per 1 000 000 tokens**
(rounding half-up, so `0.28` credits/MTok is stored as `280000`, never `0`), while flat prices are full
credit amounts (`0.25` credits per image = `250000` micro-credits, never `0`). Prices are entered and
displayed in the UI as **credits per 1M tokens**; `formatCredits` converts the stored micro-credits at
the edge. Upgrading from revision `a1ce3c4bf50b` rescales existing rule prices by 1 000 000
(`c7d41b0f9a13`), so no rule changes its effective price.

If a model is `unpriced`, requests still run but the recorded charge is 0 and a warning is returned to
the client — configure a price before exposing it to real users.

## 5. Admin testing (spec §9)

```http
POST /api/v1/admin/models/{id}/test   {"operation": "chat", "prompt": "…", "max_tokens": 64}
GET  /api/v1/admin/models/{id}/tests
```

Guarantees:

* works on **hidden, internal, unpublished and restricted** models; it never changes visibility,
  availability-publishing or the tier;
* **never bypasses provider authentication** — the provider must be enabled and hold a valid
  credential; a disabled provider or model is refused with an explanation;
* the operation must be one of the model's declared capabilities, otherwise
  `unsupported_operation` is recorded as a failed test rather than silently using another path;
* cost is written to `admin_model_tests` and to `usage_records` with `is_admin_test = true` and
  `billed_to_user = false` (platform cost), honouring `NEXA_ADMIN_TEST_MAX_COST_PER_REQUEST_MICRO`
  and `NEXA_ADMIN_TEST_DAILY_LIMIT_MICRO`;
* results are audited (`model.tested`) with the actor and IP, and a successful test moves
  `availability` from `untested` to `available` (a failure sets the error category and leaves the model
  unusable for users);
* the test history endpoint returns latency, token counts, `usage_source`, `cost_uncertain`,
  `bypassed_user_restrictions` and a response preview.

## 6. Grants for restricted models

```http
POST   /api/v1/admin/models/{id}/grants  {"subject_type": "user", "subject_id": 42,
                                          "daily_spend_limit_micro": 500000,
                                          "monthly_spend_limit_micro": 5000000,
                                          "expires_in_days": 30, "note": "pilot"}
DELETE /api/v1/admin/models/{id}/grants/{grant_id}
```

Grants are unique per `(model, subject_type, subject_id)`; a `role` grant applies to every member of
that role. The caps are enforced before each request, and expiry is checked at access time.

## 7. Bulk operations

```json
POST /api/v1/admin/models/bulk
{ "model_ids": [12, 13], "action": "publish", "confirm": true }
```

Actions: `publish`, `unpublish`, `enable`, `disable`, `set_tier`, `set_visibility`, `add_categories`.
`confirm: true` is mandatory (`models.publish` permission) and the response reports per-model
`changes[]` and `errors[]` — publishing a hidden model is refused with
`Model is not public; change visibility first.` rather than being silently allowed.

## 8. Lifecycle recipes

| Goal | Steps |
| --- | --- |
| Add a provider's flagship model | sync → edit pricing → verify with an admin test → `visibility=public`, `published=true`, tier `credit` |
| Trial a new upstream model quietly | keep `hidden` + `internal`, test it, watch `admin_model_tests` latency/cost, then publish |
| Give one customer access to an expensive model | tier `restricted` + a user grant with daily/monthly caps |
| Move a model behind subscriptions | tier `subscription`, attach it to a plan (Admin → Plans), notify users |
| Take a model out of service | `availability=disabled` (users get a clear error) → later `unpublish` and fix pricing |
| Retire a vendor | disable its models, then `DELETE` the provider after the last usage window |
