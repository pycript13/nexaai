# Architecture

Nexa AI is a monorepo with a FastAPI backend, a React/TypeScript SPA and a deployment layer that
targets Docker, Ubuntu and Windows. This document explains how the pieces fit together and why the
important design decisions were made.

## 1. High-level view

```
                    ┌──────────────────────────────────────────────┐
  browser  ────────▶│ Nginx: static SPA + proxy /api (no buffering)│
                    └───────────────┬──────────────────────────────┘
                                    ▼
                    ┌──────────────────────────────────────────────┐
                    │ FastAPI app (app.main:app)                    │
                    │  middleware: request-id → body size → security│
                    │              headers → rate limit → CORS      │
                    │  routers: auth, meta, health, users, providers│
                    │           models, chat, files, modules,       │
                    │           billing, jobs, admin                │
                    └───┬───────────────┬───────────────┬───────────┘
                        │               │               │
        ┌───────────────▼──┐   ┌────────▼────────┐  ┌───▼─────────────────┐
        │ services layer   │   │ providers layer │  │ db layer (SQLAlchemy)│
        │ access, ledger,  │   │ 16 adapters +   │  │ sessions, models,    │
        │ usage, pricing,  │   │ registry, http  │  │ Alembic migrations   │
        │ payments, jobs,  │   │ transport       │  └──────┬──────────────┘
        │ files, ai, audit │   └────────┬────────┘         │
        └──────────────────┘            │            PostgreSQL / SQLite
                                        ▼
                              provider HTTP APIs
```

## 2. Backend layout

| Path | Responsibility |
| --- | --- |
| `app/core/` | configuration (`config.py`), logging, error taxonomy, crypto (argon2id + Fernet), security helpers, SSRF-safe networking (`net.py`), rate limiting |
| `app/db/` | engine/session management (`get_db`, `get_engine`, `check_database`), declarative `Base` with a timezone-aware `UTCDateTime` |
| `app/models/` | 30 SQLAlchemy tables: users/roles/permissions/sessions, providers/models/grants/tests, conversations/messages, files, jobs, billing (accounts, ledger, payments, subscriptions, plans, pricing rules, usage), audit/security/error events, settings |
| `app/schemas/` | Pydantic request models kept deliberately close to the routers |
| `app/api/v1/` | routers; every admin router mounts under `/api/v1/admin` and each endpoint states its required permission via `require_permission(...)` |
| `app/services/` | the business rules: `access` (visibility → availability → capability → tier → balance), `ledger` (only way money moves), `usage` (one row per billable operation), `pricing` (rule resolution + charge computation), `payments`, `subscriptions`, `files` (validation, storage, extraction, chunking/embeddings), `ai` (chat/streaming/admin tests), `jobs` (queue with leases), `providers` (CRUD, connectivity test, sync), `audit`, `settings_store`, `email`, `bootstrap` |
| `app/providers/` | adapter layer: an abstract `ProviderAdapter` plus concrete OpenAI-compatible, Anthropic, Google, Stability, ElevenLabs, Deepgram and Replicate adapters, a shared HTTP client with retries/rate limiting and a swappable transport (used by tests). `reasoning.py` splits a model's chain of thought out of the visible answer — inline `<think>…</think>` blocks (verified live with MiniMax) and the dedicated `reasoning_content`/`reasoning` field (GLM) — for the blocking and the streaming path, including tags cut in half between two stream chunks |
| `app/workers/` | job worker loop (`worker.py`) and the handler registry (`handlers.py` → `registry_types.HANDLERS`) |
| `app/cli.py` | operational CLI: `bootstrap`, `create-admin`, `grant-credits`, `run-jobs`, `maintenance`, `doctor` |

## 3. Request lifecycle (a chat message)

1. **Middleware** assigns a request id, enforces the body size limit, adds security headers, applies
   rate limiting (Redis when configured, in-process otherwise) and CORS.
2. **Authentication** resolves the session cookie by hashed token and refreshes the idle timer;
   `require_permission` enforces the RBAC slug for the route.
3. **Access resolution** (`services/access.py`) checks, in order: provider enabled → model enabled →
   availability (`untested`/`disabled` are refused, `ModelAvailability.OFFLINE == "degraded_offline"`)
   → capability declared → tier (internal denied, restricted needs a grant, subscription needs an
   active plan, credit needs balance) → per-user/plan quotas and spend caps.
4. **Pricing** (`services/pricing.py`) resolves the effective price: user → plan → model → provider →
   global rule, then the model's own columns, then provider cost + markup, else `unpriced` with a
   warning. All amounts become integer micro-credits.
5. **Provider call** goes through the adapter, which normalises errors into the taxonomy
   (`authentication`, `rate_limit`, `timeout`, `unsupported_operation`, `malformed_response`, …).
6. **Accounting** (`services/usage.py` + `services/ledger.py`) writes one `usage_records` row and, when
   billable, one debit with a unique idempotency key; failed calls record `status=failed` with zero
   charge.
7. **Response** includes the assistant message, token counts, `charged_micro`, the pricing scope and
   any warnings. Streaming uses SSE with `meta`, `delta`, `reasoning`, `error`, `done` events; the
   charge is committed when the stream finishes.

## 4. Data model essentials

* **Money is integer micro-credits** (`BIGINT`), 1 credit = 1 000 000 micro. `credit_ledger` is
  append-only with `UNIQUE(idempotency_key)` and stores `balance_after_micro` for auditing.
  `credit_accounts.balance_micro` is a cache; `app.cli doctor` reconciles it against the ledger.
* **Usage** is one row per billable operation with tokens/units, provider cost, charged amount, the
  pricing rule id and version, and `usage_source` (`provider_reported` / `estimated` / `unavailable`).
* **Model state is three independent axes**: `visibility` (public/hidden) ≠ `availability`
  (available/degraded_offline/disabled/untested) ≠ `access_tier`
  (free/credit/subscription/restricted/internal). `published` and `enabled` are separate flags.
* **Admin tests** live in `admin_model_tests`: request summary, latency, tokens, platform cost and
  diagnostics, always with `is_admin_test = true` and `billed_to_user = false`.
* **Audit** (`audit_events`, `security_events`, `error_events`) is append-only and carries actor,
  entity, before/after state, IP and request id.

## 5. Frontend layout

| Path | Responsibility |
| --- | --- |
| `src/api/` | a small typed fetch client (relative URLs only) + shared response types |
| `src/state/app.tsx` | session, permissions, theme, locale, toasts, i18n context |
| `src/components/` | UI primitives (`ui.tsx`), safe markdown renderer, dependency-free charts, layout/navigation/banner |
| `src/pages/` | user-facing pages (chat, coding, images, documents, data, translation, audio, video, models, files, jobs, billing, payments, subscriptions, usage, profile, security, activity) |
| `src/pages/admin/` | 15 administration pages (dashboard, users, roles, providers, models, pricing, payments, plans, jobs, settings, audit, security, system, errors, backups) |
| `src/locales/` | four dictionaries with identical key sets (en/fa/ar/ckb) driving RTL/LTR |
| `src/styles/` | CSS tokens, layout, components, light/dark/glass themes |

Navigation is nested and permission-aware: groups are filtered by the user's permission set, and every
admin route is additionally wrapped in `RequirePermission`, which renders a Forbidden page instead of
the component.

## 6. Deployment topology

| Mode | Entry point | Database | Notes |
| --- | --- | --- | --- |
| Docker Compose | `web` service (Nginx) on `${PUBLIC_PORT}` | PostgreSQL container (not published) | `api` + `worker` share an uploads volume; migrations run on container start |
| Native Ubuntu | Nginx site on 8080 → `127.0.0.1:8000` | PostgreSQL on the host | systemd units for API and worker |
| Windows | `start_public.bat` → `0.0.0.0:8000` | SQLite (eval) or PostgreSQL | NSSM/Task Scheduler for services |
| Development | Vite on 5173 proxying `/api` to 8000 | SQLite | hot reload on both sides |

The browser always calls **relative** `/api/...` URLs, so the same bundle works behind Nginx, in
Docker and through the Vite dev proxy without rebuilding.

## 7. Design decisions and trade-offs

1. **No fake success paths.** Missing provider configuration raises `503 not_configured` with
   actionable details instead of returning placeholder content. This is a product decision: an
   installation that cannot answer must say so.
2. **Ledger-first money.** Balances are never edited directly; every movement is an immutable entry
   with an idempotency key, so a retried request, a double-click and a racing approval cannot
   double-spend.
3. **Test before publish.** `resolve_model` refuses untested models (`reason: model_not_verified`),
   which makes "verified" a real state rather than a label.
4. **Administrators are not users.** Admin tests bypass user restrictions by design, are audited,
   costed to the platform, budget-capped and can never enable or publish a model.
5. **Transport injection for tests.** `app/providers/http.py:TRANSPORT_FACTORY` lets the suite swap
   httpx transports, so adapter behaviour (including 401/429/timeout handling) is tested without
   network access, while production uses real HTTP.
6. **Redis optional.** Rate limiting and coordination degrade to in-process implementations with a
   single warning line, keeping small deployments simple; multi-worker production should use Redis.
7. **Deployment mode is data, not documentation.** `NEXA_DEPLOYMENT_MODE` drives `security_warning` in
   `GET /api/v1/meta/config`, so every client shows the same warning the operator sees in the logs.
