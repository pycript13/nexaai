# Production deployment

This is the operator's runbook for taking Nexa AI from "it runs" to "it is safe to expose". Two
supported public modes: **plain HTTP on a public IP** (mandatory requirement of the project, useful for
testing/demos) and **domain + HTTPS** (recommended for real use).

## 1. Modes at a glance

| Mode | `NEXA_DEPLOYMENT_MODE` | Cookies | HSTS | When to use |
| --- | --- | --- | --- | --- |
| Local | `local` | insecure allowed | off | development, single machine |
| Public IP | `public_ip` | `false` | `false` | sharing a demo with testers over the internet |
| Domain + HTTPS | `domain_https` | `true` | `true` | real users, real money |

The mode is surfaced in `GET /api/v1/meta/config` (`deployment_mode`, `security_warning`) and rendered
as a banner in the UI, so nobody can claim they were not warned.

## 2. Pre-flight checklist

```
[ ] 2+ vCPU, 4+ GB RAM, 40+ GB disk, UTC clock, correct DNS/hostname
[ ] Docker Compose v2 installed (or the native packages for the Ubuntu path)
[ ] .env with random NEXA_SECRET_KEY, NEXA_ENCRYPTION_KEY, POSTGRES_PASSWORD, admin credentials
[ ] NEXA_ENVIRONMENT=production (refuses SQLite, enables strict checks)
[ ] PostgreSQL reachable and NOT published; Redis private
[ ] NEXA_REGISTRATION_MODE=invite_only or closed
[ ] Backups scheduled and one restore drill completed
[ ] Provider(s) configured, models priced, verified and published
[ ] Payment instructions (bank/crypto) filled in; gateways only if you have real credentials
```

## 3. Docker Compose (typical VPS)

```bash
git clone <repo-url> nexa-ai && cd nexa-ai
cp deployment/.env.production.example .env
# edit .env (see checklist), then:
docker compose up -d --build
docker compose ps
docker compose exec api python -m app.cli doctor
docker compose logs -f api
```

Topology: only `web` publishes a port (`${PUBLIC_PORT}` → container 80). `api` runs migrations and
bootstraps on start, then serves Uvicorn behind Nginx. `worker` consumes the job queue. `db` and
`redis` live on an internal bridge network with no published ports.

Scaling notes: the API is stateless (sessions live in the database), so `docker compose up -d
--scale api=2` works behind Nginx; the worker can be scaled independently. Enable Redis
(`NEXA_REDIS_URL`, `NEXA_USE_REDIS_RATE_LIMIT=true`) before running multiple API instances so rate
limits are shared.

## 4. Native Ubuntu path

```bash
sudo bash deployment/linux/install.sh          # systemd + Nginx on 8080
```

Then harden:

* `nexa-api.service` already binds `127.0.0.1:8000`; keep it that way and let Nginx terminate.
* Keep `ProtectSystem=full`, `NoNewPrivileges`, `PrivateTmp` in the unit files.
* `sudo ufw allow 8080/tcp` (or `80,443` for a domain) and nothing else.
* Add log rotation for `/var/log/nexa-*.log` if you redirect cron output there.

## 5. Domain + HTTPS

```bash
sudo apt -y install certbot python3-certbot-nginx
sudo certbot --nginx -d app.example.com --agree-tos -m admin@example.com --redirect

sudo cp deployment/nginx/nexa-https.conf.example /etc/nginx/sites-available/nexa-ai-https
sudo sed -i 's/YOUR.DOMAIN.TLD/app.example.com/g' /etc/nginx/sites-available/nexa-ai-https
sudo ln -sf /etc/nginx/sites-available/nexa-ai-https /etc/nginx/sites-enabled/nexa-ai-https
sudo nginx -t && sudo systemctl reload nginx
```

```ini
NEXA_DEPLOYMENT_MODE=domain_https
NEXA_PUBLIC_BASE_URL=https://app.example.com
NEXA_CORS_ORIGINS=https://app.example.com
NEXA_COOKIE_SECURE=true
NEXA_HSTS_ENABLED=true
NEXA_TRUSTED_HOSTS=app.example.com          # never "*" in a public deployment
```

`NEXA_TRUSTED_HOSTS` must list every name and address the API answers on (comma separated). A
wildcard is refused at startup in `public_ip`/`domain_https` mode — the installer writes the host's
own addresses automatically. Behind an additional proxy/CDN, add its hostname (a pattern such as
`*.example.net` is accepted) and keep `proxy_set_header Host $host;` in every Nginx location that
proxies to the API, including `/healthz` and `/readyz`: nginx otherwise sends the upstream name and
the API answers `400 Invalid host header`.

Order matters: turn on `COOKIE_SECURE` only after HTTPS answers, otherwise sign-in breaks. Verify:

```bash
curl -sI https://app.example.com/healthz
curl -s https://app.example.com/api/v1/meta/config | python3 -m json.tool | head
cd backend && python -m app.cli doctor         # the plain-HTTP warning must be gone
```

Renewal: `certbot renew --dry-run` (the certbot timer handles production renewals).

## 6. Plain-HTTP public-IP mode (supported, insecure)

```ini
NEXA_DEPLOYMENT_MODE=public_ip
NEXA_PUBLIC_BASE_URL=http://203.0.113.10:8080
NEXA_PUBLIC_PORT=8080
NEXA_COOKIE_SECURE=false
NEXA_HSTS_ENABLED=false
NEXA_REGISTRATION_MODE=invite_only
```

```bash
docker compose up -d                     # or: sudo bash deployment/linux/install.sh
sudo ufw allow 8080/tcp                  # + cloud security group
# Windows: deployment\windows\start_public.bat
```

Mandatory safeguards: throw-away accounts, no production data, test-only provider keys with tight
spend limits, admin account limited to people who understand the risk, and shut the port down when the
test ends.

## 7. Hardening the provider and billing surface

| Area | Setting |
| --- | --- |
| Provider egress | `NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=false`, `NEXA_PROVIDER_ALLOWED_HOSTS=<allowlist>`, HTTPS only |
| Provider throughput | per-provider `requests_per_minute` / `max_concurrency`, plus `read_timeout` tuned per operation |
| User spend | account daily/monthly limits, per-user quotas, plan limits, grant caps |
| Platform | `NEXA_GLOBAL_DAILY_SPEND_LIMIT_MICRO`, admin-test budget |
| Payments | manual + crypto require human approval; gateways need webhook signature verification |
| Uploads | `NEXA_MAX_UPLOAD_MB`, `NEXA_USER_STORAGE_QUOTA_MB`, `NEXA_ALLOWED_UPLOAD_EXTENSIONS`, optional malware scan |

## 8. Monitoring and operations

| Check | Command | Expected |
| --- | --- | --- |
| Liveness | `curl -fsS https://host/healthz` | `{"status":"ok"}` |
| Readiness | `curl -fsS https://host/readyz` | `{"status":"ready","database":"ok"}` |
| Deep status | `GET /api/v1/health/deep` | components + payment provider configuration flags |
| Worker | `GET /api/v1/health/worker` | pending/running counts, stale leases |
| Integrity | `python -m app.cli doctor` | `production_problems` empty, ledger `inconsistent: 0` |
| Errors | Admin → Errors / `error_events` | classified with request ids |
| Security | Admin → Security | failed logins, denials, lockouts |

Alert suggestions: readiness != 200, worker queue depth growing, `error_events` with
`authentication` spiking, disk > 85%, ledger reconciliation drift.

## 9. Upgrade procedure

```bash
scripts/backup.sh --keep 10               # 1. always back up first
git pull                                  # 2. fetch the new code
docker compose build --pull               # 3. rebuild images
docker compose up -d                      # 4. migrate + restart (migrations run on start)
docker compose exec api python -m app.cli doctor
```

Native install: `git pull && sudo bash deployment/linux/install.sh` (the installer keeps an existing
`.env`), then `systemctl restart nexa-api nexa-worker`.

Once a month (and before any upgrade you are unsure about), restore the backup you just took into a
scratch database and prove it works — one command, no manual SQL:

```bash
sudo bash scripts/restore_drill.sh          # newest backup; add --keep to inspect the scratch DB
```

It fails loudly if the restored data cannot be read by the application role, if the API cannot boot
against it, if the administrator cannot sign in, or if `app.cli doctor` finds an unbalanced ledger.
See [`BACKUP_RESTORE.md`](BACKUP_RESTORE.md) §5.

Rollback: `git checkout <previous-tag>`, rebuild, and restore the database if a migration already
changed the schema (`python -m alembic downgrade -1` for a single step).

## 10. Go-live sign-off

```
[ ] HTTPS with a valid certificate and HSTS enabled; HTTP redirects
[ ] Admin password changed; every administrator has their own account and role
[ ] Providers tested, models priced + published; at least one real request executed
[ ] Manual payment instructions correct; one approval performed and verified in the ledger
[ ] Backups running; one restore drill passed and recorded
[ ] Monitoring/alerts wired; audit review scheduled
[ ] Testers/users informed about the terms and the support contact
```
