# Backup and restore

Nexa AI ships working backup, verification and restore scripts plus an administrative endpoint. This
document explains what is protected, how to run it, and how to prove a restore actually works.

## 1. What must be backed up

| Item | Where | Why |
| --- | --- | --- |
| Database | PostgreSQL (production) or SQLite (dev) | users, models, pricing, ledger, audit — the irreplaceable state |
| Uploads | `NEXA_UPLOAD_DIR` (`uploads/private`, `uploads/generated`) | user documents, generated images/audio/video |
| `.env` | project root | secrets and provider encryption key — **store in a password manager, never in the archive** |
| Provider credentials | encrypted inside the database | recoverable only with the same `NEXA_ENCRYPTION_KEY` |

Without the matching `NEXA_ENCRYPTION_KEY`, provider credentials in a restored database cannot be
decrypted and must be re-entered. Back the key up separately and securely.

## 2. Running a backup

```bash
scripts/backup.sh                        # database + uploads archive, prune older than 14 days
scripts/backup.sh --keep 30              # different retention
scripts/backup.sh --no-uploads           # database only
scripts/backup.sh --output-dir /mnt/backups
```

Behaviour: reads `.env` (`NEXA_DATABASE_URL`, `NEXA_UPLOAD_DIR`), then

* PostgreSQL → `pg_dump --format=custom --no-owner --no-privileges` into
  `backups/nexa-pg-<UTC-stamp>.dump`;
* SQLite → a consistent copy via `sqlite3 .backup` (falls back to `cp` if sqlite3 is absent);
* runs `scripts/verify_backup.sh` immediately — a backup that cannot be read is a failure, not a
  success;
* archives uploads into `backups/nexa-uploads-<stamp>.tar.gz`;
* prunes files older than `--keep` days.

Windows: `deployment\windows\backup.bat` (SQLite copy or `pg_dump`, plus a ZIP of `uploads`).

Docker:

```bash
docker compose exec db pg_dump -U nexa -Fc nexa > backups/nexa-$(date -u +%Y%m%dT%H%M%SZ).dump
docker compose cp api:/app/uploads ./backups/uploads-$(date -u +%F)
# or, from inside the api container, run the same script the native install uses:
docker compose exec api /app/scripts/backup.sh --output-dir /app/backups
```

Scheduled: install the lines from `deployment/linux/nexa-backup.cron` (nightly 02:30 backup, weekly
03:15 verification).

## 3. Verifying a backup

```bash
scripts/verify_backup.sh backups/nexa-sqlite-20260101T023000Z.db
# → PRAGMA integrity_check ok, table/user/ledger counts

scripts/verify_backup.sh backups/nexa-pg-20260101T023000Z.dump
# → pg_restore --list succeeds, object count reported
```

A verification proves the archive is readable and structurally complete. It does **not** prove the
application logic runs — that is what the restore drill below is for.

## 4. Restoring

Restores refuse to run unless the application is stopped and `--yes` is passed, because they replace
the live database.

```bash
sudo systemctl stop nexa-api nexa-worker         # or: docker compose stop api worker

scripts/restore.sh backups/nexa-sqlite-20260101T023000Z.db --yes
# or
scripts/restore.sh backups/nexa-pg-20260101T023000Z.dump --yes \
        --uploads backups/nexa-uploads-20260101T023000Z.tar.gz

sudo systemctl start nexa-api nexa-worker
scripts/health_check.sh http://127.0.0.1:8080
cd backend && python -m app.cli doctor           # balances must reconcile: inconsistent: 0
```

Details: PostgreSQL is restored with `pg_restore --clean --if-exists`; SQLite keeps a
`*.pre-restore.<stamp>` copy of the current file before overwriting; uploads are extracted next to the
configured upload directory.

Docker restore: stop `api`/`worker`, run the same script inside a container that mounts the volumes,
or `pg_restore` directly against the `db` service, then start the services again.

## 5. The restore drill (run it monthly; automated)

A backup you have never restored is a guess. `scripts/restore_drill.sh` performs the whole drill
in one command and fails loudly if any step does not hold — it is the same sequence a real recovery
follows, against a scratch database, without touching the live one:

```bash
sudo bash scripts/restore_drill.sh                  # newest backup in backups/
sudo bash scripts/restore_drill.sh backups/nexa-pg-20260101T023000Z.dump
sudo bash scripts/restore_drill.sh --keep           # keep the scratch database for inspection
```

What it does, and what it checks:

1. picks the backup (or takes the file you pass) and prints the connection string with the password
   **redacted**;
2. creates a scratch PostgreSQL database **owned by the application role** and restores **as that
   role** — a restore performed as another user (for example `postgres`) creates every table for that
   user, and the application then dies with `permission denied for table permissions` the moment an
   API is started against it. SQLite backups are copied into a scratch directory instead;
3. asserts the restored schema is *readable by the application role* (table, user and
   `credit_ledger` row counts are printed);
4. boots a throw-away API against the restored data and waits for `/readyz`;
5. signs the bootstrap administrator in (`NEXA_BOOTSTRAP_ADMIN_PASSWORD` from `.env`);
6. runs `python -m app.cli doctor` against it and **fails unless `inconsistent: 0`**, so the ledger
   has to reconcile from restored data;
7. drops the scratch database (unless `--keep`).

A passing run looks like this (executed on the installed PostgreSQL deployment, 2026-10-13):

```
[drill] backup under test : /opt/nexa-ai/backups/nexa-pg-20261013T200347Z.dump
[drill] live database     : postgresql+psycopg2://nexa:***@127.0.0.1:5432/nexa
[drill] creating the scratch database 'nexa_drill_200506' owned by 'nexa'
[drill] restoring as the application role
[drill] restored: tables=33 users=1 credit_ledger_rows=1
[drill] API ready against the restored database (/readyz answered)
[drill] administrator sign-in against the restored data: 200
[drill]       "dialect": "postgresql", "accounts_checked": 1, "inconsistent": 0
[drill] PASS — the backup restores into a usable database …
```

Record the date and the result in §7, and keep the drill DB name so a failed run can be inspected
(`--keep`).

### Doing it by hand (equivalent steps)

```bash
sudo -u postgres createdb -O nexa nexa_drill        # -O: the scratch DB must belong to the app role
sudo -u postgres psql -d nexa_drill -c 'ALTER SCHEMA public OWNER TO nexa'
PGPASSWORD='<db password>' pg_restore --no-owner --no-privileges \
    --dbname=postgresql://nexa:<db password>@127.0.0.1:5432/nexa_drill backups/nexa-pg-*.dump

cd backend
NEXA_DATABASE_URL=postgresql+psycopg2://nexa:<db password>@127.0.0.1:5432/nexa_drill \
NEXA_DEPLOYMENT_MODE=local python -m uvicorn app.main:app --port 8081
# sign in, open the ledger and usage pages, run one chat, then:
python -m app.cli doctor                            # inconsistent: 0
sudo -u postgres dropdb nexa_drill
```

## 6. Recovery scenarios

| Scenario | Action |
| --- | --- |
| Bad migration | `python -m alembic downgrade -1` then re-apply; if the data is already inconsistent, restore the last dump |
| Accidental user deletion | restore into a scratch database, copy the missing rows forward with SQL, then reconcile the ledger |
| Corrupted SQLite file | restore the newest verified `.db` copy (the pre-restore file is kept automatically) |
| Lost uploads volume | restore the `uploads` archive; file rows remain valid because paths are relative to the upload root |
| Lost `.env` | restore secrets from the password manager; provider keys still decrypt if `NEXA_ENCRYPTION_KEY` matches |
| Ransomware/compromise | rebuild the host, restore from an off-box backup, rotate every secret and provider key, and review `audit_events` from before the incident |

## 7. Retention and off-site policy (suggested)

| Tier | Frequency | Retention | Location |
| --- | --- | --- | --- |
| Local | nightly 02:30 | 14 days | `backups/` on the server |
| Remote | nightly copy | 30 days | object storage or another host |
| Monthly | first Sunday | 12 months | cold storage |
| Restore drill | monthly | report kept | scratch host |
