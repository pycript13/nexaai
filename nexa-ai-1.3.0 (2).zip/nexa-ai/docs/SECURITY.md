# Security

This document describes the threat model and the controls that are actually implemented in the code
base, plus what operators must do themselves. Anything not implemented is listed in
[`KNOWN_LIMITATIONS.md`](KNOWN_LIMITATIONS.md) rather than implied here.

## 1. Threat model

| Asset | Threat | Control |
| --- | --- | --- |
| User accounts | credential stuffing, brute force | argon2id hashing, password policy, login rate limit, failed-login lockout, `security_events` trail |
| Sessions | cookie theft/replay | server-side sessions with hashed tokens, CSRF token per session, `HttpOnly` + `SameSite`, idle timeout, revoke-all, `Secure` flag in HTTPS mode |
| Provider credentials | database leak | Fernet envelope encryption outside the DB (`NEXA_ENCRYPTION_KEY`), masked in every API response, never logged |
| Money | double-charge / double-credit | append-only ledger, unique idempotency keys, transaction-scoped writes, compensating entries only, reconciliation via `doctor` |
| Admin surface | privilege escalation | RBAC slug per endpoint, non-admins get 403 (tested), every admin action audited with actor/IP/request id |
| Provider traffic | SSRF (server used as a proxy) | outbound URL validation, private-range blocking by default, optional host allowlist, HTTPS by default |
| Uploads | malware / path traversal / type confusion | extension allowlist, size limit, content-signature validation, generated storage names, quarantine of scan failures, quotas |
| Availability | abusive volume | global + auth rate limits (Redis or in-process), body size limit, per-user request/spend caps, per-provider concurrency limits |
| Data in transit | interception | HTTPS path documented and supported, HSTS + secure cookies when enabled, plain-HTTP mode warns in the UI and API |
| Prompted content | XSS via model output | model text is rendered through a restricted markdown renderer and escaped; no `dangerouslySetInnerHTML` of raw output |

## 2. Authentication and sessions

* Passwords: argon2id (`time_cost=3`, `memory_cost=64 MiB`, `parallelism=2`), minimum length
  `NEXA_PASSWORD_MIN_LENGTH` (default 10), common-password and email/name-similarity checks.
* Password changes revoke other sessions; `GET/DELETE /api/v1/auth/sessions` lets a user see the
  device list and revoke one or all sessions. Administrators can revoke a user's sessions too.
* Sessions are stored server-side with `token_hash` (unique, indexed), `csrf_token`, `ip_address`,
  `user_agent`, `last_seen_at`, `expires_at` and `revoked_at/revoked_reason`.
* Login lockout: `NEXA_LOCKOUT_THRESHOLD` failures within `NEXA_LOCKOUT_MINUTES` locks the account and
  records a `security_events` row.
* Cookie flags are configuration, not assumptions: `NEXA_COOKIE_SECURE`, `NEXA_COOKIE_SAMESITE`,
  `NEXA_COOKIE_DOMAIN`. In HTTPS mode set `Secure=true`; in plain-HTTP testing mode it must stay false
  or nothing works (documented in the troubleshooting table).

## 3. Authorization

* 30 permissions grouped per area; 6 roles (`super_admin`, `admin`, `finance_manager`,
  `model_manager`, `support_agent`, `user`). `super_admin` holds `*`.
* Every admin endpoint declares its required permission through `require_permission(...)`; the test
  suite asserts that normal users get 403 on the admin surface and that support/manager roles get
  exactly their slice.
* The frontend mirrors the same slugs for navigation and route guards — but the API is the authority;
  hiding a menu item is never the control.
* Object-level checks exist where ownership matters: files, conversations, jobs, payments and ledger
  reads are scoped to the requesting user (cross-user access returns 404, tested).

## 4. Provider credentials and SSRF

* Secrets are encrypted with Fernet before insert; the API returns `api_key_hint` and
  `has_credentials` only, and logs never contain secret values.
* Outbound provider URLs pass through `app/core/net.py`: scheme must be https unless
  `NEXA_PROVIDER_ALLOW_INSECURE_HTTP=true`, host resolution must not land in private/loopback/
  link-local ranges unless `NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=true`, and
  `NEXA_PROVIDER_ALLOWED_HOSTS` pins an allowlist for strict deployments.
* Provider-generated URLs (for example an image URL returned by an upstream) are validated with the
  same policy before the server fetches them.
* `NEXA_ENCRYPTION_KEY` rotation requires re-entering provider keys; the failure mode is an explicit
  "stored secret cannot be decrypted" error, never a silent fallback.

## 5. Input validation and file handling

* Pydantic models validate every request body; unknown fields are rejected where they could be
  dangerous (injection through developer-provided keys is avoided by using explicit fields).
* Uploads: extension allowlist (`NEXA_ALLOWED_UPLOAD_EXTENSIONS`), `NEXA_MAX_UPLOAD_MB` limit enforced
  twice (middleware + service), magic-byte signature check against the extension, UUID-based storage
  names inside a fixed root (path traversal impossible — verified by a test that requests
  `../../etc/passwd` and receives a 404), per-user quotas, retention (`NEXA_FILE_RETENTION_DAYS`), and
  optional malware scanning (`NEXA_MALWARE_SCAN_ENABLED` + command). Files are downloaded through an
  authorization check, not by a static path.
* Excel/CSV handling is read-only and size-bounded; documents are parsed with `pypdf`/`openpyxl` and
  failures return clear errors.
* Request bodies are capped (`NEXA_MAX_REQUEST_BODY_MB`) with a `413 payload_too_large` response.

## 6. Logging, audit and privacy

* `audit_events` is append-only: actor, action, entity, before/after state, IP, user agent, request id.
  Administrators can read and filter; nothing exposes an edit or delete path.
* `security_events` records failed logins, lockouts, permission denials and suspicious input;
  `error_events` stores classified failures with the request id so a user-reported problem can be
  traced.
* Sensitive values (passwords, tokens, API keys, payment secrets) are redacted by the logging filters;
  the JSON log mode (`NEXA_LOG_JSON=true`) is intended for shipping to a collector.
* `GET /api/v1/admin/system` and `/api/v1/health/deep` expose component status without leaking
  secrets; error responses never include stack traces.

## 7. Account recovery (CLI)

`python -m app.cli reset-password --email <address> [--generate] [--must-change]` sets a new password for
an existing account. It requires shell access to the server (it is never exposed over the API), enforces
the same password policy as the UI, revokes **all** sessions of that account and writes a
`user.password_reset` audit event with severity `warning`. The installer uses the same command when an
`.env` was replaced, and rotates a placeholder administrator password automatically — logging the
rotation and the revocation.

## 8. Operator responsibilities (not automatable)

```
[ ] Replace the bootstrap admin password and never reuse installer defaults
[ ] Keep .env at mode 600 outside version control
[ ] Never publish PostgreSQL/Redis; restrict the API port to Nginx/loopback
[ ] Enable NEXA_COOKIE_SECURE + NEXA_HSTS_ENABLED only after HTTPS is working
[ ] Limit NEXA_REGISTRATION_MODE when the instance is reachable publicly
[ ] Set NEXA_TRUSTED_HOSTS to the real domain in production
[ ] Configure spend caps (per user, per plan, admin test budget)
[ ] Review audit/security events regularly and export them off-box
[ ] Keep the OS, Python, Node and dependencies patched; rebuild images after updates
[ ] Take and test backups; an untested backup is not a backup
[ ] Terminate plain-HTTP public-IP testing as soon as the demo is over
```

## 9. Framing policy (embedding this deployment)

By default every response carries `X-Frame-Options: DENY`, so no other site can put Nexa AI
in an `<iframe>` and overlay it with fake controls (clickjacking).

A deployment that must be embedded — an internal portal, a workspace preview host — sets
`NEXA_FRAME_ANCESTORS` to the exact origins that may frame it:

```
NEXA_FRAME_ANCESTORS=https://portal.example.com      # space-separated, no wildcards needed
```

The application then answers with `Content-Security-Policy: frame-ancestors …;` **and stops
sending `X-Frame-Options`** (a browser that sees both ignores the allow-list). The startup log
adds a deployment warning, and the setting is never defaulted: leaving it empty keeps
clickjacking protection on. Do not use `*`.

## 10. Reporting a vulnerability

Do not open a public issue with exploit details. Contact the operator of the deployment (the address
in `NEXA_SUPPORT_EMAIL`) with: affected endpoint, reproduction steps, impact and any proof-of-concept.
Include the `request_id` from the response if available — it maps directly to the audit trail.
