# Billing, credits and payments

Money is the part of a platform that must never "mostly work". This document describes the model,
the invariants enforced in code and in the database, the payment flows and the operational controls.

## 1. Units and storage

* 1 credit = **1 000 000 micro-credits**. All amounts are integers (`BIGINT`) named `*_micro`.
* No `FLOAT`/`DOUBLE` is used for money anywhere. Display conversion happens only at the edges
  (`formatCredits` in the frontend, `micro_to_credits` in the API), and the API also returns
  human-readable `*_display` strings.
* Provider costs are stored in USD and converted with `usd_to_micro() = usd / NEXA_CREDIT_USD_RATE × 1e6`
  so the ledger always compares like with like.
* Selling prices are entered in **credits per 1 000 000 tokens** and stored as **micro-credits per
  1 000 000 tokens** (``0.28`` credits/MTok -> ``280000``), rounding half-up. A charge for *n* tokens is
  therefore ``n × rate / 1e6`` micro-credits, rounded half-up per line item.
  Per-request / per-image / per-audio-minute / per-job prices are full credit amounts stored as plain
  micro-credits.
* The scale matters: pricing a model at ``0.28`` credits per MTok (a DeepSeek/GPT-4o-mini class price) is
  a *valid* price. Storing per-token prices in micro-credits **per token** would round every price below
  one credit per MTok down to ``0`` and bill the request as free while still reporting success. Revision
  ``c7d41b0f9a13`` rescales pre-existing rule values by ``1 000 000`` so their effective price is unchanged;
  see `tests/test_pricing_units.py` (the regression guards) and `tests/test_billing.py`
  (end-to-end: balance delta + immutable ledger entry for a cheap model).

## 2. The ledger

`credit_ledger` is the single source of truth:

| Column | Notes |
| --- | --- |
| `entry_type` | `deposit`, `usage_charge`, `admin_grant`, `adjustment`, `refund`, `subscription_credit` |
| `amount_micro` | signed; charges are negative |
| `balance_after_micro` | snapshot for auditing and for the "balance after" column in the UI |
| `idempotency_key` | **UNIQUE** — the database, not application code, rejects a double post |
| `reference_type` / `reference_id` | link back to the payment, usage row or subscription |
| `reversal_of_id` | set on compensating entries |
| `created_by_id` | administrator who performed a manual movement |

`credit_accounts.balance_micro` is a cache updated in the same transaction as the entry. A nightly or
on-demand reconciliation is available:

```bash
cd backend && python -m app.cli doctor     # reports inconsistent accounts and drift rows
```

Idempotency keys in use:

| Movement | Key |
| --- | --- |
| manual payment approval | `payment:{reference}` |
| subscription period credit | `subscription:{id}:{period_start}` |
| usage charge | `usage:{idempotency_key}` |
| refund | `refund:{reference}:{total}` |

A racing duplicate raises an `IntegrityError` which the service layer treats as "already applied" —
the caller's retry is safe.

## 3. How a request is charged

1. **Estimate** before the call: `_estimate_media_cost()` / `compute_charge()` produce the expected
   charge for the planned units.
2. **Pre-flight balance check**: `ensure_balance_for_request()` raises `402 insufficient_balance`
   (with the missing amount) before any provider traffic, and quota checks raise `429`.
3. **Provider call** happens exactly once (adapters retry only on clearly retryable failures).
4. **Usage record**: one `usage_records` row with tokens/units, `usage_source`
   (`provider_reported` / `estimated` / `unavailable`), latency, provider request id, the pricing rule
   id + version and `billed_to_user`.
5. **Debit**: a single negative ledger entry; a failure records `status=failed` with **zero** charge
   (verified by the test suite).
6. **Commit** happens before the response is returned for the module endpoints, so the charge always
   exists when the client sees `charged_micro`.

The response always includes the charge and any warnings (unpriced model, derived-from-provider-cost,
uncertain provider cost).

## 4. Spending controls

| Control | Where | Effect |
| --- | --- | --- |
| `credit_accounts.daily_spend_limit_micro` / `monthly_spend_limit_micro` | per account (set by an admin) | `429` with the limit and the spent amount |
| `users.quota_requests_per_day` / `quota_spend_micro_per_day` | per user | request-count and spend caps |
| plan `daily_request_limit` / `monthly_token_limit` | subscription | enforced for plan members |
| `model_grants.daily/monthly_spend_limit_micro` | restricted models | caps a granted user or role |
| `NEXA_ADMIN_TEST_DAILY_LIMIT_MICRO` / `..._MAX_COST_PER_REQUEST_MICRO` | admin tests | platform-side budget, never billed to users |
| `NEXA_GLOBAL_DAILY_SPEND_LIMIT_MICRO` | platform | circuit breaker |
| `is_frozen` on the account | admin freeze | all spending refused with a clear error |

## 5. Payments

### 5.1 Manual bank transfer (enabled by default)

```http
GET  /api/v1/billing/payment-methods        # methods[].enabled + instructions users must follow
POST /api/v1/billing/payments
{ "amount_micro": 25000000, "method": "manual_bank_transfer",
  "payer_name": "…", "bank_reference": "REF-123", "paid_at": "2026-01-01T10:00:00Z",
  "receipt_file_id": 7, "note": "…" }
```

* The payment is created with `status=awaiting_review` and **the balance does not move** (verified by
  the test suite).
* The administrator reviews it in _Admin → Finance → Payments_ and approves:

```http
POST /api/v1/admin/billing/payments/{id}/approve
{ "note": "matched the bank statement", "confirm": true }
```

* Approval posts exactly one ledger entry keyed `payment:{reference}`; the response reports
  `credited_micro`, `balance_after_micro` and `already_credited`. A second approval returns `422`.
* Rejection (`/reject` with a reason) and refunds (`/refund` with `amount_micro`, `confirm`, optional
  `allow_negative`) are separate, audited actions. Refunds create compensating entries and never delete
  history; the payment moves to `partially_refunded`/`refunded`.

### 5.2 Crypto

Enable with `NEXA_CRYPTO_PAYMENTS_ENABLED=true` and `NEXA_CRYPTO_WALLETS=BTC=…,ETH=…,USDT-TRC20=…`.
Users submit the asset, network, address, amount and transaction hash; the admin records on-chain
verification (`POST .../verify-crypto` with `tx_hash` and `confirmations`) before approval. Without
configuration the endpoint answers `503 not_configured` — no pretend wallet addresses are ever shown.

### 5.3 Gateways

Stripe and Zarinpal adapters exist (`gateway_stripe_*`, `gateway_zarinpal_*`). They require real keys
plus a webhook endpoint; the signature must verify. **A `success` redirect is never treated as proof of
payment** — only a verified webhook (or an administrator) may credit. Live gateway traffic has not been
exercised in this environment; see [`TEST_REPORT.md`](TEST_REPORT.md).

## 6. Subscriptions and plans

* Plans carry `price_micro_monthly`, `included_credit_micro` and quotas; three plans are seeded
  (`starter-monthly`, `pro-monthly`, `team-monthly`) and are editable in _Admin → Finance → Plans_.
* Users see available plans and a `purchase_note` explaining that activation is an administrator
  action in this deployment (no automated checkout).
* Activation: `POST /api/v1/admin/billing/subscriptions`
  `{ "user_id": 5, "plan_id": 2, "grant_credits": true }` → the plan's included credit is posted as a
  `subscription_credit` entry keyed to the period, so reactivating the same period cannot double-credit.
* Renewal: `POST .../subscriptions/{id}/renew?days=30`. Expiry: `python -m app.cli maintenance`
  lapses subscriptions whose period ended (honouring `cancel_at_period_end`).

## 7. What users and administrators see

| Endpoint | Content |
| --- | --- |
| `GET /api/v1/billing/balance` | balance, lifetime deposited/spent, spent today/this month, spend limits, `is_frozen`, subscription |
| `GET /api/v1/billing/ledger` | entries with `balance_after_micro` (negatives highlighted in the UI) |
| `GET /api/v1/billing/usage` | per-operation: module, status, model, tokens, `charged_micro`, `provider_cost_micro`, `usage_source`, latency, error category |
| `GET /api/v1/billing/payments` | user's payment requests and status |
| `GET /api/v1/admin/billing/reports` | revenue vs provider cost, margin, top models/users |
| `GET /api/v1/admin/billing/pricing` | rules with scope, version, markup and activation state |

## 8. Financial integrity checklist (enforced, not aspirational)

```
[x] Balance changes only through ledger entries (append-only, unique idempotency key)
[x] Approving a manual payment twice is refused (422) — tested
[x] Submitting a payment does not credit anything — tested
[x] A failed provider call records status=failed with a zero charge — tested
[x] Parallel debits never overdraw: 10 and 20 concurrent 10-credit charges stayed consistent — tested
[x] Daily spend caps return 429 and block the call before the provider is contacted — tested
[x] Admin tests never bill a user and are capped separately — tested
[x] Refunds are compensating entries keyed refund:{reference}:{total} — tested
[x] `doctor` reconciles cached balances against the ledger — available on demand
```

## 9. Operational recipes

| Task | Command / endpoint |
| --- | --- |
| Grant goodwill credit | `python -m app.cli grant-credits --email u@example.com --credits 10 --reason "apology"` or `POST /api/v1/admin/users/{id}/credits` |
| Freeze a suspicious account | `PATCH /api/v1/admin/users/{id}` with the freeze flag, or the danger zone in the user dialog |
| Adjust a wrong charge | Refund the payment or post an `adjustment` entry with a documented reason (never edit a row) |
| Change the credit value | `NEXA_CREDIT_USD_RATE` (affects future conversions and displays) |
| Audit a user's money | `GET /api/v1/admin/users/{id}/ledger` plus `GET /api/v1/admin/audit?search=<email>` |
