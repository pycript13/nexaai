# Installing on Ubuntu / Debian

Covers Ubuntu 22.04/24.04 and Debian 12. Two supported routes: **native** (systemd + Nginx, no
Docker) and **Docker Compose**. The full manual is [`RAHNAMA.md`](RAHNAMA.md) (fa) /
[`INSTALLATION_GUIDE.md`](INSTALLATION_GUIDE.md) (en); this page is the platform-specific checklist.

## 1. Native install (recommended on a plain VPS)

```bash
sudo apt update && sudo apt -y upgrade
sudo apt -y install git curl unzip
git clone <repo-url> nexa-ai && cd nexa-ai
sudo bash deployment/linux/install.sh
```

**The installer asks instead of deciding.** Running it on a terminal gives you three questions:

```
How should people reach this application?
  1) Public IP, no domain      — open http://<server-ip>:<port>: works immediately, plain HTTP
  2) A domain (with HTTPS)     — you type a name such as ai.example.com; Nginx is configured for
                                 it and a Let's Encrypt certificate is issued when possible
  3) This machine only         — nothing is exposed; browse http://127.0.0.1:8000
Administrator e-mail (the sign-in name) [admin@example.com]:
Administrator display name [Nexa Administrator]:
Password: at least 10 characters, typing is hidden — press Enter alone to generate one
```

So you choose **who can reach the app** and **the main administrator's e-mail, name and password**
yourself. Everything is validated before anything is installed, and re-running the installer on an
existing installation keeps it as it is (it offers the stored values as defaults and only changes
the password when you ask).

Not on a terminal (a script, cron, cloud-init)? Nothing is asked — pass the answers as flags:

| Flag | Meaning |
| --- | --- |
| `--access public` \| `domain` \| `local` | reachability mode (default `public` when it cannot ask) |
| `--domain ai.example.com` | the domain that points here; implies `--access domain` |
| `--acme-email you@example.com` | Let's Encrypt e-mail (needed only for automatic issuance) |
| `--public-port N` | published port (default 8080; **80** in domain mode) |
| `--admin-email A`, `--admin-name N` | the first Super Admin |
| `--admin-password P` | a password you choose (omit to be asked, or to have one generated) |
| `--generate-admin-password` | never prompt; generate a strong password and store it in `.env` |
| `--non-interactive` | never prompt (also automatic when stdin is not a terminal) |
| `--app-dir DIR`, `--python PATH` | install location / interpreter |
| `--no-packages`, `--no-node`, `--no-nginx`, `--no-systemd` | skip steps you manage yourself |
| `--reset-env`, `--reset-admin-password`, `--no-public-check` | recovery and re-run helpers |

For automation that must not put a password on the command line, export `NEXA_ADMIN_PASSWORD`
instead — it stays out of the process list and out of the install log. `-h`/`--help` prints all of it.

### Which mode should I pick?

| Situation | Mode | What you get |
| --- | --- | --- |
| Testing with other people right now, no domain yet | `--access public` | `http://<server-ip>:8080`. Works immediately; the UI shows the plain-HTTP security warning. Share the URL — if it does not open for them, the installer's reachability report names the exact missing firewall/NAT rule. |
| You own a domain | `--access domain --domain ai.example.com --acme-email you@example.com` | Nginx serves the domain; with DNS in place the installer issues a Let's Encrypt certificate, switches to HTTPS, enables HSTS and Secure cookies, and installs a daily renewal job. Without DNS/certbot it stays on plain HTTP on the domain and tells you exactly what to do next. |
| Just trying it on this machine | `--access local` | Nothing is published; `http://127.0.0.1:8000`. |

Changing your mind later is a re-run, not a reinstall: the database, uploads and settings are kept,
and an explicit `--access …` rewrites the access configuration (`.env` is backed up first).

**Python version:** this release supports **Python 3.11–3.13**. The pinned dependency set
(`pydantic 2.10` / `pydantic-core 2.27`) has prebuilt wheels up to 3.13; on 3.14+ pip would try to
compile `pydantic-core` from source and fail with a Rust/PyO3 error. The installer therefore selects a
supported interpreter itself (`python3.13` → `python3.12` → `python3.11` → `/usr/bin/python3` → `python3`),
installs `python3`/`python3-venv` when none is present, rebuilds a virtualenv that was created by an
unsupported interpreter, and refuses an explicit `--python` that is out of range.

What the installer does, in order:

1. installs `python3`, `python3-venv`, `python3-dev`, `build-essential`, `libpq-dev`, `postgresql`,
   `redis-server`, `nginx`, `curl`, `git`, `unzip`, `openssl`, `sqlite3`, `rsync` (plus `nodejs`/`npm`
   when they are missing);
2. **starts PostgreSQL and Redis itself** (systemd → `service` → `pg_ctlcluster` → raw `pg_ctl`) and
   waits until `pg_isready` answers — a freshly installed server is not started by `apt` in
   containers, and the installer no longer assumes it is;
3. creates the system user `nexa` with home `/opt/nexa-ai` and copies the project there (never
   overwriting `.env`, `venv/`, `data/`, `uploads/`, `backups/`, `logs/`);
3. creates the PostgreSQL role `nexa` and database `nexa` (random password) and prints nothing secret
   to the console except the admin e-mail;
4. writes `/opt/nexa-ai/.env` with `chmod 600`, generating `NEXA_SECRET_KEY` and
   `NEXA_ENCRYPTION_KEY`, and storing the administrator you chose (or a generated password when you
   pressed Enter at the password question);
5. creates `/opt/nexa-ai/venv` and installs `backend/requirements.txt`;
6. builds the SPA with `npm install && npm run build` (skipped with a warning when npm is absent);
7. **pre-flight check** with `python -m app.cli doctor`: if the application would refuse to start
   (placeholder secrets, SQLite in production, wildcard `NEXA_TRUSTED_HOSTS`) the installer stops
   with the exact problem instead of installing a service that dies at boot;
8. runs `alembic upgrade head` and `python -m app.cli bootstrap`;
9. installs `nexa-api.service` and `nexa-worker.service` (placeholders `__APP_DIR__`, `__APP_USER__`
   substituted) and enables them — or, when systemd is unavailable (containers), starts the same two
   processes through `deployment/linux/nexa-services.sh` with PID files in `/opt/nexa-ai/run`;
10. installs the right Nginx site for your choice — `nexa-host.conf` (public IP),
    `nexa-domain-http.conf` / `nexa-domain-https.conf` (domain), or none at all (local mode).
    Health endpoints are proxied with an explicit `Host` header. In domain mode the certificate is
    sought (or issued with certbot), TLS is verified against the domain name, a daily renewal job is
    installed, and a self-signed certificate is reported as such instead of being called "working";
11. runs the health check **and** verifies that the administrator account can really sign in with the
    password stored in `.env`;
12. opens the port(s) in `ufw` when available, writes `/opt/nexa-ai/.install-info` (date, access
    mode, deployment mode, domain, public URL, admin e-mail, service mode, paths — useful for
    support) and prints the URL with a **"SHARE IT WITH OTHERS"** block: what to send people, and
    the three things that stop an outside browser (host firewall, cloud security group, NAT/port
    forward) with the command to re-check.

Override defaults through environment variables:

```bash
sudo APP_DIR=/srv/nexa-ai PUBLIC_PORT=8080 ADMIN_EMAIL=ops@example.com \
     ADMIN_NAME="Ops Team" NEXA_ADMIN_PASSWORD='<choose-one>' \
     DB_PASSWORD='<strong-password>' bash deployment/linux/install.sh --non-interactive --access public
```

Unattended installs with a domain (DNS must already point here):

```bash
sudo bash deployment/linux/install.sh --non-interactive \
     --access domain --domain ai.example.com --acme-email ops@example.com \
     --admin-email ops@example.com --admin-name "Ops Team" --generate-admin-password
```

The full domain + HTTPS walk-through (DNS, certificate, renewal, verification) is in
[`PRODUCTION_DEPLOYMENT.md`](PRODUCTION_DEPLOYMENT.md) and in the "Domain and HTTPS" section below.

## 2. Post-install verification

```bash
# systemd hosts
systemctl status nexa-api nexa-worker nginx postgresql
journalctl -u nexa-api -n 50 --no-pager
# hosts without systemd (containers)
/opt/nexa-ai/deployment/linux/nexa-services.sh status
tail -n 50 /opt/nexa-ai/logs/api.log

/opt/nexa-ai/scripts/health_check.sh http://127.0.0.1:8080
cd /opt/nexa-ai/backend && sudo -u nexa ../venv/bin/python -m app.cli doctor
sudo nginx -t
```

Expected: `healthz`/`readyz` return 200, `doctor` reports `database.ok = true`,
`encryption_key_set = true`, `production_problems` empty, and the ledger reconciliation lists
`inconsistent: 0`. The installer prints `administrator sign-in verified` when it confirmed the login
itself.

## 2a. Containers, VPS images without systemd, and re-runs

Some hosts (Docker/LXC/OpenVZ containers, minimal cloud images) have no working systemd and do not
start `apt`-installed services. The installer handles this:

```bash
# PostgreSQL is not running (the classic error):
#   psql: error: connection to server on socket "/var/run/postgresql/.s.PGSQL.5432" failed
sudo pg_ctlcluster 17 main start      # or: sudo service postgresql start
pg_isready                            # must print "accepting connections"
sudo bash deployment/linux/install.sh # now re-runs cleanly

# no systemd at all: let the installer use the process launcher
sudo bash deployment/linux/install.sh --no-systemd
/opt/nexa-ai/deployment/linux/nexa-services.sh {start|stop|restart|status|logs|keepalive}
```

On a systemd-less host there is no `Restart=always`, so the installer schedules the launcher in
cron instead — `nexa-services.sh keepalive` every two minutes plus an `@reboot` line — and installs
`cron` itself when the image does not ship it. That is what brings the API and the worker back by
themselves after a crash or a host reboot. Verify it at any time with:

```bash
crontab -l | grep nexa-keepalive        # the two scheduled lines
sudo pkill -f 'uvicorn app.main:app'    # simulate a crash
sleep 120 && curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8000/healthz
```

Re-running the installer is the upgrade path: it re-copies the code, keeps `.env` and the database
password, re-applies migrations and restarts the services. It never deletes `data/`, `uploads/` or
`backups/`.

**Automatic `.env` repair.** A file left over from an earlier version — or copied from
`deployment/.env.production.example`, which targets Docker — is brought up to date instead of blocking
the install. The installer rewrites, each time with a warning and a timestamped backup
(`.env.bak.<UTC>`):

| Found | Repaired to |
| --- | --- |
| `NEXA_SECRET_KEY` / `NEXA_ENCRYPTION_KEY` empty, shorter than 16 characters, or containing `CHANGE_ME` | a fresh random secret (rotating the encryption key means provider credentials must be re-entered) |
| `NEXA_BOOTSTRAP_ADMIN_PASSWORD=CHANGE_ME…` | a strong random password; the existing account is then reset to it (audited, sessions revoked) |
| `NEXA_TRUSTED_HOSTS=*` | the host's real addresses + `localhost`, `127.0.0.1` (a wildcard is refused in production) |
| `NEXA_DATABASE_URL` with `@db:5432` or a placeholder password | the local PostgreSQL with the installed credentials |
| `NEXA_UPLOAD_DIR=/app/uploads`, `NEXA_FRONTEND_DIST_DIR=/app/frontend/dist` | `<app dir>/uploads`, `<app dir>/frontend/dist` |
| `NEXA_REDIS_URL=redis://redis:6379/0` | `redis://127.0.0.1:6379/0` |
| `NEXA_PUBLIC_BASE_URL` / `NEXA_CORS_ORIGINS` with `CHANGE_ME_SERVER_IP` | the real `http://<ip>:<port>` |
| `KEY=value   # note` (inline comment) | `KEY=value` — pydantic reads the comment literally and refuses to start |

Use `--reset-env` to discard the file completely (a backup is kept) and `--reset-admin-password` to
re-point an existing administrator account at the password stored in `.env`.

Also: the installer extends `PATH` with `/usr/sbin:/sbin` (nginx, ufw and the `pg_ctl*` tools live
there, which a minimal `sudo env PATH=…` environment does not include).

## 2b. Domain and HTTPS (mode 2)

Everything below is automated by `--access domain`; this is what happens and how to verify it.

1. **DNS first.** Add an A record for your domain pointing at the server's public address. The
   installer checks resolution and reports it:

   ```bash
   dig +short ai.example.com        # must print your server's public IPv4
   ```

2. **Run the installer** (it will install certbot itself when packages are allowed):

   ```bash
   sudo bash deployment/linux/install.sh --access domain --domain ai.example.com \
        --acme-email you@example.com
   ```

   With DNS in place and port 80 reachable, the installer issues the certificate with
   `certbot --nginx`, switches the site to `deployment/nginx/nexa-domain-https.conf`, and flips the
   application to `NEXA_DEPLOYMENT_MODE=domain_https` with `NEXA_COOKIE_SECURE=true` and
   `NEXA_HSTS_ENABLED=true` — the plain-HTTP warning in the UI disappears at that moment, because
   the deployment really is encrypted.

   If DNS is not ready yet, nothing pretends otherwise: the domain serves plain HTTP, the UI keeps
   its warning, and the installer prints the exact certbot command to run later. Re-run the same
   installer command afterwards and it switches to HTTPS by itself.

3. **Verify** (all of these are also run by the installer):

   ```bash
   curl -I https://ai.example.com/                     # 200 + strict-transport-security
   curl -I http://ai.example.com/                      # 301 -> https://
   curl -s https://ai.example.com/readyz               # {"status":"ready",...}
   curl -s https://ai.example.com/api/v1/auth/config | grep deployment_mode
   # certificate chain and expiry
   echo | openssl s_client -connect ai.example.com:443 -servername ai.example.com 2>/dev/null | openssl x509 -noout -subject -issuer -enddate
   # TLS 1.0/1.1 must be refused (the template enables TLSv1.2 + TLSv1.3 only)
   curl --tls-max 1.1 -sI https://ai.example.com/ || echo "refused, as expected"
   ```

4. **nginx version compatibility.** The HTTPS vhost is written in the portable form
   (`listen 443 ssl http2;`), which nginx 1.24 — the version Ubuntu 24.04 ships — accepts. On
   nginx 1.25.1+ the installer rewrites it to the modern two-line form (`listen 443 ssl;` +
   `http2 on;`) so no deprecation warning is logged. Either way `nginx -t` must succeed before the
   site is enabled; if it does not, the installer keeps the previous vhost and tells you.

5. **Renewal** is installed as a daily cron job (`certbot renew --quiet --deploy-hook 'systemctl
   reload nginx'`) when certbot is present. Check it any time:

   ```bash
   sudo certbot renew --dry-run
   ```

6. **A self-signed certificate** (for a rehearsal, or an internal CA) is detected and reported as
   such: the installer verifies the TLS endpoint without chain validation, prints that visitors will
   get a browser warning, and tells you to run certbot before sharing the URL. It never calls a
   self-signed setup "HTTPS ready".

7. **Ports.** HTTPS needs inbound TCP 80 (issuance + renewal + redirect) and 443. Open them in the
   host firewall and in the cloud security group:

   ```bash
   sudo ufw allow 80/tcp && sudo ufw allow 443/tcp
   ```

Mode 1 (public IP, no domain) remains the fastest way to let others test the app; the difference is
only the lack of transport encryption, and the UI says so on every page until you switch.

## 3. Firewall

```bash
sudo ufw allow OpenSSH
sudo ufw allow 8080/tcp        # or 80,443 behind a domain
sudo ufw enable
sudo ufw status verbose        # 5432 and 6379 must NOT be listed
```

Cloud providers (AWS, GCP, Hetzner, …) also need the port opened in their security group.

## 3a. The install finished, but the printed URL does not open in a browser

The installer verifies the address it prints and says which case you are in:

| Summary line | Meaning |
| --- | --- |
| `[verified: answers from another machine]` | the address answered; the link is safe to share |
| `[NOT reachable from another machine yet]` | the app is healthy (health check **and** admin sign-in passed) but the browser→port path is closed |
| `[not checked]` | you passed `--no-public-check` |

**Most common cause: this host does not own a public IPv4.** If `hostname -I` shows `10.x`,
`172.16-31.x`, `192.168.x`, `100.64.x` (CGNAT) or `169.254.x`, the machine is inside a private
network — a container, an LXC/VPS image, a cloud instance, a datacentre NAT. A browser outside must
connect to the **public** address, which belongs to the router/cloud, so nothing you change on this
host helps until inbound TCP is forwarded/1:1-mapped to it.

```bash
# which layer is closed, and the exact command to open it:
sudo bash /opt/nexa-ai/deployment/linux/check_public_access.sh --port 8080
# exit 0 = reachable · 3 = nothing answered · 4 = the outside address could not be tested
```

| Layer | How to check | How to open |
| --- | --- | --- |
| the port on this host | `sudo ss -ltnp \| grep 8080` must show `0.0.0.0:8080`, not `127.0.0.1:8080` | re-run the installer (its Nginx site binds every address) |
| the host firewall | `sudo ufw status verbose`, `sudo firewall-cmd --list-ports` | `sudo ufw allow 8080/tcp`, or `sudo firewall-cmd --add-port=8080/tcp --permanent && sudo firewall-cmd --reload` |
| NAT / cloud security group | the checker reports *the public address did not answer* | add an inbound `TCP 8080` rule to the security group / port-forward in the cloud panel |

If you do own a public address and it still fails:

* Browsers silently upgrade `http` to `https` (Chrome: *Always use secure connections*) — type the
  URL with an explicit `http://` **and** the port. On the HTTPS attempt the browser says
  *"This site can't provide a secure connection"*: that is the trap, not a broken install.
* Test from a different machine: `curl -v http://<public-ip>:8080/readyz` → `HTTP/1.1 200` proves the
  path is open.
* Behind NAT with no way to forward? An SSH reverse tunnel (`ssh -R 8080:127.0.0.1:8080 user@vps`),
  a Cloudflare Tunnel, or installing on a host that owns a public address. See §8 and
  `docs/PRODUCTION_DEPLOYMENT.md` for the domain + HTTPS route.

A closed port does **not** fail the installation: `http://127.0.0.1:8080` on the server keeps working
and the installer exits 0 — a blocked port is a network problem, not an install failure.

## 4. Docker Compose route

```bash
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker "$USER" && newgrp docker
git clone <repo-url> nexa-ai && cd nexa-ai
cp deployment/.env.production.example .env    # set POSTGRES_PASSWORD, secrets, admin account
docker compose up -d --build
docker compose ps
```

Services: `db` (PostgreSQL, not published), `redis`, `api`, `worker`, `web` (Nginx, publishes
`${PUBLIC_PORT}:80`). Upgrade with `git pull && docker compose up -d --build`.

## 5. systemd units

| Unit | Command | Notes |
| --- | --- | --- |
| `nexa-api.service` | `uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 2 --proxy-headers --forwarded-allow-ips=127.0.0.1` | binds loopback only; Nginx terminates client connections |
| `nexa-worker.service` | `python -m app.workers.worker` | one process per worker; scale by adding units |

Both use `EnvironmentFile=/opt/nexa-ai/.env`, `Restart=always` and the sandboxing directives
`NoNewPrivileges`, `PrivateTmp`, `ProtectSystem=full`, `ProtectHome`.

```bash
sudo systemctl restart nexa-api nexa-worker
sudo journalctl -u nexa-api -f
```

## 6. Scheduled maintenance

Install `deployment/linux/nexa-backup.cron` (nightly backup at 02:30, weekly verification at 03:15 on
Sundays):

```bash
sudo crontab -e      # paste the two lines from the file
```

Add housekeeping (expiring files and lapsed subscriptions) too:

```cron
*/30 * * * * cd /opt/nexa-ai/backend && /opt/nexa-ai/venv/bin/python -m app.cli maintenance >> /var/log/nexa-maintenance.log 2>&1
```

## 7. Uninstall

```bash
sudo systemctl disable --now nexa-api nexa-worker
sudo rm /etc/systemd/system/nexa-{api,worker}.service
sudo rm /etc/nginx/sites-enabled/nexa-ai /etc/nginx/sites-available/nexa-ai
sudo systemctl daemon-reload && sudo systemctl reload nginx
sudo -u postgres dropdb nexa && sudo -u postgres dropuser nexa
sudo rm -rf /opt/nexa-ai          # ⚠️ deletes uploads and backups stored there
```

Take a backup first, and prove it restores with `sudo bash scripts/restore_drill.sh` ([`BACKUP_RESTORE.md`](BACKUP_RESTORE.md)).
