# Known limitations

An honest list of what is **not** implemented, **not** verified in this environment, or deliberately
left to the operator. Nothing here is presented elsewhere as working.

## 1. Not implemented (by design or out of scope)

| Area | Status | Notes |
| --- | --- | --- |
| Automated subscription checkout | not implemented | Plans exist, quotas are enforced and credits are posted, but activation is an administrator action (`POST /api/v1/admin/billing/subscriptions`). No self-service renewals or dunning emails. |
| Payment gateway live flow | implemented, not verifiable here | Stripe and Zarinpal adapters plus webhook signature checks exist; without real credentials and a public webhook URL the live round-trip cannot be exercised. A `success` redirect is never treated as proof of payment. |
| Automated refunds to a payment provider | not implemented | Refunds are recorded as compensating ledger entries by an administrator; money is returned outside the platform. |
| Mobile app | not implemented | Responsive web UI only. No iOS/Android client and no binaries are produced. |
| Desktop installer / native package | not implemented | Installation is via scripts (Windows `.bat`, Ubuntu `install.sh`) or Docker. No `.exe`/`.msi`/`.deb` artefact is built or shipped. |
| Built-in TLS termination | not implemented | HTTPS is provided by Nginx + certbot. The whole path *is* rehearsed end to end (SPA + API + HSTS + TLS floor + secure cookies + HTTP→HTTPS redirect, with a self-signed certificate that the installer detects and reports as self-signed). What has **not** been done here: issue a real certificate from a public CA — that needs a domain pointing at the host, which this sandbox does not have. |
| Multi-tenancy / organisations | not implemented | Single tenant with per-user accounts, roles and quotas. |
| Fine-grained per-user model catalogues | partially | `restricted` tier + grants cover the common cases; there is no visual catalogue editor per customer. |
| Automatic model quality evaluation | not implemented | Administrators run manual tests and see latency/cost/errors; there is no benchmark harness or A/B routing. |
| Model routing / fallback chains | not implemented | A request uses the chosen model; no automatic cross-provider failover. Provider `priority` only orders selections in the UI. |
| Federated / SSO login | not implemented | Local accounts (email + password). OIDC/SAML are not wired. |
| Email delivery guarantee | depends on SMTP | With `NEXA_EMAIL_ENABLED=false` (default) verification/reset links are logged/queued instead of sent. |
| Object storage (S3) for uploads | not implemented | Files live on the local disk volume; back that volume up. |
| Horizontal sharding / read replicas | not implemented | A single PostgreSQL primary; scale vertically or with a managed database. |
| Code execution sandbox | deliberately absent | The coding module generates code but never executes it (a stated requirement). |

## 2. Implemented but not verified in this environment

| Item | Why it is unverified | How to verify it yourself |
| --- | --- | --- |
| Docker images / Compose stack | no Docker daemon in the build environment | `docker compose up -d --build`, then `python -m pytest tests/deployment -q` and a manual smoke test |
| Installer repair paths for *hand-written* `.env` files | the shipped templates and the common leftovers are covered by executed tests; unusual hand-edited files are not | keep a copy of a working `.env`, or use `--reset-env` |
| Windows installers | no Windows host available | run `deployment\windows\install.bat` on Windows and follow `docs/INSTALL_WINDOWS.md`; the questions, the mode-dependent `.env`, the firewall rule and the `start.bat` binding are pinned by `tests/deployment/test_installer_choice.py` but have not been executed on Windows |
| A real Let's Encrypt certificate | this sandbox has no domain pointing at it | the installer issues one automatically (`--access domain --domain … --acme-email …`); the surrounding mechanism (Nginx template, ACME path, mode switch, renewal cron, `curl --resolve` verification) is executed and green — see docs/TEST_REPORT.md §1 row 44 |
| Ubuntu installer on distributions other than Debian 13 | executed end to end on Debian 13 (systemd and launcher modes); the script targets Debian/Ubuntu generally | run it on Ubuntu 22.04/24.04 and report issues |
| Redis-backed rate limiting across **multiple replicas** | the Redis backend itself is now verified live (10 × 401 then 429, keys in `nexa:rl:*`) and the fallback path was exercised with Redis stopped; a *two-replica* load test was not run | run the API with 2+ workers and confirm the shared counter still produces `429`s |
| PostgreSQL-specific behaviour | verified: the full suite (137) was run against PostgreSQL 17 and the installed stack was exercised end to end on it | — |
| Live provider traffic (OpenAI/Anthropic/…) | **now executed** against a real, paid OpenAI-compatible endpoint (`https://inference.dahl.global/v1`, three models) — 18/18 steps of `tests/tools/real_provider_check.py`: connection test, sync, priced, admin verification test, publish, a user's manual payment approved by an admin, a real completion, a real SSE stream, usage rows and ledger entries. Other vendors (Anthropic Messages, Gemini, Replicate, Stability, …) were **not** exercised with live keys | configure your own provider under Admin → Providers and run `NEXA_REAL_BASE_URL=… NEXA_REAL_API_KEY=… python3 tests/tools/real_provider_check.py …` |
| Payment gateway round-trips | needs merchant accounts, webhooks and a public URL | configure `gateway_stripe_*` / `gateway_zarinpal_*`, complete a test payment, confirm a webhook is required to credit |
| Malware scanning | `clamav` is not installed here | install a scanner, set `NEXA_MALWARE_SCAN_ENABLED=true` and `NEXA_MALWARE_SCAN_COMMAND`, upload EICAR |
| Email flows (verification/reset) | no SMTP server | set the SMTP keys, enable email, register a user and complete the verification loop |
| Video generation | requires a provider that supports it (e.g. Replicate) | configure the provider, verify the model with an admin test, then submit a job |
| Backup/restore on PostgreSQL | **now executed** — `scripts/backup.sh` + `scripts/restore_drill.sh` against PostgreSQL 17 on the installed host (tables/users/ledger restored, API booted on the restored data, ledger reconciled) | for your own host: `sudo bash scripts/restore_drill.sh` after a backup |
| The external reachability check (`deployment/linux/check_public_access.sh`) | runs **on the server**, so it reports what that host can observe: no answer proves the port is closed, but a successful probe from the host is not proof for every other network (routers without NAT hairpinning). It cannot distinguish a missing port-forward from a cloud security-group rule — it prints both. Its public-IP branch is covered by unit tests with a stubbed network because this sandbox has no inbound path to test through | `bash /opt/nexa-ai/deployment/linux/check_public_access.sh --port 8080` on the server, then `curl -v http://<public-ip>:8080/readyz` from another machine |
| Cloud provider firewalls / NAT mappings | outside the project's reach: security groups (AWS, GCP, Azure, Oracle, Hetzner, OVH, …), floating IPs and home routers must be configured by the operator | apply the rule the checker prints, then re-run it and test from a second machine |
| Telegram bot with a **real** bot token | **now executed**: the platform's own `POST /api/v1/admin/telegram/test` returned the live `getMe` (`@Signal_RRPlusbot`) and the polling worker consumed updates from the real Bot API (a competing `getUpdates` call gets `409 Conflict`, which proves the platform holds the stream). A full authenticated conversation needs a human to send `/start <link code>` from Telegram (that send cannot be scripted without a real Telegram account) | on your server: set the token, restart, Press **Admin → Settings → Telegram → Test**, then link your own Telegram from Profile → Telegram |
| Cloud development workspace (GitHub Codespaces / Gitpod / dev container) | the workspace scripts (`deployment/codespaces/setup.sh`, `start.sh`) were **executed here** end to end, including a stranger registering through the link; what cannot be verified from this sandbox is a real forwarded `*.app.github.dev` URL and the org-level policy that decides whether a forwarded port may be made public | in your own workspace: run setup + start, then `gh codespace ports visibility 8080:public -c "$CODESPACE_NAME"` and open the printed URL from a second device |
| Command palette keyboard support on mobile browsers | the palette is opened from the topbar button on touch devices (Ctrl/⌘ K is a desktop shortcut); its keyboard handling was verified in desktop Chromium | open it on a phone with the search button in the top bar and use the on-screen keyboard |
| Browser-level UI tests | the development sandbox has Chromium via `puppeteer-core` and runs the scripted sweeps (`tests/tools/browser/check-admin-pages.cjs`, `check-model-dialog.cjs`: 34 route×viewport combinations, console/network errors, overflow, dialog controls); the *shipped* project still has no Playwright suite, so interaction coverage lives in those scripts plus the API contract tests | `tests/e2e` covers the served SPA, assets, headers and API; add Playwright for interaction tests |
| Load/performance testing | out of scope for this environment | use `locust`/`k6` against `/api/v1/chat/completions` with a mock or real provider |

## 3. Behavioural notes operators should know

1. **Unpriced models charge nothing.** If neither `selling_*` nor `provider_cost_*` is configured, the
   charge is recorded as `0` and the response carries an `unpriced` warning. Usage still appears in
   reports.
2. **An untested model is unusable.** `availability: untested` blocks user traffic
   (`reason: model_not_verified`) until an administrator runs a test — there is no "force enable".
3. **`free` tier models are paid for by the operator.** Their usage is recorded with
   `billed_to_user: false`; they still consume provider quota and show up in cost reports.
4. **Deleting a provider removes its models** from the catalogue. Historic usage rows keep the
   provider id so reports stay coherent, but the catalogue entry is gone.
5. **Rotating `NEXA_ENCRYPTION_KEY` invalidates stored provider credentials.** Re-enter them; the API
   reports an explicit decryption error rather than silently failing over.
6. **Changing `NEXA_COOKIE_SECURE`/`NEXA_HSTS_ENABLED` logs everyone out.** Users must sign in again.
7. **Plain-HTTP public-IP mode is intentionally insecure.** The warning is part of the API response and
   the UI; do not treat it as production-ready.
8. **SQLite is development-only.** Production refuses it unless explicitly overridden
   (`NEXA_ALLOW_SQLITE_IN_PRODUCTION=true`), and concurrent writes in SQLite are serialised.
9. **Rate limits are per process** without Redis. Run one API process, or enable Redis, before scaling
   out.
10. **Job workers are pull-based.** A crashed worker's lease expires after
    `NEXA_JOB_LEASE_SECONDS` and the job is retried up to `NEXA_JOB_MAX_ATTEMPTS` times; there is no
    central scheduler UI for cron-like jobs.
11. **`admin_model_tests` bypass user restrictions by design** but never bypass provider
    authentication and never publish a model; the platform budget
    (`NEXA_ADMIN_TEST_DAILY_LIMIT_MICRO`) is the guard-rail.
12. **Uploads are scanned only if you install a scanner.** Without one,
    `malware_scan_status` is reported as `disabled` in the file metadata rather than a fake "clean".

## 3b. Interface-language coverage (round 11, measured)

The four dictionaries (`en`, `fa`, `ar`, `ckb`) carry **436 keys** each — the type is a closed union,
so a missing translation is a compile error — and the shell, navigation, dialogs, tables and every
screen under **Admin →** are translated. What is *not* translated everywhere yet, counted by reading
the source with a literal scan in this round:

| Surface | English literals still hard-coded |
| --- | --- |
| Workspace pages (28 files) | ≈210 unique strings: `DataAnalysis` 23, `Images` 15, `Audio` 14, `Security` 14, `Billing`/`Documents`/`ModelDetail`/`Payments`/`Translation` 11 each, `Chat`/`ResetPassword` 10, … They are field labels, empty states and explanatory sentences, not functionality: the pages work, and the strings that *matter* for access (why a model is locked, the exact refusal code) already come from the translated `access.*` keys. |
| Admin pages | 0 after round 11 |

Catalogue values that are deliberately left in English in every language: provider/model ids,
capability slugs, access-tier and availability enum values, and HTTP header names — they are the
exact identifiers the API stores and the gateway enforces, and translating them would make a screenshot
useless for support. `site.testing_notice` / `site.security_warning` are **operator-written** settings
(Admin → Settings), so their language is the operator's choice, not the platform's.

## 4. Compatibility notes

| Item | Note |
| --- | --- |
| Python | 3.11–3.13 (developed and tested on 3.13). **3.14+ is not supported**: the pinned `pydantic-core` has no wheel for it and would need a Rust toolchain. The installer detects this, selects a supported interpreter, and points at the Docker route otherwise. |
| Node.js | 20 LTS used for the production build; 18 may work but is untested |
| PostgreSQL | 15/16 expected; earlier versions lack some JSON/index features used by migrations |
| Browsers | current Chrome/Edge/Firefox/Safari; the UI relies on `fetch`, `EventSource`-style streaming and CSS custom properties |
| Windows | scripted install is supported; the Docker path needs WSL2 |
13. **A workspace is a test deployment, not production.** `deployment/codespaces/setup.sh`
   configures SQLite, generated secrets and `NEXA_ALLOW_DEV_HOSTS=true` because a forwarded URL changes on
   every rebuild. Move to `deployment/linux/install.sh` (PostgreSQL + Nginx + HTTPS) before real users.
14. **`NEXA_ALLOWED_REGISTRATION_MODES` narrows what the console may select — it does not
   create invitations.** With `invite_only` in the list the registration policy can be switched to
   invite-only from Admin → Settings, and only then does an account need an invitation token.
15. **`NEXA_ALLOW_DEV_HOSTS=true` accepts any host name ending in the known workspace
   suffixes** (`.app.github.dev`, `.gitpod.io`, `.e2b.app`, …). It exists so a rebuild cannot lock the owner
   out of their own app; on a server with a fixed address set it to `false` and list the host in
   `NEXA_TRUSTED_HOSTS` instead.
16. **Sharing a forwarded port means making it public.** A private Codespaces port answers only
   to the account that owns the workspace, so a friend opening the link sees an error page — that is GitHub's
   setting, not the platform's.
