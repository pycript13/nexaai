# Installing on Windows

Supported on Windows 10/11 and Windows Server 2019+ with either the built-in scripts (SQLite for
evaluation, PostgreSQL for production) or Docker Desktop. Full manual:
[`RAHNAMA.md`](RAHNAMA.md) / [`INSTALLATION_GUIDE.md`](INSTALLATION_GUIDE.md).

## 1. Prerequisites

| Software | Version | Notes |
| --- | --- | --- |
| Python | 3.11+ | tick **Add Python to PATH** in the installer |
| Node.js | 20 LTS | needed to build `frontend/dist` |
| PostgreSQL | 16 | required for production; SQLite is evaluation-only |
| Git / 7-Zip | current | to fetch and unpack the project |

Run everything from an **elevated** Command Prompt (`Win+X` → *Terminal (Admin)*).

## 2. Install

```bat
cd C:\path\to\nexa-ai
deployment\windows\install.bat
```

**The installer asks you three things** (nothing is decided for you):

```
Who should be able to open the application?
   [1] only this PC (default)      [2] other machines on my network / the Internet
*** SECURITY WARNING ***   (when you choose 2)
Public mode serves the application over PLAIN HTTP on a reachable address. Traffic —
including passwords and session cookies — is NOT encrypted. Use it for testing only.
Port to publish [8000]:
Detected address: 192.168.1.20          (or your public IP when the machine has one)
Administrator e-mail [admin@example.com]:
Administrator display name [Nexa Administrator]:
Password (min 10 chars):                (typing is hidden; Enter alone generates a strong one)
```

* **Choice 2 (public)** finds the address other machines should use (public IP first, otherwise the
  LAN address), writes `NEXA_DEPLOYMENT_MODE=public_ip`, the base URL, the port, the trusted hosts
  and the CORS origins into `.env`, adds the Windows firewall rule for that port, and prints both
  the local URL and the address to hand to other people. `start.bat` then binds `0.0.0.0` on that
  port, so simply starting the app keeps it reachable.
* **Choice 1 (default)** keeps everything on `127.0.0.1` — `start.bat` binds loopback only and
  nothing is exposed. `start_public.bat` still exists for a one-off exposure.
* If other machines still cannot open the URL, it is one of: the firewall rule (the installer adds
  it for the chosen port), or a router/NAT in front of the PC — see
  [`REMOTE_TESTING.md`](REMOTE_TESTING.md). A `192.168.…`/`10.…`/`172.…` address is your own network
  only; the Internet needs a public IP from your provider.
* **Administrator credentials** are yours to choose; the password is read with a hidden prompt and
  never printed back. Press Enter instead to have a strong one generated and stored in `.env`.
  Later, `deployment\windows\set_admin.bat` creates or updates the main administrator (e-mail,
  display name, password) and keeps `.env` in sync.
* Re-running `install.bat` over an existing installation keeps `.env` (data and passwords intact)
  and tells you how to change the access mode or the administrator if you want to.

Steps performed: verify Python/Node → create `.venv` → `pip install -r backend\requirements.txt` →
generate `.env` with `NEXA_SECRET_KEY`, `NEXA_ENCRYPTION_KEY` and a random
`NEXA_BOOTSTRAP_ADMIN_PASSWORD` → build the SPA → `alembic upgrade head` → `app.cli bootstrap` →
firewall rule for TCP 8000 → desktop shortcuts.

The generated `.env` uses SQLite (`sqlite:///C:/nexa-ai/data/nexa.db`) and `NEXA_ENVIRONMENT=development`.
Switching to production:

```bat
:: create the database (psql as postgres)
CREATE ROLE nexa LOGIN PASSWORD 'strong-password';
CREATE DATABASE nexa OWNER nexa ENCODING 'UTF8';
```

```ini
; .env
NEXA_ENVIRONMENT=production
NEXA_DATABASE_URL=postgresql+psycopg2://nexa:strong-password@127.0.0.1:5432/nexa
NEXA_PUBLIC_BASE_URL=http://YOUR-SERVER-IP:8000
NEXA_DEPLOYMENT_MODE=public_ip
```

```bat
cd backend
..\.venv\Scripts\python.exe -m alembic upgrade head
..\.venv\Scripts\python.exe -m app.cli bootstrap
```

## 3. Running

| Script | Purpose |
| --- | --- |
| `start.bat` | API + worker in two windows, opens `http://127.0.0.1:8000` |
| `start_public.bat` | API on `0.0.0.0:8000`; prints your LAN IP and the plain-HTTP warning |
| `start_worker.bat` | worker only |
| `backup.bat` | database copy/`pg_dump` + `uploads` archive into `backups\` |
| `diagnose.bat` | `app.cli doctor` plus a health probe |
| `install_service.bat [--scheduler]` | install as a Windows service (NSSM if present, else Task Scheduler) |
| `uninstall_service.bat` | remove services/tasks and the firewall rule |

## 4. Service mode

```bat
deployment\windows\install_service.bat
```

* With `nssm.exe` on `PATH` (or in the project root) the installer registers `NexaAIAPI` and
  `NexaAIWorker` services with automatic restart and log files under `logs\`.
* Otherwise it creates Task Scheduler entries `NexaAIAPI` / `NexaAIWorker` that start at boot.
  Task Scheduler does not restart crashed processes — use NSSM for real production.

Validate: `sc query NexaAIAPI`, `schtasks /query /tn NexaAIAPI`, `netstat -ano | findstr :8000`.

## 5. Backups on Windows

`backup.bat` reads `NEXA_DATABASE_URL`/`NEXA_UPLOAD_DIR` from `.env` and writes
`backups\nexa-sqlite-<stamp>.db` (or `nexa-pg-<stamp>.dump` via `pg_dump`) plus
`nexa-uploads-<stamp>.zip`. Restore by stopping the API, replacing `data\nexa.db` (or
`pg_restore --clean --dbname=...`), restoring the archive and re-running `diagnose.bat`. See
[`BACKUP_RESTORE.md`](BACKUP_RESTORE.md).

## 6. Common Windows issues

| Symptom | Fix |
| --- | --- |
| `python` not recognised | reinstall Python with *Add to PATH*, or use `py -3` |
| `npm` not recognised | install Node.js 20 LTS and reopen the terminal |
| build fails compiling wheels | install "Microsoft C++ Build Tools" (VS Build Tools) |
| port 8000 in use | `netstat -ano \| findstr :8000` then `taskkill /PID <pid> /F` |
| firewall blocks remote access | `netsh advfirewall firewall add rule name="Nexa AI API" dir=in action=allow protocol=TCP localport=8000` |
| `.env` uses backslashes | use forward slashes (`C:/nexa-ai/uploads`) |
| service starts then stops | check `logs\api-error.log`; usually a missing `NEXA_ENCRYPTION_KEY` or a wrong `NEXA_DATABASE_URL` |

Remember: plain HTTP on a public IP is unencrypted. Use it for short-lived testing and prefer the
domain + HTTPS path ([`PRODUCTION_DEPLOYMENT.md`](PRODUCTION_DEPLOYMENT.md)).
