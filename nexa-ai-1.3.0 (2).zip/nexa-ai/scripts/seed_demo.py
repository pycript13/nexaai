#!/usr/bin/env python3
"""Seed *optional* demo data (a demo user and a disabled sample provider).

This script intentionally does NOT create fake AI answers or fake payments. It only
creates clearly-labelled sample rows so a fresh installation can show a populated UI.

Usage: python3 scripts/seed_demo.py [--with-provider]
"""
from __future__ import annotations

import argparse
import datetime as dt
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))

from sqlalchemy import select  # noqa: E402

from app.core.crypto import hash_password  # noqa: E402
from app.core.logging import configure_logging  # noqa: E402
from app.db.session import SessionLocal, check_database  # noqa: E402
from app.models.provider import Provider  # noqa: E402
from app.models.user import User  # noqa: E402
from app.services import bootstrap as bootstrap_service  # noqa: E402
from app.services import providers as provider_service  # noqa: E402

DEMO_EMAIL = "demo.user@example.com"
DEMO_PASSWORD = "Demo-User-Passw0rd!"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--with-provider", action="store_true", help="also create a disabled OpenAI-compatible provider placeholder")
    args = parser.parse_args()

    configure_logging("INFO")
    check_database()
    with SessionLocal() as db:
        bootstrap_service.run_bootstrap(db, create_admin=False)
        user = db.scalars(select(User).where(User.email == DEMO_EMAIL)).first()
        if user is None:
            user = User(
                email=DEMO_EMAIL,
                display_name="Demo User",
                is_test_account=True,
                password_hash=hash_password(DEMO_PASSWORD),
                status="active",
                email_verified=True,
                email_verified_at=dt.datetime.now(dt.timezone.utc),
                locale="fa",
                theme="system",
                password_changed_at=dt.datetime.now(dt.timezone.utc),
            )
            db.add(user)
            db.commit()
            print(f"created demo user {DEMO_EMAIL}")
        else:
            print(f"demo user already exists: {DEMO_EMAIL}")

        if args.with_provider:
            existing = provider_service.slugify("demo-openai-compatible")
            if db.scalars(select(Provider).where(Provider.slug == existing)).first() is None:
                provider_service.create_provider(
                    db, actor=None,
                    data={
                        "name": "Demo provider (disabled)",
                        "provider_type": "openai_compatible",
                        "base_url": "https://api.openai.com/v1",
                        "enabled": False,
                        "description": "Placeholder created by seed_demo.py. Add real credentials and enable it deliberately.",
                    },
                )
                print("created a DISABLED demo provider — enable it only with real credentials")
    print("done")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
