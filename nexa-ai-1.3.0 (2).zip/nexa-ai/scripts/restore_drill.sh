#!/usr/bin/env bash
# Nexa AI — the restore drill, automated.
#
#   sudo bash scripts/restore_drill.sh                 # newest dump in backups/
#   sudo bash scripts/restore_drill.sh backups/nexa-pg-20260101T023000Z.dump
#   sudo bash scripts/restore_drill.sh --keep          # leave the scratch database behind
#
# Why a script instead of the manual recipe that used to live in the docs: the manual steps are
# order- and role-sensitive in ways that *look* successful but leave a broken result.
#
#   * `createdb nexa_drill` run as the wrong user makes the scratch database (and, on PostgreSQL
#     15+, the `public` schema) owned by that user. `pg_restore --no-owner` then creates every
#     table for that user as well, and the application role gets
#     `permission denied for table permissions` when a throw-away API is started against it.
#     The drill therefore creates the database **owned by the application role** and restores
#     **as that role**, exactly like a production restore.
#   * A dump restored but never *used* proves nothing: this script boots a real API against the
#     restored data, checks /readyz, signs the bootstrap administrator in and runs
#     `app.cli doctor` so the ledger has to reconcile.
#
# SQLite backups are supported too (the file is copied into a scratch directory and the API is
# pointed at it), which makes the drill usable on a laptop install as well.
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=lib_env.sh
. "${ROOT_DIR}/scripts/lib_env.sh"

KEEP=0
FILE=""
BACKUP_DIR="${ROOT_DIR}/backups"
PORT="${DRILL_PORT:-8099}"
STATE_DIR=""
API_PID=""
SCRATCH_DB=""

usage() {
  sed -n '2,20p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
  exit 0
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --keep) KEEP=1; shift ;;
    --port) PORT="$2"; shift 2 ;;
    -h|--help) usage ;;
    *) FILE="$1"; shift ;;
  esac
done

log()  { printf '[drill] %s\n' "$*"; }
fail() { printf '[drill] FAIL: %s\n' "$*" >&2; exit 1; }

cleanup() {
  if [[ -n "${API_PID}" ]] && kill -0 "${API_PID}" 2>/dev/null; then
    kill "${API_PID}" 2>/dev/null || true
    wait "${API_PID}" 2>/dev/null || true
  fi
  if [[ -n "${SCRATCH_DB}" && "${KEEP}" -eq 0 ]]; then
    sudo -u postgres dropdb --if-exists "${SCRATCH_DB}" >/dev/null 2>&1 || true
  fi
  [[ -n "${STATE_DIR}" && "${KEEP}" -eq 0 ]] && rm -rf "${STATE_DIR}"
  return 0
}
trap cleanup EXIT

nexa_env_load "${ROOT_DIR}/.env" NEXA_DATABASE_URL NEXA_UPLOAD_DIR NEXA_BOOTSTRAP_ADMIN_EMAIL \
  NEXA_BOOTSTRAP_ADMIN_PASSWORD NEXA_ENVIRONMENT NEXA_PUBLIC_BASE_URL NEXA_SECRET_KEY
DATABASE_URL="${NEXA_DATABASE_URL:-sqlite:///${ROOT_DIR}/data/nexa.db}"
ADMIN_EMAIL="${NEXA_BOOTSTRAP_ADMIN_EMAIL:-admin@example.com}"
ADMIN_PASSWORD="${NEXA_BOOTSTRAP_ADMIN_PASSWORD:-}"

[[ -n "${FILE}" ]] || FILE="$(ls -t "${BACKUP_DIR}"/nexa-pg-*.dump "${BACKUP_DIR}"/nexa-sqlite-*.db 2>/dev/null | head -1 || true)"
[[ -n "${FILE}" && -f "${FILE}" ]] || fail "no backup found — run scripts/backup.sh first (or pass a file)"

STATE_DIR="$(mktemp -d)"
[[ -f "${ROOT_DIR}/venv/bin/python" ]] && PYTHON="${ROOT_DIR}/venv/bin/python" || PYTHON="$(command -v python3)"
[[ -n "${PYTHON}" ]] || fail "no python interpreter found (expected venv/bin/python or python3)"

# Never print credentials: the URL embeds the database password.
redacted() { printf '%s' "${1}" | sed -E 's#(://[^:/@]+):[^@]*@#\1:***@#'; }

log "backup under test : ${FILE}"
log "live database     : $(redacted "${DATABASE_URL}")"
log "scratch API port  : ${PORT}"

if [[ "${FILE}" == *.dump ]]; then
  # ---------------------------------------------------------------- PostgreSQL drill ----------
  command -v pg_restore >/dev/null 2>&1 || fail "pg_restore is not installed"

  URL="$(printf '%s' "${DATABASE_URL}" | sed -E 's#^(postgres(ql)?)\+[A-Za-z0-9_]+://#\1://#')"
  [[ "${URL}" == postgres* ]] || fail "a .dump backup belongs to PostgreSQL but NEXA_DATABASE_URL is not PostgreSQL"

  # user:password@host:port/database — the scratch database must be owned by the application role
  AUTHORITY="${URL#*://}"; AUTHORITY="${AUTHORITY%%/*}"
  [[ "${AUTHORITY}" == *@* ]] || fail "NEXA_DATABASE_URL has no credentials; cannot determine the database role"
  USERINFO="${AUTHORITY%@*}"      # everything before the last @
  DB_ROLE="${USERINFO%%:*}"       # everything before the first colon
  DB_PASSWORD=""
  [[ "${USERINFO}" == *:* ]] && DB_PASSWORD="${USERINFO#*:}"
  DRILL_DB="nexa_drill_$(date -u +%H%M%S)"
  SCRATCH_DB="${DRILL_DB}"
  DRILL_URL="${URL%/*}/${DRILL_DB}"
  [[ -n "${DB_ROLE}" && -n "${DB_PASSWORD}" ]] || fail "could not parse the database role/password from NEXA_DATABASE_URL"

  log "creating the scratch database '${DRILL_DB}' owned by '${DB_ROLE}' (ownership is what makes the difference)"
  if [[ "$(id -u)" -eq 0 ]] && id postgres >/dev/null 2>&1; then
    sudo -u postgres createdb -O "${DB_ROLE}" "${DRILL_DB}" || fail "could not create the scratch database"
    sudo -u postgres psql -d "${DRILL_DB}" -tAc "GRANT ALL ON SCHEMA public TO \"${DB_ROLE}\"; ALTER SCHEMA public OWNER TO \"${DB_ROLE}\";" >/dev/null
  else
    createdb -O "${DB_ROLE}" "${DRILL_DB}" || fail "could not create the scratch database (run as root, or create it yourself)"
  fi

  log "restoring as the application role"
  PGPASSWORD="${DB_PASSWORD}" pg_restore --no-owner --no-privileges --no-password \
    --dbname="${DRILL_URL}" "${FILE}" 2>&1 | tail -5 || true

  log "checking that every table is readable by ${DB_ROLE}"
  TABLES="$(PGPASSWORD="${DB_PASSWORD}" psql --no-password -tAc \
    "SELECT count(*) FROM information_schema.tables WHERE table_schema='public'" "${DRILL_URL}")" \
    || fail "the restored database is not reachable as ${DB_ROLE}"
  [[ "${TABLES}" -gt 10 ]] || fail "only ${TABLES} tables were restored"
  LEDGER_ROWS="$(PGPASSWORD="${DB_PASSWORD}" psql --no-password -tAc "SELECT count(*) FROM credit_ledger" "${DRILL_URL}")" \
    || fail "the restored database has no credit_ledger table that ${DB_ROLE} can read"
  USERS="$(PGPASSWORD="${DB_PASSWORD}" psql --no-password -tAc "SELECT count(*) FROM users" "${DRILL_URL}")"
  log "restored: tables=${TABLES} users=${USERS} credit_ledger_rows=${LEDGER_ROWS}"
  DRILL_ENV_DB="postgresql+psycopg2://${DB_ROLE}:${DB_PASSWORD}@${DRILL_URL#*@}"
else
  # ---------------------------------------------------------------------- SQLite drill ---------
  cp "${FILE}" "${STATE_DIR}/drill.db"
  mkdir -p "${STATE_DIR}/uploads"
  DRILL_ENV_DB="sqlite:///${STATE_DIR}/drill.db"
  log "copied the SQLite backup into ${STATE_DIR}/drill.db"
fi

log "starting a throw-away API against the restored data on 127.0.0.1:${PORT}"
(
  cd "${ROOT_DIR}/backend"
  NEXA_DATABASE_URL="${DRILL_ENV_DB}" \
  NEXA_ENVIRONMENT=development \
  NEXA_DEPLOYMENT_MODE=local \
  NEXA_SECRET_KEY="${NEXA_SECRET_KEY:-drill-secret-key-0123456789abcdefghij}" \
  NEXA_UPLOAD_DIR="${STATE_DIR}/uploads" \
  NEXA_PUBLIC_BASE_URL="http://127.0.0.1:${PORT}" \
  NEXA_TRUSTED_HOSTS="127.0.0.1,localhost" \
  nohup "${PYTHON}" -m uvicorn app.main:app --host 127.0.0.1 --port "${PORT}" \
    > "${STATE_DIR}/api.log" 2>&1 &
  echo $! > "${STATE_DIR}/api.pid"
)
API_PID="$(cat "${STATE_DIR}/api.pid")"

READY=0
for _ in $(seq 1 30); do
  if curl -fsS --max-time 5 "http://127.0.0.1:${PORT}/readyz" >/dev/null 2>&1; then READY=1; break; fi
  sleep 2
done
if [[ "${READY}" -ne 1 ]]; then
  tail -20 "${STATE_DIR}/api.log" >&2 || true
  fail "the API did not become ready against the restored database"
fi
log "API ready against the restored database (/readyz answered)"

if [[ -n "${ADMIN_PASSWORD}" ]]; then
  COOKIE_JAR="${STATE_DIR}/cookies.txt"
  CSRF="$(curl -fsS -c "${COOKIE_JAR}" "http://127.0.0.1:${PORT}/api/v1/health" >/dev/null 2>&1; \
          awk '/nexa_csrf/ {print $7}' "${COOKIE_JAR}" | tail -1)"
  CODE="$(curl -s -o "${STATE_DIR}/login.json" -w '%{http_code}' -b "${COOKIE_JAR}" -c "${COOKIE_JAR}" \
    -H 'content-type: application/json' -H "x-csrf-token: ${CSRF}" \
    -d "{\"email\":\"${ADMIN_EMAIL}\",\"password\":\"${ADMIN_PASSWORD}\"}" \
    "http://127.0.0.1:${PORT}/api/v1/auth/login")"
  [[ "${CODE}" == "200" ]] || fail "sign-in against the restored database failed (HTTP ${CODE})"
  log "administrator sign-in against the restored data: 200"
else
  log "WARNING: NEXA_BOOTSTRAP_ADMIN_PASSWORD is not in .env — sign-in step skipped"
fi

log "ledger reconciliation + configuration check on the restored data"
DOCTOR_OUT="$(cd "${ROOT_DIR}/backend" && \
  NEXA_DATABASE_URL="${DRILL_ENV_DB}" NEXA_ENVIRONMENT=development NEXA_DEPLOYMENT_MODE=local \
  NEXA_SECRET_KEY="${NEXA_SECRET_KEY:-drill-secret-key-0123456789abcdefghij}" \
  "${PYTHON}" -m app.cli doctor 2>&1 || true)"
printf '%s\n' "${DOCTOR_OUT}" | grep -iE "inconsistent|accounts_checked|dialect" | sed 's/^/[drill]   /' || true
if printf '%s' "${DOCTOR_OUT}" | grep -q '"inconsistent": [1-9]'; then
  fail "the restored database does not reconcile (see the doctor output above)"
fi
if printf '%s' "${DOCTOR_OUT}" | grep -qi "traceback"; then
  fail "app.cli doctor crashed against the restored database"
fi

echo
log "PASS — the backup restores into a usable database: tables readable as ${DB_ROLE:-the app role},"
log "        the API boots against it, ${ADMIN_EMAIL} signs in, and the ledger reconciles."
[[ "${KEEP}" -eq 1 && -n "${SCRATCH_DB}" ]] && log "scratch database kept: ${SCRATCH_DB} (drop it with: sudo -u postgres dropdb ${SCRATCH_DB})"
log "record the date and this result in docs/BACKUP_RESTORE.md §7 (retention/off-site policy)"
