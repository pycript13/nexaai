#!/usr/bin/env python3
"""Create or promote an administrator account.

Usage:
    python3 scripts/create_admin.py --email admin@example.com --password '...' [--role super_admin]

* Validates the password against the platform policy.
* Never prints the password back.
* Records an audit entry (the API does this automatically for in-app changes).
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))

from app.db.session import SessionLocal, check_database  # noqa: E402
from app.core.config import settings  # noqa: E402
from app.services import bootstrap as bootstrap_service  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Create or promote a Nexa AI administrator")
    parser.add_argument("--email", required=True)
    parser.add_argument("--password", required=True, help="the account password (never echoed)")
    parser.add_argument("--name", default="")
    parser.add_argument("--role", default="super_admin", help="role slug to assign (default: super_admin)")
    args = parser.parse_args()

    if len(args.password) < settings.password_min_length:
        print(f"Password must be at least {settings.password_min_length} characters.", file=sys.stderr)
        return 2

    check_database()
    with SessionLocal() as db:
        result = bootstrap_service.ensure_super_admin(db, email=args.email, password=args.password, name=args.name)
        if not result.get("created"):
            # the deployment already has an administrator: promote the requested account instead
            from app.models.user import Role, User
            from sqlalchemy import select

            user = db.scalars(select(User).where(User.email == args.email.lower())).first()
            role = db.scalars(select(Role).where(Role.slug == args.role)).first()
            if user is None:
                print(f"No account with email {args.email}. "
                      f"(Existing administrator: {result.get('email') or 'unknown'}; reason: {result.get('reason')})",
                      file=sys.stderr)
                return 3
            if role is None:
                print(f"Unknown role '{args.role}'.", file=sys.stderr)
                return 4
            if role not in user.roles:
                user.roles.append(role)
                db.commit()
            result = {"email": user.email, "created": False, "role_added": role.slug}
    print(f"Administrator ready: {result.get('email')} (created={result.get('created')})")
    print("Sign in and change the password immediately if this account was created by an installer.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
