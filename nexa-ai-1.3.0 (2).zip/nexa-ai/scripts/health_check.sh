#!/usr/bin/env bash
# Nexa AI — check that a running deployment answers on its health endpoints.
#
# Usage: scripts/health_check.sh [base-url]   (default: NEXA_PUBLIC_BASE_URL or http://127.0.0.1:8000)
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=lib_env.sh
. "${ROOT_DIR}/scripts/lib_env.sh"
nexa_env_load "${ROOT_DIR}/.env" NEXA_PUBLIC_BASE_URL NEXA_PUBLIC_PORT NEXA_ENVIRONMENT
BASE="${1:-${NEXA_PUBLIC_BASE_URL:-http://127.0.0.1:8000}}"
BASE="${BASE%/}"

fail=0
check() {
  local path="$1"; local label="$2"
  if curl -fsS --max-time 10 "${BASE}${path}" >/tmp/nexa-health.json 2>/dev/null; then
    printf '  ok   %-28s %s\n' "${label}" "$(head -c 160 /tmp/nexa-health.json)"
  else
    printf '  FAIL %-28s (%s%s)\n' "${label}" "${BASE}" "${path}"
    fail=1
  fi
}

echo "Nexa AI health check against ${BASE}"
check /healthz "liveness"
check /readyz "readiness"
check /api/v1/health "api health"
check /api/v1/health/deep "deep component check"
exit "${fail}"
