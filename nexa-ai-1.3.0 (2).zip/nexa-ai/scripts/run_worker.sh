#!/usr/bin/env bash
# Nexa AI — run the background job worker in the foreground (Docker/systemd use this too).
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}/backend"
exec python3 -m app.workers.worker "$@"
