#!/usr/bin/env bash
# Nexa AI — restore a backup into the configured database.
#
# Usage: scripts/restore.sh <backup-file> [--yes] [--uploads <tar.gz>]
#
# SAFETY: refuses to run unless the service is stopped (no running API process) and
# the operator passes --yes, because restoring overwrites the live database.
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FILE="${1:-}"
CONFIRM=0
UPLOAD_ARCHIVE=""

shift || true
while [[ $# -gt 0 ]]; do
  case "$1" in
    --yes) CONFIRM=1; shift ;;
    --uploads) UPLOAD_ARCHIVE="$2"; shift 2 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
done

[[ -n "${FILE}" && -f "${FILE}" ]] || { echo "Usage: $0 <backup-file> [--yes] [--uploads file.tar.gz]" >&2; exit 2; }

# Parsed, never sourced — see scripts/lib_env.sh for why (`source` on a value with a space aborts
# the script under `set -e`; the shipper's own .env contains `NEXA_APP_NAME=Nexa AI`).
# shellcheck source=lib_env.sh
. "${ROOT_DIR}/scripts/lib_env.sh"
nexa_env_load "${ROOT_DIR}/.env" NEXA_DATABASE_URL NEXA_UPLOAD_DIR NEXA_ENVIRONMENT

# libpq (pg_dump/pg_restore) does not understand SQLAlchemy dialect suffixes such as
# `postgresql+psycopg2://`. Passing the raw URL made libpq fall back to the local socket and the
# operating-system user ("FATAL: role \"root\" does not exist") — a PostgreSQL backup that failed
# although the application connects perfectly. Strip the driver part before handing it over.
libpq_url() {
  printf '%s' "${1}" | sed -E 's#^(postgres(ql)?)\+[A-Za-z0-9_]+://#\1://#'
}

DATABASE_URL="${NEXA_DATABASE_URL:-sqlite:///${ROOT_DIR}/data/nexa.db}"
UPLOAD_DIR="${NEXA_UPLOAD_DIR:-${ROOT_DIR}/uploads}"

log() { printf '[restore] %s\n' "$*"; }

if [[ "${CONFIRM}" -ne 1 ]]; then
  echo "Refusing to restore without --yes. This operation replaces the live database: ${DATABASE_URL}" >&2
  exit 3
fi

"${ROOT_DIR}/scripts/verify_backup.sh" "${FILE}"

if pgrep -f "uvicorn app.main:app" >/dev/null 2>&1; then
  echo "The API is still running. Stop it first (systemctl stop nexa-api / docker compose stop api)." >&2
  exit 4
fi

if [[ "${DATABASE_URL}" == postgres* ]]; then
  command -v pg_restore >/dev/null 2>&1 || { echo "pg_restore is required" >&2; exit 1; }
  log "cleaning and restoring PostgreSQL database"
  pg_restore --clean --if-exists --no-owner --no-privileges --no-password \
    --dbname="$(libpq_url "${DATABASE_URL}")" "${FILE}"
else
  DB_PATH="${DATABASE_URL#sqlite:///}"; DB_PATH="${DB_PATH#sqlite://}"
  mkdir -p "$(dirname "${DB_PATH}")"
  [[ -f "${DB_PATH}" ]] && cp "${DB_PATH}" "${DB_PATH}.pre-restore.$(date -u +%Y%m%dT%H%M%SZ)"
  log "restoring SQLite database to ${DB_PATH}"
  cp "${FILE}" "${DB_PATH}"
fi

if [[ -n "${UPLOAD_ARCHIVE}" && -f "${UPLOAD_ARCHIVE}" ]]; then
  log "restoring uploads"
  mkdir -p "$(dirname "${UPLOAD_DIR}")"
  tar -xzf "${UPLOAD_ARCHIVE}" -C "$(dirname "${UPLOAD_DIR}")"
fi

log "restore finished. Run 'scripts/health_check.sh' after starting the API."
