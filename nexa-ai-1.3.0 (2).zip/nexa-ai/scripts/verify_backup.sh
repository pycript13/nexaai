#!/usr/bin/env bash
# Nexa AI — verify that a backup file is readable and structurally sound.
#
# Usage: scripts/verify_backup.sh <path-to-backup>
#   * SQLite  -> runs PRAGMA integrity_check + counts the core tables
#   * pg dump -> runs pg_restore --list to confirm the archive is readable
set -Eeuo pipefail

FILE="${1:-}"
if [[ -z "${FILE}" || ! -f "${FILE}" ]]; then
  echo "Usage: $0 <backup-file>" >&2
  exit 2
fi

log() { printf '[verify] %s\n' "$*"; }

case "${FILE}" in
  *.db)
    command -v sqlite3 >/dev/null 2>&1 || { echo "sqlite3 is required to verify SQLite backups" >&2; exit 1; }
    RESULT="$(sqlite3 "${FILE}" 'PRAGMA integrity_check;')"
    [[ "${RESULT}" == "ok" ]] || { echo "integrity_check failed: ${RESULT}" >&2; exit 1; }
    TABLES="$(sqlite3 "${FILE}" "SELECT count(*) FROM sqlite_master WHERE type='table';")"
    USERS="$(sqlite3 "${FILE}" "SELECT count(*) FROM users;" 2>/dev/null || echo 0)"
    # the immutable ledger table is `credit_ledger` (the ORM class is LedgerEntry) —
    # a stale name here silently reported "ledger_entries=0" for every backup
    LEDGER="$(sqlite3 "${FILE}" "SELECT count(*) FROM credit_ledger;" 2>/dev/null || echo "?")"
    if [[ "${LEDGER}" == "?" ]]; then
      log "WARNING: the backup has no credit_ledger table — it predates the billing schema or is not a Nexa AI database"
    fi
    log "integrity ok · tables=${TABLES} · users=${USERS} · credit_ledger=${LEDGER}"
    ;;
  *.dump|*.sql)
    if command -v pg_restore >/dev/null 2>&1; then
      pg_restore --list "${FILE}" >/dev/null
      log "pg_restore could read the archive ($(wc -l < <(pg_restore --list "${FILE}")) objects)"
    else
      log "pg_restore not installed; skipping structural check"
    fi
    ;;
  *)
    log "unknown backup extension; only checking that the file is non-empty"
    [[ -s "${FILE}" ]] || { echo "backup file is empty" >&2; exit 1; }
    ;;
esac

log "backup verified: ${FILE}"
