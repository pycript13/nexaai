#!/usr/bin/env bash
# Nexa AI — safe readers for the project's dotenv file.
#
# Why this file exists: `backup.sh`, `restore.sh` and `health_check.sh` used to load `.env` with
# `set -a; source .env`. That executes the file through the shell, and the installer writes
# `NEXA_APP_NAME=Nexa AI` — an unquoted value with a space. The shell then tries to run `AI`, the
# command is not found, and under `set -e` the script aborts with exit 127 *before doing anything*:
# no backup, no restore, no health check, on every installation the installer itself produced.
# Sourcing a user-editable file is unsafe anyway (values may contain `$(...)`, spaces, `#`, quotes).
#
# These helpers parse the file the way python-dotenv and systemd do: `KEY=value`, optional
# surrounding quotes (stripped), optional `export ` prefix, `#` comments, blank lines.
#
# Usage:
#   . "$(dirname "$0")/lib_env.sh"
#   DB_URL="$(nexa_env_value "${ROOT_DIR}/.env" NEXA_DATABASE_URL)"

# shellcheck shell=bash

# nexa_env_value <file> <KEY>  -> prints the value (empty when the key is absent)
nexa_env_value() {
  local file="$1" key="$2" line value
  [[ -n "${file}" && -r "${file}" ]] || return 0
  # `|| true`: a missing key is not an error, and grep exits 1 when nothing matches.
  line="$(grep -E "^[[:space:]]*(export[[:space:]]+)?${key}[[:space:]]*=" "${file}" 2>/dev/null | tail -n 1 || true)"
  [[ -n "${line}" ]] || return 0
  value="${line#*=}"
  # strip one trailing CR (a .env edited on Windows), then surrounding whitespace
  value="${value%$'\r'}"
  value="${value#"${value%%[![:space:]]*}"}"
  value="${value%"${value##*[![:space:]]}"}"
  # strip matching surrounding quotes and no inline comments (the app's parser keeps `#` inside values)
  case "${value}" in
    \"*\") value="${value#\"}"; value="${value%\"}" ;;
    \'*\') value="${value#\'}"; value="${value%\'}" ;;
  esac
  printf '%s' "${value}"
}

# nexa_env_load <file> [VAR ...] -> exports the named variables (all NEXA_* when none is given).
# Never evaluates the file: only whitelisted keys are read, one at a time.
nexa_env_load() {
  local file="$1"; shift || true
  [[ -n "${file}" && -r "${file}" ]] || return 0
  local keys=("$@")
  if [[ ${#keys[@]} -eq 0 ]]; then
    while IFS= read -r key; do keys+=("${key}"); done < <(
      grep -oE "^[[:space:]]*(export[[:space:]]+)?NEXA_[A-Z0-9_]+" "${file}" \
        | sed -E 's/^[[:space:]]*(export[[:space:]]+)?//' | sort -u
    )
  fi
  local key value
  for key in "${keys[@]}"; do
    [[ "${key}" =~ ^[A-Z_][A-Z0-9_]*$ ]] || continue
    value="$(nexa_env_value "${file}" "${key}")"
    [[ -n "${value}" ]] || continue
    export "${key}=${value}"
  done
}
