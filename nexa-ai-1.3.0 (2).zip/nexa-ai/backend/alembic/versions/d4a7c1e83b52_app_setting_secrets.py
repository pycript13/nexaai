"""app_settings.is_secret — runtime-editable **secret** settings

Round 12.  Until now every credential had to live in the environment file: the operator
edited `/opt/nexa-ai/.env`, restarted the service, and only then could the Telegram bot be
connected.  The Telegram screen of the admin panel therefore had no field for the bot token
at all.

This revision adds one boolean to ``app_settings``.  Rows flagged ``is_secret`` hold a Fernet
ciphertext (``NEXA_ENCRYPTION_KEY``) instead of a plain JSON value, are never returned by the
API, and are only readable by the service that consumes them.  Nothing is migrated: an
existing installation simply has no secret settings yet, and the environment values keep
working exactly as before (the database is consulted first, the environment is the fallback).

Revision ID: d4a7c1e83b52
Revises: c7d41b0f9a13
"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "d4a7c1e83b52"
down_revision = "c7d41b0f9a13"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    columns = {column["name"] for column in inspector.get_columns("app_settings")}
    if "is_secret" not in columns:
        op.add_column(
            "app_settings",
            sa.Column("is_secret", sa.Boolean(), nullable=False, server_default=sa.false()),
        )
    link_columns = {column["name"] for column in inspector.get_columns("telegram_links")}
    if "verified_via" not in link_columns:
        op.add_column(
            "telegram_links",
            sa.Column("verified_via", sa.String(length=16), nullable=False, server_default="code"),
        )


def downgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    columns = {column["name"] for column in inspector.get_columns("app_settings")}
    if "is_secret" in columns:
        op.drop_column("app_settings", "is_secret")
    link_columns = {column["name"] for column in inspector.get_columns("telegram_links")}
    if "verified_via" in link_columns:
        op.drop_column("telegram_links", "verified_via")
