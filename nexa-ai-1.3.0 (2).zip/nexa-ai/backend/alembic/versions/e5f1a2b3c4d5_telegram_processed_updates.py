"""telegram_processed_updates — exactly-once claim per Telegram update

The production stack polls Telegram from more than one process (the API's inline
worker and the standalone worker), each holding its own in-memory offset. The same
update could therefore be fetched — and answered — twice. This table is the shared
claim: the first process to insert an update_id owns it, everyone else skips it.

Revision ID: e5f1a2b3c4d5
Revises: d4a7c1e83b52
"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "e5f1a2b3c4d5"
down_revision = "d4a7c1e83b52"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    if "telegram_processed_updates" not in inspector.get_table_names():
        op.create_table(
            "telegram_processed_updates",
            sa.Column("update_id", sa.BigInteger(), primary_key=True),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        )


def downgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    if "telegram_processed_updates" in inspector.get_table_names():
        op.drop_table("telegram_processed_updates")
