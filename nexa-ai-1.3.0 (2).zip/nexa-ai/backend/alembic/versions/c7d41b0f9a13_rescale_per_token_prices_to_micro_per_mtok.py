"""rescale per-token pricing rules to micro-credits per million tokens

Before this revision the per-token columns of ``pricing_rules`` were read as *micro-credits
per token*, which is numerically the same as *credits per million tokens* — but stored in
units so coarse that any price below one credit per MTok rounded to ``0``.

That is exactly the class of price a real provider has (DeepSeek, GPT-4o-mini, Gemini
Flash are all between 0.02 and 1 credit per MTok at ``NEXA_CREDIT_USD_RATE=1.0``), so every
such model was silently billed **free**: the usage record kept ``charged_micro=0`` and no
ledger entry was written.

This revision keeps the *effective* price of every existing rule and moves the unit to
micro-credits per 1,000,000 tokens (the same number an operator types: ``0.28`` becomes
``280000``). The scaling factor is the 1,000,000 micro-credits in one credit — the same
figure that converts a whole-credit price between the two units.

Only the six per-token columns of ``pricing_rules`` change: the flat columns
(``per_request_micro``, ``per_image_micro``, ``per_audio_minute_micro``, ``per_job_micro``)
were always plain micro-credits, and model prices live on the ``models`` table in *credits
per million tokens* (a decimal column), which the service now scales at read time.
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa

revision = 'c7d41b0f9a13'
down_revision = 'a1ce3c4bf50b'
branch_labels = None
depends_on = None

SCALE = 1_000_000

PER_TOKEN_COLUMNS = (
    "input_per_mtok_micro",
    "output_per_mtok_micro",
    "provider_input_per_mtok_micro",
    "provider_output_per_mtok_micro",
)


def upgrade() -> None:
    rules = sa.table(
        "pricing_rules",
        sa.column("input_per_mtok_micro", sa.BigInteger),
        sa.column("output_per_mtok_micro", sa.BigInteger),
        sa.column("provider_input_per_mtok_micro", sa.BigInteger),
        sa.column("provider_output_per_mtok_micro", sa.BigInteger),
    )
    connection = op.get_bind()
    for column in PER_TOKEN_COLUMNS:
        connection.execute(
            sa.text(
                f"UPDATE pricing_rules SET {column} = {column} * :scale "  # noqa: S608 - fixed column list
                f"WHERE {column} IS NOT NULL AND {column} <> 0"
            ),
            {"scale": SCALE},
        )
    # A stored 0 meant "free", which stays 0 in the new unit — leave those rows alone.
    del rules  # the table object documents the touched columns for readers


def downgrade() -> None:
    connection = op.get_bind()
    for column in PER_TOKEN_COLUMNS:
        connection.execute(
            sa.text(
                f"UPDATE pricing_rules SET {column} = {column} / :scale "  # noqa: S608 - fixed column list
                f"WHERE {column} IS NOT NULL AND {column} <> 0"
            ),
            {"scale": SCALE},
        )
