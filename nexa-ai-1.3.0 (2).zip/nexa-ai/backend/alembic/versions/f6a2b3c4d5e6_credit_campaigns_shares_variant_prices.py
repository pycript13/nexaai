"""credit campaigns, conversation shares, per-variant prices

Revision ID: f6a2b3c4d5e6
Revises: e5f1a2b3c4d5
"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "f6a2b3c4d5e6"
down_revision = "e5f1a2b3c4d5"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "credit_campaigns",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("title", sa.String(length=160), nullable=False),
        sa.Column("kind", sa.String(length=24), nullable=False, server_default="bonus"),
        sa.Column("cadence", sa.String(length=16), nullable=False, server_default="once"),
        sa.Column("amount_micro", sa.BigInteger(), nullable=False),
        sa.Column("target_type", sa.String(length=16), nullable=False, server_default="all"),
        sa.Column("target_ref", sa.JSON(), nullable=True),
        sa.Column("reason", sa.String(length=400), nullable=False, server_default=""),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("starts_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("ends_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("next_run_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_run_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("runs_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("total_granted_micro", sa.BigInteger(), nullable=False, server_default="0"),
        sa.Column("total_recipients", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("created_by_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="SET NULL"), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_credit_campaigns_due", "credit_campaigns", ["active", "next_run_at"])
    op.create_index("ix_credit_campaigns_active", "credit_campaigns", ["active"])
    op.create_index("ix_credit_campaigns_next_run_at", "credit_campaigns", ["next_run_at"])

    op.create_table(
        "credit_campaign_runs",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("campaign_id", sa.Integer(), sa.ForeignKey("credit_campaigns.id", ondelete="CASCADE"), nullable=False),
        sa.Column("run_key", sa.String(length=64), nullable=False),
        sa.Column("recipients", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("granted_micro", sa.BigInteger(), nullable=False, server_default="0"),
        sa.Column("skipped", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("triggered_by_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="SET NULL"), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.UniqueConstraint("campaign_id", "run_key", name="uq_campaign_run_key"),
    )
    op.create_index("ix_credit_campaign_runs_campaign_id", "credit_campaign_runs", ["campaign_id"])

    op.create_table(
        "conversation_shares",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("conversation_id", sa.Integer(), sa.ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False),
        sa.Column("owner_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("shared_with_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=True),
        sa.Column("token", sa.String(length=64), nullable=True),
        sa.Column("permission", sa.String(length=16), nullable=False, server_default="view"),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("revoked_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_accessed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.UniqueConstraint("token", name="uq_conversation_share_token"),
    )
    op.create_index("ix_conversation_shares_with", "conversation_shares", ["shared_with_id", "revoked_at"])
    op.create_index("ix_conversation_shares_conversation", "conversation_shares", ["conversation_id", "revoked_at"])
    op.create_index("ix_conversation_shares_conversation_id", "conversation_shares", ["conversation_id"])
    op.create_index("ix_conversation_shares_owner_id", "conversation_shares", ["owner_id"])
    op.create_index("ix_conversation_shares_shared_with_id", "conversation_shares", ["shared_with_id"])

    with op.batch_alter_table("model_variants") as batch:
        batch.add_column(sa.Column("selling_input_per_mtok", sa.Numeric(14, 6), nullable=True))
        batch.add_column(sa.Column("selling_output_per_mtok", sa.Numeric(14, 6), nullable=True))
        batch.add_column(sa.Column("selling_per_request", sa.Numeric(14, 6), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table("model_variants") as batch:
        batch.drop_column("selling_per_request")
        batch.drop_column("selling_output_per_mtok")
        batch.drop_column("selling_input_per_mtok")
    op.drop_table("conversation_shares")
    op.drop_table("credit_campaign_runs")
    op.drop_table("credit_campaigns")
