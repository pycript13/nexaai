"""A fresh archive install must be able to open its database.

The shipped archive cannot preserve the empty ``data/`` folder, so on a first
Codespaces/zip install nothing had created it and SQLite died with
``unable to open database file`` during migrations — the app never listened,
so the workspace had no port to forward. The application (and Alembic) now
create the parent directory themselves; this pins that behaviour.
"""
import sqlite3

from app.db.session import _ensure_sqlite_parent


def test_sqlite_parent_directory_is_created(tmp_path) -> None:
    target = tmp_path / "missing" / "nested" / "nexa.db"
    assert not target.parent.exists()
    _ensure_sqlite_parent(f"sqlite:///{target}")
    assert target.parent.is_dir()
    # and the file actually opens
    conn = sqlite3.connect(target)
    conn.execute("create table t (id integer)")
    conn.commit()
    conn.close()


def test_memory_and_non_sqlite_urls_are_untouched(tmp_path) -> None:
    _ensure_sqlite_parent("sqlite:///:memory:")
    _ensure_sqlite_parent("postgresql+psycopg2://user:pass@db:5432/nexa")
    assert list(tmp_path.iterdir()) == []
