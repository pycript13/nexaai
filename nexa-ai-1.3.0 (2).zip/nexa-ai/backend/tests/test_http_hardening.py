"""Response-hardening headers.

Two of them are security decisions an operator can legitimately need to change:

* the framing policy (`X-Frame-Options` by default, `NEXA_FRAME_ANCESTORS` to embed the app
  in a portal), and
* the fact that both policies must never be sent together — a browser that sees
  `X-Frame-Options` ignores `frame-ancestors`, which would silently break the allow-list.
"""
from __future__ import annotations

from fastapi.testclient import TestClient


def test_framing_is_refused_by_default(client: TestClient) -> None:
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.headers.get("x-frame-options") == "DENY", "clickjacking protection is missing"
    assert "frame-ancestors" not in (response.headers.get("content-security-policy") or "")


def test_frame_ancestors_setting_replaces_x_frame_options(client: TestClient, monkeypatch) -> None:
    from app.core.config import settings

    monkeypatch.setattr(settings, "frame_ancestors", "https://portal.example.com")
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.headers.get("content-security-policy") == "frame-ancestors https://portal.example.com;"
    assert "x-frame-options" not in response.headers, (
        "X-Frame-Options must not be sent together with frame-ancestors: the browser would ignore the allow-list"
    )


def test_embedding_allow_list_is_reported_as_a_deployment_warning(monkeypatch) -> None:
    from app.core.config import settings

    monkeypatch.setattr(settings, "frame_ancestors", "")
    assert not [w for w in settings.deployment_warnings() if "FRAME_ANCESTORS" in w]
    monkeypatch.setattr(settings, "frame_ancestors", "https://portal.example.com")
    warnings = [w for w in settings.deployment_warnings() if "FRAME_ANCESTORS" in w]
    assert warnings, "an operator who allows embedding must be told that protection is reduced"
    assert "portal.example.com" in warnings[0]


def test_basic_hardening_headers_are_always_present(client: TestClient) -> None:
    response = client.get("/healthz")
    for header, expected in (
        ("x-content-type-options", "nosniff"),
        ("referrer-policy", None),
        ("x-request-id", None),
    ):
        assert header in response.headers, f"{header} is missing"
        if expected:
            assert response.headers[header] == expected
