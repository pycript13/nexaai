"""Workspace storage quotas (MB + file count) and the forceable model probe.

The admin owns two storage settings — `files.user_quota_mb` and
`files.user_max_files` — and both are enforced at the single store point so
uploads and model-generated files count alike (receipts never block a user).
The probe's cached verdict can be bypassed with `force` so a user tapping the
latency badge gets a fresh answer instead of a stale one.
"""
import io
import json

import httpx

from app.services import settings_store
from tests.conftest import create_provider_and_model, grant_credits


def _upload(session, name: str, data: bytes = b"hello nexa"):  # noqa: ANN001, ANN202
    return session.post("/api/v1/files", files={"file": (name, io.BytesIO(data), "text/plain")})


def test_file_count_quota_is_enforced(db, user_client) -> None:
    settings_store.set_value(db, "files.user_max_files", 2)
    db.commit()
    try:
        assert _upload(user_client, "one.txt").status_code == 201
        assert _upload(user_client, "two.txt").status_code == 201
        third = _upload(user_client, "three.txt")
        assert third.status_code >= 400, third.text
        assert "limit" in third.text.lower(), third.text
        summary = user_client.get("/api/v1/files/storage/summary").json()
        assert summary["file_count"] == 2 and summary["max_files"] == 2, summary
    finally:
        settings_store.set_value(db, "files.user_max_files", 1000)
        db.commit()


def test_mb_quota_uses_the_admin_setting(db, user_client) -> None:
    settings_store.set_value(db, "files.user_quota_mb", 0)
    db.commit()
    try:
        blocked = _upload(user_client, "too-big-for-zero.txt", b"x" * 64)
        assert blocked.status_code >= 400, blocked.text
        assert "quota" in blocked.text.lower()
    finally:
        settings_store.set_value(db, "files.user_quota_mb", 2048)
        db.commit()


def test_probe_force_bypasses_the_cached_verdict(db, user_client, mock_provider_transport) -> None:
    calls = {"count": 0}

    def counting(request: httpx.Request) -> httpx.Response:
        calls["count"] += 1
        return httpx.Response(200, json={
            "id": "p",
            "choices": [{"message": {"role": "assistant", "content": "ok"}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 3, "completion_tokens": 1, "total_tokens": 4},
        })

    mock_provider_transport(counting)
    _provider, model = create_provider_and_model(db, published=True)
    grant_credits(db, user_client.email, 5.0)

    first = user_client.post(f"/api/v1/models/{model.id}/check").json()
    assert first["ok"] is True and first["cached"] is False
    after_first = calls["count"]
    second = user_client.post(f"/api/v1/models/{model.id}/check").json()
    assert second["cached"] is True and calls["count"] == after_first, "cached verdict must not re-hit the provider"
    forced = user_client.post(f"/api/v1/models/{model.id}/check?force=true").json()
    assert forced["cached"] is False and calls["count"] > after_first, "force must run a fresh probe"
