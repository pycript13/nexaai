"""The platform owner is not a customer (release round 10).

The operator's report was blunt: signed in as the super administrator, models said
*"your credit is not enough"*.  That is wrong twice over — the owner is the account that
pays the providers, so an empty balance is meaningless for them, and the commercial
switches (price, subscription tier, publication state) exist to shape what *users* may
buy, not to lock the owner out of their own deployment.

What is deliberately **not** bypassed, and is asserted here:

* a disabled provider or a disabled model — a disabled integration must never come back
  to life because the caller is an administrator;
* missing provider credentials — the run must still fail with a real configuration error
  instead of a fake answer;
* the platform-wide daily provider-spend cap — that one protects the deployment's real
  money at the provider, not a user's wallet;
* nothing about an owner run may publish, verify or otherwise mutate catalog state.

And what must stay true for everybody else is asserted too: a normal user with an empty
balance is still blocked, and the owner's runs are recorded for the books (price and
provider cost) **without** debiting any balance.
"""
from __future__ import annotations

import json

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.billing import UsageRecord
from app.models.user import User
from app.services import access as access_service
from app.services import ledger as ledger_service
from tests.conftest import AuthSession, create_provider_and_model


def _chat_ok(request: httpx.Request) -> httpx.Response:
    if request.url.path.endswith("/chat/completions"):
        return httpx.Response(
            200,
            json={
                "id": "c1",
                "model": "test-model-1",
                "choices": [
                    {"index": 0, "message": {"role": "assistant", "content": "pong"}, "finish_reason": "stop"}
                ],
                "usage": {"prompt_tokens": 6, "completion_tokens": 2, "total_tokens": 8},
            },
        )
    return httpx.Response(404, json={"error": {"message": "not found"}})


def _user(db: Session, email: str) -> User:
    user = db.scalars(select(User).where(User.email == email)).first()
    assert user is not None, f"user {email} not found"
    return user


def _chat(client: AuthSession, model_id: int, text: str = "ping"):
    return client.post("/api/v1/chat/completions", json={"model_id": model_id, "message": text})


# ------------------------------------------------------------------ the rule itself --


def test_the_owner_is_recognised_by_role_not_by_balance(admin_client: AuthSession, user_client: AuthSession, db: Session) -> None:
    assert access_service.is_platform_owner(_user(db, admin_client.email)) is True
    assert access_service.is_platform_owner(_user(db, user_client.email)) is False
    assert access_service.is_platform_owner(None) is False


def _fresh_owner(client, db: Session, email: str) -> AuthSession:
    """A brand-new super administrator, untouched by other tests' credit grants."""
    from app.core.crypto import hash_password
    from app.models.user import Role, User as UserModel

    role = db.scalars(select(Role).where(Role.slug == "super_admin")).first()
    assert role is not None, "bootstrap must have created the super_admin role"
    user = UserModel(email=email, display_name="Fresh Owner", password_hash=hash_password("Owner-Password-77"),
                     status="active", email_verified=True)
    user.roles = [role]
    db.add(user)
    db.commit()
    session = AuthSession(client, email, "Owner-Password-77")
    session.login()
    return session


def test_owner_runs_a_paid_model_with_an_empty_balance(client, db: Session, mock_provider_transport) -> None:
    mock_provider_transport(_chat_ok)
    owner_client = _fresh_owner(client, db, "fresh.owner@nexatest.io")
    owner = _user(db, owner_client.email)
    assert ledger_service.balance_of(db, owner.id) == 0, "a fresh owner starts with no credits at all"
    _, model = create_provider_and_model(db, display_name="Paid model", access_tier="credit")

    response = _chat(owner_client, model.id)
    assert response.status_code == 200, response.text
    assert response.json().get("text") or response.json().get("message")

    usage = db.scalars(
        select(UsageRecord).where(UsageRecord.model_id == model.id, UsageRecord.user_id == owner.id)
    ).first()
    assert usage is not None, "owner usage must still be recorded"
    assert usage.billed_to_user is False, "an owner run is never billed to a user balance"
    assert usage.charged_micro and usage.charged_micro > 0, "the price is still computed so the books are auditable"
    assert (usage.metadata_json or {}).get("billed_to_platform") is True
    assert ledger_service.balance_of(db, owner.id) == 0, "no ledger entry may be written for an owner run"

    from app.models.billing import LedgerEntry

    entries = db.scalars(select(LedgerEntry).where(LedgerEntry.user_id == owner.id)).all()
    assert entries == [], "a fresh owner must end the run with an untouched ledger"


def test_owner_catalog_entry_is_not_flagged_as_a_credit_problem(admin_client: AuthSession, db: Session) -> None:
    _, model = create_provider_and_model(db, display_name="Owner catalog model", access_tier="credit")
    listing = admin_client.get("/api/v1/models?page_size=100").json()["items"]
    entry = next(item for item in listing if item["id"] == model.id)
    assert entry["accessible"] is True
    assert entry["access_code"] == "owner_access"
    assert entry["access_code"] != "insufficient_balance"
    detail = admin_client.get(f"/api/v1/models/{model.id}").json()["access"]
    assert detail["allowed"] is True and detail["code"] == "owner_access"


def test_a_normal_user_with_no_credits_is_still_blocked(user_client: AuthSession, db: Session,
                                                        mock_provider_transport) -> None:
    mock_provider_transport(_chat_ok)
    _, model = create_provider_and_model(db, display_name="Paid model", access_tier="credit")
    response = _chat(user_client, model.id)
    assert response.status_code in (402, 403), response.text
    body = response.json()
    assert (body.get("error") or body).get("code") == "insufficient_balance" or "credit" in json.dumps(body).lower()


def test_a_user_with_credits_still_pays(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    """The owner bypass must not leak into normal accounts."""
    mock_provider_transport(_chat_ok)
    from tests.conftest import grant_credits

    grant_credits(db, user_client.email, 5.0)
    user = _user(db, user_client.email)
    _, model = create_provider_and_model(db, display_name="Paid model")
    before = ledger_service.balance_of(db, user.id)
    assert _chat(user_client, model.id).status_code == 200
    assert ledger_service.balance_of(db, user.id) < before, "a user run must still be charged"


# --------------------------------------------------------- what the owner may reach --


def test_owner_reaches_hidden_and_unpublished_models(admin_client: AuthSession, db: Session,
                                                     mock_provider_transport) -> None:
    mock_provider_transport(_chat_ok)
    _, hidden = create_provider_and_model(db, visibility="hidden", published=False, display_name="Hidden draft")
    _, internal = create_provider_and_model(db, access_tier="internal", display_name="Internal helper")

    for model in (hidden, internal):
        assert _chat(admin_client, model.id).status_code == 200, f"owner blocked on {model.display_name}"
        db.refresh(model)
        assert model.published is False or model.access_tier == "internal", "state must not be rewritten by a run"


def test_owner_is_not_blocked_by_a_restricted_model(admin_client: AuthSession, db: Session,
                                                    mock_provider_transport) -> None:
    mock_provider_transport(_chat_ok)
    _, restricted = create_provider_and_model(db, access_tier="restricted", display_name="Grant-only model")
    assert _chat(admin_client, restricted.id).status_code == 200


def test_owner_is_not_blocked_by_a_subscription_model(admin_client: AuthSession, db: Session,
                                                      mock_provider_transport) -> None:
    mock_provider_transport(_chat_ok)
    _, model = create_provider_and_model(db, access_tier="subscription", display_name="Subscribers only")
    assert _chat(admin_client, model.id).status_code == 200


def test_owner_can_exercise_an_unverified_model_without_verifying_it(admin_client: AuthSession, db: Session,
                                                                    mock_provider_transport) -> None:
    """An untested model stays untested: the owner may run it, nobody auto-verifies it."""
    mock_provider_transport(_chat_ok)
    _, model = create_provider_and_model(db, display_name="Freshly synced")
    model.availability = "untested"
    db.commit()

    assert _chat(admin_client, model.id).status_code == 200
    db.refresh(model)
    assert model.availability == "untested", "a normal run must not mark a model verified"
    assert model.published is False or model.id, "publication state must not change"


def test_an_unverified_model_stays_a_dead_end_for_users(user_client: AuthSession, db: Session,
                                                        mock_provider_transport) -> None:
    from tests.conftest import grant_credits

    mock_provider_transport(_chat_ok)
    grant_credits(db, user_client.email, 5.0)
    _, model = create_provider_and_model(db, display_name="Freshly synced")
    model.availability = "untested"
    db.commit()
    response = _chat(user_client, model.id)
    assert response.status_code in (403, 503), response.text
    assert "verified" in json.dumps(response.json()).lower() or "test" in json.dumps(response.json()).lower()


# ------------------------------------------------ what the owner must NOT bypass --


def test_a_disabled_provider_stays_disabled_for_the_owner(admin_client: AuthSession, db: Session,
                                                          mock_provider_transport) -> None:
    mock_provider_transport(_chat_ok)
    provider, model = create_provider_and_model(db, display_name="Provider off", provider_enabled=False)
    response = _chat(admin_client, model.id)
    assert response.status_code in (403, 503), response.text
    assert "disabled" in json.dumps(response.json()).lower()
    db.refresh(provider)
    assert provider.enabled is False, "the request must not silently re-enable a provider"


def test_a_disabled_model_stays_disabled_for_the_owner(admin_client: AuthSession, db: Session,
                                                       mock_provider_transport) -> None:
    mock_provider_transport(_chat_ok)
    _, model = create_provider_and_model(db, display_name="Model off", enabled=False)
    response = _chat(admin_client, model.id)
    assert response.status_code in (403, 503), response.text
    db.refresh(model)
    assert model.enabled is False


def test_owner_gets_a_real_configuration_error_when_credentials_are_missing(admin_client: AuthSession, db: Session) -> None:
    """No fake success: a provider without a key must still say exactly that."""
    provider, model = create_provider_and_model(db, display_name="No credentials")
    provider.api_key_encrypted = None
    db.commit()
    response = _chat(admin_client, model.id)
    assert response.status_code == 503, response.text
    assert "key" in json.dumps(response.json()).lower() or "credential" in json.dumps(response.json()).lower()


def test_owner_bypasses_user_level_limits_but_not_the_platform_cap(admin_client: AuthSession, db: Session,
                                                                   mock_provider_transport,
                                                                   monkeypatch) -> None:
    from app.core.config import settings
    from app.models.billing import UsageStatus

    mock_provider_transport(_chat_ok)
    owner = _user(db, admin_client.email)
    _, model = create_provider_and_model(db, display_name="Spend limited")

    # 1) a user-level quota set to zero does not stop the owner
    owner.quota_spend_micro_per_day = 1
    db.commit()
    assert _chat(admin_client, model.id).status_code == 200

    # 2) the platform-wide provider-spend cap still applies — it protects real money
    db.add(
        UsageRecord(
            user_id=owner.id,
            provider_id=model.provider_id,
            model_id=model.id,
            operation="chat",
            status=UsageStatus.SUCCEEDED,
            idempotency_key="platform-cap-probe",
            provider_cost_micro=400_000,
            charged_micro=0,
            billed_to_user=False,
        )
    )
    db.commit()
    monkeypatch.setattr(settings, "global_daily_spend_limit_micro", 100_000, raising=False)
    blocked = _chat(admin_client, model.id)
    assert blocked.status_code == 429, blocked.text
    assert "global" in json.dumps(blocked.json()).lower()


def test_owner_runs_do_not_appear_as_user_spend(admin_client: AuthSession, db: Session, mock_provider_transport) -> None:
    from app.services import usage as usage_service

    mock_provider_transport(_chat_ok)
    owner = _user(db, admin_client.email)
    _, model = create_provider_and_model(db, display_name="Not user spend")
    assert _chat(admin_client, model.id).status_code == 200
    assert usage_service.user_spend_today_micro(db, owner.id) == 0
    assert usage_service.user_spend_month_micro(db, owner.id) == 0
