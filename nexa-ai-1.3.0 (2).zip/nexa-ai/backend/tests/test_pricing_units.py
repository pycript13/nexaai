"""Unit tests for the money conversion rules (micro-credits everywhere).

The platform stores money as integer micro-credits (1 credit = 1 000 000 micro).
Per-token prices are stored as **micro-credits per 1 000 000 tokens** — the same number an
operator types in *credits per million tokens* (``0.28`` -> ``280000``) — while flat prices
(per request / image / audio minute / job) are plain micro-credits.

The scaling is not cosmetic. With the previous "micro-credits per token" convention a price
below one credit per million tokens — that is, *every* realistic model price — rounded to
``0`` and the platform billed the request as free while reporting success. These tests pin
the conversions, the per-token charge math and the provider-cost/markup derivation.
"""
from __future__ import annotations

from decimal import Decimal

from sqlalchemy.orm import Session

from app.services import pricing
from tests.conftest import create_provider_and_model


def _model(db: Session, **kwargs):  # noqa: ANN001, ANN202
    _, model = create_provider_and_model(db, **kwargs)
    return model


def test_per_mtok_credits_become_micro_credits_per_mtok(db: Session) -> None:
    model = _model(db, input_price=3.0, output_price=15.0)
    quote = pricing.resolve_price(db, model)
    assert quote.input_per_mtok_micro == 3_000_000, quote.input_per_mtok_micro
    assert quote.output_per_mtok_micro == 15_000_000
    # ... and the API still speaks in credits per million tokens
    assert pricing.micro_to_per_mtok_credits(quote.input_per_mtok_micro) == 3.0


def test_cheap_model_is_never_silently_free(db: Session) -> None:
    """Regression: 0.10 credits/MTok used to convert to 0 micro-credits -> free billing.

    DeepSeek/GPT-4o-mini class prices are all below one credit per million tokens, so the
    old conversion made the *entire* realistic price range free: the usage record kept
    ``charged_micro=0``, ``provider_cost_micro`` was inflated by 1e6, and no ledger entry
    was written. The charge for a 23-token call must be non-zero and exactly proportional.
    """
    model = _model(db, input_price=0.10, output_price=0.10)
    quote = pricing.resolve_price(db, model)
    assert quote.input_per_mtok_micro == 100_000, quote.input_per_mtok_micro
    assert quote.output_per_mtok_micro == 100_000

    # no minimum charge: the pure unit price must be visible
    quote.minimum_charge_micro = 0
    charge = pricing.compute_charge(quote, prompt_tokens=10, completion_tokens=13)
    # 10 * 0.1 + 13 * 0.1 = 2.3 micro-credits, rounded half-up per line item
    assert charge.charged_micro == 2, charge.charged_micro

    bigger = pricing.compute_charge(quote, prompt_tokens=1_000_000, completion_tokens=1_000_000)
    assert bigger.charged_micro == 100_000 + 100_000  # 0.1 + 0.1 credits


def test_fractional_prices_keep_full_precision(db: Session) -> None:
    """A 6-decimal price must survive the round trip, never truncate towards zero."""
    model = _model(db, input_price=None, output_price=None)
    model.selling_input_per_mtok = Decimal("0.281234")
    model.selling_output_per_mtok = Decimal("0.4")
    db.commit()
    quote = pricing.resolve_price(db, model)
    assert quote.input_per_mtok_micro == 281_234
    assert quote.output_per_mtok_micro == 400_000, "0.4 credits/MTok must not become 0"
    charge = pricing.compute_charge(quote, prompt_tokens=1_000_000, completion_tokens=1_000_000)
    assert charge.charged_micro == 281_234 + 400_000


def test_per_image_price_is_a_full_credit_amount(db: Session) -> None:
    """Regression: 0.25 credits per image used to become 0 micro-credits (free images)."""
    model = _model(db, input_price=None, output_price=None)
    model.selling_per_image = Decimal("0.25")
    db.commit()
    quote = pricing.resolve_price(db, model)
    assert quote.per_image_micro == 250_000, quote.per_image_micro

    charge = pricing.compute_charge(quote, images=2, requests=0)
    assert charge.charged_micro == 500_000
    assert charge.provider_cost_micro is not None


def test_per_request_and_audio_minute_prices_convert(db: Session) -> None:
    model = _model(db, input_price=None, output_price=None)
    model.selling_per_request = Decimal("0.05")
    model.selling_per_audio_minute = Decimal("1.20")
    db.commit()
    quote = pricing.resolve_price(db, model)
    assert quote.per_request_micro == 50_000
    assert quote.per_audio_minute_micro == 1_200_000
    charge = pricing.compute_charge(quote, requests=1, audio_seconds=30)
    assert charge.charged_micro == 50_000 + 600_000


def test_provider_costs_are_converted_from_usd(db: Session) -> None:
    """Provider cost is USD on the model: per-MTok is a rate, per-request/image is flat."""
    model = _model(db, input_price=3.0, output_price=6.0)
    model.provider_cost_per_image = Decimal("0.02")
    model.provider_cost_per_request = Decimal("0.001")
    db.commit()
    quote = pricing.resolve_price(db, model)
    assert quote.provider_per_image_micro == 20_000
    assert quote.provider_per_request_micro == 1_000


def test_provider_per_token_cost_is_a_per_mtok_rate_not_a_per_token_rate(db: Session) -> None:
    """Regression: $0.20/MTok of provider cost used to be charged as $0.20 *per token*.

    ``usd_to_micro`` yields micro-credits per million tokens (0.20 USD -> 200000 with the
    default 1 credit = 1 USD), so the per-token charge must divide by a million. Charging it
    per token inflated the recorded provider cost by 1e6 — and the same inflation leaked into
    every price the platform *derived* from provider cost + markup.
    """
    model = _model(db, input_price=1.0, output_price=2.0)
    model.provider_cost_input_per_mtok = Decimal("0.20")
    model.provider_cost_output_per_mtok = Decimal("0.60")
    db.commit()
    quote = pricing.resolve_price(db, model)
    assert quote.provider_input_per_mtok_micro == 200_000
    assert quote.provider_output_per_mtok_micro == 600_000

    charge = pricing.compute_charge(quote, prompt_tokens=1_000_000, completion_tokens=1_000_000)
    assert charge.provider_cost_micro == 200_000 + 600_000  # 0.20 + 0.60 credits


def test_model_prices_are_derived_from_provider_cost_when_unset(db: Session) -> None:
    model = _model(db, input_price=None, output_price=None)
    model.selling_per_image = None
    model.provider_cost_per_image = Decimal("0.10")
    model.pricing_uncertain = False
    db.commit()
    quote = pricing.resolve_price(db, model)
    assert quote.scope == "derived_from_provider_cost"
    # default markup is 30%
    assert quote.per_image_micro == 130_000, quote.per_image_micro
    assert any("derived" in warning.lower() for warning in quote.warnings)


def test_derived_per_token_price_stays_in_the_credits_per_mtok_range(db: Session) -> None:
    """A markup on a $0.10/MTok provider cost is ~0.13 credits/MTok — not 130000 credits."""
    model = _model(db, input_price=None, output_price=None)
    model.selling_input_per_mtok = None
    model.selling_output_per_mtok = None
    model.selling_per_image = None
    model.provider_cost_input_per_mtok = Decimal("0.10")
    model.provider_cost_output_per_mtok = Decimal("0.10")
    model.pricing_uncertain = False
    db.commit()
    quote = pricing.resolve_price(db, model)
    assert quote.scope == "derived_from_provider_cost"
    assert quote.input_per_mtok_micro == 130_000, quote.input_per_mtok_micro
    assert pricing.micro_to_per_mtok_credits(quote.input_per_mtok_micro) == 0.13

    charge = pricing.compute_charge(quote, prompt_tokens=1_000_000, completion_tokens=1_000_000)
    # 2M tokens * 0.13 credits per 1M = 0.26 credits = 260 000 micro-credits
    assert charge.charged_micro == 260_000, charge.charged_micro
    # a small call stays above zero but below the platform minimum, which then applies
    small = pricing.compute_charge(quote, prompt_tokens=1_000, completion_tokens=1_000)
    assert small.charged_micro == quote.minimum_charge_micro and small.minimum_applied is True


def test_a_pricing_rule_overrides_the_model_columns_in_credits_per_mtok(db: Session) -> None:
    """An operator enters 0.28 credits/MTok; the rule stores 280000 micro-credits/MTok."""
    from app.models.billing import PricingRule

    model = _model(db, input_price=9.0, output_price=9.0)
    db.add(PricingRule(
        name="cheap plan for this model", scope="model", scope_ref_id=model.id, version=1, active=True,
        input_per_mtok_micro=280_000, output_per_mtok_micro=560_000, markup_percent=30, currency="USD",
    ))
    db.commit()
    quote = pricing.resolve_price(db, model)
    assert quote.scope == "model"
    assert quote.input_per_mtok_micro == 280_000
    assert pricing.micro_to_per_mtok_credits(quote.input_per_mtok_micro) == 0.28

    charge = pricing.compute_charge(quote, prompt_tokens=1_000_000, completion_tokens=1_000_000)
    assert charge.charged_micro == 280_000 + 560_000


def test_priced_model_still_reports_scope_and_rule_version(db: Session) -> None:
    model = _model(db, input_price=2.0, output_price=8.0)
    quote = pricing.resolve_price(db, model)
    assert quote.scope in {"global_defaults", "model_columns"}
    assert quote.rule_id is not None  # the seeded global defaults rule is always referenced
    assert quote.minimum_charge_micro >= 0


def test_minimum_charge_only_applies_to_small_non_zero_amounts(db: Session) -> None:
    model = _model(db, input_price=None, output_price=None)
    model.selling_per_request = Decimal("0.0001")      # 100 micro-credits: non-zero but below the minimum
    db.commit()
    quote = pricing.resolve_price(db, model)
    charge = pricing.compute_charge(quote, requests=1)
    assert charge.charged_micro == quote.minimum_charge_micro
    assert charge.minimum_applied is True

    free = pricing.compute_charge(quote, requests=0)
    assert free.charged_micro == 0, "an operation with no billable units must stay at zero"

    priced = pricing.compute_charge(quote, requests=30)
    assert priced.charged_micro == 30 * 100, "amounts above the minimum are charged at the unit price"


def test_an_unpriced_model_charges_nothing_and_says_so(db: Session) -> None:
    model = _model(db, input_price=None, output_price=None)
    model.provider_cost_input_per_mtok = None
    model.provider_cost_output_per_mtok = None
    db.commit()
    quote = pricing.resolve_price(db, model)
    assert quote.scope == "unpriced"
    assert any("No pricing information" in warning for warning in quote.warnings)
    charge = pricing.compute_charge(quote, prompt_tokens=1_000, completion_tokens=1_000)
    assert charge.charged_micro == 0


def test_free_tier_is_never_charged(db: Session) -> None:
    model = _model(db, input_price=10.0, output_price=10.0, access_tier="free")
    quote = pricing.resolve_price(db, model)
    charge = pricing.compute_charge(quote, prompt_tokens=1000, completion_tokens=1000, access_tier="free")
    assert charge.charged_micro == 0
    assert charge.provider_cost_micro == 0
