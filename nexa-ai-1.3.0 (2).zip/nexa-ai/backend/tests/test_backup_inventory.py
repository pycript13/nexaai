"""Backup inventory: the admin console must report *files*, never intentions.

The page used to read its history from `GET /api/v1/admin/backup/run` — a POST-only route —
so every visit answered 404 and the operator never saw a backup. These tests pin the new
read-only inventory down, including the rule that matters most: a file is only "verified"
when the verification record written by `scripts/backup.sh` is present *and* still matches
the file on disk.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from app.services import backups as backups_service
from tests.conftest import AuthSession  # noqa: F401  (kept for the API test below)


def _touch(directory: Path, name: str, size: int, mtime: float) -> Path:
    path = directory / name
    path.write_bytes(b"x" * size)
    os.utime(path, (mtime, mtime))
    return path


def test_missing_directory_is_an_empty_inventory(tmp_path: Path) -> None:
    result = backups_service.list_backups(tmp_path / "nope")
    assert result["items"] == []
    assert result["count"] == 0
    assert result["last_verified"] is None
    assert result["directory"].endswith("nope")
    # the page always has a restore instruction to show, even with no backups yet
    assert "restore" in result["restore_note"].lower()


def test_a_file_without_a_verification_record_is_not_verified(tmp_path: Path) -> None:
    _touch(tmp_path, "nexa-sqlite-20260101T000000Z.db", 128, 1_700_000_000)
    item = backups_service.list_backups(tmp_path)["items"][0]
    assert item["status"] == "completed"
    assert item["verified"] is False
    assert item["size_bytes"] == 128
    assert "not produced by the bundled backup script" in (item["notes"] or "")


def test_verification_record_marks_a_backup_verified(tmp_path: Path) -> None:
    path = _touch(tmp_path, "nexa-sqlite-20260102T000000Z.db", 256, 1_700_000_100)
    backups_service.write_sidecar(path, database="sqlite")
    result = backups_service.list_backups(tmp_path)
    item = result["items"][0]
    assert item["verified"] is True
    assert item["sha256"] == backups_service.sha256_of(path)
    assert item["verified_at"] and result["last_verified"] == item["verified_at"]
    assert item["notes"] is None
    # the sidecar itself is not a backup row
    assert result["count"] == 1


def test_a_file_changed_after_verification_is_no_longer_verified(tmp_path: Path) -> None:
    path = _touch(tmp_path, "nexa-pg-20260103T000000Z.dump", 512, 1_700_000_200)
    backups_service.write_sidecar(path, database="postgresql")
    assert backups_service.list_backups(tmp_path)["items"][0]["verified"] is True

    # somebody replaced/truncated the dump: the recorded size no longer describes it
    path.write_bytes(b"y" * 10)
    item = backups_service.list_backups(tmp_path)["items"][0]
    assert item["verified"] is False
    assert "changed after verification" in (item["notes"] or "")


def test_interrupted_backup_is_reported_as_incomplete(tmp_path: Path) -> None:
    _touch(tmp_path, "nexa-pg-20260104T000000Z.dump.partial", 64, 1_700_000_300)
    item = backups_service.list_backups(tmp_path)["items"][0]
    assert item["status"] == "incomplete"
    assert item["verified"] is False
    assert "interrupted" in (item["notes"] or "")


def test_newest_backup_is_listed_first(tmp_path: Path) -> None:
    _touch(tmp_path, "nexa-pg-20260101T000000Z.dump", 10, 1_700_000_000)
    _touch(tmp_path, "nexa-pg-20260105T000000Z.dump", 10, 1_700_000_500)
    _touch(tmp_path, "nexa-uploads-20260103T000000Z.tar.gz", 10, 1_700_000_200)
    names = [item["filename"] for item in backups_service.list_backups(tmp_path)["items"]]
    assert names == [
        "nexa-pg-20260105T000000Z.dump",
        "nexa-uploads-20260103T000000Z.tar.gz",
        "nexa-pg-20260101T000000Z.dump",
    ]


def test_sidecar_format_matches_what_backup_sh_writes(tmp_path: Path) -> None:
    """`scripts/backup.sh` writes the same JSON through printf — the keys must line up."""
    path = _touch(tmp_path, "nexa-pg-20260106T000000Z.dump", 32, 1_700_000_600)
    sidecar = backups_service.write_sidecar(path, database="postgresql")
    payload = json.loads(sidecar.read_text())
    assert set(payload) == {"file", "size_bytes", "sha256", "verified", "verified_at", "verifier", "database"}
    assert payload["file"] == path.name
    assert payload["verified"] is True

    script = (Path(__file__).resolve().parents[2] / "scripts" / "backup.sh").read_text(encoding="utf-8")
    for key in payload:
        assert f'"{key}"' in script, f"backup.sh does not record '{key}'"
    assert "write_verification_record" in script


def test_api_lists_backups_for_an_administrator(admin_client) -> None:  # noqa: ANN001
    response = admin_client.get("/api/v1/admin/backups")
    assert response.status_code == 200, response.text
    payload = response.json()
    assert isinstance(payload["items"], list)
    assert payload["directory"].endswith("backups")
    assert "restore_note" in payload


def test_api_refuses_ordinary_users(user_client) -> None:  # noqa: ANN001
    assert user_client.get("/api/v1/admin/backups").status_code == 403
