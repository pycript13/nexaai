"""The exactly-once claim table must work on a REAL migrated database.

The in-process suites build their schema with ``create_all``, which silently
supplies server defaults the handwritten migration might forget — this test runs
the actual Alembic chain on a throwaway SQLite file and then claims an update
twice, so a migration/schema drift fails here instead of in production (where it
would have made every update look like a "duplicate" and silenced the bot).
"""
import os
import subprocess
import sys


def test_alembic_head_then_claim(tmp_path) -> None:
    db_file = tmp_path / "migrated.db"
    env = {
        **os.environ,
        "NEXA_DATABASE_URL": f"sqlite+pysqlite:///{db_file}",
        "NEXA_TELEGRAM_BOT_TOKEN": "",
    }
    backend = os.path.join(os.path.dirname(__file__), "..")
    upgrade = subprocess.run(
        [sys.executable, "-m", "alembic", "upgrade", "head"],
        cwd=backend, env=env, capture_output=True, text=True, timeout=600,
    )
    assert upgrade.returncode == 0, upgrade.stdout[-2000:] + upgrade.stderr[-2000:]

    claim = subprocess.run(
        [sys.executable, "-c", (
            "from app.db.session import SessionLocal;"
            "from app.services.telegram import claim_update;"
            "db = SessionLocal();"
            "print('first', claim_update(db, 987654321));"
            "print('second', claim_update(db, 987654321))"
        )],
        cwd=backend, env=env, capture_output=True, text=True, timeout=300,
    )
    assert claim.returncode == 0, claim.stdout[-2000:] + claim.stderr[-2000:]
    assert "first True" in claim.stdout, claim.stdout
    assert "second False" in claim.stdout, claim.stdout
