"""Authentication tests: registration, login, sessions, password policy."""
from __future__ import annotations

import os

from fastapi.testclient import TestClient

from tests.conftest import AuthSession, _register


def test_registration_requires_terms_acceptance(client: TestClient) -> None:
    response = client.post(
        "/api/v1/auth/register",
        json={
            "email": f"noterms{os.urandom(3).hex()}@nexatest.io",
            "password": "Strong-Password-77",
            "display_name": "No Terms",
            "accept_terms": False,
            "accept_privacy": True,
        },
    )
    assert response.status_code == 422
    body = response.json()
    assert body["error"]["code"] == "validation_error"
    assert "accept_terms" in body["error"]["details"]["fields"]


def test_registration_stores_policy_versions(client: TestClient, db) -> None:
    from sqlalchemy import select

    from app.models.user import User

    email = f"policy{os.urandom(3).hex()}@nexatest.io"
    response = client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": "Strong-Password-77", "display_name": "Policy User",
              "accept_terms": True, "accept_privacy": True},
    )
    assert response.status_code == 201, response.text
    user = db.scalars(select(User).where(User.email == email)).first()
    assert user is not None
    assert user.accepted_terms_version and user.accepted_terms_at is not None
    assert user.accepted_privacy_version and user.accepted_privacy_at is not None


def test_weak_passwords_are_rejected(client: TestClient) -> None:
    response = client.post(
        "/api/v1/auth/register",
        json={"email": f"weak{os.urandom(3).hex()}@nexatest.io", "password": "password",
              "display_name": "Weak", "accept_terms": True, "accept_privacy": True},
    )
    assert response.status_code == 422
    assert response.json()["error"]["details"]["fields"]["password"]


def test_duplicate_registration_conflicts(client: TestClient) -> None:
    email = f"dupe{os.urandom(3).hex()}@nexatest.io"
    payload = {"email": email, "password": "Strong-Password-77", "display_name": "Dupe",
               "accept_terms": True, "accept_privacy": True}
    assert client.post("/api/v1/auth/register", json=payload).status_code == 201
    assert client.post("/api/v1/auth/register", json=payload).status_code == 409


def test_login_logout_and_protected_route(client: TestClient) -> None:
    email = f"session{os.urandom(3).hex()}@nexatest.io"
    _register(client, email)
    session = AuthSession(client, email, "Tester-Password-99")
    data = session.login()
    assert data["user"]["email"] == email
    assert session.get("/api/v1/chat/conversations").status_code == 200
    logout = session.post("/api/v1/auth/logout")
    assert logout.status_code == 200
    assert session.get("/api/v1/chat/conversations").status_code == 401


def test_wrong_password_is_generic_error(client: TestClient) -> None:
    email = f"wrongpw{os.urandom(3).hex()}@nexatest.io"
    _register(client, email)
    response = client.post("/api/v1/auth/login", json={"email": email, "password": "Wrong-Password-123"})
    assert response.status_code == 401
    assert "Incorrect email or password" in response.json()["error"]["message"]


def test_unknown_email_same_error_shape(client: TestClient) -> None:
    response = client.post("/api/v1/auth/login", json={"email": "ghost@nexatest.io", "password": "Whatever-12345"})
    assert response.status_code == 401
    assert response.json()["error"]["code"] == "unauthenticated"


def test_unauthenticated_requests_are_rejected(client: TestClient) -> None:
    for path in ("/api/v1/chat/conversations", "/api/v1/billing/balance", "/api/v1/files", "/api/v1/auth/me"):
        assert client.get(path).status_code == 401, path


def test_login_is_possible_with_a_stale_session_cookie(client: TestClient) -> None:
    """A revoked session cookie must not lock the user out of signing in again."""
    email = f"relogin{os.urandom(3).hex()}@nexatest.io"
    session = _register(client, email)
    session.login()
    session.post("/api/v1/auth/logout")  # revokes the session server-side
    response = client.post("/api/v1/auth/login", json={"email": email, "password": "Tester-Password-99"})
    assert response.status_code == 200, response.text


def test_csrf_required_for_cookie_mutations(client: TestClient) -> None:
    email = f"csrf{os.urandom(3).hex()}@nexatest.io"
    _register(client, email)
    session = AuthSession(client, email, "Tester-Password-99")
    session.login()
    # valid session cookie but no CSRF header → request must be refused
    response = client.post("/api/v1/chat/conversations", json={"title": "no csrf"}, cookies=session.cookies)
    assert response.status_code == 403
    assert response.json()["error"]["code"] == "csrf_failed"
    # with the header, the same request succeeds
    assert session.post("/api/v1/chat/conversations", json={"title": "with csrf"}).status_code == 201


def test_password_change_revokes_other_sessions(client: TestClient) -> None:
    email = f"pwchange{os.urandom(3).hex()}@nexatest.io"
    _register(client, email)
    first = AuthSession(client, email, "Tester-Password-99")
    first.login()
    cookies_first = dict(client.cookies)

    second = AuthSession(client, email, "Tester-Password-99")
    second.login()
    response = second.post("/api/v1/auth/password", json={"current_password": "Tester-Password-99",
                                                          "new_password": "Brand-New-Password-42"})
    assert response.status_code == 200, response.text

    # the first session should now be revoked
    client.cookies.clear()
    client.cookies.update(cookies_first)
    assert client.get("/api/v1/auth/me").status_code == 401
    # the new password works
    client.cookies.clear()
    login = client.post("/api/v1/auth/login", json={"email": email, "password": "Brand-New-Password-42"})
    assert login.status_code == 200


def test_sessions_listing_and_revocation(client: TestClient) -> None:
    email = f"sessions{os.urandom(3).hex()}@nexatest.io"
    _register(client, email)
    session = AuthSession(client, email, "Tester-Password-99")
    session.login()
    listing = session.get("/api/v1/auth/sessions").json()
    assert listing["items"] and any(item["current"] for item in listing["items"])
    target = [item for item in listing["items"] if not item["current"]]
    if target:
        assert session.delete(f"/api/v1/auth/sessions/{target[0]['id']}").status_code == 200


def test_email_verification_is_disabled_without_smtp(client: TestClient, db) -> None:
    """Without SMTP the platform must not pretend to send verification mail.

    Accounts are marked verified only because verification is *not required*
    (NEXA_REQUIRE_EMAIL_VERIFICATION=false), and the API reports that email
    delivery is unconfigured instead of claiming a message was sent.
    """
    from sqlalchemy import select

    from app.models.user import User

    email = f"emailverify{os.urandom(3).hex()}@nexatest.io"
    session = _register(client, email)
    session.login()
    user = db.scalars(select(User).where(User.email == email)).first()
    assert user is not None and user.email_verified is True  # auto-verified, no email claimed
    response = session.get("/api/v1/auth/config").json()
    assert response["email_delivery_configured"] is False
    assert response["email_verification_required"] is False
    verify = session.post("/api/v1/auth/email/verify-request")
    assert verify.status_code == 200
    assert "already verified" in verify.json()["message"]


def test_password_reset_reports_unconfigured_email(client: TestClient) -> None:
    response = client.post("/api/v1/auth/password/reset-request", json={"email": "admin@nexatest.io"})
    assert response.status_code == 200
    assert "Email delivery is not configured" in response.json()["message"]


def test_account_config_endpoint_exposes_no_secrets(client: TestClient) -> None:
    data = client.get("/api/v1/auth/config").json()
    assert data["registration_mode"] in ("open", "invite_only", "closed")
    assert data["email_delivery_configured"] is False
    assert "secret" not in str(data).lower()
