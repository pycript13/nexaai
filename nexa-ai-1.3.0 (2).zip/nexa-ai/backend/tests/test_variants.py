"""Model variants: named ways of using one model (system prompt + defaults).

The rules these tests pin down:

* a variant belongs to exactly one model and can never reach another one;
* it never changes pricing, availability or the access tier — those stay the parent's;
* a disabled variant is refused loudly (never silently ignored);
* a personal variant is private to its owner;
* the system prompt of the variant is what actually reaches the provider.
"""
from __future__ import annotations

import json

from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.models.provider import ModelVariant
from tests.conftest import create_provider_and_model, grant_credits


STREAM_BODY = (
    b'data: {"id":"x","object":"chat.completion.chunk","choices":[{"index":0,"delta":{"content":"OK"},"finish_reason":null}]}\n\n'
    b'data: {"id":"x","object":"chat.completion.chunk","choices":[{"index":0,"delta":{},"finish_reason":"stop"}],'
    b'"usage":{"prompt_tokens":4,"completion_tokens":1,"total_tokens":5}}\n\n'
    b"data: [DONE]\n\n"
)


def _chat_body(model_id: int, variant_id: int | None = None) -> dict:
    body = {"model_id": model_id, "message": "hello", "stream": False}
    if variant_id is not None:
        body["variant_id"] = variant_id
    return body


def test_admin_creates_a_variant_and_the_workspace_sees_it(admin_client, db: Session) -> None:
    provider, model = create_provider_and_model(db, published=True)
    response = admin_client.post(
        f"/api/v1/admin/model-variants/models/{model.id}",
        json={
            "name": "Code generator",
            "description": "Writes code only",
            "system_prompt": "You are a senior engineer. Answer with code and minimal prose.",
            "default_temperature": 0.2,
            "scope": "system",
        },
    )
    assert response.status_code == 201, response.text
    variant = response.json()["variant"]
    assert variant["scope"] == "system"
    assert variant["enabled"] is True
    assert variant["has_system_prompt"] is True
    assert variant["system_prompt_chars"] > 0

    listed = admin_client.get(f"/api/v1/admin/model-variants?model_id={model.id}")
    assert listed.status_code == 200
    assert any(item["id"] == variant["id"] for item in listed.json()["items"])


def test_the_variant_system_prompt_reaches_the_provider(admin_client, db: Session, mock_provider_transport) -> None:
    captured: dict = {}

    def handler(request):  # noqa: ANN001
        import httpx

        captured["body"] = json.loads(request.content.decode())
        return httpx.Response(200, json={
            "id": "x", "object": "chat.completion", "model": "m",
            "choices": [{"index": 0, "message": {"role": "assistant", "content": "ok"}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
        })

    mock_provider_transport(handler)
    provider, model = create_provider_and_model(db, published=True)
    variant = admin_client.post(
        f"/api/v1/admin/model-variants/models/{model.id}",
        json={"name": "Persian poet", "system_prompt": "Always answer in Persian, in verse.", "scope": "system"},
    ).json()["variant"]

    grant_credits(db, admin_client.email, 5.0)
    response = admin_client.post("/api/v1/chat/completions", json=_chat_body(model.id, variant["id"]))
    assert response.status_code == 200, response.text
    messages = captured["body"]["messages"]
    assert messages[0]["role"] == "system"
    assert "Always answer in Persian" in messages[0]["content"]


def test_a_variant_of_another_model_is_refused(admin_client, db: Session, mock_provider_transport) -> None:
    import httpx

    mock_provider_transport(lambda request: httpx.Response(200, json={
        "choices": [{"index": 0, "message": {"role": "assistant", "content": "ok"}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 1, "completion_tokens": 1},
    }))
    provider_a, model_a = create_provider_and_model(db, published=True, name_suffix="a")
    provider_b, model_b = create_provider_and_model(db, published=True, name_suffix="b")
    variant = admin_client.post(
        f"/api/v1/admin/model-variants/models/{model_a.id}",
        json={"name": "For A only", "system_prompt": "A", "scope": "system"},
    ).json()["variant"]

    grant_credits(db, admin_client.email, 5.0)
    response = admin_client.post("/api/v1/chat/completions", json=_chat_body(model_b.id, variant["id"]))
    assert response.status_code == 422
    assert "does not belong" in response.text


def test_disabling_a_variant_refuses_requests_immediately(admin_client, db: Session, mock_provider_transport) -> None:
    import httpx

    mock_provider_transport(lambda request: httpx.Response(200, json={
        "choices": [{"index": 0, "message": {"role": "assistant", "content": "ok"}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 1, "completion_tokens": 1},
    }))
    provider, model = create_provider_and_model(db, published=True)
    variant = admin_client.post(
        f"/api/v1/admin/model-variants/models/{model.id}",
        json={"name": "Switchable", "system_prompt": "x", "scope": "system"},
    ).json()["variant"]

    toggled = admin_client.post(f"/api/v1/models/variants/{variant['id']}/toggle")
    assert toggled.status_code == 200
    assert toggled.json()["enabled"] is False

    grant_credits(db, admin_client.email, 5.0)
    response = admin_client.post("/api/v1/chat/completions", json=_chat_body(model.id, variant["id"]))
    assert response.status_code == 422
    assert "switched off" in response.text

    admin_client.post(f"/api/v1/models/variants/{variant['id']}/toggle")
    assert admin_client.post("/api/v1/chat/completions", json=_chat_body(model.id, variant["id"])).status_code == 200


def test_personal_variants_are_private_to_their_owner(user_client, second_user_client, db: Session) -> None:
    provider, model = create_provider_and_model(db, published=True)
    created = user_client.post(
        f"/api/v1/models/{model.id}/variants",
        json={"name": "My own style", "system_prompt": "Be terse.", "scope": "personal"},
    )
    assert created.status_code == 201, created.text
    variant = created.json()["variant"]
    assert variant["scope"] == "personal"

    mine = user_client.get(f"/api/v1/models/{model.id}/variants").json()["items"]
    theirs = second_user_client.get(f"/api/v1/models/{model.id}/variants").json()["items"]
    assert any(item["id"] == variant["id"] for item in mine)
    assert not any(item["id"] == variant["id"] for item in theirs)

    # and the other user cannot use it by guessing the id
    grant_credits(db, second_user_client.email, 5.0)
    response = second_user_client.post("/api/v1/chat/completions", json=_chat_body(model.id, variant["id"]))
    assert response.status_code in (422, 403), response.text


def test_a_normal_user_cannot_publish_a_workspace_variant(user_client, db: Session) -> None:
    provider, model = create_provider_and_model(db, published=True)
    response = user_client.post(
        f"/api/v1/models/{model.id}/variants",
        json={"name": "Everyone's", "system_prompt": "x", "scope": "system"},
    )
    assert response.status_code in (403, 422)


def test_variant_creation_is_audited(admin_client, db: Session) -> None:
    from app.models.admin import AuditEvent
    from sqlalchemy import select

    provider, model = create_provider_and_model(db, published=True)
    admin_client.post(
        f"/api/v1/admin/model-variants/models/{model.id}",
        json={"name": "Audited", "system_prompt": "x", "scope": "system"},
    )
    events = db.scalars(select(AuditEvent).where(AuditEvent.action == "model_variant.created")).all()
    assert events, "creating a variant must be written to the audit log"
    assert len(db.scalars(select(ModelVariant)).all()) >= 1


def test_usage_records_carry_the_variant(admin_client, db: Session, mock_provider_transport) -> None:
    import httpx

    mock_provider_transport(lambda request: httpx.Response(200, json={
        "choices": [{"index": 0, "message": {"role": "assistant", "content": "ok"}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 4, "completion_tokens": 2, "total_tokens": 6},
    }))
    provider, model = create_provider_and_model(db, published=True)
    variant = admin_client.post(
        f"/api/v1/admin/model-variants/models/{model.id}",
        json={"name": "Tracked", "system_prompt": "x", "scope": "system"},
    ).json()["variant"]
    grant_credits(db, admin_client.email, 5.0)
    admin_client.post("/api/v1/chat/completions", json=_chat_body(model.id, variant["id"]))

    from app.models.billing import UsageRecord
    from sqlalchemy import select

    record = db.scalars(select(UsageRecord).order_by(UsageRecord.id.desc())).first()
    assert record is not None
    assert record.variant_id == variant["id"]
    assert record.model_id == model.id, "pricing still resolves to the parent model"

def test_streaming_with_a_variant_carries_the_prompt_and_reports_the_variant(
    admin_client, db: Session, mock_provider_transport
) -> None:
    """Regression: the streaming endpoint used to raise NameError on `variant`.

    The SSE `meta` frame must announce the sub-model and the provider must receive the
    sub-model's system prompt — exactly like the non-streaming path already did.
    """
    captured: dict = {}

    def handler(request):  # noqa: ANN001
        import httpx

        if request.url.path.endswith("/chat/completions"):
            captured["body"] = json.loads(request.content.decode())
            return httpx.Response(200, content=STREAM_BODY, headers={"content-type": "text/event-stream"})
        return httpx.Response(404, json={"error": {"message": "not found"}})

    mock_provider_transport(handler)
    provider, model = create_provider_and_model(db, published=True)
    variant = admin_client.post(
        f"/api/v1/admin/model-variants/models/{model.id}",
        json={"name": "Streamer", "system_prompt": "STREAM-MARKER", "scope": "system"},
    ).json()["variant"]
    grant_credits(db, admin_client.email, 5.0)

    with admin_client.stream(
        "POST",
        "/api/v1/chat/stream",
        json={"model_id": model.id, "message": "hi", "variant_id": variant["id"]},
    ) as response:
        assert response.status_code == 200, response.read()
        payload = "".join(chunk for chunk in response.iter_text())

    assert "event: meta" in payload
    assert "event: done" in payload
    meta_line = next(line for line in payload.splitlines() if line.startswith("data: ") and '"conversation_id"' in line)
    meta = json.loads(meta_line[6:])
    assert meta["variant"]["id"] == variant["id"]
    assert meta["variant"]["system_prompt_chars"] == len("STREAM-MARKER")
    assert captured["body"]["messages"][0] == {"role": "system", "content": "STREAM-MARKER"}
