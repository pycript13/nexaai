"""Round-15 Telegram contracts: a two-button bar and a nested glass hub.

The owner's round-15 brief: keep only the *necessary* buttons at the bottom of the screen and
move everything else into inline buttons inside the messages, nested (تو در تو), professionally.
These tests pin that architecture:

* the persistent bar is exactly «💬 گفتگو» and «🧭 منو» — in both languages, never mutated;
* «🧭 منو» opens a tracked glass hub whose buttons open the sections nested inside it;
* opening a section from the hub EDITS the hub message (no pile-up), and «↩️ بازگشت به منو»
  edits back to the hub — the chat keeps exactly one menu card;
* account sub-views (usage/stats/status/…) keep the account hub buttons, so the nesting has a
  real parent at every level;
* «💬 گفتگو» clears the desk: the tracked card is deleted and the bar is refreshed;
* stale keyboards from before the upgrade keep working: their old labels still route.
"""
from __future__ import annotations

import asyncio
import uuid

import pytest
from sqlalchemy import select

from app.core.config import settings
from app.models.telegram import TelegramLink
from app.services import telegram as telegram_service
from app.services import telegram_menus as menus
from tests.conftest import create_provider_and_model
from tests.tools.fake_telegram import FakeTelegramServer


@pytest.fixture()
def telegram(monkeypatch: pytest.MonkeyPatch):
    server = FakeTelegramServer()
    port = server.start()
    monkeypatch.setattr(settings, "telegram_enabled", True)
    monkeypatch.setattr(settings, "telegram_bot_token", "123456:TEST-TOKEN")
    monkeypatch.setattr(settings, "telegram_bot_username", "nexa_test_bot")
    monkeypatch.setattr(settings, "telegram_api_base", f"http://127.0.0.1:{port}")
    monkeypatch.setattr(settings, "telegram_mode", "polling")
    yield server
    server.stop()


# ------------------------------------------------------------------ helpers -----
def _unique_id() -> int:
    return 720_000_000 + (uuid.uuid4().int % 100_000_000)


def _update(server: FakeTelegramServer, text: str, *, telegram_user_id: int) -> dict:
    return {
        "update_id": server.next_update_id(),
        "message": {
            "message_id": server.next_message_id(),
            "from": {"id": telegram_user_id, "is_bot": False, "first_name": "Tester"},
            "chat": {"id": telegram_user_id, "type": "private"},
            "date": 1_700_000_000,
            "text": text,
        },
    }


def _tap(server: FakeTelegramServer, data: str, *, telegram_user_id: int, message_id: int) -> dict:
    return {
        "update_id": server.next_update_id(),
        "callback_query": {
            "id": str(server.next_update_id()),
            "from": {"id": telegram_user_id, "is_bot": False, "first_name": "Tester"},
            "message": {"message_id": message_id, "chat": {"id": telegram_user_id, "type": "private"},
                        "date": 1_700_000_000},
            "data": data,
        },
    }


def _deliver(db, server: FakeTelegramServer, update: dict) -> tuple[str, list[dict]]:
    before = len(server.sent)
    result = asyncio.run(telegram_service.handle_update(db, update))
    return result, server.sent[before:]


def _say(db, server: FakeTelegramServer, text: str, *, telegram_user_id: int):
    return _deliver(db, server, _update(server, text, telegram_user_id=telegram_user_id))


def _linked_account(user_client, db, server: FakeTelegramServer) -> int:
    telegram_user_id = _unique_id()
    code = user_client.post("/api/v1/telegram/link-code").json()["code"]
    result, _ = _say(db, server, f"/start {code}", telegram_user_id=telegram_user_id)
    assert result == "linked", result
    return telegram_user_id


def _state(db, telegram_user_id: int) -> dict:
    db.expire_all()
    link = db.scalars(
        select(TelegramLink).where(TelegramLink.telegram_user_id == telegram_user_id)
    ).first()
    assert link is not None
    return dict(link.state or {})


def _inline(message: dict) -> list[list[dict]]:
    import json

    markup = message.get("reply_markup")
    if isinstance(markup, str):
        markup = json.loads(markup)
    markup = markup or {}
    assert "inline_keyboard" in markup, f"no glass buttons on: {message['text'][:60]}"
    return markup["inline_keyboard"]


def _markup_data(markup) -> list[str]:
    import json

    if isinstance(markup, str):
        markup = json.loads(markup)
    markup = markup or {}
    rows = markup.get("inline_keyboard") or []
    return [button.get("callback_data") for row in rows for button in row]


def _idata(message: dict) -> list[str]:
    return _markup_data(message.get("reply_markup"))


# ------------------------------------------------------------------ contracts ---
def test_the_bar_is_exactly_two_buttons_in_both_languages() -> None:
    for language, expected in (("fa", ["💬 گفتگو", "🧭 منو"]), ("en", ["💬 Chat", "🧭 Menu"])):
        markup = menus.fixed_bar(language)
        labels = [button["text"] for row in markup["keyboard"] for button in row]
        assert labels == expected, (language, labels)
        assert markup["is_persistent"] is True and markup["resize_keyboard"] is True
        assert len(markup["keyboard"]) == 1, "one thumb row, nothing more"


def test_the_menu_button_opens_a_tracked_glass_hub(user_client, db, telegram) -> None:
    telegram_user_id = _linked_account(user_client, db, telegram)

    result, sent = _say(db, telegram, "🧭 منو", telegram_user_id=telegram_user_id)
    assert result == "menu"
    hub = sent[-1]
    assert "keyboard" not in (hub.get("reply_markup") or {}), "the hub is inline; the bar persists by itself"
    data = _idata(hub)
    for callback in ("menu:models", "menu:sessions", "menu:account", "menu:settings", "menu:help", "menu:new"):
        assert callback in data, data
    assert _state(db, telegram_user_id).get("ui_msg_id") == hub["message_id"], "the hub is tracked like every section card"


def test_sections_nest_inside_the_hub_and_edit_it_in_place(user_client, db, telegram) -> None:
    create_provider_and_model(db, published=True, display_name="Nested Model")
    telegram_user_id = _linked_account(user_client, db, telegram)

    _result, sent = _say(db, telegram, "🧭 منو", telegram_user_id=telegram_user_id)
    hub_id = sent[-1]["message_id"]

    # hub → settings: the SAME message becomes the settings card (no pile-up)
    result, _sent = _deliver(db, telegram, _tap(telegram, "menu:settings", telegram_user_id=telegram_user_id,
                                                message_id=hub_id))
    assert result == "settings"
    edit = next(item for item in telegram.edits if item["message_id"] == hub_id)
    data = _markup_data(edit["reply_markup"])
    assert "settings:lang:en" in data, "the settings card keeps its glass toggles"
    assert "nav:home" in data, "and a way back to the hub"
    assert not any(message["message_id"] != hub_id for message in _sent), "no second message was sent"

    # settings → hub: back edits the same card again
    result, _sent = _deliver(db, telegram, _tap(telegram, "nav:home", telegram_user_id=telegram_user_id,
                                                message_id=hub_id))
    assert result == "menu"
    # nav:home from the card itself deletes it and re-sends the hub; either way exactly one card remains
    assert _state(db, telegram_user_id).get("ui_msg_id"), "the hub is tracked again after going back"


def _alive_card(telegram, sent: list[dict], previous_id: int, chat_id: int) -> tuple[int, list[str]]:
    """Return (message_id, callbacks) of the card that replaced ``previous_id``.

    The product contract is one live section card at a time: navigation either EDITS the old
    card in place or DELETES it and sends a fresh one. Both shapes satisfy «no pile-up».
    """
    edited = next((item for item in telegram.edits if item["message_id"] == previous_id), None)
    if edited is not None:
        return previous_id, _markup_data(edited["reply_markup"])
    assert (chat_id, previous_id) in [(d["chat_id"], d["message_id"]) for d in telegram.deletes], \
        f"the previous card was neither edited nor deleted: {previous_id}"
    assert sent, "and nothing was sent in its place"
    return sent[-1]["message_id"], _markup_data(sent[-1].get("reply_markup"))


def test_account_subviews_keep_their_parent(user_client, db, telegram) -> None:
    telegram_user_id = _linked_account(user_client, db, telegram)

    _result, sent = _say(db, telegram, "🧭 منو", telegram_user_id=telegram_user_id)
    hub_id = sent[-1]["message_id"]

    _result, sent = _deliver(db, telegram, _tap(telegram, "menu:account", telegram_user_id=telegram_user_id,
                                                message_id=hub_id))
    account_id, data = _alive_card(telegram, sent, hub_id, telegram_user_id)
    for callback in ("menu:usage", "menu:stats", "menu:status", "menu:whoami", "menu:export"):
        assert callback in data, "the account hub nests every account view"
    assert "nav:home" in data
    assert _state(db, telegram_user_id).get("ui_msg_id") == account_id

    result, sent = _deliver(db, telegram, _tap(telegram, "menu:usage", telegram_user_id=telegram_user_id,
                                               message_id=account_id))
    assert result == "usage"
    usage_id, data = _alive_card(telegram, sent, account_id, telegram_user_id)
    assert "menu:stats" in data, "the usage view still offers its siblings — the parent is one tap away"
    assert "nav:home" in data
    assert _state(db, telegram_user_id).get("ui_msg_id") == usage_id


def test_the_chat_button_clears_the_desk_and_refreshes_the_bar(user_client, db, telegram) -> None:
    telegram_user_id = _linked_account(user_client, db, telegram)

    _result, sent = _say(db, telegram, "🧭 منو", telegram_user_id=telegram_user_id)
    hub_id = sent[-1]["message_id"]

    result, sent = _say(db, telegram, "💬 گفتگو", telegram_user_id=telegram_user_id)
    assert result == "chat"
    assert {"chat_id": telegram_user_id, "message_id": hub_id} in telegram.deletes, "the hub card is removed"
    bar_message = sent[-1]
    labels = [button["text"] for row in bar_message["reply_markup"]["keyboard"] for button in row]
    assert labels == ["💬 گفتگو", "🧭 منو"], "the bar is refreshed on the way back to chat mode"
    assert _state(db, telegram_user_id).get("ui_msg_id") in (None, 0), "nothing is tracked while chatting"


def test_stale_keyboards_from_before_the_upgrade_still_route(user_client, db, telegram) -> None:
    create_provider_and_model(db, published=True, display_name="Legacy Tap")
    telegram_user_id = _linked_account(user_client, db, telegram)

    # Telegram clients keep an old reply keyboard until a new one arrives: the round-13/14
    # six-button labels arrive as plain text and must still open their sections.
    for label, expected in (
        ("🧠 مدل‌ها", "models"),
        ("🗂 سشن‌ها", "sessions"),
        ("💳 حساب من", "account"),
        ("⚙️ تنظیمات", "settings"),
        ("❓ راهنما", "help"),
        ("🔙 بازگشت", "menu"),
    ):
        result, _sent = _say(db, telegram, label, telegram_user_id=telegram_user_id)
        assert result == expected, (label, result)
