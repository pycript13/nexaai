"""Round-12 (part 2) backend contracts: the SPA must appear when the build appears.

Two things a commercial console must not do, both found while exercising the round-12 additions in a
real browser:

* the API used to decide *at import time* whether it could serve the built SPA, so an operator who
  started the API first and built the frontend afterwards got ``404`` on ``/login`` — no sign-in
  screen at all — until a restart;
* the "frontend build not found" answer was a bare error with no instruction, which is exactly how a
  working installation looks broken.
"""
from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.core.config import settings


def test_spa_is_served_even_when_the_build_appears_after_startup(
    client: TestClient, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The route resolves the build directory per request, not once at import."""
    dist = tmp_path / "dist"
    (dist / "assets").mkdir(parents=True)
    (dist / "index.html").write_text("<!doctype html><title>Nexa AI</title>", encoding="utf-8")
    (dist / "assets" / "app.js").write_text("console.log('built')", encoding="utf-8")

    monkeypatch.setattr(settings, "serve_frontend", True)
    monkeypatch.setattr(settings, "frontend_dist_dir", str(dist))

    index = client.get("/login")
    assert index.status_code == 200, index.text
    assert "<!doctype html>" in index.text.lower()
    asset = client.get("/assets/app.js")
    assert asset.status_code == 200
    assert "built" in asset.text


def test_spa_deep_link_and_unknown_path_both_reach_the_app(
    client: TestClient, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A client route typed in the address bar (or shared as an invitation link) must load the SPA."""
    dist = tmp_path / "dist2"
    dist.mkdir()
    (dist / "index.html").write_text("<html>spa</html>", encoding="utf-8")
    monkeypatch.setattr(settings, "serve_frontend", True)
    monkeypatch.setattr(settings, "frontend_dist_dir", str(dist))

    for path in ("/app/admin/settings", "/register?invite=abc", "/definitely-not-a-route"):
        response = client.get(path)
        assert response.status_code == 200, f"{path} did not serve the SPA: {response.text}"
        assert "spa" in response.text


def test_api_paths_are_never_answered_with_the_spa(
    client: TestClient, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The SPA route must not shadow the API: an unknown API path stays a JSON 404."""
    dist = tmp_path / "dist3"
    dist.mkdir()
    (dist / "index.html").write_text("<html>spa</html>", encoding="utf-8")
    monkeypatch.setattr(settings, "serve_frontend", True)
    monkeypatch.setattr(settings, "frontend_dist_dir", str(dist))

    response = client.get("/api/v1/does-not-exist")
    assert response.status_code == 404
    assert response.headers["content-type"].startswith("application/json")
    assert "spa" not in response.text


def test_missing_build_explains_what_to_run(
    client: TestClient, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When there really is no build, the answer must say how to make one."""
    empty = tmp_path / "empty"
    empty.mkdir()
    monkeypatch.setattr(settings, "serve_frontend", True)
    monkeypatch.setattr(settings, "frontend_dist_dir", str(empty))

    response = client.get("/login")
    assert response.status_code == 404
    message = response.json()["error"]["message"]
    assert "npm run build" in message
    assert "NEXA_FRONTEND_DIST_DIR" in message
