"""Transport guarantees around provider calls.

Two defects motivated these tests:

1. A failed connection surfaced as ``Provider connectivity failure:`` — a label, a colon
   and nothing else, because several httpx exceptions have an empty ``str()``. The operator
   had no way to tell DNS from firewall from TLS from a wrong base URL.
2. The non-streaming path retried transient failures (``max_retries``), the *streaming* path
   — the one the chat UI uses — did not. So an administrator's connection test could look
   green while every chat call failed on the first hiccup.
"""
from __future__ import annotations

import asyncio

import httpx
import pytest

from app.core.errors import CONNECTIVITY, TIMEOUT, ProviderError, hints_for
from app.providers.http import ProviderHTTPClient, classify_exception


# --------------------------------------------------------------------- messages --
def test_transport_error_names_the_endpoint_and_the_exception() -> None:
    cases = [
        (httpx.ConnectTimeout(""), TIMEOUT),
        (httpx.ConnectError("All connection attempts failed"), CONNECTIVITY),
        (httpx.ReadError("peer closed the connection"), CONNECTIVITY),
        (httpx.UnsupportedProtocol("Request URL has an unsupported protocol 'ftp://'."), CONNECTIVITY),
    ]
    for exc, expected_category in cases:
        error = classify_exception(
            exc,
            provider="acme",
            model="acme-chat",
            url="https://api.acme.test/v1/chat/completions?api_key=sk-should-never-leak",
            operation="POST /chat/completions",
        )
        assert error.category == expected_category
        # The message must carry substance, not just "<label>:".
        head, _, tail = error.detail.partition(":")
        assert head.strip(), error.detail
        assert tail.strip(), f"empty explanation for {type(exc).__name__}"
        assert type(exc).__name__ in error.detail
        assert "https://api.acme.test/v1/chat/completions" in error.detail
        assert "sk-should-never-leak" not in error.detail
        assert error.details["endpoint"] == "https://api.acme.test/v1/chat/completions"
        assert error.details["exception"] == type(exc).__name__
        assert error.details["hints"]


def test_transport_error_explains_the_likely_cause() -> None:
    error = classify_exception(httpx.ConnectTimeout(""), provider="acme", model=None, url="https://api.acme.test/v1/models")
    assert "timed out" in error.detail.lower()
    error = classify_exception(httpx.ConnectError("boom"), provider="acme", model=None, url="https://api.acme.test/v1/models")
    assert "could not be established" in error.detail.lower()


def test_provider_error_hints_point_at_the_diagnostic_command() -> None:
    hints = hints_for(CONNECTIVITY) + hints_for(TIMEOUT)
    assert any("provider-check" in hint for hint in hints), hints


def test_provider_error_keeps_upstream_status_and_message() -> None:
    from app.providers.http import classify_http_error

    error = classify_http_error(
        404,
        '{"error": {"message": "model not found"}}',
        provider="acme",
        model="ghost",
        request_id="req-1",
        url="https://api.acme.test/v1/chat/completions",
    )
    assert error.category == "model_not_found"
    assert error.details["endpoint"] == "https://api.acme.test/v1/chat/completions"
    assert "model not found" in error.detail


# ------------------------------------------------------------------ stream retry --
SSE_BODY = b'data: {"choices":[{"delta":{"content":"hi"}}]}\n\ndata: [DONE]\n\n'


@pytest.fixture()
def no_backoff(monkeypatch: pytest.MonkeyPatch) -> None:
    async def _skip(self: ProviderHTTPClient, attempt: int, retry_after: str | None) -> None:  # noqa: ANN001
        return None

    monkeypatch.setattr(ProviderHTTPClient, "_backoff", _skip)


def _client(**kwargs) -> ProviderHTTPClient:
    return ProviderHTTPClient(
        provider="acme",
        base_url="https://api.acme.test/v1",
        api_key="sk-test",
        max_retries=2,
        validate_url=False,
        **kwargs,
    )


def test_stream_retries_a_connect_failure_before_the_first_byte(mock_provider_transport, no_backoff) -> None:
    attempts = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        attempts["n"] += 1
        if attempts["n"] == 1:
            raise httpx.ConnectError("temporary failure in name resolution")
        return httpx.Response(200, content=SSE_BODY, headers={"content-type": "text/event-stream"})

    mock_provider_transport(handler)
    client = _client()

    async def collect() -> list[str]:
        return [chunk async for chunk in client.stream_lines("/chat/completions", json_body={"model": "m", "stream": True})]

    chunks = asyncio.run(collect())
    assert chunks == ['{"choices":[{"delta":{"content":"hi"}}]}']
    assert attempts["n"] == 2, "the first, transient failure must be retried"


def test_stream_raises_the_full_diagnosis_when_every_attempt_fails(mock_provider_transport, no_backoff) -> None:
    attempts = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        attempts["n"] += 1
        raise httpx.ConnectError("All connection attempts failed")

    mock_provider_transport(handler)
    # A pinned address family means exactly one transport is attempted, so the retry
    # budget is what this test measures. (With `auto` the client walks auto → ipv4 →
    # ipv6 first; that fallback is covered by test_address_family_fallback below.)
    client = _client(network_preference="ipv4")

    async def collect() -> list[str]:
        return [chunk async for chunk in client.stream_lines("/chat/completions", json_body={"model": "m"})]

    with pytest.raises(ProviderError) as info:
        asyncio.run(collect())
    error = info.value
    assert error.category == CONNECTIVITY
    assert "https://api.acme.test/v1/chat/completions" in error.detail
    assert "ConnectError" in error.detail
    assert attempts["n"] == 3, "1 attempt + max_retries=2"


def test_stream_walks_every_address_family_before_giving_up(mock_provider_transport, no_backoff) -> None:
    """With the default `auto` preference a dead endpoint is retried per family."""
    attempts = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        attempts["n"] += 1
        raise httpx.ConnectError("All connection attempts failed")

    mock_provider_transport(handler)
    client = _client()  # network_preference defaults to "auto"

    async def collect() -> list[str]:
        return [chunk async for chunk in client.stream_lines("/chat/completions", json_body={"model": "m"})]

    with pytest.raises(ProviderError) as info:
        asyncio.run(collect())
    error = info.value
    assert error.category == CONNECTIVITY
    assert error.details.get("address_families_tried") == ["auto", "ipv4", "ipv6"]
    assert attempts["n"] == 9, "3 families × (1 attempt + max_retries=2)"


def test_stream_never_retries_after_data_was_delivered(mock_provider_transport, no_backoff) -> None:
    """A retry after the first token could duplicate the answer: fail honestly instead."""
    attempts = {"n": 0}

    async def body():
        yield b'data: {"choices":[{"delta":{"content":"first"}}]}\n\n'
        raise httpx.ReadError("connection lost mid-stream")

    def handler(request: httpx.Request) -> httpx.Response:
        attempts["n"] += 1
        return httpx.Response(200, content=body(), headers={"content-type": "text/event-stream"})

    mock_provider_transport(handler)
    client = _client()
    seen: list[str] = []

    async def collect() -> None:
        async for chunk in client.stream_lines("/chat/completions", json_body={"model": "m"}):
            seen.append(chunk)

    with pytest.raises(ProviderError) as info:
        asyncio.run(collect())
    assert seen == ['{"choices":[{"delta":{"content":"first"}}]}']
    assert attempts["n"] == 1
    assert info.value.details.get("partial_stream") is True
    assert "mid-stream" in info.value.detail


def test_stream_does_not_retry_a_non_retryable_status(mock_provider_transport, no_backoff) -> None:
    attempts = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        attempts["n"] += 1
        return httpx.Response(401, json={"error": {"message": "invalid api key"}})

    mock_provider_transport(handler)
    client = _client()

    async def collect() -> None:
        async for _ in client.stream_lines("/chat/completions", json_body={"model": "m"}):
            pass

    with pytest.raises(ProviderError) as info:
        asyncio.run(collect())
    assert info.value.category == "authentication"
    assert attempts["n"] == 1


def test_a_transient_429_is_retried_with_backoff(mock_provider_transport, no_backoff) -> None:
    """A real endpoint answered "at concurrency capacity, paid accounts are admitted first".

    That is a *transient* throttle, so the platform now retries it (honouring `Retry-After`)
    instead of failing a paying user's request on the first hit. The live check against a real
    provider is what surfaced this: the same model answered a second later.
    """
    attempts = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        attempts["n"] += 1
        if attempts["n"] == 1:
            return httpx.Response(429, json={"error": {"message": "This model is at concurrency capacity."}},
                                  headers={"retry-after": "1"})
        return httpx.Response(200, json={"data": [{"id": "m"}]})

    mock_provider_transport(handler)
    result = asyncio.run(_client().request("GET", "/models"))
    assert result.get("data") == [{"id": "m"}], "the retried attempt must be the one that answers"
    assert attempts["n"] == 2, "a bare 429 must be retried once here"


def test_an_exhausted_quota_is_not_retried(mock_provider_transport, no_backoff) -> None:
    """Same status code, different meaning: a billing problem will not fix itself in two seconds."""
    attempts = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        attempts["n"] += 1
        return httpx.Response(429, json={"error": {"message": "You exceeded your current quota, please check your plan and billing details"}})

    mock_provider_transport(handler)
    client = _client()
    with pytest.raises(ProviderError) as caught:
        asyncio.run(client.request("GET", "/models"))
    assert caught.value.category == "quota_exhausted"
    assert attempts["n"] == 1, "a quota/billing failure must not be retried"


def test_a_500_is_retried_but_a_400_is_not(mock_provider_transport, no_backoff) -> None:
    seq = {"n": 0}

    def flaky(request: httpx.Request) -> httpx.Response:
        seq["n"] += 1
        if seq["n"] == 1:
            return httpx.Response(503, text="upstream unavailable")
        return httpx.Response(200, json={"ok": True})

    mock_provider_transport(flaky)
    assert asyncio.run(_client().request("GET", "/models")).get("ok") is True
    assert seq["n"] == 2

    attempts = {"n": 0}

    def bad_request(request: httpx.Request) -> httpx.Response:
        attempts["n"] += 1
        return httpx.Response(400, json={"error": {"message": "invalid parameter: temperature"}})

    mock_provider_transport(bad_request)
    with pytest.raises(ProviderError) as caught:
        asyncio.run(_client().request("GET", "/models"))
    assert caught.value.category == "invalid_request"
    assert attempts["n"] == 1, "a rejected request stays rejected"
