"""Provider adapter tests: error taxonomy, streaming, SSRF policy, model sync."""
from __future__ import annotations

import json

import httpx
import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.core.errors import (
    AUTHENTICATION,
    CONNECTIVITY,
    MALFORMED_RESPONSE,
    MODEL_NOT_FOUND,
    QUOTA_EXHAUSTED,
    RATE_LIMIT,
    TIMEOUT,
    UNSUPPORTED_OPERATION,
)
from app.providers.base import ChatMessage, ChatRequest, ProviderCredentials
from app.providers.openai_compatible import OpenAICompatibleAdapter
from tests.conftest import AuthSession, create_provider_and_model

pytestmark = pytest.mark.provider


def _adapter(**overrides) -> OpenAICompatibleAdapter:
    options = {
        "api_key": "sk-test-1234567890",
        "base_url": "https://api.openai.com/v1",
        "connect_timeout": 2,
        "read_timeout": 5,
        "max_retries": 0,
        "provider_slug": "test-provider",
        "provider_name": "Test Provider",
    }
    options.update(overrides)
    return OpenAICompatibleAdapter(ProviderCredentials(**options))


async def _chat(adapter: OpenAICompatibleAdapter, model: str = "gpt-4o-mini"):  # noqa: ANN202
    return await adapter.chat(ChatRequest(model=model, messages=[ChatMessage(role="user", content="hi")]))


@pytest.mark.anyio
async def test_authentication_failure(mock_provider_transport) -> None:
    mock_provider_transport(lambda request: httpx.Response(401, json={"error": {"message": "Incorrect API key provided"}}))
    with pytest.raises(Exception) as excinfo:
        await _chat(_adapter())
    assert getattr(excinfo.value, "category") == AUTHENTICATION


@pytest.mark.anyio
async def test_rate_limit_vs_quota(mock_provider_transport) -> None:
    mock_provider_transport(lambda request: httpx.Response(429, json={"error": {"message": "Rate limit reached"}}))
    with pytest.raises(Exception) as excinfo:
        await _chat(_adapter())
    assert getattr(excinfo.value, "category") == RATE_LIMIT

    mock_provider_transport(lambda request: httpx.Response(429, json={"error": {"message": "You exceeded your current quota"}}))
    with pytest.raises(Exception) as excinfo:
        await _chat(_adapter())
    assert getattr(excinfo.value, "category") == QUOTA_EXHAUSTED


@pytest.mark.anyio
async def test_model_not_found(mock_provider_transport) -> None:
    mock_provider_transport(lambda request: httpx.Response(404, json={"error": {"message": "The model `nope` does not exist"}}))
    with pytest.raises(Exception) as excinfo:
        await _chat(_adapter(), model="nope")
    assert getattr(excinfo.value, "category") == MODEL_NOT_FOUND


@pytest.mark.anyio
async def test_unsupported_operation_category(mock_provider_transport) -> None:
    mock_provider_transport(lambda request: httpx.Response(400, json={"error": {"message": "This endpoint does not support stream"}}))
    with pytest.raises(Exception) as excinfo:
        await _chat(_adapter())
    assert getattr(excinfo.value, "category") == UNSUPPORTED_OPERATION


@pytest.mark.anyio
async def test_timeout_and_connectivity(mock_provider_transport) -> None:
    def timeout_handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ReadTimeout("timed out", request=request)

    mock_provider_transport(timeout_handler)
    with pytest.raises(Exception) as excinfo:
        await _chat(_adapter())
    assert getattr(excinfo.value, "category") == TIMEOUT
    assert getattr(excinfo.value, "retryable") is True

    def connect_handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("connection refused", request=request)

    mock_provider_transport(connect_handler)
    with pytest.raises(Exception) as excinfo:
        await _chat(_adapter())
    assert getattr(excinfo.value, "category") == CONNECTIVITY


@pytest.mark.anyio
async def test_malformed_response(mock_provider_transport) -> None:
    mock_provider_transport(lambda request: httpx.Response(200, text="<html>gateway error</html>"))
    with pytest.raises(Exception) as excinfo:
        await _chat(_adapter())
    assert getattr(excinfo.value, "category") == MALFORMED_RESPONSE


@pytest.mark.anyio
async def test_provider_outage_5xx(mock_provider_transport) -> None:
    mock_provider_transport(lambda request: httpx.Response(503, text="upstream unavailable"))
    with pytest.raises(Exception) as excinfo:
        await _chat(_adapter())
    assert getattr(excinfo.value, "category") == "upstream_server_error"


@pytest.mark.anyio
async def test_unsupported_operation_is_declared(mock_provider_transport) -> None:
    """An adapter must refuse operations it does not implement, without any HTTP call."""
    from app.providers.media import StabilityAdapter

    adapter = StabilityAdapter(ProviderCredentials(api_key="k", base_url="https://api.stability.ai"))
    with pytest.raises(Exception) as excinfo:
        await adapter.chat(ChatRequest(model="core", messages=[ChatMessage(role="user", content="hi")]))
    assert getattr(excinfo.value, "category") == UNSUPPORTED_OPERATION


@pytest.mark.anyio
async def test_retries_on_retryable_errors(mock_provider_transport) -> None:
    calls = {"count": 0}

    def flaky(request: httpx.Request) -> httpx.Response:
        calls["count"] += 1
        if calls["count"] < 3:
            return httpx.Response(503, text="temporarily unavailable")
        return httpx.Response(200, json={
            "id": "x", "choices": [{"index": 0, "message": {"content": "ok"}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2}})

    mock_provider_transport(flaky)
    adapter = _adapter(max_retries=3)
    response = await _chat(adapter)
    assert response.text == "ok"
    assert calls["count"] == 3


@pytest.mark.anyio
async def test_streaming_parses_sse(mock_provider_transport) -> None:
    body = (
        'data: {"id":"c1","choices":[{"delta":{"content":"Hel"},"finish_reason":null}]}\n\n'
        'data: {"id":"c1","choices":[{"delta":{"content":"lo"},"finish_reason":null}]}\n\n'
        'data: {"id":"c1","choices":[{"delta":{},"finish_reason":"stop"}]}\n\n'
        'data: {"id":"c1","choices":[],"usage":{"prompt_tokens":4,"completion_tokens":2,"total_tokens":6}}\n\n'
        "data: [DONE]\n\n"
    )
    mock_provider_transport(lambda request: httpx.Response(200, text=body, headers={"content-type": "text/event-stream"}))
    adapter = _adapter()
    chunks = [chunk async for chunk in adapter.stream_chat(ChatRequest(model="m", messages=[ChatMessage("user", "hi")], stream=True))]
    text = "".join(chunk.delta for chunk in chunks)
    usage = next((chunk.usage for chunk in chunks if chunk.usage), None)
    assert text == "Hello"
    assert usage == {"prompt_tokens": 4, "completion_tokens": 2, "total_tokens": 6}


@pytest.mark.anyio
async def test_stream_error_is_mapped(mock_provider_transport) -> None:
    mock_provider_transport(lambda request: httpx.Response(401, json={"error": {"message": "bad key"}}))
    adapter = _adapter()
    with pytest.raises(Exception) as excinfo:
        async for _ in adapter.stream_chat(ChatRequest(model="m", messages=[ChatMessage("user", "hi")], stream=True)):
            pass
    assert getattr(excinfo.value, "category") == AUTHENTICATION


# ------------------------------------------------------------------ SSRF ------
def test_ssrf_blocks_private_and_metadata_targets() -> None:
    from app.core.net import validate_outbound_url

    for url in (
        "https://169.254.169.254/latest/meta-data/",
        "https://10.0.0.5/v1",
        "https://192.168.1.10/v1",
        "https://127.0.0.1:8000/v1",
        "https://[::1]/v1",
        "http://localhost/v1",
    ):
        check = validate_outbound_url(url)
        assert not check.ok, f"{url} should be blocked"


def test_ssrf_blocks_dns_pointing_at_private_addresses(monkeypatch) -> None:
    import socket

    from app.core.net import validate_outbound_url

    def private_resolution(host, port, *args, **kwargs):  # noqa: ANN001, ANN202
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("10.1.2.3", port or 0))]

    monkeypatch.setattr(socket, "getaddrinfo", private_resolution)
    check = validate_outbound_url("https://internal-gateway.example.com/v1")
    assert not check.ok
    assert "private" in check.reason.lower() or "loopback" in check.reason.lower()


def test_ssrf_allows_public_https() -> None:
    from app.core.net import validate_outbound_url

    assert validate_outbound_url("https://api.openai.com/v1").ok


def test_provider_creation_rejects_metadata_endpoint(admin_client: AuthSession) -> None:
    response = admin_client.post(
        "/api/v1/admin/providers",
        json={"name": "Evil", "provider_type": "openai_compatible",
              "base_url": "https://169.254.169.254/v1", "api_key": "x-key-1234567890"},
    )
    assert response.status_code == 422
    assert "metadata" in response.json()["error"]["message"].lower()


def test_provider_credentials_are_masked_and_encrypted(db: Session, admin_client: AuthSession) -> None:
    from sqlalchemy import select

    from app.models.provider import Provider

    response = admin_client.post(
        "/api/v1/admin/providers",
        json={"name": "Masked Provider", "provider_type": "openai", "base_url": "https://api.openai.com/v1",
              "api_key": "sk-super-secret-value-12345"},
    )
    assert response.status_code == 201, response.text
    payload = response.json()["provider"]
    assert "api_key" not in payload
    # Only the tail is shown: the head of a key carries the account/issuer prefix, and for a Telegram
    # bot token the digits before the colon are the bot id.
    hint = payload["api_key_hint"]
    assert hint.startswith("…") and hint.endswith("2345")
    assert "sk-" not in hint and "secret" not in hint
    assert payload["has_credentials"] is True

    provider = db.scalars(select(Provider).where(Provider.id == payload["id"])).first()
    assert provider is not None
    assert provider.api_key_encrypted and "sk-super-secret-value-12345" not in provider.api_key_encrypted
    from app.core.crypto import decrypt_secret

    assert decrypt_secret(provider.api_key_encrypted) == "sk-super-secret-value-12345"

    # full key never appears in any admin response
    detail = admin_client.get(f"/api/v1/admin/providers/{payload['id']}").text
    assert "sk-super-secret-value-12345" not in detail


def test_connection_test_reports_real_failure(mock_provider_transport, db: Session, admin_client: AuthSession) -> None:
    provider, _ = create_provider_and_model(db, provider_type="openai")
    mock_provider_transport(lambda request: httpx.Response(401, json={"error": {"message": "Invalid API key"}}))
    response = admin_client.post(f"/api/v1/admin/providers/{provider.id}/test")
    assert response.status_code == 200
    result = response.json()["result"]
    assert result["ok"] is False
    assert result["error_category"] == AUTHENTICATION
    assert "Invalid API key" in result["message"]


def test_connection_test_success(mock_provider_transport, db: Session, admin_client: AuthSession) -> None:
    provider, _ = create_provider_and_model(db, provider_type="openai")
    mock_provider_transport(lambda request: httpx.Response(200, json={"data": [{"id": "gpt-4o"}, {"id": "gpt-4o-mini"}]}))
    result = admin_client.post(f"/api/v1/admin/providers/{provider.id}/test").json()["result"]
    assert result["ok"] is True
    assert result["model_count"] == 2


def test_model_sync_never_publishes_new_models(mock_provider_transport, db: Session, admin_client: AuthSession) -> None:
    from sqlalchemy import select

    from app.models.provider import Model

    provider, _ = create_provider_and_model(db, provider_type="openai", model_id_str="existing-model")
    mock_provider_transport(lambda request: httpx.Response(200, json={
        "data": [{"id": "existing-model"}, {"id": "brand-new-model"}]}))

    response = admin_client.post(f"/api/v1/admin/providers/{provider.id}/sync")
    assert response.status_code == 200, response.text
    sync = response.json()["sync"]
    assert sync["created"] == 1
    new_model = db.scalars(select(Model).where(Model.provider_model_id == "brand-new-model")).first()
    assert new_model is not None
    assert new_model.visibility == "hidden"
    assert new_model.published is False
    assert new_model.availability == "untested"
    assert "chat" in new_model.capabilities      # declared by the OpenAI-compatible protocol default (text in/out)
    assert new_model.discovered_by_sync is True

    # the user-facing catalog must not expose the discovered model
    listing = admin_client.get("/api/v1/models")
    titles = [item["provider_model_id"] for item in listing.json()["items"] if item["provider_id"] == provider.id]
    assert "brand-new-model" not in titles


def test_disabled_provider_cannot_be_used(db: Session, admin_client: AuthSession) -> None:
    from sqlalchemy import select

    provider, _ = create_provider_and_model(db, provider_type="openai")
    response = admin_client.patch(f"/api/v1/admin/providers/{provider.id}", json={"enabled": False})
    assert response.status_code == 200
    db.expire_all()
    from app.models.provider import Provider as ProviderModel

    refreshed = db.get(ProviderModel, provider.id)
    assert refreshed is not None and refreshed.enabled is False


def test_keyless_provider_may_only_be_created_as_a_disabled_draft(admin_client: AuthSession) -> None:
    """A provider with no credentials must be a draft, never an enabled row.

    `scripts/seed_demo.py --with-provider` promises a *disabled* placeholder so a fresh
    installation shows a populated admin screen without inventing credentials. The service used to
    reject any credential-less provider, which made that shipped script crash; now the rule is:
    credentials may be missing only while the provider is disabled.
    """
    rejected = admin_client.post(
        "/api/v1/admin/providers",
        json={"name": "Draft without credentials", "provider_type": "openai_compatible",
              "base_url": "https://api.example.com/v1"},
    )
    assert rejected.status_code == 422, rejected.text
    body = rejected.json()["error"]
    assert "requires an API key" in body["message"]
    assert "enabled=false" in body["details"]["hint"]

    draft = admin_client.post(
        "/api/v1/admin/providers",
        json={"name": "Draft without credentials", "provider_type": "openai_compatible",
              "base_url": "https://api.example.com/v1", "enabled": False},
    )
    assert draft.status_code == 201, draft.text
    payload = draft.json()["provider"]
    assert payload["enabled"] is False
    assert payload["has_credentials"] is False
    assert payload["api_key_hint"] is None


def test_keyless_draft_provider_cannot_be_enabled_without_credentials(db: Session, admin_client: AuthSession) -> None:
    from sqlalchemy import select

    from app.models.provider import Provider

    created = admin_client.post(
        "/api/v1/admin/providers",
        json={"name": "Enable me later", "provider_type": "openai_compatible",
              "base_url": "https://api.example.com/v1", "enabled": False},
    )
    assert created.status_code == 201, created.text
    provider_id = created.json()["provider"]["id"]

    blocked = admin_client.patch(f"/api/v1/admin/providers/{provider_id}", json={"enabled": True})
    assert blocked.status_code == 422, blocked.text
    assert "without an API key" in blocked.json()["error"]["message"]
    db.expire_all()
    assert db.get(Provider, provider_id).enabled is False, "a refused enable must not flip the flag"

    # supplying the credential and enabling in one request is allowed
    ok = admin_client.patch(
        f"/api/v1/admin/providers/{provider_id}",
        json={"api_key": "sk-later-1234567890", "enabled": True},
    )
    assert ok.status_code == 200, ok.text
    payload = ok.json()["provider"]
    assert payload["enabled"] is True
    assert payload["has_credentials"] is True
    provider = db.scalars(select(Provider).where(Provider.id == provider_id)).first()
    assert provider is not None and provider.enabled is True


def test_clearing_the_credential_of_an_enabled_provider_is_refused_in_the_same_request(db: Session, admin_client: AuthSession) -> None:
    """`clear_api_key` + `enabled: true` would leave a running provider that cannot authenticate."""
    created = admin_client.post(
        "/api/v1/admin/providers",
        json={"name": "Clearing", "provider_type": "openai_compatible",
              "base_url": "https://api.example.com/v1", "api_key": "sk-clearing-1234567890"},
    )
    assert created.status_code == 201, created.text
    provider_id = created.json()["provider"]["id"]

    blocked = admin_client.patch(
        f"/api/v1/admin/providers/{provider_id}", json={"clear_api_key": True, "enabled": True}
    )
    assert blocked.status_code == 422, blocked.text
    db.expire_all()
    from app.models.provider import Provider as ProviderModel

    provider = db.get(ProviderModel, provider_id)
    assert provider is not None
    assert provider.enabled is True and provider.api_key_encrypted, "the refused patch must not have applied"


def _chat_ok(request: httpx.Request) -> httpx.Response:
    if request.url.path.endswith("/chat/completions"):
        return httpx.Response(200, json={
            "id": "c1", "model": "test-model-1",
            "choices": [{"index": 0, "message": {"role": "assistant", "content": "pong"}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 4, "completion_tokens": 1, "total_tokens": 5},
        })
    return httpx.Response(404, json={"error": {"message": "not found"}})


def test_admin_can_verify_a_model_whose_capabilities_are_still_unknown(db: Session, admin_client: AuthSession, mock_provider_transport) -> None:
    """A freshly synced model has **no** declared capabilities (they are never guessed).

    The administrative test is exactly the tool for finding out what such a model supports, yet it
    used to refuse to run: "Update the model capabilities after verifying them with a supported
    operation" — impossible, because verifying was what had just been refused. The whole provider
    flow therefore dead-ended on the first synced model. An unverified model may now be tested;
    something that declares the *wrong* capability is still refused, and nothing is auto-declared.
    """
    from sqlalchemy import select

    from app.models.provider import Model as ModelModel

    # exactly the state a catalogue sync produces: hidden, unpublished, capabilities unknown
    provider, model = create_provider_and_model(db, provider_type="openai", visibility="hidden", published=False)
    model.capabilities = []
    model.availability = "untested"
    db.commit()
    mock_provider_transport(_chat_ok)

    result = admin_client.post(f"/api/v1/admin/models/{model.id}/test", json={"operation": "chat", "input": "ping"})
    assert result.status_code == 200, result.text
    payload = result.json()
    assert payload["success"] is True, payload
    assert payload["capability_verified"] is False
    assert payload["suggested_capabilities"] == ["chat"], "the admin is told what answered, nothing more"

    db.expire_all()
    refreshed = db.scalars(select(ModelModel).where(ModelModel.id == model.id)).first()
    assert refreshed is not None
    assert refreshed.capabilities == [], "a test must never write capabilities by itself"
    assert refreshed.published is False, "a test must never publish a model"


def test_admin_test_may_probe_an_operation_the_model_does_not_declare(db: Session, admin_client: AuthSession, mock_provider_transport) -> None:
    """Verification must work in the only order that is physically possible.

    The old rule was "declare the capability first, then verify it" — so an administrator could
    never *find out* whether a model streams: the probe was refused because the capability was not
    declared yet, and the message told them to verify first. An administrative probe is now
    allowed, clearly labelled as a verification run, while the user-facing path keeps enforcing
    the capability list (see `services/access.py`) and nothing is written or published.
    """
    from sqlalchemy import select

    from app.models.provider import Model as ModelModel

    provider, model = create_provider_and_model(db, provider_type="openai", capabilities=["chat"])
    mock_provider_transport(_chat_ok)

    probed = admin_client.post(f"/api/v1/admin/models/{model.id}/test",
                               json={"operation": "streaming", "input": "one two three"})
    assert probed.status_code == 200, probed.text
    payload = probed.json()
    assert payload["success"] is True
    assert payload["capability_verified"] is False
    assert payload["suggested_capabilities"] == ["streaming"]
    assert payload["capability_warning"] and "verification run" in payload["capability_warning"]

    db.expire_all()
    refreshed = db.scalars(select(ModelModel).where(ModelModel.id == model.id)).first()
    assert refreshed is not None
    assert refreshed.capabilities == ["chat"], "the probe must not rewrite the declared capabilities"
