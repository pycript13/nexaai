"""File upload security tests (spec §12, §28)."""
from __future__ import annotations

import io
import os

from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.models.files import StoredFile
from tests.conftest import AuthSession

PNG_BYTES = bytes.fromhex(
    "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000a49444154789c63600000020001"
    "0d0a2db40000000049454e44ae426082"
)


def _upload(session: AuthSession, name: str, data: bytes, content_type: str = "application/octet-stream", **extra):  # noqa: ANN201
    return session.post("/api/v1/files", files={"file": (name, io.BytesIO(data), content_type)}, **extra)


def test_valid_upload_and_download_roundtrip(user_client: AuthSession) -> None:
    response = _upload(user_client, "note.txt", b"hello nexa", "text/plain")
    assert response.status_code == 201, response.text
    file_id = response.json()["file"]["id"]
    download = user_client.get(f"/api/v1/files/{file_id}/download")
    assert download.status_code == 200
    assert download.content == b"hello nexa"
    assert "attachment" in download.headers["content-disposition"]


def test_disallowed_extension_is_rejected(user_client: AuthSession) -> None:
    response = _upload(user_client, "payload.exe", b"MZ\x90\x00binary", "application/octet-stream")
    assert response.status_code == 422
    assert "not allowed" in response.json()["error"]["message"].lower()


def test_extension_content_mismatch_is_rejected(user_client: AuthSession) -> None:
    """A .png that is not a PNG (renamed script) must be refused."""
    response = _upload(user_client, "fake.png", b"#!/bin/sh\necho pwned\n", "image/png")
    assert response.status_code == 422
    assert "signature" in response.json()["error"]["message"].lower() or "does not look like" in response.json()["error"]["message"].lower()


def test_path_traversal_filenames_are_neutralised(user_client: AuthSession, db: Session) -> None:
    response = _upload(user_client, "../../../../etc/passwd.txt", b"root:x:0:0", "text/plain")
    assert response.status_code == 201, response.text
    file_id = response.json()["file"]["id"]
    from app.core.config import settings

    record = db.get(StoredFile, file_id)
    assert record is not None
    upload_root = os.path.abspath(settings.upload_dir)
    assert os.path.abspath(record.storage_path).startswith(upload_root)
    assert ".." not in record.storage_path
    # the display name is preserved but never used as a path
    assert record.original_name.endswith("passwd.txt")


def test_oversized_upload_is_rejected(user_client: AuthSession) -> None:
    big = b"A" * (2 * 1024 * 1024)
    response = _upload(user_client, "big.txt", big, "text/plain")
    # the test environment caps uploads at NEXA_MAX_UPLOAD_MB (50 by default),
    # so we assert the configured cap is enforced instead of an arbitrary size
    from app.core.config import settings

    if settings.max_upload_mb * 1024 * 1024 > len(big):
        assert response.status_code == 201
    else:
        assert response.status_code == 422

    # exact over-limit case (over the configured limit by 1 MB)
    oversized = b"A" * (settings.max_upload_mb * 1024 * 1024 + 1024)
    response = _upload(user_client, "huge.txt", oversized, "text/plain")
    assert response.status_code == 413
    assert response.json()["error"]["code"] == "payload_too_large"


def test_unauthorized_download_is_blocked(user_client: AuthSession, second_user_client: AuthSession) -> None:
    response = _upload(user_client, "private.txt", b"secret data", "text/plain")
    file_id = response.json()["file"]["id"]
    assert second_user_client.get(f"/api/v1/files/{file_id}/download").status_code == 403
    assert second_user_client.get(f"/api/v1/files/{file_id}").status_code == 403


def test_anonymous_download_is_blocked(client: TestClient, user_client: AuthSession) -> None:
    response = _upload(user_client, "anon.txt", b"secret", "text/plain")
    file_id = response.json()["file"]["id"]
    assert client.get(f"/api/v1/files/{file_id}/download").status_code == 401


def test_admin_can_download_user_file_for_support(db: Session, user_client: AuthSession, admin_client: AuthSession) -> None:
    from sqlalchemy import select

    from app.models.user import User

    response = _upload(user_client, "support.txt", b"support case", "text/plain")
    file_id = response.json()["file"]["id"]
    user = db.scalars(select(User).where(User.email == user_client.email)).first()
    assert user is not None
    # receiving users.read alone is not enough — that permission is held by support roles
    listing = admin_client.get(f"/api/v1/files/{file_id}")
    assert listing.status_code == 200


def test_delete_file(user_client: AuthSession) -> None:
    response = _upload(user_client, "delete-me.txt", b"bye", "text/plain")
    file_id = response.json()["file"]["id"]
    assert user_client.delete(f"/api/v1/files/{file_id}").status_code == 200
    assert user_client.get(f"/api/v1/files/{file_id}").status_code == 404


def test_text_extraction_for_txt_and_csv(user_client: AuthSession) -> None:
    response = _upload(user_client, "doc.txt", b"line one\nline two", "text/plain", params={"extract": "true"})
    assert response.status_code == 201
    data = response.json()["file"]
    assert "line one" in (data["extracted_text"] or "")

    csv_data = b"name,age\nada,36\nalan,41\n"
    response = _upload(user_client, "table.csv", csv_data, "text/csv")
    file_id = response.json()["file"]["id"]
    extracted = user_client.post(f"/api/v1/files/{file_id}/extract").json()
    assert "ada" in extracted["text"]


def test_extraction_rejects_unsupported_type(user_client: AuthSession) -> None:
    response = _upload(user_client, "pic.png", PNG_BYTES, "image/png")
    file_id = response.json()["file"]["id"]
    result = user_client.post(f"/api/v1/files/{file_id}/extract")
    assert result.status_code == 422
    assert "not supported" in result.json()["error"]["message"].lower()


def test_storage_summary_reports_quota(user_client: AuthSession) -> None:
    _upload(user_client, "quota.txt", b"x" * 1024, "text/plain")
    summary = user_client.get("/api/v1/files/storage/summary").json()
    assert summary["used_bytes"] >= 1024
    assert summary["quota_bytes"] > 0
    assert summary["malware_scanning"]["enabled"] is False  # explicitly reported, not assumed
