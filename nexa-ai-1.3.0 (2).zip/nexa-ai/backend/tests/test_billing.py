"""Billing & ledger integrity tests (spec §13, §14, §28)."""
from __future__ import annotations

import threading

import httpx
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.billing import LedgerEntry, LedgerEntryType, PaymentStatus
from app.services import ledger as ledger_service
from app.services import pricing as pricing_service
from app.services import usage as usage_service
from tests.conftest import AuthSession, create_provider_and_model, grant_credits


def _user_id(db: Session, email: str) -> int:
    from app.models.user import User

    user = db.scalars(select(User).where(User.email == email)).first()
    assert user is not None
    return user.id


def test_balance_changes_always_create_ledger_entries(db: Session, user_client: AuthSession) -> None:
    user_id = _user_id(db, user_client.email)
    grant_credits(db, user_client.email, 10.0)
    entries = db.scalars(select(LedgerEntry).where(LedgerEntry.user_id == user_id)).all()
    assert entries and all(entry.amount_micro != 0 for entry in entries)
    balance = ledger_service.balance_of(db, user_id)
    assert balance == sum(entry.amount_micro for entry in entries) + _initial_balance(db, user_id, entries)


def _initial_balance(db: Session, user_id: int, entries) -> int:  # noqa: ANN001
    from app.models.billing import CreditAccount

    account = db.scalars(select(CreditAccount).where(CreditAccount.user_id == user_id)).first()
    return 0 if account is not None else 0


def test_idempotent_credit_is_applied_once(db: Session, user_client: AuthSession) -> None:
    user_id = _user_id(db, user_client.email)
    key = "idempotency-test-key-1"
    first = ledger_service.credit(db, user_id=user_id, amount_micro=5_000_000, idempotency_key=key, description="first")
    db.commit()
    second = ledger_service.credit(db, user_id=user_id, amount_micro=5_000_000, idempotency_key=key, description="duplicate")
    db.commit()
    assert first.created is True and second.created is False
    assert second.balance_after_micro == first.balance_after_micro
    entries = db.scalars(select(LedgerEntry).where(LedgerEntry.idempotency_key == key)).all()
    assert len(entries) == 1


def test_insufficient_balance_is_rejected(db: Session, user_client: AuthSession) -> None:
    user_id = _user_id(db, user_client.email)
    from app.core.errors import InsufficientBalance

    with pytest.raises(InsufficientBalance):
        ledger_service.debit(db, user_id=user_id, amount_micro=99_000_000, idempotency_key="debit-too-big")
    db.rollback()


def test_concurrent_debits_cannot_overdraw(db: Session, user_client: AuthSession) -> None:
    """20 parallel debits of 1 credit against a 10 credit balance."""
    user_id = _user_id(db, user_client.email)
    start = ledger_service.balance_of(db, user_id)
    ledger_service.credit(db, user_id=user_id, amount_micro=10_000_000, idempotency_key="concurrency-topup", description="funding")
    db.commit()
    opening = ledger_service.balance_of(db, user_id)
    assert opening == start + 10_000_000

    from app.db.session import SessionLocal

    results: list[bool] = []

    def worker(index: int) -> None:
        session = SessionLocal()
        try:
            ledger_service.debit(session, user_id=user_id, amount_micro=1_000_000,
                                 idempotency_key=f"concurrent-{index}", description="parallel debit")
            session.commit()
            results.append(True)
        except Exception:  # noqa: BLE001 - insufficient balance is expected for some
            session.rollback()
            results.append(False)
        finally:
            session.close()

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(20)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    assert sum(1 for ok in results if ok) == 10, f"expected exactly 10 successful debits, got {results}"
    final = ledger_service.balance_of(db, user_id)
    assert final == start
    report = ledger_service.reconcile(db, user_id)
    assert report["consistent"] is True


def test_failed_provider_request_is_not_charged(
    db: Session, user_client: AuthSession, mock_provider_transport
) -> None:
    from app.models.user import User

    grant_credits(db, user_client.email, 5.0)
    provider, model = create_provider_and_model(db, capabilities=["chat"])
    mock_provider_transport(lambda request: httpx.Response(500, text="boom"))
    before = user_client.get("/api/v1/billing/balance").json()["balance_micro"]
    response = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hello"})
    assert response.status_code == 502
    after = user_client.get("/api/v1/billing/balance").json()["balance_micro"]
    assert after == before, "a failed provider call must not be charged"
    user = db.scalars(select(User).where(User.email == user_client.email)).first()
    assert user is not None
    usage = db.scalars(
        select(usage_service.UsageRecord).where(usage_service.UsageRecord.user_id == user.id)
    ).all()
    assert any(record.status == "failed" for record in usage)
    assert all(record.charged_micro == 0 for record in usage if record.status == "failed")


def test_successful_chat_is_charged_and_usage_recorded(
    db: Session, user_client: AuthSession, mock_provider_transport
) -> None:
    grant_credits(db, user_client.email, 5.0)
    provider, model = create_provider_and_model(db, input_price=1000.0, output_price=2000.0, capabilities=["chat"])
    mock_provider_transport(lambda request: httpx.Response(200, json={
        "id": "cc-1", "model": "test-model-1",
        "choices": [{"index": 0, "message": {"role": "assistant", "content": "Hello there"}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 100, "completion_tokens": 50, "total_tokens": 150}}))
    before = user_client.get("/api/v1/billing/balance").json()["balance_micro"]
    response = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hello"})
    assert response.status_code == 200, response.text
    body = response.json()
    expected = 100 * 1000 + 50 * 2000  # micro-credits (rate is per 1M tokens; 1M cancels at 100/50 tokens)
    assert body["usage"]["charged_micro"] == expected
    assert body["usage"]["prompt_tokens"] == 100
    assert body["usage"]["usage_source"] == "provider_reported"

    after = user_client.get("/api/v1/billing/balance").json()["balance_micro"]
    assert after == before - expected

    ledger = user_client.get("/api/v1/billing/ledger").json()["items"]
    charge = next(item for item in ledger if item["type"] == LedgerEntryType.USAGE_CHARGE)
    assert charge["amount_micro"] == -expected
    assert charge["balance_after_micro"] == after


def test_pricing_uses_decimal_integer_arithmetic() -> None:
    """Prices are micro-credits per 1M tokens: 3 credits/MTok == 3_000_000 micro/MTok."""
    from app.services.pricing import PriceQuote, compute_charge

    quote = PriceQuote(input_per_mtok_micro=3_000_000, output_per_mtok_micro=15_000_000, minimum_charge_micro=100)
    breakdown = compute_charge(quote, prompt_tokens=1_000_000, completion_tokens=1_000_000)
    assert breakdown.charged_micro == 3_000_000 + 15_000_000  # 3 + 15 credits
    assert isinstance(breakdown.charged_micro, int)
    no_minimum = PriceQuote(input_per_mtok_micro=3_000_000, output_per_mtok_micro=15_000_000, minimum_charge_micro=0)
    exact = compute_charge(no_minimum, prompt_tokens=7, completion_tokens=3)
    assert exact.charged_micro == 7 * 3 + 3 * 15  # integer arithmetic, no rounding drift
    sub_minimum = compute_charge(quote, prompt_tokens=1, completion_tokens=1)
    assert sub_minimum.charged_micro == 100 and sub_minimum.minimum_applied is True


def test_manual_payment_requires_admin_approval(
    db: Session, user_client: AuthSession, admin_client: AuthSession
) -> None:
    from app.models.user import User

    user_id = _user_id(db, user_client.email)
    before = ledger_service.balance_of(db, user_id)
    create = user_client.post("/api/v1/billing/payments", json={
        "amount_micro": 20_000_000, "method": "manual_bank_transfer",
        "payer_name": "Test User", "bank_reference": "TRX-123456"})
    assert create.status_code == 201, create.text
    payment = create.json()["payment"]
    assert payment["status"] == PaymentStatus.AWAITING_REVIEW
    assert payment["verified_by_platform"] is False

    # submitting the request must NOT credit the balance
    assert ledger_service.balance_of(db, user_id) == before

    approve = admin_client.post(f"/api/v1/admin/billing/payments/{payment['id']}/approve",
                                json={"note": "verified against bank statement", "confirm": True})
    assert approve.status_code == 200, approve.text
    assert approve.json()["credited_micro"] == 20_000_000
    assert ledger_service.balance_of(db, user_id) == before + 20_000_000

    # approving twice must not credit twice
    second = admin_client.post(f"/api/v1/admin/billing/payments/{payment['id']}/approve",
                               json={"confirm": True})
    assert second.status_code == 422
    assert ledger_service.balance_of(db, user_id) == before + 20_000_000


def test_payment_approval_requires_confirmation_flag(user_client: AuthSession, admin_client: AuthSession) -> None:
    create = user_client.post("/api/v1/billing/payments", json={"amount_micro": 5_000_000, "method": "manual_bank_transfer"})
    payment_id = create.json()["payment"]["id"]
    response = admin_client.post(f"/api/v1/admin/billing/payments/{payment_id}/approve", json={})
    assert response.status_code == 422
    assert "confirmation" in response.json()["error"]["message"].lower()


def test_users_cannot_approve_their_own_payment(user_client: AuthSession) -> None:
    create = user_client.post("/api/v1/billing/payments", json={"amount_micro": 5_000_000, "method": "manual_bank_transfer"})
    payment_id = create.json()["payment"]["id"]
    response = user_client.post(f"/api/v1/admin/billing/payments/{payment_id}/approve",
                                json={"confirm": True})
    assert response.status_code == 403


def test_payment_amount_validation(user_client: AuthSession) -> None:
    assert user_client.post("/api/v1/billing/payments", json={"amount_micro": 10, "method": "manual_bank_transfer"}).status_code == 422
    assert user_client.post("/api/v1/billing/payments", json={"amount_micro": 999_000_000_000, "method": "manual_bank_transfer"}).status_code == 422


def test_crypto_payment_disabled_by_default(user_client: AuthSession) -> None:
    response = user_client.post("/api/v1/billing/payments", json={
        "amount_micro": 5_000_000, "method": "crypto", "crypto_asset": "USDT-TRC20"})
    assert response.status_code == 503
    assert response.json()["error"]["category"] == "configuration_error"


def test_refund_posts_compensating_entry(db: Session, user_client: AuthSession, admin_client: AuthSession) -> None:
    user_id = _user_id(db, user_client.email)
    create = user_client.post("/api/v1/billing/payments", json={"amount_micro": 30_000_000, "method": "manual_bank_transfer"})
    payment_id = create.json()["payment"]["id"]
    admin_client.post(f"/api/v1/admin/billing/payments/{payment_id}/approve", json={"confirm": True})
    balance_after_approval = ledger_service.balance_of(db, user_id)

    refund = admin_client.post(f"/api/v1/admin/billing/payments/{payment_id}/refund",
                               json={"amount_micro": 10_000_000, "reason": "partial refund per request", "confirm": True})
    assert refund.status_code == 200, refund.text
    assert refund.json()["status"] == PaymentStatus.PARTIALLY_REFUNDED
    assert ledger_service.balance_of(db, user_id) == balance_after_approval - 10_000_000

    entry = db.scalars(
        select(LedgerEntry).where(LedgerEntry.entry_type == LedgerEntryType.REFUND).order_by(LedgerEntry.id.desc())
    ).first()
    assert entry is not None and entry.amount_micro == -10_000_000


def test_refund_requires_permission(user_client: AuthSession, admin_client: AuthSession) -> None:
    create = user_client.post("/api/v1/billing/payments", json={"amount_micro": 3_000_000, "method": "manual_bank_transfer"})
    payment_id = create.json()["payment"]["id"]
    admin_client.post(f"/api/v1/admin/billing/payments/{payment_id}/approve", json={"confirm": True})
    response = user_client.post(f"/api/v1/admin/billing/payments/{payment_id}/refund",
                                json={"amount_micro": 1_000_000, "reason": "me me me", "confirm": True})
    assert response.status_code == 403


def test_ledger_is_immutable_through_the_api(db: Session, user_client: AuthSession) -> None:
    """No API surface may update or delete ledger rows."""
    grant_credits(db, user_client.email, 1.0)
    entry = db.scalars(select(LedgerEntry).order_by(LedgerEntry.id.desc())).first()
    assert entry is not None
    for path in (f"/api/v1/billing/ledger/{entry.id}", f"/api/v1/admin/billing/ledger/{entry.id}"):
        assert user_client.delete(path).status_code in (403, 404, 405)
        assert user_client.patch(path, json={"amount_micro": 0}).status_code in (403, 404, 405)


def test_admin_reports_are_consistent(db: Session, admin_client: AuthSession) -> None:
    report = admin_client.get("/api/v1/admin/billing/reports?days=30")
    assert report.status_code == 200
    data = report.json()
    assert data["ledger_consistency"]["inconsistent"] == 0
    assert "revenue_vs_cost" in data


def test_daily_limit_blocks_further_spending(db: Session, user_client: AuthSession, mock_provider_transport) -> None:
    grant_credits(db, user_client.email, 50.0)
    provider, model = create_provider_and_model(db, input_price=1000.0, output_price=1000.0, capabilities=["chat"])
    from app.models.user import User

    user = db.scalars(select(User).where(User.email == user_client.email)).first()
    assert user is not None
    account = ledger_service.get_account(db, user.id)
    account.daily_spend_limit_micro = 1000
    db.commit()
    mock_provider_transport(lambda request: httpx.Response(200, json={
        "id": "c", "choices": [{"index": 0, "message": {"content": "hi"}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 10, "completion_tokens": 10, "total_tokens": 20}}))
    response = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hello"})
    assert response.status_code == 429
    assert response.json()["error"]["code"] == "rate_limited"
    assert response.json()["error"]["details"]["scope"] == "account_daily_spend"


def test_realistically_priced_model_is_actually_charged_end_to_end(
    db: Session, user_client: AuthSession, mock_provider_transport
) -> None:
    """Full-stack money truth: a cheap model (0.28 / 1.10 credits per MTok) must bill.

    This is the regression guard for the unit bug that made every sub-1-credit-per-MTok
    price (i.e. every real provider price) round to zero: the chat call answered 200,
    the usage row said "succeeded", and the balance never moved. The assertion is on the
    *balance delta and the immutable ledger entry*, not on the response body alone.
    """
    grant_credits(db, user_client.email, 5.0)
    provider, model = create_provider_and_model(
        db, input_price=0.28, output_price=1.10, capabilities=["chat"]
    )
    mock_provider_transport(lambda request: httpx.Response(200, json={
        "id": "cc-cheap", "model": "test-model-1",
        "choices": [{"index": 0, "message": {"role": "assistant", "content": "cheap answer"}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 100_000, "completion_tokens": 20_000, "total_tokens": 120_000}}))

    before = user_client.get("/api/v1/billing/balance").json()["balance_micro"]
    response = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hello"})
    assert response.status_code == 200, response.text

    # 100_000 * 0.28 + 20_000 * 1.10 = 28_000 + 22_000 = 50_000 micro-credits = 0.05 credits
    expected = 50_000
    assert response.json()["usage"]["charged_micro"] == expected, response.json()["usage"]

    after = user_client.get("/api/v1/billing/balance").json()["balance_micro"]
    assert after == before - expected, "the balance must move by exactly the charged amount"

    usage = user_client.get("/api/v1/billing/usage", params={"page_size": 5}).json()["items"]
    row = next(item for item in usage if item.get("model_id") == model.id)
    assert row["charged_micro"] == expected
    assert row["status"] == "succeeded"

    ledger = user_client.get("/api/v1/billing/ledger").json()["items"]
    charge = next(item for item in ledger if item["type"] == LedgerEntryType.USAGE_CHARGE)
    assert charge["amount_micro"] == -expected
    assert charge["balance_after_micro"] == after


def test_a_model_below_one_credit_per_mtok_still_writes_a_ledger_entry(
    db: Session, user_client: AuthSession, mock_provider_transport
) -> None:
    """The smallest realistic price must still produce a *non-zero* immutable entry.

    The platform applies a minimum charge to small amounts (1000 micro-credits by default),
    so an 0.05 credits/MTok model with a short answer is charged the minimum rather than
    nothing — and the usage row records which rule priced it.
    """
    grant_credits(db, user_client.email, 5.0)
    provider, model = create_provider_and_model(
        db, input_price=0.05, output_price=0.05, capabilities=["chat"]
    )
    mock_provider_transport(lambda request: httpx.Response(200, json={
        "id": "cc-tiny", "model": "test-model-1",
        "choices": [{"index": 0, "message": {"role": "assistant", "content": "ok"}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 11, "completion_tokens": 7, "total_tokens": 18}}))

    before = user_client.get("/api/v1/billing/balance").json()["balance_micro"]
    response = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hi"})
    assert response.status_code == 200, response.text
    charged = response.json()["usage"]["charged_micro"]
    assert charged > 0, "an 0.05 credits/MTok model must never be billed as free"

    after = user_client.get("/api/v1/billing/balance").json()["balance_micro"]
    assert after == before - charged
