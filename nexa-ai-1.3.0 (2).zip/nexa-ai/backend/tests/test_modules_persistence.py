"""Persistence guarantees for the module endpoints (coding, translation, image, audio, data).

These endpoints report a charge and a stored file in their response, so the same
charge (usage record + credit ledger) and the file row must exist afterwards.
Regression tests for the defect where six handlers returned 200 with a charge but
never committed the transaction, leaving the user uncharged and the generated file
orphaned on disk.
"""
from __future__ import annotations

import base64
import io
import json
import struct

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.billing import UsageRecord
from app.models.files import StoredFile
from tests.conftest import AuthSession, create_provider_and_model, grant_credits

# 1x1 transparent PNG
PNG_BYTES = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
)


def _wav_bytes(seconds: int = 1) -> bytes:
    frames = b"\x00\x00" * (8000 * seconds)
    return (
        b"RIFF" + struct.pack("<I", 36 + len(frames)) + b"WAVEfmt "
        + struct.pack("<IHHIIHH", 16, 1, 1, 8000, 16000, 2, 16)
        + b"data" + struct.pack("<I", len(frames)) + frames
    )


def _chat_handler(text: str = "module-answer"):
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/chat/completions"):
            return httpx.Response(
                200,
                json={
                    "id": "c-mod",
                    "model": "test-model-1",
                    "choices": [{"index": 0, "message": {"role": "assistant", "content": text}, "finish_reason": "stop"}],
                    "usage": {"prompt_tokens": 12, "completion_tokens": 6, "total_tokens": 18},
                },
            )
        return httpx.Response(404, json={"error": {"message": f"no mock for {request.url.path}"}})

    return handler


def _balance_micro(session: AuthSession) -> int:
    return session.get("/api/v1/billing/balance").json()["balance_micro"]


def _usage_rows(db: Session, user_id: int, operation: str) -> list[UsageRecord]:
    return list(
        db.scalars(
            select(UsageRecord).where(UsageRecord.user_id == user_id, UsageRecord.operation == operation)
        ).all()
    )


def test_coding_assist_persists_usage_and_charges(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    grant_credits(db, user_client.email, 20.0)
    _, model = create_provider_and_model(db, capabilities=["chat"], model_id_str="code-model")
    mock_provider_transport(_chat_handler("def add(a, b):\n    return a + b"))

    before = _balance_micro(user_client)
    response = user_client.post(
        "/api/v1/modules/coding/assist",
        json={"model_id": model.id, "prompt": "write an add function", "mode": "generate", "language": "python"},
    )
    assert response.status_code == 200, response.text
    payload = response.json()
    charged = payload["usage"]["charged_micro"]
    assert charged > 0

    # the charge must exist in the database, not only in the response
    rows = _usage_rows(db, db.scalars(select(__import__("app.models.user", fromlist=["User"]).User).where(
        __import__("app.models.user", fromlist=["User"]).User.email == user_client.email)).one().id, "chat")
    assert rows, "coding assist did not persist a usage record"
    assert any(row.charged_micro == charged for row in rows)
    assert _balance_micro(user_client) == before - charged


def test_translation_persists_usage_for_every_item(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    grant_credits(db, user_client.email, 20.0)
    _, model = create_provider_and_model(db, capabilities=["chat"], model_id_str="translate-model")
    mock_provider_transport(_chat_handler("translated text"))

    response = user_client.post(
        "/api/v1/modules/translation/translate",
        json={"model_id": model.id, "texts": ["one", "two", "three"], "target_language": "Persian", "source_language": "en"},
    )
    assert response.status_code == 200, response.text
    payload = response.json()
    assert len(payload["items"]) == 3
    assert payload["usage"]["charged_micro"] > 0

    from app.models.user import User

    user = db.scalars(select(User).where(User.email == user_client.email)).one()
    rows = _usage_rows(db, user.id, "chat")
    assert len([row for row in rows if row.module == "translation"]) >= 3, "each translated item must be recorded"


def test_image_generation_persists_file_and_charge(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    grant_credits(db, user_client.email, 20.0)
    _, model = create_provider_and_model(
        db,
        capabilities=["image_generation"],
        model_id_str="image-model",
        input_price=None,
        output_price=None,
    )
    # image work is billed per image, not per token
    model.selling_per_image = 0.25
    db.commit()

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/images/generations"):
            return httpx.Response(
                200,
                json={"created": 1700000000, "data": [{"b64_json": base64.b64encode(PNG_BYTES).decode(), "revised_prompt": "a dot"}]},
            )
        return httpx.Response(404, json={"error": {"message": "no mock"}})

    mock_provider_transport(handler)
    before = _balance_micro(user_client)
    response = user_client.post(
        "/api/v1/modules/image/generate",
        json={"model_id": model.id, "prompt": "a dot", "n": 1, "size": "256x256"},
    )
    assert response.status_code == 200, response.text
    images = response.json()["images"]
    assert images, "no image was returned"
    file_id = images[0]["file_id"]

    record = db.get(StoredFile, file_id)
    assert record is not None, "the generated image was reported but never stored in the database"
    assert record.kind == "generated"

    # the file must be downloadable through the public file route
    download = user_client.get(f"/api/v1/files/{file_id}/download")
    assert download.status_code == 200, download.text
    assert download.content, "downloaded file is empty"

    charged = response.json()["usage"]["charged_micro"]
    assert charged > 0, "image generation must be charged"
    assert _balance_micro(user_client) == before - charged


def test_speech_generation_persists_file_and_charge(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    grant_credits(db, user_client.email, 20.0)
    _, model = create_provider_and_model(
        db,
        capabilities=["speech_generation"],
        model_id_str="tts-model",
        input_price=None,
        output_price=None,
    )
    model.selling_per_audio_minute = 0.6
    db.commit()

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/audio/speech"):
            return httpx.Response(200, content=_wav_bytes(1), headers={"content-type": "audio/wav"})
        return httpx.Response(404, json={"error": {"message": "no mock"}})

    mock_provider_transport(handler)
    before = _balance_micro(user_client)
    response = user_client.post(
        "/api/v1/modules/audio/speak",
        json={"model_id": model.id, "text": "Hello from the test suite", "voice": "alloy"},
    )
    assert response.status_code == 200, response.text
    file_id = response.json()["file_id"]
    assert db.get(StoredFile, file_id) is not None, "generated audio was not persisted"

    download = user_client.get(f"/api/v1/files/{file_id}/download")
    assert download.status_code == 200, download.text

    charged = response.json()["usage"]["charged_micro"]
    assert charged > 0
    assert _balance_micro(user_client) == before - charged


def test_data_analysis_persists_usage_and_charge(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    grant_credits(db, user_client.email, 20.0)
    _, model = create_provider_and_model(db, capabilities=["chat"], model_id_str="analyst-model")
    mock_provider_transport(_chat_handler("The data shows a steady rise."))

    csv = "month,revenue\nJanuary,100\nFebruary,140\nMarch,190\n".encode()
    upload = user_client.post(
        "/api/v1/files",
        files={"file": ("sales.csv", csv, "text/csv")},
    )
    assert upload.status_code in (200, 201), upload.text
    file_id = (upload.json().get("file") or upload.json())["id"]

    response = user_client.post(
        "/api/v1/modules/data/analyze",
        json={"file_id": file_id, "model_id": model.id, "question": "What is the trend?", "narrative": True},
    )
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["computed_locally"]["statistics"] is True, "statistics must be computed on the server"
    charged = payload["usage"]["charged_micro"]
    assert charged > 0, "the narrative call must be charged"

    from app.models.user import User

    user = db.scalars(select(User).where(User.email == user_client.email)).one()
    assert _usage_rows(db, user.id, "chat"), "data analysis did not persist the usage record"
    assert _balance_micro(user_client) > 0  # sanity: the account is still readable
