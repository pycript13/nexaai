"""Workspace tests: conversations, streaming, error handling, modules."""
from __future__ import annotations

import json

import httpx
import pytest
from sqlalchemy.orm import Session

from app.models.chat import Conversation, Message
from tests.conftest import AuthSession, create_provider_and_model, grant_credits


def _chat_ok(request: httpx.Request) -> httpx.Response:
    if request.url.path.endswith("/chat/completions"):
        payload = json.loads(request.content.decode())
        if payload.get("stream"):
            body = (
                'data: {"id":"s1","choices":[{"delta":{"content":"Hi"},"finish_reason":null}]}\n\n'
                'data: {"id":"s1","choices":[{"delta":{"content":" there"},"finish_reason":null}]}\n\n'
                'data: {"id":"s1","choices":[{"delta":{},"finish_reason":"stop"}]}\n\n'
                'data: {"id":"s1","choices":[],"usage":{"prompt_tokens":6,"completion_tokens":2,"total_tokens":8}}\n\n'
                "data: [DONE]\n\n"
            )
            return httpx.Response(200, text=body, headers={"content-type": "text/event-stream"})
        return httpx.Response(200, json={
            "id": "c1", "model": "test-model-1",
            "choices": [{"index": 0, "message": {"role": "assistant", "content": "Hi there"}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 6, "completion_tokens": 2, "total_tokens": 8},
        })
    return httpx.Response(404, json={"error": {"message": "not found"}})


def test_conversation_lifecycle(user_client: AuthSession) -> None:
    created = user_client.post("/api/v1/chat/conversations", json={"title": "My chat"}).json()["conversation"]
    conversation_id = created["id"]
    listing = user_client.get("/api/v1/chat/conversations").json()
    assert any(item["id"] == conversation_id for item in listing["items"])
    renamed = user_client.patch(f"/api/v1/chat/conversations/{conversation_id}",
                                json={"title": "Renamed", "pinned": True}).json()["conversation"]
    assert renamed["title"] == "Renamed" and renamed["pinned"] is True
    search = user_client.get("/api/v1/chat/conversations?search=renamed").json()
    assert any(item["id"] == conversation_id for item in search["items"])
    archived = user_client.patch(f"/api/v1/chat/conversations/{conversation_id}", json={"archived": True}).json()
    assert archived["conversation"]["archived"] is True
    assert user_client.get("/api/v1/chat/conversations").json()["items"] == []
    assert user_client.delete(f"/api/v1/chat/conversations/{conversation_id}").status_code == 200
    assert user_client.get(f"/api/v1/chat/conversations/{conversation_id}").status_code == 404


def test_conversations_are_private(user_client: AuthSession, second_user_client: AuthSession) -> None:
    conversation_id = user_client.post("/api/v1/chat/conversations", json={"title": "private"}).json()["conversation"]["id"]
    assert second_user_client.get(f"/api/v1/chat/conversations/{conversation_id}").status_code == 404
    assert second_user_client.delete(f"/api/v1/chat/conversations/{conversation_id}").status_code == 404


def test_chat_without_configured_provider_returns_actionable_error(user_client: AuthSession, db: Session) -> None:
    """No fake answers: the API must explain what is missing (spec §10)."""
    from app.models.user import User
    from sqlalchemy import select

    grant_credits(db, user_client.email, 5.0)
    user = db.scalars(select(User).where(User.email == user_client.email)).first()
    assert user is not None
    # a model that exists but whose provider has no credentials
    provider, model = create_provider_and_model(db, api_key="", capabilities=["chat"])
    provider.api_key_encrypted = None
    db.commit()
    response = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hello"})
    assert response.status_code == 503
    body = response.json()["error"]
    assert body["category"] == "configuration_error"
    assert "credential" in body["message"].lower()


def test_chat_persists_messages_and_charges(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    grant_credits(db, user_client.email, 10.0)
    provider, model = create_provider_and_model(db, capabilities=["chat"])
    mock_provider_transport(_chat_ok)
    response = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hello"})
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["message"]["content"] == "Hi there"
    conversation_id = body["conversation"]["id"]
    detail = user_client.get(f"/api/v1/chat/conversations/{conversation_id}").json()
    roles = [message["role"] for message in detail["messages"]]
    assert roles == ["user", "assistant"]
    assert detail["messages"][1]["prompt_tokens"] == 6
    assert body["usage"]["charged_micro"] > 0
    # export
    export = user_client.get(f"/api/v1/chat/conversations/{conversation_id}/export?format=json").json()
    assert "Hi there" in export["content"]
    markdown = user_client.get(f"/api/v1/chat/conversations/{conversation_id}/export?format=markdown").json()
    assert markdown["filename"].endswith(".md")


def test_streaming_chat_emits_sse_events(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    grant_credits(db, user_client.email, 10.0)
    provider, model = create_provider_and_model(db, capabilities=["chat", "streaming"])
    mock_provider_transport(_chat_ok)
    with user_client.client.stream("POST", "/api/v1/chat/stream",
                                   json={"model_id": model.id, "message": "hi", "stream": True},
                                   headers=user_client.headers, cookies=user_client.cookies) as response:
        assert response.status_code == 200
        payload = "".join(chunk for chunk in response.iter_text())
    events = [line for line in payload.splitlines() if line.startswith("event:")]
    assert "event: meta" in events and "event: delta" in events and "event: done" in events
    assert "Hi" in payload and "there" in payload
    done_payload = json.loads([line for line in payload.splitlines() if line.startswith("data:")][-1][5:])
    assert done_payload["prompt_tokens"] == 6
    assert done_payload["charged_micro"] >= 0

    # messages were persisted for the streamed turn
    conversations = user_client.get("/api/v1/chat/conversations").json()["items"]
    assert conversations
    detail = user_client.get(f"/api/v1/chat/conversations/{conversations[0]['id']}").json()
    assert detail["messages"][-1]["content"] == "Hi there"


def test_streaming_provider_failure_reports_category(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    grant_credits(db, user_client.email, 10.0)
    provider, model = create_provider_and_model(db, capabilities=["chat", "streaming"])
    mock_provider_transport(lambda request: httpx.Response(401, json={"error": {"message": "invalid api key"}}))
    with user_client.client.stream("POST", "/api/v1/chat/stream",
                                   json={"model_id": model.id, "message": "hi"},
                                   headers=user_client.headers, cookies=user_client.cookies) as response:
        payload = "".join(chunk for chunk in response.iter_text())
    assert "event: error" in payload
    assert "authentication" in payload


def test_regenerate_appends_a_variant(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    grant_credits(db, user_client.email, 10.0)
    provider, model = create_provider_and_model(db, capabilities=["chat"])
    mock_provider_transport(_chat_ok)
    body = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hello"}).json()
    conversation_id = body["conversation"]["id"]
    regenerated = user_client.post(f"/api/v1/chat/conversations/{conversation_id}/regenerate")
    assert regenerated.status_code == 200, regenerated.text
    detail = user_client.get(f"/api/v1/chat/conversations/{conversation_id}").json()
    assert [message["role"] for message in detail["messages"]] == ["user", "assistant", "assistant"]
    assert [message["status"] for message in detail["messages"][1:]] == ["superseded", "complete"]


def test_edit_and_resubmit_drops_later_messages(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    grant_credits(db, user_client.email, 10.0)
    provider, model = create_provider_and_model(db, capabilities=["chat"])
    mock_provider_transport(_chat_ok)
    body = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "first"}).json()
    conversation_id = body["conversation"]["id"]
    detail = user_client.get(f"/api/v1/chat/conversations/{conversation_id}").json()
    user_message_id = detail["messages"][0]["id"]
    resubmit = user_client.post(f"/api/v1/chat/messages/{user_message_id}/resubmit", json={"content": "edited prompt"})
    assert resubmit.status_code == 200, resubmit.text
    detail = user_client.get(f"/api/v1/chat/conversations/{conversation_id}").json()
    assert detail["messages"][0]["content"] == "edited prompt"
    assert len(detail["messages"]) == 2


def test_model_capabilities_endpoint_reports_availability(user_client: AuthSession, db: Session) -> None:
    grant_credits(db, user_client.email, 5.0)
    provider, model = create_provider_and_model(db, capabilities=["chat", "streaming"])
    data = user_client.get("/api/v1/modules/capabilities").json()["modules"]
    assert data["chat"]["available"] is True
    assert data["audio"]["available"] is False
    assert "administrator" in data["audio"]["message"]


def test_unsupported_operation_returns_configuration_error(user_client: AuthSession, db: Session) -> None:
    grant_credits(db, user_client.email, 5.0)
    provider, other = create_provider_and_model(db, capabilities=["chat"], model_id_str="chat-only")
    # a chat-only model cannot generate images
    response = user_client.post("/api/v1/modules/image/generate", json={"model_id": other.id, "prompt": "a cat"})
    assert response.status_code == 403
    assert response.json()["error"]["code"] == "model_not_accessible"
    assert response.json()["error"]["details"]["code"] == "operation_unsupported"


def test_translation_module_uses_chat_model(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    grant_credits(db, user_client.email, 10.0)
    provider, model = create_provider_and_model(db, capabilities=["chat"])
    mock_provider_transport(_chat_ok)
    response = user_client.post("/api/v1/modules/translation/translate",
                                json={"model_id": model.id, "text": "Good morning", "target_language": "Persian",
                                      "source_language": "English"})
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["items"][0]["translation"]
    assert payload["usage"]["charged_micro"] >= 0


def test_coding_module_refuses_unknown_mode(user_client: AuthSession, db: Session) -> None:
    grant_credits(db, user_client.email, 5.0)
    provider, model = create_provider_and_model(db, capabilities=["chat"])
    response = user_client.post("/api/v1/modules/coding/assist",
                                json={"model_id": model.id, "mode": "hack", "prompt": "do something"})
    assert response.status_code == 422


def test_data_analysis_computes_real_statistics(user_client: AuthSession, db: Session) -> None:
    import io

    csv_bytes = b"city,temp\nHelsinki,5\nTehran,21\nHelsinki,3\nTehran,25\n"
    upload = user_client.post("/api/v1/files", files={"file": ("weather.csv", io.BytesIO(csv_bytes), "text/csv")})
    file_id = upload.json()["file"]["id"]
    response = user_client.post("/api/v1/modules/data/analyze", json={"file_id": file_id, "narrative": False})
    assert response.status_code == 200, response.text
    stats = response.json()["statistics"]
    assert stats["row_count"] == 4
    temp_column = next(column for column in stats["columns"] if column["name"] == "temp")
    assert temp_column["mean"] == 13.5
    assert temp_column["min"] == 3 and temp_column["max"] == 25
    city_column = next(column for column in stats["columns"] if column["name"] == "city")
    assert city_column["type"] == "text"
    assert city_column["top_values"][0][1] == 2
    assert response.json()["computed_locally"]["statistics"] is True

def test_an_answer_with_no_visible_text_is_annotated_not_left_blank() -> None:
    """A reasoning model can burn the whole output budget on internal reasoning and return an empty
    `message.content` with `finish_reason=length` (seen live with `zai-org/GLM-5.3-Flash` on the paid
    Dahl endpoint). The provider really worked and really billed its tokens, so the platform still
    charges — but the user must see *why* the bubble is empty instead of a silent blank reply."""
    from app.api.v1.chat import _empty_answer_note

    note = _empty_answer_note(text="   ", finish_reason="length", completion_tokens=64, reasoning="thinking…")
    assert note and "output budget" in note
    assert _empty_answer_note(text="", finish_reason="stop", completion_tokens=12, reasoning="only reasoning")
    assert _empty_answer_note(text="", finish_reason="stop", completion_tokens=7, reasoning=None)
    # a normal answer never gets a note
    assert _empty_answer_note(text="hello", finish_reason="stop", completion_tokens=7, reasoning="x") is None


def test_a_stored_empty_answer_carries_its_explanation() -> None:
    """The note must survive a reload: it is stored on the message row and returned to the client."""
    from app.api.v1.chat import _message_payload
    from app.models.chat import Message, MessageRole

    from datetime import datetime, timezone

    row = Message(
        id=999, conversation_id=1, user_id=1, role=MessageRole.ASSISTANT.value
        if hasattr(MessageRole.ASSISTANT, "value") else MessageRole.ASSISTANT,
        content="", status="incomplete", error_category="empty_answer",
        error_message="explained above", created_at=datetime.now(timezone.utc),
    )
    payload = _message_payload(row)
    assert payload["error_message"] == "explained above"
    assert payload["error_category"] == "empty_answer"
    assert payload["status"] == "incomplete"


def test_conversation_preview_never_leaks_reasoning_tags(user_client: AuthSession, db: Session) -> None:
    """Round-15 rail: the preview mirrors the *visible* answer — <think> blocks belong to the
    reasoning panel, so they must not surface in the conversation list (regression: the raw
    tags leaked into the rail snippet and, with it, into the rendered page)."""
    from datetime import datetime, timezone

    think = chr(60) + "think" + chr(62)
    end_think = chr(60) + "/think" + chr(62)
    created = user_client.post("/api/v1/chat/conversations", json={"title": "Reasoning"}).json()["conversation"]
    conversation_id = created["id"]
    conversation = db.get(Conversation, conversation_id)
    assert conversation is not None
    db.add(Message(
        conversation_id=conversation_id,
        user_id=conversation.user_id,
        role="assistant",
        content=f"{think}" + "\nThe user asks for 21*2; the answer is 42.\n" + f"{end_think}" + "\n\n42",
        status="complete",
        created_at=datetime.now(timezone.utc),
    ))
    db.commit()

    listing = user_client.get("/api/v1/chat/conversations").json()
    row = next(item for item in listing["items"] if item["id"] == conversation_id)
    preview = row["last_message_preview"] or ""
    assert think not in preview and end_think not in preview
    assert "42" in preview
