#!/usr/bin/env python3
"""Bring up a throwaway Nexa AI stack and run the Telegram demo against it.

This is the fastest honest way to see the bot work end to end without a real bot token
and without touching a real deployment: it

  1. creates a scratch SQLite database and a scratch upload folder,
  2. runs the real migrations and bootstrap with the project's own CLI,
  3. starts the real API (uvicorn) with Telegram pointed at the local Bot API double,
  4. registers the bundled mock OpenAI-compatible upstream as a provider, syncs it,
     publishes + prices a chat model and verifies it with an administrative test,
  5. runs ``tests/tools/telegram_demo.py`` against that stack (link code, welcome,
     commands, a real charged model answer),
  6. tears everything down and prints where the artefacts are.

Usage (from backend/):
    python tests/tools/telegram_demo_stack.py
    python tests/tools/telegram_demo_stack.py --keep          # leave the stack running
    python tests/tools/telegram_demo_stack.py --app-port 8031 --upstream-port 9099
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from http.cookiejar import CookieJar

BACKEND = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ROOT = os.path.dirname(BACKEND)


class Session:
    def __init__(self, base: str) -> None:
        self.base = base.rstrip("/")
        self.jar = CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))

    def call(self, method: str, path: str, payload: dict | None = None) -> tuple[int, dict]:
        data = json.dumps(payload).encode() if payload is not None else None
        request = urllib.request.Request(self.base + path, data=data, method=method)
        request.add_header("Content-Type", "application/json")
        token = next((c.value for c in self.jar if c.name == "nexa_csrf"), None)
        if token:
            request.add_header("X-CSRF-Token", token)
        try:
            with self.opener.open(request, timeout=60) as response:
                raw = response.read()
                return response.status, (json.loads(raw) if raw else {})
        except urllib.error.HTTPError as error:
            raw = error.read()
            try:
                return error.code, json.loads(raw) if raw else {}
            except ValueError:
                return error.code, {"_raw": raw[:200].decode(errors="replace")}

    def login(self, email: str, password: str) -> None:
        status, body = self.call("POST", "/api/v1/auth/login", {"email": email, "password": password})
        if status != 200:
            raise SystemExit(f"login failed: {status} {body}")


def wait_for_http(url: str, timeout: float = 60.0) -> bool:
    """Wait until *something* answers with a non-server-error status.

    A 401 counts as "up": the mock upstream answers 401 without a token, and urllib
    raises HTTPError for it, which must not be mistaken for "not started yet".
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=3) as response:
                if response.status < 500:
                    return True
        except urllib.error.HTTPError as error:
            if error.code < 500:
                return True
        except Exception:  # noqa: BLE001 - still starting
            pass
        time.sleep(0.5)
    return False


def _require_free_ports(*ports: int) -> None:
    """Refuse to start when something already listens on a port we are about to use.

    An aborted run can leave an API or a fake upstream behind on 8031/9021/9109. The stack then
    binds nothing, the *stale* process answers the demo's HTTP calls, and the run fails with a
    confusing "the bot did not answer an unlinked user" instead of naming the squatter.
    """
    import socket

    squatters: list[str] = []
    for port in ports:
        probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            probe.bind(("127.0.0.1", port))
        except OSError:
            squatters.append(str(port))
        finally:
            probe.close()
    if squatters:
        print(
            "! ports already in use: "
            + ", ".join(squatters)
            + "\n  A previous run was probably aborted. Inspect with:  sudo ss -ltnp | grep -E '"
            + "|".join(squatters)
            + "'  then kill the stray process (socat bridges included).",
            file=sys.stderr,
        )
        raise SystemExit(9)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--app-port", type=int, default=8031)
    parser.add_argument("--bot-api-port", type=int, default=9021)
    parser.add_argument("--upstream-port", type=int, default=9109)
    parser.add_argument("--admin-password", default="Telegram-Demo-Passw0rd-1")
    parser.add_argument("--keep", action="store_true", help="leave the API and upstream running")
    parser.add_argument("--workdir", default="", help="where to put the scratch database (default: a temp dir)")
    args = parser.parse_args()

    _require_free_ports(args.app_port, args.bot_api_port, args.upstream_port)

    workdir = args.workdir or tempfile.mkdtemp(prefix="nexa-telegram-demo-")
    os.makedirs(os.path.join(workdir, "uploads"), exist_ok=True)
    print(f"• scratch directory: {workdir}")

    env = dict(os.environ)
    env.update({
        "NEXA_ENVIRONMENT": "development",
        "NEXA_DEPLOYMENT_MODE": "local",
        "NEXA_PUBLIC_BASE_URL": f"http://127.0.0.1:{args.app_port}",
        "NEXA_SECRET_KEY": "telegram-demo-secret-key-0123456789abcdefghij",
        "NEXA_ENCRYPTION_KEY": "",
        "NEXA_DATABASE_URL": f"sqlite:///{workdir}/demo.db",
        "NEXA_UPLOAD_DIR": f"{workdir}/uploads",
        "NEXA_SERVE_FRONTEND": "true",
        "NEXA_FRONTEND_DIST_DIR": f"{ROOT}/frontend/dist",
        "NEXA_BOOTSTRAP_ADMIN_EMAIL": "admin@example.com",
        "NEXA_BOOTSTRAP_ADMIN_PASSWORD": args.admin_password,
        "NEXA_COOKIE_SECURE": "false",
        "NEXA_HSTS_ENABLED": "false",
        "NEXA_TRUSTED_HOSTS": "127.0.0.1,localhost",
        "NEXA_CORS_ORIGINS": f"http://127.0.0.1:{args.app_port}",
        "NEXA_INLINE_WORKER": "true",
        "NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS": "true",
        "NEXA_PROVIDER_ALLOW_INSECURE_HTTP": "true",
        "NEXA_LOG_LEVEL": "INFO",
        "NEXA_EMAIL_ENABLED": "false",
        "NEXA_MANUAL_PAYMENTS_ENABLED": "true",
        # --- Telegram, pointed at the local Bot API double -------------------
        "NEXA_TELEGRAM_ENABLED": "true",
        "NEXA_TELEGRAM_BOT_TOKEN": "123456:DEMO-TOKEN",
        "NEXA_TELEGRAM_BOT_USERNAME": "nexa_demo_bot",
        "NEXA_TELEGRAM_API_BASE": f"http://127.0.0.1:{args.bot_api_port}",
        "NEXA_TELEGRAM_MODE": "polling",
    })

    upstream = subprocess.Popen(
        [sys.executable, f"{ROOT}/tests/tools/mock_openai_upstream.py", "--port", str(args.upstream_port)],
        cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT,
    )
    api: subprocess.Popen | None = None
    log_path = os.path.join(workdir, "api.log")
    try:
        if not wait_for_http(f"http://127.0.0.1:{args.upstream_port}/v1/models"):
            print("! the mock upstream did not start", file=sys.stderr)
            return 2

        print("• applying migrations and bootstrapping ...")
        subprocess.run([sys.executable, "-m", "alembic", "upgrade", "head"], cwd=BACKEND, env=env, check=True,
                       stdout=subprocess.DEVNULL)
        subprocess.run([sys.executable, "-m", "app.cli", "bootstrap"], cwd=BACKEND, env=env, check=True,
                       stdout=subprocess.DEVNULL)

        with open(log_path, "wb") as log:
            api = subprocess.Popen(
                [sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", str(args.app_port)],
                cwd=BACKEND, env=env, stdout=log, stderr=subprocess.STDOUT,
            )
        base = f"http://127.0.0.1:{args.app_port}"
        if not wait_for_http(f"{base}/readyz"):
            print(f"! the API did not become ready - see {log_path}", file=sys.stderr)
            return 3
        print(f"• API ready on {base} (log: {log_path})")

        # --- a provider + a published, priced model so the bot has something to call --
        session = Session(base)
        session.login("admin@example.com", args.admin_password)
        status, provider = session.call("POST", "/api/v1/admin/providers", {
            "name": "Demo upstream", "provider_type": "openai_compatible",
            "base_url": f"http://127.0.0.1:{args.upstream_port}/v1",
            "api_key": "sk-mock-key", "enabled": True,
        })
        assert status == 201, (status, provider)
        provider_id = provider["provider"]["id"]
        session.call("POST", f"/api/v1/admin/providers/{provider_id}/sync", {})
        models = session.call("GET", f"/api/v1/admin/models?provider_id={provider_id}")[1]["items"]
        model = next(m for m in models if m["provider_model_id"] == "mock-chat-large")
        status, body = session.call("PATCH", f"/api/v1/admin/models/{model['id']}", {
            "visibility": "public", "published": True, "enabled": True,
            "capabilities": ["chat", "streaming"],
            "selling_input_per_mtok": 0.10, "selling_output_per_mtok": 0.10,
        })
        if status >= 400:
            # without this check a rejected payload (unknown field, invalid price) left the model
            # unpublished and unpriced, and the demo only showed it as "charged 0" later on
            raise SystemExit(f"publish/price patch failed: {status} {body}")
        session.call("POST", f"/api/v1/admin/models/{model['id']}/test",
                     {"operation": "chat", "input": "ping", "max_tokens": 8})
        subprocess.run([sys.executable, "-m", "app.cli", "grant-credits", "--email", "admin@example.com",
                        "--credits", "5", "--reason", "telegram demo"], cwd=BACKEND, env=env,
                       check=False, stdout=subprocess.DEVNULL)
        print(f"• provider ready, model '{model['display_name']}' published, verified and credited")

        # --- the actual demo, in its own process so its output stays clean ----------
        result = subprocess.run(
            [sys.executable, f"{BACKEND}/tests/tools/telegram_demo.py",
             "--base-url", base, "--admin-email", "admin@example.com",
             "--admin-password", args.admin_password, "--bot-api-port", str(args.bot_api_port)],
            cwd=BACKEND, env=env, check=False,
        )
        return result.returncode
    finally:
        if api is not None and not args.keep:
            api.send_signal(signal.SIGTERM)
            try:
                api.wait(timeout=10)
            except subprocess.TimeoutExpired:
                api.kill()
        if not args.keep:
            upstream.send_signal(signal.SIGTERM)
            upstream.wait(timeout=10)
        print(f"• artefacts kept in {workdir}" if args.keep else f"• stack stopped; logs were in {workdir}")


if __name__ == "__main__":
    raise SystemExit(main())
