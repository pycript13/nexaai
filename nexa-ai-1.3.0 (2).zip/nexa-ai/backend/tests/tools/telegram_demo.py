#!/usr/bin/env python3
"""Drive the Telegram bot against a *running* deployment and print the transcript.

This is the operator-facing twin of ``tests/test_telegram.py``: instead of pytest it
talks to a live server over HTTP, pushes real Bot API updates into a faithful local
Bot API double (``tests/tools/fake_telegram.py``) and prints exactly what a Telegram
user would have received — welcome message, command answers and a real, charged model
answer.

Requirements on the server side (its environment):
    NEXA_TELEGRAM_ENABLED=true
    NEXA_TELEGRAM_BOT_TOKEN=<any token; the double accepts it>
    NEXA_TELEGRAM_BOT_USERNAME=<bot username shown to users>
    NEXA_TELEGRAM_API_BASE=http://127.0.0.1:<bot-api-port>
    NEXA_TELEGRAM_MODE=polling
    NEXA_INLINE_WORKER=true        # so the API process polls (or run the worker)
    NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=true   # only for the local mock upstream

Usage
    python tests/tools/telegram_demo.py \
        --base-url http://127.0.0.1:8031 \
        --admin-email admin@example.com --admin-password "..." \
        --bot-api-port 9021 --telegram-user-id 4242

The script never touches a real Telegram server and never sends anything outside
loopback.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request
from http.cookiejar import CookieJar

# backend/ must be importable so `tests.tools.fake_telegram` resolves when this file
# is executed directly (that is how the docs call it).
_BACKEND = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, _BACKEND)

from tests.tools.fake_telegram import FakeTelegramServer  # noqa: E402


class Session:
    def __init__(self, base: str) -> None:
        self.base = base.rstrip("/")
        self.jar = CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))

    def call(self, method: str, path: str, payload: dict | None = None) -> tuple[int, dict]:
        data = json.dumps(payload).encode() if payload is not None else None
        request = urllib.request.Request(self.base + path, data=data, method=method)
        request.add_header("Content-Type", "application/json")
        token = next((c.value for c in self.jar if c.name == "nexa_csrf"), None)
        if token:
            request.add_header("X-CSRF-Token", token)
        try:
            with self.opener.open(request, timeout=60) as response:
                raw = response.read()
                return response.status, (json.loads(raw) if raw else {})
        except urllib.error.HTTPError as error:
            raw = error.read()
            try:
                return error.code, json.loads(raw) if raw else {}
            except ValueError:
                return error.code, {"_raw": raw[:200].decode(errors="replace")}

    def login(self, email: str, password: str) -> None:
        status, body = self.call("POST", "/api/v1/auth/login", {"email": email, "password": password})
        if status != 200:
            raise SystemExit(f"login failed: {status} {body}")
        print(f"• signed in as {email}")


def push(server: FakeTelegramServer, text: str, *, user_id: int, username: str) -> None:
    server.push_update({
        "update_id": server.next_update_id(),
        "message": {
            "message_id": server.next_message_id(),
            "from": {"id": user_id, "is_bot": False, "first_name": "Demo", "username": username},
            "chat": {"id": user_id, "type": "private"},
            "date": int(time.time()),
            "text": text,
        },
    })


def wait_for(condition, timeout: float = 45.0, interval: float = 0.7):  # noqa: ANN001, ANN201
    deadline = time.time() + timeout
    while time.time() < deadline:
        value = condition()
        if value:
            return value
        time.sleep(interval)
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description="Telegram bot demo against a live deployment")
    parser.add_argument("--base-url", default=os.environ.get("NEXA_TEST_BASE_URL", "http://127.0.0.1:8080"))
    parser.add_argument("--admin-email", default=os.environ.get("NEXA_ADMIN_EMAIL", "admin@example.com"))
    parser.add_argument("--admin-password", default=os.environ.get("NEXA_ADMIN_PASSWORD", ""))
    parser.add_argument("--bot-api-port", type=int, default=9021)
    parser.add_argument("--telegram-user-id", type=int, default=4242)
    parser.add_argument("--telegram-username", default="demo_user")
    parser.add_argument("--message", default="یک تابع پایتون برای معکوس کردن رشته بنویس")
    parser.add_argument("--keep-link", action="store_true", help="do not unlink when finished")
    args = parser.parse_args()

    if not args.admin_password:
        print("Provide --admin-password (or NEXA_ADMIN_PASSWORD)", file=sys.stderr)
        return 2

    server = FakeTelegramServer()
    port = server.start(port=args.bot_api_port)
    print(f"• local Bot API double listening on http://127.0.0.1:{port}")

    session = Session(args.base_url)
    try:
        session.login(args.admin_email, args.admin_password)

        status, body = session.call("GET", "/api/v1/telegram/status")
        print(f"• bot status: configured={body.get('bot_configured')} linked={body.get('linked')} "
              f"transport={body.get('transport')} username=@{body.get('bot_username')}")
        if not body.get("bot_configured"):
            print("! the server is not configured for Telegram - set NEXA_TELEGRAM_* and restart", file=sys.stderr)
            return 3

        # 1. an unlinked Telegram id must be refused and told what to do
        push(server, "سلام", user_id=args.telegram_user_id, username=args.telegram_username)
        refused = wait_for(lambda: [m["text"] for m in server.sent if m["chat_id"] == args.telegram_user_id])
        print("\n=== unlinked visitor ===")
        print((refused or ["(no answer)"])[0][:400])
        if not refused:
            print("! the bot did not answer an unlinked user", file=sys.stderr)
            return 4

        # 2. link with a one-time code created in the workspace
        status, code = session.call("POST", "/api/v1/telegram/link-code")
        if status != 201:
            print(f"! could not create a link code: {status} {code}", file=sys.stderr)
            return 5
        print(f"\n• link code: {code['code']} (valid {code['expires_in_minutes']} minutes)")

        before = len(server.sent)
        push(server, f"/start {code['code']}", user_id=args.telegram_user_id, username=args.telegram_username)
        welcome = wait_for(lambda: [m["text"] for m in server.sent[before:]])
        print("\n=== welcome message ===")
        print((welcome or ["(none)"])[0][:900])
        linked = wait_for(lambda: session.call("GET", "/api/v1/telegram/status")[1]["linked"], timeout=20)
        print(f"\n• account linked: {bool(linked)}")
        if not linked:
            print("! linking failed", file=sys.stderr)
            return 6

        # 3. guided commands
        for command in ("/help", "/status", "/models"):
            before = len(server.sent)
            push(server, command, user_id=args.telegram_user_id, username=args.telegram_username)
            reply = wait_for(lambda: [m["text"] for m in server.sent[before:]])
            print(f"\n=== {command} ===")
            print((reply or ["(none)"])[0][:800])

        # 4. a real model call, billed to the linked account
        before = len(server.sent)
        push(server, args.message, user_id=args.telegram_user_id, username=args.telegram_username)
        answer = wait_for(lambda: [m["text"] for m in server.sent[before:]], timeout=90)
        print("\n=== free-text message -> real model call ===")
        print((answer or ["(none)"])[0][:900])

        status, usage = session.call("GET", "/api/v1/billing/usage?module=telegram&page_size=5")
        rows = (usage or {}).get("items") or []
        totals = (usage or {}).get("totals") or {}
        print(f"\n• usage for module=telegram: {len(rows)} row(s), "
              f"total charged {totals.get('charged_micro', 'n/a')} micro"
              f" (latest: {rows[0]['charged_micro'] if rows else 'n/a'} micro)"
              f" — endpoint {status}")
        if not rows:
            print("! no telegram usage record was written - the message was not billed", file=sys.stderr)
            return 7

        if not args.keep_link:
            session.call("DELETE", "/api/v1/telegram/link")
            print("• link removed again (demo cleanup)")

        print("\nRESULT: the bot verified the Telegram id against a platform account, sent the welcome "
              "message and usage guide, and answered a real (charged) model request.")
        return 0
    finally:
        server.stop()


if __name__ == "__main__":
    raise SystemExit(main())
