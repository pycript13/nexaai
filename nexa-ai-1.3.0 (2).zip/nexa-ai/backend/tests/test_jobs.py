"""Background job pipeline: enqueue → worker handler → status/history."""
from __future__ import annotations

import json

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.jobs import Job, JobStatus, JobType
from app.workers import handlers  # noqa: F401  (registers the handlers, as the worker does)
from app.workers.registry_types import HANDLERS
from tests.conftest import AuthSession, create_provider_and_model, grant_credits


def test_all_declared_job_types_have_handlers() -> None:
    for job_type in JobType.ALL:
        assert job_type in HANDLERS, f"{job_type} has no registered handler"


def test_enqueue_document_job_runs_through_handler(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    import io

    grant_credits(db, user_client.email, 20.0)
    provider, model = create_provider_and_model(db, capabilities=["chat"])
    mock_provider_transport(lambda request: httpx.Response(200, json={
        "id": "doc-1", "choices": [{"index": 0, "message": {"content": "Summary of the document."},
                                    "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 20, "completion_tokens": 10, "total_tokens": 30}}))
    upload = user_client.post("/api/v1/files", files={"file": ("report.txt", io.BytesIO(b"Quarterly results\nRevenue up 12%"), "text/plain")})
    file_id = upload.json()["file"]["id"]

    created = user_client.post("/api/v1/modules/documents/process", json={
        "file_ids": [file_id], "model_id": model.id, "mode": "summarize", "async_job": True})
    assert created.status_code == 202, created.text
    job_id = created.json()["job"]["id"]

    from app.services.jobs import run_once

    processed = run_once(db)
    assert processed is not None
    job = user_client.get(f"/api/v1/jobs/{job_id}").json()["job"]
    assert job["status"] == JobStatus.SUCCEEDED, job
    assert "Summary" in json.dumps(job["result"])


def test_failed_job_records_error_and_can_be_retried(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    import io

    grant_credits(db, user_client.email, 20.0)
    provider, model = create_provider_and_model(db, capabilities=["chat"])
    mock_provider_transport(lambda request: httpx.Response(500, text="upstream exploded"))
    upload = user_client.post("/api/v1/files", files={"file": ("r.txt", io.BytesIO(b"data"), "text/plain")})
    file_id = upload.json()["file"]["id"]
    created = user_client.post("/api/v1/modules/documents/process", json={
        "file_ids": [file_id], "model_id": model.id, "mode": "summarize", "async_job": True})
    job_id = created.json()["job"]["id"]
    from app.services.jobs import run_once

    # a retryable upstream error is retried until the attempts are exhausted
    for _ in range(6):
        run_once(db)
        job = user_client.get(f"/api/v1/jobs/{job_id}").json()["job"]
        if job["status"] in ("failed", "succeeded"):
            break
    assert job["status"] == JobStatus.FAILED, job
    assert job["error_category"] == "upstream_server_error"
    assert job["attempts"] >= 1

    record = db.get(Job, job_id)
    assert record is not None and record.attempts >= 1
    assert record.max_attempts >= 1


def test_user_can_cancel_pending_job(user_client: AuthSession, db: Session) -> None:
    import io

    upload = user_client.post("/api/v1/files", files={"file": ("c.txt", io.BytesIO(b"cancel me"), "text/plain")})
    file_id = upload.json()["file"]["id"]
    created = user_client.post("/api/v1/modules/documents/process", json={
        "file_ids": [file_id], "mode": "index", "async_job": True})
    assert created.status_code == 202, created.text
    job_id = created.json()["job"]["id"]
    assert user_client.post(f"/api/v1/jobs/{job_id}/cancel").status_code == 200
    job = user_client.get(f"/api/v1/jobs/{job_id}").json()["job"]
    assert job["status"] == JobStatus.CANCELLED


def test_jobs_are_scoped_to_their_owner(user_client: AuthSession, second_user_client: AuthSession, db: Session) -> None:
    import io

    upload = user_client.post("/api/v1/files", files={"file": ("j.txt", io.BytesIO(b"mine"), "text/plain")})
    file_id = upload.json()["file"]["id"]
    created = user_client.post("/api/v1/modules/documents/process", json={
        "file_ids": [file_id], "mode": "index", "async_job": True})
    assert created.status_code == 202, created.text
    job_id = created.json()["job"]["id"]
    assert second_user_client.get(f"/api/v1/jobs/{job_id}").status_code == 404
    assert second_user_client.post(f"/api/v1/jobs/{job_id}/cancel").status_code == 404


def test_admin_sees_job_queue(user_client: AuthSession, admin_client: AuthSession, db: Session) -> None:
    import io

    upload = user_client.post("/api/v1/files", files={"file": ("a.txt", io.BytesIO(b"admin view"), "text/plain")})
    file_id = upload.json()["file"]["id"]
    user_client.post("/api/v1/modules/documents/process", json={
        "file_ids": [file_id], "mode": "index", "async_job": True})
    listing = admin_client.get("/api/v1/admin/jobs").json()
    assert "items" in listing
    assert listing["queue"] is not None
    assert user_client.get("/api/v1/admin/jobs").status_code == 403
    assert user_client.get("/api/v1/admin/jobs").status_code == 403
