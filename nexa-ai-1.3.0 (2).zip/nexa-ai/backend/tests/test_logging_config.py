"""Logging setup must stay attached to the *current* console and stay single.

Both properties were broken and both are easy to regress:

* ``logging.StreamHandler`` captures the stream object it is given. A handler created while
  something else owns ``sys.stdout`` (a test framework, a caller using ``contextlib.redirect_stdout``)
  keeps writing into that buffer after it is closed, so the final output of the process is lost.
* ``configure_logging`` used to bail out after the first call, so a later call could not change the
  stream (the CLI asks for stderr to keep its JSON report machine-readable) and handlers piled up —
  every log line would eventually be printed several times.
"""
from __future__ import annotations

import contextlib
import io
import logging

from app.core.logging import configure_logging, get_logger


def _managed_handlers() -> list[logging.Handler]:
    return [h for h in logging.getLogger().handlers if getattr(h, "_nexa_managed", False)]


def test_reconfiguration_replaces_handlers_instead_of_stacking_them():
    configure_logging("INFO")
    configure_logging("INFO")
    configure_logging("WARNING")
    managed = _managed_handlers()
    assert len(managed) == 1, f"expected exactly one managed handler, found {len(managed)}"
    assert logging.getLogger().level == logging.WARNING


def test_stream_choice_is_honoured_on_every_call():
    configure_logging("INFO", stream="stdout")
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        get_logger("test.logging").info("to-stdout")
    assert "to-stdout" in out.getvalue() and "to-stdout" not in err.getvalue()

    configure_logging("INFO", stream="stderr")
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        get_logger("test.logging").info("to-stderr")
    assert "to-stderr" in err.getvalue() and "to-stderr" not in out.getvalue()


def test_handler_follows_a_replaced_stdout_and_survives_its_closure():
    configure_logging("INFO", stream="stdout")
    first, second = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(first):
        get_logger("test.logging").info("first-buffer")
    first.close()  # a closed capture buffer must never be written to again
    with contextlib.redirect_stdout(second):
        get_logger("test.logging").info("second-buffer")
    assert "second-buffer" in second.getvalue()
