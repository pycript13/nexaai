"""Switching the model in the middle of a conversation must really switch.

Owner report: in one chat, after picking a second model, the bubble showed the
new model's name but the answers kept coming from (and identifying as) the
first model. Two defects made that happen:

1. the conversation row kept the *first* model forever — the platform never
   recorded the switch, so anything that re-reads the conversation (the UI
   after each send, regenerate, …) silently fell back to model #1;
2. the history fed to the new model still contained the old model's answers
   ("I am MiniMax-M2.7") with nothing telling the new model who *it* is, so
   it happily continued the previous model's identity.

The mock upstream echoes the exact ``model`` field it was called with, so the
test proves what the provider actually received — not what the UI claimed.
"""
from __future__ import annotations

import json

import httpx
from sqlalchemy.orm import Session

from tests.conftest import AuthSession, create_provider_and_model, grant_credits

SEEN: list[dict] = []


def _echo(request: httpx.Request) -> httpx.Response:
    if request.url.path.endswith("/chat/completions"):
        payload = json.loads(request.content.decode())
        SEEN.append(payload)
        model = payload.get("model") or "?"
        return httpx.Response(200, json={
            "id": "c1", "model": model,
            "choices": [{"index": 0, "message": {"role": "assistant", "content": f"answer from {model}"},
                         "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 6, "completion_tokens": 2, "total_tokens": 8},
        })
    return httpx.Response(404, json={"error": {"message": "not found"}})


def test_switching_model_mid_conversation_really_switches(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    SEEN.clear()
    grant_credits(db, user_client.email, 10.0)
    provider, model_a = create_provider_and_model(db, capabilities=["chat"], model_id_str="model-a", display_name="Model A")
    from app.models.provider import Model

    model_b = Model(
        provider_id=provider.id, provider_model_id="model-b", display_name="Model B",
        capabilities=["chat"], input_modalities=["text"], output_modalities=["text"],
        supports_streaming=True, visibility="public", availability="available",
        access_tier="credit", enabled=True, published=True,
        selling_input_per_mtok=3.0, selling_output_per_mtok=15.0,
        provider_cost_input_per_mtok=0.5, provider_cost_output_per_mtok=1.5, pricing_uncertain=False,
    )
    db.add(model_b)
    db.commit()
    mock_provider_transport(_echo)

    first = user_client.post("/api/v1/chat/completions", json={"model_id": model_a.id, "message": "سلام"})
    assert first.status_code == 200, first.text
    conversation_id = first.json()["conversation"]["id"]
    assert first.json()["message"]["content"] == "answer from model-a"
    assert first.json()["message"]["provider_model_id"] == "model-a"

    second = user_client.post("/api/v1/chat/completions", json={
        "model_id": model_b.id, "conversation_id": conversation_id, "message": "تو چه مدلی هستی؟",
    })
    assert second.status_code == 200, second.text
    # the provider was *actually* called with the new model
    assert SEEN[-1]["model"] == "model-b"
    assert second.json()["message"]["content"] == "answer from model-b"
    assert second.json()["message"]["provider_model_id"] == "model-b"

    # the request tells the new model who it is (history still holds A's words)
    system_blob = json.dumps(SEEN[-1], ensure_ascii=False)
    assert "model-b" in system_blob and "model switch" in system_blob.lower()

    # the conversation itself now belongs to the new model: a later turn with
    # no explicit model must keep using B, never fall back to A
    detail = user_client.get(f"/api/v1/chat/conversations/{conversation_id}").json()
    assert detail["conversation"]["model_id"] == model_b.id
    third = user_client.post("/api/v1/chat/completions", json={
        "conversation_id": conversation_id, "message": "ادامه بده",
    })
    assert third.status_code == 200, third.text
    assert SEEN[-1]["model"] == "model-b"
    assert third.json()["message"]["provider_model_id"] == "model-b"
