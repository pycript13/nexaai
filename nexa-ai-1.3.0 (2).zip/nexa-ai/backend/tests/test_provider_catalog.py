"""Provider catalogue: fetch everything, classify honestly, import only the selection.

The catalogue entry is derived exclusively from what the provider declared
(architecture modalities, supported parameters, published pricing). The only
name-based signal is the *suggested* "coding" tag.
"""
import httpx
import pytest
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.errors import ValidationError
from app.models.provider import Model
from app.services.providers import classify_catalog_entry, validate_base_url
from tests.conftest import AuthSession, create_provider_and_model

OPENROUTER_PAYLOAD = {
    "data": [
        {
            "id": "acme/vision-coder-1",
            "name": "Acme: Vision Coder 1",
            "description": "A coding model that sees.",
            "context_length": 262144,
            "top_provider": {"max_completion_tokens": 8192},
            "architecture": {"input_modalities": ["text", "image"], "output_modalities": ["text"]},
            "supported_parameters": ["tools", "response_format", "reasoning"],
            "pricing": {"prompt": "0.000001", "completion": "0.000002"},
        },
        {
            "id": "acme/free-chat-1",
            "name": "Acme: Free Chat 1",
            "context_length": 32768,
            "architecture": {"input_modalities": ["text"], "output_modalities": ["text"]},
            "supported_parameters": [],
            "pricing": {"prompt": "0", "completion": "0"},
        },
        {
            "id": "acme/embed-1",
            "name": "Acme Embed 1",
            "architecture": {"input_modalities": ["text"], "output_modalities": ["embeddings"]},
            "pricing": {"prompt": "0.0000001", "completion": "0"},
        },
    ]
}


def test_classification_uses_declared_facts_only() -> None:
    entries = [classify_catalog_entry(m | {"provider_model_id": m["id"]}) for m in OPENROUTER_PAYLOAD["data"]]
    vision = entries[0]
    assert vision["is_free"] is False
    assert vision["price_input_per_mtok"] == 1.0 and vision["price_output_per_mtok"] == 2.0
    assert vision["context_window"] == 262144 and vision["max_output_tokens"] == 8192
    assert "vision" in vision["tags"] and "tools" in vision["tags"] and "reasoning" in vision["tags"]
    assert "coding" in vision["tags"]  # suggested from the name — labeled as a hint in the UI
    assert "image_understanding" in vision["capabilities"] and "chat" in vision["capabilities"]

    free = entries[1]
    assert free["is_free"] is True and free["tags"][0] == "free"
    assert free["price_input_per_mtok"] == 0.0

    embed = entries[2]
    assert "embeddings" in embed["capabilities"] and "chat" not in embed["capabilities"]


def test_openrouter_wrong_base_url_is_corrected_loudly() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate_base_url("openai_compatible", "https://openrouter.ai/v1/")
    assert "api/v1" in excinfo.value.detail
    # the correct address passes validation untouched
    assert validate_base_url("openai_compatible", "https://openrouter.ai/api/v1") == "https://openrouter.ai/api/v1"


def test_catalog_fetch_and_selective_import(admin_client: AuthSession, db: Session, mock_provider_transport) -> None:
    provider, _model = create_provider_and_model(db, provider_type="openai_compatible")
    mock_provider_transport(lambda request: httpx.Response(200, json=OPENROUTER_PAYLOAD))

    catalogue = admin_client.get(f"/api/v1/admin/providers/{provider.id}/catalog")
    assert catalogue.status_code == 200, catalogue.text
    body = catalogue.json()
    assert body["summary"]["total"] == 3
    assert body["summary"]["free"] == 1 and body["summary"]["vision"] == 1 and body["summary"]["coding"] == 1
    assert all(entry["imported"] is False for entry in body["entries"])

    # import ONLY the free one, unpublished
    result = admin_client.post(
        f"/api/v1/admin/providers/{provider.id}/catalog/import",
        json={"provider_model_ids": ["acme/free-chat-1"], "publish": False},
    )
    assert result.status_code == 200, result.text
    assert result.json()["created"] == 1
    imported = db.scalars(select(Model).where(Model.provider_model_id == "acme/free-chat-1")).first()
    assert imported is not None
    assert imported.published is False and imported.visibility == "hidden"
    assert imported.access_tier == "free" and imported.selling_input_per_mtok == 0
    assert "chat" in imported.capabilities  # declared — so the model can actually be called
    assert db.scalars(select(Model).where(Model.provider_model_id == "acme/vision-coder-1")).first() is None

    # import the paid vision model, published this time
    result = admin_client.post(
        f"/api/v1/admin/providers/{provider.id}/catalog/import",
        json={"provider_model_ids": ["acme/vision-coder-1"], "publish": True},
    )
    assert result.json()["created"] == 1
    vision = db.scalars(select(Model).where(Model.provider_model_id == "acme/vision-coder-1")).first()
    assert vision.published is True and vision.visibility == "public"
    assert vision.supports_vision is True and vision.supports_tools is True
    assert float(vision.selling_input_per_mtok) == 1.0

    # re-import is an update, never a duplicate
    again = admin_client.post(
        f"/api/v1/admin/providers/{provider.id}/catalog/import",
        json={"provider_model_ids": ["acme/vision-coder-1"], "publish": True},
    )
    assert again.json()["created"] == 0 and again.json()["updated"] == 1
    assert len(db.scalars(select(Model).where(Model.provider_model_id == "acme/vision-coder-1")).all()) == 1

    # and it is really listed for users now
    listing = admin_client.get("/api/v1/models").json()
    ids = [item["provider_model_id"] for item in listing["items"]]
    assert "acme/vision-coder-1" in ids and "acme/free-chat-1" not in ids
