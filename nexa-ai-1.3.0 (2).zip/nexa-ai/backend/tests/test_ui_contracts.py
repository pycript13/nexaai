"""Contracts the web client depends on.

A browser sweep of the admin UI found three response shapes that the SPA read as
arrays while the API returns them as objects. The frontend was wrong and has been
fixed, but the shapes themselves are deliberate API decisions — the server owns the
list of payment methods and the set of localised labels — so they are pinned here
to stop a "helpful" refactor on either side from silently breaking the other.
"""
from __future__ import annotations

import json

from fastapi.testclient import TestClient


def test_payment_methods_are_keyed_by_slug(client: TestClient, user_client) -> None:
    response = user_client.get("/api/v1/billing/payment-methods")
    assert response.status_code == 200
    payload = response.json()

    for field in ("methods", "gateways"):
        assert isinstance(payload[field], dict), f"{field} must stay an object keyed by slug"
        for slug, entry in payload[field].items():
            assert isinstance(slug, str) and slug
            assert isinstance(entry, dict)
    assert "manual_bank_transfer" in payload["methods"]
    assert "enabled" in payload["methods"]["manual_bank_transfer"]


def test_admin_pricing_rules_keep_their_shape(client: TestClient, admin_client) -> None:
    """Regression: the admin pricing page read `items` while the endpoint sends `rules`.

    The table therefore rendered empty *without an error* — an administrator could not see
    or edit the platform's prices. The shape (rules + the unit note) is pinned here.
    """
    response = admin_client.get("/api/v1/admin/billing/pricing")
    assert response.status_code == 200
    payload = response.json()
    assert isinstance(payload["rules"], list), "the page maps over `rules`"
    assert payload["rules"], "a bootstrapped installation always has the global default rule"
    for row in payload["rules"]:
        assert {"id", "scope", "version", "active"} <= set(row)
        # per-token prices are micro-credits per 1,000,000 tokens; flat prices are micro-credits
        assert {"input_per_mtok_micro", "output_per_mtok_micro", "per_request_micro", "per_image_micro"} <= set(row)
    assert isinstance(payload.get("unit_note"), str) and payload["unit_note"]
    global_rule = next(rule for rule in payload["rules"] if rule["scope"] == "global")
    assert global_rule["minimum_charge_micro"] is not None


def test_admin_settings_come_back_as_a_flat_list(client: TestClient, admin_client) -> None:
    response = admin_client.get("/api/v1/admin/settings")
    assert response.status_code == 200
    payload = response.json()
    assert isinstance(payload["items"], list), "the page groups settings by category itself"
    assert payload["items"], "a bootstrapped installation always has settings"
    for row in payload["items"]:
        assert {"key", "value", "category"} <= set(row)
    assert isinstance(payload["environment"], dict)


def test_catalog_operation_labels_are_localised_objects(client: TestClient, admin_client) -> None:
    response = admin_client.get("/api/v1/models")
    assert response.status_code == 200
    labels = response.json()["operation_labels"]
    assert isinstance(labels, dict) and labels
    for operation, translations in labels.items():
        assert isinstance(translations, dict), f"{operation} labels must stay per-locale"
        assert {"en", "fa", "ar", "ckb"} <= set(translations), f"{operation} is missing a language"
        assert all(isinstance(value, str) and value for value in translations.values())


def test_login_returns_roles_as_objects_and_a_csrf_token(user_client) -> None:
    """The SPA prints role names and keeps the token for streaming fetches."""
    payload = user_client.login()
    assert isinstance(payload.get("csrf_token"), str) and payload["csrf_token"]
    roles = payload["user"]["roles"]
    assert isinstance(roles, list) and roles
    for role in roles:
        assert {"slug", "name"} <= set(role), "the shell shows role names, not only slugs"


def test_streaming_accepts_the_csrf_header_the_client_sends(user_client) -> None:
    """The chat page posts to /chat/stream with fetch(), outside the API helper.

    The page reads the token from the JavaScript-readable `nexa_csrf` cookie after a
    reload; that cookie has to exist and match what the header check compares against.
    """
    payload = user_client.login()
    token = payload["csrf_token"]
    assert user_client.cookies.get("nexa_csrf") == token, "the SPA reads this cookie after a reload"
    response = user_client.post(
        "/api/v1/chat/stream",
        json={"model_id": 1, "message": "contract check"},
        headers={"Accept": "text/event-stream"},
    )
    # 4xx for "no usable model" is fine; a CSRF rejection would mean the browser
    # fetch path can never authenticate.
    if response.status_code >= 400:
        body = json.dumps(response.json())
        assert "csrf" not in body.lower(), body[:300]
    else:
        assert response.headers["content-type"].startswith("text/event-stream")
