"""Telegram exactly-once delivery + model probe on selection.

The production stack polls Telegram from more than one process (API inline worker
AND the standalone worker), each with its own in-memory offset — without a shared
claim the same update is fetched and ANSWERED TWICE (the owner saw «سلام» answered
two times). One claim per update_id in the database makes the first handler the
only one. The same file pins the model probe: selecting a model must verify it
answers *now*, and say so — success or failure — before the user writes into
the void.
"""
import asyncio
import json

import httpx

from app.services import telegram as telegram_service
from tests.conftest import create_provider_and_model, grant_credits
from tests.test_telegram_round16 import _answer_handler, _sse


def _probe_aware_handler(chunks):
    """Stream SSE for chat, plain JSON for the (non-streaming) probe."""
    sse = _answer_handler(chunks)

    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode())
        if not payload.get("stream"):
            return httpx.Response(200, json={
                "id": "probe",
                "choices": [{"message": {"role": "assistant", "content": "ok"}, "finish_reason": "stop"}],
                "usage": {"prompt_tokens": 4, "completion_tokens": 1, "total_tokens": 5},
            })
        return sse(request)

    return handler
from tests.test_telegram_sessions import (  # noqa: F401  (telegram fixture re-export)
    _linked_account,
    _say,
    _tap,
    telegram,  # noqa: F401
)


def _deliver_same(db, server, update):
    before = len(server.sent)
    result = asyncio.run(telegram_service.handle_update(db, update))
    return result, server.sent[before:]


def test_same_update_twice_is_claimed_once(db, user_client, telegram, mock_provider_transport) -> None:
    mock_provider_transport(_probe_aware_handler(["پاسخ", " واحد"]))
    create_provider_and_model(db, published=True, display_name="Dedup Model")
    grant_credits(db, user_client.email, 20.0)
    tid = _linked_account(user_client, db, telegram)

    update = {
        "update_id": telegram.next_update_id(),
        "message": {
            "message_id": 1, "date": 1_700_000_000,
            "from": {"id": tid, "first_name": "Test"},
            "chat": {"id": tid, "type": "private"},
            "text": "سلام",
        },
    }
    first, sent_first = _deliver_same(db, telegram, update)
    second, sent_second = _deliver_same(db, telegram, update)
    assert first == "answer", first
    assert second == "duplicate", second
    answers = [m for m in sent_first if "پاسخ" in m.get("text", "")]
    assert len(answers) == 1, "exactly one answer message for one user message"
    assert sent_second == [], "a duplicate delivery must send nothing at all"


def test_model_selection_probes_and_reports(db, user_client, telegram, mock_provider_transport) -> None:
    mock_provider_transport(_probe_aware_handler(["خوبم"]))
    create_provider_and_model(db, published=True, display_name="Probe Model")
    grant_credits(db, user_client.email, 20.0)
    tid = _linked_account(user_client, db, telegram)

    # open the models list and tap the only model
    update = _tap(telegram, "menu:models", telegram_user_id=tid)
    result = asyncio.run(telegram_service.handle_update(db, update))
    assert result in {"models", "model_selected"}, result
    buttons = []
    for message in telegram.sent:
        for row in (message.get("reply_markup") or {}).get("inline_keyboard", []):
            buttons.extend(row)
    pick = next((b for b in buttons if str(b.get("callback_data", "")).startswith("model:")), None)
    assert pick is not None, f"no model button in {buttons}"
    before = len(telegram.sent)
    result = asyncio.run(telegram_service.handle_update(db, _tap(telegram, pick["callback_data"], telegram_user_id=tid)))
    assert result == "model_selected", result
    texts = [m["text"] for m in telegram.sent[before:]] + [e["text"] for e in telegram.edits]
    probe_msgs = [text for text in texts if "بررسی مدل" in text]
    assert probe_msgs, "selecting a model must report the health verdict to the user"
    assert "پاسخ‌گوست" in probe_msgs[-1]


def test_model_selection_reports_a_dead_model(db, user_client, telegram, mock_provider_transport) -> None:
    mock_provider_transport(lambda request: httpx.Response(503, json={"error": {"message": "model busy"}}))
    _provider, dead_model = create_provider_and_model(db, published=True, display_name="Dead Model")
    # A previous test may have cached a healthy verdict for this model id (the cache
    # is correct product behaviour) — this scenario needs a cold probe.
    from sqlalchemy import delete as _delete

    from app.models.admin import AppSetting
    db.execute(_delete(AppSetting).where(AppSetting.key == f"model_probe:{dead_model.id}"))
    db.commit()
    grant_credits(db, user_client.email, 20.0)
    tid = _linked_account(user_client, db, telegram)

    before = len(telegram.sent)
    result = asyncio.run(
        telegram_service.handle_update(db, _tap(telegram, f"model:{dead_model.id}", telegram_user_id=tid))
    )
    assert result == "model_selected", result
    texts = [m["text"] for m in telegram.sent[before:]] + [e["text"] for e in telegram.edits]
    probe_msgs = [text for text in texts if "نمی‌تواند پاسخ بدهد" in text]
    assert probe_msgs, "a dead model must be announced at selection time, not mid-chat"


def test_check_endpoint_reports_health(user_client, db, mock_provider_transport) -> None:
    def ok_chat(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode())
        assert payload.get("stream") in (False, None), "the probe must not stream"
        return httpx.Response(200, json={
            "id": "p1",
            "choices": [{"message": {"role": "assistant", "content": "ok"}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 5, "completion_tokens": 1, "total_tokens": 6},
        })

    mock_provider_transport(ok_chat)
    _provider, model = create_provider_and_model(db, published=True)
    grant_credits(db, user_client.email, 5.0)
    first = user_client.post(f"/api/v1/models/{model.id}/check")
    assert first.status_code == 200, first.text
    body = first.json()
    assert body["ok"] is True and body["model_id"] == model.id, body
    second = user_client.post(f"/api/v1/models/{model.id}/check").json()
    assert second["ok"] is True and second["cached"] is True, "the second check inside the window is cached"


def test_check_endpoint_reports_failure(user_client, db, mock_provider_transport) -> None:
    mock_provider_transport(lambda request: httpx.Response(429, json={"error": {"message": "slow down"}}))
    _provider, model = create_provider_and_model(db, published=True)
    grant_credits(db, user_client.email, 5.0)
    response = user_client.post(f"/api/v1/models/{model.id}/check")
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["ok"] is False and body["category"], body
