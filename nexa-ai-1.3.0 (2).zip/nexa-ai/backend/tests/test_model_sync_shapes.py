"""`/models` shapes, and what the operator is told when one is unusable.

Reported from a real deployment: "the provider connects but it does not import the models". The
strict parser only accepted `{"data": [ … ]}` and answered anything else with "Model list endpoint
returned an unexpected payload shape" — a message that reads like a credential problem and gives
the operator nothing to act on, even though gateways commonly answer with `{"models": […]}`, a bare
list, or a nested `{"data": {"models": […]}}`.

These tests pin both halves of the fix: the tolerant reader, and the diagnostic that quotes the
payload's real top-level keys when even that fails.
"""
from __future__ import annotations

import asyncio

import httpx
import pytest

from app.providers.base import ProviderCredentials
from app.providers.openai_compatible import (
    OpenAICompatibleAdapter,
    extract_model_items,
    model_identifier,
)

pytestmark = pytest.mark.provider


def _adapter() -> OpenAICompatibleAdapter:
    return OpenAICompatibleAdapter(
        ProviderCredentials(
            api_key="sk-test-1234567890",
            base_url="https://api.example.com/v1",
            connect_timeout=2,
            read_timeout=5,
            max_retries=0,
            provider_slug="shape-test",
            provider_name="Shape Test",
        )
    )


def test_every_shape_a_gateway_uses_is_read(mock_provider_transport) -> None:
    payloads = {
        "data": {"object": "list", "data": [{"id": "a"}, {"id": "b"}]},
        "models": {"models": [{"name": "a"}, {"name": "b"}]},
        "bare": [{"id": "a"}, {"id": "b"}],
        "nested": {"data": {"models": [{"id": "a"}, {"id": "b"}]}},
    }
    for expected_shape, payload in payloads.items():
        mock_provider_transport(lambda request, payload=payload: httpx.Response(200, json=payload))
        models = asyncio.run(_adapter().list_models())
        assert [m["provider_model_id"] for m in models] == ["a", "b"], expected_shape
        assert all(m["display_name"] for m in models)


def test_the_connection_test_reports_the_shape_and_the_next_step(mock_provider_transport) -> None:
    mock_provider_transport(lambda request: httpx.Response(200, json={"models": [{"name": "a"}]}))
    result = asyncio.run(_adapter().test_connection())
    assert result["ok"] is True
    assert result["model_count"] == 1
    assert result["details"]["shape"] == "models"
    assert "Press Sync" in result["message"], "the operator must be told what to do with them"


def test_an_unusable_payload_names_the_keys_and_the_base_url_check(mock_provider_transport) -> None:
    mock_provider_transport(
        lambda request: httpx.Response(200, json={"ok": True, "capabilities": [], "server": {"name": "x"}})
    )
    with pytest.raises(Exception) as caught:
        asyncio.run(_adapter().list_models())
    error = caught.value
    details = getattr(error, "details", {})
    assert details.get("top_level_keys") == ["capabilities", "ok", "server"]
    assert "/v1" in " ".join(details.get("hints", [])), "the most common cause must be named"
    assert "credential" in details.get("hints", [""])[-1] or any("credential" in h for h in details["hints"])
    assert details.get("received")


def test_the_connection_test_survives_an_empty_catalogue(mock_provider_transport) -> None:
    mock_provider_transport(lambda request: httpx.Response(200, json={"object": "list", "data": []}))
    result = asyncio.run(_adapter().test_connection())
    assert result["ok"] is True and result["model_count"] == 0
    assert "empty for this key" in result["message"]


@pytest.mark.parametrize(
    "item,expected",
    [
        ({"id": "a"}, "a"),
        ({"name": "b"}, "b"),
        ({"model": "c"}, "c"),
        ({"model_id": "d"}, "d"),
        ({"id": "  e  "}, "e"),
        ({"object": "model"}, ""),
    ],
)
def test_model_identifiers_are_read_from_the_usual_keys(item: dict, expected: str) -> None:
    assert model_identifier(item) == expected


def test_extract_reports_no_shape_for_a_scalar() -> None:
    assert extract_model_items("nope") == ([], "")
    assert extract_model_items({"data": "nope"}) == ([], "")
    assert extract_model_items(None) == ([], "")
