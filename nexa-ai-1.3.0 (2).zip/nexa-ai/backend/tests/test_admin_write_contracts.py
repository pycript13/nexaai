"""Every admin screen must be able to save (release round 10).

The report was *"the model page has two close buttons and no save button"*.  Underneath it
sat a worse defect: the model dialog **did** try to save, on every keystroke, and the API
answered 422 every single time — `PATCH /api/v1/admin/models/{id}` is a `StrictModel` that
forbids unknown fields, and the dialog sent `confirm: true` with every request.  The same
mismatch existed on the provider dialog (`ProviderUpdate.confirm`) and the pricing dialog
(`PricingRuleRequest.confirm`), so three admin screens could not persist anything while the
API looked healthy.

This module drives the **exact payload each admin page sends** against the live API and fails
if the request is rejected as malformed.  A 422 for bad *values* is a different thing and is
allowed to be asserted separately; what must never happen is "unknown field `confirm`".
"""
from __future__ import annotations

import json
import os

import pytest
from sqlalchemy.orm import Session

from app.models.provider import Model, Provider
from tests.conftest import AuthSession, create_provider_and_model


def _assert_accepted(response, label: str) -> dict:
    assert response.status_code not in (404, 405), f"{label}: endpoint missing ({response.status_code})"
    assert response.status_code != 422, f"{label} was rejected as malformed: {response.text[:400]}"
    if response.status_code >= 400:
        # a permission/state error is fine here — a payload-shape error is not
        body = response.text.lower()
        assert "extra_forbidden" not in body and "extra inputs" not in body, f"{label}: {response.text[:400]}"
    try:
        return response.json()
    except json.JSONDecodeError:  # pragma: no cover - defensive
        return {}


@pytest.fixture()
def admin_model(db: Session):
    provider, model = create_provider_and_model(db, display_name="Contract model", model_id_str="contract-model-1")
    return provider, model


# ------------------------------------------------------------------ the model dialog --


def test_model_dialog_payload_is_accepted(admin_client: AuthSession, admin_model) -> None:
    """Exactly what AdminModels.tsx sends when the operator presses Save."""
    _, model = admin_model
    payload = {
        "display_name": "Contract model (renamed)",
        "visibility": "hidden",
        "access_tier": "credit",
        "availability": "available",
        "published": False,
        "enabled": True,
        "selling_input_per_mtok": 3.0,
        "selling_output_per_mtok": 15.0,
        "selling_per_image": 0.0,
        "confirm": True,
    }
    body = _assert_accepted(admin_client.patch(f"/api/v1/admin/models/{model.id}", json=payload), "model save (full form)")
    assert body["model"]["display_name"] == "Contract model (renamed)"
    assert float(body["model"]["selling_input_per_mtok"]) in (3.0, 3)


def test_model_dialog_can_publish_a_public_model(admin_client: AuthSession, db: Session) -> None:
    _, model = create_provider_and_model(db, display_name="Publishable", visibility="public", published=False)
    payload = {"visibility": "public", "published": True, "confirm": True}
    body = _assert_accepted(admin_client.patch(f"/api/v1/admin/models/{model.id}", json=payload), "model publish")
    assert body["model"]["published"] is True


def test_model_create_dialog_payload_is_accepted(admin_client: AuthSession, admin_model) -> None:
    provider, _ = admin_model
    payload = {
        "provider_id": provider.id,
        "provider_model_id": "created-by-dialog",
        "display_name": "Created by the dialog",
        "capabilities": ["chat", "streaming"],
        "visibility": "hidden",
        "access_tier": "credit",
        "published": False,
        "selling_input_per_mtok": 3,
        "selling_output_per_mtok": 15,
    }
    body = _assert_accepted(admin_client.post("/api/v1/admin/models", json=payload), "model create")
    assert body["model"]["provider_model_id"] == "created-by-dialog"


def test_model_test_dialog_payload_is_accepted(admin_client: AuthSession, admin_model) -> None:
    _, model = admin_model
    response = admin_client.post(
        f"/api/v1/admin/models/{model.id}/test",
        json={"operation": "chat", "input": "Reply with the single word: pong"},
    )
    assert response.status_code not in (404, 405, 422), response.text


# --------------------------------------------------------------- the provider dialog --


def test_provider_dialog_payload_is_accepted(admin_client: AuthSession, admin_model) -> None:
    """Exactly what AdminProviders.tsx sends when the operator presses Save."""
    provider, _ = admin_model
    payload = {
        "name": "Renamed provider",
        "base_url": provider.base_url,
        "api_key": "sk-rotated-by-dialog-0001",
        "clear_api_key": False,
        "enabled": True,
        "priority": 5,
        "confirm": True,
    }
    body = _assert_accepted(admin_client.patch(f"/api/v1/admin/providers/{provider.id}", json=payload), "provider save")
    assert body["provider"]["name"] == "Renamed provider"


def test_provider_create_dialog_payload_is_accepted(admin_client: AuthSession) -> None:
    payload = {
        "name": "Contract provider",
        "provider_type": "openai_compatible",
        "base_url": f"https://provider{os.urandom(2).hex()}.example.com/v1",
        "api_key": "sk-contract-key-1234567890",
        "enabled": False,
        "priority": 10,
    }
    body = _assert_accepted(admin_client.post("/api/v1/admin/providers", json=payload), "provider create")
    assert body["provider"]["slug"]


# ---------------------------------------------------------------- the pricing dialog --


def test_pricing_dialog_payload_is_accepted(admin_client: AuthSession, admin_model) -> None:
    _, model = admin_model
    created = _assert_accepted(
        admin_client.post(
            "/api/v1/admin/billing/pricing",
            json={
                "name": "Contract rule",
                "scope": "model",
                "scope_ref_id": model.id,
                "input_per_mtok_micro": 3_000_000,
                "output_per_mtok_micro": 15_000_000,
                "per_request_micro": 0,
                "per_image_micro": 0,
                "per_audio_minute_micro": 0,
                "per_job_micro": 0,
                "minimum_charge_micro": 0,
                "provider_input_per_mtok_micro": 500_000,
                "provider_output_per_mtok_micro": 1_500_000,
                "provider_per_request_micro": 0,
                "provider_per_image_micro": 0,
                "provider_per_audio_minute_micro": 0,
                "provider_pricing_uncertain": False,
                "markup_percent": 0,
                "currency": "credits",
                "notes": None,
            },
        ),
        "pricing create",
    )
    rule_id = created["rule_id"]
    assert isinstance(rule_id, int), created
    # exactly what AdminPricing.tsx sends: the edited price fields plus the confirmation flag.
    # No name and no scope — the rule keeps its identity and the change becomes a new version.
    payload = {
        "input_per_mtok_micro": 4_000_000,
        "output_per_mtok_micro": 16_000_000,
        "per_request_micro": 0,
        "per_image_micro": 0,
        "per_audio_minute_micro": 0,
        "minimum_charge_micro": 0,
        "markup_percent": 0,
        "confirm": True,
    }
    body = _assert_accepted(admin_client.patch(f"/api/v1/admin/billing/pricing/{rule_id}", json=payload), "pricing update")
    assert body["version"] == 2, body
    assert body["previous_rule_id"] == rule_id, "the old version is superseded, not overwritten"

    listing = admin_client.get("/api/v1/admin/billing/pricing").json()
    rows = listing.get("rules") or listing.get("items") or []
    fresh = next(row for row in rows if row["id"] == body["rule_id"])
    assert fresh["input_per_mtok_micro"] == 4_000_000, "the edited price is applied"
    assert fresh["name"] == "Contract rule", "the rule's identity is carried over, not blanked"
    assert fresh["scope"] == "model" and fresh["scope_ref_id"] == model.id, "the scope survives"
    assert fresh["provider_input_per_mtok_micro"] == 500_000, "untouched fields survive the update"


# ------------------------------------------------------------------ the money screens --


def _pending_payment(user_client: AuthSession, micro: int = 20_000_000) -> int:
    response = user_client.post("/api/v1/billing/payments", json={"amount_micro": micro, "method": "manual_bank_transfer"})
    assert response.status_code in (200, 201), response.text
    return response.json()["payment"]["id"]


def test_payment_approve_payload_is_accepted(user_client: AuthSession, admin_client: AuthSession) -> None:
    payment_id = _pending_payment(user_client)
    body = _assert_accepted(
        admin_client.post(
            f"/api/v1/admin/billing/payments/{payment_id}/approve",
            json={"note": "Verified against the bank statement", "confirm": True},
        ),
        "payment approve",
    )
    assert body["credited_micro"] == 20_000_000


def test_payment_reject_payload_is_accepted(user_client: AuthSession, admin_client: AuthSession) -> None:
    payment_id = _pending_payment(user_client, 6_000_000)
    # exactly what AdminPayments.tsx sends — the reject dialog asks for a reason, not a checkbox
    response = admin_client.post(
        f"/api/v1/admin/billing/payments/{payment_id}/reject",
        json={"reason": "The transfer never arrived"},
    )
    assert response.status_code not in (404, 405, 422), response.text


def test_payment_refund_payload_is_accepted(user_client: AuthSession, admin_client: AuthSession) -> None:
    payment_id = _pending_payment(user_client, 30_000_000)
    admin_client.post(f"/api/v1/admin/billing/payments/{payment_id}/approve", json={"confirm": True})
    response = admin_client.post(
        f"/api/v1/admin/billing/payments/{payment_id}/refund",
        json={"amount_micro": 10_000_000, "reason": "Refund approved by administrator", "confirm": True},
    )
    assert response.status_code not in (404, 405, 422), response.text


def test_credit_grant_payload_is_accepted(user_client: AuthSession, admin_client: AuthSession) -> None:
    me = user_client.get("/api/v1/auth/me").json()["user"]
    response = admin_client.post(
        f"/api/v1/admin/users/{me['id']}/credits",
        json={"amount_micro": 5_000_000, "reason": "Administrator grant", "confirm": True},
    )
    assert response.status_code not in (404, 405, 422), response.text


def test_user_roles_and_suspension_payloads_are_accepted(user_client: AuthSession, admin_client: AuthSession) -> None:
    from sqlalchemy import select

    from app.models.user import Role  # noqa: PLC0415

    me = user_client.get("/api/v1/auth/me").json()["user"]
    roles = admin_client.get("/api/v1/admin/roles").json()["items"]
    user_role = next(role for role in roles if role["slug"] == "user")
    response = admin_client.put(f"/api/v1/admin/users/{me['id']}/roles", json={"roles": [user_role["slug"]], "confirm": True})
    assert response.status_code not in (404, 405, 422), response.text

    suspend = admin_client.post(f"/api/v1/admin/users/{me['id']}/suspend", json={"confirm": True, "reason": "contract check"})
    assert suspend.status_code not in (404, 405, 422), suspend.text
    reactivate = admin_client.post(f"/api/v1/admin/users/{me['id']}/reactivate", json={"confirm": True})
    assert reactivate.status_code not in (404, 405, 422), reactivate.text


def test_role_permissions_payload_is_accepted(admin_client: AuthSession) -> None:
    roles = admin_client.get("/api/v1/admin/roles").json()["items"]
    role = next((r for r in roles if r["slug"] not in ("super_admin",)), None)
    assert role is not None, "a non-super-admin role must exist to exercise the permission editor"
    listing = admin_client.get("/api/v1/admin/roles").json()
    groups = listing.get("permission_groups") or {}
    # the catalogue is {group name: [permission slugs]} — the roles screen used to read it as a
    # list of {group, permissions[]}, which rendered an empty permission editor (fixed in the UI)
    permissions = [slug for slugs in groups.values() for slug in (slugs or [])]
    assert permissions, f"the permission catalogue must not be empty: {list(listing)[:5]}"
    response = admin_client.request(
        "PUT",
        f"/api/v1/admin/roles/{role['id']}/permissions",
        json={"permissions": permissions[:3], "confirm": True},
    )
    assert response.status_code not in (404, 405, 422), response.text


def test_settings_payload_is_accepted(admin_client: AuthSession) -> None:
    settings = admin_client.get("/api/v1/admin/settings").json()["items"]
    key = next(item["key"] for item in settings if isinstance(item.get("value"), (bool, int, float, str))) \
        if settings else None
    if key is None:
        pytest.skip("no writable setting to exercise")
    current = next(item["value"] for item in settings if item["key"] == key)
    response = admin_client.patch(f"/api/v1/admin/settings/{key}", json={"value": current, "confirm": True})
    assert response.status_code not in (404, 405, 422), response.text


def test_backup_run_payload_is_accepted(admin_client: AuthSession) -> None:
    response = admin_client.post("/api/v1/admin/backup/run", json={"confirm": True})
    assert response.status_code not in (404, 405, 422), response.text


def test_provider_test_payload_is_accepted(admin_client: AuthSession, admin_model) -> None:
    provider, _ = admin_model
    response = admin_client.post(f"/api/v1/admin/providers/{provider.id}/test", json={"with_model_request": False})
    assert response.status_code not in (404, 405, 422), response.text
