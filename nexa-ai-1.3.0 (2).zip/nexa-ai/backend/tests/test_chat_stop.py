"""Stop-generation semantics for the chat stream (regression suite).

Pins the contract that was once broken by yielding the terminal event from a
finally block:
1. aclose() mid-stream completes cleanly (no "async generator ignored
   GeneratorExit"), closes the provider stream, records the usage as
   cancelled/user_stopped (charged for produced tokens only), and writes no
   provider-health success sample for a user abort.
2. CancelledError propagates — it is never swallowed into a "done" event.
3. The SSE endpoint persists the partial answer with status="stopped" and
   emits a "stopped" event before the cancellation propagates.
"""
import asyncio

import pytest
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.billing import UsageRecord
from app.models.provider import ProviderHealthSample
from app.models.user import User
from app.providers.base import ChatChunk, ChatMessage
from app.services import ai as ai_service
from app.services.access import AccessDecision
from tests.conftest import create_provider_and_model, grant_credits


class FakeAdapter:
    """Streams eight deltas, tracking whether its own cleanup ran."""

    def __init__(self, chunks: int = 8) -> None:
        self.chunks = chunks
        self.closed = False

    async def stream_chat(self, request):  # noqa: ANN001, ARG002
        try:
            for i in range(self.chunks):
                yield ChatChunk(delta=f"part{i} ")
                await asyncio.sleep(0)
        finally:
            self.closed = True


def _make_ref(db: Session, adapter: FakeAdapter):
    provider, model = create_provider_and_model(db, capabilities=["chat", "streaming"])
    return ai_service.ModelRef(model=model, provider=provider, adapter=adapter,
                               decision=AccessDecision(allowed=True))


def _drive_aclose(email: str, db_factory):
    async def main():
        db = db_factory()
        user = db.scalar(select(User).where(User.email == email))
        adapter = FakeAdapter()
        ref = _make_ref(db, adapter)
        gen = ai_service.stream_chat(
            db, user=user, model_ref=ref,
            messages=[ChatMessage(role="user", content="hi")],
            module="chat", idempotency_key="msg:repro-aclose",
        )
        await gen.__anext__()
        await gen.__anext__()
        try:
            await gen.aclose()
            outcome = "clean"
        except RuntimeError as exc:
            outcome = f"runtimeerror: {exc}"
        except BaseException as exc:  # noqa: BLE001
            outcome = f"{type(exc).__name__}: {exc}"
        return outcome, adapter.closed, db

    return asyncio.run(main())


def test_aclose_midstream_is_clean_and_marks_cancelled(user_client, db: Session) -> None:
    grant_credits(db, user_client.email, 10.0)
    outcome, adapter_closed, session = _drive_aclose(user_client.email, lambda: db)
    print("ACLOSE OUTCOME:", outcome, "adapter_closed:", adapter_closed)
    records = session.scalars(
        select(UsageRecord).where(UsageRecord.idempotency_key == "msg:repro-aclose")
    ).all()
    health = session.scalars(
        select(ProviderHealthSample).where(
            ProviderHealthSample.provider_id.in_(
                select(UsageRecord.provider_id).where(UsageRecord.idempotency_key == "msg:repro-aclose")
            )
        )
    ).all()
    print("USAGE:", [(r.status, r.error_category, r.charged_micro) for r in records])
    print("HEALTH success flags:", [h.success for h in health])
    assert outcome == "clean", f"aclose must not explode, got: {outcome}"
    assert adapter_closed, "the provider stream must be closed on abort"
    assert any(r.status == "cancelled" for r in records), "abort must record a CANCELLED usage"
    assert not any(h.success for h in health), "a user abort is not a provider success"


def _drive_athrow(email: str, db):
    async def main():
        user = db.scalar(select(User).where(User.email == email))
        adapter = FakeAdapter()
        ref = _make_ref(db, adapter)
        gen = ai_service.stream_chat(
            db, user=user, model_ref=ref,
            messages=[ChatMessage(role="user", content="hi")],
            module="chat", idempotency_key="msg:repro-athrow",
        )
        await gen.__anext__()
        try:
            event = await gen.athrow(asyncio.CancelledError)
            return ("swallowed", getattr(event, "type", "?"))
        except asyncio.CancelledError:
            return ("propagated", None)

    return asyncio.run(main())


def test_cancelled_error_propagates_not_swallowed(user_client, db: Session) -> None:
    grant_credits(db, user_client.email, 10.0)
    outcome = _drive_athrow(user_client.email, db)
    print("ATHROW OUTCOME:", outcome)
    assert outcome[0] == "propagated", (
        f"cancellation was swallowed and turned into a {outcome[1]!r} event"
    )


def _endpoint_stream(db: Session, user, model_id: int, monkeypatch):  # noqa: ANN001, ANN202
    """Drive the real SSE endpoint generator with a stream that dies mid-answer."""
    from app.api.v1 import chat as chat_api
    from app.services.ai import StreamEvent

    async def dying_stream(*args, **kwargs):  # noqa: ANN002, ANN003, ANN202
        yield StreamEvent("delta", {"text": "نیمه‌ی پاسخ "})
        yield StreamEvent("delta", {"text": "که قطع شد"})
        raise asyncio.CancelledError

    monkeypatch.setattr(ai_service, "stream_chat", dying_stream)
    payload = chat_api.ChatRequest(model_id=model_id, message="سلام", stream=True)

    async def collect():
        response = await chat_api.chat_stream(payload, request=None, db=db, user=user, client=None)
        events = []
        with pytest.raises(asyncio.CancelledError):
            async for chunk in response.body_iterator:
                events.append(chunk if isinstance(chunk, str) else chunk.decode())
        return events

    return asyncio.run(collect())


def test_endpoint_persists_partial_as_stopped(user_client, db: Session, monkeypatch) -> None:
    grant_credits(db, user_client.email, 10.0)
    _provider, model = create_provider_and_model(db, capabilities=["chat", "streaming"])
    user = db.scalar(select(User).where(User.email == user_client.email))
    events = _endpoint_stream(db, user, model.id, monkeypatch)
    joined = "".join(events)
    assert "event: meta" in joined and "event: delta" in joined
    assert "event: stopped" in joined, "the client must be told the stream was stopped"
    from app.models.chat import Message

    assistant = db.scalars(
        select(Message).where(Message.role == "assistant", Message.content == "نیمه‌ی پاسخ که قطع شد")
    ).all()
    assert len(assistant) == 1
    assert assistant[0].status == "stopped"
    assert assistant[0].error_category == "user_stopped"
    assert assistant[0].content == "نیمه‌ی پاسخ که قطع شد"


if __name__ == "__main__":
    pytest.main([__file__, "-x", "-s"])
