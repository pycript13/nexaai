"""Authorization regression tests (spec §6, §8, §28).

These are the critical security invariants: ordinary users cannot reach admin
APIs, restricted/hidden models stay inaccessible, disabled providers/models stay
disabled, and a Super Admin can administer everything.
"""
from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from tests.conftest import AuthSession, create_provider_and_model, grant_credits

ADMIN_ENDPOINTS = [
    ("GET", "/api/v1/admin/users"),
    ("GET", "/api/v1/admin/providers"),
    ("GET", "/api/v1/admin/models"),
    ("GET", "/api/v1/admin/dashboard"),
    ("GET", "/api/v1/admin/audit"),
    ("GET", "/api/v1/admin/system"),
    ("GET", "/api/v1/admin/billing/payments"),
    ("GET", "/api/v1/admin/billing/pricing"),
    ("GET", "/api/v1/admin/jobs"),
    ("GET", "/api/v1/admin/security-events"),
    ("GET", "/api/v1/admin/roles"),
    ("POST", "/api/v1/admin/providers"),
    ("POST", "/api/v1/admin/models/bulk"),
]


def test_users_cannot_access_admin_endpoints(user_client: AuthSession) -> None:
    for method, path in ADMIN_ENDPOINTS:
        response = user_client.request(method, path, json={})
        assert response.status_code == 403, f"{method} {path} returned {response.status_code}"
        assert response.json()["error"]["code"] == "permission_denied"


def test_anonymous_cannot_access_admin_endpoints(client: TestClient) -> None:
    for method, path in ADMIN_ENDPOINTS:
        assert client.request(method, path).status_code == 401, path


def test_admin_endpoints_succeed_for_super_admin(admin_client: AuthSession) -> None:
    for method, path in ADMIN_ENDPOINTS:
        if method == "GET":
            response = admin_client.get(path)
            assert response.status_code == 200, f"{path}: {response.text[:200]}"


def test_super_admin_has_every_permission(admin_client: AuthSession) -> None:
    data = admin_client.get("/api/v1/admin/permissions").json()
    assert data["is_super_admin"] is True
    assert len(data["permissions"]) >= 25


def test_user_permissions_contain_no_admin_scopes(user_client: AuthSession) -> None:
    data = user_client.get("/api/v1/admin/permissions").json()
    assert data["is_super_admin"] is False
    assert data["permissions"] == []


def test_hidden_model_is_invisible_and_unusable_for_users(
    client: TestClient, db: Session, admin_client: AuthSession, user_client: AuthSession
) -> None:
    provider, model = create_provider_and_model(db, visibility="hidden", published=True, capabilities=["chat"])
    listing = user_client.get("/api/v1/models").json()
    assert all(item["id"] != model.id for item in listing["items"])
    assert user_client.get(f"/api/v1/models/{model.id}").status_code == 404
    response = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hi"})
    assert response.status_code == 403
    assert response.json()["error"]["code"] == "model_not_accessible"
    # ...while the administrator can still see it in the admin catalog
    admin_listing = admin_client.get("/api/v1/admin/models?visibility=hidden").json()
    assert any(item["id"] == model.id for item in admin_listing["items"])


def test_disabled_model_is_not_usable_even_when_visible(
    client: TestClient, db: Session, user_client: AuthSession, admin_client: AuthSession
) -> None:
    provider, model = create_provider_and_model(db, visibility="public", published=True, enabled=False)
    response = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hi"})
    assert response.status_code == 403
    assert response.json()["error"]["details"]["code"] == "model_disabled"


def test_disabled_provider_blocks_model_use(db: Session, user_client: AuthSession) -> None:
    provider, model = create_provider_and_model(db, provider_enabled=False)
    response = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hi"})
    assert response.status_code == 403
    assert response.json()["error"]["details"]["code"] == "provider_disabled"


def test_unpublished_model_is_not_offered(db: Session, user_client: AuthSession) -> None:
    provider, model = create_provider_and_model(db, published=False)
    listing = user_client.get("/api/v1/models").json()
    assert all(item["id"] != model.id for item in listing["items"])


def test_restricted_model_requires_grant(db: Session, user_client: AuthSession, admin_client: AuthSession) -> None:
    provider, model = create_provider_and_model(db, access_tier="restricted")
    response = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hi"})
    assert response.status_code == 403
    assert response.json()["error"]["details"]["code"] == "model_restricted"

    # a grant for the user's role unlocks it
    from sqlalchemy import select

    from app.models.provider import ModelGrant
    from app.models.user import Role

    user_role = db.scalars(select(Role).where(Role.slug == "user")).first()
    assert user_role is not None
    db.add(ModelGrant(model_id=model.id, subject_type="role", subject_id=user_role.id))
    db.commit()
    listing = user_client.get("/api/v1/models").json()
    assert any(item["id"] == model.id for item in listing["items"])


def test_subscription_tier_requires_active_subscription(db: Session, user_client: AuthSession) -> None:
    provider, model = create_provider_and_model(db, access_tier="subscription")
    response = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hi"})
    assert response.status_code == 403
    assert response.json()["error"]["details"]["code"] == "subscription_required"


def test_internal_tier_is_never_granted_to_users(db: Session, user_client: AuthSession) -> None:
    provider, model = create_provider_and_model(db, access_tier="internal")
    response = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hi"})
    assert response.status_code == 403
    assert response.json()["error"]["details"]["code"] in ("internal_only", "model_not_available")


def test_support_agent_cannot_manage_providers(db: Session, client: TestClient, admin_client: AuthSession) -> None:
    """Granular permissions: a support agent may read users but not manage providers."""
    from sqlalchemy import select

    from app.models.user import Role, User
    from app.core.crypto import hash_password
    import datetime as dt

    agent_email = "agent@nexatest.io"
    if db.scalars(select(User).where(User.email == agent_email)).first() is None:
        role = db.scalars(select(Role).where(Role.slug == "support_agent")).first()
        user = User(email=agent_email, display_name="Support Agent",
                    password_hash=hash_password("Agent-Password-77"), status="active", email_verified=True,
                    password_changed_at=dt.datetime.now(dt.timezone.utc))
        db.add(user)
        db.flush()
        user.roles.append(role)
        db.commit()
    agent = AuthSession(client, agent_email, "Agent-Password-77")
    agent.login()
    assert agent.get("/api/v1/admin/users").status_code == 200
    assert agent.get("/api/v1/admin/providers").status_code == 403
    assert agent.post("/api/v1/admin/providers", json={"name": "x", "provider_type": "openai"}).status_code == 403


def test_provider_credential_change_requires_specific_permission(
    db: Session, client: TestClient, admin_client: AuthSession
) -> None:
    from sqlalchemy import select

    from app.core.crypto import hash_password
    from app.models.user import Role, User
    import datetime as dt

    email = "modmgr@nexatest.io"
    if db.scalars(select(User).where(User.email == email)).first() is None:
        role = db.scalars(select(Role).where(Role.slug == "model_manager")).first()
        user = User(email=email, display_name="Model Manager", password_hash=hash_password("Manager-Password-77"),
                    status="active", email_verified=True, password_changed_at=dt.datetime.now(dt.timezone.utc))
        db.add(user)
        db.flush()
        user.roles.append(role)
        db.commit()
    manager = AuthSession(client, email, "Manager-Password-77")
    manager.login()
    created = manager.post(
        "/api/v1/admin/providers",
        json={"name": "Manager Provider", "provider_type": "openai", "base_url": "https://api.openai.com/v1",
              "api_key": "sk-manager-key-123456"},
    )
    assert created.status_code == 201, created.text
    provider_id = created.json()["provider"]["id"]
    # model_manager has providers.manage but not providers.credentials
    updated = manager.patch(f"/api/v1/admin/providers/{provider_id}", json={"api_key": "sk-rotated-key-999999"})
    assert updated.status_code == 403
    assert updated.json()["error"]["details"]["required_permission"] == "providers.credentials"


def test_admin_can_test_hidden_model_and_it_stays_hidden(
    db: Session, admin_client: AuthSession, mock_provider_transport, user_client: AuthSession
) -> None:
    """Spec §6/§9: admins test hidden models; the model is not published by testing."""
    import json

    import httpx
    from sqlalchemy import select

    from app.models.provider import Model

    provider, model = create_provider_and_model(db, visibility="hidden", published=False, capabilities=["chat"])

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/chat/completions"):
            return httpx.Response(200, json={
                "id": "chatcmpl-1", "model": "test-model-1",
                "choices": [{"index": 0, "message": {"role": "assistant", "content": "pong"},
                             "finish_reason": "stop"}],
                "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
            })
        return httpx.Response(404, json={"error": {"message": "not found"}})

    mock_provider_transport(handler)
    response = admin_client.post(f"/api/v1/admin/models/{model.id}/test",
                                 json={"operation": "chat", "input": "ping"})
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["success"] is True
    assert payload["response_text"] == "pong"
    assert payload["prompt_tokens"] == 5
    assert payload["billed_to_user"] is False
    assert payload["provider"]["enabled"] is True

    db.expire_all()
    refreshed = db.get(Model, model.id)
    assert refreshed is not None
    assert refreshed.visibility == "hidden"       # testing never publishes
    assert refreshed.published is False
    assert refreshed.last_test_status == "ok"
    # ordinary user still cannot use it
    assert user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hi"}).status_code == 403


def test_admin_cannot_test_with_disabled_provider(db: Session, admin_client: AuthSession) -> None:
    provider, model = create_provider_and_model(db, provider_enabled=False, capabilities=["chat"])
    response = admin_client.post(f"/api/v1/admin/models/{model.id}/test", json={"operation": "chat", "input": "ping"})
    assert response.status_code == 422
    assert "disabled" in response.json()["error"]["message"].lower()


def test_admin_cannot_test_disabled_model(db: Session, admin_client: AuthSession) -> None:
    provider, model = create_provider_and_model(db, enabled=False, capabilities=["chat"])
    response = admin_client.post(f"/api/v1/admin/models/{model.id}/test", json={"operation": "chat", "input": "ping"})
    assert response.status_code == 422
    assert "disabled" in response.json()["error"]["message"].lower()


def test_admin_test_requires_models_test_permission(db: Session, user_client: AuthSession) -> None:
    provider, model = create_provider_and_model(db, capabilities=["chat"])
    response = user_client.post(f"/api/v1/admin/models/{model.id}/test", json={"operation": "chat", "input": "x"})
    assert response.status_code == 403


def test_admin_test_is_audited(db: Session, admin_client: AuthSession, mock_provider_transport) -> None:
    import httpx
    from sqlalchemy import select

    from app.models.admin import AdminModelTest
    from app.models.admin import AuditEvent

    provider, model = create_provider_and_model(db, visibility="hidden", capabilities=["chat"])
    mock_provider_transport(lambda request: httpx.Response(200, json={
        "id": "chatcmpl-2", "choices": [{"index": 0, "message": {"content": "ok"}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 3, "completion_tokens": 1, "total_tokens": 4}}))
    admin_client.post(f"/api/v1/admin/models/{model.id}/test", json={"operation": "chat", "input": "ping"})
    events = db.scalars(select(AuditEvent).where(AuditEvent.action == "model.tested")).all()
    assert events, "model test must be audited"
    tests = db.scalars(select(AdminModelTest).where(AdminModelTest.model_id == model.id)).all()
    assert tests and tests[-1].bypassed_user_restrictions is True
    assert tests[-1].used_model_visibility == "hidden"


def test_admin_granted_credits_go_through_ledger(db: Session, admin_client: AuthSession) -> None:
    from sqlalchemy import select

    from app.models.user import User

    user = db.scalars(select(User).where(User.email == "admin@nexatest.io")).first()
    assert user is not None
    before = admin_client.get("/api/v1/billing/balance").json()["balance_micro"]
    response = admin_client.post(f"/api/v1/admin/users/{user.id}/credits",
                                 json={"amount_micro": 2_500_000, "reason": "test top-up"})
    assert response.status_code == 200, response.text
    after = admin_client.get("/api/v1/billing/balance").json()["balance_micro"]
    assert after == before + 2_500_000


def test_suspended_user_cannot_authenticate(db: Session, client: TestClient, admin_client: AuthSession, user_client: AuthSession) -> None:
    from sqlalchemy import select

    from app.models.user import User

    user = db.scalars(select(User).where(User.email == user_client.email)).first()
    assert user is not None
    response = admin_client.post(f"/api/v1/admin/users/{user.id}/suspend", json={"reason": "abuse test"})
    assert response.status_code == 200
    relogin = client.post("/api/v1/auth/login", json={"email": user_client.email, "password": "Tester-Password-99"})
    assert relogin.status_code == 401
    assert "suspended" in relogin.json()["error"]["message"].lower()
    # the user's live sessions were revoked
    assert user_client.get("/api/v1/auth/me").status_code == 401


def test_every_permission_the_api_demands_exists_in_the_catalogue() -> None:
    """A guard on a permission nobody can hold locks a screen for everybody — including the owner.

    `GET /api/v1/admin/telegram/status` required `settings.read`, which is not part of
    `PERMISSION_GROUPS`. The super admin role stores the catalogue's 30 permissions (the `*`
    wildcard is expanded at bootstrap), so not even the owner of the installation could open the
    Telegram status screen: the request failed with 403. Nothing failed loudly — the endpoint was
    simply never reachable. This check reads every `require_permission(...)` string in the server
    code and compares it with the catalogue, so a typo or an invented slug is caught at test time.
    """
    import re
    from pathlib import Path

    from app.models.enums import ALL_PERMISSIONS

    app_dir = Path(__file__).resolve().parents[1] / "app"
    known = set(ALL_PERMISSIONS) | {"*"}  # "*" is the super-admin wildcard
    used: dict[str, set[str]] = {}
    for path in app_dir.rglob("*.py"):
        text = path.read_text()
        for match in re.finditer(r'require_permission\(\s*"([^"]+)"', text):
            used.setdefault(match.group(1), set()).add(str(path.relative_to(app_dir)))
        for match in re.finditer(r"require_any_permission\(\s*\[([^\]]+)\]", text):
            for name in re.findall(r'"([^"]+)"', match.group(1)):
                used.setdefault(name, set()).add(str(path.relative_to(app_dir)))

    assert used, "no permission guards found — the scan is broken, not the code"
    unknown = {name: sorted(files) for name, files in used.items() if name not in known}
    assert not unknown, f"the API demands permissions that no role can ever hold: {unknown}"
