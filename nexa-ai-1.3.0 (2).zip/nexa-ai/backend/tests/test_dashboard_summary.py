"""Round 16 — GET /api/v1/dashboard/summary.

The user dashboard must report exactly that user's own numbers: no other user's traffic,
no admin-test rows, a dense daily series with honest zeros, and the model names behind
the spend. It is also a normal authenticated endpoint — anonymous callers get 401 and
bad windows get 422.
"""
import datetime as dt
import uuid

from sqlalchemy import select

from app.models.billing import UsageRecord
from app.models.user import User as UserModel
from tests.conftest import create_provider_and_model


def _record(db, user_id: int, *, charged_micro: int = 1000, total_tokens: int = 100,
            model_id: int | None = None, module: str = "chat", operation: str = "chat",
            status: str = "succeeded", when: dt.timedelta | None = None,
            is_admin_test: bool = False) -> UsageRecord:
    created = dt.datetime.now(dt.timezone.utc) - (when or dt.timedelta(0))
    record = UsageRecord(
        user_id=user_id, model_id=model_id, operation=operation, module=module,
        status=status, charged_micro=charged_micro, total_tokens=total_tokens,
        latency_ms=123, is_admin_test=is_admin_test,
        idempotency_key=f"dash-test:{uuid.uuid4().hex}",
        created_at=created,
    )
    db.add(record)
    db.commit()
    return record


def _user_id(db, email: str) -> int:
    user = db.scalars(select(UserModel).where(UserModel.email == email)).first()
    assert user is not None
    return user.id


def test_summary_reports_my_spend_chart_models_and_traces(user_client, second_user_client, db) -> None:
    me = _user_id(db, user_client.email)
    other = _user_id(db, second_user_client.email)
    _, model = create_provider_and_model(db, published=True, display_name="Dash Model")

    _record(db, me, charged_micro=1500, total_tokens=210, model_id=model.id,
            when=dt.timedelta(minutes=5))                                  # today, chat
    _record(db, me, charged_micro=2500, total_tokens=90, module="telegram", model_id=model.id,
            when=dt.timedelta(days=1))                                     # yesterday, bot
    _record(db, other, charged_micro=999_999, when=dt.timedelta(minutes=5))  # another user: invisible
    _record(db, me, charged_micro=7777, is_admin_test=True,
            when=dt.timedelta(minutes=5))                                  # admin-test row: excluded

    response = user_client.get("/api/v1/dashboard/summary", params={"days": 7})
    assert response.status_code == 200
    data = response.json()
    assert data["window_days"] == 7

    kpis = data["kpis"]
    assert kpis["spent_window_micro"] == 4000, "only my own, non-admin-test usage counts"
    assert kpis["spent_today_micro"] == 1500
    assert kpis["requests_window"] == 2
    assert kpis["tokens_window"] == 300
    assert kpis["balance_micro"] >= 0

    assert len(data["daily"]) == 7, "the chart series is dense — one point per day"
    today = dt.datetime.now(dt.timezone.utc).date().isoformat()
    assert data["daily"][-1]["day"] == today
    assert data["daily"][-1]["charged_micro"] == 1500
    assert data["daily"][-2]["charged_micro"] == 2500
    assert sum(point["charged_micro"] for point in data["daily"]) == 4000
    assert sum(point["requests"] for point in data["daily"]) == 2

    assert data["top_models"] and data["top_models"][0]["name"] == "Dash Model"
    assert data["top_models"][0]["charged_micro"] == 4000 and data["top_models"][0]["requests"] == 2
    assert sum(item["charged_micro"] for item in data["top_models"]) == 4000

    assert len(data["recent"]) == 2
    assert {row["module"] for row in data["recent"]} == {"chat", "telegram"}
    assert all(row["status"] == "succeeded" and row["latency_ms"] == 123 for row in data["recent"])
    assert data["recent"][0]["charged_micro"] in (1500, 2500)


def test_summary_requires_auth_and_validates_the_window(client) -> None:
    assert client.get("/api/v1/dashboard/summary").status_code == 401
    # an authenticated caller cannot ask for a silly window
    # (422 comes from Query(ge=7, le=90); 401 is checked above for anonymous)


def test_summary_window_bounds_are_enforced(user_client) -> None:
    assert user_client.get("/api/v1/dashboard/summary", params={"days": 3}).status_code == 422
    assert user_client.get("/api/v1/dashboard/summary", params={"days": 200}).status_code == 422
    assert user_client.get("/api/v1/dashboard/summary", params={"days": 30}).status_code == 200


def test_summary_is_empty_but_wellformed_for_a_fresh_account(user_client) -> None:
    data = user_client.get("/api/v1/dashboard/summary").json()
    assert data["kpis"]["spent_window_micro"] == 0
    assert data["kpis"]["requests_window"] == 0
    assert len(data["daily"]) == 30
    assert all(point["charged_micro"] == 0 and point["requests"] == 0 for point in data["daily"])
    assert data["top_models"] == []
    assert data["recent"] == []
