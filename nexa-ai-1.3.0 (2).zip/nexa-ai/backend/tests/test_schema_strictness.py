"""Write payloads must refuse unknown fields instead of silently dropping them.

The defect this pins down: `PATCH /api/v1/admin/models/{id}` with
`{"selling_per_mtok_input": 3}` answered **200** while the real field
(`selling_input_per_mtok`) stayed unset. The platform then billed the configured minimum
(or nothing) and the operator only saw a warning buried in a log line — a money bug that
looked like success. Every write body now derives from :class:`StrictModel`
(`extra="forbid"`), so a typo is a loud 422 that names the offending keys.
"""
from __future__ import annotations

import pytest

from tests.conftest import create_provider_and_model


@pytest.mark.parametrize(
    ("method", "path", "body"),
    [
        # money: selling and provider prices
        ("PATCH", "/api/v1/admin/models/{model_id}", {"selling_per_mtok_input": "3.0"}),
        ("PATCH", "/api/v1/admin/models/{model_id}", {"sellingPrices": {"input": 3}}),
        # publishing / lifecycle
        ("PATCH", "/api/v1/admin/models/{model_id}", {"publish": True}),
        # sub-models
        ("POST", "/api/v1/admin/model-variants/models/{model_id}", {"name": "x", "prompt": "hello"}),
    ],
)
def test_unknown_fields_on_admin_model_writes_are_rejected(admin_client, db, method, path, body) -> None:
    provider, model = create_provider_and_model(db, published=True)
    url = path.format(model_id=model.id)
    response = admin_client.request(method, url, json=body)
    assert response.status_code == 422, f"{method} {url} accepted an unknown field: {response.text}"
    detail = response.json()["error"]["details"]["fields"]
    unknown = next(iter(detail))
    assert "Extra inputs are not permitted" in detail[unknown]


def test_the_correct_field_names_still_work(admin_client, db) -> None:
    """Strictness must not break the real contract (this is what the frontend sends)."""
    provider, model = create_provider_and_model(db, published=True)
    response = admin_client.patch(
        f"/api/v1/admin/models/{model.id}",
        json={"selling_input_per_mtok": "3.0", "selling_output_per_mtok": "15.0"},
    )
    assert response.status_code == 200, response.text
    assert float(response.json()["model"]["selling_input_per_mtok"]) == 3.0


@pytest.mark.parametrize(
    ("method", "path", "body"),
    [
        ("POST", "/api/v1/admin/providers", {"name": "p", "provider_type": "openai_compatible",
                                             "base_url": "https://example.test/v1", "api_key": "k",
                                             "networkPreference": "ipv4"}),
        ("POST", "/api/v1/admin/users/{user_id}/credits", {"amount": 10, "note": "x"}),
        ("POST", "/api/v1/billing/payments", {"amount_micro": 10_000_000, "method": "bank_transfer", "extra": 1}),
    ],
)
def test_unknown_fields_on_other_write_endpoints_are_rejected(admin_client, db, method, path, body) -> None:
    from sqlalchemy import select

    from app.models.user import User

    user = db.scalars(select(User)).first()
    url = path.format(user_id=user.id)
    response = admin_client.request(method, url, json=body)
    assert response.status_code == 422, f"{method} {url} accepted an unknown field: {response.text}"
    assert "Extra inputs are not permitted" in response.text
