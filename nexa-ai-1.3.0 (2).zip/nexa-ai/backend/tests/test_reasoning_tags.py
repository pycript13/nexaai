"""Reasoning models that inline their chain of thought in the answer.

Verified live against the paid Dahl endpoint (`https://inference.dahl.global/v1`):

* `MiniMaxAI/MiniMax-M2.7` returns the **whole** answer as
  `<think>The user says: "…"</think>ready`. Before this test existed, the chat screen printed the
  raw tags, and — worse — a reply whose budget ran out inside the thinking block arrived as
  `finish_reason=length` with no visible answer at all, which the UI rendered as an empty bubble.
* `zai-org/GLM-5.3-Flash` streams the same content through the dedicated `delta.reasoning` field.

Both shapes are covered here: the splitter itself, and the adapter that uses it (non-streaming and
streaming, including a tag split across two chunks, which is what really happens on the wire).
"""
from __future__ import annotations

import asyncio
import json

import httpx

from app.providers.base import ChatMessage, ChatRequest, ProviderCredentials
from app.providers.openai_compatible import OpenAICompatibleAdapter
from app.providers.reasoning import InlineReasoningStream, split_inline_reasoning


# --------------------------------------------------------------------- the splitter --
def test_inline_thinking_is_moved_out_of_the_visible_answer() -> None:
    text, reasoning = split_inline_reasoning('<think>The user asks for "ready".</think>ready')
    assert text == "ready"
    assert reasoning == 'The user asks for "ready".'


def test_an_unterminated_block_counts_as_reasoning_not_as_an_answer() -> None:
    """The truncated case: the model spent its whole output budget thinking."""
    text, reasoning = split_inline_reasoning("<think>thinking, thinking, thinking")
    assert text == ""
    assert reasoning and "thinking" in reasoning


def test_a_dedicated_reasoning_field_is_kept_alongside_inline_reasoning() -> None:
    text, reasoning = split_inline_reasoning("<think>inline</think>answer", "field")
    assert text == "answer"
    assert reasoning == "field\n\ninline"


def test_plain_answers_are_untouched() -> None:
    assert split_inline_reasoning("just an answer") == ("just an answer", None)
    assert split_inline_reasoning("") == ("", None)
    assert split_inline_reasoning(None) == ("", None)
    # a literal comparison in the answer is not a tag
    assert split_inline_reasoning("use <thinking_cap> tags")[0] == "use <thinking_cap> tags"


def test_streaming_splitter_handles_a_tag_cut_in_half() -> None:
    stream = InlineReasoningStream()
    parts = [stream.feed(chunk) for chunk in ["<thi", "nk>the user", " wants</thi", "nk>ready", " now"]]
    parts.append(stream.flush())
    assert "".join(visible for visible, _ in parts) == "ready now"
    assert "".join(reasoning for _, reasoning in parts) == "the user wants"


def test_streaming_splitter_releases_an_unterminated_thinking_block() -> None:
    stream = InlineReasoningStream()
    first = stream.feed("<think>only thinking")
    tail = stream.flush()
    assert first == ("", "only thinking")
    assert tail == ("", "")


def test_the_blank_line_after_a_thinking_block_is_not_part_of_the_answer() -> None:
    """Live shape: `…</think>\n\nParis` — the answer is `Paris`, not `\n\nParis`."""
    stream = InlineReasoningStream()
    parts = [stream.feed("<think>hmm</think>\n\nParis"), stream.flush()]
    assert "".join(visible for visible, _ in parts) == "Paris"
    assert "".join(reasoning for _, reasoning in parts) == "hmm"


def test_blank_lines_inside_an_answer_are_preserved() -> None:
    stream = InlineReasoningStream()
    parts = [stream.feed("line one\n\nline two"), stream.flush()]
    assert "".join(visible for visible, _ in parts) == "line one\n\nline two"


def test_streaming_splitter_does_not_swallow_a_lone_angle_bracket() -> None:
    stream = InlineReasoningStream()
    parts = [stream.feed("a<"), stream.feed("b"), stream.feed(">c"), stream.flush()]
    assert "".join(visible for visible, _ in parts) == "a<b>c"


# --------------------------------------------------------------------- the adapter --
def _provider(**overrides) -> OpenAICompatibleAdapter:  # noqa: ANN003
    options = {
        "api_key": "sk-test-key-1234567890",
        "base_url": "https://provider.test/v1",
        "connect_timeout": 2,
        "read_timeout": 5,
        "max_retries": 0,
        "provider_slug": "dahl",
        "provider_name": "Dahl",
    }
    options.update(overrides)
    return OpenAICompatibleAdapter(ProviderCredentials(**options))


def _non_streaming_response(content: str, *, finish_reason: str = "stop", reasoning: str | None = None) -> httpx.Response:
    message: dict[str, object] = {"role": "assistant", "content": content}
    if reasoning is not None:
        message["reasoning_content"] = reasoning
    return httpx.Response(
        200,
        json={
            "id": "req-1",
            "model": "MiniMaxAI/MiniMax-M2.7",
            "choices": [{"index": 0, "message": message, "finish_reason": finish_reason}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 25, "total_tokens": 35},
        },
    )


def test_adapter_admits_only_the_visible_answer_for_a_reasoning_model(mock_provider_transport) -> None:
    mock_provider_transport(lambda request: _non_streaming_response("<think>hidden chain</think>ready"))

    async def run() -> object:
        return await _provider().chat(ChatRequest(model="m", messages=[ChatMessage(role="user", content="hi")]))

    response = asyncio.run(run())
    assert response.text == "ready"                       # no raw tags in the answer
    assert response.reasoning == "hidden chain"           # kept, and shown in its own panel


def test_adapter_reports_an_empty_answer_when_the_thinking_ate_the_budget(mock_provider_transport) -> None:
    mock_provider_transport(lambda request: _non_streaming_response("<think>still thinking", finish_reason="length"))

    async def run() -> object:
        return await _provider().chat(ChatRequest(model="m", messages=[ChatMessage(role="user", content="hi")]))

    response = asyncio.run(run())
    assert response.text == ""
    assert response.reasoning and "still thinking" in response.reasoning
    assert response.finish_reason == "length"


def test_adapter_splits_reasoning_during_streaming(mock_provider_transport) -> None:
    """Deltas that break the tag in two — the real wire shape."""
    chunks = [
        {"id": "c1", "choices": [{"index": 0, "delta": {"content": "<thi"}, "finish_reason": None}]},
        {"id": "c2", "choices": [{"index": 0, "delta": {"content": "nk>secret plans</thi"}, "finish_reason": None}]},
        {"id": "c3", "choices": [{"index": 0, "delta": {"content": "nk>Hello"}, "finish_reason": None}]},
        {"id": "c4", "choices": [{"index": 0, "delta": {"content": " there"}, "finish_reason": "stop"}]},
    ]
    body = "".join(f"data: {json.dumps(chunk)}\n\n" for chunk in chunks) + "data: [DONE]\n\n"

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=body.encode(), headers={"content-type": "text/event-stream"})

    mock_provider_transport(handler)

    async def run() -> list[tuple[str, str]]:
        out: list[tuple[str, str]] = []
        async for chunk in _provider().stream_chat(ChatRequest(model="m", messages=[ChatMessage(role="user", content="hi")])):
            out.append((chunk.delta, chunk.reasoning_delta))
        return out

    pairs = asyncio.run(run())
    assert "".join(delta for delta, _ in pairs) == "Hello there"
    assert "".join(reasoning for _, reasoning in pairs) == "secret plans"


def test_adapter_keeps_a_dedicated_reasoning_delta_field(mock_provider_transport) -> None:
    """`delta.reasoning` (GLM-5.3-Flash live) must reach the client as reasoning, not as an answer."""
    chunks = [
        {"id": "c1", "choices": [{"index": 0, "delta": {"reasoning": "weighing options"}, "finish_reason": None}]},
        {"id": "c2", "choices": [{"index": 0, "delta": {"content": "Done."}, "finish_reason": "stop"}]},
    ]
    body = "".join(f"data: {json.dumps(chunk)}\n\n" for chunk in chunks) + "data: [DONE]\n\n"
    mock_provider_transport(lambda request: httpx.Response(200, content=body.encode(), headers={"content-type": "text/event-stream"}))

    async def run() -> list[tuple[str, str]]:
        out: list[tuple[str, str]] = []
        async for chunk in _provider().stream_chat(ChatRequest(model="m", messages=[ChatMessage(role="user", content="hi")])):
            out.append((chunk.delta, chunk.reasoning_delta))
        return out

    pairs = asyncio.run(run())
    assert "".join(delta for delta, _ in pairs) == "Done."
    assert "weighing options" in "".join(reasoning for _, reasoning in pairs)
