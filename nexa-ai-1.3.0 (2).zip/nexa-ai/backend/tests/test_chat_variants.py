"""Answer variants: regeneration keeps previous answers instead of destroying them.

Contract:
- regenerate marks the old answer ``superseded`` and appends the new one as active;
- the conversation history fed to the model contains only the active variant;
- POST /messages/{id}/activate-variant switches the active variant, persisted;
- exports carry the active variant only (json keeps everything, with statuses).
"""
import json

import httpx
from sqlalchemy.orm import Session

from tests.conftest import AuthSession, create_provider_and_model, grant_credits

ANSWERS = ["answer-one", "answer-two", "answer-three"]


def _handler_factory(captured: list[dict]):
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        if not request.url.path.endswith("/chat/completions"):
            return httpx.Response(404, json={"error": {"message": "not found"}})
        payload = json.loads(request.content.decode())
        captured.append(payload)
        text = ANSWERS[min(calls["n"], len(ANSWERS) - 1)]
        calls["n"] += 1
        return httpx.Response(200, json={
            "id": "c1", "model": "test-model-1",
            "choices": [{"index": 0, "message": {"role": "assistant", "content": text}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 6, "completion_tokens": 2, "total_tokens": 8},
        })

    return handler


def _setup(user_client: AuthSession, db: Session, mock_provider_transport, captured: list[dict]) -> int:
    grant_credits(db, user_client.email, 10.0)
    _provider, model = create_provider_and_model(db, capabilities=["chat"])
    mock_provider_transport(_handler_factory(captured))
    body = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hello"}).json()
    return body["conversation"]["id"]


def _assistants(user_client: AuthSession, conversation_id: int) -> list[dict]:
    detail = user_client.get(f"/api/v1/chat/conversations/{conversation_id}").json()
    return [m for m in detail["messages"] if m["role"] == "assistant"]


def test_regenerate_keeps_variants(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    captured: list[dict] = []
    conversation_id = _setup(user_client, db, mock_provider_transport, captured)

    user_client.post(f"/api/v1/chat/conversations/{conversation_id}/regenerate")
    variants = _assistants(user_client, conversation_id)
    assert [v["content"] for v in variants] == ["answer-one", "answer-two"]
    assert [v["status"] for v in variants] == ["superseded", "complete"]

    user_client.post(f"/api/v1/chat/conversations/{conversation_id}/regenerate")
    variants = _assistants(user_client, conversation_id)
    assert [v["content"] for v in variants] == ANSWERS
    assert [v["status"] for v in variants] == ["superseded", "superseded", "complete"]


def test_activate_variant_switches_history_and_export(user_client: AuthSession, db: Session, mock_provider_transport) -> None:
    captured: list[dict] = []
    conversation_id = _setup(user_client, db, mock_provider_transport, captured)
    user_client.post(f"/api/v1/chat/conversations/{conversation_id}/regenerate")

    first = _assistants(user_client, conversation_id)[0]
    switched = user_client.post(f"/api/v1/chat/messages/{first['id']}/activate-variant")
    assert switched.status_code == 200, switched.text
    assert switched.json()["variant_index"] == 0 and switched.json()["variant_count"] == 2
    assert [v["status"] for v in _assistants(user_client, conversation_id)] == ["complete", "superseded"]

    # the next turn must be built on the re-activated variant, not the newer draft
    user_client.post("/api/v1/chat/completions", json={"conversation_id": conversation_id, "message": "next question"})
    sent = captured[-1]["messages"]
    sent_texts = [m.get("content", "") for m in sent]
    assert "answer-one" in sent_texts and "answer-two" not in sent_texts

    markdown = user_client.get(f"/api/v1/chat/conversations/{conversation_id}/export?format=markdown").json()
    assert "answer-one" in markdown["content"] and "answer-two" not in markdown["content"]
