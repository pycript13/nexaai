"""Settings store: encrypted secrets and the audit-log rendering that must never crash."""
from __future__ import annotations

from app.services import settings_store


def test_safe_handles_every_value_type() -> None:
    assert settings_store._safe(None) is None
    assert settings_store._safe(0) == 0
    assert settings_store._safe(False) is False
    assert settings_store._safe(12.5) == 12.5
    assert settings_store._safe("x" * 500) == "x" * 200
    assert settings_store._safe("my password") == "***redacted***"
    assert settings_store._safe({"secret": "abc"}) == "***encrypted***"
    assert settings_store._safe({"value": None}) == {"value": None}
    assert settings_store._safe(["a", None]) == ["a", None]


def test_set_value_writes_an_audit_row_for_an_empty_previous_value(db) -> None:
    """A brand-new key has no previous value; the audit write must still succeed (was a 500)."""
    row = settings_store.set_value(db, "ui.round12_probe", "Signal_Bot")
    assert settings_store.get_value(db, "ui.round12_probe") == "Signal_Bot"
    assert row.is_secret is False
    again = settings_store.set_value(db, "ui.round12_probe", "Signal_Bot_2")
    assert settings_store.get_value(db, "ui.round12_probe") == "Signal_Bot_2"
    assert again.key == "ui.round12_probe"


def test_secret_round_trip_is_encrypted_at_rest(db) -> None:
    settings_store.set_secret(db, "telegram.bot_token", "123456:AAF-secret-value", category="integrations")
    assert settings_store.get_secret(db, "telegram.bot_token") == "123456:AAF-secret-value"
    stored = settings_store._row(db, "telegram.bot_token")
    assert stored is not None and stored.is_secret is True
    assert "AAF-secret-value" not in str(stored.value_json)  # ciphertext, not plaintext
    status = settings_store.secret_status(db, "telegram.bot_token")
    assert status["configured"] is True and status["hint"].startswith("…")
    assert settings_store.clear_secret(db, "telegram.bot_token") is True
    assert settings_store.get_secret(db, "telegram.bot_token") == ""
    assert settings_store.secret_status(db, "telegram.bot_token")["configured"] is False


def test_secret_rows_are_masked_in_listings(db) -> None:
    settings_store.set_secret(db, "telegram.bot_token", "123456:AAF-secret-value")
    rows = {row["key"]: row for row in settings_store.all_settings(db)}
    row = rows["telegram.bot_token"]
    assert "123456:AAF" not in str(row)  # never the value
    assert row.get("is_secret") is True
