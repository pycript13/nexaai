"""Public catalog: visibility != availability != access (spec §9)."""
from __future__ import annotations

import json

from sqlalchemy.orm import Session

from tests.conftest import AuthSession, create_provider_and_model, grant_credits

# The catalogue is paginated (default page_size=25).  A full session creates a few dozen
# models, so the newest one legitimately sits on a later page: the assertions below are
# about *which* models are listed, not about paging, so ask for one generous page.
CATALOG = "/api/v1/models?page_size=200"


def test_catalog_lists_only_published_public_models(user_client: AuthSession, db: Session) -> None:
    grant_credits(db, user_client.email, 5.0)
    provider, visible = create_provider_and_model(db, display_name="Visible Model", published=True)
    _, hidden = create_provider_and_model(db, visibility="hidden", published=False, display_name="Hidden Model")
    _, unpublished = create_provider_and_model(db, visibility="public", published=False, display_name="Draft Model")
    _, internal = create_provider_and_model(db, access_tier="internal", display_name="Internal Model")
    _, disabled = create_provider_and_model(db, display_name="Disabled Model", enabled=False)

    listing = user_client.get(CATALOG).json()
    ids = {item["id"] for item in listing["items"]}
    assert visible.id in ids
    for excluded in (hidden, unpublished, internal, disabled):
        assert excluded.id not in ids, f"model {excluded.id} must not be listed"


def test_catalog_detail_hides_inaccessible_models(user_client: AuthSession, db: Session) -> None:
    grant_credits(db, user_client.email, 5.0)
    _, model = create_provider_and_model(db)
    assert user_client.get(f"/api/v1/models/{model.id}").status_code == 200
    _, hidden = create_provider_and_model(db, visibility="hidden", published=False)
    response = user_client.get(f"/api/v1/models/{hidden.id}")
    assert response.status_code in (403, 404)


def test_availability_is_not_visibility(user_client: AuthSession, db: Session) -> None:
    """An 'untested' model must still be invisible until published."""
    grant_credits(db, user_client.email, 5.0)
    provider, model = create_provider_and_model(db, published=True, capabilities=["chat"])
    model.availability = "untested"
    db.commit()
    listing = user_client.get(CATALOG).json()
    entry = next(item for item in listing["items"] if item["id"] == model.id)
    assert entry["availability"] == "untested"
    assert entry["accessible"] is True  # published and priced, but availability is reported honestly
    # availability is reported honestly, but the model is not callable yet
    response = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hi"})
    assert response.status_code in (403, 503)


def test_catalog_filters_by_capability_and_provider(user_client: AuthSession, db: Session) -> None:
    grant_credits(db, user_client.email, 5.0)
    provider, chat_model = create_provider_and_model(db, capabilities=["chat"], display_name="Chatty")
    _, image_model = create_provider_and_model(db, capabilities=["image_generation"], display_name="Painter",
                                               model_id_str="image-model-1")
    by_capability = user_client.get("/api/v1/models?capability=image_generation").json()["items"]
    assert [item["id"] for item in by_capability] == [image_model.id]
    by_provider = user_client.get(f"/api/v1/models?provider={provider.slug}").json()["items"]
    assert {item["id"] for item in by_provider} == {chat_model.id}
    search = user_client.get("/api/v1/models?search=painter").json()["items"]
    assert {item["id"] for item in search} == {image_model.id}


def test_catalog_exposes_pricing_and_capabilities_without_secrets(user_client: AuthSession, db: Session) -> None:
    grant_credits(db, user_client.email, 5.0)
    provider, model = create_provider_and_model(db, capabilities=["chat", "streaming"])
    listing = user_client.get(CATALOG).json()["items"]
    entry = next(item for item in listing if item["id"] == model.id)
    assert entry["pricing"]["input_credits_per_mtok"] == 3.0
    assert entry["pricing"]["output_credits_per_mtok"] == 15.0
    assert "provider_cost" not in json.dumps(entry).lower()
    payload = user_client.get(CATALOG).text
    assert "sk-test-key" not in payload
    assert "api_key" not in payload


def test_model_detail_reports_why_it_is_usable(user_client: AuthSession, db: Session) -> None:
    grant_credits(db, user_client.email, 5.0)
    provider, model = create_provider_and_model(db, capabilities=["chat"])
    payload = user_client.get(f"/api/v1/models/{model.id}").json()
    assert payload["access"]["allowed"] is True
    assert payload["access"]["code"] in {"credit", "free", "subscription_active"}
    assert payload["pricing"]["input_credits_per_mtok"] == 3.0
    assert payload["model"]["id"] == model.id


def test_unauthenticated_catalog_access_is_limited(client, db: Session) -> None:
    from tests.conftest import create_provider_and_model as _create

    _, model = _create(db, display_name="Public Preview")
    response = client.get("/api/v1/models?page_size=200")
    assert response.status_code in (200, 401)
    if response.status_code == 200:
        assert all(item["published"] for item in response.json()["items"])


def test_categories_endpoint(user_client: AuthSession) -> None:
    response = user_client.get("/api/v1/models/categories")
    assert response.status_code == 200
    assert isinstance(response.json().get("items"), list)


def test_subscription_tier_requires_active_subscription(user_client: AuthSession, db: Session, admin_client: AuthSession) -> None:
    grant_credits(db, user_client.email, 5.0)
    provider, model = create_provider_and_model(db, access_tier="subscription", display_name="Sub only")
    listing = user_client.get(CATALOG).json()["items"]
    entry = next(item for item in listing if item["id"] == model.id)
    assert entry["access_tier"] == "subscription"
    plans = admin_client.get("/api/v1/admin/billing/plans").json()["items"]
    assert plans, "a subscription plan must exist for the flow to be testable"
    response = user_client.post("/api/v1/chat/completions", json={"model_id": model.id, "message": "hi"})
    assert response.status_code == 403
    assert response.json()["error"]["details"]["code"] == "subscription_required"


def test_catalog_survives_models_without_any_configured_price(user_client: AuthSession, db: Session) -> None:
    """Regression: an unpriced model (no provider cost, no selling price) must not break the catalogue.

    Regression test for the live-stack crash where
    ``pricing_service.micro_to_credits(quote.input_per_mtok_micro * 1_000_000)``
    (the serializer now goes through ``micro_to_per_mtok_credits``, which is None-safe)
    raised ``TypeError: unsupported operand type(s) for *: 'NoneType' and 'int'``
    for models the price resolver could not price at all.
    """
    from app.models.provider import Provider
    from app.core.crypto import encrypt_secret

    provider = Provider(
        slug="unpriced-provider",
        name="Unpriced provider",
        provider_type="openai_compatible",
        base_url="https://unpriced.example.com/v1",
        api_key_encrypted=encrypt_secret("sk-unpriced-key"),
        enabled=True,
    )
    db.add(provider)
    db.flush()
    from app.models.provider import Model

    model = Model(
        provider_id=provider.id,
        provider_model_id="unpriced-model",
        display_name="Unpriced model",
        capabilities=["chat"],
        visibility="public",
        availability="available",
        access_tier="free",
        enabled=True,
        published=True,
        # every price column deliberately left empty
    )
    db.add(model)
    db.commit()

    response = user_client.get("/api/v1/models", params={"search": "unpriced", "page_size": 100})
    assert response.status_code == 200, response.text
    entry = next(item for item in response.json()["items"] if item["id"] == model.id)
    # unpriced prices are reported as null instead of crashing or inventing a number
    assert entry["pricing"]["input_credits_per_mtok"] is None
    assert entry["pricing"]["output_credits_per_mtok"] is None
    assert entry["pricing"]["minimum_charge_credits"] is not None  # the platform minimum still applies

    detail = user_client.get(f"/api/v1/models/{model.id}")
    assert detail.status_code == 200, detail.text
    assert detail.json()["pricing"]["input_credits_per_mtok"] is None
