"""Advanced money & collaboration round:

* credit campaigns — one-off bonuses and daily/weekly/monthly allowances for
  everyone, a role/group, a plan's subscribers, or named users;
* the platform owner is never charged and never needs a grant, everyone else
  pays strictly by the rules;
* only the owner can delete accounts; suspension blocks sign-in;
* crypto top-ups: owner-configured wallet + rate -> order -> tx hash -> review;
* per-variant (sub-model) prices win over the parent model; a personal variant
  can never set its own price;
* models added without prices receive editable market defaults;
* conversations can be shared (view/edit) and worked on together, and public
  links are read-only.
"""
from __future__ import annotations

import datetime as dt

from sqlalchemy import select

from app.models.provider import Model, ModelVariant
from app.models.user import User
from app.services import pricing as pricing_service
from app.services import settings_store
from tests.conftest import AuthSession, create_provider_and_model, grant_credits


def _balance(session: AuthSession) -> int:
    return session.get("/api/v1/billing/balance").json()["balance_micro"]


def _user_id(db, email: str) -> int:
    return db.scalars(select(User).where(User.email == email)).first().id


# ------------------------------------------------------------- campaigns ----
def test_one_off_bonus_pays_named_users_once(admin_client, user_client, second_user_client, db) -> None:
    before = _balance(user_client)
    target = _user_id(db, user_client.email)
    resp = admin_client.post("/api/v1/admin/billing/grant-campaigns", json={
        "title": "Nowruz bonus", "cadence": "once", "amount_credits": 5,
        "target_type": "users", "target_ref": {"user_ids": [target]},
        "reason": "Nowruz gift", "confirm": True,
    })
    assert resp.status_code == 201, resp.text
    campaign = resp.json()["campaign"]
    assert campaign["total_recipients"] == 1 and campaign["active"] is False
    assert _balance(user_client) == before + 5_000_000
    assert _balance(second_user_client) == 0  # not a target: not paid

    entries = user_client.get("/api/v1/billing/ledger").json()["items"]
    bonus = [e for e in entries if e["type"] == "promotional"]
    assert bonus and "Nowruz" in bonus[0]["description"]


def test_campaign_requires_confirmation_and_owner_permission(admin_client, user_client) -> None:
    resp = admin_client.post("/api/v1/admin/billing/grant-campaigns", json={
        "title": "x", "cadence": "once", "amount_credits": 1, "target_type": "all",
    })
    assert resp.status_code == 422 or "confirm" in resp.text.lower()
    resp = user_client.post("/api/v1/admin/billing/grant-campaigns", json={
        "title": "x", "cadence": "once", "amount_credits": 1, "target_type": "all", "confirm": True,
    })
    assert resp.status_code in (401, 403)


def test_recurring_allowance_runs_when_due_and_never_twice(admin_client, user_client, db) -> None:
    from app.models.billing import CreditCampaign
    from app.services import grants as grants_service

    before = _balance(user_client)
    resp = admin_client.post("/api/v1/admin/billing/grant-campaigns", json={
        "title": "Daily allowance", "cadence": "daily", "amount_credits": 2,
        "target_type": "users", "target_ref": {"user_ids": [_user_id(db, user_client.email)]},
        "reason": "daily", "confirm": True,
    })
    assert resp.status_code == 201, resp.text
    campaign = db.get(CreditCampaign, resp.json()["campaign"]["id"])
    # the first period pays at creation; nothing else is due until tomorrow
    assert _balance(user_client) == before + 2_000_000
    assert grants_service.process_due_campaigns(db) == 0
    # yesterday's period falls due -> pays exactly once, however often we tick
    campaign.next_run_at = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=1)
    db.commit()
    grants_service.process_due_campaigns(db)
    assert _balance(user_client) == before + 4_000_000
    campaign.next_run_at = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=1)
    db.commit()
    grants_service.process_due_campaigns(db)
    assert _balance(user_client) == before + 4_000_000  # same period: idempotent


def test_allowance_skips_suspended_users(admin_client, user_client, db) -> None:
    from app.services import grants as grants_service
    from app.models.billing import CreditCampaign

    uid = _user_id(db, user_client.email)
    user = db.get(User, uid)
    user.status = "suspended"
    db.commit()
    campaign = CreditCampaign(title="t", kind="allowance", cadence="daily", amount_micro=1_000_000,
                              target_type="users", target_ref={"user_ids": [uid]}, active=True)
    db.add(campaign)
    db.commit()
    audience = grants_service.resolve_audience(db, campaign)
    assert all(u.id != uid for u in audience)


# ------------------------------------------------------- owner vs the rules --
def test_platform_owner_is_never_charged(admin_client, db) -> None:
    from app.services import access as access_service

    admin = db.scalars(select(User).where(User.email == admin_client.email)).first()
    assert access_service.is_platform_owner(admin)
    _, model = create_provider_and_model(db, display_name="Owner Free Model", model_id_str="owner-free-1")
    decision = access_service.evaluate_model_access(db, admin, model, operation="chat")
    assert decision.allowed  # zero balance, still open for the owner


def test_regular_user_pays_by_the_rules(user_client, db) -> None:
    _, model = create_provider_and_model(db, display_name="Paid Rule Model", model_id_str="paid-rule-1",
                                         access_tier="credit")
    from app.services import access as access_service

    user = db.scalars(select(User).where(User.email == user_client.email)).first()
    assert not access_service.evaluate_model_access(db, user, model, operation="chat").allowed
    grant_credits(db, user_client.email, 10)
    assert access_service.evaluate_model_access(db, user, model, operation="chat").allowed


def test_suspend_blocks_login_and_only_owner_deletes(admin_client, user_client, db) -> None:
    uid = _user_id(db, user_client.email)
    resp = admin_client.post(f"/api/v1/admin/users/{uid}/suspend", json={"confirm": True, "reason": "abuse"})
    assert resp.status_code == 200, resp.text
    login = admin_client.client.post("/api/v1/auth/login", json={"email": user_client.email, "password": user_client.password})
    assert login.status_code == 401 and "suspended" in login.text.lower()
    assert admin_client.post(f"/api/v1/admin/users/{uid}/reactivate").status_code == 200

    # a non-owner must not delete accounts even with a made-up request
    resp = user_client.delete(f"/api/v1/admin/users/{uid}")
    assert resp.status_code in (401, 403, 422)
    # the owner can (soft delete), and cannot delete themselves
    assert admin_client.delete(f"/api/v1/admin/users/{_user_id(db, admin_client.email)}").status_code == 422
    resp = admin_client.delete(f"/api/v1/admin/users/{uid}")
    assert resp.status_code == 200 and resp.json()["mode"] == "soft"


# ----------------------------------------------------------------- crypto ----
def test_crypto_topup_order_tx_review_flow(admin_client, user_client, db) -> None:
    settings_store.set_value(db, "payments.crypto_wallets", {"USDT-TRC20": "TTestWalletAddress123"}, actor=None)
    settings_store.set_value(db, "payments.crypto_rates", {"USDT-TRC20": 100.0}, actor=None)
    db.commit()
    try:
        _crypto_flow(admin_client, user_client, db)
    finally:
        # panel settings live in the shared test DB: never leak them into
        # other tests (crypto must stay disabled-by-default elsewhere)
        from app.models.admin import AppSetting

        for key in ("payments.crypto_wallets", "payments.crypto_rates"):
            row = db.scalars(select(AppSetting).where(AppSetting.key == key)).first()
            if row is not None:
                db.delete(row)
        db.commit()


def _crypto_flow(admin_client, user_client, db) -> None:

    methods = user_client.get("/api/v1/billing/payment-methods").json()
    usdt = [a for a in methods["crypto"]["assets"] if a["key"] == "USDT-TRC20"][0]
    assert usdt["usable"] and usdt["address"] == "TTestWalletAddress123"

    created = user_client.post("/api/v1/billing/payments", json={
        "amount_micro": 50_000_000, "method": "crypto", "crypto_asset": "USDT-TRC20",
    })
    assert created.status_code == 201, created.text
    payment = created.json()["payment"]
    assert payment["status"] == "pending"
    assert payment["crypto"]["address"] == "TTestWalletAddress123"
    assert abs(payment["crypto"]["amount"] - 0.5) < 1e-9  # 50 credits at 100 credits/USDT
    assert _balance(user_client) == 0  # nothing credited before review

    tx = user_client.post(f"/api/v1/billing/payments/{payment['id']}/crypto-tx",
                          json={"tx_hash": "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6"})
    assert tx.status_code == 200 and tx.json()["payment"]["status"] == "awaiting_review"

    verified = admin_client.post(f"/api/v1/admin/billing/payments/{payment['id']}/verify-crypto",
                                 json={"confirmations": 3})
    assert verified.status_code == 200, verified.text
    approved = admin_client.post(f"/api/v1/admin/billing/payments/{payment['id']}/approve",
                                 json={"confirm": True})
    assert approved.status_code == 200, approved.text
    assert _balance(user_client) == 50_000_000


# --------------------------------------------------------------- pricing -----
def test_variant_price_wins_and_personal_variant_cannot_set_price(admin_client, user_client, db) -> None:
    _, model = create_provider_and_model(db, display_name="Variant Priced", model_id_str="variant-priced-1",
                                         input_price=3.0, output_price=15.0)
    created = admin_client.post(f"/api/v1/admin/model-variants/models/{model.id}", json={
        "name": "Cheap sub-model", "selling_input_per_mtok": 1.0, "selling_output_per_mtok": 2.0,
    })
    assert created.status_code == 201, created.text
    variant = db.get(ModelVariant, created.json()["variant"]["id"])
    user = db.scalars(select(User).where(User.email == user_client.email)).first()
    quote = pricing_service.resolve_price(db, model, user=user, variant=variant)
    assert quote.input_per_mtok_micro == 1_000_000 and quote.output_per_mtok_micro == 2_000_000

    personal = user_client.post("/api/v1/models/variants", json={
        "model_id": model.id, "name": "Mine", "selling_input_per_mtok": 0.01,
    })
    if personal.status_code == 201:
        mine = db.get(ModelVariant, personal.json()["variant"]["id"])
        assert mine.selling_input_per_mtok is None  # silently stripped, never a discount


def test_new_model_gets_market_default_pricing(admin_client, db) -> None:
    _, model = create_provider_and_model(db, display_name="x", model_id_str="tmp")
    model.selling_input_per_mtok = None
    model.selling_output_per_mtok = None
    model.provider_cost_input_per_mtok = None
    model.provider_cost_output_per_mtok = None
    model.provider_model_id = "gpt-4o-mini"
    assert pricing_service.apply_default_pricing(model)
    assert float(model.provider_cost_input_per_mtok) == 0.15
    assert float(model.selling_input_per_mtok) > 0.15  # cost + platform markup
    unknown = Model(provider_id=model.provider_id, provider_model_id="acme-unknown-9000",
                    display_name="?", capabilities=["chat"])
    pricing_service.apply_default_pricing(unknown)
    assert unknown.pricing_uncertain is True and unknown.selling_input_per_mtok is not None


# --------------------------------------------------------------- sharing -----
def _conversation(session: AuthSession, title: str = "Shared chat") -> int:
    resp = session.post("/api/v1/chat/conversations", json={"title": title})
    assert resp.status_code == 201, resp.text
    return resp.json()["conversation"]["id"]


def test_share_view_edit_and_link(user_client, second_user_client, client) -> None:
    cid = _conversation(user_client)
    grant_credits_for = None  # noqa: F841
    # stranger cannot read it
    assert second_user_client.get(f"/api/v1/chat/conversations/{cid}").status_code == 404

    shared = user_client.post(f"/api/v1/chat/conversations/{cid}/shares", json={
        "email": second_user_client.email, "permission": "view",
    })
    assert shared.status_code == 201, shared.text

    inbox = second_user_client.get("/api/v1/chat/shared").json()
    assert any(item["id"] == cid and item["permission"] == "view" for item in inbox["items"])
    opened = second_user_client.get(f"/api/v1/chat/conversations/{cid}")
    assert opened.status_code == 200
    assert opened.json()["conversation"]["access"]["role"] == "viewer"

    # viewer cannot post into it
    posted = second_user_client.post("/api/v1/chat/completions", json={"conversation_id": cid, "message": "hi"})
    assert posted.status_code in (404, 422)

    # upgrade to editor: now they can open it as editor
    upgraded = user_client.post(f"/api/v1/chat/conversations/{cid}/shares", json={
        "email": second_user_client.email, "permission": "edit",
    })
    assert upgraded.status_code == 201
    assert second_user_client.get(f"/api/v1/chat/conversations/{cid}").json()["conversation"]["access"]["role"] == "editor"

    # public link: read-only without an account, dies when revoked
    link = user_client.post(f"/api/v1/chat/conversations/{cid}/shares", json={"link": True})
    token = link.json()["share"]["token"]
    public = client.get(f"/api/v1/chat/shared/link/{token}")
    assert public.status_code == 200 and public.json()["permission"] == "view"
    share_id = link.json()["share"]["id"]
    assert user_client.delete(f"/api/v1/chat/conversations/{cid}/shares/{share_id}").status_code == 200
    assert client.get(f"/api/v1/chat/shared/link/{token}").status_code == 404

    # recipient leaves: the conversation disappears from their inbox
    mine = [i for i in second_user_client.get("/api/v1/chat/shared").json()["items"] if i["id"] == cid][0]
    assert second_user_client.delete(f"/api/v1/chat/shared/{mine['share_id']}").status_code == 200
    assert second_user_client.get(f"/api/v1/chat/conversations/{cid}").status_code == 404
