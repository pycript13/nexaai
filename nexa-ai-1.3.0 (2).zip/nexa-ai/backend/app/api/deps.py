"""FastAPI dependencies: authentication, authorization, CSRF, pagination."""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from typing import Annotated, Any

from fastapi import Depends, Header, HTTPException, Query, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.errors import AuthError, PermissionDenied
from app.core.logging import REQUEST_ID, USER_ID
from app.core.security import CSRF_COOKIE, CSRF_HEADER, SESSION_COOKIE, decode_access_token, hash_session_token
from app.db.session import get_db
from app.models.user import AccountStatus, User, UserSession
from app.services import access as access_service

bearer_scheme = HTTPBearer(auto_error=False)

SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}

# Endpoints that establish or recover credentials. They act on *nobody's* existing
# session privileges, and requiring a valid session's CSRF token would make it
# impossible to sign in again after a session was revoked server-side.
CSRF_EXEMPT_PATHS = {
    "/api/v1/auth/login",
    "/api/v1/auth/register",
    "/api/v1/auth/logout",
    "/api/v1/auth/password/reset-request",
    "/api/v1/auth/password/reset",
    "/api/v1/auth/email/verify",
}


@dataclass
class ClientContext:
    ip: str | None
    user_agent: str | None
    request_id: str


def get_client_context(request: Request) -> ClientContext:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        ip = forwarded.split(",")[0].strip()
    else:
        ip = request.client.host if request.client else None
    return ClientContext(ip=ip, user_agent=request.headers.get("user-agent"), request_id=REQUEST_ID.get())


def _touch_session(db: Session, session: UserSession) -> None:
    now = dt.datetime.now(dt.timezone.utc)
    if not session.last_seen_at or (now - session.last_seen_at).total_seconds() > 60:
        session.last_seen_at = now
        db.commit()


def get_current_user_optional(
    request: Request,
    db: Annotated[Session, Depends(get_db)],
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer_scheme)] = None,
) -> User | None:
    user: User | None = None
    session: UserSession | None = None

    token = request.cookies.get(SESSION_COOKIE)
    if token:
        session = db.scalars(select(UserSession).where(UserSession.token_hash == hash_session_token(token))).first()
        if session is not None and session.is_valid():
            user = db.get(User, session.user_id)
        elif session is not None:
            session.revoked_at = dt.datetime.now(dt.timezone.utc)
            session.revoked_reason = "expired"
            db.commit()
    if user is None and credentials is not None:
        try:
            payload = decode_access_token(credentials.credentials)
            user = db.get(User, int(payload["sub"]))
        except Exception:
            user = None
    if user is not None:
        if user.status != AccountStatus.ACTIVE or user.deleted_at is not None:
            raise AuthError(
                "This account is not active.",
                details={"status": user.status, "hint": "Contact platform support if you believe this is a mistake."},
            )
        if user.expires_at and user.expires_at < dt.datetime.now(dt.timezone.utc):
            raise AuthError("This test account has expired.", details={"expires_at": user.expires_at.isoformat()})
        USER_ID.set(str(user.id))
        if session is not None:
            _touch_session(db, session)
    return user


def get_current_user(user: Annotated[User | None, Depends(get_current_user_optional)]) -> User:
    if user is None:
        raise AuthError("Authentication required.")
    return user


def enforce_csrf(request: Request, user: User | None, db: Session) -> None:
    if not settings.csrf_enabled or request.method in SAFE_METHODS:
        return
    if request.url.path in CSRF_EXEMPT_PATHS:
        return
    if user is None:
        return
    token = request.cookies.get(SESSION_COOKIE)
    if not token:
        # Bearer-token (programmatic) requests are not cookie-authenticated, so
        # CSRF does not apply to them.
        return
    session = db.scalars(select(UserSession).where(UserSession.token_hash == hash_session_token(token))).first()
    if session is None or not session.is_valid():
        # A revoked/expired cookie cannot authorise anything: let the request
        # proceed so the client can re-authenticate (it will fail with 401 if the
        # endpoint requires authentication).
        return
    header_token = request.headers.get(CSRF_HEADER) or request.headers.get("x-xsrf-token")
    if not header_token or header_token != session.csrf_token:
        raise PermissionDenied(
            "CSRF validation failed. Reload the page and retry.",
            code="csrf_failed",
            details={"hint": f"Send the session's CSRF token in the '{CSRF_HEADER}' header."},
        )


def get_db_with_csrf(
    request: Request,
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[User | None, Depends(get_current_user_optional)],
) -> Session:
    enforce_csrf(request, user, db)
    return db


DbDep = Annotated[Session, Depends(get_db_with_csrf)]
CurrentUser = Annotated[User, Depends(get_current_user)]
OptionalUser = Annotated[User | None, Depends(get_current_user_optional)]
Client = Annotated[ClientContext, Depends(get_client_context)]


def require_permission(permission: str):  # noqa: ANN201 - dependency factory
    def dependency(user: CurrentUser) -> User:
        if not access_service.has_permission(user, permission):
            raise PermissionDenied(
                f"You need the '{permission}' permission to perform this action.",
                details={"required_permission": permission},
            )
        return user

    return dependency


def require_any_permission(*permissions: str):  # noqa: ANN201
    def dependency(user: CurrentUser) -> User:
        if not access_service.has_any_permission(user, list(permissions)):
            raise PermissionDenied(
                "You do not have any of the permissions required for this action.",
                details={"required_permissions": list(permissions)},
            )
        return user

    return dependency


def require_super_admin(user: CurrentUser) -> User:
    if not access_service.is_super_admin(user):
        raise PermissionDenied("This operation is restricted to the Super Admin.")
    return user


@dataclass
class Page:
    page: int
    page_size: int

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.page_size

    @property
    def limit(self) -> int:
        return self.page_size


def pagination(
    page: Annotated[int, Query(ge=1, le=100_000)] = 1,
    page_size: Annotated[int, Query(ge=1, le=200)] = 25,
) -> Page:
    return Page(page=page, page_size=page_size)


PageDep = Annotated[Page, Depends(pagination)]


def paginated(items: list[Any], total: int, page: Page) -> dict[str, Any]:
    return {
        "items": items,
        "pagination": {
            "page": page.page,
            "page_size": page.page_size,
            "total": total,
            "pages": (total + page.page_size - 1) // page.page_size if page.page_size else 0,
            "has_next": page.page * page.page_size < total,
            "has_prev": page.page > 1,
        },
    }


def rate_limit_key(request: Request, scope: str, identifier: str | None = None) -> str:
    ctx_ip = request.headers.get("x-forwarded-for", "").split(",")[0].strip() or (request.client.host if request.client else "unknown")
    return f"{scope}:{identifier or ctx_ip}"


def http_exception_from(error: Exception) -> HTTPException:  # pragma: no cover - helper
    from app.core.errors import NexaError

    if isinstance(error, NexaError):
        return HTTPException(status_code=error.status_code, detail=error.to_payload())
    return HTTPException(status_code=500, detail={"error": {"code": "internal_error", "message": "Internal server error"}})
