"""Per-user dashboard aggregates (round 16).

The numbers a router-platform dashboard is expected to show — spend, an activity chart,
the models the credits actually go to, and the most recent billed operations — computed
from the same UsageRecord rows the billing pages use. Everything is scoped to the
authenticated user; admin-test rows are excluded, and nothing is estimated: a day with
no traffic is reported as zero instead of being guessed.
"""
from __future__ import annotations

import datetime as dt
from typing import Any

from fastapi import APIRouter, Query
from sqlalchemy import func, select

from app.api.deps import CurrentUser, DbDep
from app.models.billing import CreditAccount, UsageRecord
from app.models.provider import Model

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("/summary")
def dashboard_summary(
    db: DbDep,
    user: CurrentUser,
    days: int = Query(30, ge=7, le=90),
) -> dict[str, Any]:
    """Spend KPIs, a dense daily series, the top models and the latest traces — all mine."""
    now = dt.datetime.now(dt.timezone.utc)
    since = now - dt.timedelta(days=days)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

    def _sum(column, *where) -> int:
        return int(db.scalar(
            select(func.coalesce(func.sum(column), 0)).where(
                UsageRecord.user_id == user.id,
                UsageRecord.is_admin_test.is_(False),
                *where,
            )
        ) or 0)

    spent_today_micro = _sum(UsageRecord.charged_micro, UsageRecord.created_at >= today_start)
    spent_window_micro = _sum(UsageRecord.charged_micro, UsageRecord.created_at >= since)
    tokens_window = _sum(UsageRecord.total_tokens, UsageRecord.created_at >= since)
    requests_window = int(db.scalar(
        select(func.count(UsageRecord.id)).where(
            UsageRecord.user_id == user.id,
            UsageRecord.is_admin_test.is_(False),
            UsageRecord.created_at >= since,
        )
    ) or 0)

    daily_rows = db.execute(
        select(
            func.date(UsageRecord.created_at).label("day"),
            func.coalesce(func.sum(UsageRecord.charged_micro), 0),
            func.count(UsageRecord.id),
        )
        .where(
            UsageRecord.user_id == user.id,
            UsageRecord.is_admin_test.is_(False),
            UsageRecord.created_at >= since,
        )
        .group_by(func.date(UsageRecord.created_at))
        .order_by(func.date(UsageRecord.created_at))
    ).all()
    by_day = {str(day): (int(charged or 0), int(count)) for day, charged, count in daily_rows}
    # a dense series: every day in the window is present, empty days are honest zeros
    daily = []
    for offset in range(days - 1, -1, -1):
        day = (now - dt.timedelta(days=offset)).date().isoformat()
        charged, count = by_day.get(day, (0, 0))
        daily.append({"day": day, "charged_micro": charged, "requests": count})

    top_rows = db.execute(
        select(
            Model.display_name,
            UsageRecord.provider_model_id,
            func.coalesce(func.sum(UsageRecord.charged_micro), 0),
            func.count(UsageRecord.id),
        )
        .join(Model, Model.id == UsageRecord.model_id, isouter=True)
        .where(
            UsageRecord.user_id == user.id,
            UsageRecord.is_admin_test.is_(False),
            UsageRecord.created_at >= since,
        )
        .group_by(Model.display_name, UsageRecord.provider_model_id)
        .order_by(func.sum(UsageRecord.charged_micro).desc())
        .limit(5)
    ).all()
    top_models = [
        {
            "name": display or provider_model or "\u2014",
            "charged_micro": int(charged or 0),
            "requests": int(count),
        }
        for display, provider_model, charged, count in top_rows
    ]

    recent_rows = db.execute(
        select(UsageRecord, Model.display_name)
        .join(Model, Model.id == UsageRecord.model_id, isouter=True)
        .where(UsageRecord.user_id == user.id, UsageRecord.is_admin_test.is_(False))
        .order_by(UsageRecord.created_at.desc(), UsageRecord.id.desc())
        .limit(8)
    ).all()
    recent = [
        {
            "id": record.id,
            "created_at": record.created_at.isoformat() if record.created_at else None,
            "model": display or record.provider_model_id or "\u2014",
            "module": record.module or "\u2014",
            "operation": record.operation,
            "status": record.status,
            "total_tokens": int(record.total_tokens or 0),
            "charged_micro": int(record.charged_micro or 0),
            "latency_ms": record.latency_ms,
        }
        for record, display in recent_rows
    ]

    account = db.scalars(select(CreditAccount).where(CreditAccount.user_id == user.id)).first()
    return {
        "window_days": days,
        "currency": "credits",
        "kpis": {
            "balance_micro": int(account.balance_micro) if account else 0,
            "spent_today_micro": spent_today_micro,
            "spent_window_micro": spent_window_micro,
            "requests_window": requests_window,
            "tokens_window": tokens_window,
            "daily_spend_limit_micro": (int(account.daily_spend_limit_micro)
                                        if account and account.daily_spend_limit_micro else None),
        },
        "daily": daily,
        "top_models": top_models,
        "recent": recent,
    }
