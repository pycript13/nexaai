"""Health & readiness endpoints.

Public probes expose only a boolean and a version (no infrastructure detail, no
secrets). Detailed diagnostics live under /api/v1/admin/system and require
authentication + permissions.
"""
from __future__ import annotations

import datetime as dt
import os
import shutil
import time
from typing import Any

from fastapi import APIRouter, Response
from sqlalchemy import func, select

from app.core.config import settings
from app.db.session import check_database, get_engine
from app.models.jobs import Job, JobStatus
from app.services import email as email_service
from app.services import payments as payments_service

router = APIRouter()
STARTED_AT = time.time()


@router.get("/healthz", include_in_schema=False)
def live() -> dict[str, Any]:
    return {"status": "ok", "service": "nexa-ai-api", "version": settings.version}


@router.get("/readyz", include_in_schema=False)
def ready(response: Response) -> dict[str, Any]:
    db_ok, detail = check_database()
    if not db_ok:
        response.status_code = 503
    return {
        "status": "ready" if db_ok else "degraded",
        "database": "ok" if db_ok else "unavailable",
        "version": settings.version,
    }


@router.get("/api/v1/health")
def public_health(response: Response) -> dict[str, Any]:
    """Minimal public health payload used by the installers' wait loops."""
    db_ok, _ = check_database()
    if not db_ok:
        response.status_code = 503
    return {
        "status": "ok" if db_ok else "degraded",
        "version": settings.version,
        "environment": settings.environment,
        "deployment_mode": settings.deployment_mode,
        "uptime_seconds": int(time.time() - STARTED_AT),
        "time": dt.datetime.now(dt.timezone.utc).isoformat(),
        "security_warning": settings.plain_http_warning,
    }


def _inline_worker_state() -> dict[str, Any]:
    """Live counters of the in-process worker (empty when it is not running)."""
    from app.services import inline_worker

    worker = inline_worker.current()
    if worker is None:
        return {}
    return {
        "running": worker.running,
        "processed": worker.processed,
        "errors": worker.errors,
        "telegram_polling": bool(worker._telegram_thread and worker._telegram_thread.is_alive()),
    }


@router.get("/api/v1/health/deep")
def deep_health(response: Response) -> dict[str, Any]:
    """Slightly deeper probe intended for operators (still no secrets).

    Reports component states without internal identifiers, hostnames or config
    values so it is safe to expose behind the reverse proxy.
    """
    from app.db.session import SessionLocal

    db_ok, dialect = check_database()
    components: dict[str, Any] = {
        "database": {"ok": db_ok, "dialect": dialect if db_ok else None},
        "worker": {**{"inline_mode": settings.inline_worker}, **_inline_worker_state()},
        "email": {"configured": email_service.is_configured()},
        "redis": {"configured": bool(settings.redis_url)},
    }
    queue: dict[str, int] = {}
    if db_ok:
        try:
            with SessionLocal() as db:
                rows = db.execute(select(Job.status, func.count(Job.id)).group_by(Job.status)).all()
                queue = {status: int(count) for status, count in rows}
                components["database"]["pending_migrations_checked"] = True
        except Exception as exc:  # noqa: BLE001
            components["database"]["error"] = str(exc)[:200]
    components["jobs"] = queue
    healthy = db_ok
    if not healthy:
        response.status_code = 503
    return {
        "status": "ok" if healthy else "degraded",
        "version": settings.version,
        "uptime_seconds": int(time.time() - STARTED_AT),
        "components": components,
        "payment_providers": payments_service.gateway_status(),
        "disk": _disk_status(),
    }


def _disk_status() -> dict[str, Any]:
    try:
        usage = shutil.disk_usage(os.environ.get("NEXA_UPLOAD_DIR", "."))
        return {
            "total_gb": round(usage.total / 1024**3, 2),
            "free_gb": round(usage.free / 1024**3, 2),
            "used_percent": round(usage.used / usage.total * 100, 1),
        }
    except Exception:  # pragma: no cover
        return {}


@router.get("/api/v1/health/worker")
def worker_health() -> dict[str, Any]:
    from app.db.session import SessionLocal

    with SessionLocal() as db:
        pending = db.scalar(select(func.count(Job.id)).where(Job.status == JobStatus.PENDING)) or 0
        running = db.scalars(select(Job).where(Job.status == JobStatus.RUNNING)).all()
        stale = [
            {"id": job.id, "type": job.job_type, "lease_expires_at": job.lease_expires_at}
            for job in running
            if job.lease_expires_at and job.lease_expires_at < dt.datetime.now(dt.timezone.utc)
        ]
    return {
        "pending": int(pending),
        "running": len(running),
        "stale_leases": stale,
        "inline_worker": settings.inline_worker,
        "inline_worker_running": bool(_inline_worker_state().get("running")),
        "note": (
            "Jobs run inside the API process (NEXA_INLINE_WORKER=true). "
            "In Docker deployments a dedicated worker service processes them."
        ),
    }
