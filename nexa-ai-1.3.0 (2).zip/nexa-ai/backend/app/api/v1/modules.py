"""AI capability modules (spec §11): coding, documents, translation, data
analysis, image, audio, video, plus job control.

Every module is *gated by real capability data*: if no enabled provider+model
declares the required operation, the endpoint returns a configuration error that
names what is missing — it never fabricates a result.
"""
from __future__ import annotations

import base64
import csv
import io
import json
import statistics
import time
import uuid
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from sqlalchemy import func, select

from app.api.deps import CurrentUser, DbDep, PageDep, paginated
from app.core.errors import ConfigurationError, NotFound, ValidationError
from app.core.logging import get_logger
from app.models.files import FileKind, StoredFile
from app.models.jobs import Job, JobStatus, JobType
from app.models.user import User as UserModel
from app.providers.base import (
    ChatMessage,
    ImageGenerationRequest,
    SpeechRequest,
    TranscriptionRequest,
    VideoGenerationRequest,
)
from app.providers.capabilities import MODULES, Operation
from app.providers.registry import adapter_for_provider
from app.services import access as access_service
from app.services import ai as ai_service
from app.services import files as file_service
from app.services import jobs as job_service
from app.services import pricing as pricing_service
from app.services import usage as usage_service
from app.models.billing import UsageStatus
from app.schemas.common import StrictModel

log = get_logger(__name__)
router = APIRouter(prefix="/modules", tags=["modules"])

CODE_MODES = {
    "generate": "You are a precise senior software engineer. Produce complete, runnable, well-structured code. "
                "Explain briefly, then give the code in fenced blocks with a language tag.",
    "explain": "You are a patient senior engineer. Explain the supplied code step by step: purpose, data flow, "
               "edge cases and risks. Be concrete and reference exact identifiers.",
    "refactor": "You are a code reviewer. Refactor the supplied code for clarity, performance and idiomatic style. "
                "Preserve behaviour. Show a unified diff or the full refactored file plus a rationale list.",
    "debug": "You are a debugging specialist. Identify the likely root cause of the reported problem, list the "
             "evidence, then give the minimal fix and how to verify it.",
    "review": "You are a security-focused reviewer. List concrete findings (correctness, security, performance, "
              "maintainability) with severity and suggested patches.",
    "test": "You are a test engineer. Write thorough tests (happy path, boundaries, failure modes). State the "
            "framework. Do not invent APIs that were not provided.",
}


class CodingRequest(StrictModel):
    model_id: int
    mode: str = "generate"
    prompt: str = Field(min_length=1)
    language: str | None = None
    code: str | None = None
    context: str | None = None
    temperature: float | None = Field(default=0.2, ge=0, le=2)
    max_tokens: int | None = Field(default=None, ge=1, le=100_000)
    conversation_id: int | None = None


class TranslateRequest(StrictModel):
    model_id: int
    text: str | None = None
    texts: list[str] | None = None
    source_language: str = "auto"
    target_language: str
    tone: str | None = None
    glossary: dict[str, str] | None = None
    conversation_id: int | None = None


class DocumentRequest(StrictModel):
    model_id: int | None = None
    file_ids: list[int] = Field(min_length=1, max_length=10)
    mode: str = Field(default="summarize", pattern="^(summarize|ask|extract|translate|index)$")
    question: str | None = None
    target_language: str | None = None
    max_tokens: int | None = Field(default=None, ge=1, le=100_000)
    async_job: bool = False
    embedding_model_id: int | None = None


class DataAnalysisRequest(StrictModel):
    file_id: int
    model_id: int | None = None
    question: str | None = None
    narrative: bool = True
    sheet: str | None = None


class ImageGenerationApiRequest(StrictModel):
    model_id: int
    prompt: str = Field(min_length=1, max_length=4000)
    n: int = Field(default=1, ge=1, le=4)
    size: str | None = None
    quality: str | None = None
    negative_prompt: str | None = None
    seed: int | None = None


class ImageAnalysisRequest(StrictModel):
    model_id: int
    file_id: int
    question: str = "Describe this image in detail."


class TranscriptionApiRequest(StrictModel):
    model_id: int
    file_id: int
    language: str | None = None
    prompt: str | None = None
    async_job: bool = False


class SpeechApiRequest(StrictModel):
    model_id: int
    text: str = Field(min_length=1, max_length=5000)
    voice: str | None = None


class VideoApiRequest(StrictModel):
    model_id: int
    prompt: str = Field(min_length=1, max_length=2000)
    image_url: str | None = None
    duration_seconds: float | None = None
    aspect_ratio: str | None = None


def _require_model(db, model_id: int | None):  # noqa: ANN001
    """Load a model row or fail with a clear validation error."""
    if model_id is None:
        raise ValidationError("Provide 'model_id'.")
    from app.models.provider import Model

    model = db.get(Model, model_id)
    if model is None:
        raise NotFound("Model not found.")
    return model


def _require_operation(db, user, model_id: int | None, operation: str):  # noqa: ANN001
    _require_model(db, model_id)
    return ai_service.resolve_model(db, user=user, model_id=model_id, operation=operation)


def _charge_media(
    db,
    *,
    user,
    model_ref,
    operation: str,
    module: str,
    images: int = 0,
    audio_seconds: float | None = None,
    prompt_tokens: int | None = None,
    completion_tokens: int | None = None,
    latency_ms: int | None = None,
    provider_request_id: str | None = None,
    usage_source: str = "unavailable",
    metadata: dict | None = None,
):
    """Estimate, verify funds, run is caller's job — this records and charges."""
    key = f"{operation}:{uuid.uuid4().hex}"
    outcome = usage_service.record_usage(
        db, user=user, model=model_ref.model, provider=model_ref.provider, operation=operation, module=module,
        status=UsageStatus.SUCCEEDED, idempotency_key=key, prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens, usage_source=usage_source, images=images,
        audio_seconds=audio_seconds, latency_ms=latency_ms, provider_request_id=provider_request_id,
        metadata=metadata,
    )
    return outcome


def _estimate_media_cost(db, user, model, *, images: int = 0, audio_seconds: float | None = None, tokens: int | None = None) -> int:
    quote = pricing_service.resolve_price(db, model, user=user)
    breakdown = pricing_service.compute_charge(
        quote, images=images, audio_seconds=audio_seconds, prompt_tokens=tokens,
        requests=1 if not images and not audio_seconds else 0, access_tier=model.access_tier,
    )
    return breakdown.charged_micro


# ------------------------------------------------------------------ status ---
@router.get("/capabilities")
def module_capabilities(db: DbDep, user: CurrentUser) -> dict[str, Any]:
    """Which modules can actually run right now, based on enabled providers/models."""
    from app.models.provider import AccessTier, Model, ModelAvailability, ModelVisibility, Provider

    models = db.scalars(
        select(Model).join(Provider, Provider.id == Model.provider_id).where(
            Model.enabled.is_(True), Provider.enabled.is_(True), Model.published.is_(True),
            Model.visibility == ModelVisibility.PUBLIC, Model.availability != ModelAvailability.DISABLED,
            Model.access_tier != AccessTier.INTERNAL,
        )
    ).all()
    accessible = access_service.filter_models_for_user(db, user, models)
    capabilities: dict[str, Any] = {}
    for module_key, definition in MODULES.items():
        operations = definition["operations"]
        providers_for_module: list[dict[str, Any]] = []
        for model in accessible:
            for operation in operations:
                if operation in (model.capabilities or []):
                    providers_for_module.append(
                        {"model_id": model.id, "model": model.display_name, "provider": model.provider.name,
                         "operation": operation}
                    )
        capabilities[module_key] = {
            "label": definition["label"],
            "operations": operations,
            "available": bool(providers_for_module),
            "options": providers_for_module[:50],
            "message": None if providers_for_module else (
                "No published model with this capability is available to your account yet. "
                "An administrator must add a provider, verify the model capability and publish it."
            ),
        }
    return {"modules": capabilities}


# ------------------------------------------------------------------ coding ---
@router.post("/coding/assist")
async def coding_assist(payload: CodingRequest, db: DbDep, user: CurrentUser) -> dict[str, Any]:
    if payload.mode not in CODE_MODES:
        raise ValidationError(f"Unknown coding mode '{payload.mode}'. Available: {', '.join(sorted(CODE_MODES))}.")
    ref = _require_operation(db, user, payload.model_id, Operation.CHAT.value)
    system = CODE_MODES[payload.mode]
    if payload.language:
        system += f"\nTarget language/runtime: {payload.language}."
    system += (
        "\nGenerated code is never executed by this platform; the user is responsible for reviewing and running it "
        "in their own environment."
    )
    parts = [payload.prompt]
    if payload.code:
        parts.append(f"\n\n--- Code ---\n```{payload.language or ''}\n{payload.code}\n```")
    if payload.context:
        parts.append(f"\n\n--- Additional context ---\n{payload.context}")
    response, outcome = await ai_service.run_chat(
        db, user=user, model_ref=ref, messages=[ChatMessage(role="user", content="\n".join(parts))],
        system=system, temperature=payload.temperature, max_tokens=payload.max_tokens,
        module="coding", conversation_id=payload.conversation_id,
    )
    # Persist the usage row + credit debit before answering: the response reports a charge,
    # so the charge must exist in the ledger even if the client disconnects afterwards.
    db.commit()
    return {
        "mode": payload.mode,
        "response": response.text,
        "model": ref.model.public_dict(),
        "usage": {"prompt_tokens": outcome.usage.prompt_tokens, "completion_tokens": outcome.usage.completion_tokens,
                  "charged_micro": outcome.usage.charged_micro, "usage_source": outcome.usage.usage_source},
        "safety_note": "Code was generated by a third-party model. It was not executed on the platform.",
    }


# --------------------------------------------------------------- documents ---
def _document_context(db, user, file_ids: list[int], max_chars: int = 120_000,
                      question: str | None = None) -> tuple[str, list[dict[str, Any]]]:
    records: list[StoredFile] = []
    for file_id in file_ids:
        record = db.get(StoredFile, file_id)
        if record is None or (record.user_id != user.id and not access_service.has_permission(user, "users.read")):
            raise NotFound(f"File {file_id} not found.")
        records.append(record)
    chunks: list[str] = []
    meta: list[dict[str, Any]] = []
    budget = max_chars
    for record in records:
        text = record.extracted_text or file_service.extract_text(record, max_chars=budget)
        record.extracted_text = text
        selected, retrieval = file_service.retrieve_context(record, question or "", budget_chars=budget)
        chunks.append(f"=== DOCUMENT: {record.original_name} ===\n{selected}")
        meta.append({"file_id": record.id, "name": record.original_name, "characters": len(text),
                     "extension": record.extension, "mime_type": record.mime_type,
                     "context": retrieval})
        budget -= len(text)
        if budget <= 0:
            break
    db.commit()
    return "\n\n".join(chunks), meta


@router.post("/documents/process")
async def documents_process(payload: DocumentRequest, db: DbDep, user: CurrentUser) -> dict[str, Any]:
    if payload.async_job or payload.mode == "index":
        # long documents are processed in the background so the request does not time out
        job_type = JobType.DOCUMENT_INDEX if payload.mode == "index" else JobType.DOCUMENT_SUMMARY
        if payload.mode == "index" and payload.embedding_model_id is None:
            pass  # indexing without embeddings is a valid lexical index
        elif payload.mode != "index":
            _require_model(db, payload.model_id)
        job = job_service.enqueue(
            db, job_type=job_type, user_id=user.id, model_id=payload.model_id,
            payload={"file_ids": payload.file_ids, "mode": payload.mode, "question": payload.question,
                     "target_language": payload.target_language,
                     "embedding_model_id": payload.embedding_model_id,
                     "max_tokens": payload.max_tokens},
            priority=70 if payload.mode != "index" else 120,
        )
        db.commit()
        from fastapi.encoders import jsonable_encoder

        return JSONResponse(
            status_code=202,
            content=jsonable_encoder({"job": _job_payload(job), "message": "The document job was queued."}),
        )
    _require_model(db, payload.model_id)
    ref = _require_operation(db, user, payload.model_id, Operation.CHAT.value)
    context, meta = _document_context(db, user, payload.file_ids, question=payload.question)
    if payload.mode == "summarize":
        instruction = (
            "Summarise the documents below. Produce: (1) a 3-sentence executive summary, (2) key points as a bullet "
            "list, (3) any figures/dates that matter, (4) open questions. Use the documents only — do not invent facts."
        )
    elif payload.mode == "ask":
        if not payload.question:
            raise ValidationError("Provide a 'question' when mode is 'ask'.")
        instruction = (
            f"Answer the question using ONLY the documents below. Cite the document name and, where possible, the "
            f"section. If the answer is not present, say so explicitly.\n\nQuestion: {payload.question}"
        )
    elif payload.mode == "extract":
        instruction = (
            "Extract structured data from the documents below. Return JSON with keys: entities (people, "
            "organisations), dates, amounts, obligations, and a 'confidence' field per item."
        )
    else:
        instruction = (
            f"Translate the documents below into {payload.target_language or 'English'}. Preserve formatting, numbers "
            "and proper nouns. Output the translated text only."
        )
    response, outcome = await ai_service.run_chat(
        db, user=user, model_ref=ref, messages=[ChatMessage(role="user", content=f"{instruction}\n\n{context}")],
        system="You are a meticulous document analyst. Never fabricate content that is not in the provided documents.",
        max_tokens=payload.max_tokens, module="documents",
    )
    return {
        "mode": payload.mode,
        "result": response.text,
        "documents": meta,
        "model": ref.model.public_dict(),
        "usage": {"prompt_tokens": outcome.usage.prompt_tokens, "completion_tokens": outcome.usage.completion_tokens,
                  "charged_micro": outcome.usage.charged_micro, "usage_source": outcome.usage.usage_source},
    }


# -------------------------------------------------------------- translation --
@router.post("/translation/translate")
async def translate(payload: TranslateRequest, db: DbDep, user: CurrentUser) -> dict[str, Any]:
    items = payload.texts or ([payload.text] if payload.text else [])
    items = [item for item in items if item and item.strip()]
    if not items:
        raise ValidationError("Provide 'text' or a non-empty 'texts' array.")
    if len(items) > 50:
        raise ValidationError("Batch translation is limited to 50 items per request.")
    ref = _require_operation(db, user, payload.model_id, Operation.CHAT.value)
    glossary_hint = ""
    if payload.glossary:
        glossary_hint = "\nUse these exact translations: " + "; ".join(f"{k} → {v}" for k, v in payload.glossary.items())
    tone_hint = f"\nTone: {payload.tone}." if payload.tone else ""
    system = (
        "You are a professional translator. Translate faithfully, preserving meaning, formatting and terminology. "
        "Never add commentary. Reply with the translation only."
    )
    results: list[dict[str, Any]] = []
    charged_total = 0
    prompt_tokens_total = 0
    completion_tokens_total = 0
    for item in items:
        instruction = (
            f"Source language: {payload.source_language or 'auto-detect'}.\nTarget language: {payload.target_language}."
            f"{tone_hint}{glossary_hint}\n\nText:\n{item}"
        )
        response, outcome = await ai_service.run_chat(
            db, user=user, model_ref=ref, messages=[ChatMessage(role="user", content=instruction)], system=system,
            temperature=0.1, module="translation",
        )
        results.append(
            {
                "source": item,
                "translation": response.text.strip(),
                "detected_source_language": payload.source_language if payload.source_language != "auto" else None,
                "detection_note": (
                    "Source language was not supplied, so it was not independently detected. "
                    "Set source_language explicitly if exact detection matters."
                    if payload.source_language in (None, "auto")
                    else None
                ),
            }
        )
        charged_total += outcome.usage.charged_micro
        prompt_tokens_total += outcome.usage.prompt_tokens or 0
        completion_tokens_total += outcome.usage.completion_tokens or 0
    db.commit()
    return {
        "target_language": payload.target_language,
        "items": results,
        "model": ref.model.public_dict(),
        "usage": {"charged_micro": charged_total, "prompt_tokens": prompt_tokens_total,
                  "completion_tokens": completion_tokens_total},
    }


# ------------------------------------------------------------ data analysis --
def _read_tabular(db, record: StoredFile, sheet: str | None = None) -> list[list[Any]]:
    path = file_service.absolute_path_for(record)
    if record.extension == "csv":
        text = path.read_text(encoding="utf-8", errors="replace")
        sample = text[:200_000]
        delimiter = "\t" if record.extension == "tsv" or sample.count("\t") > sample.count(",") else ","
        return [row for row in csv.reader(io.StringIO(sample), delimiter=delimiter)][:5000]
    if record.extension in ("xlsx", "xls"):
        from openpyxl import load_workbook

        workbook = load_workbook(filename=str(path), read_only=True, data_only=True)
        worksheet = workbook[sheet] if sheet and sheet in workbook.sheetnames else workbook.worksheets[0]
        rows = [list(row) for row in worksheet.iter_rows(max_row=5000, values_only=True)]
        workbook.close()
        return rows
    raise ValidationError("Data analysis supports .csv, .tsv and .xlsx files.")


def _analyse_table(rows: list[list[Any]]) -> dict[str, Any]:
    if not rows:
        raise ValidationError("The file contains no rows.")
    header = [str(cell) if cell is not None else f"column_{i}" for i, cell in enumerate(rows[0])]
    data_rows = rows[1:]
    columns: list[dict[str, Any]] = []
    for index, name in enumerate(header):
        values = [row[index] for row in data_rows if index < len(row)]
        non_null = [v for v in values if v not in (None, "")]
        numeric: list[float] = []
        for value in non_null:
            try:
                numeric.append(float(str(value).replace(",", "")))
            except (TypeError, ValueError):
                numeric = []
                break
        column: dict[str, Any] = {
            "name": name,
            "non_null": len(non_null),
            "nulls": len(values) - len(non_null),
            "distinct": len({str(v) for v in non_null}),
            "type": "numeric" if numeric else "text",
        }
        if numeric:
            column.update(
                {
                    "min": min(numeric),
                    "max": max(numeric),
                    "mean": round(statistics.fmean(numeric), 6),
                    "median": round(statistics.median(numeric), 6),
                    "stdev": round(statistics.pstdev(numeric), 6) if len(numeric) > 1 else 0.0,
                    "sum": round(sum(numeric), 6),
                }
            )
        else:
            counts: dict[str, int] = {}
            for value in non_null:
                key = str(value)[:80]
                counts[key] = counts.get(key, 0) + 1
            column["top_values"] = sorted(counts.items(), key=lambda item: item[1], reverse=True)[:5]
        columns.append(column)
    return {
        "row_count": len(data_rows),
        "column_count": len(header),
        "columns": columns,
        "preview": [header] + [[("" if cell is None else cell) for cell in row] for row in data_rows[:15]],
    }


@router.post("/data/analyze")
async def data_analyze(payload: DataAnalysisRequest, db: DbDep, user: CurrentUser) -> dict[str, Any]:
    record = db.get(StoredFile, payload.file_id)
    if record is None or record.user_id != user.id:
        raise NotFound("File not found.")
    rows = _read_tabular(db, record, payload.sheet)
    analysis = _analyse_table(rows)
    narrative: str | None = None
    model_info: dict[str, Any] | None = None
    usage: dict[str, Any] | None = None
    if payload.narrative:
        if payload.model_id is None:
            raise ValidationError("Provide 'model_id' to generate a narrative summary, or set narrative=false.")
        ref = _require_operation(db, user, payload.model_id, Operation.CHAT.value)
        compact = {
            "row_count": analysis["row_count"],
            "column_count": analysis["column_count"],
            "columns": [
                {k: v for k, v in column.items() if k in ("name", "type", "non_null", "nulls", "distinct", "min", "max",
                                                          "mean", "median", "stdev", "sum", "top_values")}
                for column in analysis["columns"]
            ],
            "preview_rows": analysis["preview"][:8],
        }
        question = payload.question or "Summarise this dataset: what it contains, notable patterns, data-quality issues, and three concrete next steps."
        response, outcome = await ai_service.run_chat(
            db, user=user, model_ref=ref,
            messages=[ChatMessage(role="user", content=f"{question}\n\nDataset statistics (JSON):\n{json.dumps(compact, default=str)}")],
            system=(
                "You are a data analyst. Base every statement strictly on the provided statistics; explicitly flag "
                "limitations and do not invent values."
            ),
            module="data",
        )
        narrative = response.text
        model_info = ref.model.public_dict()
        usage = {"prompt_tokens": outcome.usage.prompt_tokens, "completion_tokens": outcome.usage.completion_tokens,
                 "charged_micro": outcome.usage.charged_micro, "usage_source": outcome.usage.usage_source}
    db.commit()
    return {
        "file": {"id": record.id, "name": record.original_name, "extension": record.extension},
        "statistics": analysis,
        "narrative": narrative,
        "model": model_info,
        "usage": usage,
        "computed_locally": {
            "statistics": True,
            "note": "All statistics above were computed on the server from the uploaded file; the model only wrote the narrative.",
        },
    }


# ------------------------------------------------------------------- image ---
@router.post("/image/generate")
async def image_generate(payload: ImageGenerationApiRequest, db: DbDep, user: CurrentUser) -> dict[str, Any]:
    ref = _require_operation(db, user, payload.model_id, Operation.IMAGE_GENERATION.value)
    estimated = _estimate_media_cost(db, user, ref.model, images=payload.n)
    access_service.enforce_quotas(db, user, ref.model, estimated_charge_micro=estimated)
    access_service.ensure_balance_for_request(db, user, ref.model, estimated_charge_micro=estimated)
    started = time.perf_counter()
    result = await ref.adapter.generate_image(  # type: ignore[misc]
        ImageGenerationRequest(
            model=ref.model.provider_model_id, prompt=payload.prompt, n=payload.n, size=payload.size,
            quality=payload.quality, negative_prompt=payload.negative_prompt, seed=payload.seed,
        )
    )
    latency_ms = int((time.perf_counter() - started) * 1000)
    stored: list[dict[str, Any]] = []
    for index, image in enumerate(result.images):
        data: bytes | None = None
        if image.b64_json:
            data = base64.b64decode(image.b64_json)
        elif image.url:
            import httpx

            from app.core.net import assert_outbound_url

            assert_outbound_url(image.url, purpose="generated image download")
            async with httpx.AsyncClient(timeout=60) as client:
                response = await client.get(image.url)
                if response.status_code < 400:
                    data = response.content
        if not data:
            continue
        record = file_service.store_generated(
            db, user=user, data=data, extension="png", name=f"gen-{uuid.uuid4().hex[:8]}-{index}",
            metadata={"prompt": payload.prompt, "model_id": ref.model.id, "provider": ref.provider.name},
        )
        stored.append(
            {
                "file_id": record.id,
                "name": record.original_name,
                "size_bytes": record.size_bytes,
                "download_url": f"/api/v1/files/{record.id}/download",
                "revised_prompt": image.revised_prompt,
            }
        )
    outcome = _charge_media(
        db, user=user, model_ref=ref, operation=Operation.IMAGE_GENERATION.value, module="image",
        images=len(stored), latency_ms=latency_ms, provider_request_id=result.provider_request_id,
        usage_source=result.usage_source, metadata={"prompt": payload.prompt[:500]},
    )
    # Generated files are storage rows owned by the user and the charge is already reported
    # in the response — both must be committed before the files are advertised.
    db.commit()
    return {
        "images": stored,
        "model": ref.model.public_dict(),
        "provider": ref.provider.name,
        "latency_ms": latency_ms,
        "usage": {"charged_micro": outcome.usage.charged_micro, "usage_source": outcome.usage.usage_source,
                  "provider_reported_usage": result.usage_source == "provider_reported"},
    }


@router.post("/image/analyze")
async def image_analyze(payload: ImageAnalysisRequest, db: DbDep, user: CurrentUser) -> dict[str, Any]:
    record = db.get(StoredFile, payload.file_id)
    if record is None or record.user_id != user.id:
        raise NotFound("File not found.")
    if record.extension not in file_service.IMAGE_EXTENSIONS:
        raise ValidationError("Image analysis requires a PNG/JPEG/WEBP/GIF image.")
    ref = _require_operation(db, user, payload.model_id, Operation.CHAT.value)
    if not (ref.model.supports_vision or Operation.IMAGE_UNDERSTANDING.value in (ref.model.capabilities or [])):
        raise ConfigurationError(
            f"Model '{ref.model.display_name}' is not flagged as vision-capable. Enable 'Image understanding' on the "
            "model after verifying it, or choose another model."
        )
    data = file_service.read_bytes(record)
    content = [
        {"type": "text", "text": payload.question},
        {"type": "image_url", "image_url": {"url": f"data:{record.mime_type};base64,{base64.b64encode(data).decode()}"}},
    ]
    response, outcome = await ai_service.run_chat(
        db, user=user, model_ref=ref, messages=[ChatMessage(role="user", content=content)],
        system="Describe only what is visible in the image. Say explicitly when something cannot be determined.",
        module="image",
    )
    db.commit()
    return {
        "analysis": response.text,
        "file": {"id": record.id, "name": record.original_name},
        "model": ref.model.public_dict(),
        "usage": {"prompt_tokens": outcome.usage.prompt_tokens, "completion_tokens": outcome.usage.completion_tokens,
                  "charged_micro": outcome.usage.charged_micro, "usage_source": outcome.usage.usage_source},
    }


# ------------------------------------------------------------------- audio ---
@router.post("/audio/transcribe")
async def transcribe(payload: TranscriptionApiRequest, db: DbDep, user: CurrentUser) -> dict[str, Any]:
    record = db.get(StoredFile, payload.file_id)
    if record is None or record.user_id != user.id:
        raise NotFound("File not found.")
    if record.extension not in file_service.AUDIO_EXTENSIONS:
        raise ValidationError(f"Transcription supports: {', '.join(sorted(file_service.AUDIO_EXTENSIONS))}.")
    ref = _require_operation(db, user, payload.model_id, Operation.AUDIO_TRANSCRIPTION.value)
    if payload.async_job:
        job = job_service.enqueue(
            db, job_type=JobType.AUDIO_TRANSCRIPTION,
            payload={"file_id": record.id, "model_id": ref.model.id, "language": payload.language, "prompt": payload.prompt},
            user_id=user.id, model_id=ref.model.id, provider_id=ref.provider.id,
        )
        db.commit()
        return {"job": _job_payload(job), "mode": "async"}
    started = time.perf_counter()
    result = await ref.adapter.transcribe(  # type: ignore[misc]
        TranscriptionRequest(model=ref.model.provider_model_id, file_path=str(file_service.absolute_path_for(record)),
                             language=payload.language, prompt=payload.prompt)
    )
    latency_ms = int((time.perf_counter() - started) * 1000)
    outcome = _charge_media(
        db, user=user, model_ref=ref, operation=Operation.AUDIO_TRANSCRIPTION.value, module="audio",
        audio_seconds=result.duration_seconds, latency_ms=latency_ms, provider_request_id=result.provider_request_id,
        usage_source=result.usage_source, metadata={"file_id": record.id},
    )
    return {
        "text": result.text,
        "duration_seconds": result.duration_seconds,
        "language": result.language,
        "model": ref.model.public_dict(),
        "usage": {"charged_micro": outcome.usage.charged_micro, "usage_source": outcome.usage.usage_source,
                  "duration_seconds": result.duration_seconds},
    }


@router.post("/audio/speak")
async def speak(payload: SpeechApiRequest, db: DbDep, user: CurrentUser) -> dict[str, Any]:
    ref = _require_operation(db, user, payload.model_id, Operation.SPEECH_GENERATION.value)
    estimated_seconds = max(1.0, len(payload.text) / 15.0)
    estimated = _estimate_media_cost(db, user, ref.model, audio_seconds=estimated_seconds)
    access_service.enforce_quotas(db, user, ref.model, estimated_charge_micro=estimated)
    access_service.ensure_balance_for_request(db, user, ref.model, estimated_charge_micro=estimated)
    started = time.perf_counter()
    result = await ref.adapter.synthesize(  # type: ignore[misc]
        SpeechRequest(model=ref.model.provider_model_id, text=payload.text, voice=payload.voice)
    )
    latency_ms = int((time.perf_counter() - started) * 1000)
    extension = "mp3" if "mpeg" in result.mime_type or "mp3" in result.mime_type else (
        "wav" if "wav" in result.mime_type else "ogg"
    )
    record = file_service.store_generated(
        db, user=user, data=result.audio_bytes, extension=extension, name=f"speech-{uuid.uuid4().hex[:8]}",
        metadata={"text": payload.text[:300], "model_id": ref.model.id},
    )
    outcome = _charge_media(
        db, user=user, model_ref=ref, operation=Operation.SPEECH_GENERATION.value, module="audio",
        audio_seconds=result.duration_seconds or estimated_seconds, latency_ms=latency_ms,
        provider_request_id=result.provider_request_id, usage_source=result.usage_source,
    )
    db.commit()
    return {
        "file_id": record.id,
        "download_url": f"/api/v1/files/{record.id}/download",
        "mime_type": result.mime_type,
        "bytes": len(result.audio_bytes),
        "duration_seconds": result.duration_seconds,
        "duration_note": None if result.duration_seconds else "Duration was not reported by the provider; the charge uses an estimate of the generated audio length.",
        "model": ref.model.public_dict(),
        "usage": {"charged_micro": outcome.usage.charged_micro, "usage_source": outcome.usage.usage_source},
    }


# ------------------------------------------------------------------- video ---
@router.post("/video/generate")
async def video_generate(payload: VideoApiRequest, db: DbDep, user: CurrentUser) -> dict[str, Any]:
    ref = _require_operation(db, user, payload.model_id, Operation.VIDEO_GENERATION.value)
    job = job_service.enqueue(
        db, job_type=JobType.VIDEO_GENERATION,
        payload={"prompt": payload.prompt, "image_url": payload.image_url, "duration_seconds": payload.duration_seconds,
                 "aspect_ratio": payload.aspect_ratio, "model_id": ref.model.id},
        user_id=user.id, model_id=ref.model.id, provider_id=ref.provider.id,
    )
    db.commit()
    return {
        "job": _job_payload(job),
        "note": (
            "Video generation runs as a background job. Poll GET /api/v1/jobs/{id}; the job stays pending while the "
            "provider renders and is charged when it succeeds."
        ),
    }


# -------------------------------------------------------------------- jobs ---
def _job_payload(job: Job) -> dict[str, Any]:
    return {
        "id": job.id,
        "type": job.job_type,
        "status": job.status,
        "progress": job.progress,
        "attempts": job.attempts,
        "max_attempts": job.max_attempts,
        "user_id": job.user_id,
        "model_id": job.model_id,
        "result": job.result or {},
        "error_category": job.error_category,
        "error_message": job.error_message,
        "charged_micro": job.charged_micro,
        "created_at": job.created_at,
        "started_at": job.started_at,
        "finished_at": job.finished_at,
    }


jobs_router = APIRouter(prefix="/jobs", tags=["jobs"])


@jobs_router.get("")
def list_jobs(
    db: DbDep,
    page: PageDep,
    user: CurrentUser,
    job_type: str | None = None,
    status: str | None = None,
) -> dict[str, Any]:
    stmt = select(Job).where(Job.user_id == user.id)
    if job_type:
        stmt = stmt.where(Job.job_type == job_type)
    if status:
        stmt = stmt.where(Job.status == status)
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.scalars(stmt.order_by(Job.created_at.desc()).offset(page.offset).limit(page.limit)).all()
    return paginated([_job_payload(job) for job in rows], int(total), page)


@jobs_router.get("/{job_id}")
def get_job(
    job_id: int,
    db: DbDep,
    user: CurrentUser,
) -> dict[str, Any]:
    job = db.get(Job, job_id)
    if job is None or (job.user_id != user.id and not access_service.has_permission(user, "jobs.manage")):
        raise NotFound("Job not found.")
    return {"job": _job_payload(job)}


@jobs_router.post("/{job_id}/cancel")
def cancel_job(
    job_id: int,
    db: DbDep,
    user: CurrentUser,
) -> dict[str, Any]:
    job = db.get(Job, job_id)
    if job is None or (job.user_id != user.id and not access_service.has_permission(user, "jobs.manage")):
        raise NotFound("Job not found.")
    if job.status == JobStatus.PENDING:
        job_service.cancel(db, job, actor=user)
    elif job.status == JobStatus.RUNNING:
        raise ValidationError(
            "This job is already running at the provider and cannot be interrupted. It will finish and report its result."
        )
    else:
        raise ValidationError(f"Job is already {job.status}.")
    return {"job": _job_payload(job)}
