"""Billing: balance, ledger, usage, payments, subscriptions, refunds (spec §13, §14)."""
from __future__ import annotations

import datetime as dt
from decimal import Decimal
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy import func, select

from app.api.deps import CurrentUser, DbDep, PageDep, paginated, require_permission
from app.core.config import settings
from app.core.errors import NotFound, ValidationError
from app.core.logging import get_logger
from app.models.billing import (
    CreditAccount,
    LedgerEntry,
    Payment,
    PaymentMethod,
    PaymentStatus,
    PricingRule,
    Subscription,
    SubscriptionPlan,
    UsageRecord,
)
from app.models.files import StoredFile
from app.models.user import User as UserModel
from app.services import access as access_service
from app.services import audit as audit_service
from app.services import ledger as ledger_service
from app.services import payments as payment_service
from app.services import pricing as pricing_service
from app.services import usage as usage_service
from app.schemas.common import StrictModel

log = get_logger(__name__)
router = APIRouter(prefix="/billing", tags=["billing"])
admin_router = APIRouter(prefix="/admin/billing", tags=["admin:billing"])


class TopUpRequest(StrictModel):
    amount_micro: int = Field(gt=0, le=10_000_000_000)
    method: str = PaymentMethod.MANUAL_BANK
    payer_name: str | None = None
    bank_reference: str | None = None
    paid_at: dt.datetime | None = None
    crypto_asset: str | None = None
    crypto_network: str | None = None
    crypto_amount: float | None = None
    crypto_tx_hash: str | None = None
    receipt_file_id: int | None = None
    note: str | None = None


class ReviewRequest(StrictModel):
    note: str | None = None
    amount_override_micro: int | None = None
    confirm: bool = False


class RejectRequest(StrictModel):
    reason: str = Field(min_length=3, max_length=400)


class RefundRequest(StrictModel):
    amount_micro: int = Field(gt=0)
    reason: str = Field(min_length=3, max_length=300)
    confirm: bool = False
    allow_negative: bool = True


class VerifyCryptoRequest(StrictModel):
    confirmations: int = Field(ge=0)
    tx_hash: str | None = None


class PricingRuleRequest(StrictModel):
    name: str
    scope: str = Field(default="global", pattern="^(global|provider|model|user|plan)$")
    scope_ref_id: int | None = None
    input_per_mtok_micro: int | None = None
    output_per_mtok_micro: int | None = None
    per_request_micro: int | None = None
    per_image_micro: int | None = None
    per_audio_minute_micro: int | None = None
    per_job_micro: int | None = None
    minimum_charge_micro: int = 0
    provider_input_per_mtok_micro: int | None = None
    provider_output_per_mtok_micro: int | None = None
    provider_per_request_micro: int | None = None
    provider_per_image_micro: int | None = None
    provider_per_audio_minute_micro: int | None = None
    provider_pricing_uncertain: bool = False
    markup_percent: float = 0.0
    currency: str | None = None
    notes: str | None = None


class PricingRuleUpdate(StrictModel):
    """PATCH /admin/billing/pricing/{rule_id} shaped like the pricing dialog.

    The dialog edits the price fields and keeps the rule's identity, so everything except the
    confirmation flag is optional; the endpoint merges the change onto the existing rule, which
    is versioned rather than overwritten.
    """

    name: str | None = None
    scope: str | None = Field(default=None, pattern="^(global|provider|model|user|plan)$")
    scope_ref_id: int | None = None
    input_per_mtok_micro: int | None = None
    output_per_mtok_micro: int | None = None
    per_request_micro: int | None = None
    per_image_micro: int | None = None
    per_audio_minute_micro: int | None = None
    per_job_micro: int | None = None
    minimum_charge_micro: int | None = None
    provider_input_per_mtok_micro: int | None = None
    provider_output_per_mtok_micro: int | None = None
    provider_per_request_micro: int | None = None
    provider_per_image_micro: int | None = None
    provider_per_audio_minute_micro: int | None = None
    provider_pricing_uncertain: bool | None = None
    markup_percent: float | None = None
    currency: str | None = None
    notes: str | None = None
    confirm: bool = False


class PlanRequest(StrictModel):
    slug: str
    name: str
    name_fa: str | None = None
    description: str = ""
    price_micro_monthly: int = 0
    included_credit_micro: int = 0
    daily_request_limit: int | None = None
    monthly_token_limit: int | None = None
    markup_percent: float | None = None
    features: dict[str, Any] | None = None
    is_active: bool = True
    is_public: bool = True
    sort_order: int = 100


# ------------------------------------------------------------- user billing --
@router.get("/balance")
def balance(db: DbDep, user: CurrentUser) -> dict[str, Any]:
    account = ledger_service.get_account(db, user.id)
    assert account is not None
    subscription = access_service.active_subscription(db, user)
    return {
        "balance_micro": account.balance_micro,
        "balance_display": pricing_service.micro_to_display(account.balance_micro),
        "currency": account.currency,
        "credit_display_name": settings.credit_display_name,
        "credit_usd_rate": settings.credit_usd_rate,
        "lifetime_deposited_micro": account.lifetime_deposited_micro,
        "lifetime_spent_micro": account.lifetime_spent_micro,
        "spent_today_micro": usage_service.user_spend_today_micro(db, user.id),
        "spent_month_micro": usage_service.user_spend_month_micro(db, user.id),
        "daily_spend_limit_micro": account.daily_spend_limit_micro,
        "monthly_spend_limit_micro": account.monthly_spend_limit_micro,
        "is_frozen": account.is_frozen,
        "subscription": (
            {"plan": subscription.plan.name, "status": subscription.status, "current_period_end": subscription.current_period_end}
            if subscription
            else None
        ),
    }


@router.get("/ledger")
def my_ledger(db: DbDep, page: PageDep, user: CurrentUser, entry_type: str | None = None) -> dict[str, Any]:
    stmt = select(LedgerEntry).where(LedgerEntry.user_id == user.id)
    if entry_type:
        stmt = stmt.where(LedgerEntry.entry_type == entry_type)
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.scalars(stmt.order_by(LedgerEntry.created_at.desc()).offset(page.offset).limit(page.limit)).all()
    return paginated(
        [
            {
                "id": r.id, "type": r.entry_type, "amount_micro": r.amount_micro, "amount_display": pricing_service.micro_to_display(r.amount_micro),
                "balance_after_micro": r.balance_after_micro, "description": r.description,
                "reference_type": r.reference_type, "reference_id": r.reference_id, "currency": r.currency,
                "created_at": r.created_at,
            }
            for r in rows
        ],
        int(total),
        page,
    )


@router.get("/usage")
def my_usage(
    db: DbDep,
    page: PageDep,
    user: CurrentUser,
    operation: str | None = None,
    status: str | None = None,
    module: str | None = None,
    model_id: int | None = None,
    variant_id: int | None = None,
    from_date: dt.datetime | None = None,
    to_date: dt.datetime | None = None,
) -> dict[str, Any]:
    """This account's usage log.

    `module` answers "which surface spent the money" (chat, telegram, images, …) and
    `variant_id` isolates a single sub-model, so a user or an operator can attribute
    every credit without reading raw tables.
    """
    stmt = select(UsageRecord).where(UsageRecord.user_id == user.id, UsageRecord.is_admin_test.is_(False))
    if operation:
        stmt = stmt.where(UsageRecord.operation == operation)
    if status:
        stmt = stmt.where(UsageRecord.status == status)
    if module:
        stmt = stmt.where(UsageRecord.module == module)
    if model_id:
        stmt = stmt.where(UsageRecord.model_id == model_id)
    if variant_id:
        stmt = stmt.where(UsageRecord.variant_id == variant_id)
    if from_date:
        stmt = stmt.where(UsageRecord.created_at >= from_date)
    if to_date:
        stmt = stmt.where(UsageRecord.created_at <= to_date)
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.scalars(stmt.order_by(UsageRecord.created_at.desc()).offset(page.offset).limit(page.limit)).all()
    totals = db.execute(
        select(
            func.coalesce(func.sum(UsageRecord.charged_micro), 0),
            func.coalesce(func.sum(UsageRecord.total_tokens), 0),
            func.count(UsageRecord.id),
        ).where(UsageRecord.user_id == user.id, UsageRecord.is_admin_test.is_(False))
    ).one()
    return {
        **paginated(
            [
                {
                    "id": r.id, "operation": r.operation, "module": r.module, "status": r.status,
                    "model_id": r.model_id, "variant_id": r.variant_id,
                    "provider_model_id": r.provider_model_id,
                    "prompt_tokens": r.prompt_tokens, "completion_tokens": r.completion_tokens,
                    "total_tokens": r.total_tokens, "images_generated": r.images_generated,
                    "audio_seconds": float(r.audio_seconds) if r.audio_seconds is not None else None,
                    "charged_micro": r.charged_micro, "usage_source": r.usage_source,
                    "pricing_uncertain": r.pricing_uncertain, "latency_ms": r.latency_ms,
                    "error_category": r.error_category, "created_at": r.created_at,
                }
                for r in rows
            ],
            int(total),
            page,
        ),
        "totals": {"charged_micro": int(totals[0] or 0), "tokens": int(totals[1] or 0), "records": int(totals[2] or 0)},
    }


@router.get("/payments")
def my_payments(db: DbDep, page: PageDep, user: CurrentUser, status: str | None = None) -> dict[str, Any]:
    stmt = select(Payment).where(Payment.user_id == user.id)
    if status:
        stmt = stmt.where(Payment.status == status)
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.scalars(stmt.order_by(Payment.created_at.desc()).offset(page.offset).limit(page.limit)).all()
    return paginated([_payment_payload(p) for p in rows], int(total), page)


def _payment_payload(payment: Payment) -> dict[str, Any]:
    return {
        "id": payment.id,
        "reference": payment.reference,
        "method": payment.method,
        "status": payment.status,
        "amount_micro": payment.amount_micro,
        "amount_display": pricing_service.micro_to_display(payment.amount_micro),
        "currency": payment.currency,
        "payer_name": payment.payer_name,
        "bank_reference": payment.bank_reference,
        "paid_at": payment.paid_at,
        "crypto": {
            "asset": payment.crypto_asset,
            "network": payment.crypto_network,
            "amount": float(payment.crypto_amount) if payment.crypto_amount is not None else None,
            "tx_hash": payment.crypto_tx_hash,
            "confirmations": payment.crypto_confirmations,
            "verified": payment.crypto_verified,
        }
        if payment.method == PaymentMethod.CRYPTO
        else None,
        "receipt_file_id": payment.receipt_file_id,
        "review_note": payment.review_note,
        "rejected_reason": payment.rejected_reason,
        "refunded_micro": payment.refunded_micro,
        "client_submitted": payment.client_submitted,
        "verified_by_platform": payment.verified_by_platform,
        "verification_note": (
            "Submitted by the user and awaiting administrator review — not yet verified."
            if payment.status == PaymentStatus.AWAITING_REVIEW
            else ("Verified by the platform." if payment.verified_by_platform else "Not verified by the platform.")
        ),
        "gateway": payment.gateway_name,
        "created_at": payment.created_at,
        "approved_at": payment.approved_at,
        "reviewed_at": payment.reviewed_at,
    }


@router.get("/payment-methods")
def payment_methods(db: DbDep, user: CurrentUser) -> dict[str, Any]:
    return {
        "methods": payment_service.available_methods().to_dict(),
        "gateways": payment_service.gateway_status(),
        "minimum_topup_micro": payment_service.MIN_TOPUP_MICRO,
        "maximum_topup_micro": payment_service.MAX_TOPUP_MICRO,
        "credit_usd_rate": settings.credit_usd_rate,
    }


@router.post("/payments", status_code=201)
def create_payment(payload: TopUpRequest, db: DbDep, user: CurrentUser) -> dict[str, Any]:
    payment = payment_service.create_manual_payment(
        db, user=user, amount_micro=payload.amount_micro, method=payload.method, payer_name=payload.payer_name,
        bank_reference=payload.bank_reference, paid_at=payload.paid_at, crypto_asset=payload.crypto_asset,
        crypto_network=payload.crypto_network, crypto_amount=payload.crypto_amount,
        crypto_tx_hash=payload.crypto_tx_hash, receipt_file_id=payload.receipt_file_id, note=payload.note,
    )
    return {
        "payment": _payment_payload(payment),
        "next_steps": (
            "An administrator will review your transfer. Credits appear only after approval — "
            "submitting a request does not credit your balance automatically."
        ),
    }


@router.get("/subscriptions")
def my_subscriptions(db: DbDep, user: CurrentUser) -> dict[str, Any]:
    subs = db.scalars(select(Subscription).where(Subscription.user_id == user.id).order_by(Subscription.created_at.desc())).all()
    plans = db.scalars(select(SubscriptionPlan).where(SubscriptionPlan.is_public.is_(True), SubscriptionPlan.is_active.is_(True))).all()
    return {
        "subscriptions": [
            {
                "id": s.id, "plan": s.plan.name if s.plan else None, "plan_slug": s.plan.slug if s.plan else None,
                "status": s.status, "current_period_start": s.current_period_start, "current_period_end": s.current_period_end,
                "cancel_at_period_end": s.cancel_at_period_end, "renewal_count": s.renewal_count,
            }
            for s in subs
        ],
        "available_plans": [
            {
                "id": p.id, "slug": p.slug, "name": p.name, "name_fa": p.name_fa, "description": p.description,
                "price_micro_monthly": p.price_micro_monthly, "included_credit_micro": p.included_credit_micro,
                "daily_request_limit": p.daily_request_limit, "monthly_token_limit": p.monthly_token_limit,
                "features": p.features or {},
            }
            for p in plans
        ],
        "purchase_note": (
            "Subscriptions are activated by an administrator after payment approval in this deployment. "
            "An automated subscription checkout is not enabled."
        ),
    }


# ------------------------------------------------------------ admin billing --
@admin_router.get("/payments")
def admin_list_payments(
    db: DbDep,
    page: PageDep,
    actor: Annotated[UserModel, Depends(require_permission("payments.read"))],
    status: str | None = None,
    method: str | None = None,
    user_id: int | None = None,
    search: str | None = None,
) -> dict[str, Any]:
    stmt = select(Payment)
    if status:
        stmt = stmt.where(Payment.status == status)
    if method:
        stmt = stmt.where(Payment.method == method)
    if user_id:
        stmt = stmt.where(Payment.user_id == user_id)
    if search:
        stmt = stmt.where(Payment.reference.ilike(f"%{search}%"))
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.scalars(stmt.order_by(Payment.created_at.desc()).offset(page.offset).limit(page.limit)).all()
    summary = db.execute(
        select(
            func.coalesce(func.sum(func.nullif(Payment.amount_micro, 0)), 0),
            func.count(Payment.id),
        ).where(Payment.status == PaymentStatus.AWAITING_REVIEW)
    ).one()
    return {
        **paginated([_payment_payload(p) for p in rows], int(total), page),
        "pending_review": {"count": int(summary[1] or 0), "amount_micro": int(summary[0] or 0)},
    }


@admin_router.post("/payments/{payment_id}/approve")
def approve_payment(
    payment_id: int,
    payload: ReviewRequest,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("payments.approve"))],
) -> dict[str, Any]:
    payment = db.get(Payment, payment_id)
    if payment is None:
        raise NotFound("Payment not found.")
    if not payload.confirm:
        raise ValidationError("Approval requires explicit confirmation (confirm=true).")
    result = payment_service.approve_payment(db, reviewer=actor, payment=payment, note=payload.note,
                                             amount_override_micro=payload.amount_override_micro)
    return result


@admin_router.post("/payments/{payment_id}/reject")
def reject_payment(
    payment_id: int,
    payload: RejectRequest,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("payments.manage"))],
) -> dict[str, Any]:
    payment = db.get(Payment, payment_id)
    if payment is None:
        raise NotFound("Payment not found.")
    return payment_service.reject_payment(db, reviewer=actor, payment=payment, reason=payload.reason)


@admin_router.post("/payments/{payment_id}/refund")
def refund_payment(
    payment_id: int,
    payload: RefundRequest,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("refunds.manage"))],
) -> dict[str, Any]:
    payment = db.get(Payment, payment_id)
    if payment is None:
        raise NotFound("Payment not found.")
    if not payload.confirm:
        raise ValidationError("Refunds require explicit confirmation (confirm=true).")
    return payment_service.refund_payment(db, reviewer=actor, payment=payment, amount_micro=payload.amount_micro,
                                          reason=payload.reason, allow_negative=payload.allow_negative)


@admin_router.post("/payments/{payment_id}/verify-crypto")
def verify_crypto(
    payment_id: int,
    payload: VerifyCryptoRequest,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("payments.approve"))],
) -> dict[str, Any]:
    payment = db.get(Payment, payment_id)
    if payment is None:
        raise NotFound("Payment not found.")
    return payment_service.verify_crypto_payment(db, reviewer=actor, payment=payment,
                                                 confirmations=payload.confirmations, tx_hash=payload.tx_hash)


@admin_router.get("/pricing")
def admin_pricing(
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("pricing.manage"))],
    scope: str | None = None,
) -> dict[str, Any]:
    stmt = select(PricingRule).order_by(PricingRule.scope, PricingRule.name, PricingRule.version.desc())
    if scope:
        stmt = stmt.where(PricingRule.scope == scope)
    rules = db.scalars(stmt).all()
    return {
        "rules": [
            {
                "id": r.id, "name": r.name, "scope": r.scope, "scope_ref_id": r.scope_ref_id, "version": r.version,
                "active": r.active, "currency": r.currency,
                "input_per_mtok_micro": r.input_per_mtok_micro, "output_per_mtok_micro": r.output_per_mtok_micro,
                "per_request_micro": r.per_request_micro, "per_image_micro": r.per_image_micro,
                "per_audio_minute_micro": r.per_audio_minute_micro, "per_job_micro": r.per_job_micro,
                "minimum_charge_micro": r.minimum_charge_micro,
                "provider_input_per_mtok_micro": r.provider_input_per_mtok_micro,
                "provider_output_per_mtok_micro": r.provider_output_per_mtok_micro,
                "provider_per_request_micro": r.provider_per_request_micro,
                "provider_per_image_micro": r.provider_per_image_micro,
                "provider_per_audio_minute_micro": r.provider_per_audio_minute_micro,
                "provider_pricing_uncertain": r.provider_pricing_uncertain,
                "markup_percent": float(r.markup_percent or 0), "notes": r.notes,
                "created_at": r.created_at, "updated_at": r.updated_at,
            }
            for r in rules
        ],
        "unit_note": (
            "Per-token prices are expressed in micro-credits per 1,000,000 tokens "
            "(1 credit = 1,000,000 micro-credits). Provider costs entered here are already in micro-credits; "
            "provider USD prices set on a model are converted with the credit↔USD rate."
        ),
        "global_daily_spend_limit_micro": settings.global_daily_spend_limit_micro,
        "platform_spend_today_micro": usage_service.platform_spend_today_micro(db),
    }


@admin_router.post("/pricing")
def create_pricing_rule(
    payload: PricingRuleRequest,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("pricing.manage"))],
) -> dict[str, Any]:
    version = (db.scalar(
        select(func.coalesce(func.max(PricingRule.version), 0)).where(
            PricingRule.scope == payload.scope, PricingRule.scope_ref_id == payload.scope_ref_id
        )
    ) or 0) + 1
    if payload.scope != "global" and payload.scope_ref_id is None:
        raise ValidationError("A scope_ref_id is required for provider/model/user/plan scoped rules.")
    rule = PricingRule(
        name=payload.name, scope=payload.scope, scope_ref_id=payload.scope_ref_id, version=version, active=True,
        input_per_mtok_micro=payload.input_per_mtok_micro, output_per_mtok_micro=payload.output_per_mtok_micro,
        per_request_micro=payload.per_request_micro, per_image_micro=payload.per_image_micro,
        per_audio_minute_micro=payload.per_audio_minute_micro, per_job_micro=payload.per_job_micro,
        minimum_charge_micro=payload.minimum_charge_micro,
        provider_input_per_mtok_micro=payload.provider_input_per_mtok_micro,
        provider_output_per_mtok_micro=payload.provider_output_per_mtok_micro,
        provider_per_request_micro=payload.provider_per_request_micro,
        provider_per_image_micro=payload.provider_per_image_micro,
        provider_per_audio_minute_micro=payload.provider_per_audio_minute_micro,
        provider_pricing_uncertain=payload.provider_pricing_uncertain,
        markup_percent=payload.markup_percent, currency=payload.currency or settings.default_currency,
        notes=payload.notes, created_by_id=actor.id,
    )
    db.add(rule)
    db.flush()
    audit_service.record_audit(
        db, action="pricing.updated", summary=f"Pricing rule '{rule.name}' (v{version}, scope={rule.scope}) created.",
        actor=actor, entity_type="pricing_rule", entity_id=rule.id,
        after={"scope": rule.scope, "scope_ref_id": rule.scope_ref_id, "version": version}, severity="warning",
    )
    db.commit()
    return {"rule_id": rule.id, "version": version}


@admin_router.patch("/pricing/{rule_id}")
def update_pricing_rule(
    rule_id: int,
    payload: PricingRuleUpdate,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("pricing.manage"))],
) -> dict[str, Any]:
    old = db.get(PricingRule, rule_id)
    if old is None:
        raise NotFound("Pricing rule not found.")
    # Only what the caller sent is replaced — `exclude_unset` keeps the difference between
    # "remove this price" (an explicit null) and "leave it alone" (an absent key).
    sent = payload.model_dump(exclude_unset=True, exclude={"confirm"})
    # rules are versioned: deactivate the old one and create a new version
    old.active = False
    new_rule = PricingRule(
        name=sent.get("name", old.name), scope=sent.get("scope", old.scope),
        scope_ref_id=sent.get("scope_ref_id", old.scope_ref_id), version=(old.version or 1) + 1,
        active=True,
        input_per_mtok_micro=sent.get("input_per_mtok_micro", old.input_per_mtok_micro),
        output_per_mtok_micro=sent.get("output_per_mtok_micro", old.output_per_mtok_micro),
        per_request_micro=sent.get("per_request_micro", old.per_request_micro),
        per_image_micro=sent.get("per_image_micro", old.per_image_micro),
        per_audio_minute_micro=sent.get("per_audio_minute_micro", old.per_audio_minute_micro),
        per_job_micro=sent.get("per_job_micro", old.per_job_micro),
        minimum_charge_micro=sent.get("minimum_charge_micro", old.minimum_charge_micro),
        provider_input_per_mtok_micro=sent.get("provider_input_per_mtok_micro", old.provider_input_per_mtok_micro),
        provider_output_per_mtok_micro=sent.get("provider_output_per_mtok_micro", old.provider_output_per_mtok_micro),
        provider_per_request_micro=sent.get("provider_per_request_micro", old.provider_per_request_micro),
        provider_per_image_micro=sent.get("provider_per_image_micro", old.provider_per_image_micro),
        provider_per_audio_minute_micro=sent.get("provider_per_audio_minute_micro", old.provider_per_audio_minute_micro),
        provider_pricing_uncertain=sent.get("provider_pricing_uncertain", old.provider_pricing_uncertain),
        markup_percent=sent.get("markup_percent", old.markup_percent),
        currency=sent.get("currency") or old.currency, notes=sent.get("notes", old.notes),
        created_by_id=actor.id,
    )
    db.add(new_rule)
    db.flush()
    audit_service.record_audit(
        db, action="pricing.updated", summary=f"Pricing rule '{new_rule.name}' updated to v{new_rule.version}.",
        actor=actor, entity_type="pricing_rule", entity_id=new_rule.id,
        before={"rule_id": old.id, "version": old.version}, after={"rule_id": new_rule.id, "version": new_rule.version},
        severity="warning",
    )
    db.commit()
    return {"rule_id": new_rule.id, "version": new_rule.version, "previous_rule_id": old.id}


@admin_router.get("/plans")
def admin_plans(
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("subscriptions.manage"))],
) -> dict[str, Any]:
    plans = db.scalars(select(SubscriptionPlan).order_by(SubscriptionPlan.sort_order)).all()
    return {
        "items": [
            {
                "id": p.id, "slug": p.slug, "name": p.name, "name_fa": p.name_fa, "description": p.description,
                "price_micro_monthly": p.price_micro_monthly, "included_credit_micro": p.included_credit_micro,
                "daily_request_limit": p.daily_request_limit, "monthly_token_limit": p.monthly_token_limit,
                "markup_percent": float(p.markup_percent) if p.markup_percent is not None else None,
                "features": p.features or {}, "is_active": p.is_active, "is_public": p.is_public,
                "subscriber_count": db.scalar(
                    select(func.count(Subscription.id)).where(Subscription.plan_id == p.id, Subscription.status == "active")
                ) or 0,
            }
            for p in plans
        ]
    }


@admin_router.post("/plans", status_code=201)
def admin_create_plan(
    payload: PlanRequest,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("subscriptions.manage"))],
) -> dict[str, Any]:
    if db.scalars(select(SubscriptionPlan).where(SubscriptionPlan.slug == payload.slug)).first() is not None:
        raise ValidationError("A plan with this slug already exists.")
    plan = payment_service.create_plan(db, actor=actor, data=payload.model_dump())
    return {"plan_id": plan.id, "slug": plan.slug}


@admin_router.post("/subscriptions")
def admin_grant_subscription(
    payload: dict[str, Any],
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("subscriptions.manage"))],
) -> dict[str, Any]:
    user = db.get(UserModel, int(payload.get("user_id") or 0))
    plan = db.get(SubscriptionPlan, int(payload.get("plan_id") or 0))
    if user is None or plan is None:
        raise NotFound("User or plan not found.")
    sub = payment_service.subscribe_user(db, actor=actor, user=user, plan=plan,
                                         grant_credits=bool(payload.get("grant_credits", True)))
    return {"subscription_id": sub.id, "status": sub.status, "current_period_end": sub.current_period_end}


@admin_router.post("/subscriptions/{subscription_id}/renew")
def admin_renew_subscription(
    subscription_id: int,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("subscriptions.manage"))],
    days: int = Query(30, ge=1, le=365),
) -> dict[str, Any]:
    sub = db.get(Subscription, subscription_id)
    if sub is None:
        raise NotFound("Subscription not found.")
    sub = payment_service.renew_subscription(db, sub, actor=actor, days=days)
    return {"subscription_id": sub.id, "status": sub.status, "current_period_end": sub.current_period_end}


@admin_router.get("/reports")
def admin_reports(
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("reports.read"))],
    days: int = Query(30, ge=1, le=365),
) -> dict[str, Any]:
    since = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=days)
    daily = db.execute(
        select(
            func.date(UsageRecord.created_at).label("day"),
            func.coalesce(func.sum(UsageRecord.charged_micro), 0),
            func.coalesce(func.sum(UsageRecord.provider_cost_micro), 0),
            func.count(UsageRecord.id),
        )
        .where(UsageRecord.created_at >= since, UsageRecord.is_admin_test.is_(False))
        .group_by(func.date(UsageRecord.created_at))
        .order_by(func.date(UsageRecord.created_at))
    ).all()
    payment_daily = db.execute(
        select(func.date(Payment.approved_at).label("day"), func.coalesce(func.sum(Payment.amount_micro), 0), func.count(Payment.id))
        .where(Payment.approved_at.is_not(None), Payment.approved_at >= since)
        .group_by(func.date(Payment.approved_at))
        .order_by(func.date(Payment.approved_at))
    ).all()
    admin_test_cost = db.scalar(
        select(func.coalesce(func.sum(UsageRecord.provider_cost_micro), 0)).where(
            UsageRecord.is_admin_test.is_(True), UsageRecord.created_at >= since
        )
    ) or 0
    sold = db.scalar(select(func.coalesce(func.sum(UsageRecord.charged_micro), 0)).where(UsageRecord.created_at >= since)) or 0
    cost = db.scalar(
        select(func.coalesce(func.sum(UsageRecord.provider_cost_micro), 0)).where(
            UsageRecord.created_at >= since, UsageRecord.is_admin_test.is_(False)
        )
    ) or 0
    consistency = ledger_service.ledger_consistency_report(db)
    return {
        "window_days": days,
        "revenue_vs_cost": {
            "charged_micro": int(sold),
            "provider_cost_micro": int(cost),
            "margin_micro": int(sold) - int(cost),
            "admin_test_cost_micro": int(admin_test_cost),
            "note": "Provider cost is only included when a price is configured; uncertain costs are excluded rather than estimated.",
        },
        "usage_daily": [
            {"day": str(day), "charged_micro": int(charged or 0), "provider_cost_micro": int(cost_ or 0), "requests": int(count)}
            for day, charged, cost_, count in daily
        ],
        "payments_daily": [
            {"day": str(day), "amount_micro": int(amount or 0), "count": int(count)} for day, amount, count in payment_daily
        ],
        "ledger_consistency": consistency,
        "currency": settings.default_currency,
        "credit_usd_rate": settings.credit_usd_rate,
    }
