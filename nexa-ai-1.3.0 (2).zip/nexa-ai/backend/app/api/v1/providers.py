"""Admin provider management (spec §7)."""
from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy import func, select

from app.api.deps import Client, DbDep, PageDep, paginated, require_permission
from app.core.errors import NotFound, ValidationError
from app.core.logging import get_logger
from app.models.provider import Model, Provider, ProviderType
from app.models.user import User
from app.providers.capabilities import ALL_OPERATIONS
from app.providers.registry import describe_adapters
from app.services import providers as provider_service
from app.schemas.common import StrictModel

log = get_logger(__name__)
router = APIRouter(prefix="/admin/providers", tags=["admin:providers"])


class ProviderCreate(StrictModel):
    name: str = Field(min_length=2, max_length=120)
    provider_type: str
    description: str = ""
    base_url: str = ""
    api_key: str | None = None
    organization_id: str | None = None
    project_id: str | None = None
    api_version: str | None = None
    region: str | None = None
    enabled: bool = True
    priority: int = 100
    connect_timeout: float = 10
    read_timeout: float = 120
    max_retries: int = 2
    requests_per_minute: int = 0
    max_concurrency: int = 4
    proxy_url: str | None = None
    extra_headers: dict[str, str] | None = None
    extra_config: dict[str, Any] | None = None


class ProviderUpdate(StrictModel):
    confirm: bool = False
    """The admin dialog's explicit-confirmation gesture.

    A field the UI sends must exist here: unknown fields are rejected loudly (``StrictModel``),
    so `{\"...\", \"confirm\": true}` used to fail every provider save with 422 while the screen
    looked healthy.  Authorization stays on permissions; this only records the human gesture.
    """

    name: str | None = None
    description: str | None = None
    base_url: str | None = None
    api_key: str | None = None
    clear_api_key: bool = False
    organization_id: str | None = None
    project_id: str | None = None
    api_version: str | None = None
    region: str | None = None
    enabled: bool | None = None
    priority: int | None = None
    connect_timeout: float | None = None
    read_timeout: float | None = None
    max_retries: int | None = None
    requests_per_minute: int | None = None
    max_concurrency: int | None = None
    proxy_url: str | None = None
    extra_headers: dict[str, str] | None = None
    extra_config: dict[str, Any] | None = None


@router.get("")
def list_providers(
    db: DbDep,
    page: PageDep,
    actor: Annotated[User, Depends(require_permission("providers.read"))],
    search: str | None = None,
    enabled: bool | None = None,
    provider_type: str | None = None,
) -> dict[str, Any]:
    stmt = select(Provider)
    if search:
        stmt = stmt.where(func.lower(Provider.name).like(f"%{search.lower()}%"))
    if enabled is not None:
        stmt = stmt.where(Provider.enabled.is_(enabled))
    if provider_type:
        stmt = stmt.where(Provider.provider_type == provider_type)
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    providers = db.scalars(stmt.order_by(Provider.priority, Provider.name).offset(page.offset).limit(page.limit)).all()
    items = []
    for provider in providers:
        model_count = db.scalar(select(func.count(Model.id)).where(Model.provider_id == provider.id)) or 0
        data = provider_service.provider_to_dict(provider)
        data["model_count"] = int(model_count)
        data["health"] = provider_service.provider_health(db, provider.id) if page.page_size <= 25 else {}
        items.append(data)
    return {
        **paginated(items, int(total), page),
        "adapters": describe_adapters(),
        "provider_types": [{"value": t, "label": ProviderType.LABELS.get(t, t)} for t in ProviderType.ALL],
    }


@router.post("", status_code=201)
def create_provider(
    payload: ProviderCreate,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("providers.manage"))],
    client: Client,
) -> dict[str, Any]:
    provider = provider_service.create_provider(db, actor=actor, data=payload.model_dump())
    return {"provider": provider_service.provider_to_dict(provider)}


@router.get("/{provider_id}")
def get_provider(
    provider_id: int,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("providers.read"))],
) -> dict[str, Any]:
    provider = db.get(Provider, provider_id)
    if provider is None:
        raise NotFound("Provider not found.")
    data = provider_service.provider_to_dict(provider, include_health=True,
                                             health=provider_service.provider_health(db, provider.id))
    models = db.scalars(select(Model).where(Model.provider_id == provider.id).order_by(Model.display_name)).all()
    data["models"] = [
        {
            "id": m.id,
            "display_name": m.display_name,
            "provider_model_id": m.provider_model_id,
            "visibility": m.visibility,
            "availability": m.availability,
            "enabled": m.enabled,
            "published": m.published,
            "capabilities": m.capabilities or [],
            "last_tested_at": m.last_tested_at,
            "last_test_status": m.last_test_status,
        }
        for m in models
    ]
    return {"provider": data, "supported_operations": sorted(ALL_OPERATIONS)}


@router.patch("/{provider_id}")
def update_provider(
    provider_id: int,
    payload: ProviderUpdate,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("providers.manage"))],
    client: Client,
) -> dict[str, Any]:
    provider = db.get(Provider, provider_id)
    if provider is None:
        raise NotFound("Provider not found.")
    if payload.api_key or payload.clear_api_key:
        from app.core.errors import PermissionDenied

        from app.services import access as access_service

        if not access_service.has_permission(actor, "providers.credentials"):
            raise PermissionDenied(
                "You need the 'providers.credentials' permission to change API credentials.",
                details={"required_permission": "providers.credentials"},
            )
    provider = provider_service.update_provider(db, actor=actor, provider=provider, data=payload.model_dump(exclude_unset=True))
    return {"provider": provider_service.provider_to_dict(provider)}


@router.delete("/{provider_id}")
def delete_provider(
    provider_id: int,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("providers.manage"))],
    force: bool = False,
) -> dict[str, Any]:
    provider = db.get(Provider, provider_id)
    if provider is None:
        raise NotFound("Provider not found.")
    return provider_service.delete_provider(db, actor=actor, provider=provider, force=force)


@router.post("/{provider_id}/test")
async def test_provider(
    provider_id: int,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("providers.test"))],
    minimal_request: bool = Query(False, description="Also run a minimal real operation (extra cost)."),
) -> dict[str, Any]:
    provider = db.get(Provider, provider_id)
    if provider is None:
        raise NotFound("Provider not found.")
    result = await provider_service.test_provider(db, actor=actor, provider=provider, with_model_request=minimal_request)
    if minimal_request and result.get("ok"):
        # pick one chat-capable model of this provider and send a tiny real request
        model = db.scalars(
            select(Model).where(Model.provider_id == provider.id, Model.enabled.is_(True)).order_by(Model.id).limit(1)
        ).first()
        if model is None:
            result["minimal_request"] = {"ran": False, "reason": "No model registered for this provider yet — synchronize models first."}
        elif "chat" not in (model.capabilities or []):
            result["minimal_request"] = {
                "ran": False,
                "reason": f"Model '{model.display_name}' has no verified 'chat' capability; add it under Model management first.",
            }
        else:
            from app.services import ai as ai_service

            test = await ai_service.admin_test_model(
                db, admin=actor, model=model, operation="chat",
                payload={"input": "Reply with the single word: ok", "max_tokens": 8},
            )
            result["minimal_request"] = {
                "ran": True,
                "model": model.display_name,
                "success": test["success"],
                "latency_ms": test["latency_ms"],
                "error_category": test["error_category"],
                "response_preview": (test.get("response_text") or "")[:200],
                "test_id": test["test_id"],
            }
    return {"result": result}


@router.post("/{provider_id}/sync")
async def sync_models(
    provider_id: int,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("providers.sync"))],
) -> dict[str, Any]:
    provider = db.get(Provider, provider_id)
    if provider is None:
        raise NotFound("Provider not found.")
    result = await provider_service.sync_models(db, actor=actor, provider=provider)
    return {"sync": result, "policy_note": "Newly discovered models are created hidden, unpublished and untested. Publish them explicitly after verification."}


class CatalogImportRequest(StrictModel):
    provider_model_ids: list[str] = Field(min_length=1, max_length=1000)
    publish: bool = True


@router.get("/{provider_id}/catalog")
async def provider_catalog(
    provider_id: int,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("providers.read"))],
) -> dict[str, Any]:
    """The provider's full remote catalogue with classification — imports nothing."""
    provider = db.get(Provider, provider_id)
    if provider is None:
        raise NotFound("Provider not found.")
    return await provider_service.fetch_catalog(db, provider=provider)


@router.post("/{provider_id}/catalog/import")
async def import_provider_catalog(
    provider_id: int,
    payload: CatalogImportRequest,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("providers.sync"))],
) -> dict[str, Any]:
    provider = db.get(Provider, provider_id)
    if provider is None:
        raise NotFound("Provider not found.")
    return await provider_service.import_catalog(
        db, actor=actor, provider=provider,
        provider_model_ids=payload.provider_model_ids, publish=payload.publish,
    )


@router.get("/{provider_id}/health")
def provider_health(
    provider_id: int,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("providers.read"))],
) -> dict[str, Any]:
    provider = db.get(Provider, provider_id)
    if provider is None:
        raise NotFound("Provider not found.")
    return {"provider_id": provider.id, "name": provider.name, "health": provider_service.provider_health(db, provider.id)}


@router.get("/{provider_id}/models")
def provider_models(
    provider_id: int,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("providers.read"))],
) -> dict[str, Any]:
    provider = db.get(Provider, provider_id)
    if provider is None:
        raise NotFound("Provider not found.")
    models = db.scalars(select(Model).where(Model.provider_id == provider.id).order_by(Model.display_name)).all()
    return {
        "items": [
            {
                "id": m.id, "display_name": m.display_name, "provider_model_id": m.provider_model_id,
                "visibility": m.visibility, "enabled": m.enabled, "published": m.published,
                "capabilities": m.capabilities or [], "availability": m.availability,
            }
            for m in models
        ]
    }
