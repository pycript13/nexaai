"""Telegram endpoints: account linking (user), bot configuration (admin) and the webhook.

Round 12 changes the credential story: the bot token (and the optional webhook secret) can be
entered in **Admin → Settings → Telegram** and is stored encrypted in ``app_settings``. The
environment variables still work and are the fallback, so both an operator who prefers `.env` and
one who only has a browser are served. Everything the panel needs is answered by
``GET /api/v1/admin/telegram``.
"""
from __future__ import annotations

import hmac

from typing import Annotated, Any

from fastapi import APIRouter, Depends, Header, Request
from sqlalchemy.orm import Session  # noqa: F401  (used in type hints below)

from app.api.deps import CurrentUser, DbDep, User, require_permission
from app.core.config import settings
from app.core.errors import AuthError, NexaError, PermissionDenied, ValidationError
from app.core.logging import get_logger
from app.services import settings_store
from app.services import telegram as telegram_service

log = get_logger(__name__)
router = APIRouter(prefix="/telegram", tags=["telegram"])
admin_router = APIRouter(prefix="/admin/telegram", tags=["admin:telegram"])

#: Admin → Settings → Telegram writes here. The value is encrypted with NEXA_ENCRYPTION_KEY and is
#: never returned by any endpoint (only a masked hint and a boolean).
TOKEN_SETTING_KEY = telegram_service.BOT_TOKEN_SETTING_KEY
ENABLED_SETTING_KEY = "telegram.enabled"
WEBHOOK_SECRET_SETTING_KEY = "telegram.webhook_secret"


# ------------------------------------------------------------------ user side -----
@router.get("/status")
def link_status(db: DbDep, user: CurrentUser) -> dict[str, Any]:
    """Is this account linked to a Telegram chat, and is the bot configured at all?"""
    return telegram_service.link_status(db, user=user)


@router.post("/numeric-id")
def set_numeric_id(payload: dict[str, Any], db: DbDep, user: CurrentUser) -> dict[str, Any]:
    """Register the numeric Telegram id typed in the profile.

    The bot answers a Telegram id only when it is registered on the site; this is the self-service
    way to register it (the one-time link code remains the *proven* path). A Telegram id can belong
    to exactly one account, so two accounts can never share an identity — and nobody's credits can
    be spent under somebody else's chat.
    """
    raw = payload.get("telegram_user_id")
    if raw in (None, ""):
        raise ValidationError("Send the numeric Telegram id (for example 123456789).")
    try:
        telegram_user_id = int(str(raw).strip())
    except (TypeError, ValueError):
        raise ValidationError("The Telegram id must be a number, e.g. 123456789.") from None
    return telegram_service.set_numeric_id(db, user=user, telegram_user_id=telegram_user_id)


@router.post("/link-code", status_code=201)
def create_link_code(db: DbDep, user: CurrentUser) -> dict[str, Any]:
    """Create a single-use, short-lived code and the t.me deep link that carries it."""
    if not telegram_service.is_configured(db):
        raise ValidationError(
            "The Telegram bot is not configured yet: an administrator enters the bot token under "
            "Admin → Settings → Telegram (or sets NEXA_TELEGRAM_BOT_TOKEN and restarts).",
            details={"reason": "telegram_not_configured"},
        )
    return telegram_service.create_link_code(db, user=user)


@router.delete("/link")
def unlink(db: DbDep, user: CurrentUser) -> dict[str, Any]:
    """Disconnect this account from Telegram (the bot immediately stops acting for it)."""
    return telegram_service.unlink(db, user=user)


# ------------------------------------------------------------------ admin side ----


def _telegram_state(db: DbDep) -> dict[str, Any]:
    """Everything the admin card shows: configuration, identity confirmation and real statistics."""
    from sqlalchemy import func, select

    from app.models.telegram import TelegramLink
    from app.models.user import User as UserModel

    telegram_service.refresh_token(db)
    stored_enabled = settings_store.get_value(db, ENABLED_SETTING_KEY, None)
    enabled = settings.telegram_enabled if stored_enabled is None else bool(stored_enabled)
    total = db.scalar(select(func.count(TelegramLink.id))) or 0
    active = db.scalar(select(func.count(TelegramLink.id)).where(TelegramLink.enabled.is_(True))) or 0
    messages = db.scalar(select(func.coalesce(func.sum(TelegramLink.message_count), 0))) or 0
    verified = db.scalar(
        select(func.count(TelegramLink.id)).where(TelegramLink.verified_via == "code")
    ) or 0
    recent = db.scalars(select(TelegramLink).order_by(TelegramLink.id.desc()).limit(10)).all()
    status = settings_store.secret_status(db, TOKEN_SETTING_KEY)
    webhook_secret = settings_store.secret_status(db, WEBHOOK_SECRET_SETTING_KEY)
    return {
        "enabled": bool(enabled),
        "enabled_source": "database" if stored_enabled is not None else "environment",
        "configured": telegram_service.is_configured(db),
        "token": {
            "configured": status["configured"] or bool(settings.telegram_bot_token),
            "source": status["source"] if status["configured"] else ("environment" if settings.telegram_bot_token else "none"),
            "hint": status["hint"] or (f"…{settings.telegram_bot_token[-4:]}" if settings.telegram_bot_token else ""),
            "updated_at": status["updated_at"],
        },
        "webhook_secret": {
            "configured": webhook_secret["configured"] or bool(settings.telegram_webhook_secret),
            "source": webhook_secret["source"] if webhook_secret["configured"] else ("environment" if settings.telegram_webhook_secret else "none"),
            "hint": webhook_secret["hint"] or ("set in the environment" if settings.telegram_webhook_secret else ""),
        },
        "mode": settings.telegram_mode,
        "bot_username": telegram_service.bot_username(db) or None,
        "api_base": telegram_service.api_base(),
        "linked_accounts": int(total),
        "enabled_links": int(active),
        "verified_links": int(verified),
        "declared_links": int(total - verified),
        "messages_handled": int(messages),
        "how_to": (
            "1) Paste the bot token from @BotFather and save. 2) Press “Test” — the panel calls getMe "
            "live. 3) The bot polls automatically (a worker restart is not needed). 4) Users register "
            "their numeric Telegram id in Profile → Telegram, or link with a one-time code."
        ),
        "recent": [
            {
                "user_id": link.user_id,
                "email": (db.get(UserModel, link.user_id).email if db.get(UserModel, link.user_id) else None),
                "telegram_user_id": link.telegram_user_id,
                "telegram_username": link.telegram_username,
                "verified_via": getattr(link, "verified_via", None),
                "enabled": link.enabled,
                "message_count": link.message_count,
                "linked_at": link.linked_at,
                "last_message_at": link.last_message_at,
            }
            for link in recent
        ],
    }


@admin_router.get("/status")
def admin_status(
    db: DbDep,
    # `settings.manage` — the permission that actually exists in the catalogue. This endpoint used
    # to require `settings.read`, which is defined nowhere, so `has_permission` was false for every
    # account including the super admin: the Telegram status screen could never load for anyone.
    actor: Annotated[User, Depends(require_permission("settings.manage"))],
) -> dict[str, Any]:
    return _telegram_state(db)


@admin_router.put("/token")
def admin_set_token(
    payload: dict[str, Any],
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("settings.manage"))],
) -> dict[str, Any]:
    """Store (or clear) the bot token. Write-only: the value never comes back out of the API."""
    token = str(payload.get("token") or "").strip()
    clear = bool(payload.get("clear"))
    if clear:
        settings_store.clear_secret(db, TOKEN_SETTING_KEY, actor=actor)
        telegram_service.refresh_token(db)
        return _telegram_state(db)
    if not token:
        raise ValidationError("Paste the token you received from @BotFather (it looks like 123456:ABC-DEF…).")
    if ":" not in token or len(token) < 20:
        raise ValidationError(
            "That does not look like a bot token: @BotFather issues <digits>:<letters and digits>."
        )
    settings_store.set_secret(
        db, TOKEN_SETTING_KEY, token, actor=actor, category="integrations",
        label="Telegram bot token",
        description="Issued by @BotFather. Stored encrypted; used by the polling worker and the webhook.",
    )
    # Publish the real username so deep links (t.me/<bot>?start=<code>) can be built everywhere.
    telegram_service.refresh_token(db)
    return _telegram_state(db)


@admin_router.put("/enabled")
def admin_set_enabled(
    payload: dict[str, Any],
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("settings.manage"))],
) -> dict[str, Any]:
    """Switch the bot on or off without touching the environment file."""
    enabled = bool(payload.get("enabled"))
    settings_store.set_value(db, ENABLED_SETTING_KEY, enabled, actor=actor)
    return _telegram_state(db)


@admin_router.put("/webhook-secret")
def admin_set_webhook_secret(
    payload: dict[str, Any],
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("settings.manage"))],
) -> dict[str, Any]:
    secret = str(payload.get("secret") or "").strip()
    if payload.get("clear"):
        settings_store.clear_secret(db, WEBHOOK_SECRET_SETTING_KEY, actor=actor)
        return _telegram_state(db)
    if len(secret) < 16:
        raise ValidationError("Telegram requires a webhook secret of at least 16 characters (A-Z, a-z, 0-9, _ and -).")
    settings_store.set_secret(
        db, WEBHOOK_SECRET_SETTING_KEY, secret, actor=actor, category="integrations",
        label="Telegram webhook secret", description="Verified against the X-Telegram-Bot-Api-Secret-Token header.",
    )
    return _telegram_state(db)


@admin_router.post("/test")
async def admin_test(
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("settings.manage"))],
) -> dict[str, Any]:
    """Call getMe — the only honest way to say "the token works"."""
    telegram_service.refresh_token(db)
    if not telegram_service.bot_token():
        raise ValidationError(
            "No bot token yet: paste the one from @BotFather in this card and save it.",
            details={"reason": "telegram_not_configured"},
        )
    me = await telegram_service.get_me()
    username = str(me.get("username") or "")
    result: dict[str, Any] = {
        "ok": True,
        "bot": {
            "id": me.get("id"),
            "username": me.get("username"),
            "first_name": me.get("first_name"),
            "can_join_groups": me.get("can_join_groups"),
            "can_read_all_group_messages": me.get("can_read_all_group_messages"),
        },
        "token_source": telegram_service.token_source(),
        "note": "If can_read_all_group_messages is false the bot answers direct messages only — that is the "
                "intended privacy-friendly default.",
    }
    # Remember the username as a normal setting so the bot can build t.me links without an extra call.
    if username:
        settings_store.set_value(db, "telegram.bot_username", username, actor=actor, commit=False)
        db.commit()
    commands_registered = False
    try:
        await telegram_service.set_my_commands()
        commands_registered = True
    except NexaError as exc:  # pragma: no cover - depends on Telegram being reachable
        result["commands_error"] = str(exc)
    result["commands_registered"] = commands_registered
    return result


@admin_router.post("/commands")
async def admin_set_commands(
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("settings.manage"))],
) -> dict[str, Any]:
    """(Re)publish the command list Telegram shows in its menu button."""
    telegram_service.refresh_token(db)
    result = await telegram_service.set_my_commands()
    return {"ok": True, "result": result}


@admin_router.post("/webhook")
async def admin_set_webhook(
    payload: dict[str, Any],
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("settings.manage"))],
) -> dict[str, Any]:
    """Register the production webhook (https://<your-domain>/api/v1/telegram/webhook)."""
    url = str(payload.get("url") or "").strip()
    if not url.startswith("https://"):
        raise ValidationError("Telegram requires an HTTPS webhook URL.")
    telegram_service.refresh_token(db)
    result = await telegram_service.set_webhook(url)
    return {"ok": True, "result": result}


@admin_router.get("/webhook")
async def admin_webhook_info(
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("settings.manage"))],
) -> dict[str, Any]:
    """What Telegram currently believes about this bot's delivery (real getWebhookInfo call)."""
    telegram_service.refresh_token(db)
    return {"ok": True, "result": await telegram_service.get_webhook_info()}


# ------------------------------------------------------------------ webhook ------
@router.post("/webhook")
async def webhook(
    request: Request,
    db: DbDep,
    x_telegram_bot_api_secret_token: Annotated[str | None, Header()] = None,
) -> dict[str, Any]:
    """Receive updates from Telegram when the deployment uses webhook mode.

    Telegram echoes the secret it was registered with in the ``X-Telegram-Bot-Api-Secret-Token``
    header. The check **fails closed**: without a configured secret the endpoint refuses to process
    anything. It used to accept anonymous updates whenever no secret was set, and a forged update is
    not harmless — the payload carries ``from.id`` and ``chat.id``, so anyone could have impersonated
    a registered user's Telegram id and collected that user's answers (and spent their credits).
    Enter the secret under Admin → Settings → Telegram, pass the same value to ``setWebhook``.
    """
    if not telegram_service.is_configured(db):
        raise ValidationError("The Telegram bot is not configured.", details={"reason": "telegram_not_configured"})
    expected = settings_store.get_secret(db, WEBHOOK_SECRET_SETTING_KEY) or settings.telegram_webhook_secret
    if not expected:
        raise ValidationError(
            "This endpoint only accepts updates authenticated with the bot's webhook secret. Create one "
            "under Admin → Settings → Telegram (the same value is passed to setWebhook).",
            details={"reason": "webhook_secret_required"},
        )
    if not hmac.compare_digest(x_telegram_bot_api_secret_token or "", expected):
        raise AuthError("Invalid Telegram webhook secret.")
    try:
        update = await request.json()
    except Exception as exc:  # noqa: BLE001
        raise ValidationError("The webhook body is not valid JSON.") from exc
    if not isinstance(update, dict):
        raise PermissionDenied("Malformed update.")
    result = await telegram_service.handle_update(db, update)
    return {"ok": True, "handled": result}
