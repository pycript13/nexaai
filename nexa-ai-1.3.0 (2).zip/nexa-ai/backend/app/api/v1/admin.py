"""Administrative console: dashboard, system health, audit, jobs, settings, backups."""
from __future__ import annotations

import datetime as dt
import platform
import shutil
import sys
from pathlib import Path
from dataclasses import dataclass
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy import func, or_, select

from app.api.deps import Client, CurrentUser, DbDep, PageDep, paginated, require_permission
from app.core.config import settings
from app.core.errors import NotFound, PermissionDenied, ValidationError
from app.core.logging import get_logger
from app.core.ratelimit import limiter as rate_limiter
from app.models.admin import AdminModelTest, AppSetting, AuditEvent
from app.models.billing import CreditAccount, LedgerEntry, Payment, PaymentStatus, Subscription, UsageRecord
from app.models.chat import Conversation, Message
from app.models.files import StoredFile
from app.models.jobs import Job, JobStatus
from app.models.provider import Model, Provider, ProviderHealthSample
from app.models.user import Role, User, UserSession
from app.services import access as access_service
from app.services import audit as audit_service
from app.services import email as email_service
from app.services import jobs as job_service
from app.services import payments as payment_service
from app.services import pricing as pricing_service
from app.services import providers as provider_service
from app.services import usage as usage_service
from app.services.settings_store import all_settings, set_value
from app.schemas.common import StrictModel

log = get_logger(__name__)
router = APIRouter(prefix="/admin", tags=["admin"])


@router.get("/dashboard")
def dashboard(
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("usage.read"))],
    days: int = Query(14, ge=1, le=90),
) -> dict[str, Any]:
    since = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=days)
    today = dt.datetime.now(dt.timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)

    users_total = db.scalar(select(func.count(User.id))) or 0
    users_active = db.scalar(select(func.count(User.id)).where(User.status == "active")) or 0
    users_new_today = db.scalar(select(func.count(User.id)).where(User.created_at >= today)) or 0
    users_suspended = db.scalar(select(func.count(User.id)).where(User.status == "suspended")) or 0

    providers_total = db.scalar(select(func.count(Provider.id))) or 0
    providers_enabled = db.scalar(select(func.count(Provider.id)).where(Provider.enabled.is_(True))) or 0
    models_total = db.scalar(select(func.count(Model.id))) or 0
    models_published = db.scalar(
        select(func.count(Model.id)).where(Model.published.is_(True), Model.visibility == "public")
    ) or 0
    models_erroring = db.scalar(
        select(func.count(Model.id)).where(Model.last_test_status == "error")
    ) or 0

    requests_today = db.scalar(select(func.count(UsageRecord.id)).where(UsageRecord.created_at >= today)) or 0
    failures_today = db.scalar(
        select(func.count(UsageRecord.id)).where(UsageRecord.created_at >= today, UsageRecord.error_category.is_not(None))
    ) or 0
    tokens_today = db.scalar(
        select(func.coalesce(func.sum(UsageRecord.total_tokens), 0)).where(UsageRecord.created_at >= today)
    ) or 0
    charged_today = db.scalar(
        select(func.coalesce(func.sum(UsageRecord.charged_micro), 0)).where(
            UsageRecord.created_at >= today, UsageRecord.is_admin_test.is_(False)
        )
    ) or 0
    cost_today = db.scalar(
        select(func.coalesce(func.sum(UsageRecord.provider_cost_micro), 0)).where(UsageRecord.created_at >= today)
    ) or 0
    admin_test_cost_today = usage_service.admin_test_spend_today_micro(db)

    pending_payments = db.scalar(
        select(func.count(Payment.id)).where(Payment.status == PaymentStatus.AWAITING_REVIEW)
    ) or 0
    approved_30d = db.scalar(
        select(func.coalesce(func.sum(Payment.amount_micro), 0)).where(
            Payment.status == PaymentStatus.APPROVED, Payment.created_at >= since
        )
    ) or 0
    balances = db.execute(
        select(func.coalesce(func.sum(CreditAccount.balance_micro), 0), func.count(CreditAccount.id))
    ).one()

    queue = job_service.queue_depth(db)
    jobs_failed = queue.get(JobStatus.FAILED, 0)

    daily = db.execute(
        select(
            func.date(UsageRecord.created_at).label("day"),
            func.count(UsageRecord.id),
            func.coalesce(func.sum(UsageRecord.total_tokens), 0),
            func.coalesce(func.sum(UsageRecord.charged_micro), 0),
            func.coalesce(func.sum(UsageRecord.provider_cost_micro), 0),
        )
        .where(UsageRecord.created_at >= since)
        .group_by(func.date(UsageRecord.created_at))
        .order_by(func.date(UsageRecord.created_at))
    ).all()

    top_models = db.execute(
        select(Model.id, Model.display_name, func.count(UsageRecord.id).label("requests"),
               func.coalesce(func.sum(UsageRecord.charged_micro), 0))
        .join(UsageRecord, UsageRecord.model_id == Model.id)
        .where(UsageRecord.created_at >= since)
        .group_by(Model.id, Model.display_name)
        .order_by(func.count(UsageRecord.id).desc())
        .limit(8)
    ).all()

    recent_errors = db.scalars(
        select(UsageRecord).where(UsageRecord.error_category.is_not(None))
        .order_by(UsageRecord.created_at.desc()).limit(10)
    ).all()
    recent_audit = db.scalars(select(AuditEvent).order_by(AuditEvent.created_at.desc()).limit(10)).all()

    return {
        "users": {
            "total": int(users_total), "active": int(users_active), "new_today": int(users_new_today),
            "suspended": int(users_suspended),
        },
        "ai": {
            "providers_total": int(providers_total), "providers_enabled": int(providers_enabled),
            "models_total": int(models_total), "models_published": int(models_published),
            "models_erroring": int(models_erroring),
            "queue": queue, "jobs_failed": int(jobs_failed),
        },
        "usage": {
            "requests_today": int(requests_today), "failures_today": int(failures_today),
            "tokens_today": int(tokens_today), "charged_today_micro": int(charged_today),
            "provider_cost_today_micro": int(cost_today),
            "admin_test_cost_today_micro": int(admin_test_cost_today),
            "daily": [
                {"day": str(day), "requests": int(count), "tokens": int(tokens), "charged_micro": int(charged),
                 "provider_cost_micro": int(cost)}
                for day, count, tokens, charged, cost in daily
            ],
            "top_models": [
                {"model_id": mid, "name": name, "requests": int(requests), "charged_micro": int(charged)}
                for mid, name, requests, charged in top_models
            ],
        },
        "finance": {
            "pending_payments": int(pending_payments),
            "approved_recent_micro": int(approved_30d),
            "total_user_balances_micro": int(balances[0] or 0),
            "accounts": int(balances[1] or 0),
            "window_days": days,
        },
        "recent_errors": [
            {
                "id": u.id, "category": u.error_category, "operation": u.operation, "model_id": u.model_id,
                "user_id": u.user_id, "created_at": u.created_at, "is_admin_test": u.is_admin_test,
            }
            for u in recent_errors
        ],
        "recent_audit": [
            {"id": a.id, "action": a.action, "summary": a.summary, "actor_email": a.actor_email,
             "severity": a.severity, "created_at": a.created_at}
            for a in recent_audit
        ],
        "deployment": {
            "mode": settings.deployment_mode,
            "public_base_url": settings.public_base_url,
            "security_warning": settings.plain_http_warning,
            "warnings": settings.deployment_warnings(),
        },
    }


@router.get("/system")
def system_status(
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("settings.manage"))],
) -> dict[str, Any]:
    from app.db.session import check_database

    db_ok, dialect = check_database()
    providers = db.scalars(select(Provider)).all()
    provider_rows = []
    for provider in providers:
        health = provider_service.provider_health(db, provider.id)
        provider_rows.append(
            {
                "id": provider.id, "name": provider.name, "type": provider.provider_type, "enabled": provider.enabled,
                "has_credentials": bool(provider.api_key_encrypted),
                "last_sync_at": provider.last_sync_at, "last_sync_status": provider.last_sync_status,
                "last_test_at": provider.last_test_at, "last_test_status": provider.last_test_status,
                "last_error_category": provider.last_error_category,
                "model_count": db.scalar(select(func.count(Model.id)).where(Model.provider_id == provider.id)) or 0,
                "health_24h": health,
            }
        )
    try:
        disk_target = settings.upload_dir
        Path(disk_target).mkdir(parents=True, exist_ok=True)
        disk = shutil.disk_usage(disk_target)
    except Exception:  # noqa: BLE001 - fall back to the working directory
        disk = shutil.disk_usage(".")
    upload_bytes = db.scalar(
        select(func.coalesce(func.sum(StoredFile.size_bytes), 0)).where(StoredFile.deleted_at.is_(None))
    ) or 0
    return {
        "application": {
            "version": settings.version,
            "environment": settings.environment,
            "deployment_mode": settings.deployment_mode,
            "public_base_url": settings.public_base_url,
            "python": sys.version.split()[0],
            "platform": f"{platform.system()} {platform.release()}",
            "uptime_hint": "see /api/v1/health",
        },
        "database": {
            "ok": db_ok,
            "dialect": dialect if db_ok else None,
            "is_sqlite": settings.is_sqlite,
            "production_warning": (
                "SQLite is in use — fine for a single-user evaluation, not for concurrent production traffic."
                if settings.is_sqlite
                else None
            ),
        },
        "security": {
            "csrf_enabled": settings.csrf_enabled,
            "cookie_secure": settings.cookie_secure,
            "hsts_enabled": settings.hsts_enabled,
            "cors_origins": settings.cors_origin_list,
            "trusted_hosts": settings.trusted_host_list,
            "rate_limiter_backend": rate_limiter.backend,
            "registration_mode": settings.registration_mode,
            "private_provider_endpoints_allowed": settings.allow_private_provider_endpoints,
            "provider_allowlist": settings.private_endpoint_allowlist,
            "plain_http_warning": settings.plain_http_warning,
        },
        "email": email_service.status(),
        "payments": {"methods": payment_service.available_methods().to_dict(), "gateways": payment_service.gateway_status()},
        "storage": {
            "upload_dir": settings.upload_dir,
            "max_upload_mb": settings.max_upload_mb,
            "user_quota_mb": settings.user_storage_quota_mb,
            "retention_days": settings.file_retention_days,
            "stored_bytes": int(upload_bytes),
            "disk_total_gb": round(disk.total / 1024**3, 2),
            "disk_free_gb": round(disk.free / 1024**3, 2),
            "used_percent": round(disk.used / disk.total * 100, 1),
        },
        "providers": provider_rows,
        "counts": {
            "users": db.scalar(select(func.count(User.id))) or 0,
            "conversations": db.scalar(select(func.count(Conversation.id))) or 0,
            "messages": db.scalar(select(func.count(Message.id))) or 0,
            "files": db.scalar(select(func.count(StoredFile.id)).where(StoredFile.deleted_at.is_(None))) or 0,
            "ledger_entries": db.scalar(select(func.count(LedgerEntry.id))) or 0,
            "usage_records": db.scalar(select(func.count(UsageRecord.id))) or 0,
            "audit_events": db.scalar(select(func.count(AuditEvent.id))) or 0,
            "admin_tests": db.scalar(select(func.count(AdminModelTest.id))) or 0,
        },
        "queue": job_service.queue_depth(db),
    }


@router.get("/errors")
def recent_errors(
    db: DbDep,
    page: PageDep,
    actor: Annotated[User, Depends(require_permission("usage.read"))],
    category: str | None = None,
    provider_id: int | None = None,
) -> dict[str, Any]:
    stmt = select(UsageRecord).where(UsageRecord.error_category.is_not(None))
    if category:
        stmt = stmt.where(UsageRecord.error_category == category)
    if provider_id:
        stmt = stmt.where(UsageRecord.provider_id == provider_id)
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.scalars(stmt.order_by(UsageRecord.created_at.desc()).offset(page.offset).limit(page.limit)).all()
    return {
        **paginated(
            [
                {
                    "id": r.id, "category": r.error_category, "operation": r.operation, "status": r.status,
                    "model_id": r.model_id, "provider_id": r.provider_id, "user_id": r.user_id,
                    "is_admin_test": r.is_admin_test, "created_at": r.created_at,
                    "metadata": r.metadata_json or {},
                }
                for r in rows
            ],
            int(total),
            page,
        ),
        "categories": [
            {"category": category_, "count": int(count)}
            for category_, count in db.execute(
                select(UsageRecord.error_category, func.count(UsageRecord.id))
                .where(UsageRecord.error_category.is_not(None))
                .group_by(UsageRecord.error_category)
                .order_by(func.count(UsageRecord.id).desc())
            ).all()
        ],
    }


@router.get("/audit")
def audit_log(
    db: DbDep,
    page: PageDep,
    actor: Annotated[User, Depends(require_permission("audit.read"))],
    search: str | None = None,
    category: str | None = None,
    severity: str | None = None,
    actor_user_id: int | None = None,
    from_date: dt.datetime | None = None,
    to_date: dt.datetime | None = None,
) -> dict[str, Any]:
    stmt = select(AuditEvent)
    if search:
        term = f"%{search.lower()}%"
        stmt = stmt.where(or_(func.lower(AuditEvent.summary).like(term), func.lower(AuditEvent.action).like(term),
                              func.lower(func.coalesce(AuditEvent.actor_email, "")).like(term)))
    if category:
        stmt = stmt.where(AuditEvent.category == category)
    if severity:
        stmt = stmt.where(AuditEvent.severity == severity)
    if actor_user_id:
        stmt = stmt.where(AuditEvent.actor_user_id == actor_user_id)
    if from_date:
        stmt = stmt.where(AuditEvent.created_at >= from_date)
    if to_date:
        stmt = stmt.where(AuditEvent.created_at <= to_date)
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.scalars(stmt.order_by(AuditEvent.created_at.desc()).offset(page.offset).limit(page.limit)).all()
    return {
        **paginated(
            [
                {
                    "id": a.id, "action": a.action, "category": a.category, "severity": a.severity,
                    "summary": a.summary, "actor_user_id": a.actor_user_id, "actor_email": a.actor_email,
                    "actor_role": a.actor_role, "entity_type": a.entity_type, "entity_id": a.entity_id,
                    "before": a.before_state, "after": a.after_state, "ip_address": a.ip_address,
                    "request_id": a.request_id, "created_at": a.created_at,
                }
                for a in rows
            ],
            int(total),
            page,
        ),
        "filters": {
            "categories": [c for (c,) in db.execute(select(AuditEvent.category).distinct()).all()],
            "actions": [a for (a,) in db.execute(select(AuditEvent.action).distinct().limit(200)).all()],
        },
    }


@router.get("/security-events")
def security_events(
    db: DbDep,
    page: PageDep,
    actor: Annotated[User, Depends(require_permission("security.read"))],
) -> dict[str, Any]:
    stmt = select(AuditEvent).where(
        or_(AuditEvent.category == "security", AuditEvent.severity.in_(["warning", "critical"]))
    )
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.scalars(stmt.order_by(AuditEvent.created_at.desc()).offset(page.offset).limit(page.limit)).all()
    failed_logins = db.scalar(
        select(func.count(AuditEvent.id)).where(
            AuditEvent.action == "auth.login_failed",
            AuditEvent.created_at >= dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=7),
        )
    ) or 0
    active_sessions = db.scalar(
        select(func.count(UserSession.id)).where(UserSession.revoked_at.is_(None), UserSession.expires_at > dt.datetime.now(dt.timezone.utc))
    ) or 0
    return {
        **paginated(
            [
                {
                    "id": a.id, "action": a.action, "severity": a.severity, "summary": a.summary,
                    "actor_email": a.actor_email, "category": a.category, "ip_address": a.ip_address,
                    "created_at": a.created_at,
                }
                for a in rows
            ],
            int(total),
            page,
        ),
        "summary": {
            "failed_logins_7d": int(failed_logins),
            "active_sessions": int(active_sessions),
            "suspended_accounts": int(db.scalar(select(func.count(User.id)).where(User.status == "suspended")) or 0),
        },
    }


@router.get("/jobs")
def all_jobs(
    db: DbDep,
    page: PageDep,
    actor: Annotated[User, Depends(require_permission("jobs.manage"))],
    status: str | None = None,
    job_type: str | None = None,
) -> dict[str, Any]:
    stmt = select(Job)
    if status:
        stmt = stmt.where(Job.status == status)
    if job_type:
        stmt = stmt.where(Job.job_type == job_type)
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.scalars(stmt.order_by(Job.created_at.desc()).offset(page.offset).limit(page.limit)).all()
    return {
        **paginated(
            [
                {
                    "id": j.id, "type": j.job_type, "status": j.status, "progress": j.progress, "attempts": j.attempts,
                    "user_id": j.user_id, "model_id": j.model_id, "error_category": j.error_category,
                    "error_message": j.error_message, "worker_id": j.worker_id, "charged_micro": j.charged_micro,
                    "created_at": j.created_at, "started_at": j.started_at, "finished_at": j.finished_at,
                    "result_preview": {k: v for k, v in (j.result or {}).items() if k in ("text", "file_id", "video_url", "status")},
                }
                for j in rows
            ],
            int(total),
            page,
        ),
        "queue": job_service.queue_depth(db),
    }


@router.post("/jobs/{job_id}/retry")
def retry_job(
    job_id: int,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("jobs.manage"))],
) -> dict[str, Any]:
    job = db.get(Job, job_id)
    if job is None:
        raise NotFound("Job not found.")
    if job.status not in (JobStatus.FAILED, JobStatus.CANCELLED, JobStatus.EXPIRED):
        raise ValidationError(f"Job is {job.status} and cannot be retried.")
    job.status = JobStatus.PENDING
    job.attempts = 0
    job.error_category = None
    job.error_message = None
    job.worker_id = None
    job.lease_expires_at = None
    db.commit()
    audit_service.record_audit(db, action="jobs.manage", summary=f"Job {job.id} requeued by {actor.email}.", actor=actor,
                               entity_type="job", entity_id=job.id, category="jobs")
    db.commit()
    return {"job_id": job.id, "status": job.status}


@router.get("/settings")
def list_settings(
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("settings.manage"))],
) -> dict[str, Any]:
    everything = all_settings(db)
    return {
        # Secrets are returned flagged, never with their value: each one has its own editor (for example
        # the Telegram card below), so the generic table must not offer a text box for them.
        "items": everything,
        "secret_keys": [row["key"] for row in everything if row.get("is_secret")],
        "read_only_note": (
            "Secret configuration (encryption key, database URL, SMTP password when it is not entered here) lives "
            "only in the environment file and is never editable or readable from the API. Secrets that *are* "
            "editable — such as the Telegram bot token — are stored encrypted and have their own editor."
        ),
        "environment": {
            "environment": settings.environment,
            "deployment_mode": settings.deployment_mode,
            "public_base_url": settings.public_base_url,
            "session_ttl_hours": settings.session_ttl_hours,
            "session_idle_timeout_minutes": settings.session_idle_timeout_minutes,
            "max_upload_mb": settings.max_upload_mb,
            "registration_mode": settings.registration_mode,
        },
    }


class SettingUpdate(StrictModel):
    value: Any
    confirm: bool = False


@router.patch("/settings/{key}")
def update_setting(
    key: str,
    payload: SettingUpdate,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("settings.manage"))],
) -> dict[str, Any]:
    row = db.scalars(select(AppSetting).where(AppSetting.key == key)).first()
    if row is None:
        raise NotFound("Setting not found.")
    if key in ("registration.mode",) and payload.value not in ("open", "invite_only", "closed"):
        raise ValidationError("registration.mode must be one of: open, invite_only, closed.")
    if key in ("registration.mode",) and not settings.registration_mode_allowed(payload.value):
        # The deployment may forbid a policy (NEXA_ALLOWED_REGISTRATION_MODES): refusing here keeps the
        # sign-up page consistent with the operator's own rule instead of failing later for visitors.
        raise ValidationError(
            "This deployment does not allow that registration policy.",
            details={
                "requested": payload.value,
                "allowed": sorted(settings.allowed_registration_mode_set),
                "changed_by": "NEXA_ALLOWED_REGISTRATION_MODES in the environment file",
            },
        )
    if not payload.confirm:
        raise ValidationError("Setting changes require explicit confirmation (confirm=true).")
    set_value(db, key, payload.value, actor=actor)
    return {"key": key, "value": payload.value}


@router.get("/admins")
def list_admins(
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("users.read"))],
) -> dict[str, Any]:
    rows = db.scalars(select(User).join(User.roles).where(Role.slug.in_(["super_admin", "admin", "model_manager", "finance_manager", "support_agent"])).distinct()).all()
    return {
        "items": [
            {"id": u.id, "email": u.email, "display_name": u.display_name, "status": u.status,
             "roles": [r.slug for r in u.roles], "last_login_at": u.last_login_at}
            for u in rows
        ]
    }


@router.get("/backups")
def backup_inventory(
    actor: Annotated[User, Depends(require_permission("backups.manage"))],
) -> dict[str, Any]:
    """List the backups that really exist on disk.

    The console used to call the *run* endpoint to render its history — every visit to the
    page answered 404 and the operator saw an error instead of their backups. The history
    now has its own read-only endpoint; it reports on files, never on intentions.
    """
    from app.services import backups as backups_service

    app_root = Path(__file__).resolve().parents[4]
    return backups_service.list_backups(backups_service.backup_directory(app_root))


@router.post("/backup/run")
def run_backup(
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("backups.manage"))],
) -> dict[str, Any]:
    """Trigger a database backup using the bundled script.

    Only permitted on PostgreSQL deployments with the backup script present;
    otherwise the endpoint explains the correct manual procedure instead of
    pretending a backup happened.
    """
    import subprocess
    from pathlib import Path

    project_root = Path(__file__).resolve().parents[4]
    script = project_root / "backup.sh"
    if settings.is_sqlite:
        return {
            "started": False,
            "reason": (
                "This deployment uses SQLite. Take a consistent copy with: "
                "sqlite3 data/nexa.db \".backup 'backups/nexa-$(date +%F).db'\" "
                "(or simply copy data/nexa.db while the service is stopped)."
            ),
        }
    if not script.exists():
        return {
            "started": False,
            "reason": f"backup.sh was not found at {script}. Run the backup from the host: ./backup.sh",
        }
    try:
        completed = subprocess.run([str(script)], capture_output=True, text=True, timeout=600, check=False)  # noqa: S603
    except Exception as exc:  # noqa: BLE001
        raise ValidationError(f"Backup script failed to start: {exc}") from exc
    audit_service.record_audit(
        db, action="backup.requested", summary=f"Backup triggered by {actor.email} (exit code {completed.returncode}).",
        actor=actor, entity_type="system", entity_id="backup", category="system", severity="notice",
    )
    db.commit()
    from app.services import backups as backups_service

    app_root = Path(__file__).resolve().parents[4]
    inventory = backups_service.list_backups(backups_service.backup_directory(app_root))
    return {
        "started": True,
        "success": completed.returncode == 0,
        "exit_code": completed.returncode,
        "stdout_tail": completed.stdout[-2000:],
        "stderr_tail": completed.stderr[-2000:],
        # The caller needs the new file, not just an exit code: the page re-renders the
        # inventory from this answer, so a backup that failed to verify cannot look done.
        "backups": inventory["items"],
        "last_verified": inventory["last_verified"],
        "directory": inventory["directory"],
    }


@router.get("/permissions")
def my_admin_permissions(actor: CurrentUser) -> dict[str, Any]:
    return {
        "permissions": sorted(access_service.user_permissions(actor)),
        "roles": access_service.role_slugs(actor),
        "is_super_admin": access_service.is_super_admin(actor),
    }
