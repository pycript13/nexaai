"""Declarative base + portable column helpers (PostgreSQL first, SQLite for dev)."""
from __future__ import annotations

import datetime as dt
import uuid

from sqlalchemy import BigInteger, DateTime, Integer, MetaData, String, TypeDecorator, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

# Consistent constraint naming so Alembic autogenerate/upgrade is deterministic.
naming_convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class UTCDateTime(TypeDecorator):
    """Timezone-aware UTC timestamps on every backend.

    PostgreSQL returns aware datetimes for ``TIMESTAMP WITH TIME ZONE``, while
    SQLite returns naive values. This decorator normalises both directions so
    comparisons never mix naive and aware datetimes.
    """

    impl = DateTime(timezone=True)
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        if value.tzinfo is None:
            value = value.replace(tzinfo=dt.timezone.utc)
        return value.astimezone(dt.timezone.utc)

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        if value.tzinfo is None:
            return value.replace(tzinfo=dt.timezone.utc)
        return value.astimezone(dt.timezone.utc)


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=naming_convention)


# BigInteger primary keys, downgraded to INTEGER on SQLite so that autoincrement works.
PKType = BigInteger().with_variant(Integer, "sqlite")


def pk() -> Mapped[int]:
    return mapped_column(PKType, primary_key=True, autoincrement=True)


def created_at_col() -> Mapped[dt.datetime]:
    return mapped_column(UTCDateTime, server_default=func.now(), nullable=False)


def updated_at_col() -> Mapped[dt.datetime]:
    return mapped_column(UTCDateTime, server_default=func.now(), onupdate=func.now(), nullable=False)


def utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def uuid4_str() -> str:
    return uuid.uuid4().hex


TimestampMixin = None  # (kept for backwards-compat import safety)
