from __future__ import annotations

import datetime as dt
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, ConfigDict, Field

T = TypeVar("T")


class StrictModel(BaseModel):
    """Request model that refuses unknown fields.

    A typo in a request body used to be ignored silently — `{"selling_per_mtok_input": 3}`
    returned 200 while the real price stayed unset, and the platform then billed 0 (or the
    configured minimum) with only a warning deep in the logs. Money and state changes must
    fail loudly, so every write payload derives from this class and gets a 422 naming the
    offending keys.
    """

    model_config = ConfigDict(extra="forbid")


class MessageResponse(BaseModel):
    message: str
    detail: str | None = None


class Pagination(BaseModel):
    page: int
    page_size: int
    total: int
    pages: int
    has_next: bool
    has_prev: bool


class Page(BaseModel, Generic[T]):
    items: list[T]
    pagination: Pagination


class ErrorBody(BaseModel):
    code: str
    message: str
    category: str | None = None
    details: dict[str, Any] = Field(default_factory=dict)


class ErrorResponse(BaseModel):
    error: ErrorBody


class OrmModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class TimestampedMixin(BaseModel):
    created_at: dt.datetime | None = None
    updated_at: dt.datetime | None = None
