from __future__ import annotations

import datetime as dt

from sqlalchemy import JSON, Boolean, DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import UTCDateTime, Base, created_at_col, pk, updated_at_col


class AccountStatus:
    """Account lifecycle states (persisted as short strings)."""

    PENDING = "pending"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    DEACTIVATED = "deactivated"
    DELETED = "deleted"

    ALL = (PENDING, ACTIVE, SUSPENDED, DEACTIVATED, DELETED)


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = pk()
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True, nullable=False)
    username: Mapped[str | None] = mapped_column(String(64), unique=True, nullable=True)
    display_name: Mapped[str] = mapped_column(String(120), nullable=False, default="")
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    status: Mapped[str] = mapped_column(String(24), nullable=False, default="active", index=True)
    email_verified: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    # One-time code that binds a Telegram account to this one (see services/telegram.py).
    telegram_link_code: Mapped[str | None] = mapped_column(String(24), nullable=True)
    telegram_link_code_expires_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    email_verified_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    locale: Mapped[str] = mapped_column(String(12), nullable=False, default="fa")
    theme: Mapped[str] = mapped_column(String(16), nullable=False, default="system")
    enhanced_theme: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    timezone: Mapped[str] = mapped_column(String(64), nullable=False, default="UTC")
    avatar_url: Mapped[str | None] = mapped_column(String(512), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(32), nullable=True)
    company: Mapped[str | None] = mapped_column(String(160), nullable=True)

    # policy acceptance (ToS / privacy) — version + timestamp are kept forever
    accepted_terms_version: Mapped[str | None] = mapped_column(String(32), nullable=True)
    accepted_terms_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    accepted_privacy_version: Mapped[str | None] = mapped_column(String(32), nullable=True)
    accepted_privacy_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)

    # test-account controls (remote tester onboarding, spec §25)
    is_test_account: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    expires_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    quota_requests_per_day: Mapped[int | None] = mapped_column(Integer, nullable=True)
    quota_spend_micro_per_day: Mapped[int | None] = mapped_column(Integer, nullable=True)
    invited_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)

    failed_login_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    locked_until: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    last_login_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    last_login_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    password_changed_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    must_change_password: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    storage_used_bytes: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    created_at: Mapped[dt.datetime] = created_at_col()
    updated_at: Mapped[dt.datetime] = updated_at_col()
    deleted_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)

    roles: Mapped[list["Role"]] = relationship(
        secondary="user_roles",
        primaryjoin="User.id == UserRole.user_id",
        secondaryjoin="Role.id == UserRole.role_id",
        foreign_keys="[UserRole.user_id, UserRole.role_id]",
        back_populates="users",
        lazy="selectin",
    )
    sessions: Mapped[list["UserSession"]] = relationship(back_populates="user", cascade="all, delete-orphan")
    credit_account: Mapped["CreditAccount"] = relationship(  # noqa: F821
        back_populates="user", uselist=False, cascade="all, delete-orphan"
    )

    __table_args__ = (Index("ix_users_status_created", "status", "created_at"),)

    @property
    def is_active(self) -> bool:
        if self.status != "active":
            return False
        if self.expires_at and self.expires_at < dt.datetime.now(dt.timezone.utc):
            return False
        return self.deleted_at is None

    def permission_slugs(self) -> set[str]:
        out: set[str] = set()
        for role in self.roles:
            for perm in role.permissions:
                out.add(perm.slug)
        return out

    def is_admin(self) -> bool:
        slugs = {r.slug for r in self.roles}
        return bool(slugs & {"super_admin", "admin"})


class Role(Base):
    __tablename__ = "roles"

    id: Mapped[int] = pk()
    slug: Mapped[str] = mapped_column(String(48), unique=True, nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(96), nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False, default="")
    is_system: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    created_at: Mapped[dt.datetime] = created_at_col()
    updated_at: Mapped[dt.datetime] = updated_at_col()

    permissions: Mapped[list["Permission"]] = relationship(
        secondary="role_permissions", back_populates="roles", lazy="selectin"
    )
    users: Mapped[list["User"]] = relationship(
        secondary="user_roles",
        primaryjoin="Role.id == UserRole.role_id",
        secondaryjoin="User.id == UserRole.user_id",
        foreign_keys="[UserRole.user_id, UserRole.role_id]",
        back_populates="roles",
        lazy="noload",
    )


class Permission(Base):
    __tablename__ = "permissions"

    id: Mapped[int] = pk()
    slug: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    group: Mapped[str] = mapped_column(String(48), nullable=False, default="General")
    description: Mapped[str] = mapped_column(String(255), nullable=False, default="")

    roles: Mapped[list[Role]] = relationship(secondary="role_permissions", back_populates="permissions", lazy="noload")


class RolePermission(Base):
    __tablename__ = "role_permissions"
    __table_args__ = (UniqueConstraint("role_id", "permission_id", name="uq_role_permissions_pair"),)

    id: Mapped[int] = pk()
    role_id: Mapped[int] = mapped_column(ForeignKey("roles.id", ondelete="CASCADE"), nullable=False, index=True)
    permission_id: Mapped[int] = mapped_column(ForeignKey("permissions.id", ondelete="CASCADE"), nullable=False, index=True)


class UserRole(Base):
    __tablename__ = "user_roles"
    __table_args__ = (UniqueConstraint("user_id", "role_id", name="uq_user_roles_pair"),)

    id: Mapped[int] = pk()
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    role_id: Mapped[int] = mapped_column(ForeignKey("roles.id", ondelete="CASCADE"), nullable=False, index=True)
    granted_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    granted_at: Mapped[dt.datetime] = created_at_col()


class UserSession(Base):
    """Server-side session record. Only the SHA-256 hash of the cookie token is stored."""

    __tablename__ = "user_sessions"
    __table_args__ = (Index("ix_sessions_user_active", "user_id", "revoked_at"),)

    id: Mapped[int] = pk()
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    csrf_token: Mapped[str] = mapped_column(String(96), nullable=False, default="")
    user_agent: Mapped[str | None] = mapped_column(String(400), nullable=True)
    ip_address: Mapped[str | None] = mapped_column(String(64), nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()
    last_seen_at: Mapped[dt.datetime] = created_at_col()
    expires_at: Mapped[dt.datetime] = mapped_column(UTCDateTime, nullable=False)
    revoked_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    revoked_reason: Mapped[str | None] = mapped_column(String(120), nullable=True)

    user: Mapped[User] = relationship(back_populates="sessions")

    def is_valid(self, now: dt.datetime | None = None) -> bool:
        from app.core.config import settings

        now = now or dt.datetime.now(dt.timezone.utc)
        if self.revoked_at is not None:
            return False
        if self.expires_at and self.expires_at < now:
            return False
        idle = dt.timedelta(minutes=settings.session_idle_timeout_minutes)
        last = self.last_seen_at or self.created_at
        if last and last + idle < now:
            return False
        return True


class UserActivity(Base):
    """Account activity history shown to the user and to administrators."""

    __tablename__ = "user_activities"
    __table_args__ = (Index("ix_user_activities_user_created", "user_id", "created_at"),)

    id: Mapped[int] = pk()
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    event: Mapped[str] = mapped_column(String(64), nullable=False)
    description: Mapped[str] = mapped_column(String(400), nullable=False, default="")
    ip_address: Mapped[str | None] = mapped_column(String(64), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(400), nullable=True)
    metadata_json: Mapped[dict | None] = mapped_column("metadata", JSON, nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()
