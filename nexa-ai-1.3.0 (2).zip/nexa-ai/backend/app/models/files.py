from __future__ import annotations

import datetime as dt

from sqlalchemy import JSON, BigInteger, Boolean, DateTime, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import UTCDateTime, Base, created_at_col, pk


class FileKind:
    UPLOAD = "upload"
    GENERATED = "generated"
    RECEIPT = "receipt"
    EXPORT = "export"
    ATTACHMENT = "attachment"


class StoredFile(Base):
    """Every stored artifact (user upload, generated image, payment receipt).

    Security properties:
    * ``storage_path`` is generated server-side (random uuid + validated suffix);
      the user-supplied filename is only kept as metadata for display.
    * Files live outside the web root and are only served through an authorized
      API endpoint that re-checks ownership/permissions on every request.
    """

    __tablename__ = "files"
    __table_args__ = (
        Index("ix_files_user_kind", "user_id", "kind"),
        Index("ix_files_created", "created_at"),
    )

    id: Mapped[int] = pk()
    uuid: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=True, index=True)
    kind: Mapped[str] = mapped_column(String(24), nullable=False, default=FileKind.UPLOAD, index=True)
    original_name: Mapped[str] = mapped_column(String(255), nullable=False)
    storage_path: Mapped[str] = mapped_column(String(512), nullable=False)
    mime_type: Mapped[str] = mapped_column(String(160), nullable=False, default="application/octet-stream")
    extension: Mapped[str] = mapped_column(String(16), nullable=False, default="")
    size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    checksum_sha256: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    sha_verified: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    content_validated: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    malware_scan_status: Mapped[str] = mapped_column(String(24), nullable=False, default="not_configured")
    is_private: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    extracted_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    metadata_json: Mapped[dict | None] = mapped_column("metadata", JSON, nullable=True)
    expires_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    deleted_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()

    user: Mapped["User"] = relationship()  # noqa: F821

    @property
    def size_mb(self) -> float:
        return round(self.size_bytes / (1024 * 1024), 3)
