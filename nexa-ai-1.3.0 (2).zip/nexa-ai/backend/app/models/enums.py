"""String enums shared across models, schemas and the frontend contract."""
from __future__ import annotations

from enum import Enum


class StrEnum(str, Enum):
    def __str__(self) -> str:  # pragma: no cover
        return self.value


ROLE_SLUGS = ("super_admin", "admin", "support_agent", "finance_manager", "model_manager", "user")

ACCOUNT_STATUSES = ("pending", "active", "suspended", "deactivated", "deleted")

PERMISSION_GROUPS: dict[str, list[str]] = {
    "Users": ["users.read", "users.create", "users.update", "users.suspend", "users.impersonate"],
    "Roles": ["roles.manage"],
    "Providers": ["providers.read", "providers.manage", "providers.credentials", "providers.test", "providers.sync"],
    "Models": ["models.read", "models.manage", "models.test", "models.publish", "models.grants.manage"],
    "Pricing/Finance": [
        "pricing.manage", "subscriptions.manage", "payments.read", "payments.manage", "payments.approve",
        "refunds.manage", "credits.manage", "usage.read", "reports.read",
    ],
    "System": ["settings.manage", "audit.read", "backups.manage", "jobs.manage", "security.read"],
}

ALL_PERMISSIONS: list[str] = [p for group in PERMISSION_GROUPS.values() for p in group]

ROLE_DEFINITIONS: dict[str, dict] = {
    "super_admin": {
        "name": "Super Admin",
        "description": "Full administrative authority over every part of the platform.",
        "permissions": ["*"],
    },
    "admin": {
        "name": "Administrator",
        "description": "Operational administration excluding destructive system-level operations.",
        "permissions": [
            "users.read", "users.create", "users.update", "users.suspend",
            "providers.read", "providers.manage", "providers.test", "providers.sync",
            "models.read", "models.manage", "models.test", "models.publish",
            "pricing.manage", "subscriptions.manage", "payments.read", "payments.manage",
            "credits.manage", "usage.read", "settings.manage", "audit.read", "jobs.manage", "security.read",
        ],
    },
    "support_agent": {
        "name": "Support Agent",
        "description": "Customer support: read users, view usage, suspend abusive accounts.",
        "permissions": ["users.read", "users.suspend", "usage.read", "audit.read", "payments.read"],
    },
    "finance_manager": {
        "name": "Finance Manager",
        "description": "Billing operations: pricing, payments, refunds, credits, reports.",
        "permissions": [
            "pricing.manage", "subscriptions.manage", "payments.read", "payments.manage",
            "payments.approve", "refunds.manage", "credits.manage", "usage.read", "reports.read",
        ],
    },
    "model_manager": {
        "name": "Content/Model Manager",
        "description": "Owns the AI catalog: providers, models, capabilities, publishing.",
        "permissions": [
            "providers.read", "providers.manage", "providers.test", "providers.sync",
            "models.read", "models.manage", "models.test", "models.publish", "models.grants.manage",
        ],
    },
    "user": {"name": "Standard User", "description": "Regular platform user.", "permissions": []},
}
