"""Financial subsystem models.

Money handling rules (enforced throughout the codebase):
* All amounts are stored as **integer micro-credits** (1 credit = 1_000_000 micro).
  No binary floating point is ever used for balances, charges or ledger entries.
* ``credit_ledger`` is append-only: entries are never updated or deleted, and each
  entry stores the resulting ``balance_after_micro`` so the balance can be
  recomputed and reconciled at any time.
* Every balance mutation runs inside a single DB transaction and carries a unique
  ``idempotency_key`` so retries can never double-charge or double-credit.
"""
from __future__ import annotations

import datetime as dt

from sqlalchemy import (
    JSON,
    BigInteger,
    Column,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Table,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import UTCDateTime, Base, PKType, created_at_col, pk, updated_at_col


class LedgerEntryType:
    DEPOSIT = "deposit"
    USAGE_CHARGE = "usage_charge"
    REFUND = "refund"
    ADJUSTMENT = "adjustment"
    ADMIN_GRANT = "admin_grant"
    PROMOTIONAL = "promotional"
    SUBSCRIPTION_GRANT = "subscription_grant"
    EXPIRY = "expiry"
    CHARGEBACK = "chargeback"
    ADMIN_TEST = "admin_test_cost"

    CREDIT_TYPES = (DEPOSIT, REFUND, ADMIN_GRANT, PROMOTIONAL, SUBSCRIPTION_GRANT, ADJUSTMENT)
    DEBIT_TYPES = (USAGE_CHARGE, EXPIRY, CHARGEBACK, ADMIN_TEST)


class PaymentStatus:
    PENDING = "pending"
    AWAITING_REVIEW = "awaiting_review"
    APPROVED = "approved"
    REJECTED = "rejected"
    CANCELLED = "cancelled"
    EXPIRED = "expired"
    REFUNDED = "refunded"
    PARTIALLY_REFUNDED = "partially_refunded"
    FAILED = "failed"

    ALL = (PENDING, AWAITING_REVIEW, APPROVED, REJECTED, CANCELLED, EXPIRED, REFUNDED, PARTIALLY_REFUNDED, FAILED)


class PaymentMethod:
    MANUAL_BANK = "manual_bank_transfer"
    MANUAL_ADMIN = "admin_grant"
    CRYPTO = "crypto"
    STRIPE = "stripe"
    ZARINPAL = "zarinpal"

    ALL = (MANUAL_BANK, MANUAL_ADMIN, CRYPTO, STRIPE, ZARINPAL)
    AUTOMATED = (STRIPE, ZARINPAL)


class SubscriptionStatus:
    ACTIVE = "active"
    TRIALING = "trialing"
    PAST_DUE = "past_due"
    CANCELED = "canceled"
    EXPIRED = "expired"
    PENDING = "pending"

    ALL = (ACTIVE, TRIALING, PAST_DUE, CANCELED, EXPIRED, PENDING)


class UsageStatus:
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    PARTIAL = "partial"
    CANCELLED = "cancelled"
    UNKNOWN_USAGE = "unknown_usage"


plan_model_grants = Table(
    "subscription_plan_models",
    Base.metadata,
    Column("plan_id", PKType, ForeignKey("subscription_plans.id", ondelete="CASCADE"), primary_key=True),
    Column("model_id", PKType, ForeignKey("models.id", ondelete="CASCADE"), primary_key=True),
)


class CreditAccount(Base):
    __tablename__ = "credit_accounts"

    id: Mapped[int] = pk()
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True, index=True)
    balance_micro: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    lifetime_deposited_micro: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    lifetime_spent_micro: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    reserved_micro: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    currency: Mapped[str] = mapped_column(String(8), nullable=False, default="USD")
    daily_spend_limit_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    monthly_spend_limit_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    is_frozen: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    created_at: Mapped[dt.datetime] = created_at_col()
    updated_at: Mapped[dt.datetime] = updated_at_col()

    user: Mapped["User"] = relationship(back_populates="credit_account")  # noqa: F821

    @property
    def balance_credits(self) -> float:
        return self.balance_micro / 1_000_000


class LedgerEntry(Base):
    __tablename__ = "credit_ledger"
    __table_args__ = (
        UniqueConstraint("idempotency_key", name="uq_credit_ledger_idempotency"),
        Index("ix_credit_ledger_account_created", "account_id", "created_at"),
        Index("ix_credit_ledger_user_created", "user_id", "created_at"),
        Index("ix_credit_ledger_type_created", "entry_type", "created_at"),
    )

    id: Mapped[int] = pk()
    account_id: Mapped[int] = mapped_column(ForeignKey("credit_accounts.id", ondelete="RESTRICT"), nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    entry_type: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    # positive = credit added, negative = credit deducted
    amount_micro: Mapped[int] = mapped_column(BigInteger, nullable=False)
    balance_after_micro: Mapped[int] = mapped_column(BigInteger, nullable=False)
    currency: Mapped[str] = mapped_column(String(8), nullable=False, default="USD")
    idempotency_key: Mapped[str] = mapped_column(String(120), nullable=False)
    description: Mapped[str] = mapped_column(String(400), nullable=False, default="")
    reference_type: Mapped[str | None] = mapped_column(String(32), nullable=True)  # usage|payment|refund|admin_test
    reference_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    metadata_json: Mapped[dict | None] = mapped_column("metadata", JSON, nullable=True)
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    reversal_of_id: Mapped[int | None] = mapped_column(ForeignKey("credit_ledger.id", ondelete="SET NULL"), nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()


class PricingRule(Base):
    """Versioned pricing. Each usage record stores the rule + version it used."""

    __tablename__ = "pricing_rules"
    __table_args__ = (
        UniqueConstraint("scope", "scope_ref_id", "version", name="uq_pricing_rules_version"),
        Index("ix_pricing_rules_scope", "scope", "scope_ref_id", "active"),
    )

    id: Mapped[int] = pk()
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    scope: Mapped[str] = mapped_column(String(24), nullable=False, default="global")  # global|provider|model|user|plan
    scope_ref_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    # selling price (what the customer pays).
    # per-token columns are micro-credits per 1_000_000 tokens (== credits per MTok);
    # the flat columns are micro-credits per unit. Never store per-token prices in
    # micro-credits per *token*: a 0.28 credits/MTok model would round to 0 (free).
    input_per_mtok_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    output_per_mtok_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    per_request_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    per_image_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    per_audio_minute_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    per_job_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    minimum_charge_micro: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)

    # provider cost (what the platform pays) — micro-credits per 1M tokens / per unit
    provider_input_per_mtok_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    provider_output_per_mtok_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    provider_per_request_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    provider_per_image_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    provider_per_audio_minute_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    provider_pricing_uncertain: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    markup_percent: Mapped[float] = mapped_column(Numeric(8, 3), nullable=False, default=0)
    currency: Mapped[str] = mapped_column(String(8), nullable=False, default="USD")
    notes: Mapped[str | None] = mapped_column(String(400), nullable=True)
    effective_from: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()
    updated_at: Mapped[dt.datetime] = updated_at_col()


class UsageRecord(Base):
    """One row per billable provider operation (user-facing *or* admin test)."""

    __tablename__ = "usage_records"
    __table_args__ = (
        UniqueConstraint("idempotency_key", name="uq_usage_records_idempotency"),
        Index("ix_usage_user_created", "user_id", "created_at"),
        Index("ix_usage_status_created", "status", "created_at"),
        Index("ix_usage_model_created", "model_id", "created_at"),
        Index("ix_usage_admin_test", "is_admin_test", "created_at"),
    )

    id: Mapped[int] = pk()
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    account_id: Mapped[int | None] = mapped_column(ForeignKey("credit_accounts.id", ondelete="SET NULL"), nullable=True)
    provider_id: Mapped[int | None] = mapped_column(ForeignKey("providers.id", ondelete="SET NULL"), nullable=True)
    model_id: Mapped[int | None] = mapped_column(ForeignKey("models.id", ondelete="SET NULL"), nullable=True)
    variant_id: Mapped[int | None] = mapped_column(ForeignKey("model_variants.id", ondelete="SET NULL"), nullable=True)
    provider_model_id: Mapped[str | None] = mapped_column(String(200), nullable=True)
    operation: Mapped[str] = mapped_column(String(32), nullable=False, default="chat")
    module: Mapped[str | None] = mapped_column(String(32), nullable=True)
    conversation_id: Mapped[int | None] = mapped_column(ForeignKey("conversations.id", ondelete="SET NULL"), nullable=True)
    job_id: Mapped[int | None] = mapped_column(ForeignKey("jobs.id", ondelete="SET NULL"), nullable=True)

    status: Mapped[str] = mapped_column(String(24), nullable=False, default="succeeded", index=True)
    error_category: Mapped[str | None] = mapped_column(String(48), nullable=True)

    prompt_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    completion_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    total_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    images_generated: Mapped[int | None] = mapped_column(Integer, nullable=True)
    audio_seconds: Mapped[float | None] = mapped_column(Numeric(12, 3), nullable=True)
    video_seconds: Mapped[float | None] = mapped_column(Numeric(12, 3), nullable=True)
    request_count: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    usage_source: Mapped[str] = mapped_column(String(24), nullable=False, default="provider_reported")  # provider_reported|estimated|unavailable

    provider_cost_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    charged_micro: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    pricing_rule_id: Mapped[int | None] = mapped_column(ForeignKey("pricing_rules.id", ondelete="SET NULL"), nullable=True)
    pricing_rule_version: Mapped[int | None] = mapped_column(Integer, nullable=True)
    pricing_uncertain: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    latency_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    provider_request_id: Mapped[str | None] = mapped_column(String(160), nullable=True)
    idempotency_key: Mapped[str] = mapped_column(String(120), nullable=False)
    is_admin_test: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, index=True)
    admin_test_id: Mapped[int | None] = mapped_column(ForeignKey("admin_model_tests.id", ondelete="SET NULL"), nullable=True)
    billed_to_user: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    metadata_json: Mapped[dict | None] = mapped_column("metadata", JSON, nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()


class Payment(Base):
    __tablename__ = "payments"
    __table_args__ = (
        UniqueConstraint("reference", name="uq_payments_reference"),
        UniqueConstraint("idempotency_key", name="uq_payments_idempotency"),
        Index("ix_payments_user_created", "user_id", "created_at"),
        Index("ix_payments_status_created", "status", "created_at"),
    )

    id: Mapped[int] = pk()
    reference: Mapped[str] = mapped_column(String(48), nullable=False, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False, index=True)
    method: Mapped[str] = mapped_column(String(32), nullable=False, default=PaymentMethod.MANUAL_BANK, index=True)
    status: Mapped[str] = mapped_column(String(24), nullable=False, default=PaymentStatus.PENDING, index=True)

    amount_micro: Mapped[int] = mapped_column(BigInteger, nullable=False)
    amount_fiat: Mapped[float | None] = mapped_column(Numeric(18, 6), nullable=True)
    currency: Mapped[str] = mapped_column(String(8), nullable=False, default="USD")
    fiat_currency: Mapped[str | None] = mapped_column(String(8), nullable=True)
    fx_rate: Mapped[float | None] = mapped_column(Numeric(18, 8), nullable=True)

    # manual transfer / crypto details (never card data)
    payer_name: Mapped[str | None] = mapped_column(String(160), nullable=True)
    bank_reference: Mapped[str | None] = mapped_column(String(160), nullable=True)
    paid_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    receipt_file_id: Mapped[int | None] = mapped_column(ForeignKey("files.id", ondelete="SET NULL"), nullable=True)

    crypto_asset: Mapped[str | None] = mapped_column(String(24), nullable=True)
    crypto_network: Mapped[str | None] = mapped_column(String(32), nullable=True)
    crypto_address: Mapped[str | None] = mapped_column(String(160), nullable=True)
    crypto_amount: Mapped[float | None] = mapped_column(Numeric(28, 12), nullable=True)
    crypto_tx_hash: Mapped[str | None] = mapped_column(String(200), nullable=True, index=True)
    crypto_confirmations: Mapped[int | None] = mapped_column(Integer, nullable=True)
    crypto_verified: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    crypto_verified_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)

    gateway_name: Mapped[str | None] = mapped_column(String(32), nullable=True)
    gateway_session_id: Mapped[str | None] = mapped_column(String(200), nullable=True)
    gateway_authority: Mapped[str | None] = mapped_column(String(200), nullable=True)
    gateway_payload: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    signature_verified: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    review_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    reviewed_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    reviewed_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    approved_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    rejected_reason: Mapped[str | None] = mapped_column(String(400), nullable=True)
    refunded_micro: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)

    idempotency_key: Mapped[str] = mapped_column(String(120), nullable=False)
    ledger_entry_id: Mapped[int | None] = mapped_column(ForeignKey("credit_ledger.id", ondelete="SET NULL"), nullable=True)
    client_submitted: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)  # user claims vs. verified
    verified_by_platform: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    metadata_json: Mapped[dict | None] = mapped_column("metadata", JSON, nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()
    updated_at: Mapped[dt.datetime] = updated_at_col()

    user: Mapped["User"] = relationship(foreign_keys=[user_id])  # noqa: F821


class SubscriptionPlan(Base):
    __tablename__ = "subscription_plans"

    id: Mapped[int] = pk()
    slug: Mapped[str] = mapped_column(String(48), unique=True, nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    name_fa: Mapped[str | None] = mapped_column(String(120), nullable=True)
    description: Mapped[str] = mapped_column(Text, nullable=False, default="")
    price_micro_monthly: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    included_credit_micro: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    daily_request_limit: Mapped[int | None] = mapped_column(Integer, nullable=True)
    monthly_token_limit: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    markup_percent: Mapped[float | None] = mapped_column(Numeric(8, 3), nullable=True)
    features: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    is_public: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=100)
    created_at: Mapped[dt.datetime] = created_at_col()
    updated_at: Mapped[dt.datetime] = updated_at_col()


class Subscription(Base):
    __tablename__ = "subscriptions"
    __table_args__ = (Index("ix_subscriptions_user_status", "user_id", "status"),)

    id: Mapped[int] = pk()
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey("subscription_plans.id", ondelete="RESTRICT"), nullable=False)
    status: Mapped[str] = mapped_column(String(24), nullable=False, default=SubscriptionStatus.PENDING, index=True)
    started_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    current_period_start: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    current_period_end: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    cancel_at_period_end: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    canceled_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    renewal_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    last_payment_id: Mapped[int | None] = mapped_column(ForeignKey("payments.id", ondelete="SET NULL"), nullable=True)
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()
    updated_at: Mapped[dt.datetime] = updated_at_col()

    plan: Mapped[SubscriptionPlan] = relationship(lazy="selectin")
    user: Mapped["User"] = relationship(foreign_keys=[user_id])  # noqa: F821

    def is_currently_active(self, now: dt.datetime | None = None) -> bool:
        now = now or dt.datetime.now(dt.timezone.utc)
        if self.status not in (SubscriptionStatus.ACTIVE, SubscriptionStatus.TRIALING):
            return False
        if self.current_period_end and self.current_period_end < now:
            return False
        return True


def usage_admin_test_scope() -> str:  # pragma: no cover - helper for docs/tests
    return "Administrative test usage is recorded with is_admin_test=true and never billed to a user account."


class GrantCadence:
    ONCE = "once"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    ALL = (ONCE, DAILY, WEEKLY, MONTHLY)


class GrantTarget:
    ALL = "all"          # every active user
    ROLE = "role"        # users holding a role slug (the platform's user groups)
    PLAN = "plan"        # users with a current subscription to a plan
    USERS = "users"      # an explicit list of user ids
    USER = "user"        # a single user id
    ALL_TYPES = (ALL, ROLE, PLAN, USERS, USER)


class CreditCampaign(Base):
    """A credit grant program: a one-off bonus/reward or a recurring allowance.

    One row drives both worlds the owner asked for: ``cadence='once'`` campaigns
    are bonuses (an occasion, a manual reward — executed immediately or on
    demand), while ``daily|weekly|monthly`` campaigns are standing allowances
    executed by the worker when ``next_run_at`` falls due. Every execution is
    recorded as a :class:`CreditCampaignRun` and every recipient gets an
    append-only ledger entry whose idempotency key embeds campaign+run+user,
    so a retried run can never pay twice.
    """

    __tablename__ = "credit_campaigns"
    __table_args__ = (Index("ix_credit_campaigns_due", "active", "next_run_at"),)

    id: Mapped[int] = pk()
    title: Mapped[str] = mapped_column(String(160), nullable=False)
    kind: Mapped[str] = mapped_column(String(24), nullable=False, default="bonus")  # bonus | allowance
    cadence: Mapped[str] = mapped_column(String(16), nullable=False, default=GrantCadence.ONCE)
    amount_micro: Mapped[int] = mapped_column(BigInteger, nullable=False)
    target_type: Mapped[str] = mapped_column(String(16), nullable=False, default=GrantTarget.ALL)
    target_ref: Mapped[dict | None] = mapped_column(JSON, nullable=True)  # {role} | {plan_id} | {user_ids:[...]}
    reason: Mapped[str] = mapped_column(String(400), nullable=False, default="")
    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, index=True)
    starts_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    ends_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    next_run_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True, index=True)
    last_run_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    runs_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    total_granted_micro: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    total_recipients: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()
    updated_at: Mapped[dt.datetime] = updated_at_col()


class CreditCampaignRun(Base):
    """One execution of a campaign (audit trail; ``run_key`` makes it idempotent)."""

    __tablename__ = "credit_campaign_runs"
    __table_args__ = (UniqueConstraint("campaign_id", "run_key", name="uq_campaign_run_key"),)

    id: Mapped[int] = pk()
    campaign_id: Mapped[int] = mapped_column(ForeignKey("credit_campaigns.id", ondelete="CASCADE"), nullable=False, index=True)
    run_key: Mapped[str] = mapped_column(String(64), nullable=False)
    recipients: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    granted_micro: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    skipped: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    triggered_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()
