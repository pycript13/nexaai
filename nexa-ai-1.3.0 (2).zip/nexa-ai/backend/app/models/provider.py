"""Provider + model catalog entities.

Deliberate separations:
* ``visible`` (can a normal user see it), ``availability`` (can it run at all),
  ``access_tier`` (who may run it) and ``enabled`` (operator kill-switch) are
  four independent fields. A hidden model is not disabled; a visible model is
  not automatically usable; an administrator can always *test* anything.
* Capabilities are stored per model and verified through real test requests —
  they are never inferred from the model name.
"""
from __future__ import annotations

import datetime as dt

from sqlalchemy import (
    JSON,
    BigInteger,
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Table,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, backref, mapped_column, relationship

from app.db.base import UTCDateTime, Base, PKType, created_at_col, pk, updated_at_col


class ProviderType:
    OPENAI_COMPATIBLE = "openai_compatible"
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    AZURE_OPENAI = "azure_openai"
    GOOGLE = "google"
    OPENROUTER = "openrouter"
    GROQ = "groq"
    MISTRAL = "mistral"
    TOGETHER = "together"
    DEEPSEEK = "deepseek"
    OLLAMA = "ollama"
    STABILITY = "stability"
    ELEVENLABS = "elevenlabs"
    DEEPGRAM = "deepgram"
    REPLICATE = "replicate"
    CUSTOM = "custom"

    ALL = (
        OPENAI, ANTHROPIC, AZURE_OPENAI, GOOGLE, OPENROUTER, GROQ, MISTRAL, TOGETHER,
        DEEPSEEK, OLLAMA, STABILITY, ELEVENLABS, DEEPGRAM, REPLICATE, OPENAI_COMPATIBLE, CUSTOM,
    )

    LABELS = {
        OPENAI: "OpenAI",
        ANTHROPIC: "Anthropic",
        AZURE_OPENAI: "Azure OpenAI",
        GOOGLE: "Google Gemini",
        OPENROUTER: "OpenRouter",
        GROQ: "Groq",
        MISTRAL: "Mistral AI",
        TOGETHER: "Together AI",
        DEEPSEEK: "DeepSeek",
        OLLAMA: "Ollama (self-hosted)",
        STABILITY: "Stability AI",
        ELEVENLABS: "ElevenLabs",
        DEEPGRAM: "Deepgram",
        REPLICATE: "Replicate",
        OPENAI_COMPATIBLE: "OpenAI-compatible (generic)",
        CUSTOM: "Custom adapter",
    }


class ModelVisibility:
    PUBLIC = "public"          # listed for every eligible user
    HIDDEN = "hidden"          # stored and testable by admins, never listed
    INTERNAL = "internal"      # listed only inside the admin console
    ARCHIVED = "archived"      # retained for history, not offered anywhere

    ALL = (PUBLIC, HIDDEN, INTERNAL, ARCHIVED)


class ModelAvailability:
    AVAILABLE = "available"
    DEGRADED = "degraded"
    OFFLINE = "degraded_offline"
    DISABLED = "disabled"
    UNTESTED = "untested"

    ALL = (AVAILABLE, DEGRADED, DISABLED, UNTESTED)


class AccessTier:
    FREE = "free"                      # no charge (operator-funded)
    CREDIT = "credit"                  # metered against credit balance
    SUBSCRIPTION = "subscription"      # requires an active subscription plan
    RESTRICTED = "restricted"          # only granted users/roles
    INTERNAL = "internal"              # admin-only usage

    ALL = (FREE, CREDIT, SUBSCRIPTION, RESTRICTED, INTERNAL)


class ModelVariant(Base):
    """A named way of using a model (system prompt + generation defaults).

    Variants hang off a parent model: the platform keeps billing, access control,
    availability and auditing on the parent, so a variant can never become a way to reach a
    model a user is not allowed to use, nor a way to pay a different price.
    """

    __tablename__ = "model_variants"
    __table_args__ = (UniqueConstraint("model_id", "slug", name="uq_model_variant_slug"),)

    id: Mapped[int] = pk()
    model_id: Mapped[int] = mapped_column(ForeignKey("models.id", ondelete="CASCADE"), nullable=False, index=True)
    slug: Mapped[str] = mapped_column(String(64), nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False, default="")
    emoji: Mapped[str] = mapped_column(String(8), nullable=False, default="")

    system_prompt: Mapped[str] = mapped_column(Text, nullable=False, default="")
    default_temperature: Mapped[float | None] = mapped_column(Float, nullable=True)
    default_top_p: Mapped[float | None] = mapped_column(Float, nullable=True)
    default_max_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)

    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, index=True)
    is_default: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    scope: Mapped[str] = mapped_column(String(16), nullable=False, default="system")   # system | personal

    # Optional per-variant selling prices (credits per 1M tokens / per request).
    # NULL means "inherit the parent model's price"; a variant may only carry its
    # own price when the operator explicitly sets one, so styling a variant can
    # never silently change what a user pays.
    selling_input_per_mtok: Mapped[float | None] = mapped_column(Numeric(14, 6), nullable=True)
    selling_output_per_mtok: Mapped[float | None] = mapped_column(Numeric(14, 6), nullable=True)
    selling_per_request: Mapped[float | None] = mapped_column(Numeric(14, 6), nullable=True)
    owner_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=True, index=True)
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=100)

    usage_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    last_used_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)

    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    updated_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()
    updated_at: Mapped[dt.datetime] = updated_at_col()

    model = relationship("Model", backref=backref("variants", cascade="all, delete-orphan", passive_deletes=True),
                         foreign_keys=[model_id])


model_categories = Table(
    "model_categories_link",
    Base.metadata,
    Column("model_id", PKType, ForeignKey("models.id", ondelete="CASCADE"), primary_key=True),
    Column("category_id", PKType, ForeignKey("model_category.id", ondelete="CASCADE"), primary_key=True),
)

model_tags = Table(
    "model_tags_link",
    Base.metadata,
    Column("model_id", PKType, ForeignKey("models.id", ondelete="CASCADE"), primary_key=True),
    Column("tag_id", PKType, ForeignKey("model_tags.id", ondelete="CASCADE"), primary_key=True),
)


class Provider(Base):
    __tablename__ = "providers"
    __table_args__ = (UniqueConstraint("slug", name="uq_providers_slug"),)

    id: Mapped[int] = pk()
    slug: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    provider_type: Mapped[str] = mapped_column(String(40), nullable=False, default=ProviderType.OPENAI_COMPATIBLE, index=True)
    description: Mapped[str] = mapped_column(Text, nullable=False, default="")
    base_url: Mapped[str] = mapped_column(String(512), nullable=False, default="")
    organization_id: Mapped[str | None] = mapped_column(String(160), nullable=True)
    project_id: Mapped[str | None] = mapped_column(String(160), nullable=True)
    api_version: Mapped[str | None] = mapped_column(String(64), nullable=True)  # e.g. Azure
    region: Mapped[str | None] = mapped_column(String(64), nullable=True)       # e.g. Vertex/Bedrock

    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, index=True)
    is_default: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, default=100)  # lower = preferred in routing

    # credentials (encrypted at rest; never returned in full)
    api_key_encrypted: Mapped[str | None] = mapped_column(Text, nullable=True)
    api_key_hint: Mapped[str | None] = mapped_column(String(64), nullable=True)
    credential_rotated_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    extra_headers_encrypted: Mapped[str | None] = mapped_column(Text, nullable=True)
    extra_config: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    # transport tuning
    connect_timeout: Mapped[float] = mapped_column(Float, nullable=False, default=10.0)
    read_timeout: Mapped[float] = mapped_column(Float, nullable=False, default=120.0)
    max_retries: Mapped[int] = mapped_column(Integer, nullable=False, default=2)
    requests_per_minute: Mapped[int] = mapped_column(Integer, nullable=False, default=0)  # 0 = unlimited
    max_concurrency: Mapped[int] = mapped_column(Integer, nullable=False, default=4)
    proxy_url: Mapped[str | None] = mapped_column(String(255), nullable=True)
    network_preference: Mapped[str] = mapped_column(String(8), nullable=False, default="auto")  # auto | ipv4 | ipv6

    # health / sync bookkeeping
    last_sync_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    last_sync_status: Mapped[str | None] = mapped_column(String(24), nullable=True)
    last_sync_message: Mapped[str | None] = mapped_column(String(400), nullable=True)
    last_sync_model_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
    last_test_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    last_test_status: Mapped[str | None] = mapped_column(String(24), nullable=True)
    last_test_message: Mapped[str | None] = mapped_column(String(400), nullable=True)
    last_error_category: Mapped[str | None] = mapped_column(String(48), nullable=True)
    last_error_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)

    created_at: Mapped[dt.datetime] = created_at_col()
    updated_at: Mapped[dt.datetime] = updated_at_col()
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)

    models: Mapped[list["Model"]] = relationship(back_populates="provider", cascade="all, delete-orphan")
    health_samples: Mapped[list["ProviderHealthSample"]] = relationship(back_populates="provider", cascade="all, delete-orphan")

    @property
    def has_credentials(self) -> bool:
        return bool(self.api_key_encrypted)


class ProviderHealthSample(Base):
    """Rolling latency/error/latency samples used for provider dashboards."""

    __tablename__ = "provider_health_samples"
    __table_args__ = (Index("ix_provider_health_provider_created", "provider_id", "created_at"),)

    id: Mapped[int] = pk()
    provider_id: Mapped[int] = mapped_column(ForeignKey("providers.id", ondelete="CASCADE"), nullable=False, index=True)
    operation: Mapped[str] = mapped_column(String(32), nullable=False, default="chat")
    success: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    latency_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    error_category: Mapped[str | None] = mapped_column(String(48), nullable=True)
    status_code: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()

    provider: Mapped[Provider] = relationship(back_populates="health_samples")


class ModelCategory(Base):
    __tablename__ = "model_category"
    __table_args__ = (UniqueConstraint("slug", name="uq_model_category_slug"),)

    id: Mapped[int] = pk()
    slug: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(96), nullable=False)
    name_fa: Mapped[str | None] = mapped_column(String(96), nullable=True)
    description: Mapped[str] = mapped_column(String(255), nullable=False, default="")
    icon: Mapped[str | None] = mapped_column(String(48), nullable=True)
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=100)
    created_at: Mapped[dt.datetime] = created_at_col()

    models: Mapped[list["Model"]] = relationship(secondary=model_categories, back_populates="categories", lazy="selectin")


class ModelTag(Base):
    __tablename__ = "model_tags"
    __table_args__ = (UniqueConstraint("slug", name="uq_model_tags_slug"),)

    id: Mapped[int] = pk()
    slug: Mapped[str] = mapped_column(String(48), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(64), nullable=False)


class Model(Base):
    __tablename__ = "models"
    __table_args__ = (
        UniqueConstraint("provider_id", "provider_model_id", name="uq_models_provider_model"),
        Index("ix_models_visibility_enabled", "visibility", "enabled"),
        Index("ix_models_tier", "access_tier"),
    )

    id: Mapped[int] = pk()
    provider_id: Mapped[int] = mapped_column(ForeignKey("providers.id", ondelete="CASCADE"), nullable=False, index=True)
    provider_model_id: Mapped[str] = mapped_column(String(200), nullable=False)
    display_name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False, default="")
    model_family: Mapped[str | None] = mapped_column(String(96), nullable=True, index=True)

    # capabilities (verified, never guessed from the name)
    capabilities: Mapped[list | None] = mapped_column(JSON, nullable=False, default=list)
    input_modalities: Mapped[list | None] = mapped_column(JSON, nullable=False, default=list)
    output_modalities: Mapped[list | None] = mapped_column(JSON, nullable=False, default=list)
    context_window: Mapped[int | None] = mapped_column(Integer, nullable=True)
    max_output_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    supports_streaming: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    supports_tools: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    supports_vision: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    supports_embeddings: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    supports_json_mode: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    supports_reasoning: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    supports_audio_input: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    supports_audio_output: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    supports_video: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    attributes: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    # commercial
    provider_cost_input_per_mtok: Mapped[float | None] = mapped_column(Numeric(14, 6), nullable=True)
    provider_cost_output_per_mtok: Mapped[float | None] = mapped_column(Numeric(14, 6), nullable=True)
    provider_cost_per_request: Mapped[float | None] = mapped_column(Numeric(14, 6), nullable=True)
    provider_cost_per_image: Mapped[float | None] = mapped_column(Numeric(14, 6), nullable=True)
    provider_cost_per_audio_minute: Mapped[float | None] = mapped_column(Numeric(14, 6), nullable=True)
    provider_cost_currency: Mapped[str] = mapped_column(String(8), nullable=False, default="USD")
    pricing_uncertain: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    selling_input_per_mtok: Mapped[float | None] = mapped_column(Numeric(14, 6), nullable=True)
    selling_output_per_mtok: Mapped[float | None] = mapped_column(Numeric(14, 6), nullable=True)
    selling_per_request: Mapped[float | None] = mapped_column(Numeric(14, 6), nullable=True)
    selling_per_image: Mapped[float | None] = mapped_column(Numeric(14, 6), nullable=True)
    selling_per_audio_minute: Mapped[float | None] = mapped_column(Numeric(14, 6), nullable=True)

    # governance
    visibility: Mapped[str] = mapped_column(String(24), nullable=False, default=ModelVisibility.HIDDEN, index=True)
    availability: Mapped[str] = mapped_column(String(24), nullable=False, default=ModelAvailability.UNTESTED, index=True)
    access_tier: Mapped[str] = mapped_column(String(24), nullable=False, default=AccessTier.CREDIT, index=True)
    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, index=True)
    published: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    subscription_plan_id: Mapped[int | None] = mapped_column(ForeignKey("subscription_plans.id", ondelete="SET NULL"), nullable=True)
    is_default: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_favorite_hint: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=100)
    deprecation_note: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # health bookkeeping
    last_tested_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    last_test_status: Mapped[str | None] = mapped_column(String(24), nullable=True)
    last_test_latency_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    last_test_error_category: Mapped[str | None] = mapped_column(String(48), nullable=True)
    last_test_message: Mapped[str | None] = mapped_column(String(400), nullable=True)
    discovered_by_sync: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    provider_metadata: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    created_at: Mapped[dt.datetime] = created_at_col()
    updated_at: Mapped[dt.datetime] = updated_at_col()
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)

    provider: Mapped[Provider] = relationship(back_populates="models", lazy="selectin")
    categories: Mapped[list[ModelCategory]] = relationship(secondary=model_categories, back_populates="models", lazy="selectin")
    grants: Mapped[list["ModelGrant"]] = relationship(back_populates="model", cascade="all, delete-orphan")

    # -- helpers ------------------------------------------------------------
    def capability_set(self) -> set[str]:
        from app.providers.capabilities import Operation

        raw = set(self.capabilities or [])
        if self.supports_streaming:
            raw.add(Operation.CHAT.value)
        return raw

    def supports(self, operation: str) -> bool:
        return operation in self.capability_set()

    def is_user_visible(self) -> bool:
        return (
            self.visibility == ModelVisibility.PUBLIC
            and self.published
            and self.enabled
            and self.availability != ModelAvailability.DISABLED
        )

    def public_dict(self) -> dict:
        return {
            "id": self.id,
            "display_name": self.display_name,
            "provider_model_id": self.provider_model_id,
            "provider": self.provider.name if self.provider else None,
            "provider_id": self.provider_id,
            "capabilities": self.capabilities or [],
            "input_modalities": self.input_modalities or [],
            "output_modalities": self.output_modalities or [],
            "context_window": self.context_window,
            "max_output_tokens": self.max_output_tokens,
            "access_tier": self.access_tier,
            "availability": self.availability,
            "supports_streaming": self.supports_streaming,
            "supports_tools": self.supports_tools,
            "supports_vision": self.supports_vision,
            "description": self.description,
            "model_family": self.model_family,
        }


class ModelGrant(Base):
    """Explicit access grant: user- or role-scoped, optionally with a spend cap."""

    __tablename__ = "model_grants"
    __table_args__ = (
        UniqueConstraint("model_id", "subject_type", "subject_id", name="uq_model_grants_subject"),
        Index("ix_model_grants_model", "model_id"),
    )

    id: Mapped[int] = pk()
    model_id: Mapped[int] = mapped_column(ForeignKey("models.id", ondelete="CASCADE"), nullable=False)
    subject_type: Mapped[str] = mapped_column(String(16), nullable=False, default="user")  # user | role
    subject_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    granted_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    daily_spend_limit_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    monthly_spend_limit_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    expires_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    note: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()

    model: Mapped[Model] = relationship(back_populates="grants")
