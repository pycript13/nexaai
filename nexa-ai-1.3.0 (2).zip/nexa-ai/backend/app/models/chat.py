from __future__ import annotations

import datetime as dt

from sqlalchemy import JSON, Boolean, DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import UTCDateTime, Base, created_at_col, pk, updated_at_col


class MessageRole:
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


class Conversation(Base):
    __tablename__ = "conversations"
    __table_args__ = (
        Index("ix_conversations_user_updated", "user_id", "updated_at"),
        Index("ix_conversations_user_archived", "user_id", "archived"),
    )

    id: Mapped[int] = pk()
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(200), nullable=False, default="New conversation")
    module: Mapped[str] = mapped_column(String(32), nullable=False, default="chat", index=True)
    model_id: Mapped[int | None] = mapped_column(ForeignKey("models.id", ondelete="SET NULL"), nullable=True)
    variant_id: Mapped[int | None] = mapped_column(ForeignKey("model_variants.id", ondelete="SET NULL"), nullable=True)
    system_prompt: Mapped[str | None] = mapped_column(Text, nullable=True)
    settings_json: Mapped[dict | None] = mapped_column("settings", JSON, nullable=True)
    pinned: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    archived: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    message_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    total_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    total_charged_micro: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    search_text: Mapped[str | None] = mapped_column(Text, nullable=True)  # lowercased index for LIKE search
    created_at: Mapped[dt.datetime] = created_at_col()
    updated_at: Mapped[dt.datetime] = updated_at_col()

    messages: Mapped[list["Message"]] = relationship(
        back_populates="conversation", cascade="all, delete-orphan", order_by="Message.id"
    )


class Message(Base):
    __tablename__ = "messages"
    __table_args__ = (Index("ix_messages_conversation_created", "conversation_id", "id"),)

    id: Mapped[int] = pk()
    conversation_id: Mapped[int] = mapped_column(ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    role: Mapped[str] = mapped_column(String(16), nullable=False, default=MessageRole.USER)
    content: Mapped[str] = mapped_column(Text, nullable=False, default="")
    content_parts: Mapped[list | None] = mapped_column(JSON, nullable=True)  # multimodal parts (text/image refs)
    model_id: Mapped[int | None] = mapped_column(ForeignKey("models.id", ondelete="SET NULL"), nullable=True)
    provider_model_id: Mapped[str | None] = mapped_column(String(200), nullable=True)
    prompt_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    completion_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    total_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    provider_request_id: Mapped[str | None] = mapped_column(String(160), nullable=True)
    finish_reason: Mapped[str | None] = mapped_column(String(48), nullable=True)
    latency_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    status: Mapped[str] = mapped_column(String(24), nullable=False, default="complete")  # complete|streaming|error|stopped|superseded
    error_category: Mapped[str | None] = mapped_column(String(48), nullable=True)
    error_message: Mapped[str | None] = mapped_column(String(500), nullable=True)
    attachments: Mapped[list | None] = mapped_column(JSON, nullable=True)  # [{"file_id":1,"name":"a.pdf"}]
    usage_id: Mapped[int | None] = mapped_column(ForeignKey("usage_records.id", ondelete="SET NULL"), nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()
    updated_at: Mapped[dt.datetime] = updated_at_col()

    conversation: Mapped[Conversation] = relationship(back_populates="messages")


class ConversationShare(Base):
    """Sharing a conversation with another user, or via a read-only link.

    ``permission``: ``view`` (read-only) or ``edit`` (the collaborator can also
    post messages; each poster's own usage is billed to that poster). A row
    with ``token`` set and no ``shared_with_id`` is a public link: anyone
    holding the link can *read* the conversation without an account, never
    write. Revoking sets ``revoked_at``; rows are kept for audit.
    """

    __tablename__ = "conversation_shares"
    __table_args__ = (
        UniqueConstraint("token", name="uq_conversation_share_token"),
        Index("ix_conversation_shares_with", "shared_with_id", "revoked_at"),
        Index("ix_conversation_shares_conversation", "conversation_id", "revoked_at"),
    )

    id: Mapped[int] = pk()
    conversation_id: Mapped[int] = mapped_column(ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False, index=True)
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    shared_with_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=True, index=True)
    token: Mapped[str | None] = mapped_column(String(64), nullable=True)
    permission: Mapped[str] = mapped_column(String(16), nullable=False, default="view")  # view | edit
    expires_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    revoked_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    last_accessed_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()
