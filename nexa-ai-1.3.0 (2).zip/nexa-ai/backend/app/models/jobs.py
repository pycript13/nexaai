from __future__ import annotations

import datetime as dt

from sqlalchemy import JSON, Boolean, DateTime, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import UTCDateTime, Base, created_at_col, pk, updated_at_col


class JobStatus:
    PENDING = "pending"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"
    EXPIRED = "expired"

    TERMINAL = (SUCCEEDED, FAILED, CANCELLED, EXPIRED)


class JobType:
    IMAGE_GENERATION = "image_generation"
    AUDIO_TRANSCRIPTION = "audio_transcription"
    SPEECH_GENERATION = "speech_generation"
    VIDEO_GENERATION = "video_generation"
    DOCUMENT_INDEX = "document_index"
    DOCUMENT_SUMMARY = "document_summary"
    DATA_ANALYSIS = "data_analysis"
    BATCH_TRANSLATION = "batch_translation"
    MODEL_TEST = "model_test"
    PROVIDER_SYNC = "provider_sync"
    EXPORT = "export"
    CLEANUP = "cleanup"

    ALL = (
        IMAGE_GENERATION, AUDIO_TRANSCRIPTION, SPEECH_GENERATION, VIDEO_GENERATION, DOCUMENT_INDEX,
        DOCUMENT_SUMMARY, DATA_ANALYSIS, BATCH_TRANSLATION, MODEL_TEST, PROVIDER_SYNC, EXPORT, CLEANUP,
    )


class Job(Base):
    """Persistent job queue (DB-backed so the queue survives restarts).

    Workers claim jobs with a conditional UPDATE, which makes the claim atomic on
    both PostgreSQL and SQLite. ``lease_expires_at`` recovers jobs from crashed
    workers.
    """

    __tablename__ = "jobs"
    __table_args__ = (
        Index("ix_jobs_status_created", "status", "created_at"),
        Index("ix_jobs_user_created", "user_id", "created_at"),
        Index("ix_jobs_type_status", "job_type", "status"),
    )

    id: Mapped[int] = pk()
    job_type: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default=JobStatus.PENDING, index=True)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, default=100)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    model_id: Mapped[int | None] = mapped_column(ForeignKey("models.id", ondelete="SET NULL"), nullable=True)
    provider_id: Mapped[int | None] = mapped_column(ForeignKey("providers.id", ondelete="SET NULL"), nullable=True)
    payload: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    result: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    progress: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=3)
    worker_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    lease_expires_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    error_category: Mapped[str | None] = mapped_column(String(48), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    charged_micro: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    provider_cost_micro: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    admin_test: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    created_at: Mapped[dt.datetime] = created_at_col()
    started_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    finished_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    updated_at: Mapped[dt.datetime] = updated_at_col()
