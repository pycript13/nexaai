"""Secure file storage.

Security model
* The stored path is generated server-side: ``<upload_dir>/<kind>/<yyyy>/<mm>/<uuid>.<ext>``
  where ``<ext>`` is validated against an allowlist. The client filename never
  influences the path (no traversal, no overwrite, no execution).
* Content is sniffed (magic bytes) and must be consistent with the extension.
* Files live outside the web root; downloads always go through an authorized
  endpoint that checks ownership/permissions for every request.
* Per-user quota + per-file size cap + configurable retention.
"""
from __future__ import annotations

import re

import datetime as dt
import hashlib
import json
import os
import shutil
import subprocess
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.errors import NotFound, PermissionDenied, StorageError, ValidationError
from app.core.logging import get_logger
from app.models.files import FileKind, StoredFile
from app.models.user import User

log = get_logger(__name__)

TEXT_EXTENSIONS = {"txt", "md", "csv", "tsv", "json", "log", "yml", "yaml", "xml", "html", "py", "js", "ts", "sql"}
IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "webp", "gif", "bmp"}
AUDIO_EXTENSIONS = {"mp3", "wav", "m4a", "ogg", "flac", "webm"}
VIDEO_EXTENSIONS = {"mp4", "mov", "webm"}
DOC_EXTENSIONS = {"pdf", "docx", "xlsx", "xls", "doc"}

# magic-number signatures for the formats we accept (content sniffing)
SIGNATURES: dict[str, list[bytes]] = {
    "png": [b"\x89PNG\r\n\x1a\n"],
    "jpg": [b"\xff\xd8\xff"],
    "jpeg": [b"\xff\xd8\xff"],
    "gif": [b"GIF87a", b"GIF89a"],
    "webp": [b"RIFF"],
    "bmp": [b"BM"],
    "pdf": [b"%PDF"],
    "zip": [b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08"],   # docx/xlsx are zip containers
    "docx": [b"PK\x03\x04"],
    "xlsx": [b"PK\x03\x04"],
    "mp3": [b"ID3", b"\xff\xfb", b"\xff\xf3", b"\xff\xf2"],
    "wav": [b"RIFF"],
    "ogg": [b"OggS"],
    "flac": [b"fLaC"],
    "m4a": [b"\x00\x00\x00\x20ftyp", b"\x00\x00\x00\x18ftyp", b"ftyp"],
    "mp4": [b"\x00\x00\x00\x18ftyp", b"\x00\x00\x00\x20ftyp", b"ftyp"],
    "mov": [b"ftyp", b"moov"],
    "webm": [b"\x1a\x45\xdf\xa3"],
}


def upload_root() -> Path:
    root = Path(settings.upload_dir).resolve()
    (root / "tmp").mkdir(parents=True, exist_ok=True)
    for kind in ("uploads", "generated", "receipts", "exports"):
        (root / kind).mkdir(parents=True, exist_ok=True)
    return root


def _kind_dir(kind: str) -> str:
    return {
        FileKind.UPLOAD: "uploads",
        FileKind.GENERATED: "generated",
        FileKind.RECEIPT: "receipts",
        FileKind.EXPORT: "exports",
        FileKind.ATTACHMENT: "uploads",
    }.get(kind, "uploads")


def safe_extension(filename: str) -> str:
    """Extract a *validated* extension. Anything suspicious returns ''."""
    name = (filename or "").replace("\\", "/").split("/")[-1]
    if "." not in name:
        return ""
    ext = name.rsplit(".", 1)[-1].lower()
    if not ext.isalnum() or len(ext) > 8:
        return ""
    return ext


def validate_extension(ext: str) -> None:
    allowed = settings.allowed_extension_set
    if not ext:
        raise ValidationError("The file has no recognisable extension; only whitelisted file types are accepted.")
    if ext not in allowed:
        raise ValidationError(
            f"File type '.{ext}' is not allowed. Allowed types: {', '.join(sorted(allowed))}.",
            details={"allowed_extensions": sorted(allowed)},
        )


def sniff_matches(head: bytes, ext: str) -> bool:
    signatures = SIGNATURES.get(ext)
    if not signatures:
        # no signature policy for this type: require it to be non-binary where we can
        if ext in TEXT_EXTENSIONS:
            try:
                head.decode("utf-8")
                return True
            except UnicodeDecodeError:
                return False
        return True
    return any(head.startswith(sig) for sig in signatures)


def mime_for(ext: str) -> str:
    import mimetypes

    guessed, _ = mimetypes.guess_type(f"file.{ext}")
    return guessed or "application/octet-stream"


def user_storage_used(db: Session, user_id: int) -> int:
    total = db.scalar(
        select(func.coalesce(func.sum(StoredFile.size_bytes), 0)).where(
            StoredFile.user_id == user_id, StoredFile.deleted_at.is_(None)
        )
    )
    return int(total or 0)


@dataclass
class ScanResult:
    status: str
    detail: str = ""


def malware_scan(path: Path) -> ScanResult:
    if not settings.malware_scan_enabled:
        return ScanResult("not_configured", "Malware scanning is disabled (NEXA_MALWARE_SCAN_ENABLED=false).")
    command = settings.malware_scan_command
    if not command:
        return ScanResult("misconfigured", "NEXA_MALWARE_SCAN_ENABLED is true but NEXA_MALWARE_SCAN_COMMAND is empty.")
    try:
        completed = subprocess.run(  # noqa: S603 - operator-configured command
            [*command.split(), str(path)], capture_output=True, timeout=60, check=False
        )
    except Exception as exc:  # pragma: no cover - depends on host tooling
        return ScanResult("error", f"Scanner failed to run: {exc}")
    if completed.returncode == 0:
        return ScanResult("clean")
    if completed.returncode == 1:
        return ScanResult("infected", completed.stdout.decode(errors="ignore")[:300])
    return ScanResult("error", completed.stderr.decode(errors="ignore")[:300])


def store_upload(
    db: Session,
    *,
    user: User,
    filename: str,
    data: bytes,
    kind: str = FileKind.UPLOAD,
    mime_type: str | None = None,
    is_private: bool = True,
    validate_content: bool = True,
    metadata: dict | None = None,
) -> StoredFile:
    max_bytes = settings.max_upload_mb * 1024 * 1024
    if len(data) == 0:
        raise ValidationError("The uploaded file is empty.")
    if len(data) > max_bytes:
        from app.core.errors import PayloadTooLarge

        raise PayloadTooLarge(
            f"File is too large ({len(data) / 1048576:.1f} MB). The limit is {settings.max_upload_mb} MB.",
            details={"max_upload_mb": settings.max_upload_mb, "size_bytes": len(data)},
        )
    ext = safe_extension(filename)
    validate_extension(ext)
    if is_private and user is not None:
        # Quotas are operator-tunable settings (Admin → Settings → storage); the
        # environment values are only the defaults. One enforcement point covers
        # uploads AND model-generated files (store_generated funnels into here).
        from app.services import settings_store

        quota_mb = int(settings_store.get_value(db, "files.user_quota_mb", settings.user_storage_quota_mb))
        max_files = int(settings_store.get_value(db, "files.user_max_files", 1000))
        used = user_storage_used(db, user.id)
        quota = quota_mb * 1024 * 1024
        if used + len(data) > quota:
            raise StorageError(
                f"Storage quota exceeded ({used / 1048576:.1f} MB used of {quota_mb} MB). "
                "Delete files from your workspace to free space.",
                details={"used_bytes": used, "quota_bytes": quota},
            )
        file_count = int(db.scalar(
            select(func.count()).select_from(StoredFile).where(
                StoredFile.user_id == user.id,
                StoredFile.deleted_at.is_(None),
                StoredFile.kind != FileKind.RECEIPT,
            )
        ) or 0)
        if max_files > 0 and file_count >= max_files:
            raise StorageError(
                f"File count limit reached ({file_count} of {max_files} files). "
                "Delete files from your workspace to add new ones.",
                details={"file_count": file_count, "max_files": max_files},
            )
    head = data[:64]
    signature_ok = sniff_matches(head, ext)
    if validate_content and not signature_ok:
        raise ValidationError(
            f"The content of '{filename}' does not look like a valid .{ext} file (signature check failed).",
            details={"extension": ext, "expected_signature": True},
        )

    root = upload_root()
    now = dt.datetime.now(dt.timezone.utc)
    target_dir = root / _kind_dir(kind) / f"{now:%Y}" / f"{now:%m}"
    target_dir.mkdir(parents=True, exist_ok=True)
    token = uuid.uuid4().hex
    stored_name = f"{token}.{ext}" if ext else token
    path = (target_dir / stored_name).resolve()
    if root not in path.parents:
        raise StorageError("Resolved storage path escaped the upload directory — aborting.")  # defensive

    with open(path, "wb") as handle:
        handle.write(data)
    checksum = hashlib.sha256(data).hexdigest()

    scan = malware_scan(path)
    if scan.status == "infected":
        path.unlink(missing_ok=True)
        log.error("Rejected infected upload user=%s name=%s detail=%s", user.id if user else None, filename, scan.detail)
        raise ValidationError("The uploaded file was rejected by the malware scanner.", details={"scan": scan.status})
    if scan.status == "error":
        log.warning("Malware scan failed for %s: %s", path.name, scan.detail)

    record = StoredFile(
        uuid=token,
        user_id=user.id if user else None,
        kind=kind,
        original_name=filename[:255],
        storage_path=str(path),
        mime_type=mime_type or mime_for(ext),
        extension=ext,
        size_bytes=len(data),
        checksum_sha256=checksum,
        sha_verified=True,
        content_validated=signature_ok,
        malware_scan_status=scan.status,
        is_private=is_private,
        metadata_json=metadata,
        expires_at=now + dt.timedelta(days=settings.file_retention_days) if settings.file_retention_days else None,
    )
    db.add(record)
    if user is not None:
        user.storage_used_bytes = (user.storage_used_bytes or 0) + len(data)
    db.flush()
    return record


def store_generated(
    db: Session,
    *,
    user: User | None,
    data: bytes,
    extension: str = "png",
    name: str = "generated",
    kind: str = FileKind.GENERATED,
    mime_type: str | None = None,
    metadata: dict | None = None,
) -> StoredFile:
    return store_upload(
        db,
        user=user,  # type: ignore[arg-type]
        filename=f"{name}.{extension}",
        data=data,
        kind=kind,
        mime_type=mime_type or mime_for(extension),
        is_private=True,
        validate_content=True,
        metadata=metadata,
    )


def absolute_path_for(record: StoredFile) -> Path:
    root = upload_root()
    path = Path(record.storage_path).resolve()
    if root not in path.parents:
        raise StorageError("Stored file path is outside the managed upload directory.")
    if not path.exists():
        raise NotFound("The file no longer exists on disk (it may have been cleaned up by the retention policy).")
    return path


def read_bytes(record: StoredFile) -> bytes:
    return absolute_path_for(record).read_bytes()


def authorize_download(db: Session, *, record: StoredFile, user: User | None) -> None:
    from app.services import access as access_service

    if record.deleted_at is not None:
        raise NotFound("File was deleted.")
    if record.kind == FileKind.RECEIPT:
        if user is None:
            raise PermissionDenied("Authentication required.")
        if record.user_id == user.id:
            return
        access_service.require_permission(user, "payments.read")
        return
    if record.is_private:
        if user is None:
            raise PermissionDenied("Authentication required to download this file.")
        if record.user_id == user.id:
            return
        if access_service.has_permission(user, "users.read"):
            return
        raise PermissionDenied("You do not have access to this file.")
    if user is None:
        raise PermissionDenied("Authentication required.")


def delete_file(db: Session, record: StoredFile, *, hard: bool = False) -> None:
    record.deleted_at = dt.datetime.now(dt.timezone.utc)
    if hard:
        try:
            absolute_path_for(record).unlink(missing_ok=True)
        except (StorageError, NotFound):
            pass
        record.storage_path = ""
    if record.user_id:
        user = db.get(User, record.user_id)
        if user is not None:
            user.storage_used_bytes = max(0, (user.storage_used_bytes or 0) - record.size_bytes)


def extract_text(record: StoredFile, *, max_chars: int = 200_000) -> str:
    """Best-effort text extraction for documents (no code execution)."""
    path = absolute_path_for(record)
    ext = record.extension
    try:
        if ext in TEXT_EXTENSIONS:
            return path.read_text(encoding="utf-8", errors="replace")[:max_chars]
        if ext == "pdf":
            from pypdf import PdfReader

            reader = PdfReader(str(path))
            chunks: list[str] = []
            for page in reader.pages[:200]:
                chunks.append(page.extract_text() or "")
                if sum(len(c) for c in chunks) > max_chars:
                    break
            return "\n".join(chunks)[:max_chars]
        if ext == "xlsx":
            from openpyxl import load_workbook

            workbook = load_workbook(filename=str(path), read_only=True, data_only=True)
            lines: list[str] = []
            for sheet in workbook.worksheets[:10]:
                lines.append(f"# Sheet: {sheet.title}")
                for row in sheet.iter_rows(max_row=500, values_only=True):
                    lines.append("\t".join("" if cell is None else str(cell) for cell in row))
                    if sum(len(line) for line in lines) > max_chars:
                        break
            workbook.close()
            return "\n".join(lines)[:max_chars]
        if ext == "docx":
            import zipfile

            with zipfile.ZipFile(path) as archive:
                xml = archive.read("word/document.xml").decode("utf-8", errors="replace")
            import re

            text = re.sub(r"<[^>]+>", " ", xml)
            return re.sub(r"\s+", " ", text)[:max_chars]
        if ext == "csv":
            return path.read_text(encoding="utf-8", errors="replace")[:max_chars]
    except Exception as exc:  # noqa: BLE001
        log.warning("Text extraction failed for file %s: %s", record.uuid, exc)
        raise ValidationError(f"Could not extract text from '{record.original_name}': {exc}") from exc
    raise ValidationError(
        f"Text extraction is not supported for '.{ext}' files. Supported: {', '.join(sorted(TEXT_EXTENSIONS | DOC_EXTENSIONS))}."
    )


def cleanup_expired(db: Session, *, now: dt.datetime | None = None, hard: bool = True) -> dict:
    now = now or dt.datetime.now(dt.timezone.utc)
    expired = db.scalars(
        select(StoredFile).where(StoredFile.expires_at.is_not(None), StoredFile.expires_at < now, StoredFile.deleted_at.is_(None))
    ).all()
    removed = 0
    for record in expired:
        delete_file(db, record, hard=hard)
        removed += 1
    # abandoned temp files
    tmp_dir = upload_root() / "tmp"
    purged = 0
    for candidate in tmp_dir.glob("*"):
        try:
            if candidate.is_file() and dt.datetime.fromtimestamp(candidate.stat().st_mtime, dt.timezone.utc) < now - dt.timedelta(days=1):
                candidate.unlink()
                purged += 1
        except OSError:  # pragma: no cover
            continue
    db.commit()
    return {"files_expired": removed, "tmp_purged": purged}


# ------------------------------------------------------------------- indexing --
CHUNK_CHARS = 1400
CHUNK_OVERLAP = 200


def chunk_text(text: str, *, chunk_chars: int = CHUNK_CHARS, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """Split text into overlapping chunks at paragraph/sentence boundaries."""
    text = (text or "").strip()
    if not text:
        return []
    if len(text) <= chunk_chars:
        return [text]
    chunks: list[str] = []
    start = 0
    while start < len(text):
        end = min(len(text), start + chunk_chars)
        if end < len(text):
            window = text[start:end]
            for separator in ("\n\n", ". ", "\n"):
                cut = window.rfind(separator)
                if cut > chunk_chars * 0.5:
                    end = start + cut + len(separator)
                    break
        chunks.append(text[start:end].strip())
        if end >= len(text):
            break
        start = max(end - overlap, start + 1)
    return [chunk for chunk in chunks if chunk]


def store_chunks(record: StoredFile, chunks: list[str], *, limit: int = 500) -> list[dict[str, Any]]:
    """Persist lexical chunks on the file row (bounded so a huge PDF cannot bloat the DB)."""
    trimmed = chunks[:limit]
    payload = [{"i": index, "text": chunk, "words": len(chunk.split())} for index, chunk in enumerate(trimmed)]
    metadata = dict(record.metadata_json or {})
    metadata["chunks"] = payload
    metadata["chunk_count"] = len(payload)
    metadata["chunks_truncated"] = len(chunks) > len(payload)
    record.metadata_json = metadata
    return payload


def store_embeddings(record: StoredFile, vectors: list[list[float]]) -> None:
    metadata = dict(record.metadata_json or {})
    chunks = metadata.get("chunks") or []
    if len(vectors) != len(chunks):
        raise ValidationError(
            f"The embedding provider returned {len(vectors)} vectors for {len(chunks)} chunks; the index was not stored."
        )
    metadata["embeddings"] = vectors
    record.metadata_json = metadata


def retrieve_context(record: StoredFile, question: str, *, budget_chars: int = 120_000) -> tuple[str, dict[str, Any]]:
    """Return context for a question.

    If the document was indexed (``chunk_text``/``store_chunks``) and is larger than
    the budget, chunks are ranked with a lexical score (optionally boosted by stored
    embeddings) and the best ones are concatenated. Otherwise the extracted text is
    returned whole. Nothing is invented — a document with no extractable text says so.
    """
    metadata = record.metadata_json or {}
    chunks = metadata.get("chunks") or []
    embeddings = metadata.get("embeddings")
    text = record.extracted_text or extract_text(record)
    if not chunks or len(text) <= budget_chars:
        return text[:budget_chars], {"strategy": "full_text", "chunks_used": 0,
                                     "truncated": len(text) > budget_chars, "indexed": bool(chunks)}

    terms = {term for term in re.findall(r"[\w\u0600-\u06FF]{3,}", (question or "").lower())}
    scored: list[tuple[float, int, str]] = []
    for chunk in chunks:
        body = chunk["text"].lower()
        score = sum(body.count(term) for term in terms) if terms else 0
        scored.append((float(score), chunk["i"], chunk["text"]))
    scored.sort(key=lambda item: (-item[0], item[1]))
    chosen: list[tuple[int, str]] = []
    used = 0
    for score, index, body in scored:
        if used + len(body) > budget_chars:
            continue
        chosen.append((index, body))
        used += len(body)
        if used > budget_chars * 0.9:
            break
    chosen.sort(key=lambda item: item[0])
    joined = "\n\n".join(f"[chunk {index + 1}] {body}" for index, body in chosen)
    return joined, {
        "strategy": "lexical_retrieval" if not embeddings else "lexical_retrieval_with_embeddings",
        "chunks_used": len(chosen),
        "chunks_total": len(chunks),
        "truncated": True,
        "indexed": True,
    }
