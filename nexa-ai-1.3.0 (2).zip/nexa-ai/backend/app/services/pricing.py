"""Pricing resolution and cost math.

Unit conventions (all stored as integers; no binary floating point in money paths):

* Balances, charges and costs are **micro-credits**: ``1 credit = 1_000_000 micro``.
* **Per-token prices** (``input_per_mtok_micro`` / ``output_per_mtok_micro`` and the
  matching ``provider_*`` rule columns) are **micro-credits per 1,000,000 tokens**,
  which is numerically identical to *credits per 1,000,000 tokens*. ``0.28`` credits per
  million tokens is therefore stored as ``280000``. Storing the price in micro-credits
  per MTok (instead of micro-credits per token) is what keeps cheap models honest: at
  one micro-credit per token the smallest representable price would be one whole credit
  per million tokens, so every real-world price below that silently became **free**.
* **Flat prices** (``per_request_micro``, ``per_image_micro``, ``per_audio_minute_micro``,
  ``per_job_micro``) are plain micro-credits per unit.
* Provider prices are stored in USD on the model (``provider_cost_*``) and converted with
  the operator-configured ``NEXA_CREDIT_USD_RATE`` (how many USD one credit is worth).

A per-token charge is ``tokens * rate / 1_000_000`` micro-credits, rounded half-up per
line item so that a 23-token call at 0.10 credits/MTok still costs money.

Resolution order for the *customer* price of a model+operation:
1. user-scoped rule  2. plan-scoped rule  3. model-scoped rule
4. provider-scoped rule  5. global rule  6. model.selling_* columns
7. derived from provider cost + markup (uncertain flag set)
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.billing import PricingRule, Subscription, SubscriptionStatus
from app.models.provider import AccessTier, Model
from app.models.user import User

MICRO = 1_000_000

UNIT_INPUT_TOKENS = "input_tokens"
UNIT_OUTPUT_TOKENS = "output_tokens"
UNIT_REQUEST = "request"
UNIT_IMAGE = "image"
UNIT_AUDIO_MINUTE = "audio_minute"
UNIT_JOB = "job"


def usd_to_micro(usd: float | Decimal | None) -> int | None:
    if usd is None:
        return None
    rate = Decimal(str(settings.credit_usd_rate or 1))
    return int((Decimal(str(usd)) / rate * MICRO).to_integral_value(rounding="ROUND_HALF_UP"))


def micro_to_credits(micro: int | None) -> float | None:
    """Convert internal micro-credits to a display-friendly credit amount.

    Display only — all arithmetic happens on integer micro-credits.
    """
    if micro is None:
        return None
    return micro / MICRO


def credits_to_micro(credits: float | Decimal | None) -> int | None:
    if credits is None:
        return None
    return int((Decimal(str(credits)) * MICRO).to_integral_value(rounding="ROUND_HALF_UP"))


def micro_to_display(micro: int | None) -> str:
    if micro is None:
        return "—"
    return f"{micro / MICRO:.6f}".rstrip("0").rstrip(".")


@dataclass
class PriceQuote:
    """The effective price for one operation, with provenance for auditing."""

    rule_id: int | None = None
    rule_version: int | None = None
    scope: str = "default"
    currency: str = settings.default_currency

    # per-token prices, in micro-credits per 1,000,000 tokens
    input_per_mtok_micro: int | None = None
    output_per_mtok_micro: int | None = None
    per_request_micro: int | None = None
    per_image_micro: int | None = None
    per_audio_minute_micro: int | None = None
    per_job_micro: int | None = None
    minimum_charge_micro: int = 0

    # provider cost, same unit (micro-credits per 1,000,000 tokens — i.e. credits per MTok)
    provider_input_per_mtok_micro: int | None = None
    provider_output_per_mtok_micro: int | None = None
    provider_per_request_micro: int | None = None
    provider_per_image_micro: int | None = None
    provider_per_audio_minute_micro: int | None = None
    provider_cost_uncertain: bool = False
    markup_percent: float = 0.0
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "rule_id": self.rule_id,
            "rule_version": self.rule_version,
            "scope": self.scope,
            "currency": self.currency,
            "input_per_mtok_micro": self.input_per_mtok_micro,
            "output_per_mtok_micro": self.output_per_mtok_micro,
            "per_request_micro": self.per_request_micro,
            "per_image_micro": self.per_image_micro,
            "per_audio_minute_micro": self.per_audio_minute_micro,
            "per_job_micro": self.per_job_micro,
            "minimum_charge_micro": self.minimum_charge_micro,
            "provider_cost_uncertain": self.provider_cost_uncertain,
            "markup_percent": self.markup_percent,
            "warnings": self.warnings,
        }


def _apply_rule(quote: PriceQuote, rule: PricingRule) -> None:
    quote.rule_id = rule.id
    quote.rule_version = rule.version
    quote.scope = rule.scope
    quote.currency = rule.currency or quote.currency
    quote.input_per_mtok_micro = rule.input_per_mtok_micro
    quote.output_per_mtok_micro = rule.output_per_mtok_micro
    quote.per_request_micro = rule.per_request_micro
    quote.per_image_micro = rule.per_image_micro
    quote.per_audio_minute_micro = rule.per_audio_minute_micro
    quote.per_job_micro = rule.per_job_micro
    quote.minimum_charge_micro = rule.minimum_charge_micro or 0
    quote.provider_input_per_mtok_micro = rule.provider_input_per_mtok_micro
    quote.provider_output_per_mtok_micro = rule.provider_output_per_mtok_micro
    quote.provider_per_request_micro = rule.provider_per_request_micro
    quote.provider_per_image_micro = rule.provider_per_image_micro
    quote.provider_per_audio_minute_micro = rule.provider_per_audio_minute_micro
    quote.provider_cost_uncertain = rule.provider_pricing_uncertain
    quote.markup_percent = float(rule.markup_percent or 0)


def active_plan_for(db: Session, user: User | None) -> Subscription | None:
    if user is None:
        return None
    subs = db.scalars(
        select(Subscription).where(
            Subscription.user_id == user.id, Subscription.status.in_([SubscriptionStatus.ACTIVE, SubscriptionStatus.TRIALING])
        )
    ).all()
    for sub in subs:
        if sub.is_currently_active():
            return sub
    return None


def resolve_price(db: Session, model: Model, *, user: User | None = None, operation: str = "chat", variant=None) -> PriceQuote:  # noqa: ANN001
    """Resolve the effective customer price and provider cost for a model.

    A scoped rule only *defines* the price when it actually carries unit prices.
    Rules that only set a markup/minimum (e.g. the seeded global default) are used
    as a baseline, and the model's own prices are applied on top so that a
    model-specific price is never silently discarded.
    """
    quote = PriceQuote()
    sub = active_plan_for(db, user)
    scopes: list[tuple[str, int | None]] = []
    if user is not None:
        scopes.append(("user", user.id))
    if sub is not None:
        scopes.append(("plan", sub.plan_id))
    scopes.append(("model", model.id))
    scopes.append(("provider", model.provider_id))
    scopes.append(("global", None))

    rule_with_prices: PricingRule | None = None
    base_rule: PricingRule | None = None
    for scope, ref in scopes:
        candidate = db.scalars(
            select(PricingRule)
            .where(PricingRule.active.is_(True), PricingRule.scope == scope, PricingRule.scope_ref_id == ref)
            .order_by(PricingRule.version.desc())
            .limit(1)
        ).first()
        if candidate is None:
            continue
        if base_rule is None:
            base_rule = candidate
        if _rule_defines_prices(candidate):
            rule_with_prices = candidate
            break

    if rule_with_prices is not None:
        _apply_rule(quote, rule_with_prices)
    elif base_rule is not None:
        quote.rule_id = base_rule.id
        quote.rule_version = base_rule.version
        quote.scope = f"{base_rule.scope}_defaults"
        quote.currency = base_rule.currency or quote.currency
        quote.minimum_charge_micro = base_rule.minimum_charge_micro or 0
        quote.markup_percent = float(base_rule.markup_percent or 0)

    if variant is not None and (
        getattr(variant, "selling_input_per_mtok", None) is not None
        or getattr(variant, "selling_output_per_mtok", None) is not None
        or getattr(variant, "selling_per_request", None) is not None
    ):
        # An explicitly priced sub-model (variant) wins over the parent model's
        # columns; anything the variant leaves NULL inherits the parent price.
        quote.scope = "variant_columns"
        quote.input_per_mtok_micro = _as_micro(variant.selling_input_per_mtok) or _as_micro(model.selling_input_per_mtok)
        quote.output_per_mtok_micro = _as_micro(variant.selling_output_per_mtok) or _as_micro(model.selling_output_per_mtok)
        quote.per_request_micro = _flat_credits_to_micro(variant.selling_per_request) or _flat_credits_to_micro(model.selling_per_request)
        quote.per_image_micro = _flat_credits_to_micro(model.selling_per_image)
        quote.per_audio_minute_micro = _flat_credits_to_micro(model.selling_per_audio_minute)

    if not _quote_has_unit_prices(quote):
        # fall back to the model's own selling prices
        quote.scope = quote.scope if quote.rule_id else "model_columns"
        quote.input_per_mtok_micro = quote.input_per_mtok_micro or _as_micro(model.selling_input_per_mtok)
        quote.output_per_mtok_micro = quote.output_per_mtok_micro or _as_micro(model.selling_output_per_mtok)
        quote.per_request_micro = quote.per_request_micro or _flat_credits_to_micro(model.selling_per_request)
        quote.per_image_micro = quote.per_image_micro or _flat_credits_to_micro(model.selling_per_image)
        quote.per_audio_minute_micro = quote.per_audio_minute_micro or _flat_credits_to_micro(model.selling_per_audio_minute)
    if not quote.minimum_charge_micro:
        quote.minimum_charge_micro = settings.minimum_charge_micro

    # provider cost: rule values win, otherwise the model's published USD prices
    if quote.provider_input_per_mtok_micro is None:
        quote.provider_input_per_mtok_micro = usd_to_micro(model.provider_cost_input_per_mtok)
    if quote.provider_output_per_mtok_micro is None:
        quote.provider_output_per_mtok_micro = usd_to_micro(model.provider_cost_output_per_mtok)
    if quote.provider_per_request_micro is None:
        quote.provider_per_request_micro = usd_to_micro(model.provider_cost_per_request)
    if quote.provider_per_image_micro is None:
        quote.provider_per_image_micro = usd_to_micro(model.provider_cost_per_image)
    if quote.provider_per_audio_minute_micro is None:
        quote.provider_per_audio_minute_micro = usd_to_micro(model.provider_cost_per_audio_minute)
    quote.provider_cost_uncertain = quote.provider_cost_uncertain or bool(model.pricing_uncertain)

    if not _quote_has_unit_prices(quote):
        # derive from provider cost + markup where possible
        markup = Decimal(str(quote.markup_percent or settings.default_markup_percent or 0)) / Decimal(100)
        derived = False
        for field_name, cost in (
            ("input_per_mtok_micro", quote.provider_input_per_mtok_micro),
            ("output_per_mtok_micro", quote.provider_output_per_mtok_micro),
            ("per_request_micro", quote.provider_per_request_micro),
            ("per_image_micro", quote.provider_per_image_micro),
        ):
            if cost is not None:
                setattr(quote, field_name, int(Decimal(cost) * (1 + markup)))
                derived = True
        if derived:
            quote.scope = "derived_from_provider_cost"
            if not quote.markup_percent:
                quote.markup_percent = float(settings.default_markup_percent or 0)
            quote.warnings.append(
                "Price was derived from the configured provider cost plus platform markup; "
                "verify the provider's current price list."
            )
        else:
            quote.scope = "unpriced"
            quote.warnings.append(
                "No pricing information is configured for this model. Charges are recorded as 0 until "
                "an administrator sets prices (Admin → Finance → Pricing)."
            )
    return quote


def _as_micro(value) -> int | None:  # noqa: ANN001
    """Credits per **million tokens** -> micro-credits per **million tokens**.

    A price of ``3`` (credits/MTok) becomes ``3_000_000``; ``0.28`` becomes ``280000``.
    The value must never be truncated towards zero: the previous "micro-credits per
    token" convention turned every price below one credit per MTok (that is: every
    realistic provider price) into ``0`` and billed nothing at all. Rounding is
    half-up so a 6-decimal price cannot drift.
    """
    if value is None:
        return None
    return int((Decimal(str(value)) * MICRO).to_integral_value(rounding="ROUND_HALF_UP"))


def micro_to_per_mtok_credits(rate: int | None) -> float | None:
    """Display helper: stored micro-credits per MTok -> credits per MTok."""
    if rate is None:
        return None
    return float(Decimal(int(rate)) / MICRO)


def _flat_credits_to_micro(value) -> int | None:  # noqa: ANN001
    """A *flat* price expressed in credits (per request / image / audio minute) -> micro-credits.

    Unlike the per-MTok columns this is a full credit amount, so ``0.25`` (credits per
    image) becomes ``250000`` micro-credits — never ``0``.
    """
    if value is None:
        return None
    return credits_to_micro(value)


def _rule_defines_prices(rule: PricingRule) -> bool:
    return any(
        getattr(rule, field) is not None
        for field in ("input_per_mtok_micro", "output_per_mtok_micro", "per_request_micro", "per_image_micro",
                      "per_audio_minute_micro", "per_job_micro")
    )


def _quote_has_unit_prices(quote: PriceQuote) -> bool:
    return any(
        getattr(quote, field) is not None
        for field in ("input_per_mtok_micro", "output_per_mtok_micro", "per_request_micro", "per_image_micro",
                      "per_audio_minute_micro", "per_job_micro")
    )


@dataclass
class ChargeBreakdown:
    charged_micro: int
    provider_cost_micro: int | None
    usage_source: str
    breakdown: list[dict]
    minimum_applied: bool = False
    warnings: list[str] = field(default_factory=list)


def _tokens_charge(tokens: int, rate_micro_per_mtok: int) -> int:
    """Charge for ``tokens`` at a micro-credits-per-million-tokens rate (rounded half-up)."""
    exact = Decimal(int(tokens)) * Decimal(int(rate_micro_per_mtok)) / MICRO
    return int(exact.to_integral_value(rounding="ROUND_HALF_UP"))


def compute_charge(
    quote: PriceQuote,
    *,
    prompt_tokens: int | None = None,
    completion_tokens: int | None = None,
    requests: int = 1,
    images: int = 0,
    audio_seconds: float | None = None,
    jobs: int = 0,
    access_tier: str = AccessTier.CREDIT,
    apply_minimum: bool = True,
) -> ChargeBreakdown:
    """Compute the customer charge and provider cost for one operation."""
    items: list[dict] = []
    total_micro = 0
    provider_total = 0
    provider_known = True
    warnings = list(quote.warnings)

    if access_tier == AccessTier.FREE:
        return ChargeBreakdown(0, 0, "not_applicable", [{"note": "model access tier is 'free'"}], warnings=warnings)

    if prompt_tokens is not None and quote.input_per_mtok_micro:
        amount = _tokens_charge(prompt_tokens, quote.input_per_mtok_micro)
        total_micro += amount
        items.append({"unit": UNIT_INPUT_TOKENS, "quantity": prompt_tokens, "unit_price_micro": quote.input_per_mtok_micro, "amount_micro": amount})
    if completion_tokens is not None and quote.output_per_mtok_micro:
        amount = _tokens_charge(completion_tokens, quote.output_per_mtok_micro)
        total_micro += amount
        items.append({"unit": UNIT_OUTPUT_TOKENS, "quantity": completion_tokens, "unit_price_micro": quote.output_per_mtok_micro, "amount_micro": amount})
    if requests and quote.per_request_micro:
        amount = int((Decimal(requests) * Decimal(quote.per_request_micro)).to_integral_value(rounding="ROUND_HALF_UP"))
        total_micro += amount
        items.append({"unit": UNIT_REQUEST, "quantity": requests, "unit_price_micro": quote.per_request_micro, "amount_micro": amount})
    if images and quote.per_image_micro:
        amount = int((Decimal(images) * Decimal(quote.per_image_micro)).to_integral_value(rounding="ROUND_HALF_UP"))
        total_micro += amount
        items.append({"unit": UNIT_IMAGE, "quantity": images, "unit_price_micro": quote.per_image_micro, "amount_micro": amount})
    if audio_seconds and quote.per_audio_minute_micro:
        minutes = Decimal(str(audio_seconds)) / Decimal(60)
        amount = int((minutes * Decimal(quote.per_audio_minute_micro)).to_integral_value(rounding="ROUND_HALF_UP"))
        total_micro += amount
        items.append({"unit": UNIT_AUDIO_MINUTE, "quantity": round(float(minutes), 4), "unit_price_micro": quote.per_audio_minute_micro, "amount_micro": amount})
    if jobs and quote.per_job_micro:
        amount = int((Decimal(jobs) * Decimal(quote.per_job_micro)).to_integral_value(rounding="ROUND_HALF_UP"))
        total_micro += amount
        items.append({"unit": UNIT_JOB, "quantity": jobs, "unit_price_micro": quote.per_job_micro, "amount_micro": amount})

    minimum_applied = False
    if apply_minimum and quote.minimum_charge_micro and 0 < total_micro < quote.minimum_charge_micro:
        total_micro = quote.minimum_charge_micro
        minimum_applied = True
        items.append({"unit": "minimum", "quantity": 1, "unit_price_micro": quote.minimum_charge_micro, "amount_micro": 0,
                      "note": "minimum charge applied"})

    # provider cost
    if quote.provider_input_per_mtok_micro and prompt_tokens is not None:
        provider_total += _tokens_charge(prompt_tokens, quote.provider_input_per_mtok_micro)
    elif prompt_tokens is not None and access_tier != AccessTier.FREE:
        provider_known = False
    if quote.provider_output_per_mtok_micro and completion_tokens is not None:
        provider_total += _tokens_charge(completion_tokens, quote.provider_output_per_mtok_micro)
    elif completion_tokens is not None and access_tier != AccessTier.FREE:
        provider_known = False
    if quote.provider_per_request_micro:
        provider_total += quote.provider_per_request_micro * max(requests, 1)
    if images and quote.provider_per_image_micro:
        provider_total += quote.provider_per_image_micro * images
    if audio_seconds and quote.provider_per_audio_minute_micro:
        provider_total += int((Decimal(str(audio_seconds)) / Decimal(60) * Decimal(quote.provider_per_audio_minute_micro)).to_integral_value(rounding="ROUND_HALF_UP"))

    return ChargeBreakdown(
        charged_micro=max(0, int(total_micro)),
        provider_cost_micro=provider_total if provider_known else None,
        usage_source="provider_reported",
        breakdown=items + [{
            "provider_cost_micro": provider_total if provider_known else None,
            "cost_uncertain": (not provider_known) or quote.provider_cost_uncertain,
        }],
        minimum_applied=minimum_applied,
        warnings=warnings,
    )


def redact_provider_cost(breakdown: ChargeBreakdown) -> dict:
    """Customer-facing view: never expose provider cost."""
    return {
        "charged_micro": breakdown.charged_micro,
        "items": [item for item in breakdown.breakdown if item.get("provider_cost_micro") is None and "provider_cost_micro" not in item],
        "minimum_applied": breakdown.minimum_applied,
    }


# ---------------------------------------------------------------------------
# Default market pricing for newly added models
# ---------------------------------------------------------------------------
# Typical public list prices (USD per 1M tokens, input/output) of the model
# families platforms usually resell. When an operator adds a model without
# prices, these become the model's provider cost and the selling price is
# derived with the platform markup — the operator can change every number
# later (Admin → Pricing, or per-model/per-variant fields). Guesses that do
# not come from a known family are flagged ``pricing_uncertain``.
_MARKET_PRICES: list[tuple[tuple[str, ...], float, float]] = [
    (("gpt-4o-mini", "gpt-4.1-mini", "gpt-4.1-nano"), 0.15, 0.60),
    (("gpt-4o",), 2.50, 10.00),
    (("gpt-4.1", "o3", "o4-mini"), 2.00, 8.00),
    (("gpt-5",), 1.25, 10.00),
    (("Opus",), 15.00, 75.00),
    (("sonnet",), 3.00, 15.00),
    (("Alex", "haiku"), 0.80, 4.00),
    (("gemini-2.5-pro", "gemini-pro"), 1.25, 10.00),
    (("gemini", "flash"), 0.30, 2.50),
    (("deepseek",), 0.27, 1.10),
    (("llama", "mixtral", "mistral", "qwen", "phi-", "gemma"), 0.20, 0.60),
    (("embedding", "embed", "bge-", "e5-"), 0.02, 0.0),
]


def market_price_for(provider_model_id: str) -> tuple[float, float, bool] | None:
    """(input, output, known_family) USD/MTok for a model id, or None."""
    name = (provider_model_id or "").lower()
    if not name:
        return None
    for keys, price_in, price_out in _MARKET_PRICES:
        if any(k in name for k in keys):
            return price_in, price_out, True
    return None


def apply_default_pricing(model) -> bool:  # noqa: ANN001
    """Fill missing prices of a newly added model from market defaults.

    Provider cost comes from the family table when the model is recognised;
    otherwise a conservative mid-tier fallback is used and flagged uncertain.
    Selling prices are the cost plus the platform markup. Existing operator
    prices are never overwritten. Returns True when anything was filled.
    """
    changed = False
    market = market_price_for(getattr(model, "provider_model_id", "") or "")
    if market is not None:
        price_in, price_out, known = market
    else:
        caps = set(getattr(model, "capabilities", None) or [])
        if "embeddings" in caps:
            price_in, price_out = 0.02, 0.0
        elif getattr(model, "supports_reasoning", False):
            price_in, price_out = 2.00, 8.00
        else:
            price_in, price_out = 0.50, 1.50
        known = False
    if model.provider_cost_input_per_mtok is None:
        model.provider_cost_input_per_mtok = price_in
        changed = True
    if model.provider_cost_output_per_mtok is None:
        model.provider_cost_output_per_mtok = price_out
        changed = True
    markup = Decimal(str(settings.default_markup_percent or 0)) / Decimal(100)
    if model.selling_input_per_mtok is None and model.provider_cost_input_per_mtok is not None:
        model.selling_input_per_mtok = float(Decimal(str(model.provider_cost_input_per_mtok)) * (1 + markup))
        changed = True
    if model.selling_output_per_mtok is None and model.provider_cost_output_per_mtok is not None:
        model.selling_output_per_mtok = float(Decimal(str(model.provider_cost_output_per_mtok)) * (1 + markup))
        changed = True
    if not known:
        model.pricing_uncertain = True
    return changed
