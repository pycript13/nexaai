"""Database-backed persistent job queue.

Why the database: financial and long-running work must survive restarts and must
not depend on in-memory state. Claims are made with a conditional UPDATE so two
workers can never run the same job (works on PostgreSQL and SQLite).
"""
from __future__ import annotations

import datetime as dt
import uuid
from collections.abc import Callable
from typing import Any

from sqlalchemy import func, select, update
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.errors import RateLimited, ValidationError
from app.core.logging import get_logger
from app.models.jobs import Job, JobStatus, JobType
from app.services import audit as audit_service

log = get_logger(__name__)


def queue_depth(db: Session) -> dict[str, int]:
    rows = db.execute(
        select(Job.status, func.count(Job.id)).group_by(Job.status)
    ).all()
    return {status: int(count) for status, count in rows}


def enqueue(
    db: Session,
    *,
    job_type: str,
    payload: dict[str, Any] | None = None,
    user_id: int | None = None,
    model_id: int | None = None,
    provider_id: int | None = None,
    priority: int = 100,
    max_attempts: int | None = None,
    admin_test: bool = False,
) -> Job:
    if job_type not in JobType.ALL:
        raise ValidationError(f"Unknown job type '{job_type}'.")
    if user_id is not None:
        pending = db.scalar(
            select(func.count(Job.id)).where(Job.user_id == user_id, Job.status.in_([JobStatus.PENDING, JobStatus.RUNNING]))
        ) or 0
        if int(pending) >= settings.queue_max_pending_per_user:
            raise RateLimited(
                f"You already have {pending} queued jobs (limit {settings.queue_max_pending_per_user}). Wait for them to finish.",
                retry_after=60,
            )
    job = Job(
        job_type=job_type,
        payload=payload or {},
        user_id=user_id,
        model_id=model_id,
        provider_id=provider_id,
        priority=priority,
        max_attempts=max_attempts or settings.job_max_attempts,
        admin_test=admin_test,
    )
    db.add(job)
    db.flush()
    log.info("job enqueued id=%s type=%s user=%s", job.id, job_type, user_id)
    return job


def claim_job(db: Session, worker_id: str, *, job_types: list[str] | None = None) -> Job | None:
    now = dt.datetime.now(dt.timezone.utc)
    # recover expired leases first
    requeue_expired(db, now=now)
    stmt = (
        select(Job)
        .where(Job.status == JobStatus.PENDING)
        .order_by(Job.priority.asc(), Job.created_at.asc())
        .limit(1)
        .with_for_update(skip_locked=True)
    )
    if job_types:
        stmt = stmt.where(Job.job_type.in_(job_types))
    job = db.scalars(stmt).first()
    if job is None:
        return None
    result = db.execute(
        update(Job)
        .where(Job.id == job.id, Job.status == JobStatus.PENDING)
        .values(
            status=JobStatus.RUNNING,
            worker_id=worker_id,
            started_at=now,
            lease_expires_at=now + dt.timedelta(seconds=settings.job_lease_seconds),
            attempts=Job.attempts + 1,
        )
    )
    db.commit()
    if result.rowcount == 0:
        return None  # another worker won the race
    db.refresh(job)
    return job


def heartbeat(db: Session, job: Job, *, progress: int | None = None) -> None:
    job.lease_expires_at = dt.datetime.now(dt.timezone.utc) + dt.timedelta(seconds=settings.job_lease_seconds)
    if progress is not None:
        job.progress = max(0, min(100, progress))
    db.commit()


def complete(db: Session, job: Job, *, result: dict[str, Any] | None = None, charged_micro: int = 0, provider_cost_micro: int = 0) -> None:
    job.status = JobStatus.SUCCEEDED
    job.result = result or {}
    job.progress = 100
    job.finished_at = dt.datetime.now(dt.timezone.utc)
    job.charged_micro = charged_micro
    job.provider_cost_micro = provider_cost_micro
    db.commit()
    log.info("job succeeded id=%s type=%s", job.id, job.job_type)


def fail(db: Session, job: Job, *, category: str, message: str, retryable: bool = False) -> None:
    job.error_category = category
    job.error_message = message[:2000]
    job.finished_at = dt.datetime.now(dt.timezone.utc)
    if retryable and job.attempts < job.max_attempts:
        job.status = JobStatus.PENDING
        job.lease_expires_at = None
        job.worker_id = None
        log.warning("job retry scheduled id=%s attempt=%s/%s category=%s", job.id, job.attempts, job.max_attempts, category)
    else:
        job.status = JobStatus.FAILED
        log.error("job failed id=%s type=%s category=%s", job.id, job.job_type, category)
    db.commit()


def cancel(db: Session, job: Job, *, actor=None) -> None:  # noqa: ANN001
    if job.status in JobStatus.TERMINAL:
        raise ValidationError(f"Job {job.id} is already {job.status}.")
    job.status = JobStatus.CANCELLED
    job.finished_at = dt.datetime.now(dt.timezone.utc)
    db.commit()
    audit_service.record_audit(db, action="job.cancelled", summary=f"Job {job.id} ({job.job_type}) cancelled.", actor=actor,
                               entity_type="job", entity_id=job.id, commit=True)


def requeue_expired(db: Session, *, now: dt.datetime | None = None) -> int:
    now = now or dt.datetime.now(dt.timezone.utc)
    stale = db.scalars(
        select(Job).where(Job.status == JobStatus.RUNNING, Job.lease_expires_at.is_not(None), Job.lease_expires_at < now)
    ).all()
    count = 0
    for job in stale:
        if job.attempts >= job.max_attempts:
            job.status = JobStatus.FAILED
            job.error_category = "lease_expired"
            job.error_message = "Worker lease expired and no attempts remain."
            job.finished_at = now
        else:
            job.status = JobStatus.PENDING
            job.worker_id = None
            job.lease_expires_at = None
        count += 1
    if count:
        db.commit()
        log.warning("requeued %s expired job(s)", count)
    return count


def new_worker_id() -> str:
    return f"worker-{uuid.uuid4().hex[:8]}"


def register_handler(job_type: str):  # noqa: ANN201 - decorator
    """Register a handler in the shared registry used by the worker loop."""
    from app.workers.registry_types import HANDLERS

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        HANDLERS[job_type] = func
        return func

    return decorator


def run_once(db: Session, worker_id: str | None = None) -> Job | None:
    """Claim and execute a single job. Returns the job that was processed."""
    import app.workers.handlers  # noqa: F401  (registers handlers on import)
    from app.workers.registry_types import HANDLERS

    worker_id = worker_id or new_worker_id()
    job = claim_job(db, worker_id)
    if job is None:
        return None
    handler = HANDLERS.get(job.job_type)
    if handler is None:
        fail(db, job, category="unsupported_operation", message=f"No handler registered for job type '{job.job_type}'.")
        return job
    try:
        handler(db, job)
    except Exception as exc:  # noqa: BLE001 - worker must survive handler errors
        from app.core.errors import ProviderError

        log.exception("job handler raised id=%s type=%s", job.id, job.job_type)
        if isinstance(exc, ProviderError):
            fail(db, job, category=exc.category, message=exc.detail, retryable=exc.retryable)
        else:
            fail(db, job, category="internal_error", message=f"{type(exc).__name__}: {exc}", retryable=False)
    return job
