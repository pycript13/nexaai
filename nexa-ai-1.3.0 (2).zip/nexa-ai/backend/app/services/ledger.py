"""Immutable credit ledger.

Guarantees
* Every balance mutation writes exactly one append-only ``credit_ledger`` row.
* Entries carry a globally unique ``idempotency_key``; re-posting the same key is
  a no-op that returns the original entry (safe against retries, double submits
  and webhook replays).
* Balances are mutated with an atomic SQL ``UPDATE ... balance = balance + :delta``
  so concurrent charges cannot lose updates on PostgreSQL or SQLite.
* A negative balance is only possible for explicitly allowed operators (refund
  reversal / admin adjustment); user charges are rejected when funds are short.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass

from sqlalchemy import func, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.errors import InsufficientBalance, ValidationError
from app.core.logging import get_logger
from app.models.billing import CreditAccount, LedgerEntry, LedgerEntryType

log = get_logger(__name__)


@dataclass
class LedgerResult:
    entry: LedgerEntry
    created: bool
    balance_after_micro: int


def get_account(db: Session, user_id: int, *, create: bool = True, currency: str | None = None) -> CreditAccount | None:
    account = db.scalars(select(CreditAccount).where(CreditAccount.user_id == user_id)).first()
    if account is None and create:
        from app.core.config import settings

        account = CreditAccount(user_id=user_id, balance_micro=0, currency=currency or settings.default_currency)
        db.add(account)
        db.flush()
    return account


def _post(
    db: Session,
    *,
    account: CreditAccount,
    amount_micro: int,
    entry_type: str,
    idempotency_key: str,
    description: str,
    reference_type: str | None = None,
    reference_id: int | None = None,
    metadata: dict | None = None,
    created_by_id: int | None = None,
    reversal_of_id: int | None = None,
) -> LedgerResult:
    existing = db.scalars(select(LedgerEntry).where(LedgerEntry.idempotency_key == idempotency_key)).first()
    if existing is not None:
        return LedgerResult(entry=existing, created=False, balance_after_micro=existing.balance_after_micro)

    # Atomic balance mutation. For debits the sufficiency check is part of the
    # same statement (``WHERE balance >= required``), so two concurrent charges
    # can never overdraw the account on PostgreSQL or SQLite.
    statement = update(CreditAccount).where(CreditAccount.id == account.id)
    if amount_micro < 0 and not getattr(account, "_allow_negative_override", False):
        statement = statement.where(CreditAccount.balance_micro + amount_micro >= 0)
    result = db.execute(statement.values(balance_micro=CreditAccount.balance_micro + amount_micro))
    if result.rowcount == 0:
        current = db.scalar(select(CreditAccount.balance_micro).where(CreditAccount.id == account.id)) or 0
        raise InsufficientBalance(
            "Insufficient credit balance for this request.",
            details={"balance_micro": int(current), "required_micro": -int(amount_micro),
                     "shortfall_micro": int(-amount_micro - current)},
        )
    new_balance = db.scalar(select(CreditAccount.balance_micro).where(CreditAccount.id == account.id)) or 0
    entry = LedgerEntry(
        account_id=account.id,
        user_id=account.user_id,
        entry_type=entry_type,
        amount_micro=amount_micro,
        balance_after_micro=int(new_balance),
        currency=account.currency,
        idempotency_key=idempotency_key,
        description=description[:400],
        reference_type=reference_type,
        reference_id=reference_id,
        metadata_json=metadata,
        created_by_id=created_by_id,
        reversal_of_id=reversal_of_id,
    )
    db.add(entry)
    try:
        db.flush()
    except IntegrityError:
        # another concurrent transaction inserted the same idempotency key first
        db.rollback()
        raise
    account.balance_micro = int(new_balance)
    log.info(
        "ledger entry type=%s amount_micro=%s balance_after=%s user=%s key=%s",
        entry_type, amount_micro, new_balance, account.user_id, idempotency_key,
    )
    return LedgerResult(entry=entry, created=True, balance_after_micro=int(new_balance))


def credit(
    db: Session,
    *,
    user_id: int,
    amount_micro: int,
    entry_type: str = LedgerEntryType.DEPOSIT,
    idempotency_key: str,
    description: str = "",
    reference_type: str | None = None,
    reference_id: int | None = None,
    metadata: dict | None = None,
    created_by_id: int | None = None,
) -> LedgerResult:
    if amount_micro <= 0:
        raise ValidationError("Credit amount must be positive.")
    account = get_account(db, user_id)
    assert account is not None
    if account.is_frozen:
        raise ValidationError("This credit account is frozen; contact an administrator.")
    result = _post(
        db, account=account, amount_micro=int(amount_micro), entry_type=entry_type, idempotency_key=idempotency_key,
        description=description, reference_type=reference_type, reference_id=reference_id, metadata=metadata,
        created_by_id=created_by_id,
    )
    if result.created and entry_type in (LedgerEntryType.DEPOSIT,):
        account.lifetime_deposited_micro = (account.lifetime_deposited_micro or 0) + int(amount_micro)
    return result


def debit(
    db: Session,
    *,
    user_id: int,
    amount_micro: int,
    entry_type: str = LedgerEntryType.USAGE_CHARGE,
    idempotency_key: str,
    description: str = "",
    reference_type: str | None = None,
    reference_id: int | None = None,
    metadata: dict | None = None,
    created_by_id: int | None = None,
    allow_negative: bool = False,
    allow_zero: bool = True,
) -> LedgerResult:
    if amount_micro < 0:
        raise ValidationError("Debit amount must be positive.")
    if amount_micro == 0 and allow_zero:
        account = get_account(db, user_id)
        assert account is not None
        return LedgerResult(
            entry=None,  # type: ignore[arg-type]
            created=False,
            balance_after_micro=account.balance_micro,
        )
    account = get_account(db, user_id)
    assert account is not None
    if account.is_frozen:
        raise ValidationError("This credit account is frozen; contact an administrator.")
    if not allow_negative and account.balance_micro < amount_micro:
        # fast path; the authoritative check is the conditional UPDATE in _post()
        raise InsufficientBalance(
            "Insufficient credit balance for this request.",
            details={
                "balance_micro": account.balance_micro,
                "required_micro": amount_micro,
                "shortfall_micro": amount_micro - account.balance_micro,
            },
        )
    account._allow_negative_override = bool(allow_negative)  # type: ignore[attr-defined]
    try:
        result = _post(
            db, account=account, amount_micro=-int(amount_micro), entry_type=entry_type, idempotency_key=idempotency_key,
            description=description, reference_type=reference_type, reference_id=reference_id, metadata=metadata,
            created_by_id=created_by_id,
        )
    finally:
        account._allow_negative_override = False  # type: ignore[attr-defined]
    if result.created:
        account.lifetime_spent_micro = (account.lifetime_spent_micro or 0) + int(amount_micro)
    return result


def adjust(
    db: Session,
    *,
    user_id: int,
    amount_micro: int,
    reason: str,
    admin_id: int | None,
    idempotency_key: str,
    entry_type: str = LedgerEntryType.ADJUSTMENT,
    metadata: dict | None = None,
) -> LedgerResult:
    """Administrative balance adjustment (can be positive or negative)."""
    account = get_account(db, user_id)
    assert account is not None
    if amount_micro == 0:
        raise ValidationError("Adjustment amount must not be zero.")
    result = _post(
        db, account=account, amount_micro=int(amount_micro), entry_type=entry_type, idempotency_key=idempotency_key,
        description=reason, reference_type="adjustment", metadata=metadata, created_by_id=admin_id,
    )
    return result


def balance_of(db: Session, user_id: int) -> int:
    account = get_account(db, user_id)
    return int(account.balance_micro) if account else 0


def spent_since(db: Session, user_id: int, since: dt.datetime) -> int:
    total = db.scalar(
        select(func.coalesce(func.sum(LedgerEntry.amount_micro), 0)).where(
            LedgerEntry.user_id == user_id,
            LedgerEntry.amount_micro < 0,
            LedgerEntry.created_at >= since,
            LedgerEntry.entry_type == LedgerEntryType.USAGE_CHARGE,
        )
    )
    return int(-(total or 0))


def reconcile(db: Session, user_id: int) -> dict:
    """Recompute a balance from the ledger and compare with the stored value."""
    account = get_account(db, user_id)
    if account is None:
        return {"account": None}
    total = db.scalar(
        select(func.coalesce(func.sum(LedgerEntry.amount_micro), 0)).where(LedgerEntry.account_id == account.id)
    )
    stored = int(account.balance_micro)
    return {
        "account_id": account.id,
        "user_id": user_id,
        "stored_balance_micro": stored,
        "ledger_sum_micro": int(total or 0),
        "consistent": stored == int(total or 0),
        "difference_micro": stored - int(total or 0),
    }


def ledger_consistency_report(db: Session, limit: int = 500) -> dict:
    accounts = db.scalars(select(CreditAccount).limit(limit)).all()
    rows = []
    inconsistent = 0
    for account in accounts:
        total = db.scalar(
            select(func.coalesce(func.sum(LedgerEntry.amount_micro), 0)).where(LedgerEntry.account_id == account.id)
        )
        if int(total or 0) != int(account.balance_micro):
            inconsistent += 1
            rows.append(
                {
                    "account_id": account.id,
                    "user_id": account.user_id,
                    "stored_micro": int(account.balance_micro),
                    "ledger_micro": int(total or 0),
                }
            )
    return {"accounts_checked": len(accounts), "inconsistent": inconsistent, "rows": rows}
