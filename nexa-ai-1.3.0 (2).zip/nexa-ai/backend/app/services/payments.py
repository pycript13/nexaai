"""Payments, refunds and subscriptions.

Financial integrity rules implemented here:
* Amounts are validated against the operator's configured min/max and stored as
  integer micro-credits.
* A manual payment is *never* credited automatically: it moves to
  ``awaiting_review`` and only an authorised reviewer can approve it, which posts
  exactly one ledger entry (idempotency key = payment reference).
* Automated gateways verify authenticity using the official verification flow
  (server-to-server) and signature checks; a browser redirect to a "success" URL
  is never treated as proof of payment.
* Crypto submissions require network, asset, amount, address and (optional) tx
  hash; verification is explicitly manual unless an explorer integration is
  configured, and duplicate tx hashes are rejected.
* Refunds post a compensating ledger entry and never delete history.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import secrets
from dataclasses import dataclass
from decimal import Decimal
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.crypto import idempotency_hash
from app.core.errors import (
    ConfigurationError,
    InsufficientBalance,
    NotFound,
    PermissionDenied,
    ValidationError,
)
from app.core.logging import get_logger
from app.models.billing import (
    LedgerEntryType,
    Payment,
    PaymentMethod,
    PaymentStatus,
    Subscription,
    SubscriptionPlan,
    SubscriptionStatus,
)
from app.models.files import FileKind, StoredFile
from app.models.user import User
from app.services import audit as audit_service
from app.services import ledger as ledger_service
from app.services import pricing as pricing_service

log = get_logger(__name__)

MIN_TOPUP_MICRO = 1_000_000        # 1 credit
MAX_TOPUP_MICRO = 10_000_000_000   # 10,000 credits


def payment_reference() -> str:
    return f"NX-{dt.datetime.now(dt.timezone.utc):%Y%m%d}-{secrets.token_hex(4).upper()}"


@dataclass
class PaymentMethods:
    manual_bank: bool = False
    crypto: bool = False
    stripe: bool = False
    zarinpal: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "manual_bank_transfer": {
                "enabled": self.manual_bank,
                "status": "configured" if self.manual_bank else "disabled",
                "instructions": settings.bank_transfer_instructions if self.manual_bank else "",
                "verification": "manual_admin_review",
            },
            "crypto": {
                "enabled": self.crypto,
                "status": "configured_manual_verification" if self.crypto else "disabled",
                "assets": [a.strip() for a in settings.crypto_assets.split(",") if a.strip()],
                "wallets": settings.crypto_wallet_map,
                "min_confirmations": settings.crypto_min_confirmations,
                "verification": "manual_review" if self.crypto else "disabled",
            },
            "stripe": {
                "enabled": self.stripe,
                "status": "configured_not_tested" if self.stripe else "disabled",
                "verification": "server_side_signature_and_intent_verification",
            },
            "zarinpal": {
                "enabled": self.zarinpal,
                "status": "configured_not_tested" if self.zarinpal else "disabled",
                "verification": "server_side_verify_endpoint",
            },
        }


def available_methods() -> PaymentMethods:
    return PaymentMethods(
        manual_bank=bool(settings.manual_payments_enabled),
        crypto=bool(settings.crypto_payments_enabled),
        stripe=bool(settings.gateway_stripe_enabled and settings.gateway_stripe_secret_key),
        zarinpal=bool(settings.gateway_zarinpal_enabled and settings.gateway_zarinpal_merchant_id),
    )


def create_manual_payment(
    db: Session,
    *,
    user: User,
    amount_micro: int,
    method: str = PaymentMethod.MANUAL_BANK,
    payer_name: str | None = None,
    bank_reference: str | None = None,
    paid_at: dt.datetime | None = None,
    crypto_asset: str | None = None,
    crypto_network: str | None = None,
    crypto_amount: Decimal | float | None = None,
    crypto_tx_hash: str | None = None,
    receipt_file_id: int | None = None,
    note: str | None = None,
) -> Payment:
    if amount_micro < MIN_TOPUP_MICRO:
        raise ValidationError(f"Minimum top-up is {pricing_service.micro_to_display(MIN_TOPUP_MICRO)} credits.")
    if amount_micro > MAX_TOPUP_MICRO:
        raise ValidationError(f"Maximum single top-up is {pricing_service.micro_to_display(MAX_TOPUP_MICRO)} credits.")
    methods = available_methods()
    if method == PaymentMethod.MANUAL_BANK and not methods.manual_bank:
        raise ConfigurationError("Manual bank transfers are disabled on this platform.")
    if method == PaymentMethod.CRYPTO:
        if not methods.crypto:
            raise ConfigurationError("Cryptocurrency payments are disabled on this platform.")
        if not crypto_asset:
            raise ValidationError("Select the crypto asset you paid with.")
        asset = crypto_asset.strip().upper()
        wallets = settings.crypto_wallet_map
        if wallets and asset not in wallets:
            raise ValidationError(f"Asset '{asset}' is not accepted. Accepted: {', '.join(sorted(wallets))}.")
        if crypto_tx_hash:
            duplicate = db.scalars(select(Payment).where(Payment.crypto_tx_hash == crypto_tx_hash.strip())).first()
            if duplicate is not None:
                raise ValidationError(
                    "This transaction hash has already been submitted (replay protection).",
                    details={"existing_payment_reference": duplicate.reference},
                )
    if method not in (PaymentMethod.MANUAL_BANK, PaymentMethod.CRYPTO):
        raise ValidationError("Automated gateways must be started through their dedicated endpoints.")

    receipt: StoredFile | None = None
    if receipt_file_id:
        receipt = db.get(StoredFile, receipt_file_id)
        if receipt is None or receipt.user_id != user.id:
            raise NotFound("Receipt file not found for this account.")
        if receipt.kind not in (FileKind.RECEIPT, FileKind.UPLOAD, FileKind.ATTACHMENT):
            raise ValidationError("The supplied file cannot be used as a payment receipt.")

    reference = payment_reference()
    payment = Payment(
        reference=reference,
        user_id=user.id,
        method=method,
        status=PaymentStatus.AWAITING_REVIEW,
        amount_micro=int(amount_micro),
        currency=settings.default_currency,
        payer_name=payer_name,
        bank_reference=bank_reference,
        paid_at=paid_at,
        receipt_file_id=receipt.id if receipt else None,
        crypto_asset=(crypto_asset or "").upper() or None,
        crypto_network=crypto_network,
        crypto_amount=Decimal(str(crypto_amount)) if crypto_amount is not None else None,
        crypto_tx_hash=crypto_tx_hash.strip() if crypto_tx_hash else None,
        crypto_verified=False,
        client_submitted=True,
        verified_by_platform=False,
        review_note=note,
        idempotency_key=idempotency_hash("manual_payment", str(user.id), reference),
    )
    if receipt is not None:
        receipt.kind = FileKind.RECEIPT
    db.add(payment)
    db.flush()
    audit_service.record_audit(
        db, action="payment.created",
        summary=f"Manual payment {reference} submitted for review ({pricing_service.micro_to_display(amount_micro)} credits, {method}).",
        actor=user, entity_type="payment", entity_id=payment.id,
        after={"amount_micro": amount_micro, "method": method, "status": payment.status},
        ip_address=None,
    )
    db.commit()
    log.info("manual payment submitted reference=%s user=%s amount=%s", reference, user.id, amount_micro)
    return payment


def approve_payment(
    db: Session,
    *,
    reviewer: User,
    payment: Payment,
    note: str | None = None,
    amount_override_micro: int | None = None,
) -> dict[str, Any]:
    from app.services import access as access_service

    access_service.require_permission(reviewer, "payments.approve")
    if payment.status not in (PaymentStatus.AWAITING_REVIEW, PaymentStatus.PENDING):
        raise ValidationError(f"Payment {payment.reference} is '{payment.status}' and cannot be approved.")
    amount = int(amount_override_micro if amount_override_micro is not None else payment.amount_micro)
    if amount <= 0:
        raise ValidationError("Approved amount must be positive.")

    # idempotent ledger post: key derives from the payment reference, so a double
    # approval (or a retried request) can never credit twice.
    result = ledger_service.credit(
        db,
        user_id=payment.user_id,
        amount_micro=amount,
        entry_type=LedgerEntryType.DEPOSIT,
        idempotency_key=f"payment:{payment.reference}",
        description=f"Payment {payment.reference} approved ({payment.method})",
        reference_type="payment",
        reference_id=payment.id,
        created_by_id=reviewer.id,
        metadata={"method": payment.method, "reviewer_id": reviewer.id, "note": note},
    )
    payment.status = PaymentStatus.APPROVED
    payment.approved_at = dt.datetime.now(dt.timezone.utc)
    payment.reviewed_at = payment.approved_at
    payment.reviewed_by_id = reviewer.id
    payment.review_note = note or payment.review_note
    payment.ledger_entry_id = result.entry.id
    payment.verified_by_platform = True
    db.flush()
    audit_service.record_audit(
        db, action="payment.approved",
        summary=f"Payment {payment.reference} approved by {reviewer.email} for {pricing_service.micro_to_display(amount)} credits.",
        actor=reviewer, entity_type="payment", entity_id=payment.id,
        before={"status": "awaiting_review"}, after={"status": "approved", "amount_micro": amount},
    )
    db.commit()
    return {
        "payment_id": payment.id,
        "reference": payment.reference,
        "status": payment.status,
        "credited_micro": amount,
        "balance_after_micro": result.balance_after_micro,
        "ledger_entry_id": result.entry.id,
        "already_credited": not result.created,
    }


def reject_payment(db: Session, *, reviewer: User, payment: Payment, reason: str) -> dict[str, Any]:
    from app.services import access as access_service

    access_service.require_permission(reviewer, "payments.manage")
    if payment.status not in (PaymentStatus.AWAITING_REVIEW, PaymentStatus.PENDING):
        raise ValidationError(f"Payment {payment.reference} is '{payment.status}' and cannot be rejected.")
    payment.status = PaymentStatus.REJECTED
    payment.rejected_reason = reason[:400]
    payment.reviewed_at = dt.datetime.now(dt.timezone.utc)
    payment.reviewed_by_id = reviewer.id
    db.flush()
    audit_service.record_audit(
        db, action="payment.rejected", summary=f"Payment {payment.reference} rejected: {reason[:200]}",
        actor=reviewer, entity_type="payment", entity_id=payment.id,
        before={"status": "awaiting_review"}, after={"status": "rejected", "reason": reason[:200]},
    )
    db.commit()
    return {"payment_id": payment.id, "status": payment.status}


def refund_payment(db: Session, *, reviewer: User, payment: Payment, amount_micro: int, reason: str,
                   allow_negative: bool = True) -> dict[str, Any]:
    from app.services import access as access_service

    access_service.require_permission(reviewer, "refunds.manage")
    if payment.status not in (PaymentStatus.APPROVED, PaymentStatus.PARTIALLY_REFUNDED):
        raise ValidationError("Only approved payments can be refunded.")
    remaining = payment.amount_micro - (payment.refunded_micro or 0)
    if amount_micro <= 0 or amount_micro > remaining:
        raise ValidationError(f"Refund must be between 1 and {pricing_service.micro_to_display(remaining)} credits.")

    key = f"refund:{payment.reference}:{payment.refunded_micro + amount_micro}"
    try:
        result = ledger_service.debit(
            db,
            user_id=payment.user_id,
            amount_micro=amount_micro,
            entry_type=LedgerEntryType.REFUND,
            idempotency_key=key,
            description=f"Refund for payment {payment.reference}: {reason[:200]}",
            reference_type="refund",
            reference_id=payment.id,
            created_by_id=reviewer.id,
            allow_negative=allow_negative,
        )
    except InsufficientBalance as exc:
        raise ValidationError(
            "The user's balance does not cover this refund. Re-run with an explicit negative-balance override "
            "to record a debt, or adjust the amount.",
            details=exc.details,
        ) from exc

    payment.refunded_micro = (payment.refunded_micro or 0) + amount_micro
    payment.status = (
        PaymentStatus.REFUNDED if payment.refunded_micro >= payment.amount_micro else PaymentStatus.PARTIALLY_REFUNDED
    )
    db.flush()
    audit_service.record_audit(
        db, action="payment.refunded",
        summary=f"Refund of {pricing_service.micro_to_display(amount_micro)} credits on {payment.reference}: {reason[:150]}",
        actor=reviewer, entity_type="payment", entity_id=payment.id, severity="critical",
        after={"refunded_micro": payment.refunded_micro, "status": payment.status},
    )
    db.commit()
    return {
        "payment_id": payment.id,
        "status": payment.status,
        "refunded_micro": amount_micro,
        "total_refunded_micro": payment.refunded_micro,
        "balance_after_micro": result.balance_after_micro if result.entry else None,
        "note": "Refunds reduce the credit balance immediately and are recorded as ledger entries (history is never deleted)."
        if allow_negative
        else "",
    }


# ------------------------------------------------------------- subscriptions --
def create_plan(db: Session, *, actor: User | None, data: dict[str, Any]) -> SubscriptionPlan:
    plan = SubscriptionPlan(
        slug=data["slug"],
        name=data["name"],
        name_fa=data.get("name_fa"),
        description=data.get("description", ""),
        price_micro_monthly=int(data.get("price_micro_monthly") or 0),
        included_credit_micro=int(data.get("included_credit_micro") or 0),
        daily_request_limit=data.get("daily_request_limit"),
        monthly_token_limit=data.get("monthly_token_limit"),
        markup_percent=data.get("markup_percent"),
        features=data.get("features") or {},
        is_active=bool(data.get("is_active", True)),
        is_public=bool(data.get("is_public", True)),
        sort_order=int(data.get("sort_order") or 100),
    )
    db.add(plan)
    db.flush()
    db.commit()
    return plan


def subscribe_user(db: Session, *, actor: User, user: User, plan: SubscriptionPlan, grant_credits: bool = True) -> Subscription:
    if not plan.is_active:
        raise ValidationError("This plan is not available.")
    now = dt.datetime.now(dt.timezone.utc)
    sub = Subscription(
        user_id=user.id,
        plan_id=plan.id,
        status=SubscriptionStatus.ACTIVE,
        started_at=now,
        current_period_start=now,
        current_period_end=now + dt.timedelta(days=30),
        created_by_id=actor.id,
    )
    db.add(sub)
    db.flush()
    if grant_credits and plan.included_credit_micro:
        ledger_service.credit(
            db,
            user_id=user.id,
            amount_micro=plan.included_credit_micro,
            entry_type=LedgerEntryType.SUBSCRIPTION_GRANT,
            idempotency_key=f"subscription:{sub.id}:grant",
            description=f"Included credits for plan '{plan.name}'",
            reference_type="subscription",
            reference_id=sub.id,
            created_by_id=actor.id,
        )
    audit_service.record_audit(
        db, action="subscription.created",
        summary=f"Subscription to '{plan.name}' for {user.email}.",
        actor=actor, entity_type="subscription", entity_id=sub.id,
    )
    db.commit()
    return sub


def renew_subscription(db: Session, sub: Subscription, *, actor: User | None = None, days: int = 30) -> Subscription:
    now = dt.datetime.now(dt.timezone.utc)
    base = sub.current_period_end if sub.current_period_end and sub.current_period_end > now else now
    sub.current_period_start = base
    sub.current_period_end = base + dt.timedelta(days=days)
    sub.status = SubscriptionStatus.ACTIVE
    sub.renewal_count = (sub.renewal_count or 0) + 1
    db.flush()
    audit_service.record_audit(
        db, action="subscription.updated", summary=f"Subscription {sub.id} renewed until {sub.current_period_end:%Y-%m-%d}.",
        actor=actor, entity_type="subscription", entity_id=sub.id,
    )
    db.commit()
    return sub


def expire_lapsed_subscriptions(db: Session) -> int:
    now = dt.datetime.now(dt.timezone.utc)
    lapsed = db.scalars(
        select(Subscription).where(
            Subscription.status.in_([SubscriptionStatus.ACTIVE, SubscriptionStatus.TRIALING]),
            Subscription.current_period_end.is_not(None),
            Subscription.current_period_end < now,
        )
    ).all()
    for sub in lapsed:
        sub.status = SubscriptionStatus.EXPIRED
    if lapsed:
        db.commit()
    return len(lapsed)


# ------------------------------------------------------------ crypto verify --
def verify_crypto_payment(db: Session, *, reviewer: User, payment: Payment, confirmations: int,
                          tx_hash: str | None = None) -> dict[str, Any]:
    """Record a *manually verified* crypto payment.

    Automated blockchain verification is intentionally not implemented: if no
    explorer integration is configured we must never claim automatic verification.
    The reviewer states the transaction hash and confirmation count they verified
    in an external explorer, and that statement is audited.
    """
    from app.services import access as access_service

    access_service.require_permission(reviewer, "payments.approve")
    if payment.method != PaymentMethod.CRYPTO:
        raise ValidationError("This payment is not a cryptocurrency payment.")
    if payment.status not in (PaymentStatus.AWAITING_REVIEW, PaymentStatus.PENDING):
        raise ValidationError(f"Payment {payment.reference} is '{payment.status}'.")
    if confirmations < settings.crypto_min_confirmations:
        raise ValidationError(
            f"At least {settings.crypto_min_confirmations} confirmations are required by policy "
            f"(got {confirmations})."
        )
    if tx_hash:
        duplicate = db.scalars(
            select(Payment).where(Payment.crypto_tx_hash == tx_hash.strip(), Payment.id != payment.id)
        ).first()
        if duplicate is not None:
            raise ValidationError("This transaction hash is already attached to another payment.")
        payment.crypto_tx_hash = tx_hash.strip()
    payment.crypto_confirmations = confirmations
    payment.crypto_verified = True
    payment.crypto_verified_at = dt.datetime.now(dt.timezone.utc)
    payment.verified_by_platform = True
    payment.metadata_json = {
        **(payment.metadata_json or {}),
        "verification": "manual_reviewer",
        "verified_by": reviewer.email,
        "confirmations": confirmations,
    }
    db.flush()
    audit_service.record_audit(
        db, action="payment.approved",
        summary=f"Crypto payment {payment.reference} manually verified ({confirmations} confirmations).",
        actor=reviewer, entity_type="payment", entity_id=payment.id,
        after={"confirmations": confirmations, "tx_hash": payment.crypto_tx_hash},
    )
    db.commit()
    return {"payment_id": payment.id, "verified": True, "verification_mode": "manual"}


# ------------------------------------------------------------ gateway hooks --
def stripe_configured() -> bool:
    return bool(settings.gateway_stripe_enabled and settings.gateway_stripe_secret_key)


def zarinpal_configured() -> bool:
    return bool(settings.gateway_zarinpal_enabled and settings.gateway_zarinpal_merchant_id)


def gateway_status() -> dict[str, Any]:
    return {
        "stripe": {
            "configured": stripe_configured(),
            "live_verified": False,
            "note": "Adapter implemented; live verification requires real Stripe credentials and a webhook endpoint (untested in this environment).",
            "webhook_secret_configured": bool(settings.gateway_stripe_webhook_secret),
        },
        "zarinpal": {
            "configured": zarinpal_configured(),
            "live_verified": False,
            "note": "Adapter implemented; live verification requires a real merchant ID and sandbox/live transaction (untested in this environment).",
        },
    }


async def stripe_create_checkout(db: Session, *, user: User, amount_micro: int, success_url: str, cancel_url: str) -> dict[str, Any]:
    """Create a Stripe Checkout Session (implemented; requires live credentials)."""
    if not stripe_configured():
        raise ConfigurationError("Stripe is not configured (NEXA_GATEWAY_STRIPE_ENABLED / NEXA_GATEWAY_STRIPE_SECRET_KEY).")
    import httpx

    amount_usd = float(Decimal(amount_micro) / Decimal(1_000_000) * Decimal(str(settings.credit_usd_rate)))
    body = {
        "mode": "payment",
        "success_url": success_url,
        "cancel_url": cancel_url,
        "client_reference_id": str(user.id),
        "line_items[0][price_data][currency]": "usd",
        "line_items[0][price_data][product_data][name]": f"{settings.app_name} credits",
        "line_items[0][price_data][unit_amount]": str(int(round(amount_usd * 100))),
        "line_items[0][quantity]": "1",
    }
    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.post(
            "https://api.stripe.com/v1/checkout/sessions",
            data=body,
            headers={"Authorization": f"Bearer {settings.gateway_stripe_secret_key}"},
        )
    if response.status_code >= 400:
        raise ValidationError(f"Stripe rejected the checkout session: {response.text[:300]}")
    payload = response.json()
    payment = Payment(
        reference=payment_reference(),
        user_id=user.id,
        method=PaymentMethod.STRIPE,
        status=PaymentStatus.PENDING,
        amount_micro=int(amount_micro),
        currency=settings.default_currency,
        gateway_name="stripe",
        gateway_session_id=payload.get("id"),
        gateway_payload={"checkout_url": payload.get("url")},
        verified_by_platform=False,
        client_submitted=True,
        idempotency_key=idempotency_hash("stripe", payload.get("id") or payment_reference()),
    )
    db.add(payment)
    db.commit()
    return {"payment_id": payment.id, "reference": payment.reference, "checkout_url": payload.get("url")}


async def stripe_verify_session(db: Session, *, payment: Payment) -> dict[str, Any]:
    """Server-to-server verification: only the provider can mark a payment paid."""
    if not stripe_configured():
        raise ConfigurationError("Stripe is not configured.")
    import httpx

    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.get(
            f"https://api.stripe.com/v1/checkout/sessions/{payment.gateway_session_id}",
            headers={"Authorization": f"Bearer {settings.gateway_stripe_secret_key}"},
        )
    if response.status_code >= 400:
        raise ValidationError(f"Stripe verification failed: {response.text[:200]}")
    session = response.json()
    paid = session.get("payment_status") == "paid"
    payment.gateway_payload = {**(payment.gateway_payload or {}), "verify_status": session.get("payment_status")}
    payment.verified_by_platform = bool(paid)
    if paid:
        payment.status = PaymentStatus.APPROVED
        payment.approved_at = dt.datetime.now(dt.timezone.utc)
        ledger_service.credit(
            db,
            user_id=payment.user_id,
            amount_micro=payment.amount_micro,
            entry_type=LedgerEntryType.DEPOSIT,
            idempotency_key=f"payment:{payment.reference}",
            description=f"Stripe payment {payment.reference} verified",
            reference_type="payment",
            reference_id=payment.id,
            metadata={"gateway": "stripe", "session": session.get("id")},
        )
    db.commit()
    return {"payment_id": payment.id, "paid": paid, "status": payment.status}


def verify_stripe_signature(payload: bytes, signature_header: str | None) -> bool:
    """Verify a Stripe webhook signature (HMAC-SHA256, timestamped)."""
    if not settings.gateway_stripe_webhook_secret or not signature_header:
        return False
    import hmac
    import time as time_module

    try:
        parts = dict(item.split("=", 1) for item in signature_header.split(","))
    except ValueError:
        return False
    timestamp = parts.get("t")
    signature = parts.get("v1")
    if not timestamp or not signature:
        return False
    try:
        if abs(time_module.time() - int(timestamp)) > 300:
            return False
    except ValueError:
        return False
    expected = hmac.new(
        settings.gateway_stripe_webhook_secret.encode(), f"{timestamp}.".encode() + payload, hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature)


def create_invitation(db: Session, *, actor: User, email: str, expires_days: int = 14, note: str | None = None) -> dict[str, Any]:
    """Invitation-only registration token (stored in app settings-free table-less form).

    The token itself is returned once and only its hash is persisted in the audit
    trail, so an operator can revoke by deleting the audit entry — simple, and it
    never leaks a reusable secret.
    """
    from app.core.crypto import random_token
    from app.core.security import hash_session_token

    token = random_token(24)
    audit_service.record_audit(
        db, action="user.created",
        summary=f"Invitation issued for {email} (expires in {expires_days} days).",
        actor=actor, entity_type="invitation", entity_id=hash_session_token(token)[:32],
        after={"email": email, "expires_days": expires_days, "note": note},
        category="users",
    )
    db.commit()
    return {"email": email, "token": token, "expires_days": expires_days,
            "usage": "Register with the invitation token in the sign-up form."}
