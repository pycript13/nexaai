"""Backup inventory — what the bundled backup script actually wrote to disk.

The admin console must never *invent* a backup. Every row returned here corresponds to a
real file in the backup directory, and ``verified`` only reports verification this platform
performed: ``scripts/verify_backup.sh`` runs after every dump, and it writes a
``<file>.meta.json`` sidecar (plus a ``<file>.sha256``) next to the backup. A file without
that record — one copied in by hand, or produced by an older release — is reported as *not
verified* instead of being presented as a healthy backup.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
from pathlib import Path
from typing import Any

BACKUP_PREFIXES = ("nexa-pg-", "nexa-sqlite-", "nexa-uploads-")
PARTIAL_SUFFIX = ".partial"
META_SUFFIX = ".meta.json"
RESTORE_NOTE = (
    "Restore with scripts/restore.sh <file> (PostgreSQL) or by replacing data/nexa.db "
    "(SQLite); scripts/restore_drill.sh performs a full verified restore. See docs/BACKUP_RESTORE.md."
)


def backup_directory(app_root: Path) -> Path:
    """The directory ``scripts/backup.sh`` writes into (``<app>/backups``)."""
    return app_root / "backups"


def _is_backup_file(name: str) -> bool:
    if ".meta.json" in name or name.endswith(".sha256"):
        return False
    return name.startswith(BACKUP_PREFIXES)


def sha256_of(path: Path, *, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            block = handle.read(chunk_size)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def read_sidecar(path: Path) -> dict[str, Any]:
    sidecar = path.with_name(path.name + META_SUFFIX)
    if not sidecar.exists():
        return {}
    try:
        data = json.loads(sidecar.read_text())
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def write_sidecar(path: Path, *, database: str, extra: dict[str, Any] | None = None) -> Path:
    """Record the verification result next to a backup file.

    Kept in Python so the *tests* exercise exactly the format the shell script writes
    (``scripts/backup.sh`` emits the same JSON through ``printf``).
    """
    stat = path.stat()
    payload: dict[str, Any] = {
        "file": path.name,
        "size_bytes": stat.st_size,
        "sha256": sha256_of(path),
        "verified": True,
        "verified_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "verifier": "scripts/verify_backup.sh",
        "database": database,
    }
    if extra:
        payload.update(extra)
    sidecar = path.with_name(path.name + META_SUFFIX)
    sidecar.write_text(json.dumps(payload, indent=2) + "\n")
    return sidecar


def _iso(timestamp: float) -> str:
    return dt.datetime.fromtimestamp(timestamp, tz=dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def describe(path: Path) -> dict[str, Any]:
    """One inventory row for one file on disk."""
    stat = path.stat()
    partial = path.name.endswith(PARTIAL_SUFFIX)
    meta = read_sidecar(path)
    size_matches = bool(meta) and meta.get("size_bytes") == stat.st_size
    verified = bool(meta.get("verified")) and size_matches and not partial
    notes: str | None = None
    if partial:
        notes = "Incomplete: the backup script was interrupted before the file was finalised."
    elif not meta:
        notes = "No verification record next to this file — it was not produced by the bundled backup script (or predates it)."
    elif not size_matches:
        notes = "The file changed after verification — checksum recorded in the sidecar no longer describes it."
    return {
        "id": path.name,
        "filename": path.name,
        "size_bytes": stat.st_size,
        "status": "incomplete" if partial else "completed",
        "created_at": _iso(stat.st_mtime),
        "verified": verified,
        "sha256": meta.get("sha256"),
        "verified_at": meta.get("verified_at"),
        "notes": notes,
    }


def list_backups(directory: Path) -> dict[str, Any]:
    """Inventory of every backup file in ``directory`` (never a fabricated row)."""
    directory = Path(directory)
    items: list[dict[str, Any]] = []
    if directory.is_dir():
        for path in sorted(directory.iterdir()):
            if path.is_file() and _is_backup_file(path.name):
                try:
                    items.append(describe(path))
                except OSError:  # pragma: no cover - file disappeared mid-scan
                    continue
    items.sort(key=lambda item: item["created_at"], reverse=True)
    verified_at = [item["verified_at"] for item in items if item.get("verified_at")]
    return {
        "items": items,
        "directory": str(directory),
        "count": len(items),
        "total_bytes": sum(item["size_bytes"] for item in items),
        "last_verified": max(verified_at) if verified_at else None,
        "restore_note": RESTORE_NOTE,
    }
