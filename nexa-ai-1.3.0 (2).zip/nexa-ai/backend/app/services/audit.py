"""Audit trail + user-visible activity history."""
from __future__ import annotations

from typing import Any

from sqlalchemy.orm import Session

from app.core.logging import REQUEST_ID, USER_ID, get_logger
from app.models.admin import AuditEvent
from app.models.user import User, UserActivity

log = get_logger(__name__)

# Actions that must always be audited (used by tests + docs).
AUDITED_ACTIONS = {
    "auth.login": ("security", "info"),
    "auth.login_failed": ("security", "warning"),
    "auth.logout": ("security", "info"),
    "auth.register": ("security", "notice"),
    "auth.password_reset_requested": ("security", "notice"),
    "auth.password_reset_completed": ("security", "warning"),
    "auth.email_verified": ("security", "notice"),
    "auth.session_revoked": ("security", "notice"),
    "user.created": ("users", "notice"),
    "user.updated": ("users", "notice"),
    "user.suspended": ("users", "warning"),
    "user.reactivated": ("users", "notice"),
    "user.deleted": ("users", "critical"),
    "user.roles_changed": ("users", "warning"),
    "user.credits_adjusted": ("finance", "warning"),
    "provider.created": ("providers", "notice"),
    "provider.updated": ("providers", "notice"),
    "provider.credentials_rotated": ("providers", "critical"),
    "provider.deleted": ("providers", "critical"),
    "provider.enabled": ("providers", "notice"),
    "provider.disabled": ("providers", "warning"),
    "provider.tested": ("providers", "info"),
    "provider.synced": ("providers", "notice"),
    "model.created": ("models", "notice"),
    "model.updated": ("models", "notice"),
    "model.deleted": ("models", "critical"),
    "model.published": ("models", "notice"),
    "model.unpublished": ("models", "warning"),
    "model.enabled": ("models", "notice"),
    "model.disabled": ("models", "warning"),
    "model.tested": ("models", "info"),
    "model.bulk_updated": ("models", "warning"),
    "model.grant_created": ("models", "notice"),
    "model.grant_revoked": ("models", "notice"),
    "payment.created": ("finance", "notice"),
    "payment.approved": ("finance", "warning"),
    "payment.rejected": ("finance", "warning"),
    "payment.refunded": ("finance", "critical"),
    "subscription.created": ("finance", "notice"),
    "subscription.updated": ("finance", "notice"),
    "pricing.updated": ("finance", "warning"),
    "settings.updated": ("system", "warning"),
    "backup.requested": ("system", "notice"),
    "file.uploaded": ("files", "info"),
    "file.deleted": ("files", "info"),
    "job.cancelled": ("jobs", "notice"),
}


def record_audit(
    db: Session,
    *,
    action: str,
    summary: str,
    actor: User | None = None,
    entity_type: str | None = None,
    entity_id: str | int | None = None,
    before: dict[str, Any] | None = None,
    after: dict[str, Any] | None = None,
    ip_address: str | None = None,
    user_agent: str | None = None,
    severity: str | None = None,
    category: str | None = None,
    commit: bool = False,
) -> AuditEvent:
    default_category, default_severity = AUDITED_ACTIONS.get(action, ("general", "info"))
    event = AuditEvent(
        action=action,
        category=category or default_category,
        severity=severity or default_severity,
        actor_user_id=actor.id if actor else None,
        actor_email=actor.email if actor else None,
        actor_role=",".join(sorted(r.slug for r in actor.roles)) if actor and actor.roles else None,
        entity_type=entity_type,
        entity_id=str(entity_id) if entity_id is not None else None,
        summary=summary[:400],
        before_state=_sanitize(before),
        after_state=_sanitize(after),
        ip_address=ip_address,
        user_agent=(user_agent or "")[:400] or None,
        request_id=REQUEST_ID.get(),
    )
    db.add(event)
    if commit:
        db.commit()
    log.info("audit action=%s entity=%s/%s actor=%s", action, entity_type, entity_id, actor.email if actor else "-")
    return event


SENSITIVE_KEYS = {
    "password", "new_password", "current_password", "api_key", "api_key_encrypted", "secret",
    "token", "session_token", "authorization", "credential", "private_key", "client_secret", "receipt",
}


def _sanitize(data: dict[str, Any] | None) -> dict[str, Any] | None:
    if not data:
        return None
    out: dict[str, Any] = {}
    for key, value in data.items():
        if key.lower() in SENSITIVE_KEYS or any(marker in key.lower() for marker in ("password", "secret", "token", "key")):
            out[key] = "***redacted***"
        elif isinstance(value, dict):
            out[key] = _sanitize(value)
        elif isinstance(value, (str, int, float, bool, type(None), list)):
            out[key] = value
        else:
            out[key] = str(value)
    return out


def record_activity(
    db: Session,
    *,
    user: User,
    event: str,
    description: str = "",
    ip_address: str | None = None,
    user_agent: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> UserActivity:
    activity = UserActivity(
        user_id=user.id,
        event=event,
        description=description[:400],
        ip_address=ip_address,
        user_agent=(user_agent or "")[:400] or None,
        metadata_json=metadata,
    )
    db.add(activity)
    return activity
