"""Transactional email.

Status is explicit: when SMTP is not configured, ``is_configured()`` is False and
every send returns False — the platform never claims that a verification or reset
email was delivered when it was not.
"""
from __future__ import annotations

import smtplib
import ssl
from email.message import EmailMessage

from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.logging import get_logger
from app.models.user import User

log = get_logger(__name__)


def is_configured() -> bool:
    return bool(settings.email_enabled and settings.smtp_host)


def status() -> dict:
    return {
        "enabled": is_configured(),
        "host": settings.smtp_host or None,
        "port": settings.smtp_port if is_configured() else None,
        "starttls": settings.smtp_starttls,
        "from_address": settings.email_from if is_configured() else None,
        "require_email_verification": bool(settings.require_email_verification and is_configured()),
        "note": None if is_configured() else "SMTP is not configured: verification/reset emails are disabled.",
    }


def send_email(*, to: str, subject: str, body: str) -> bool:
    if not is_configured():
        log.warning("Email delivery requested but SMTP is not configured (to=%s subject=%s)", to, subject)
        return False
    message = EmailMessage()
    message["From"] = settings.email_from
    message["To"] = to
    message["Subject"] = subject
    message.set_content(body)
    try:
        if settings.smtp_port == 465:
            with smtplib.SMTP_SSL(settings.smtp_host, settings.smtp_port, timeout=20, context=ssl.create_default_context()) as client:
                if settings.smtp_username:
                    client.login(settings.smtp_username, settings.smtp_password)
                client.send_message(message)
        else:
            with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=20) as client:
                if settings.smtp_starttls:
                    client.starttls(context=ssl.create_default_context())
                if settings.smtp_username:
                    client.login(settings.smtp_username, settings.smtp_password)
                client.send_message(message)
        log.info("email sent to=%s subject=%s", to, subject)
        return True
    except Exception as exc:  # noqa: BLE001
        log.error("email delivery failed to=%s subject=%s error=%s", to, subject, exc)
        return False


def base_url() -> str:
    return settings.public_base_url.rstrip("/")


def send_verification_email(db: Session, *, user: User) -> bool:  # noqa: ARG001 - db kept for future templates
    from app.core.security import create_action_token

    token = create_action_token(str(user.id), "email_verify", ttl_minutes=60 * 24 * 3)
    link = f"{base_url()}/verify-email?token={token}"
    return send_email(
        to=user.email,
        subject=f"Verify your {settings.app_name} email address",
        body=(
            f"Hello {user.display_name},\n\n"
            f"Welcome to {settings.app_name}. Please confirm your email address by opening:\n\n{link}\n\n"
            "This link expires in 3 days. If you did not create this account you can ignore this message.\n"
        ),
    )


def send_password_reset_email(db: Session, *, user: User, token: str) -> bool:  # noqa: ARG001
    link = f"{base_url()}/reset-password?token={token}"
    return send_email(
        to=user.email,
        subject=f"Reset your {settings.app_name} password",
        body=(
            f"Hello {user.display_name},\n\n"
            f"A password reset was requested for your account. Open this link to choose a new password:\n\n{link}\n\n"
            "The link expires in 30 minutes. If you did not request it, no action is needed and your password stays unchanged.\n"
        ),
    )


def send_admin_notification(*, subject: str, body: str, to: str | None = None) -> bool:
    recipient = to or settings.bootstrap_admin_email
    if not recipient:
        return False
    return send_email(to=recipient, subject=f"[{settings.app_name}] {subject}", body=body)
