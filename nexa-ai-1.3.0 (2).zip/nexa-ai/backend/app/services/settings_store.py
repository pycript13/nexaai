"""Runtime-editable settings (stored in ``app_settings``).

Two kinds of value live here:

* **ordinary** settings — stored as ``{"value": ...}`` JSON, returned by the admin API;
* **secret** settings (``is_secret``) — a bot token, a gateway secret, a webhook key.  They are
  encrypted with ``NEXA_ENCRYPTION_KEY`` (Fernet) before they touch the database, are never
  returned by any endpoint, and are read back only by the service that needs them.

Why this exists: connecting the Telegram bot used to require editing ``.env`` on the server and
restarting it — the admin panel had no field for the token because the settings table only held
non-secret values.  Operators work in a browser; the platform should meet them there.

Precedence is always **database → environment**: a token entered in the panel wins over the one in
``.env`` (so an operator can rotate it without shell access), and clearing it falls back to the
environment value rather than breaking the bot silently.
"""
from __future__ import annotations

import datetime as dt
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.crypto import decrypt_secret, encrypt_secret, mask_secret
from app.models.admin import AppSetting
from app.services import audit as audit_service


def _row(db: Session, key: str) -> AppSetting | None:
    return db.scalars(select(AppSetting).where(AppSetting.key == key)).first()


def get_value(db: Session, key: str, default: Any = None) -> Any:
    row = _row(db, key)
    if row is None or row.value_json is None:
        return default
    if isinstance(row.value_json, dict) and "value" in row.value_json:
        return row.value_json["value"]
    return row.value_json


def set_value(db: Session, key: str, value: Any, *, actor=None, commit: bool = True) -> AppSetting:  # noqa: ANN001
    row = _row(db, key)
    before = get_value(db, key)
    if row is None:
        row = AppSetting(key=key, value_json={"value": value}, category="general", label=key)
        db.add(row)
    else:
        row.value_json = {"value": value}
        row.is_secret = False
    row.updated_by_id = actor.id if actor else None
    row.updated_at = dt.datetime.now(dt.timezone.utc)
    db.flush()
    audit_service.record_audit(
        db, action="settings.updated", summary=f"Setting '{key}' updated.",
        actor=actor, entity_type="setting", entity_id=key, before={"value": _safe(before)}, after={"value": _safe(value)},
    )
    if commit:
        db.commit()
    return row


# ------------------------------------------------------------------ secrets ----
def set_secret(
    db: Session,
    key: str,
    plaintext: str,
    *,
    actor=None,  # noqa: ANN001
    category: str = "security",
    label: str = "",
    description: str = "",
    commit: bool = True,
) -> AppSetting:
    """Store (or replace) an encrypted secret. The audit row records **that** it changed, never what."""
    stored = encrypt_secret(plaintext)
    row = _row(db, key)
    existed = row is not None and bool(get_secret(db, key))
    if row is None:
        row = AppSetting(key=key, category=category, label=label or key, description=description)
        db.add(row)
    row.value_json = {"secret": stored}
    row.value_type = "secret"
    row.is_secret = True
    row.is_public = False
    if label:
        row.label = label
    if description:
        row.description = description
    row.updated_by_id = actor.id if actor else None
    row.updated_at = dt.datetime.now(dt.timezone.utc)
    db.flush()
    audit_service.record_audit(
        db, action="settings.secret_updated",
        summary=f"Secret setting '{key}' {'replaced' if existed else 'stored'} (value never logged).",
        actor=actor, entity_type="setting", entity_id=key,
        before={"has_value": existed}, after={"has_value": True, "hint": mask_secret(plaintext)},
    )
    if commit:
        db.commit()
    return row


def get_secret(db: Session, key: str, default: str = "") -> str:
    row = _row(db, key)
    if row is None or row.value_json is None:
        return default
    payload = row.value_json
    if isinstance(payload, dict) and "secret" in payload:
        return decrypt_secret(str(payload["secret"])) or default
    if isinstance(payload, dict) and payload.get("secret") is None:
        return default
    return default


def clear_secret(db: Session, key: str, *, actor=None, commit: bool = True) -> bool:  # noqa: ANN001
    """Remove a stored secret. Returns True when something was removed."""
    row = _row(db, key)
    if row is None or not row.is_secret:
        return False
    had_value = bool(get_secret(db, key))
    row.value_json = None
    row.is_secret = True
    row.updated_by_id = actor.id if actor else None
    row.updated_at = dt.datetime.now(dt.timezone.utc)
    db.flush()
    audit_service.record_audit(
        db, action="settings.secret_cleared", summary=f"Secret setting '{key}' cleared.",
        actor=actor, entity_type="setting", entity_id=key, before={"has_value": had_value}, after={"has_value": False},
    )
    if commit:
        db.commit()
    return had_value


def secret_status(db: Session, key: str) -> dict[str, Any]:
    """What the UI may know about a secret: whether one exists, and a masked hint."""
    row = _row(db, key)
    if row is None or not row.is_secret:
        return {"key": key, "configured": False, "hint": "", "updated_at": None, "source": "none"}
    value = get_secret(db, key)
    return {
        "key": key,
        "configured": bool(value),
        "hint": mask_secret(value) if value else "",
        "updated_at": row.updated_at,
        "source": "database" if value else "none",
    }


def _safe(value: Any) -> Any:
    """Render a value for the **audit log**: never long, never a secret, never a crash.

    The previous version called ``str(value)`` and then sliced ``value`` — so any non-string (or
    ``None``) raised ``TypeError: 'NoneType' object is not subscriptable`` inside an audit write, and
    the whole request failed with a 500. Saving a Telegram bot token hit exactly that.
    """
    if value is None:
        return None
    if isinstance(value, bool) or isinstance(value, (int, float)):
        return value
    if isinstance(value, str):
        if any(marker in value.lower() for marker in ("password", "secret", "key=", "token", "bearer ")):
            return "***redacted***"
        return value[:200]
    if isinstance(value, dict):
        if {"secret", "encrypted", "ciphertext"} & set(value):
            return "***encrypted***"
        return {str(key): _safe(item) for key, item in list(value.items())[:12]}
    if isinstance(value, (list, tuple)):
        return [_safe(item) for item in list(value)[:12]]
    return str(value)[:200]


#: Setting keys that exist for internal bookkeeping only. They live in the same table because it is
#: convenient, but they are not configuration: showing them in Admin → Settings (as `{"expires_at":
#: …}` blobs) made the screen look broken and buried the settings that matter.
INTERNAL_SETTING_PREFIXES = ("telegram.link_code.", "telegram.session.")


def is_internal_setting(key: str) -> bool:
    return key.startswith(INTERNAL_SETTING_PREFIXES)


def all_settings(db: Session, *, public_only: bool = False) -> list[dict[str, Any]]:
    stmt = select(AppSetting).order_by(AppSetting.category, AppSetting.key)
    if public_only:
        stmt = stmt.where(AppSetting.is_public.is_(True))
    items: list[dict[str, Any]] = []
    for row in db.scalars(stmt).all():
        if is_internal_setting(row.key):
            continue
        if row.is_secret:
            value = get_secret(db, row.key)
            # The value is never returned. The panel renders its own editor for each secret, so the
            # generic table shows a hint instead of a `null` box the operator cannot use.
            items.append(
                {
                    "key": row.key,
                    "value": None,
                    "category": row.category,
                    "label": row.label,
                    "description": row.description,
                    "is_public": False,
                    "is_secret": True,
                    "has_value": bool(value),
                    "masked": mask_secret(value) if value else "",
                    "updated_at": row.updated_at,
                }
            )
            continue
        items.append(
            {
                "key": row.key,
                "value": get_value(db, row.key),
                "category": row.category,
                "label": row.label,
                "description": row.description,
                "is_public": row.is_public,
                "is_secret": False,
                "updated_at": row.updated_at,
            }
        )
    return items


def public_settings(db: Session) -> dict[str, Any]:
    return {item["key"]: item["value"] for item in all_settings(db, public_only=True)}
