"""Model variants — a *named way of using* a model, not a separate model.

A variant lives under a parent model and carries its own system prompt and generation
defaults, so one upstream model (say a DeepSeek chat model) can appear in the workspace as
several purposeful assistants: "Chat", "Code generator", "Persian copywriter" — each one
switchable on or off, each one audited, none of them able to escape the parent model's
pricing, access tier or availability rules.

Design rules that mirror the rest of the platform:

* a variant **never** changes which upstream model is called or what it costs — billing
  always resolves to the parent model;
* a variant is only advertised to a user when its parent model is itself usable and the
  variant is enabled and visible to that user (``scope='system'`` for everyone with access
  to the model, ``scope='personal'`` for its owner only);
* the system prompt is data, not code: it is sent as the system message of the chat request
  and is visible to the user who is using it (no hidden instructions);
* disabling a variant is immediate and does not touch the parent model.
"""
from __future__ import annotations

import re
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.errors import NotFound, PermissionDenied, ValidationError
from app.models.provider import Model, ModelVariant
from app.models.user import User
from app.services import audit as audit_service

SCOPES = ("system", "personal")
MAX_SYSTEM_PROMPT = 8000


def _slugify(value: str) -> str:
    cleaned = re.sub(r"[^a-z0-9]+", "-", value.strip().lower()).strip("-")
    return (cleaned or "variant")[:48]


def unique_slug(db: Session, model_id: int, base: str) -> str:
    slug = _slugify(base)
    candidate, index = slug, 2
    while db.scalars(select(ModelVariant).where(ModelVariant.model_id == model_id, ModelVariant.slug == candidate)).first():
        candidate = f"{slug[:40]}-{index}"
        index += 1
    return candidate


PRICING_FIELDS = ("selling_input_per_mtok", "selling_output_per_mtok", "selling_per_request")


def validate_payload(data: dict[str, Any], *, partial: bool = False, allow_pricing: bool = False) -> dict[str, Any]:
    cleaned: dict[str, Any] = {}
    if not partial or "name" in data:
        name = str(data.get("name") or "").strip()
        if not name:
            raise ValidationError("A variant name is required (for example: 'Code generator').")
        if len(name) > 120:
            raise ValidationError("The variant name is too long (120 characters max).")
        cleaned["name"] = name
    if not partial or "system_prompt" in data:
        prompt = str(data.get("system_prompt") or "")
        if len(prompt) > MAX_SYSTEM_PROMPT:
            raise ValidationError(f"The system prompt is too long ({MAX_SYSTEM_PROMPT} characters max).")
        cleaned["system_prompt"] = prompt
    if "description" in data:
        cleaned["description"] = str(data.get("description") or "")[:400]
    if "emoji" in data:
        cleaned["emoji"] = str(data.get("emoji") or "")[:8]
    for field, caster, low, high in (
        ("default_temperature", float, 0.0, 2.0),
        ("default_top_p", float, 0.0, 1.0),
    ):
        if field in data and data[field] is not None:
            value = caster(data[field])
            if not low <= value <= high:
                raise ValidationError(f"{field} must be between {low} and {high}.")
            cleaned[field] = value
    if "default_max_tokens" in data and data["default_max_tokens"] is not None:
        value = int(data["default_max_tokens"])
        if not 1 <= value <= 200000:
            raise ValidationError("default_max_tokens must be between 1 and 200000.")
        cleaned["default_max_tokens"] = value
    if "sort_order" in data and data["sort_order"] is not None:
        cleaned["sort_order"] = int(data["sort_order"])
    for flag in ("enabled", "is_default"):
        if flag in data and data[flag] is not None:
            cleaned[flag] = bool(data[flag])
    if "scope" in data and data["scope"] is not None:
        scope = str(data["scope"])
        if scope not in SCOPES:
            raise ValidationError(f"scope must be one of {', '.join(SCOPES)}.")
        cleaned["scope"] = scope
    # Per-variant prices are an operator privilege: a personal variant must
    # never become a way for its owner to pay less than the parent model's price.
    if allow_pricing:
        for field in PRICING_FIELDS:
            if field in data:
                value = data[field]
                if value is not None and float(value) < 0:
                    raise ValidationError(f"{field} cannot be negative.")
                cleaned[field] = float(value) if value is not None else None
    return cleaned


def serialize(variant: ModelVariant, *, model: Model | None = None, prompts_visible: bool = True) -> dict[str, Any]:
    data = {
        "id": variant.id,
        "model_id": variant.model_id,
        "slug": variant.slug,
        "name": variant.name,
        "description": variant.description or "",
        "emoji": variant.emoji or "",
        "enabled": bool(variant.enabled),
        "is_default": bool(variant.is_default),
        "scope": variant.scope,
        "sort_order": variant.sort_order,
        "owner_user_id": variant.owner_user_id,
        "default_temperature": float(variant.default_temperature) if variant.default_temperature is not None else None,
        "default_top_p": float(variant.default_top_p) if variant.default_top_p is not None else None,
        "default_max_tokens": variant.default_max_tokens,
        "has_system_prompt": bool(variant.system_prompt),
        "system_prompt": (variant.system_prompt or "") if prompts_visible else None,
        "system_prompt_chars": len(variant.system_prompt or ""),
        "selling_input_per_mtok": float(variant.selling_input_per_mtok) if variant.selling_input_per_mtok is not None else None,
        "selling_output_per_mtok": float(variant.selling_output_per_mtok) if variant.selling_output_per_mtok is not None else None,
        "selling_per_request": float(variant.selling_per_request) if variant.selling_per_request is not None else None,
        "usage_count": variant.usage_count or 0,
        "last_used_at": variant.last_used_at,
        "created_at": variant.created_at,
        "updated_at": variant.updated_at,
    }
    if model is not None:
        data["model"] = {
            "id": model.id,
            "display_name": model.display_name,
            "provider_model_id": model.provider_model_id,
            "availability": model.availability,
            "visibility": model.visibility,
        }
    return data


def get_variant(db: Session, variant_id: int) -> ModelVariant:
    variant = db.get(ModelVariant, variant_id)
    if variant is None:
        raise NotFound("Model variant not found.")
    return variant


def list_variants(
    db: Session,
    *,
    model_id: int | None = None,
    actor: User | None = None,
    include_disabled: bool = False,
    include_personal_of_others: bool = False,
) -> list[ModelVariant]:
    query = select(ModelVariant)
    if model_id is not None:
        query = query.where(ModelVariant.model_id == model_id)
    variants = list(db.scalars(query.order_by(ModelVariant.sort_order, ModelVariant.id)).all())
    if include_disabled and include_personal_of_others:
        return variants
    actor_id = actor.id if actor else None
    visible = []
    for variant in variants:
        if not include_disabled and not variant.enabled:
            continue
        if variant.scope == "personal" and variant.owner_user_id not in (None, actor_id):
            continue
        visible.append(variant)
    return visible


def create_variant(db: Session, *, actor: User, model: Model, data: dict[str, Any], allow_system_scope: bool) -> ModelVariant:
    cleaned = validate_payload(data, allow_pricing=allow_system_scope)
    scope = cleaned.pop("scope", "personal")
    if scope == "system" and not allow_system_scope:
        raise PermissionDenied("Only administrators can create workspace-wide variants.")
    is_default = bool(cleaned.pop("is_default", False))
    if is_default:
        _clear_default(db, model_id=model.id)
    variant = ModelVariant(
        model_id=model.id,
        slug=unique_slug(db, model.id, cleaned.get("name") or "variant"),
        name=cleaned["name"],
        description=cleaned.get("description", ""),
        emoji=cleaned.get("emoji", ""),
        system_prompt=cleaned.get("system_prompt", ""),
        default_temperature=cleaned.get("default_temperature"),
        default_top_p=cleaned.get("default_top_p"),
        default_max_tokens=cleaned.get("default_max_tokens"),
        enabled=bool(cleaned.get("enabled", True)),
        scope=scope,
        owner_user_id=None if scope == "system" else actor.id,
        sort_order=int(cleaned.get("sort_order", 100)),
        selling_input_per_mtok=cleaned.get("selling_input_per_mtok"),
        selling_output_per_mtok=cleaned.get("selling_output_per_mtok"),
        selling_per_request=cleaned.get("selling_per_request"),
        is_default=is_default,
        created_by_id=actor.id,
        updated_by_id=actor.id,
    )
    db.add(variant)
    db.flush()
    audit_service.record_audit(
        db,
        action="model_variant.created",
        summary=f"Variant '{variant.name}' created for model '{model.display_name}' (scope={scope}, system prompt: "
                f"{'yes' if variant.system_prompt else 'no'}).",
        actor=actor,
        entity_type="model_variant",
        entity_id=variant.id,
        after={"name": variant.name, "model_id": model.id, "scope": scope, "enabled": variant.enabled,
               "system_prompt_chars": len(variant.system_prompt or "")},
    )
    db.commit()
    return variant


def update_variant(db: Session, *, actor: User, variant: ModelVariant, data: dict[str, Any], allow_system_scope: bool) -> ModelVariant:
    if variant.scope == "personal" and variant.owner_user_id not in (None, actor.id) and not allow_system_scope:
        raise PermissionDenied("This personal variant belongs to another account.")
    cleaned = validate_payload(data, partial=True, allow_pricing=allow_system_scope)
    before = {
        "name": variant.name,
        "enabled": variant.enabled,
        "system_prompt_chars": len(variant.system_prompt or ""),
        "scope": variant.scope,
    }
    if "scope" in cleaned:
        scope = cleaned.pop("scope")
        if scope == "system" and not allow_system_scope:
            raise PermissionDenied("Only administrators can publish a variant to the whole workspace.")
        variant.scope = scope
        variant.owner_user_id = None if scope == "system" else actor.id
    if cleaned.pop("is_default", None):
        _clear_default(db, model_id=variant.model_id)
        variant.is_default = True
    for field in ("name", "description", "emoji", "system_prompt", "default_temperature", "default_top_p",
                  "default_max_tokens", "sort_order", *PRICING_FIELDS):
        if field in cleaned:
            setattr(variant, field, cleaned[field])
    if "enabled" in cleaned:
        variant.enabled = bool(cleaned["enabled"])
    variant.updated_by_id = actor.id
    audit_service.record_audit(
        db,
        action="model_variant.updated",
        summary=f"Variant '{variant.name}' updated (enabled={variant.enabled}).",
        actor=actor,
        entity_type="model_variant",
        entity_id=variant.id,
        before=before,
        after={"name": variant.name, "enabled": variant.enabled,
               "system_prompt_chars": len(variant.system_prompt or ""), "scope": variant.scope,
               "changed": sorted(set(cleaned) | ({"scope"} if "scope" in data else set()))},
    )
    db.commit()
    return variant


def delete_variant(db: Session, *, actor: User, variant: ModelVariant, allow_system_scope: bool) -> None:
    if variant.scope == "personal" and variant.owner_user_id not in (None, actor.id) and not allow_system_scope:
        raise PermissionDenied("This personal variant belongs to another account.")
    name, model_id = variant.name, variant.model_id
    db.delete(variant)
    audit_service.record_audit(
        db,
        action="model_variant.deleted",
        summary=f"Variant '{name}' deleted from model {model_id}.",
        actor=actor,
        entity_type="model_variant",
        entity_id=variant.id,
        severity="warning",
    )
    db.commit()


def _clear_default(db: Session, *, model_id: int) -> None:
    for row in db.scalars(select(ModelVariant).where(ModelVariant.model_id == model_id, ModelVariant.is_default.is_(True))).all():
        row.is_default = False


def resolve_for_request(db: Session, *, model: Model, user: User, variant_id: int | None) -> ModelVariant | None:
    """Return the variant a chat request must honour, or raise.

    A caller may always ask for *no* variant (the plain model). Asking for a variant that is
    disabled, personal to somebody else, or belongs to another model is refused explicitly —
    never silently ignored.
    """
    if variant_id is None:
        return None
    variant = db.get(ModelVariant, variant_id)
    if variant is None or variant.model_id != model.id:
        raise ValidationError("That variant does not belong to the selected model.", details={"variant_id": variant_id})
    if not variant.enabled:
        raise ValidationError("That variant is currently switched off by the administrator.",
                              details={"variant_id": variant_id, "reason": "variant_disabled"})
    if variant.scope == "personal" and variant.owner_user_id != user.id and not user_has_admin(db, user):
        raise ValidationError("That personal variant belongs to another account.",
                              details={"variant_id": variant_id, "reason": "variant_private"})
    return variant


def user_has_admin(db: Session, user: User) -> bool:
    from app.services import access as access_service

    return access_service.has_permission(user, "models.manage") or access_service.has_permission(user, "models.test")


def mark_used(db: Session, variant: ModelVariant | None) -> None:
    if variant is None:
        return
    import datetime as dt

    variant.usage_count = (variant.usage_count or 0) + 1
    variant.last_used_at = dt.datetime.now(dt.timezone.utc)


def system_prompt_for(variant: ModelVariant | None) -> str | None:
    """The system message a variant contributes (empty string means 'no extra instructions')."""
    if variant is None:
        return None
    prompt = (variant.system_prompt or "").strip()
    return prompt or None
