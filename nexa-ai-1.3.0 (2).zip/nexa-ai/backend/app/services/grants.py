"""Credit campaigns: recurring allowances and one-off bonuses/rewards.

The platform owner (super admin) defines campaigns; everyone else simply
receives credits under exactly those rules:

* **allowances** — ``daily`` / ``weekly`` / ``monthly`` campaigns executed by
  the inline worker when due (and lazily whenever an admin lists campaigns,
  so a stopped worker never silently starves a schedule);
* **bonuses** — ``once`` campaigns for occasions or manual rewards, executed
  immediately on creation or later via *run now*.

Audiences: everyone active, a role (the platform's user groups), current
subscribers of a plan, an explicit list of users, or a single user. Every
recipient gets an append-only ledger entry whose idempotency key embeds
``campaign:run:user`` — re-running a period never pays twice, and suspended
or deleted accounts are skipped (rules apply to everyone but the owner, and
the owner never needs a grant).
"""
from __future__ import annotations

import datetime as dt
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.errors import ValidationError
from app.core.logging import get_logger
from app.models.billing import (
    CreditCampaign,
    CreditCampaignRun,
    GrantCadence,
    GrantTarget,
    LedgerEntryType,
    Subscription,
    SubscriptionStatus,
)
from app.models.user import Role, User
from app.services import access as access_service
from app.services import audit as audit_service
from app.services import ledger as ledger_service

log = get_logger(__name__)

_ENTRY_TYPE = {"bonus": LedgerEntryType.PROMOTIONAL, "allowance": LedgerEntryType.ADMIN_GRANT}


def _utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def next_run_after(cadence: str, when: dt.datetime) -> dt.datetime | None:
    if cadence == GrantCadence.DAILY:
        return when + dt.timedelta(days=1)
    if cadence == GrantCadence.WEEKLY:
        return when + dt.timedelta(days=7)
    if cadence == GrantCadence.MONTHLY:
        # calendar month, clamped to the month's last day
        year, month = (when.year + 1, 1) if when.month == 12 else (when.year, when.month + 1)
        day = min(when.day, [31, 29 if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0) else 28,
                             31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1])
        return when.replace(year=year, month=month, day=day)
    return None


def resolve_audience(db: Session, campaign: CreditCampaign) -> list[User]:
    """The users a campaign pays, under the standing rules.

    Only active accounts are ever paid; the platform owner is excluded (the
    owner's usage is billed to the platform, a grant would be meaningless),
    as are suspended/deleted accounts.
    """
    ref = campaign.target_ref or {}
    stmt = select(User).where(User.status == "active", User.deleted_at.is_(None))
    if campaign.target_type == GrantTarget.ROLE:
        slug = str(ref.get("role") or "")
        role = db.scalars(select(Role).where(Role.slug == slug)).first()
        if role is None:
            return []
        ids = [u.id for u in role.users]
        stmt = stmt.where(User.id.in_(ids)) if ids else stmt.where(User.id == -1)
    elif campaign.target_type == GrantTarget.PLAN:
        plan_id = ref.get("plan_id")
        if not plan_id:
            return []
        sub_user_ids = db.scalars(
            select(Subscription.user_id).where(
                Subscription.plan_id == int(plan_id),
                Subscription.status.in_([SubscriptionStatus.ACTIVE, SubscriptionStatus.TRIALING]),
            )
        ).all()
        stmt = stmt.where(User.id.in_(sub_user_ids)) if sub_user_ids else stmt.where(User.id == -1)
    elif campaign.target_type in (GrantTarget.USERS, GrantTarget.USER):
        raw = ref.get("user_ids") or ([ref.get("user_id")] if ref.get("user_id") else [])
        ids = [int(x) for x in raw if str(x).isdigit()]
        stmt = stmt.where(User.id.in_(ids)) if ids else stmt.where(User.id == -1)
    users = list(db.scalars(stmt.order_by(User.id)).all())
    return [u for u in users if not access_service.is_platform_owner(u)]


def run_campaign(db: Session, campaign: CreditCampaign, *, triggered_by: User | None = None,
                 run_key: str | None = None, now: dt.datetime | None = None) -> CreditCampaignRun:
    """Execute one period of a campaign. Idempotent per (campaign, run_key)."""
    now = now or _utcnow()
    if run_key is None:
        run_key = now.strftime("%Y%m%d%H%M%S") if campaign.cadence == GrantCadence.ONCE else now.strftime("%Y-%m-%d")
    existing = db.scalars(select(CreditCampaignRun).where(
        CreditCampaignRun.campaign_id == campaign.id, CreditCampaignRun.run_key == run_key)).first()
    if existing is not None:
        return existing
    if campaign.amount_micro <= 0:
        raise ValidationError("Campaign amount must be positive.")

    audience = resolve_audience(db, campaign)
    entry_type = _ENTRY_TYPE.get(campaign.kind, LedgerEntryType.PROMOTIONAL)
    description = (campaign.reason or campaign.title)[:400]
    run = CreditCampaignRun(campaign_id=campaign.id, run_key=run_key, recipients=0,
                            granted_micro=0, skipped=0, triggered_by_id=triggered_by.id if triggered_by else None)
    db.add(run)
    db.flush()
    granted = 0
    for user in audience:
        try:
            with db.begin_nested():  # one frozen account must not starve the rest
                result = ledger_service.credit(
                    db, user_id=user.id, amount_micro=int(campaign.amount_micro), entry_type=entry_type,
                    idempotency_key=f"campaign:{campaign.id}:{run_key}:{user.id}",
                    description=description, reference_type="credit_campaign", reference_id=campaign.id,
                    metadata={"campaign_id": campaign.id, "kind": campaign.kind, "cadence": campaign.cadence,
                              "target_type": campaign.target_type},
                    created_by_id=triggered_by.id if triggered_by else campaign.created_by_id,
                )
            if result.created:
                granted += 1
        except Exception:  # noqa: BLE001
            run.skipped += 1
            log.warning("campaign %s: grant to user %s skipped", campaign.id, user.id, exc_info=True)
    run.recipients = granted
    run.granted_micro = granted * int(campaign.amount_micro)
    campaign.last_run_at = now
    campaign.runs_count = (campaign.runs_count or 0) + (1 if granted or run.skipped == 0 else 0)
    campaign.total_granted_micro = (campaign.total_granted_micro or 0) + run.granted_micro
    campaign.total_recipients = (campaign.total_recipients or 0) + granted
    if campaign.cadence == GrantCadence.ONCE:
        campaign.next_run_at = None
        campaign.active = False  # a one-off bonus is done once executed
    else:
        nxt = next_run_after(campaign.cadence, now)
        if campaign.ends_at and nxt and nxt > campaign.ends_at:
            campaign.next_run_at = None
            campaign.active = False
        else:
            campaign.next_run_at = nxt
    audit_service.record_audit(
        db, action="credit_campaign.executed",
        summary=f"Campaign «{campaign.title}» paid {run.granted_micro} micro-credits to {granted} user(s).",
        actor=triggered_by, entity_type="credit_campaign", entity_id=campaign.id,
        after={"run_key": run_key, "recipients": granted, "granted_micro": run.granted_micro},
    )
    db.commit()
    db.refresh(run)
    return run


def process_due_campaigns(db: Session, *, now: dt.datetime | None = None) -> int:
    """Run every allowance whose time has come. Returns campaigns executed."""
    now = now or _utcnow()
    due = db.scalars(
        select(CreditCampaign).where(
            CreditCampaign.active.is_(True),
            CreditCampaign.cadence != GrantCadence.ONCE,
            CreditCampaign.next_run_at.is_not(None),
            CreditCampaign.next_run_at <= now,
        ).order_by(CreditCampaign.next_run_at)
    ).all()
    executed = 0
    for campaign in due:
        if campaign.ends_at and now > campaign.ends_at:
            campaign.active = False
            campaign.next_run_at = None
            db.commit()
            continue
        run_key = (campaign.next_run_at or now).strftime("%Y-%m-%d")
        already = db.scalars(select(CreditCampaignRun).where(
            CreditCampaignRun.campaign_id == campaign.id, CreditCampaignRun.run_key == run_key)).first()
        if already is not None:
            # this period already paid (manual run or a worker race): just move on
            campaign.next_run_at = next_run_after(campaign.cadence, now)
            db.commit()
            continue
        try:
            run_campaign(db, campaign, run_key=run_key, now=now)
            executed += 1
        except Exception:  # noqa: BLE001 - one bad campaign must not block the others
            db.rollback()
            log.exception("campaign %s failed to run", campaign.id)
    return executed


def create_campaign(db: Session, *, actor: User, data: dict[str, Any]) -> CreditCampaign:
    cadence = str(data.get("cadence") or GrantCadence.ONCE)
    if cadence not in GrantCadence.ALL:
        raise ValidationError(f"Unknown cadence '{cadence}'.")
    target_type = str(data.get("target_type") or GrantTarget.ALL)
    if target_type not in GrantTarget.ALL_TYPES:
        raise ValidationError(f"Unknown target type '{target_type}'.")
    amount = int(data.get("amount_micro") or 0)
    if amount <= 0:
        raise ValidationError("Campaign amount must be positive.")
    now = _utcnow()
    campaign = CreditCampaign(
        title=str(data.get("title") or "Credit grant")[:160],
        kind="allowance" if cadence != GrantCadence.ONCE else "bonus",
        cadence=cadence,
        amount_micro=amount,
        target_type=target_type,
        target_ref=data.get("target_ref") or {},
        reason=str(data.get("reason") or "")[:400],
        active=True,
        starts_at=data.get("starts_at"),
        ends_at=data.get("ends_at"),
        created_by_id=actor.id,
    )
    if cadence != GrantCadence.ONCE:
        campaign.next_run_at = campaign.starts_at or now
    db.add(campaign)
    db.flush()
    audit_service.record_audit(
        db, action="credit_campaign.created",
        summary=f"Campaign «{campaign.title}» created ({campaign.kind}, {cadence}, {amount} micro, target {target_type}).",
        actor=actor, entity_type="credit_campaign", entity_id=campaign.id,
        after={"amount_micro": amount, "cadence": cadence, "target_type": target_type},
    )
    db.commit()
    db.refresh(campaign)
    if cadence == GrantCadence.ONCE and data.get("run_immediately", True):
        run_campaign(db, campaign, triggered_by=actor)
        db.refresh(campaign)
    elif campaign.next_run_at and campaign.next_run_at <= _utcnow():
        process_due_campaigns(db)
        db.refresh(campaign)
    return campaign


def campaign_payload(campaign: CreditCampaign) -> dict[str, Any]:
    return {
        "id": campaign.id,
        "title": campaign.title,
        "kind": campaign.kind,
        "cadence": campaign.cadence,
        "amount_micro": int(campaign.amount_micro),
        "amount_credits": int(campaign.amount_micro) / 1_000_000,
        "target_type": campaign.target_type,
        "target_ref": campaign.target_ref or {},
        "reason": campaign.reason,
        "active": bool(campaign.active),
        "starts_at": campaign.starts_at.isoformat() if campaign.starts_at else None,
        "ends_at": campaign.ends_at.isoformat() if campaign.ends_at else None,
        "next_run_at": campaign.next_run_at.isoformat() if campaign.next_run_at else None,
        "last_run_at": campaign.last_run_at.isoformat() if campaign.last_run_at else None,
        "runs_count": campaign.runs_count,
        "total_granted_micro": int(campaign.total_granted_micro),
        "total_recipients": campaign.total_recipients,
        "created_at": campaign.created_at.isoformat() if campaign.created_at else None,
    }
