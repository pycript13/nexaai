"""Background job handlers (image, audio, video, document, data, export, cleanup).

Handlers receive a live ORM session and the claimed ``Job``. They must:
* persist real results (files/rows) — never invent outputs,
* charge only for successful provider work,
* write errors in the shared taxonomy so the UI can explain them.
"""
from __future__ import annotations

import base64
import datetime as dt
import json
import time
import uuid
from typing import Any

import httpx
from sqlalchemy.orm import Session

from app.core.errors import ValidationError
from app.core.logging import get_logger
from app.core.net import assert_outbound_url
from app.models.billing import UsageStatus
from app.models.files import StoredFile
from app.models.jobs import Job, JobStatus, JobType
from app.models.provider import Model
from app.models.user import User
from app.providers.base import (
    ImageGenerationRequest,
    TranscriptionRequest,
    VideoGenerationRequest,
)
from app.services import files as file_service
from app.services import jobs as job_service
from app.services import pricing as pricing_service
from app.services import usage as usage_service
from app.workers.registry_types import HANDLERS

log = get_logger(__name__)


def _ref(db: Session, model_id: int | None):  # noqa: ANN201
    from app.services import ai as ai_service

    model = db.get(Model, model_id) if model_id else None
    if model is None:
        raise ValidationError("The model attached to this job no longer exists.")
    return ai_service.resolve_model(db, user=None, model_id=model.id, operation="chat",
                                    is_admin_test=True, admin_user=None) if False else model


def _charge(
    db: Session,
    *,
    job: Job,
    user: User | None,
    model: Model,
    operation: str,
    images: int = 0,
    audio_seconds: float | None = None,
    latency_ms: int | None = None,
    provider_request_id: str | None = None,
    usage_source: str = "unavailable",
) -> int:
    outcome = usage_service.record_usage(
        db, user=user, model=model, provider=model.provider, operation=operation, module="jobs",
        status=UsageStatus.SUCCEEDED, idempotency_key=f"job:{job.id}", images=images, audio_seconds=audio_seconds,
        latency_ms=latency_ms, provider_request_id=provider_request_id, usage_source=usage_source, job_id=job.id,
    )
    job.charged_micro = outcome.usage.charged_micro
    job.provider_cost_micro = outcome.usage.provider_cost_micro or 0
    return outcome.usage.charged_micro


@job_service.register_handler(JobType.IMAGE_GENERATION)
def handle_image_generation(db: Session, job: Job) -> None:
    from app.services import ai as ai_service
    from app.providers.registry import adapter_for_provider

    payload = job.payload or {}
    model = db.get(Model, job.model_id)
    if model is None:
        raise ValidationError("Model for this job no longer exists.")
    adapter = adapter_for_provider(model.provider, require_key=True)
    user = db.get(User, job.user_id) if job.user_id else None
    started = time.perf_counter()
    result = _run_async(adapter.generate_image(  # type: ignore[misc]
        ImageGenerationRequest(model=model.provider_model_id, prompt=payload.get("prompt", ""), n=int(payload.get("n") or 1),
                               size=payload.get("size"), quality=payload.get("quality"), response_format="b64_json")
    ))
    latency_ms = int((time.perf_counter() - started) * 1000)
    stored: list[dict[str, Any]] = []
    for index, image in enumerate(result.images):
        data: bytes | None = None
        if image.b64_json:
            data = base64.b64decode(image.b64_json)
        elif image.url:
            assert_outbound_url(image.url, purpose="generated image download")
            with httpx.Client(timeout=60) as client:
                response = client.get(image.url)
                if response.status_code < 400:
                    data = response.content
        if not data:
            continue
        record = file_service.store_generated(
            db, user=user, data=data, extension="png", name=f"gen-{uuid.uuid4().hex[:8]}-{index}",
            metadata={"prompt": payload.get("prompt", ""), "model_id": model.id, "job_id": job.id},
        )
        stored.append({"file_id": record.id, "name": record.original_name, "size_bytes": record.size_bytes})
    charged = _charge(db, job=job, user=user, model=model, operation="image_generation", images=len(stored),
                      latency_ms=latency_ms, provider_request_id=result.provider_request_id,
                      usage_source=result.usage_source)
    job_service.complete(db, job, result={"images": stored, "prompt": payload.get("prompt", ""), "charged_micro": charged,
                                          "provider_usage": result.usage_source})


@job_service.register_handler(JobType.AUDIO_TRANSCRIPTION)
def handle_transcription(db: Session, job: Job) -> None:
    from app.providers.registry import adapter_for_provider

    payload = job.payload or {}
    model = db.get(Model, job.model_id)
    record = db.get(StoredFile, payload.get("file_id"))
    if model is None or record is None:
        raise ValidationError("The model or audio file attached to this job no longer exists.")
    adapter = adapter_for_provider(model.provider, require_key=True)
    user = db.get(User, job.user_id) if job.user_id else None
    started = time.perf_counter()
    result = _run_async(adapter.transcribe(  # type: ignore[misc]
        TranscriptionRequest(model=model.provider_model_id, file_path=str(file_service.absolute_path_for(record)),
                             language=payload.get("language"), prompt=payload.get("prompt"))
    ))
    latency_ms = int((time.perf_counter() - started) * 1000)
    charged = _charge(db, job=job, user=user, model=model, operation="audio_transcription",
                      audio_seconds=result.duration_seconds, latency_ms=latency_ms,
                      provider_request_id=result.provider_request_id, usage_source=result.usage_source)
    record.extracted_text = result.text
    job_service.complete(db, job, result={"text": result.text, "duration_seconds": result.duration_seconds,
                                          "file_id": record.id, "charged_micro": charged})


@job_service.register_handler(JobType.VIDEO_GENERATION)
def handle_video_generation(db: Session, job: Job) -> None:
    from app.providers.registry import adapter_for_provider

    payload = job.payload or {}
    model = db.get(Model, job.model_id)
    if model is None:
        raise ValidationError("Model for this job no longer exists.")
    adapter = adapter_for_provider(model.provider, require_key=True)
    user = db.get(User, job.user_id) if job.user_id else None
    started = time.perf_counter()
    result = _run_async(adapter.generate_video(  # type: ignore[misc]
        VideoGenerationRequest(model=model.provider_model_id, prompt=payload.get("prompt", ""),
                              image_url=payload.get("image_url"), duration_seconds=payload.get("duration_seconds"),
                              aspect_ratio=payload.get("aspect_ratio"))
    ))
    # poll until the provider finishes (bounded), then record the output URL
    provider_job_id = result.job_id
    status = result.status
    video_url = result.video_url
    deadline = time.time() + 900
    while provider_job_id and status not in ("succeeded", "failed", "canceled") and time.time() < deadline:
        time.sleep(10)
        job_service.heartbeat(db, job, progress=min(90, (job.progress or 0) + 10))
        poll = _run_async(adapter.video_status(provider_job_id))  # type: ignore[misc]
        status = poll.status
        video_url = poll.video_url or video_url
    latency_ms = int((time.perf_counter() - started) * 1000)
    if status not in ("succeeded", "completed", "ok", "success") and not video_url:
        job_service.fail(db, job, category="upstream_server_error",
                         message=f"Provider reported status '{status}' without an output.", retryable=False)
        return
    charged = _charge(db, job=job, user=user, model=model, operation="video_generation",
                      audio_seconds=None, latency_ms=latency_ms, provider_request_id=result.provider_request_id,
                      usage_source="provider_reported" if video_url else "unavailable")
    job_service.complete(db, job, result={"video_url": video_url, "provider_job_id": provider_job_id, "status": status,
                                          "charged_micro": charged})


@job_service.register_handler(JobType.CLEANUP)
def handle_cleanup(db: Session, job: Job) -> None:
    report = file_service.cleanup_expired(db)
    expired_subs = __import__("app.services.payments", fromlist=["payments"]).expire_lapsed_subscriptions(db)
    job_service.complete(db, job, result={**report, "subscriptions_expired": expired_subs})


@job_service.register_handler(JobType.EXPORT)
def handle_export(db: Session, job: Job) -> None:
    from app.models.chat import Conversation, Message

    payload = job.payload or {}
    user = db.get(User, job.user_id) if job.user_id else None
    if user is None:
        raise ValidationError("The account that requested this export no longer exists.")
    conversations = db.query(Conversation).filter(Conversation.user_id == user.id).order_by(Conversation.id).all()
    export: dict[str, Any] = {
        "exported_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        "user": {"id": user.id, "email": user.email},
        "conversations": [],
    }
    for conversation in conversations:
        messages = db.query(Message).filter(Message.conversation_id == conversation.id).order_by(Message.id).all()
        export["conversations"].append(
            {
                "id": conversation.id, "title": conversation.title, "module": conversation.module,
                "created_at": str(conversation.created_at),
                "messages": [{"role": m.role, "content": m.content, "created_at": str(m.created_at)} for m in messages],
            }
        )
    data = json.dumps(export, ensure_ascii=False, indent=2, default=str).encode()
    record = file_service.store_generated(db, user=user, data=data, extension="json",
                                          name=f"nexa-export-{user.id}-{uuid.uuid4().hex[:6]}",
                                          kind="export", mime_type="application/json")
    job_service.complete(db, job, result={"file_id": record.id, "conversations": len(conversations),
                                          "size_bytes": len(data)})


def _run_async(coro):  # noqa: ANN001, ANN201
    """Run an async adapter call from a synchronous worker."""
    import asyncio

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None
    if loop is not None:  # pragma: no cover - workers are sync
        return loop.run_until_complete(coro)
    return asyncio.run(coro)


@job_service.register_handler(JobType.SPEECH_GENERATION)
def handle_speech_generation(db: Session, job: Job) -> None:
    from app.providers.base import SpeechRequest
    from app.providers.registry import adapter_for_provider

    payload = job.payload or {}
    model = db.get(Model, job.model_id)
    if model is None:
        raise ValidationError("Model for this job no longer exists.")
    text = (payload.get("text") or "").strip()
    if not text:
        raise ValidationError("The speech job has no text to synthesise.")
    adapter = adapter_for_provider(model.provider, require_key=True)
    user = db.get(User, job.user_id) if job.user_id else None
    started = time.perf_counter()
    result = _run_async(adapter.synthesize(  # type: ignore[misc]
        SpeechRequest(model=model.provider_model_id, text=text, voice=payload.get("voice"))
    ))
    latency_ms = int((time.perf_counter() - started) * 1000)
    record = file_service.store_generated(
        db, user=user, data=result.audio_bytes, extension=result.extension or "mp3",
        name=f"speech-{uuid.uuid4().hex[:8]}",
        metadata={"text": text[:500], "model_id": model.id, "job_id": job.id, "voice": payload.get("voice")},
    )
    charged = _charge(db, job=job, user=user, model=model, operation="speech_generation", latency_ms=latency_ms,
                      provider_request_id=result.provider_request_id, usage_source=result.usage_source)
    job_service.complete(db, job, result={"file_id": record.id, "name": record.original_name,
                                          "size_bytes": record.size_bytes, "charged_micro": charged})


@job_service.register_handler(JobType.DOCUMENT_SUMMARY)
def handle_document_summary(db: Session, job: Job) -> None:
    """Summarise / ask / extract / translate documents using a chat model."""
    from app.providers.base import ChatMessage
    from app.services import ai as ai_service

    payload = job.payload or {}
    model = db.get(Model, job.model_id)
    if model is None:
        raise ValidationError("Model for this job no longer exists.")
    user = db.get(User, job.user_id) if job.user_id else None
    if user is None:
        raise ValidationError("The account that requested this job no longer exists.")
    file_ids = [int(fid) for fid in (payload.get("file_ids") or [])]
    if not file_ids:
        raise ValidationError("The document job has no files attached.")
    from app.api.v1.modules import _document_context  # local import avoids a cycle at import time

    mode = payload.get("mode") or "summarize"
    context, meta = _document_context(db, user, file_ids)
    instructions = {
        "summarize": ("Summarise the documents. Give a short executive summary, key points, figures/dates and open "
                      "questions. Use only the provided documents."),
        "extract": ("Extract structured data as JSON with entities, dates, amounts, obligations and a confidence "
                    "field per item."),
        "ask": ("Answer the question using ONLY the documents below. If the answer is absent, say so explicitly.\n\n"
                f"Question: {payload.get('question') or ''}"),
        "translate": (f"Translate the documents into {payload.get('target_language') or 'English'}. Preserve "
                      "formatting, numbers and proper nouns. Output only the translation."),
    }
    instruction = instructions.get(mode, instructions["summarize"])
    ref = ai_service.resolve_model(db, user=user, model_id=model.id, operation="chat")
    response, outcome = _run_async(ai_service.run_chat(
        db, user=user, model_ref=ref, messages=[ChatMessage(role="user", content=f"{instruction}\n\n{context}")],
        system="You are a meticulous document analyst. Never fabricate content that is not in the documents.",
        module="documents", job_id=job.id,
    ))
    job_service.complete(db, job, result={"mode": mode, "text": response.text, "documents": meta,
                                          "charged_micro": outcome.usage.charged_micro})


@job_service.register_handler(JobType.DOCUMENT_INDEX)
def handle_document_index(db: Session, job: Job) -> None:
    """Chunk a document (and optionally embed it) so later questions can retrieve context."""
    from app.providers.registry import adapter_for_provider

    payload = job.payload or {}
    record = db.get(StoredFile, payload.get("file_id"))
    if record is None:
        raise ValidationError("The file attached to this job no longer exists.")
    text = file_service.extract_text(record)
    record.extracted_text = text
    chunks = file_service.chunk_text(text)
    indexed = file_service.store_chunks(record, chunks)
    embeddings: dict[str, Any] = {"model_id": None, "status": "not_requested"}
    embedding_model_id = payload.get("embedding_model_id")
    if embedding_model_id:
        model = db.get(Model, int(embedding_model_id))
        if model is None:
            raise ValidationError("The embedding model attached to this job no longer exists.")
        adapter = adapter_for_provider(model.provider, require_key=True)
        vectors: list[list[float]] = []
        for start in range(0, len(indexed), 32):
            batch = [item["text"] for item in indexed[start:start + 32]]
            result = _run_async(adapter.embed(model=model.provider_model_id, inputs=batch))
            vectors.extend(result.embeddings)
        file_service.store_embeddings(record, vectors)
        embeddings = {"model_id": model.id, "status": "stored", "vectors": len(vectors),
                      "dimensions": len(vectors[0]) if vectors else 0}
    job_service.complete(db, job, result={"file_id": record.id, "chunks": len(indexed),
                                          "characters": len(text), "embeddings": embeddings})


@job_service.register_handler(JobType.DATA_ANALYSIS)
def handle_data_analysis(db: Session, job: Job) -> None:
    from app.providers.base import ChatMessage
    from app.services import ai as ai_service

    payload = job.payload or {}
    record = db.get(StoredFile, payload.get("file_id"))
    if record is None:
        raise ValidationError("The dataset attached to this job no longer exists.")
    user = db.get(User, job.user_id) if job.user_id else None
    if user is None:
        raise ValidationError("The account that requested this job no longer exists.")
    from app.api.v1.modules import _analyse_table, _read_tabular  # reuse the server-side analyser

    analysis = _analyse_table(_read_tabular(db, record, payload.get("sheet")))
    narrative: str | None = None
    charged = 0
    if payload.get("narrative") and job.model_id:
        model = db.get(Model, job.model_id)
        if model is None:
            raise ValidationError("Model for this job no longer exists.")
        ref = ai_service.resolve_model(db, user=user, model_id=model.id, operation="chat")
        compact = {"row_count": analysis["row_count"], "column_count": analysis["column_count"],
                   "columns": analysis["columns"], "preview_rows": analysis["preview"][:8]}
        question = payload.get("question") or ("Summarise this dataset: contents, notable patterns, data-quality "
                                               "issues and three concrete next steps.")
        response, outcome = _run_async(ai_service.run_chat(
            db, user=user, model_ref=ref,
            messages=[ChatMessage(role="user", content=f"{question}\n\nDataset statistics (JSON):\n{json.dumps(compact, default=str)}")],
            system="You are a data analyst. Base every statement strictly on the provided statistics.",
            module="data", job_id=job.id,
        ))
        narrative = response.text
        charged = outcome.usage.charged_micro
    job_service.complete(db, job, result={"statistics": analysis, "narrative": narrative, "charged_micro": charged,
                                          "file_id": record.id})


@job_service.register_handler(JobType.BATCH_TRANSLATION)
def handle_batch_translation(db: Session, job: Job) -> None:
    from app.providers.base import ChatMessage
    from app.services import ai as ai_service

    payload = job.payload or {}
    model = db.get(Model, job.model_id)
    if model is None:
        raise ValidationError("Model for this job no longer exists.")
    user = db.get(User, job.user_id) if job.user_id else None
    if user is None:
        raise ValidationError("The account that requested this job no longer exists.")
    texts = [item for item in (payload.get("texts") or []) if str(item).strip()]
    if not texts:
        raise ValidationError("The translation job has no text to translate.")
    if len(texts) > 500:
        raise ValidationError("Batch translation jobs are limited to 500 items.")
    ref = ai_service.resolve_model(db, user=user, model_id=model.id, operation="chat")
    translations: list[dict[str, Any]] = []
    charged = 0
    for index, item in enumerate(texts):
        instruction = (f"Source language: {payload.get('source_language') or 'auto-detect'}.\n"
                       f"Target language: {payload.get('target_language')}.\n\nText:\n{item}")
        response, outcome = _run_async(ai_service.run_chat(
            db, user=user, model_ref=ref, messages=[ChatMessage(role="user", content=instruction)],
            system="You are a professional translator. Reply with the translation only.",
            temperature=0.1, module="translation", job_id=job.id,
        ))
        charged += outcome.usage.charged_micro
        translations.append({"index": index, "source": item, "translation": response.text.strip()})
        job_service.heartbeat(db, job, progress=min(95, int((index + 1) / len(texts) * 100)))
    job_service.complete(db, job, result={"target_language": payload.get("target_language"),
                                          "items": translations, "charged_micro": charged})


@job_service.register_handler(JobType.MODEL_TEST)
def handle_model_test(db: Session, job: Job) -> None:
    from app.services import ai as ai_service

    payload = job.payload or {}
    model = db.get(Model, job.model_id)
    if model is None:
        raise ValidationError("Model for this job no longer exists.")
    admin = db.get(User, job.user_id) if job.user_id else None
    if admin is None:
        raise ValidationError("The administrator who requested this test no longer exists.")
    outcome = _run_async(ai_service.admin_test_model(
        db, admin=admin, model=model, operation=payload.get("operation") or "chat",
        payload=payload.get("payload") or {},
    ))
    job_service.complete(db, job, result={"test_id": outcome.get("test", {}).get("id"),
                                          "status": outcome.get("test", {}).get("status"),
                                          "summary": outcome.get("test", {}).get("response_summary"),
                                          "charged_micro": 0})


@job_service.register_handler(JobType.PROVIDER_SYNC)
def handle_provider_sync(db: Session, job: Job) -> None:
    from app.models.provider import Provider
    from app.services import providers as provider_service

    payload = job.payload or {}
    provider = db.get(Provider, int(payload.get("provider_id") or 0))
    if provider is None:
        raise ValidationError("The provider attached to this job no longer exists.")
    actor = db.get(User, job.user_id) if job.user_id else None
    summary = _run_async(provider_service.sync_models(db, actor=actor, provider=provider))
    job_service.complete(db, job, result=summary)
