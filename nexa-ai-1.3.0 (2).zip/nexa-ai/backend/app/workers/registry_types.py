"""Shared registry object to avoid a circular import between services and handlers."""
from __future__ import annotations

from collections.abc import Callable
from typing import Any

HANDLERS: dict[str, Callable[..., Any]] = {}
