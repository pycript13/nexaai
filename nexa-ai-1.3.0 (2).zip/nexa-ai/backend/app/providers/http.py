"""HTTP transport shared by all adapters.

Responsibilities
* SSRF-validated base URLs (never lets a configured provider URL reach metadata
  or private services unless the operator explicitly allowlists it).
* Error categorisation: connectivity / authentication / rate limit / quota /
  model-not-found / unsupported / invalid request / timeout / upstream failure.
* Retry with exponential backoff + jitter for retryable categories only.
* Per-provider concurrency semaphore and optional requests-per-minute throttle.
* Secret-safe logging: API keys, Authorization headers and bodies are never
  logged; error messages are passed through the redaction filter.
"""
from __future__ import annotations

import asyncio
import json
import random
import time
from collections.abc import AsyncIterator
from typing import Any

import httpx

from app.core.errors import (
    AUTHENTICATION,
    AUTHORIZATION,
    CATEGORY_LABELS,
    CONNECTIVITY,
    CONTENT_FILTERED,
    INVALID_REQUEST,
    MALFORMED_RESPONSE,
    MODEL_NOT_FOUND,
    QUOTA_EXHAUSTED,
    RATE_LIMIT,
    TIMEOUT,
    UNSUPPORTED_OPERATION,
    UPSTREAM_ERROR,
    ProviderError,
    hints_for,
)
from app.core.logging import get_logger, redact
from app.core.net import validate_outbound_url
from app.core.ratelimit import limiter

log = get_logger(__name__)

REQUEST_ID_HEADERS = ("x-request-id", "request-id", "openai-request-id", "x-amzn-requestid", "cf-ray")

# --- test seam -----------------------------------------------------------------
# Tests (and only tests) may install an httpx transport factory so that provider
# calls are served by a mock transport instead of the real network. Production
# code never sets this; it stays None.
TRANSPORT_FACTORY = None


def _client_kwargs(*, local_address: str | None = None, **kwargs) -> dict:
    """Build httpx client kwargs.

    ``local_address`` is *not* an ``AsyncClient`` argument: it belongs to the transport, and it is
    how a single address family (IPv4/IPv6) is forced — httpcore then resolves the host with that
    family only. It is ignored when a proxy is configured (the proxy chooses the family) and when
    a test transport is installed.
    """
    if TRANSPORT_FACTORY is not None:
        kwargs["transport"] = TRANSPORT_FACTORY()
    elif local_address and not kwargs.get("proxy"):
        kwargs.pop("local_address", None)
        kwargs["transport"] = httpx.AsyncHTTPTransport(local_address=local_address, retries=0)
    else:
        kwargs.pop("local_address", None)
    return kwargs


# local_address makes httpcore/anyio resolve the host with that family only, which is how a
# single address family can be forced without touching SNI, TLS verification or redirects.
LOCAL_ADDRESS_FOR_FAMILY = {"ipv4": "0.0.0.0", "ipv6": "::"}


def transport_candidates(preference: str) -> list[tuple[str, str | None]]:
    """The transports to try, in order, as ``(label, local_address)``.

    * ``ipv4``/``ipv6`` — that family only, no fallback (the operator asked for it).
    * ``auto``          — the system's own choice first, then IPv4, then IPv6. The extra
      attempts only run when a connection-level failure happened, and any success is
      reported with the family that actually worked.
    """
    if preference == "ipv4":
        return [("ipv4", LOCAL_ADDRESS_FOR_FAMILY["ipv4"])]
    if preference == "ipv6":
        return [("ipv6", LOCAL_ADDRESS_FOR_FAMILY["ipv6"])]
    return [("auto", None), ("ipv4", LOCAL_ADDRESS_FOR_FAMILY["ipv4"]), ("ipv6", LOCAL_ADDRESS_FOR_FAMILY["ipv6"])]


# What each transport-level failure actually means, in one sentence an operator can act on.
_CAUSE_EXPLANATIONS: dict[str, str] = {
    "ConnectError": "the connection to the provider could not be established — DNS, firewall, TLS or the provider itself",
    "ConnectTimeout": "the connection attempt to the provider timed out",
    "ReadTimeout": "the provider did not send a response before the read timeout",
    "WriteTimeout": "the request could not be sent to the provider before the write timeout",
    "PoolTimeout": "no free connection to the provider was available before the pool timeout",
    "ReadError": "the connection was closed while reading the provider's response — proxy, firewall or an overloaded provider",
    "WriteError": "the connection was closed while sending the request",
    "RemoteProtocolError": "the provider closed the connection before finishing the response",
    "ProxyError": "the configured proxy refused or failed the connection",
    "UnsupportedProtocol": "the provider base URL is not an http:// or https:// address",
    "SSLError": "the TLS handshake with the provider failed (certificate or protocol mismatch)",
    "InvalidURL": "the provider base URL is malformed",
}


def _endpoint_label(url: str | None, *, max_length: int = 96) -> str:
    """`https://host/path` without query string or credentials, safe for error messages."""
    if not url:
        return ""
    from urllib.parse import urlsplit

    try:
        parts = urlsplit(url)
    except ValueError:
        return "[unparseable url]"
    host = parts.hostname or ""
    if parts.port and parts.port not in (80, 443):
        host = f"{host}:{parts.port}"
    label = f"{parts.scheme}://{host}{parts.path}" if host else (parts.path or url)
    return label[:max_length]


def _exception_detail(exc: BaseException, *, max_length: int = 240) -> str:
    """A never-empty, redaction-safe description of a transport failure.

    ``str()`` is empty for several httpx exceptions (ConnectTimeout, ReadTimeout, ...),
    so the class name, the ``errno`` and the underlying cause are always included.
    """
    name = type(exc).__name__
    text = str(exc).strip()
    cause = exc.__cause__ or exc.__context__
    cause_text = str(cause).strip() if cause is not None else ""
    bits = [name]
    if text:
        bits.append(text)
    if cause_text and cause_text != text:
        bits.append(f"caused by {type(cause).__name__}: {cause_text}")
    errno = getattr(exc, "errno", None)
    if errno is not None and str(errno) not in (text + cause_text):
        bits.append(f"errno {errno}")
    detail = " — ".join(bits)
    explanation = _CAUSE_EXPLANATIONS.get(name)
    if explanation:
        detail = f"{detail} ({explanation})"
    return redact(detail)[:max_length]


def _extract_request_id(headers: httpx.Headers | None) -> str | None:
    if not headers:
        return None
    for header in REQUEST_ID_HEADERS:
        value = headers.get(header)
        if value:
            return str(value)[:160]
    return None


def _body_excerpt(response: httpx.Response, limit: int = 600) -> str:
    try:
        text = response.text
    except Exception:  # pragma: no cover
        return ""
    return redact(text[:limit])


def _message_from_body(body: str) -> str:
    try:
        data = json.loads(body)
    except Exception:
        return body[:400]
    if isinstance(data, dict):
        err = data.get("error")
        if isinstance(err, dict):
            return str(err.get("message") or err.get("type") or err)[:400]
        if isinstance(err, str):
            return err[:400]
        for key in ("message", "detail", "error_description"):
            if key in data and isinstance(data[key], str):
                return data[key][:400]
    return body[:400]


def classify_http_error(
    status_code: int,
    body: str,
    *,
    provider: str,
    model: str | None,
    request_id: str | None,
    url: str | None = None,
) -> ProviderError:
    lowered = body.lower()
    message = _message_from_body(body)
    if status_code in (401, 407):
        category = AUTHENTICATION
    elif status_code == 403:
        category = AUTHORIZATION
    elif status_code == 404:
        category = MODEL_NOT_FOUND
    elif status_code == 429:
        category = QUOTA_EXHAUSTED if any(k in lowered for k in ("quota", "insufficient_quota", "billing", "exceeded your current quota")) else RATE_LIMIT
    elif status_code in (400, 405, 422):
        if any(k in lowered for k in ("not supported", "unsupported", "does not support", "not implemented")):
            category = UNSUPPORTED_OPERATION
        elif any(k in lowered for k in ("content policy", "safety", "blocked")):
            category = CONTENT_FILTERED
        elif "model" in lowered and any(k in lowered for k in ("does not exist", "not found", "unknown model", "no such model")):
            category = MODEL_NOT_FOUND
        else:
            category = INVALID_REQUEST
    elif status_code == 408:
        category = TIMEOUT
    elif status_code >= 500:
        category = UPSTREAM_ERROR
    else:
        category = INVALID_REQUEST
    return ProviderError(
        message or CATEGORY_LABELS.get(category, "Provider request failed"),
        category=category,
        provider=provider,
        model=model,
        status_code=status_code,
        request_id=request_id,
        # A bare 429 is a *transient* throttle: providers clear it in seconds (the live check
        # against a real endpoint hit exactly this — "at concurrency capacity, paid accounts are
        # admitted first"), so it is retried with the caller's backoff, which honours Retry-After.
        # An exhausted quota or a billing block (same status code, different meaning) is not
        # retried: nothing would change by asking again.
        retryable=category in (RATE_LIMIT, TIMEOUT, UPSTREAM_ERROR),
        details={
            "upstream_status": status_code,
            "upstream_message": message,
            "endpoint": _endpoint_label(url),
            "hints": hints_for(category),
        },
    )


def classify_exception(
    exc: Exception,
    *,
    provider: str,
    model: str | None,
    url: str | None = None,
    operation: str | None = None,
) -> ProviderError:
    """Turn a transport exception into a ProviderError an operator can act on.

    The message always carries substance (exception class, underlying cause, the endpoint
    that was called), because a bare category label tells nobody what to fix.
    """
    if isinstance(exc, ProviderError):
        return exc
    if isinstance(exc, (httpx.ConnectTimeout, httpx.ReadTimeout, httpx.WriteTimeout, httpx.PoolTimeout, asyncio.TimeoutError)):
        category = TIMEOUT
    elif isinstance(exc, (httpx.ConnectError, httpx.NetworkError, httpx.ProxyError, httpx.UnsupportedProtocol)):
        category = CONNECTIVITY
    elif isinstance(exc, httpx.HTTPError):
        category = UPSTREAM_ERROR
    elif isinstance(exc, json.JSONDecodeError):
        category = MALFORMED_RESPONSE
    else:
        category = UPSTREAM_ERROR

    label = CATEGORY_LABELS.get(category, "Provider request failed")
    endpoint = _endpoint_label(url)
    detail = _exception_detail(exc)
    message = f"{label} while calling {endpoint}: {detail}" if endpoint else f"{label}: {detail}"
    return ProviderError(
        message,
        category=category,
        provider=provider,
        model=model,
        retryable=category in (TIMEOUT, CONNECTIVITY, UPSTREAM_ERROR),
        details={
            "endpoint": endpoint or None,
            "exception": type(exc).__name__,
            "cause": type(exc.__cause__).__name__ if exc.__cause__ is not None else None,
            "operation": operation,
            "hints": hints_for(category),
        },
    )


class ProviderHTTPClient:
    """Thin, safe wrapper around ``httpx.AsyncClient``."""

    _semaphores: dict[str, asyncio.Semaphore] = {}

    def __init__(
        self,
        *,
        provider: str,
        base_url: str,
        api_key: str = "",
        extra_headers: dict[str, str] | None = None,
        connect_timeout: float = 10.0,
        read_timeout: float = 120.0,
        max_retries: int = 2,
        requests_per_minute: int = 0,
        max_concurrency: int = 4,
        proxy_url: str | None = None,
        auth_header: str = "Authorization",
        auth_prefix: str = "Bearer ",
        validate_url: bool = True,
        model: str | None = None,
        network_preference: str = "auto",
    ) -> None:
        self.provider = provider
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key or ""
        self.extra_headers = extra_headers or {}
        self.connect_timeout = connect_timeout
        self.read_timeout = read_timeout
        self.max_retries = max(0, int(max_retries))
        self.requests_per_minute = requests_per_minute
        self.max_concurrency = max(1, int(max_concurrency))
        self.proxy_url = proxy_url
        self.auth_header = auth_header
        self.auth_prefix = auth_prefix
        self.model = model
        # auto | ipv4 | ipv6 — see the module docstring of _transport_candidates()
        self.network_preference = network_preference if network_preference in ("auto", "ipv4", "ipv6") else "auto"

        if validate_url and self.base_url:
            check = validate_outbound_url(self.base_url, purpose=f"provider '{provider}' base URL")
            if not check.ok:
                raise ProviderError(
                    f"Blocked provider base URL: {check.reason}",
                    category=CONNECTIVITY,
                    provider=provider,
                    model=model,
                    retryable=False,
                    details={"reason": check.reason, "hints": hints_for(CONNECTIVITY)},
                )

        self._semaphore = ProviderHTTPClient._semaphores.setdefault(
            f"{provider}:{base_url}", asyncio.Semaphore(self.max_concurrency)
        )

    # -- header construction -------------------------------------------------
    def headers(self, extra: dict[str, str] | None = None, *, with_auth: bool = True) -> dict[str, str]:
        headers = {"Accept": "application/json", "User-Agent": "NexaAI/1.0 (+https://nexa.ai)"}
        if with_auth and self.api_key:
            headers[self.auth_header] = f"{self.auth_prefix}{self.api_key}"
        headers.update(self.extra_headers)
        if extra:
            headers.update(extra)
        return headers

    def url(self, path: str) -> str:
        if path.startswith("http://") or path.startswith("https://"):
            return path
        return f"{self.base_url}{path if path.startswith('/') else '/' + path}"

    # -- low level request with retries --------------------------------------
    async def request(
        self,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        files: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
        with_auth: bool = True,
        expect_json: bool = True,
        raw_response: bool = False,
    ) -> Any:
        """Perform a provider request, trying the configured address family and, in `auto`
        mode, falling back to the other one when the connection cannot be established."""
        candidates = transport_candidates(self.network_preference)
        last_error: ProviderError | None = None
        for index, (label, local_address) in enumerate(candidates):
            try:
                result = await self._request_once(
                    method,
                    path,
                    json_body=json_body,
                    data=data,
                    files=files,
                    params=params,
                    headers=headers,
                    timeout=timeout,
                    with_auth=with_auth,
                    expect_json=expect_json,
                    raw_response=raw_response,
                    local_address=local_address,
                )
            except ProviderError as error:
                if error.category != CONNECTIVITY or index == len(candidates) - 1:
                    if index > 0 and error.category == CONNECTIVITY:
                        error.details.setdefault("address_families_tried", [c[0] for c in candidates[: index + 1]])
                    raise
                last_error = error
                log.warning(
                    "provider=%s connection failed over %s (%s) — trying the next address family",
                    self.provider, label, error.detail[:160],
                )
                continue
            if isinstance(result, dict) and isinstance(result.get("_nexa_meta"), dict) and index > 0:
                result["_nexa_meta"]["address_family"] = label
            return result
        raise last_error or ProviderError("Provider request failed", provider=self.provider, model=self.model)

    async def _request_once(
        self,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        files: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
        with_auth: bool = True,
        expect_json: bool = True,
        raw_response: bool = False,
        local_address: str | None = None,
    ) -> Any:
        url = self.url(path)
        if url.startswith("http://") or url.startswith("https://"):
            check = validate_outbound_url(url, purpose=f"provider '{self.provider}' request")
            if not check.ok:
                raise ProviderError(
                    f"Blocked outbound request: {check.reason}",
                    category=CONNECTIVITY,
                    provider=self.provider,
                    model=self.model,
                    retryable=False,
                    details={"reason": check.reason},
                )
        if self.requests_per_minute:
            allowed, remaining = limiter.check(f"provider:{self.provider}", self.requests_per_minute, 60, raise_on_limit=False)
            if not allowed:
                raise ProviderError(
                    f"Local provider throttle engaged for '{self.provider}' ({self.requests_per_minute} req/min). Retry shortly.",
                    category=RATE_LIMIT,
                    provider=self.provider,
                    model=self.model,
                    retryable=True,
                    details={"retry_after_seconds": remaining, "source": "platform_throttle"},
                )
        timeout_value = timeout or self.read_timeout
        timeout_cfg = httpx.Timeout(timeout_value, connect=self.connect_timeout)
        attempt = 0
        last_error: ProviderError | None = None
        started = time.perf_counter()
        async with self._semaphore:
            while attempt <= self.max_retries:
                attempt += 1
                try:
                    async with httpx.AsyncClient(
                        **_client_kwargs(
                            timeout=timeout_cfg,
                            follow_redirects=False,
                            proxy=self.proxy_url or None,
                            local_address=local_address,
                            limits=httpx.Limits(max_connections=self.max_concurrency * 2,
                                                max_keepalive_connections=self.max_concurrency),
                        )
                    ) as client:
                        response = await client.request(
                            method.upper(),
                            url,
                            json=json_body,
                            data=data,
                            files=files,
                            params=params,
                            headers=self.headers(headers, with_auth=with_auth),
                        )
                    request_id = _extract_request_id(response.headers)
                    if response.status_code >= 400:
                        body = _body_excerpt(response)
                        error = classify_http_error(
                            response.status_code,
                            body,
                            provider=self.provider,
                            model=self.model,
                            request_id=request_id,
                            url=url,
                        )
                        # Attach raw diagnostic info for the admin UI
                        error.details.setdefault("latency_ms", int((time.perf_counter() - started) * 1000))
                        if error.retryable and attempt <= self.max_retries:
                            last_error = error
                            await self._backoff(attempt, response.headers.get("retry-after"))
                            continue
                        raise error
                    latency_ms = int((time.perf_counter() - started) * 1000)
                    if raw_response:
                        return response
                    if expect_json:
                        try:
                            payload = response.json()
                        except Exception as exc:
                            raise ProviderError(
                                f"Provider returned a non-JSON response (HTTP {response.status_code}). "
                                f"First bytes: {_body_excerpt(response, 160)}",
                                category=MALFORMED_RESPONSE,
                                provider=self.provider,
                                model=self.model,
                                status_code=response.status_code,
                                retryable=False,
                                request_id=request_id,
                                details={"hints": hints_for(MALFORMED_RESPONSE)},
                            ) from exc
                        if isinstance(payload, dict):
                            payload.setdefault("_nexa_meta", {})
                            if isinstance(payload["_nexa_meta"], dict):
                                payload["_nexa_meta"].update({"latency_ms": latency_ms, "request_id": request_id})
                        return payload
                    return response.text
                except ProviderError as error:
                    last_error = error
                    if error.retryable and attempt <= self.max_retries:
                        await self._backoff(attempt, None)
                        continue
                    raise
                except Exception as exc:  # noqa: BLE001
                    error = classify_exception(
                        exc, provider=self.provider, model=self.model, url=url, operation=f"{method.upper()} {path}"
                    )
                    error.details.setdefault("attempts", attempt)
                    last_error = error
                    if error.retryable and attempt <= self.max_retries:
                        log.warning(
                            "provider=%s %s attempt %s/%s failed (%s) — retrying",
                            self.provider, path, attempt, self.max_retries + 1, error.detail[:200],
                        )
                        await self._backoff(attempt, None)
                        continue
                    raise error
        raise last_error or ProviderError("Provider request failed", provider=self.provider, model=self.model)

    async def _backoff(self, attempt: int, retry_after: str | None) -> None:
        delay = min(8.0, 0.5 * (2 ** (attempt - 1))) + random.uniform(0, 0.35)
        if retry_after:
            try:
                delay = max(delay, min(30.0, float(retry_after)))
            except ValueError:
                pass
        log.info("provider=%s retrying request in %.2fs (attempt %s)", self.provider, delay, attempt)
        await asyncio.sleep(delay)

    # -- SSE streaming -------------------------------------------------------
    async def stream_lines(
        self,
        path: str,
        *,
        json_body: dict[str, Any],
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
    ) -> AsyncIterator[str]:
        """Stream SSE payloads, trying each configured address family until one produces data."""
        candidates = transport_candidates(self.network_preference)
        last_error: ProviderError | None = None
        for index, (label, local_address) in enumerate(candidates):
            delivered = False
            try:
                async for chunk in self._stream_once(
                    path, json_body=json_body, headers=headers, timeout=timeout, local_address=local_address
                ):
                    delivered = True
                    yield chunk
                return
            except ProviderError as error:
                if delivered or error.category != CONNECTIVITY or index == len(candidates) - 1:
                    if index > 0 and error.category == CONNECTIVITY:
                        error.details.setdefault("address_families_tried", [c[0] for c in candidates[: index + 1]])
                    raise
                last_error = error
                log.warning(
                    "provider=%s stream over %s failed (%s) — trying the next address family",
                    self.provider, label, error.detail[:160],
                )
                continue
        if last_error is not None:  # pragma: no cover - defensive
            raise last_error

    async def _stream_once(
        self,
        path: str,
        *,
        json_body: dict[str, Any],
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
        local_address: str | None = None,
    ) -> AsyncIterator[str]:
        """Yield decoded SSE ``data:`` payloads (excluding [DONE]).

        A connection-level failure is retried with the same backoff as ``request()`` — but
        only while *nothing has been yielded yet*: after the first byte a retry could duplicate
        the answer, so the stream then fails honestly with a full diagnosis instead.
        """
        url = self.url(path)
        check = validate_outbound_url(url, purpose=f"provider '{self.provider}' stream")
        if not check.ok:
            raise ProviderError(
                f"Blocked outbound request: {check.reason}",
                category=CONNECTIVITY,
                provider=self.provider,
                model=self.model,
                retryable=False,
                details={"reason": check.reason, "endpoint": _endpoint_label(url), "hints": hints_for(CONNECTIVITY)},
            )
        timeout_cfg = httpx.Timeout(timeout or self.read_timeout, connect=self.connect_timeout)
        stream_headers = self.headers(headers)
        stream_headers["Accept"] = "text/event-stream"
        attempt = 0
        last_error: ProviderError | None = None
        async with self._semaphore:
            while attempt <= self.max_retries:
                attempt += 1
                delivered = False
                try:
                    async with httpx.AsyncClient(
                        **_client_kwargs(
                            timeout=timeout_cfg,
                            follow_redirects=False,
                            proxy=self.proxy_url or None,
                            local_address=local_address,
                        )
                    ) as client:
                        async with client.stream("POST", url, json=json_body, headers=stream_headers) as response:
                            if response.status_code >= 400:
                                body = (await response.aread()).decode("utf-8", "replace")
                                raise classify_http_error(
                                    response.status_code,
                                    body,
                                    provider=self.provider,
                                    model=self.model,
                                    request_id=_extract_request_id(response.headers),
                                    url=url,
                                )
                            async for line in response.aiter_lines():
                                if not line:
                                    continue
                                if line.startswith("data:"):
                                    payload = line[5:].strip()
                                    if payload and payload != "[DONE]":
                                        delivered = True
                                        yield payload
                                elif line.startswith("{"):
                                    delivered = True
                                    yield line
                    return
                except ProviderError as error:
                    if error.retryable and not delivered and attempt <= self.max_retries:
                        last_error = error
                        log.warning(
                            "provider=%s stream %s attempt %s/%s failed (%s) — retrying before any data was sent",
                            self.provider, path, attempt, self.max_retries + 1, error.detail[:200],
                        )
                        await self._backoff(attempt, None)
                        continue
                    raise
                except Exception as exc:  # noqa: BLE001
                    error = classify_exception(
                        exc, provider=self.provider, model=self.model, url=url, operation=f"POST {path} (stream)"
                    )
                    error.details.setdefault("attempts", attempt)
                    error.details.setdefault("partial_stream", delivered)
                    if error.retryable and not delivered and attempt <= self.max_retries:
                        last_error = error
                        log.warning(
                            "provider=%s stream %s attempt %s/%s failed (%s) — retrying before any data was sent",
                            self.provider, path, attempt, self.max_retries + 1, error.detail[:200],
                        )
                        await self._backoff(attempt, None)
                        continue
                    raise error from exc
        if last_error is not None:  # pragma: no cover - defensive
            raise last_error


def estimate_tokens(text: str) -> int:
    """Rough token estimate used ONLY when a provider returns no usage data.

    Records using this are marked ``usage_source='estimated'`` so that reports
    never present an estimate as a provider-reported figure.
    """
    if not text:
        return 0
    return max(1, int(len(text) / 4))
