"""Reasoning models that inline their thinking in `content`.

Most gateways keep reasoning in a dedicated field (`reasoning_content`, `reasoning`), but some
return it **inside** the normal content as a `<think>…</think>` block. Verified live against
`MiniMaxAI/MiniMax-M2.7` on `https://inference.dahl.global/v1`: the whole answer arrived as

    <think>The user says: "Reply with the single word: ready" …</think>ready

Because the platform must never present raw model scaffolding as the answer, and because a
reasoning block that consumes the whole output budget leaves *no visible answer at all* (the model
answers `finish_reason=length` with the closing tag missing), the text is split here — once — for
both the non-streaming and the streaming path.

`split_inline_reasoning` handles a complete response; `InlineReasoningStream` handles deltas that
can break a tag in half (`"<thi"` + `"nk>…"`), which happens constantly in real streams.
"""

from __future__ import annotations

import re

# `<think>`, `<thinking>`, `<reasoning>` — with an optional closing tag; tags may carry attributes.
_OPEN_TAGS = ("think", "thinking", "reasoning")
_CLOSED = re.compile(
    r"<\s*(?:" + "|".join(_OPEN_TAGS) + r")\b[^>]*>(.*?)<\s*/\s*(?:" + "|".join(_OPEN_TAGS) + r")\s*>",
    re.IGNORECASE | re.DOTALL,
)
_UNCLOSED = re.compile(
    r"<\s*(?:" + "|".join(_OPEN_TAGS) + r")\b[^>]*>(.*)\Z",
    re.IGNORECASE | re.DOTALL,
)
# a lone closing tag with no opener: drop it, it is scaffolding
_STRAY_CLOSE = re.compile(r"<\s*/\s*(?:" + "|".join(_OPEN_TAGS) + r")\s*>", re.IGNORECASE)


def split_inline_reasoning(text: str | None, reasoning: str | None = None) -> tuple[str, str | None]:
    """Return `(visible_text, reasoning_text)`.

    `reasoning` (from a dedicated provider field) is prepended to anything found inline. The visible
    text keeps its formatting; only the scaffolding tags are removed.
    """
    body = text or ""
    inline = ""
    if body:
        inline = "".join(match.group(1) for match in _CLOSED.finditer(body))
        stripped = _CLOSED.sub("", body)
        unclosed = _UNCLOSED.search(stripped)
        if unclosed:
            inline += unclosed.group(1)
            stripped = stripped[: unclosed.start()]
        body = _STRAY_CLOSE.sub("", stripped).strip()
    parts = [part.strip() for part in (reasoning, inline) if part and part.strip()]
    return body, ("\n\n".join(parts) or None)


class InlineReasoningStream:
    """Split a chunked stream into visible text and reasoning text.

    Chunks may end in the middle of a tag (`"…<thi"`), so a tail that could still become a tag is
    held back until the next chunk (or until `flush()` at the end of the stream).
    """

    _MAX_TAG = 24  # longest opening/closing tag we ever expect, bounds the held-back tail

    def __init__(self) -> None:
        self._pending = ""
        self._inside = False
        self._just_closed = False

    def feed(self, delta: str) -> tuple[str, str]:
        """Return `(visible_delta, reasoning_delta)` for one upstream chunk."""
        if not delta and not self._pending:
            return "", ""
        text = self._pending + delta
        self._pending = ""
        visible: list[str] = []
        reasoning: list[str] = []
        index = 0
        while index < len(text):
            if not self._inside:
                match = re.search(r"<\s*/?\s*(?:" + "|".join(_OPEN_TAGS) + r")", text[index:], re.IGNORECASE)
                if match is None:
                    # no tag opened: emit everything except a possible partial tag at the very end
                    tail = self._possible_tag_tail(text[index:])
                    chunk = text[index : len(text) - tail] if tail else text[index:]
                    if chunk and self._just_closed and not any(part.strip() for part in visible):
                        # the answer that follows `</think>` is usually separated by a blank line
                        # which is not part of the answer — only trimmed at the start of the reply,
                        # never in the middle of one
                        chunk = chunk.lstrip("\n")
                        if chunk:
                            self._just_closed = False
                    visible.append(chunk)
                    self._pending = text[len(text) - tail :] if tail else ""
                    break
                start = index + match.start()
                visible.append(text[index:start])
                rest = text[start:]
                closing = re.match(r"<\s*/\s*", rest) is not None
                close_at = rest.find(">")
                if close_at == -1:
                    # the tag is not complete yet: hold it back
                    self._pending = rest
                    break
                self._inside = not closing
                if closing:
                    # a closing tag seen outside a block: the next visible fragment follows it
                    self._just_closed = True
                index = start + close_at + 1
            else:
                end = re.search(r"<\s*/\s*(?:" + "|".join(_OPEN_TAGS) + r")\s*>", text[index:], re.IGNORECASE)
                if end is None:
                    tail = self._possible_close_tail(text[index:])
                    reasoning.append(text[index : len(text) - tail] if tail else text[index:])
                    self._pending = text[len(text) - tail :] if tail else ""
                    break
                reasoning.append(text[index : index + end.start()])
                index = index + end.end()
                self._inside = False
                self._just_closed = True
        return "".join(visible), "".join(reasoning)

    def flush(self) -> tuple[str, str]:
        """End of stream: release anything still held back (an unterminated `<think>` counts as
        reasoning, which is exactly the truncated reasoning-model case)."""
        pending, self._pending = self._pending, ""
        if not pending:
            return "", ""
        if self._inside:
            return "", pending
        stripped = _STRAY_CLOSE.sub("", pending)
        if structured := stripped.lstrip("\n").strip():
            return structured, ""
        return (stripped if stripped.strip() else ""), ""

    # every spelling a partially received tag can still grow into
    _TAG_FORMS = tuple(
        prefix + name
        for name in _OPEN_TAGS
        for prefix in ("<", "</")
    )

    @classmethod
    def _held_back(cls, text: str) -> int:
        """Length of a trailing fragment that may still become an opening or closing tag.

        Works on prefixes rather than regular expressions: `"<thi"` is a prefix of `"<think"`, so it
        is held back until the next chunk arrives.
        """
        index = text.rfind("<")
        if index == -1:
            return 0
        fragment = text[index:]
        if ">" in fragment:
            return 0
        normalized = fragment.replace(" ", "").lower()
        return len(fragment) if any(form.startswith(normalized) for form in cls._TAG_FORMS) else 0

    _possible_tag_tail = classmethod(lambda cls, text: cls._held_back(text))

    @classmethod
    def _possible_close_tail(cls, text: str) -> int:
        return cls._held_back(text)
