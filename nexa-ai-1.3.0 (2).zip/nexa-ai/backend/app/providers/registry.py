"""Adapter registry — maps provider types to adapter classes and provider rows to
configured adapter instances."""
from __future__ import annotations

from typing import Any

from app.core.crypto import decrypt_secret
from app.core.errors import ConfigurationError, NotFound
from app.providers.anthropic import AnthropicAdapter
from app.providers.base import ProviderAdapter, ProviderCredentials
from app.providers.google import GoogleAdapter
from app.providers.media import DeepgramAdapter, ElevenLabsAdapter, ReplicateAdapter, StabilityAdapter
from app.providers.openai_compatible import (
    AzureOpenAIAdapter,
    DeepSeekAdapter,
    GroqAdapter,
    MistralAdapter,
    OllamaAdapter,
    OpenAIAdapter,
    OpenAICompatibleAdapter,
    OpenRouterAdapter,
    TogetherAdapter,
)

ADAPTER_REGISTRY: dict[str, type[ProviderAdapter]] = {
    "openai": OpenAIAdapter,
    "openai_compatible": OpenAICompatibleAdapter,
    "azure_openai": AzureOpenAIAdapter,
    "openrouter": OpenRouterAdapter,
    "groq": GroqAdapter,
    "mistral": MistralAdapter,
    "together": TogetherAdapter,
    "deepseek": DeepSeekAdapter,
    "ollama": OllamaAdapter,
    "anthropic": AnthropicAdapter,
    "google": GoogleAdapter,
    "stability": StabilityAdapter,
    "elevenlabs": ElevenLabsAdapter,
    "deepgram": DeepgramAdapter,
    "replicate": ReplicateAdapter,
    "custom": OpenAICompatibleAdapter,  # generic self-hosted gateways
}

# Suggested defaults surfaced in the admin UI (base URL only; never credentials).
PROVIDER_PRESETS: dict[str, dict[str, Any]] = {
    "openai": {"base_url": "https://api.openai.com/v1", "needs_api_key": True},
    "anthropic": {"base_url": "https://api.anthropic.com/v1", "needs_api_key": True},
    "azure_openai": {"base_url": "https://<resource>.openai.azure.com", "needs_api_key": True, "needs_api_version": True},
    "google": {"base_url": "https://generativelanguage.googleapis.com/v1beta", "needs_api_key": True},
    "openrouter": {"base_url": "https://openrouter.ai/api/v1", "needs_api_key": True},
    "groq": {"base_url": "https://api.groq.com/openai/v1", "needs_api_key": True},
    "mistral": {"base_url": "https://api.mistral.ai/v1", "needs_api_key": True},
    "together": {"base_url": "https://api.together.xyz/v1", "needs_api_key": True},
    "deepseek": {"base_url": "https://api.deepseek.com/v1", "needs_api_key": True},
    "ollama": {"base_url": "http://host.docker.internal:11434/v1", "needs_api_key": False},
    "stability": {"base_url": "https://api.stability.ai", "needs_api_key": True},
    "elevenlabs": {"base_url": "https://api.elevenlabs.io", "needs_api_key": True},
    "deepgram": {"base_url": "https://api.deepgram.com", "needs_api_key": True},
    "replicate": {"base_url": "https://api.replicate.com/v1", "needs_api_key": True},
    "openai_compatible": {"base_url": "", "needs_api_key": True},
    "custom": {"base_url": "", "needs_api_key": True},
}


def adapter_for_type(provider_type: str) -> type[ProviderAdapter]:
    adapter = ADAPTER_REGISTRY.get(provider_type)
    if adapter is None:
        raise NotFound(f"Unknown provider type '{provider_type}'")
    return adapter


def credentials_from_provider(provider, *, require_key: bool = True) -> ProviderCredentials:  # noqa: ANN001
    api_key = ""
    if provider.api_key_encrypted:
        api_key = decrypt_secret(provider.api_key_encrypted)
    adapter_cls = adapter_for_type(provider.provider_type)
    if require_key and adapter_cls.requires_api_key and not api_key:
        raise ConfigurationError(
            f"Provider '{provider.name}' has no API credential configured. "
            "Add one under Admin → AI Infrastructure → Providers → Edit.",
            details={"provider_id": provider.id, "provider": provider.name, "missing": "api_key"},
        )
    extra_headers: dict[str, str] = {}
    if provider.extra_headers_encrypted:
        try:
            import json

            extra_headers = json.loads(decrypt_secret(provider.extra_headers_encrypted) or "{}")
        except Exception:  # pragma: no cover - corrupt value
            extra_headers = {}
    return ProviderCredentials(
        api_key=api_key,
        base_url=provider.base_url or PROVIDER_PRESETS.get(provider.provider_type, {}).get("base_url", ""),
        organization_id=provider.organization_id,
        project_id=provider.project_id,
        api_version=provider.api_version,
        region=provider.region,
        extra_headers=extra_headers,
        extra_config=dict(provider.extra_config or {}),
        network_preference=getattr(provider, "network_preference", "auto") or "auto",
        proxy_url=provider.proxy_url,
        connect_timeout=provider.connect_timeout,
        read_timeout=provider.read_timeout,
        max_retries=provider.max_retries,
        requests_per_minute=provider.requests_per_minute,
        max_concurrency=provider.max_concurrency,
        provider_slug=provider.slug,
        provider_name=provider.name,
    )


def adapter_for_provider(provider, *, require_key: bool = True) -> ProviderAdapter:  # noqa: ANN001
    adapter_cls = adapter_for_type(provider.provider_type)
    credentials = credentials_from_provider(provider, require_key=require_key)
    return adapter_cls(credentials)


def describe_adapters() -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    seen: set[type] = set()
    for provider_type, cls in ADAPTER_REGISTRY.items():
        if cls in seen and provider_type not in PROVIDER_PRESETS:
            continue
        seen.add(cls)
        out.append(
            {
                "provider_type": provider_type,
                "display_name": cls.display_name,
                "operations": list(cls.supports_operations),
                "requires_api_key": cls.requires_api_key,
                "supports_model_listing": cls.supports_model_listing,
                "documentation_url": cls.documentation_url,
                "preset": PROVIDER_PRESETS.get(provider_type, {}),
            }
        )
    return sorted(out, key=lambda item: item["display_name"])
