"""Media-specific adapters: Stability (images), ElevenLabs (speech),
Deepgram (transcription) and Replicate (image + video models).

Each adapter implements only the endpoints it genuinely supports; everything
else raises ``UnsupportedOperation`` through the base class.
"""
from __future__ import annotations

import base64
import time
from typing import Any

from app.core.errors import MALFORMED_RESPONSE, ProviderError
from app.providers.base import (
    GeneratedImage,
    ImageGenerationRequest,
    ImageGenerationResponse,
    ProviderAdapter,
    SpeechRequest,
    SpeechResponse,
    TranscriptionRequest,
    TranscriptionResponse,
    VideoGenerationRequest,
    VideoGenerationResponse,
)
from app.providers.capabilities import Operation
from app.providers.http import ProviderHTTPClient

# ---------------------------------------------------------------- Stability --
class StabilityAdapter(ProviderAdapter):
    provider_type = "stability"
    display_name = "Stability AI"
    supports_operations = (Operation.IMAGE_GENERATION.value,)
    documentation_url = "https://platform.stability.ai/docs/api-reference"

    DEFAULT_MODEL = "core"

    def client(self, *, model: str | None = None, timeout: float | None = None) -> ProviderHTTPClient:
        c = self.credentials
        return ProviderHTTPClient(
            provider=c.provider_slug or self.provider_type,
            base_url=c.base_url or "https://api.stability.ai",
            api_key=c.api_key,
            extra_headers=c.extra_headers or {},
            connect_timeout=c.connect_timeout,
            read_timeout=timeout or c.read_timeout,
            max_retries=c.max_retries,
            requests_per_minute=c.requests_per_minute,
            max_concurrency=c.max_concurrency,
            proxy_url=c.proxy_url,
            auth_header="Authorization",
            auth_prefix="Bearer ",
            model=model,
        )

    async def test_connection(self) -> dict[str, Any]:
        started = time.perf_counter()
        client = self.client(timeout=min(self.credentials.read_timeout, 30))
        try:
            payload = await client.request("GET", "/v1/user/account")
            return {
                "ok": True,
                "message": f"Stability account reachable (credits: {payload.get('credits', 'n/a')}).",
                "latency_ms": int((time.perf_counter() - started) * 1000),
                "details": {"credits": payload.get("credits")},
            }
        except ProviderError as error:
            return {
                "ok": False,
                "message": error.detail,
                "error_category": error.category,
                "latency_ms": int((time.perf_counter() - started) * 1000),
                "details": error.details,
            }

    async def list_models(self) -> list[dict[str, Any]]:
        payload = await self.client().request("GET", "/v1/engines/list")
        items = payload if isinstance(payload, list) else payload.get("engines", [])
        return [
            {
                "provider_model_id": item.get("id") or item.get("name"),
                "display_name": (item.get("name") or item.get("id") or "").replace("_", " ").title(),
                "raw": item,
            }
            for item in items
            if isinstance(item, dict)
        ]

    async def generate_image(self, request: ImageGenerationRequest) -> ImageGenerationResponse:
        self.guard(Operation.IMAGE_GENERATION.value, request.model)
        started = time.perf_counter()
        model = request.model or self.DEFAULT_MODEL
        client = self.client(model=model, timeout=max(self.credentials.read_timeout, 240))
        data: dict[str, Any] = {"prompt": request.prompt, "output_format": "png"}
        if request.negative_prompt:
            data["negative_prompt"] = request.negative_prompt
        if request.seed is not None:
            data["seed"] = str(request.seed)
        if request.size and "x" in request.size:
            width, _, height = request.size.partition("x")
            data["aspect_ratio"] = f"{width}:{height}"
        data.update({k: str(v) for k, v in (request.extra or {}).items()})
        response = await client.request(
            "POST", f"/v2beta/stable-image/generate/{model}", data=data, headers={"Accept": "image/*"},
            raw_response=True, expect_json=False,
        )
        content = response.content or b""
        mime = response.headers.get("content-type", "image/png")
        if not content or "application/json" in mime:
            raise ProviderError(
                f"Stability returned no image content: {content[:200]!r}",
                category=MALFORMED_RESPONSE,
                provider=self.provider_name,
                model=model,
            )
        return ImageGenerationResponse(
            images=[GeneratedImage(b64_json=base64.b64encode(content).decode(), mime_type="image/png")],
            latency_ms=int((time.perf_counter() - started) * 1000),
            provider_request_id=response.headers.get("x-request-id"),
            usage_source="provider_reported",
        )


# --------------------------------------------------------------- ElevenLabs --
class ElevenLabsAdapter(ProviderAdapter):
    provider_type = "elevenlabs"
    display_name = "ElevenLabs"
    supports_operations = (Operation.SPEECH_GENERATION.value,)
    documentation_url = "https://elevenlabs.io/docs/api-reference/text-to-speech"

    DEFAULT_VOICE = "21m00Tcm4TlvDq8ikWAM"  # public "Rachel" library voice

    def client(self, *, model: str | None = None, timeout: float | None = None) -> ProviderHTTPClient:
        c = self.credentials
        return ProviderHTTPClient(
            provider=c.provider_slug or self.provider_type,
            base_url=c.base_url or "https://api.elevenlabs.io",
            api_key=c.api_key,
            extra_headers=c.extra_headers or {},
            connect_timeout=c.connect_timeout,
            read_timeout=timeout or c.read_timeout,
            max_retries=c.max_retries,
            requests_per_minute=c.requests_per_minute,
            max_concurrency=c.max_concurrency,
            proxy_url=c.proxy_url,
            auth_header="xi-api-key",
            auth_prefix="",
            model=model,
        )

    async def test_connection(self) -> dict[str, Any]:
        started = time.perf_counter()
        client = self.client(timeout=min(self.credentials.read_timeout, 30))
        try:
            payload = await client.request("GET", "/v1/user/subscription")
            return {
                "ok": True,
                "message": (
                    "ElevenLabs key valid — character quota: "
                    f"{payload.get('character_count', '?')}/{payload.get('character_limit', '?')}"
                ),
                "latency_ms": int((time.perf_counter() - started) * 1000),
                "details": {k: payload.get(k) for k in ("tier", "character_count", "character_limit")},
            }
        except ProviderError as error:
            return {
                "ok": False,
                "message": error.detail,
                "error_category": error.category,
                "latency_ms": int((time.perf_counter() - started) * 1000),
                "details": error.details,
            }

    async def list_models(self) -> list[dict[str, Any]]:
        payload = await self.client().request("GET", "/v1/models")
        items = payload if isinstance(payload, list) else payload.get("models", [])
        return [
            {"provider_model_id": item.get("model_id") or item.get("id"), "display_name": item.get("name"), "raw": item}
            for item in items
            if isinstance(item, dict)
        ]

    async def synthesize(self, request: SpeechRequest) -> SpeechResponse:
        self.guard(Operation.SPEECH_GENERATION.value, request.model)
        started = time.perf_counter()
        client = self.client(model=request.model, timeout=max(self.credentials.read_timeout, 180))
        voice = request.voice or self.DEFAULT_VOICE
        body: dict[str, Any] = {
            "text": request.text,
            "model_id": request.model or "eleven_multilingual_v2",
        }
        if request.language:
            body["language_code"] = request.language
        payload = await client.request(
            "POST", f"/v1/text-to-speech/{voice}", json_body=body, headers={"Accept": "audio/mpeg"},
            raw_response=True, expect_json=False,
        )
        audio = payload.content
        if not audio:
            raise ProviderError("ElevenLabs returned empty audio", category=MALFORMED_RESPONSE, provider=self.provider_name)
        return SpeechResponse(
            audio_bytes=audio,
            mime_type=payload.headers.get("content-type", "audio/mpeg"),
            latency_ms=int((time.perf_counter() - started) * 1000),
            usage_source="estimated",
            provider_request_id=payload.headers.get("x-request-id"),
        )


# ----------------------------------------------------------------- Deepgram --
class DeepgramAdapter(ProviderAdapter):
    provider_type = "deepgram"
    display_name = "Deepgram"
    supports_operations = (Operation.AUDIO_TRANSCRIPTION.value,)
    documentation_url = "https://developers.deepgram.com/reference/pre-recorded"

    def client(self, *, model: str | None = None, timeout: float | None = None) -> ProviderHTTPClient:
        c = self.credentials
        return ProviderHTTPClient(
            provider=c.provider_slug or self.provider_type,
            base_url=c.base_url or "https://api.deepgram.com",
            api_key=c.api_key,
            extra_headers=c.extra_headers or {},
            connect_timeout=c.connect_timeout,
            read_timeout=timeout or c.read_timeout,
            max_retries=c.max_retries,
            requests_per_minute=c.requests_per_minute,
            max_concurrency=c.max_concurrency,
            proxy_url=c.proxy_url,
            model=model,
        )

    async def test_connection(self) -> dict[str, Any]:
        started = time.perf_counter()
        client = self.client(timeout=min(self.credentials.read_timeout, 30))
        try:
            payload = await client.request("GET", "/v1/projects")
            projects = payload.get("projects") if isinstance(payload, dict) else []
            return {
                "ok": True,
                "message": f"Deepgram key valid; {len(projects or [])} project(s) accessible.",
                "latency_ms": int((time.perf_counter() - started) * 1000),
            }
        except ProviderError as error:
            return {
                "ok": False,
                "message": error.detail,
                "error_category": error.category,
                "latency_ms": int((time.perf_counter() - started) * 1000),
                "details": error.details,
            }

    async def list_models(self) -> list[dict[str, Any]]:
        payload = await self.client().request("GET", "/v1/models")
        items = payload if isinstance(payload, list) else payload.get("models", [])
        return [
            {"provider_model_id": item.get("canonical_name") or item.get("name"), "display_name": item.get("name"), "raw": item}
            for item in items
            if isinstance(item, dict)
        ]

    async def transcribe(self, request: TranscriptionRequest) -> TranscriptionResponse:
        self.guard(Operation.AUDIO_TRANSCRIPTION.value, request.model)
        started = time.perf_counter()
        client = self.client(model=request.model, timeout=max(self.credentials.read_timeout, 300))
        with open(request.file_path, "rb") as handle:
            audio = handle.read()
        params: dict[str, Any] = {"model": request.model or "nova-2", "smart_format": "true", "punctuate": "true"}
        if request.language:
            params["language"] = request.language
        payload = await client.request(
            "POST", "/v1/listen", data=audio,
            headers={"Content-Type": "audio/*", "Accept": "application/json"},
            params=params, expect_json=True,
        )
        try:
            channel = payload["results"]["channels"][0]
            alternative = channel["alternatives"][0]
            text = alternative.get("transcript", "")
            duration = payload.get("metadata", {}).get("duration")
            return TranscriptionResponse(
                text=text,
                language=request.language,
                duration_seconds=duration,
                segments=alternative.get("words"),
                latency_ms=int((time.perf_counter() - started) * 1000),
                usage_source="provider_reported" if duration else "estimated",
                provider_request_id=payload.get("metadata", {}).get("request_id"),
            )
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError(f"Malformed Deepgram response: {exc}", category=MALFORMED_RESPONSE, provider=self.provider_name) from exc


# ---------------------------------------------------------------- Replicate --
class ReplicateAdapter(ProviderAdapter):
    """Runs arbitrary Replicate model versions (image and video models).

    Because Replicate is model-agnostic, the operator must supply the model
    version/ref either in the model's ``provider_model_id`` (``owner/name`` or
    ``owner/name:version``) or in provider ``extra_config`` (``version``).
    """

    provider_type = "replicate"
    display_name = "Replicate"
    supports_operations = (Operation.IMAGE_GENERATION.value, Operation.VIDEO_GENERATION.value)
    documentation_url = "https://replicate.com/docs/reference/http"

    def client(self, *, model: str | None = None, timeout: float | None = None) -> ProviderHTTPClient:
        c = self.credentials
        return ProviderHTTPClient(
            provider=c.provider_slug or self.provider_type,
            base_url=c.base_url or "https://api.replicate.com/v1",
            api_key=c.api_key,
            extra_headers=c.extra_headers or {},
            connect_timeout=c.connect_timeout,
            read_timeout=timeout or c.read_timeout,
            max_retries=c.max_retries,
            requests_per_minute=c.requests_per_minute,
            max_concurrency=c.max_concurrency,
            proxy_url=c.proxy_url,
            auth_header="Authorization",
            auth_prefix="Bearer ",
            model=model,
        )

    async def test_connection(self) -> dict[str, Any]:
        started = time.perf_counter()
        client = self.client(timeout=min(self.credentials.read_timeout, 30))
        try:
            payload = await client.request("GET", "/models?limit=1")
            results = payload.get("results") if isinstance(payload, dict) else []
            return {
                "ok": True,
                "message": f"Replicate reachable; sample model: {(results or [{}])[0].get('url', 'n/a')}",
                "latency_ms": int((time.perf_counter() - started) * 1000),
            }
        except ProviderError as error:
            return {
                "ok": False,
                "message": error.detail,
                "error_category": error.category,
                "latency_ms": int((time.perf_counter() - started) * 1000),
                "details": error.details,
            }

    async def list_models(self) -> list[dict[str, Any]]:
        payload = await self.client().request("GET", "/models")
        items = payload.get("results") if isinstance(payload, dict) else []
        return [
            {"provider_model_id": item.get("owner", "") + "/" + item.get("name", ""), "display_name": item.get("name"), "raw": item}
            for item in (items or [])
            if isinstance(item, dict)
        ]

    def _prediction_body(self, model_ref: str, input_payload: dict[str, Any]) -> dict[str, Any]:
        version = self.credentials.extra_config.get("version") if self.credentials.extra_config else None
        if ":" in model_ref:
            owner_name, _, ref_version = model_ref.partition(":")
            return {"version": ref_version, "input": input_payload}
        if version:
            return {"version": version, "input": input_payload}
        return {"input": input_payload}

    async def _create_prediction(self, model_ref: str, input_payload: dict[str, Any]) -> dict[str, Any]:
        client = self.client(model=model_ref, timeout=max(self.credentials.read_timeout, 300))
        body = self._prediction_body(model_ref, input_payload)
        path = f"/models/{model_ref.split(':')[0]}/predictions" if "version" not in body else "/predictions"
        return await client.request("POST", path, json_body=body, headers={"Prefer": "wait=60"})

    async def generate_image(self, request: ImageGenerationRequest) -> ImageGenerationResponse:
        self.guard(Operation.IMAGE_GENERATION.value, request.model)
        started = time.perf_counter()
        inputs = {"prompt": request.prompt, "num_outputs": max(1, request.n)}
        if request.seed is not None:
            inputs["seed"] = request.seed
        inputs.update(request.extra or {})
        prediction = await self._create_prediction(request.model, inputs)
        output = prediction.get("output")
        urls = output if isinstance(output, list) else ([output] if output else [])
        return ImageGenerationResponse(
            images=[GeneratedImage(url=url if isinstance(url, str) else str(url)) for url in urls],
            latency_ms=int((time.perf_counter() - started) * 1000),
            provider_request_id=prediction.get("id"),
            usage_source="provider_reported",
            raw={"status": prediction.get("status")},
        )

    async def generate_video(self, request: VideoGenerationRequest) -> VideoGenerationResponse:
        self.guard(Operation.VIDEO_GENERATION.value, request.model)
        inputs: dict[str, Any] = {"prompt": request.prompt}
        if request.image_url:
            inputs["image"] = request.image_url
        if request.duration_seconds:
            inputs["duration"] = request.duration_seconds
        if request.aspect_ratio:
            inputs["aspect_ratio"] = request.aspect_ratio
        inputs.update(request.extra or {})
        prediction = await self._create_prediction(request.model, inputs)
        return VideoGenerationResponse(
            job_id=prediction.get("id"),
            status=prediction.get("status", "pending"),
            video_url=prediction.get("output") if isinstance(prediction.get("output"), str) else None,
            provider_request_id=prediction.get("id"),
            raw={"prediction": prediction},
        )

    async def video_status(self, job_id: str) -> VideoGenerationResponse:
        payload = await self.client().request("GET", f"/predictions/{job_id}")
        return VideoGenerationResponse(
            job_id=job_id,
            status=payload.get("status", "unknown"),
            video_url=payload.get("output") if isinstance(payload.get("output"), str) else None,
            raw={"prediction": payload},
        )
