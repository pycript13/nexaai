"""Anthropic Messages API adapter (chat, streaming, vision, tools).

Anthropic does not implement OpenAI-style image generation, audio or embeddings
endpoints, so those operations are intentionally absent from the declared
capabilities and any attempt to call them raises ``UnsupportedOperation``.
"""
from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator
from typing import Any

from app.core.errors import MALFORMED_RESPONSE, ProviderError, hints_for
from app.providers.base import (
    ChatChunk,
    ChatRequest,
    ChatResponse,
    ProviderAdapter,
)
from app.providers.capabilities import Operation
from app.providers.http import ProviderHTTPClient

ANTHROPIC_VERSION = "2023-06-01"


class AnthropicAdapter(ProviderAdapter):
    provider_type = "anthropic"
    display_name = "Anthropic"
    supports_operations = (
        Operation.CHAT.value,
        Operation.STREAMING.value,
        Operation.IMAGE_UNDERSTANDING.value,
        Operation.TOOLS.value,
        Operation.DOCUMENT_QA.value,
    )
    requires_api_key = True
    documentation_url = "https://docs.anthropic.com/en/api/messages"

    def client(self, *, model: str | None = None, timeout: float | None = None) -> ProviderHTTPClient:
        c = self.credentials
        return ProviderHTTPClient(
            provider=c.provider_slug or self.provider_type,
            base_url=c.base_url or "https://api.anthropic.com/v1",
            api_key=c.api_key,
            extra_headers={"anthropic-version": c.api_version or ANTHROPIC_VERSION, **(c.extra_headers or {})},
            connect_timeout=c.connect_timeout,
            read_timeout=timeout or c.read_timeout,
            max_retries=c.max_retries,
            requests_per_minute=c.requests_per_minute,
            max_concurrency=c.max_concurrency,
            network_preference=getattr(c, "network_preference", "auto"),
            proxy_url=c.proxy_url,
            auth_header="x-api-key",
            auth_prefix="",
            model=model,
        )

    def _messages_and_system(self, request: ChatRequest) -> tuple[list[dict[str, Any]], str | None]:
        messages: list[dict[str, Any]] = []
        system = request.system
        for msg in request.messages:
            if msg.role == "system":
                system = f"{system}\n{msg.text()}" if system else msg.text()
                continue
            content: Any = msg.content
            if isinstance(content, str):
                content = [{"type": "text", "text": content}]
            # Anthropic only accepts user/assistant in messages
            role = "assistant" if msg.role == "assistant" else "user"
            messages.append({"role": role, "content": content})
        return messages, system

    def _body(self, request: ChatRequest, *, stream: bool) -> dict[str, Any]:
        messages, system = self._messages_and_system(request)
        body: dict[str, Any] = {"model": request.model, "messages": messages, "max_tokens": request.max_tokens or 1024}
        if stream:
            body["stream"] = True
        if system:
            body["system"] = system
        if request.temperature is not None:
            body["temperature"] = request.temperature
        if request.top_p is not None:
            body["top_p"] = request.top_p
        if request.stop:
            body["stop_sequences"] = request.stop
        if request.tools:
            body["tools"] = [
                {
                    "name": tool.get("name", "tool"),
                    "description": tool.get("description", ""),
                    "input_schema": (tool.get("function") or {}).get("parameters") or tool.get("input_schema") or {"type": "object"},
                }
                for tool in request.tools
            ]
        return body

    async def test_connection(self) -> dict[str, Any]:
        started = time.perf_counter()
        client = self.client(timeout=min(self.credentials.read_timeout, 30))
        try:
            payload = await client.request("GET", "/models")
            data = payload.get("data") if isinstance(payload, dict) else None
            count = len(data) if isinstance(data, list) else 0
            return {
                "ok": True,
                "message": f"Authenticated with Anthropic; {count} models available.",
                "latency_ms": int((time.perf_counter() - started) * 1000),
                "model_count": count,
            }
        except ProviderError as error:
            return {
                "ok": False,
                "message": error.detail,
                "error_category": error.category,
                "latency_ms": int((time.perf_counter() - started) * 1000),
                "details": error.details,
            }

    async def list_models(self) -> list[dict[str, Any]]:
        payload = await self.client().request("GET", "/models")
        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, list):
            raise ProviderError("Malformed model list from Anthropic", category=MALFORMED_RESPONSE, provider=self.provider_name)
        return [
            {
                "provider_model_id": item.get("id"),
                "display_name": item.get("display_name") or item.get("id"),
                "created_at": item.get("created_at"),
                "raw": item,
            }
            for item in data
            if isinstance(item, dict) and item.get("id")
        ]

    async def chat(self, request: ChatRequest) -> ChatResponse:
        self.guard(Operation.CHAT.value, request.model)
        started = time.perf_counter()
        client = self.client(model=request.model, timeout=request.timeout)
        payload = await client.request("POST", "/messages", json_body=self._body(request, stream=False))
        try:
            blocks = payload.get("content") or []
            text = "".join(block.get("text", "") for block in blocks if isinstance(block, dict) and block.get("type") == "text")
            tool_calls = [
                {"id": block.get("id"), "type": "function", "function": {"name": block.get("name"), "arguments": json.dumps(block.get("input", {}))}}
                for block in blocks
                if isinstance(block, dict) and block.get("type") == "tool_use"
            ]
            usage = payload.get("usage") or {}
            return ChatResponse(
                text=text,
                model=payload.get("model", request.model),
                finish_reason=payload.get("stop_reason"),
                prompt_tokens=usage.get("input_tokens"),
                completion_tokens=usage.get("output_tokens"),
                total_tokens=(usage.get("input_tokens") or 0) + (usage.get("output_tokens") or 0) if usage else None,
                usage_source="provider_reported" if usage else "unavailable",
                provider_request_id=payload.get("id"),
                latency_ms=int((time.perf_counter() - started) * 1000),
                tool_calls=tool_calls or None,
            )
        except (TypeError, AttributeError) as exc:
            raise ProviderError(
                f"Malformed Anthropic response: {exc}",
                category=MALFORMED_RESPONSE,
                provider=self.provider_name,
                model=request.model,
                details={"hints": hints_for(MALFORMED_RESPONSE)},
            ) from exc

    async def stream_chat(self, request: ChatRequest) -> AsyncIterator[ChatChunk]:  # type: ignore[override]
        self.guard(Operation.STREAMING.value, request.model)
        client = self.client(model=request.model, timeout=request.timeout)
        input_tokens = 0
        output_tokens = 0
        async for raw in client.stream_lines("/messages", json_body=self._body(request, stream=True)):
            try:
                event = json.loads(raw)
            except json.JSONDecodeError:
                continue
            etype = event.get("type")
            if etype == "message_start":
                usage = (event.get("message") or {}).get("usage") or {}
                input_tokens = usage.get("input_tokens", 0) or 0
            elif etype == "content_block_delta":
                delta = event.get("delta") or {}
                if delta.get("type") == "text_delta":
                    yield ChatChunk(delta=delta.get("text", ""))
            elif etype == "message_delta":
                usage = event.get("usage") or {}
                output_tokens = usage.get("output_tokens", output_tokens) or output_tokens
                yield ChatChunk(
                    finish_reason=(event.get("delta") or {}).get("stop_reason"),
                    usage={"prompt_tokens": input_tokens, "completion_tokens": output_tokens, "total_tokens": input_tokens + output_tokens},
                )
            elif etype == "message_stop":
                yield ChatChunk(
                    finish_reason="stop",
                    usage={"prompt_tokens": input_tokens, "completion_tokens": output_tokens, "total_tokens": input_tokens + output_tokens},
                )
            elif etype == "error":
                message = (event.get("error") or {}).get("message", "Anthropic stream error")
                raise ProviderError(message, category="upstream_server_error", provider=self.provider_name, model=request.model)
