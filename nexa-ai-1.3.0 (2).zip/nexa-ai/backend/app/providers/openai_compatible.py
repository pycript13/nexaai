"""OpenAI-compatible adapter (also the base for OpenAI, Azure, OpenRouter, Groq,
Mistral, Together, DeepSeek, Ollama's OpenAI-compatible endpoint and any
self-hosted gateway that speaks the same protocol).

Important: speaking "OpenAI-compatible" does NOT imply that every endpoint
exists. Each subclass narrows ``supports_operations`` to what the upstream API
actually documents, and every call is validated against those declared
operations before any HTTP traffic is generated.
"""
from __future__ import annotations

import base64
import json
import time
from collections.abc import AsyncIterator
from typing import Any

from app.core.errors import MALFORMED_RESPONSE, ProviderError, hints_for
from app.core.logging import get_logger
from app.providers.reasoning import InlineReasoningStream, split_inline_reasoning
from app.providers.base import (
    ChatChunk,
    ChatMessage,
    ChatRequest,
    ChatResponse,
    EmbeddingRequest,
    EmbeddingResponse,
    GeneratedImage,
    ImageGenerationRequest,
    ImageGenerationResponse,
    ProviderAdapter,
    SpeechRequest,
    SpeechResponse,
    TranscriptionRequest,
    TranscriptionResponse,
)
from app.providers.capabilities import Operation
from app.providers.http import ProviderHTTPClient, estimate_tokens

log = get_logger(__name__)


def _to_openai_messages(request: ChatRequest) -> list[dict[str, Any]]:
    messages: list[dict[str, Any]] = []
    if request.system:
        messages.append({"role": "system", "content": request.system})
    for msg in request.messages:
        item: dict[str, Any] = {"role": msg.role}
        if isinstance(msg.content, list):
            item["content"] = msg.content
        else:
            item["content"] = msg.content
        if msg.name:
            item["name"] = msg.name
        if msg.tool_call_id:
            item["tool_call_id"] = msg.tool_call_id
        if msg.tool_calls:
            item["tool_calls"] = msg.tool_calls
        messages.append(item)
    return messages


# ---------------------------------------------------------------- model list shapes --
# `/models` is *mostly* `{"data": [ … ]}` — but not always. Gateways in the wild answer with a bare
# list, with `{"models": […]}` (Ollama-style), or with `{"data": {"models": […]}}` (a proxy in
# front of a proxy). The strict parser that used to live here rejected all of those with
# "Model list endpoint returned an unexpected payload shape", which reads like a credential problem
# and leaves an operator unable to import any model. The shape is detected, reported, and the
# payload's real keys are quoted back when nothing usable is found.
def extract_model_items(payload: Any) -> tuple[list[dict[str, Any]], str]:
    """Return `(items, shape)` from the shapes seen in the wild (`[]` and `""` when unusable)."""
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)], "bare list"
    if isinstance(payload, dict):
        for key in ("data", "models", "result", "items", "available_models"):
            value = payload.get(key)
            if isinstance(value, list):
                return [item for item in value if isinstance(item, dict)], key
            if isinstance(value, dict):
                for inner in ("models", "data", "items"):
                    nested = value.get(inner)
                    if isinstance(nested, list):
                        return [item for item in nested if isinstance(item, dict)], f"{key}.{inner}"
    return [], ""


def model_identifier(item: dict[str, Any]) -> str:
    """The model id, whichever key this gateway uses."""
    for key in ("id", "name", "model", "model_id", "slug"):
        value = item.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _model_list_problem(payload: Any, provider_name: str) -> ProviderError:
    """A malformed model list that says what actually arrived."""
    # `_nexa_meta` is added by our own HTTP client; it is noise in an operator-facing message
    keys = (
        sorted(k for k in payload if not str(k).startswith("_nexa"))
        if isinstance(payload, dict) else []
    )
    try:
        excerpt = json.dumps(payload, ensure_ascii=False)[:300]
    except (TypeError, ValueError):
        excerpt = repr(payload)[:300]
    return ProviderError(
        "The provider's model list has an unexpected shape"
        + (f" (top-level keys: {', '.join(keys)})" if keys else f" ({type(payload).__name__})")
        + ".",
        category=MALFORMED_RESPONSE,
        provider=provider_name,
        details={
            "top_level_keys": keys,
            "received": excerpt,
            "expected": '{ "data": [ { "id": "model-name" } ] }  (or { "models": [ … ] }, or a bare list)',
            "hints": [
                "Check the base URL: it usually must end with /v1 (e.g. https://host/v1).",
                "Some gateways expose the catalogue on a different path — enter that URL and retry.",
                "This is a protocol mismatch, not a credential problem: the key itself was accepted.",
            ] + hints_for(MALFORMED_RESPONSE),
        },
    )


class OpenAICompatibleAdapter(ProviderAdapter):
    provider_type = "openai_compatible"
    display_name = "OpenAI-compatible"
    supports_operations = (
        Operation.CHAT.value,
        Operation.STREAMING.value,
        Operation.COMPLETION.value,
        Operation.EMBEDDINGS.value,
        Operation.IMAGE_GENERATION.value,
        Operation.AUDIO_TRANSCRIPTION.value,
        Operation.SPEECH_GENERATION.value,
    )
    requires_api_key = True
    supports_model_listing = True
    documentation_url = "https://platform.openai.com/docs/api-reference"

    def client(self, *, model: str | None = None, timeout: float | None = None) -> ProviderHTTPClient:
        c = self.credentials
        return ProviderHTTPClient(
            provider=c.provider_slug or self.provider_type,
            base_url=c.base_url or "https://api.openai.com/v1",
            api_key=c.api_key,
            extra_headers=dict(c.extra_headers or {}),
            connect_timeout=c.connect_timeout,
            read_timeout=timeout or c.read_timeout,
            max_retries=c.max_retries,
            requests_per_minute=c.requests_per_minute,
            max_concurrency=c.max_concurrency,
            network_preference=getattr(c, "network_preference", "auto"),
            proxy_url=c.proxy_url,
            model=model,
        )

    def common_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {}
        if self.credentials.organization_id:
            headers["OpenAI-Organization"] = self.credentials.organization_id
        if self.credentials.project_id:
            headers["OpenAI-Project"] = self.credentials.project_id
        return headers

    # -- connectivity --------------------------------------------------------
    async def test_connection(self) -> dict[str, Any]:
        started = time.perf_counter()
        client = self.client(timeout=min(self.credentials.read_timeout, 30))
        try:
            payload = await client.request("GET", "/models", headers=self.common_headers())
            items, shape = extract_model_items(payload)
            if not shape:
                raise _model_list_problem(payload, self.provider_name)
            unnamed = sum(1 for item in items if not model_identifier(item))
            next_step = (
                "Press Sync to import them — imported models stay hidden and unpublished until you "
                "verify them and publish."
                if items
                else "The provider answered, but its model list is empty for this key: check the key's scope."
            )
            return {
                "ok": True,
                "message": f"Authenticated successfully; {len(items)} model(s) visible at the provider ({shape}). {next_step}",
                "latency_ms": int((time.perf_counter() - started) * 1000),
                "model_count": len(items),
                "details": {
                    "endpoint": "/models",
                    "shape": shape,
                    "usable": len(items) - unnamed,
                    "without_identifier": unnamed,
                },
            }
        except ProviderError as error:
            return {
                "ok": False,
                "message": error.detail,
                "latency_ms": int((time.perf_counter() - started) * 1000),
                "error_category": error.category,
                "details": error.details,
            }

    async def list_models(self) -> list[dict[str, Any]]:
        client = self.client()
        payload = await client.request("GET", "/models", headers=self.common_headers())
        items, shape = extract_model_items(payload)
        if not shape:
            raise _model_list_problem(payload, self.provider_name)
        models: list[dict[str, Any]] = []
        for item in items:
            model_id = model_identifier(item)
            if not model_id:
                continue
            top_provider = item.get("top_provider") or {}
            models.append(
                {
                    "provider_model_id": model_id,
                    "display_name": str(item.get("name") or item.get("display_name") or model_id),
                    "created_at": item.get("created"),
                    "owned_by": item.get("owned_by"),
                    # Normalised catalogue fields (OpenRouter-shaped gateways send all of
                    # these; plain OpenAI-shaped ones send none and stay ``None`` — the
                    # catalogue importer never invents what the provider did not declare).
                    "description": str(item.get("description") or "")[:2000],
                    "context_window": item.get("context_length") or item.get("context_window"),
                    "max_output_tokens": top_provider.get("max_completion_tokens") or item.get("max_output_tokens"),
                    "pricing": item.get("pricing") if isinstance(item.get("pricing"), dict) else None,
                    "architecture": item.get("architecture") if isinstance(item.get("architecture"), dict) else None,
                    "supported_parameters": item.get("supported_parameters") if isinstance(item.get("supported_parameters"), list) else None,
                    "raw": {k: v for k, v in item.items() if k not in {"id", "name"}},
                }
            )
        return models

    # -- chat ----------------------------------------------------------------
    def _chat_body(self, request: ChatRequest, *, stream: bool) -> dict[str, Any]:
        body: dict[str, Any] = {
            "model": request.model,
            "messages": _to_openai_messages(request),
            "stream": stream,
        }
        if request.temperature is not None:
            body["temperature"] = request.temperature
        if request.top_p is not None:
            body["top_p"] = request.top_p
        if request.max_tokens is not None:
            body["max_tokens"] = request.max_tokens
        if request.stop:
            body["stop"] = request.stop
        if request.tools:
            body["tools"] = request.tools
        if request.tool_choice:
            body["tool_choice"] = request.tool_choice
        if request.presence_penalty is not None:
            body["presence_penalty"] = request.presence_penalty
        if request.frequency_penalty is not None:
            body["frequency_penalty"] = request.frequency_penalty
        if request.seed is not None:
            body["seed"] = request.seed
        if request.json_mode:
            body["response_format"] = {"type": "json_object"}
        elif request.response_format:
            body["response_format"] = request.response_format
        return body

    async def chat(self, request: ChatRequest) -> ChatResponse:
        self.guard(Operation.CHAT.value, request.model)
        started = time.perf_counter()
        client = self.client(model=request.model, timeout=request.timeout)
        payload = await client.request(
            "POST",
            "/chat/completions",
            json_body=self._chat_body(request, stream=False),
            headers=self.common_headers(),
        )
        latency_ms = int((time.perf_counter() - started) * 1000)
        try:
            choice = payload["choices"][0]
            message = choice.get("message") or {}
            text = message.get("content") or ""
            if isinstance(text, list):  # some gateways return content parts
                text = "".join(part.get("text", "") for part in text if isinstance(part, dict))
            usage = payload.get("usage") or {}
            reasoning = message.get("reasoning_content") or message.get("reasoning")
            # Some gateways (verified live with MiniMax) put the whole chain of thought inline in
            # `content` inside a `<think>…</think>` block; the raw scaffolding must never be shown
            # as the answer, so it is moved to the reasoning field here.
            text, reasoning = split_inline_reasoning(text, reasoning)
            return ChatResponse(
                text=text or "",
                model=payload.get("model", request.model),
                finish_reason=choice.get("finish_reason"),
                prompt_tokens=usage.get("prompt_tokens"),
                completion_tokens=usage.get("completion_tokens"),
                total_tokens=usage.get("total_tokens"),
                usage_source="provider_reported" if usage else "unavailable",
                provider_request_id=payload.get("id") or payload.get("_nexa_meta", {}).get("request_id"),
                latency_ms=latency_ms,
                tool_calls=message.get("tool_calls"),
                reasoning=reasoning,
                raw={"_nexa_meta": payload.get("_nexa_meta", {})},
            )
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError(
                f"Provider returned a malformed chat completion payload: {exc}",
                category=MALFORMED_RESPONSE,
                provider=self.provider_name,
                model=request.model,
                details={"hints": hints_for(MALFORMED_RESPONSE)},
            ) from exc

    async def stream_chat(self, request: ChatRequest) -> AsyncIterator[ChatChunk]:  # type: ignore[override]
        self.guard(Operation.STREAMING.value, request.model)
        client = self.client(model=request.model, timeout=request.timeout)
        body = self._chat_body(request, stream=True)
        body["stream_options"] = {"include_usage": True}
        splitter = InlineReasoningStream()
        async for raw in client.stream_lines("/chat/completions", json_body=body, headers=self.common_headers()):
            try:
                event = json.loads(raw)
            except json.JSONDecodeError:
                continue
            usage = event.get("usage")
            choices = event.get("choices") or []
            if not choices:
                if usage:
                    yield ChatChunk(usage={
                        "prompt_tokens": usage.get("prompt_tokens") or 0,
                        "completion_tokens": usage.get("completion_tokens") or 0,
                        "total_tokens": usage.get("total_tokens") or 0,
                    }, provider_request_id=event.get("id"))
                continue
            choice = choices[0]
            delta = choice.get("delta") or {}
            content = delta.get("content") or ""
            if isinstance(content, list):
                content = "".join(part.get("text", "") for part in content if isinstance(part, dict))
            visible, inline_reasoning = splitter.feed(content or "")
            yield ChatChunk(
                delta=visible,
                reasoning_delta=(delta.get("reasoning_content") or delta.get("reasoning") or "") + inline_reasoning,
                finish_reason=choice.get("finish_reason"),
                provider_request_id=event.get("id"),
                tool_call_delta=delta.get("tool_calls"),
            )
        # release a held-back tail (a half-received tag, or an unterminated `<think>` block)
        tail_visible, tail_reasoning = splitter.flush()
        if tail_visible or tail_reasoning:
            yield ChatChunk(delta=tail_visible, reasoning_delta=tail_reasoning)

    # -- embeddings ----------------------------------------------------------
    async def embed(self, request: EmbeddingRequest) -> EmbeddingResponse:
        self.guard(Operation.EMBEDDINGS.value, request.model)
        started = time.perf_counter()
        client = self.client(model=request.model)
        body: dict[str, Any] = {"model": request.model, "input": request.inputs}
        if request.dimensions:
            body["dimensions"] = request.dimensions
        payload = await client.request("POST", "/embeddings", json_body=body, headers=self.common_headers())
        try:
            vectors = [item["embedding"] for item in payload["data"]]
        except (KeyError, TypeError) as exc:
            raise ProviderError("Malformed embeddings response", category=MALFORMED_RESPONSE, provider=self.provider_name) from exc
        usage = payload.get("usage") or {}
        return EmbeddingResponse(
            vectors=vectors,
            total_tokens=usage.get("total_tokens"),
            usage_source="provider_reported" if usage else "unavailable",
            provider_request_id=payload.get("id"),
            latency_ms=int((time.perf_counter() - started) * 1000),
        )

    # -- images --------------------------------------------------------------
    async def generate_image(self, request: ImageGenerationRequest) -> ImageGenerationResponse:
        self.guard(Operation.IMAGE_GENERATION.value, request.model)
        started = time.perf_counter()
        client = self.client(model=request.model, timeout=max(self.credentials.read_timeout, 120))
        body: dict[str, Any] = {
            "model": request.model,
            "prompt": request.prompt,
            "n": request.n,
            "response_format": request.response_format,
        }
        if request.size:
            body["size"] = request.size
        if request.quality:
            body["quality"] = request.quality
        if request.style:
            body["style"] = request.style
        if request.seed is not None:
            body["seed"] = request.seed
        body.update(request.extra or {})
        payload = await client.request("POST", "/images/generations", json_body=body, headers=self.common_headers())
        images: list[GeneratedImage] = []
        for item in payload.get("data", []) or []:
            images.append(
                GeneratedImage(
                    b64_json=item.get("b64_json"),
                    url=item.get("url"),
                    revised_prompt=item.get("revised_prompt"),
                    mime_type="image/png",
                )
            )
        usage = payload.get("usage") or {}
        return ImageGenerationResponse(
            images=images,
            provider_request_id=payload.get("id") or payload.get("_nexa_meta", {}).get("request_id"),
            latency_ms=int((time.perf_counter() - started) * 1000),
            usage_source="provider_reported" if usage else "unavailable",
            raw={"_nexa_meta": payload.get("_nexa_meta", {}), "usage": usage or None},
        )

    # -- audio ---------------------------------------------------------------
    async def transcribe(self, request: TranscriptionRequest) -> TranscriptionResponse:
        self.guard(Operation.AUDIO_TRANSCRIPTION.value, request.model)
        started = time.perf_counter()
        client = self.client(model=request.model, timeout=max(self.credentials.read_timeout, 180))
        with open(request.file_path, "rb") as handle:
            files = {"file": (request.file_path.split("/")[-1], handle.read())}
        data: dict[str, Any] = {"model": request.model, "response_format": request.response_format}
        if request.language:
            data["language"] = request.language
        if request.prompt:
            data["prompt"] = request.prompt
        if request.temperature is not None:
            data["temperature"] = request.temperature
        payload = await client.request(
            "POST", "/audio/transcriptions", data=data, files=files, headers=self.common_headers()
        )
        text = payload.get("text") if isinstance(payload, dict) else str(payload)
        if text is None:
            raise ProviderError("Malformed transcription response", category=MALFORMED_RESPONSE, provider=self.provider_name)
        return TranscriptionResponse(
            text=text,
            language=payload.get("language") if isinstance(payload, dict) else None,
            duration_seconds=payload.get("duration") if isinstance(payload, dict) else None,
            segments=payload.get("segments") if isinstance(payload, dict) else None,
            provider_request_id=payload.get("_nexa_meta", {}).get("request_id") if isinstance(payload, dict) else None,
            latency_ms=int((time.perf_counter() - started) * 1000),
            usage_source="provider_reported" if isinstance(payload, dict) and payload.get("duration") else "estimated",
        )

    async def synthesize(self, request: SpeechRequest) -> SpeechResponse:
        self.guard(Operation.SPEECH_GENERATION.value, request.model)
        started = time.perf_counter()
        client = self.client(model=request.model, timeout=max(self.credentials.read_timeout, 180))
        body: dict[str, Any] = {
            "model": request.model,
            "input": request.text,
            "voice": request.voice or "alloy",
            "response_format": request.response_format,
        }
        if request.speed:
            body["speed"] = request.speed
        response = await client.request(
            "POST", "/audio/speech", json_body=body, headers=self.common_headers(), expect_json=False, raw_response=True
        )
        audio = response.content
        if not audio:
            raise ProviderError("Speech endpoint returned an empty body", category=MALFORMED_RESPONSE, provider=self.provider_name)
        mime = response.headers.get("content-type", "audio/mpeg")
        return SpeechResponse(
            audio_bytes=audio,
            mime_type=mime,
            latency_ms=int((time.perf_counter() - started) * 1000),
            usage_source="estimated",
            duration_seconds=None,
            provider_request_id=response.headers.get("x-request-id"),
        )


class OpenAIAdapter(OpenAICompatibleAdapter):
    provider_type = "openai"
    display_name = "OpenAI"
    documentation_url = "https://platform.openai.com/docs/api-reference"


class AzureOpenAIAdapter(OpenAICompatibleAdapter):
    """Azure OpenAI uses deployment names in the path and ``api-key`` header."""

    provider_type = "azure_openai"
    display_name = "Azure OpenAI"
    documentation_url = "https://learn.microsoft.com/azure/ai-services/openai/"

    def url(self, path: str) -> str:  # pragma: no cover - exercised in provider tests
        base = self.credentials.base_url.rstrip("/")
        if path in ("/models", "models"):
            return f"{base}/models?api-version={self.credentials.api_version or '2024-08-01-preview'}"
        return f"{base}{path}"

    def client(self, *, model: str | None = None, timeout: float | None = None) -> ProviderHTTPClient:
        client = super().client(model=model, timeout=timeout)
        client.auth_header = "api-key"
        client.auth_prefix = ""
        return client

    def _deployment_path(self, model: str, suffix: str) -> str:
        version = self.credentials.api_version or "2024-08-01-preview"
        return f"/openai/deployments/{model}{suffix}?api-version={version}"

    async def chat(self, request: ChatRequest) -> ChatResponse:
        self.guard(Operation.CHAT.value, request.model)
        started = time.perf_counter()
        client = self.client(model=request.model, timeout=request.timeout)
        payload = await client.request(
            "POST",
            self._deployment_path(request.model, "/chat/completions"),
            json_body=self._chat_body(request, stream=False),
        )
        latency_ms = int((time.perf_counter() - started) * 1000)
        choice = (payload.get("choices") or [{}])[0]
        message = choice.get("message") or {}
        usage = payload.get("usage") or {}
        return ChatResponse(
            text=message.get("content") or "",
            model=payload.get("model", request.model),
            finish_reason=choice.get("finish_reason"),
            prompt_tokens=usage.get("prompt_tokens"),
            completion_tokens=usage.get("completion_tokens"),
            total_tokens=usage.get("total_tokens"),
            usage_source="provider_reported" if usage else "unavailable",
            provider_request_id=payload.get("id"),
            latency_ms=latency_ms,
        )

    async def stream_chat(self, request: ChatRequest) -> AsyncIterator[ChatChunk]:  # type: ignore[override]
        self.guard(Operation.STREAMING.value, request.model)
        client = self.client(model=request.model, timeout=request.timeout)
        body = self._chat_body(request, stream=True)
        async for raw in client.stream_lines(self._deployment_path(request.model, "/chat/completions"), json_body=body):
            try:
                event = json.loads(raw)
            except json.JSONDecodeError:
                continue
            for choice in event.get("choices") or []:
                delta = choice.get("delta") or {}
                yield ChatChunk(
                    delta=delta.get("content") or "",
                    finish_reason=choice.get("finish_reason"),
                    usage=event.get("usage"),
                    provider_request_id=event.get("id"),
                )


class OpenRouterAdapter(OpenAICompatibleAdapter):
    provider_type = "openrouter"
    display_name = "OpenRouter"
    documentation_url = "https://openrouter.ai/docs"


class GroqAdapter(OpenAICompatibleAdapter):
    provider_type = "groq"
    display_name = "Groq"
    documentation_url = "https://console.groq.com/docs"


class MistralAdapter(OpenAICompatibleAdapter):
    provider_type = "mistral"
    display_name = "Mistral AI"
    documentation_url = "https://docs.mistral.ai/"


class TogetherAdapter(OpenAICompatibleAdapter):
    provider_type = "together"
    display_name = "Together AI"
    documentation_url = "https://docs.together.ai/"


class DeepSeekAdapter(OpenAICompatibleAdapter):
    provider_type = "deepseek"
    display_name = "DeepSeek"
    documentation_url = "https://api-docs.deepseek.com/"


class OllamaAdapter(OpenAICompatibleAdapter):
    """Ollama exposes both a native API and an OpenAI-compatible bridge.

    Self-hosted Ollama usually requires no API key and often lives on a private
    network — operators must explicitly allow that destination
    (NEXA_PROVIDER_ALLOWED_HOSTS or NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS).
    """

    provider_type = "ollama"
    display_name = "Ollama (self-hosted)"
    requires_api_key = False
    documentation_url = "https://github.com/ollama/ollama/blob/main/docs/api.md"

    async def test_connection(self) -> dict[str, Any]:
        started = time.perf_counter()
        client = self.client(timeout=min(self.credentials.read_timeout, 20))
        try:
            payload = await client.request("GET", "/models")
            data = payload.get("data") if isinstance(payload, dict) else []
            return {
                "ok": True,
                "message": f"Ollama reachable; {len(data or [])} models installed.",
                "latency_ms": int((time.perf_counter() - started) * 1000),
                "model_count": len(data or []),
            }
        except ProviderError as error:
            return {
                "ok": False,
                "message": error.detail,
                "latency_ms": int((time.perf_counter() - started) * 1000),
                "error_category": error.category,
                "details": error.details,
            }
