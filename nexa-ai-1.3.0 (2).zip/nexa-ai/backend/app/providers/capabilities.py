"""Operation + capability vocabulary shared by adapters, models, and the UI."""
from __future__ import annotations

from enum import Enum


class Operation(str, Enum):
    CHAT = "chat"
    STREAMING = "streaming"
    COMPLETION = "completion"
    EMBEDDINGS = "embeddings"
    IMAGE_GENERATION = "image_generation"
    IMAGE_UNDERSTANDING = "image_understanding"
    AUDIO_TRANSCRIPTION = "audio_transcription"
    SPEECH_GENERATION = "speech_generation"
    VIDEO_GENERATION = "video_generation"
    RERANK = "rerank"
    TOOLS = "tools"
    JSON_MODE = "json_mode"
    REASONING = "reasoning"
    DOCUMENT_QA = "document_qa"


ALL_OPERATIONS = tuple(op.value for op in Operation)

OPERATION_LABELS: dict[str, dict[str, str]] = {
    Operation.CHAT.value: {"en": "Chat", "fa": "گفتگو", "ar": "محادثة", "ckb": "گفتوگۆ"},
    Operation.STREAMING.value: {"en": "Streaming", "fa": "پاسخ جریانی", "ar": "بث مباشر", "ckb": "پەخشی ڕاستەوخۆ"},
    Operation.COMPLETION.value: {"en": "Text completion", "fa": "تکمیل متن", "ar": "إكمال النص", "ckb": "تەواوکردنی دەق"},
    Operation.EMBEDDINGS.value: {"en": "Embeddings", "fa": "برداری‌سازی", "ar": "التضمينات", "ckb": "ئیمبێدینگ"},
    Operation.IMAGE_GENERATION.value: {"en": "Image generation", "fa": "تولید تصویر", "ar": "توليد الصور", "ckb": "بەرهەمهێنانی وێنە"},
    Operation.IMAGE_UNDERSTANDING.value: {"en": "Image understanding", "fa": "تحلیل تصویر", "ar": "فهم الصور", "ckb": "تێگەیشتن لە وێنە"},
    Operation.AUDIO_TRANSCRIPTION.value: {"en": "Audio transcription", "fa": "رونویسی صدا", "ar": "تحويل الصوت إلى نص", "ckb": "دەنگ بۆ دەق"},
    Operation.SPEECH_GENERATION.value: {"en": "Speech generation", "fa": "تولید گفتار", "ar": "توليد الكلام", "ckb": "بەرهەمهێنانی دەنگ"},
    Operation.VIDEO_GENERATION.value: {"en": "Video generation", "fa": "تولید ویدئو", "ar": "توليد الفيديو", "ckb": "بەرهەمهێنانی ڤیدیۆ"},
    Operation.RERANK.value: {"en": "Reranking", "fa": "بازچینش", "ar": "إعادة الترتيب", "ckb": "ڕیزکردنەوە"},
    Operation.TOOLS.value: {"en": "Tool calling", "fa": "فراخوانی ابزار", "ar": "استدعاء الأدوات", "ckb": "بانگکردنی ئامراز"},
    Operation.JSON_MODE.value: {"en": "Structured JSON output", "fa": "خروجی JSON ساخت‌یافته", "ar": "إخراج JSON منظم", "ckb": "دەرچووی JSON"},
    Operation.REASONING.value: {"en": "Reasoning", "fa": "استدلال", "ar": "الاستدلال", "ckb": "بیرکردنەوە"},
    Operation.DOCUMENT_QA.value: {"en": "Document question answering", "fa": "پرسش و پاسخ اسناد", "ar": "أسئلة المستندات", "ckb": "پرسیار لە بەڵگەنامە"},
}

MODULES = {
    "chat": {"label": "General chat", "operations": [Operation.CHAT.value, Operation.STREAMING.value]},
    "coding": {"label": "Coding assistant", "operations": [Operation.CHAT.value, Operation.STREAMING.value, Operation.REASONING.value]},
    "image": {"label": "Image tools", "operations": [Operation.IMAGE_GENERATION.value, Operation.IMAGE_UNDERSTANDING.value]},
    "documents": {"label": "Documents", "operations": [Operation.CHAT.value, Operation.DOCUMENT_QA.value]},
    "translation": {"label": "Translation", "operations": [Operation.CHAT.value]},
    "data": {"label": "Data analysis", "operations": [Operation.CHAT.value]},
    "audio": {"label": "Audio", "operations": [Operation.AUDIO_TRANSCRIPTION.value, Operation.SPEECH_GENERATION.value]},
    "video": {"label": "Video", "operations": [Operation.VIDEO_GENERATION.value]},
}


def operation_supported(model_capabilities: list[str] | None, operation: str) -> bool:
    """A model supports an op only if it was explicitly verified/declared."""
    caps = set(model_capabilities or [])
    if operation in caps:
        return True
    # streaming is implied by chat support for models flagged as streaming-capable
    return False


def capability_union(*sets: list[str] | None) -> list[str]:
    out: set[str] = set()
    for s in sets:
        out.update(s or [])
    return sorted(out)
