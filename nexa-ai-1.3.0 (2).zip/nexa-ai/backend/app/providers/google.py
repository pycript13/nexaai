"""Google Gemini adapter (generativelanguage API): chat, streaming, vision,
embeddings and Imagen image generation."""
from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator
from typing import Any

from app.core.errors import MALFORMED_RESPONSE, ProviderError
from app.providers.base import (
    ChatChunk,
    ChatRequest,
    ChatResponse,
    EmbeddingRequest,
    EmbeddingResponse,
    GeneratedImage,
    ImageGenerationRequest,
    ImageGenerationResponse,
    ProviderAdapter,
)
from app.providers.capabilities import Operation
from app.providers.http import ProviderHTTPClient

DEFAULT_BASE = "https://generativelanguage.googleapis.com/v1beta"


class GoogleAdapter(ProviderAdapter):
    provider_type = "google"
    display_name = "Google Gemini"
    supports_operations = (
        Operation.CHAT.value,
        Operation.STREAMING.value,
        Operation.IMAGE_UNDERSTANDING.value,
        Operation.EMBEDDINGS.value,
        Operation.IMAGE_GENERATION.value,
        Operation.TOOLS.value,
    )
    requires_api_key = True
    documentation_url = "https://ai.google.dev/api"

    def client(self, *, model: str | None = None, timeout: float | None = None) -> ProviderHTTPClient:
        c = self.credentials
        return ProviderHTTPClient(
            provider=c.provider_slug or self.provider_type,
            base_url=c.base_url or DEFAULT_BASE,
            api_key=c.api_key,
            extra_headers=c.extra_headers or {},
            connect_timeout=c.connect_timeout,
            read_timeout=timeout or c.read_timeout,
            max_retries=c.max_retries,
            requests_per_minute=c.requests_per_minute,
            max_concurrency=c.max_concurrency,
            network_preference=getattr(c, "network_preference", "auto"),
            proxy_url=c.proxy_url,
            auth_header="x-goog-api-key",
            auth_prefix="",
            model=model,
        )

    def _contents(self, request: ChatRequest) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
        contents: list[dict[str, Any]] = []
        for msg in request.messages:
            parts: list[dict[str, Any]] = []
            if isinstance(msg.content, str):
                parts.append({"text": msg.content})
            else:
                for part in msg.content:
                    if part.get("type") == "text":
                        parts.append({"text": part.get("text", "")})
                    elif part.get("type") == "image_url":
                        url = (part.get("image_url") or {}).get("url", "")
                        if url.startswith("data:"):
                            header, _, b64 = url.partition(",")
                            mime = header.split(";")[0].replace("data:", "") or "image/png"
                            parts.append({"inline_data": {"mime_type": mime, "data": b64}})
                        else:
                            parts.append({"file_data": {"mime_type": "image/jpeg", "file_uri": url}})
            contents.append({"role": "model" if msg.role == "assistant" else "user", "parts": parts})
        system = {"parts": [{"text": request.system}]} if request.system else None
        return contents, system

    def _body(self, request: ChatRequest) -> dict[str, Any]:
        contents, system = self._contents(request)
        body: dict[str, Any] = {"contents": contents}
        if system:
            body["systemInstruction"] = system
        generation: dict[str, Any] = {}
        if request.temperature is not None:
            generation["temperature"] = request.temperature
        if request.top_p is not None:
            generation["topP"] = request.top_p
        if request.max_tokens is not None:
            generation["maxOutputTokens"] = request.max_tokens
        if request.stop:
            generation["stopSequences"] = request.stop
        if request.json_mode:
            generation["responseMimeType"] = "application/json"
        if generation:
            body["generationConfig"] = generation
        if request.tools:
            body["tools"] = [{"functionDeclarations": [t.get("function", t) for t in request.tools]}]
        return body

    async def test_connection(self) -> dict[str, Any]:
        started = time.perf_counter()
        client = self.client(timeout=min(self.credentials.read_timeout, 30))
        try:
            payload = await client.request("GET", "/models")
            models = payload.get("models") if isinstance(payload, dict) else []
            return {
                "ok": True,
                "message": f"Gemini API reachable; {len(models or [])} models visible.",
                "latency_ms": int((time.perf_counter() - started) * 1000),
                "model_count": len(models or []),
            }
        except ProviderError as error:
            return {
                "ok": False,
                "message": error.detail,
                "error_category": error.category,
                "latency_ms": int((time.perf_counter() - started) * 1000),
                "details": error.details,
            }

    async def list_models(self) -> list[dict[str, Any]]:
        payload = await self.client().request("GET", "/models", params={"pageSize": 200})
        items = payload.get("models") if isinstance(payload, dict) else None
        if not isinstance(items, list):
            raise ProviderError("Malformed Gemini model list", category=MALFORMED_RESPONSE, provider=self.provider_name)
        out = []
        for item in items:
            name = item.get("name", "")
            out.append(
                {
                    "provider_model_id": name.split("/")[-1],
                    "display_name": item.get("displayName") or name.split("/")[-1],
                    "context_window": item.get("inputTokenLimit"),
                    "max_output_tokens": item.get("outputTokenLimit"),
                    "raw": item,
                }
            )
        return out

    async def chat(self, request: ChatRequest) -> ChatResponse:
        self.guard(Operation.CHAT.value, request.model)
        started = time.perf_counter()
        client = self.client(model=request.model, timeout=request.timeout)
        payload = await client.request("POST", f"/models/{request.model}:generateContent", json_body=self._body(request))
        try:
            candidates = payload.get("candidates") or []
            parts = (candidates[0].get("content") or {}).get("parts", []) if candidates else []
            text = "".join(part.get("text", "") for part in parts if isinstance(part, dict))
            usage = payload.get("usageMetadata") or {}
            return ChatResponse(
                text=text,
                model=request.model,
                finish_reason=(candidates[0].get("finishReason") if candidates else None),
                prompt_tokens=usage.get("promptTokenCount"),
                completion_tokens=usage.get("candidatesTokenCount"),
                total_tokens=usage.get("totalTokenCount"),
                usage_source="provider_reported" if usage else "unavailable",
                latency_ms=int((time.perf_counter() - started) * 1000),
                provider_request_id=payload.get("_nexa_meta", {}).get("request_id"),
            )
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError(f"Malformed Gemini response: {exc}", category=MALFORMED_RESPONSE, provider=self.provider_name) from exc

    async def stream_chat(self, request: ChatRequest) -> AsyncIterator[ChatChunk]:  # type: ignore[override]
        self.guard(Operation.STREAMING.value, request.model)
        client = self.client(model=request.model, timeout=request.timeout)
        prompt_tokens = completion_tokens = 0
        async for raw in client.stream_lines(
            f"/models/{request.model}:streamGenerateContent?alt=sse", json_body=self._body(request)
        ):
            try:
                event = json.loads(raw)
            except json.JSONDecodeError:
                continue
            for candidate in event.get("candidates") or []:
                for part in (candidate.get("content") or {}).get("parts", []):
                    if part.get("text"):
                        yield ChatChunk(delta=part["text"])
                if candidate.get("finishReason"):
                    yield ChatChunk(finish_reason=candidate["finishReason"])
            usage = event.get("usageMetadata") or {}
            if usage:
                prompt_tokens = usage.get("promptTokenCount", prompt_tokens) or prompt_tokens
                completion_tokens = usage.get("candidatesTokenCount", completion_tokens) or completion_tokens
                yield ChatChunk(usage={"prompt_tokens": prompt_tokens, "completion_tokens": completion_tokens,
                                       "total_tokens": usage.get("totalTokenCount") or (prompt_tokens + completion_tokens)})

    async def embed(self, request: EmbeddingRequest) -> EmbeddingResponse:
        self.guard(Operation.EMBEDDINGS.value, request.model)
        client = self.client(model=request.model)
        body = {"requests": [{"model": f"models/{request.model}", "content": {"parts": [{"text": text}]}} for text in request.inputs]}
        payload = await client.request("POST", f"/models/{request.model}:batchEmbedContents", json_body=body)
        embeddings = payload.get("embeddings") or []
        return EmbeddingResponse(
            vectors=[e.get("values", []) for e in embeddings],
            usage_source="unavailable",
        )

    async def generate_image(self, request: ImageGenerationRequest) -> ImageGenerationResponse:
        self.guard(Operation.IMAGE_GENERATION.value, request.model)
        started = time.perf_counter()
        client = self.client(model=request.model, timeout=max(self.credentials.read_timeout, 180))
        body = {
            "instances": [{"prompt": request.prompt}],
            "parameters": {"sampleCount": max(1, request.n)},
        }
        payload = await client.request("POST", f"/models/{request.model}:predict", json_body=body)
        images: list[GeneratedImage] = []
        for prediction in payload.get("predictions", []) or []:
            b64 = prediction.get("bytesBase64Encoded") or prediction.get("image", {}).get("imageBytes")
            if b64:
                images.append(GeneratedImage(b64_json=b64, mime_type=prediction.get("mimeType", "image/png")))
        return ImageGenerationResponse(
            images=images,
            latency_ms=int((time.perf_counter() - started) * 1000),
            usage_source="provider_reported",
        )
