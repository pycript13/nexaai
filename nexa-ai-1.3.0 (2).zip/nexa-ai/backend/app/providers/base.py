"""Provider adapter interface.

Every adapter declares the operations it genuinely implements. Adapters do NOT
guess capabilities from model names: the catalog stores verified capabilities and
an operation that the adapter cannot perform raises ``UnsupportedOperation``.
"""
from __future__ import annotations

import abc
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any

from app.core.errors import ProviderError, hints_for
from app.providers.capabilities import Operation


class UnsupportedOperation(ProviderError):
    def __init__(self, operation: str, *, provider: str | None = None, model: str | None = None, detail: str | None = None):
        super().__init__(
            detail
            or f"Provider '{provider or 'adapter'}' does not implement the '{operation}' operation. "
            "Choose a model whose verified capabilities include this operation.",
            category="unsupported_operation",
            provider=provider,
            model=model,
            retryable=False,
            details={"operation": operation, "hints": hints_for("unsupported_operation")},
        )
        self.operation = operation


@dataclass
class ProviderCredentials:
    """Runtime credentials + transport configuration for a provider row."""

    api_key: str = ""
    base_url: str = ""
    organization_id: str | None = None
    project_id: str | None = None
    api_version: str | None = None
    region: str | None = None
    extra_headers: dict[str, str] = field(default_factory=dict)
    extra_config: dict[str, Any] = field(default_factory=dict)
    proxy_url: str | None = None
    network_preference: str = "auto"          # auto | ipv4 | ipv6
    connect_timeout: float = 10.0
    read_timeout: float = 120.0
    max_retries: int = 2
    requests_per_minute: int = 0
    max_concurrency: int = 4
    provider_slug: str = ""
    provider_name: str = ""


@dataclass
class ChatMessage:
    role: str
    content: str | list[dict[str, Any]] = ""
    name: str | None = None
    tool_call_id: str | None = None
    tool_calls: list[dict[str, Any]] | None = None

    def text(self) -> str:
        if isinstance(self.content, str):
            return self.content
        parts = [p.get("text", "") for p in self.content if isinstance(p, dict) and p.get("type") == "text"]
        return "\n".join(part for part in parts if part)


@dataclass
class ChatRequest:
    model: str
    messages: list[ChatMessage]
    system: str | None = None
    temperature: float | None = None
    top_p: float | None = None
    max_tokens: int | None = None
    stop: list[str] | None = None
    stream: bool = False
    tools: list[dict[str, Any]] | None = None
    tool_choice: str | dict | None = None
    response_format: dict[str, Any] | None = None
    json_mode: bool = False
    presence_penalty: float | None = None
    frequency_penalty: float | None = None
    seed: int | None = None
    timeout: float | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ChatResponse:
    text: str = ""
    model: str = ""
    finish_reason: str | None = None
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    total_tokens: int | None = None
    usage_source: str = "unavailable"          # provider_reported | estimated | unavailable
    provider_request_id: str | None = None
    latency_ms: int | None = None
    tool_calls: list[dict[str, Any]] | None = None
    raw: dict[str, Any] | None = None
    reasoning: str | None = None


@dataclass
class ChatChunk:
    delta: str = ""
    reasoning_delta: str = ""
    finish_reason: str | None = None
    usage: dict[str, int] | None = None
    provider_request_id: str | None = None
    tool_call_delta: dict[str, Any] | None = None


@dataclass
class ImageGenerationRequest:
    model: str
    prompt: str
    n: int = 1
    size: str | None = None
    quality: str | None = None
    style: str | None = None
    response_format: str = "b64_json"
    negative_prompt: str | None = None
    seed: int | None = None
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class GeneratedImage:
    b64_json: str | None = None
    url: str | None = None
    revised_prompt: str | None = None
    mime_type: str = "image/png"
    width: int | None = None
    height: int | None = None


@dataclass
class ImageGenerationResponse:
    images: list[GeneratedImage] = field(default_factory=list)
    provider_request_id: str | None = None
    latency_ms: int | None = None
    usage_source: str = "provider_reported"
    raw: dict[str, Any] | None = None
    estimated_cost_micro: int | None = None


@dataclass
class TranscriptionRequest:
    model: str
    file_path: str
    language: str | None = None
    prompt: str | None = None
    temperature: float | None = None
    response_format: str = "json"


@dataclass
class TranscriptionResponse:
    text: str = ""
    language: str | None = None
    duration_seconds: float | None = None
    segments: list[dict[str, Any]] | None = None
    provider_request_id: str | None = None
    latency_ms: int | None = None
    usage_source: str = "provider_reported"
    raw: dict[str, Any] | None = None


@dataclass
class SpeechRequest:
    model: str
    text: str
    voice: str | None = None
    response_format: str = "mp3"
    speed: float | None = None
    language: str | None = None


@dataclass
class SpeechResponse:
    audio_bytes: bytes = b""
    mime_type: str = "audio/mpeg"
    provider_request_id: str | None = None
    latency_ms: int | None = None
    usage_source: str = "unavailable"
    duration_seconds: float | None = None
    raw: dict[str, Any] | None = None


@dataclass
class EmbeddingRequest:
    model: str
    inputs: list[str]
    dimensions: int | None = None


@dataclass
class EmbeddingResponse:
    vectors: list[list[float]] = field(default_factory=list)
    total_tokens: int | None = None
    usage_source: str = "provider_reported"
    provider_request_id: str | None = None
    latency_ms: int | None = None


@dataclass
class RerankRequest:
    model: str
    query: str
    documents: list[str]
    top_n: int | None = None


@dataclass
class RerankResponse:
    results: list[dict[str, Any]] = field(default_factory=list)
    usage_source: str = "unavailable"
    provider_request_id: str | None = None


@dataclass
class VideoGenerationRequest:
    model: str
    prompt: str
    image_url: str | None = None
    duration_seconds: float | None = None
    aspect_ratio: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class VideoGenerationResponse:
    job_id: str | None = None
    status: str = "pending"
    video_url: str | None = None
    progress: int | None = None
    provider_request_id: str | None = None
    raw: dict[str, Any] | None = None


class ProviderAdapter(abc.ABC):
    """Base class for all provider adapters."""

    provider_type: str = "custom"
    display_name: str = "Custom provider"
    supports_operations: tuple[str, ...] = ()
    requires_api_key: bool = True
    supports_model_listing: bool = True
    documentation_url: str = ""
    notes: str = ""

    def __init__(self, credentials: ProviderCredentials) -> None:
        self.credentials = credentials
        self.provider_name = credentials.provider_name or credentials.provider_slug or self.provider_type

    # -- capability declaration --------------------------------------------
    def supports(self, operation: str) -> bool:
        return operation in self.supports_operations

    def guard(self, operation: str, model: str | None = None) -> None:
        if not self.supports(operation):
            raise UnsupportedOperation(operation, provider=self.provider_name, model=model)

    def capabilities(self) -> dict[str, Any]:
        return {
            "provider_type": self.provider_type,
            "display_name": self.display_name,
            "operations": list(self.supports_operations),
            "requires_api_key": self.requires_api_key,
            "supports_model_listing": self.supports_model_listing,
            "documentation_url": self.documentation_url,
            "notes": self.notes,
        }

    # -- operations ---------------------------------------------------------
    @abc.abstractmethod
    async def test_connection(self) -> dict[str, Any]:
        """Perform a *real* minimal request. Returns a dict with at least
        ``ok``, ``message``, ``latency_ms`` and optionally ``details``."""

    async def list_models(self) -> list[dict[str, Any]]:
        self.guard("list_models")
        raise UnsupportedOperation("list_models", provider=self.provider_name)  # pragma: no cover

    async def chat(self, request: ChatRequest) -> ChatResponse:
        raise UnsupportedOperation(Operation.CHAT.value, provider=self.provider_name, model=request.model)

    async def stream_chat(self, request: ChatRequest) -> AsyncIterator[ChatChunk]:  # type: ignore[override]
        raise UnsupportedOperation(Operation.STREAMING.value, provider=self.provider_name, model=request.model)
        yield ChatChunk()  # pragma: no cover - makes this an async generator

    async def generate_image(self, request: ImageGenerationRequest) -> ImageGenerationResponse:
        raise UnsupportedOperation(Operation.IMAGE_GENERATION.value, provider=self.provider_name, model=request.model)

    async def transcribe(self, request: TranscriptionRequest) -> TranscriptionResponse:
        raise UnsupportedOperation(Operation.AUDIO_TRANSCRIPTION.value, provider=self.provider_name, model=request.model)

    async def synthesize(self, request: SpeechRequest) -> SpeechResponse:
        raise UnsupportedOperation(Operation.SPEECH_GENERATION.value, provider=self.provider_name, model=request.model)

    async def embed(self, request: EmbeddingRequest) -> EmbeddingResponse:
        raise UnsupportedOperation(Operation.EMBEDDINGS.value, provider=self.provider_name, model=request.model)

    async def rerank(self, request: RerankRequest) -> RerankResponse:
        raise UnsupportedOperation(Operation.RERANK.value, provider=self.provider_name, model=request.model)

    async def generate_video(self, request: VideoGenerationRequest) -> VideoGenerationResponse:
        raise UnsupportedOperation(Operation.VIDEO_GENERATION.value, provider=self.provider_name, model=request.model)

    async def video_status(self, job_id: str) -> VideoGenerationResponse:
        raise UnsupportedOperation("video_status", provider=self.provider_name)

    async def aclose(self) -> None:
        return None
