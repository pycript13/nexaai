"""Nexa AI backend application package."""

__version__ = "1.3.0"
