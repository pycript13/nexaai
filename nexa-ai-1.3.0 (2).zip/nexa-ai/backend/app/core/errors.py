"""Uniform error taxonomy and API error responses.

Provider-facing error categories are shared between adapters, the admin model
tester, usage records and the UI so that "invalid API key" is never confused
with "model not found" or "provider timeout".
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

# --- error categories (used for provider calls, jobs and usage records) -----
CONNECTIVITY = "provider_connectivity"
AUTHENTICATION = "authentication"
AUTHORIZATION = "authorization"
RATE_LIMIT = "rate_limit"
QUOTA_EXHAUSTED = "quota_exhausted"
UNSUPPORTED_OPERATION = "unsupported_operation"
MODEL_NOT_FOUND = "model_not_found"
INVALID_REQUEST = "invalid_request"
TIMEOUT = "provider_timeout"
UPSTREAM_ERROR = "upstream_server_error"
MALFORMED_RESPONSE = "malformed_response"
CONTENT_FILTERED = "content_filtered"
CANCELLED = "cancelled"
CONFIGURATION = "configuration_error"
INTERNAL = "internal_error"

CATEGORY_LABELS = {
    CONNECTIVITY: "Provider connectivity failure",
    AUTHENTICATION: "Authentication failure (invalid or missing credentials)",
    AUTHORIZATION: "Provider authorization/permission failure",
    RATE_LIMIT: "Provider rate limit reached",
    QUOTA_EXHAUSTED: "Provider quota or billing exhausted",
    UNSUPPORTED_OPERATION: "Operation not supported by this provider/model",
    MODEL_NOT_FOUND: "Model not found at provider",
    INVALID_REQUEST: "Invalid request rejected by provider",
    TIMEOUT: "Provider timeout",
    UPSTREAM_ERROR: "Upstream provider server error",
    MALFORMED_RESPONSE: "Malformed response from provider",
    CONTENT_FILTERED: "Content rejected by provider safety filter",
    CANCELLED: "Cancelled by user",
    CONFIGURATION: "Platform configuration error",
    INTERNAL: "Internal platform error",
}

RETRYABLE_CATEGORIES = {CONNECTIVITY, RATE_LIMIT, TIMEOUT, UPSTREAM_ERROR}


class NexaError(Exception):
    """Base class for all application errors."""

    status_code = 500
    code = "internal_error"
    category = INTERNAL
    message = "Internal server error"

    def __init__(self, message: str | None = None, *, details: dict[str, Any] | None = None, code: str | None = None):
        super().__init__(message or self.message)
        self.detail = message or self.message
        self.details = details or {}
        if code:
            self.code = code

    def to_payload(self) -> dict[str, Any]:
        return {"error": {"code": self.code, "message": self.detail, "category": self.category, "details": self.details}}


class ValidationError(NexaError):
    status_code = 422
    code = "validation_error"
    category = INVALID_REQUEST
    message = "The submitted data is invalid"


class AuthError(NexaError):
    status_code = 401
    code = "unauthenticated"
    category = AUTHENTICATION
    message = "Authentication required"


class PermissionDenied(NexaError):
    status_code = 403
    code = "permission_denied"
    category = AUTHORIZATION
    message = "You do not have permission to perform this action"


class NotFound(NexaError):
    status_code = 404
    code = "not_found"
    category = INVALID_REQUEST
    message = "Resource not found"


class Conflict(NexaError):
    status_code = 409
    code = "conflict"
    message = "The resource conflicts with existing data"


class RateLimited(NexaError):
    status_code = 429
    code = "rate_limited"
    category = RATE_LIMIT
    message = "Too many requests"

    def __init__(self, message: str | None = None, *, retry_after: int = 60, **kwargs: Any):
        super().__init__(message, **kwargs)
        self.retry_after = retry_after


class ConfigurationError(NexaError):
    """Raised when the platform cannot perform an action because the operator
    has not configured a required provider/tool. Never silently faked."""

    status_code = 503
    code = "not_configured"
    category = CONFIGURATION
    message = "This feature is not configured"


class ProviderError(NexaError):
    status_code = 502
    code = "provider_error"

    def __init__(
        self,
        message: str,
        *,
        category: str = UPSTREAM_ERROR,
        provider: str | None = None,
        model: str | None = None,
        status_code: int | None = None,
        retryable: bool | None = None,
        details: dict[str, Any] | None = None,
        request_id: str | None = None,
    ):
        super().__init__(message, details=details or {})
        self.category = category
        self.provider = provider
        self.model = model
        self.upstream_status = status_code
        self.retryable = retryable if retryable is not None else category in RETRYABLE_CATEGORIES
        self.provider_request_id = request_id

    def to_payload(self) -> dict[str, Any]:
        payload = super().to_payload()
        payload["error"]["category"] = self.category
        payload["error"]["category_label"] = CATEGORY_LABELS.get(self.category, self.category)
        payload["error"]["provider"] = self.provider
        payload["error"]["model"] = self.model
        payload["error"]["retryable"] = self.retryable
        payload["error"]["upstream_status"] = self.upstream_status
        return payload


class InsufficientBalance(NexaError):
    status_code = 402
    code = "insufficient_balance"
    message = "Insufficient credit balance for this request"


class ModelNotUsable(NexaError):
    status_code = 403
    code = "model_not_accessible"
    message = "This model is not available to your account"


class PayloadTooLarge(NexaError):
    status_code = 413
    code = "payload_too_large"
    category = INVALID_REQUEST
    message = "The uploaded payload exceeds the configured limit"


class StorageError(NexaError):
    status_code = 400
    code = "storage_error"
    message = "File storage operation failed"


@dataclass
class Diagnostic:
    """Safe diagnostics attached to errors surfaced in the admin UI."""

    message: str
    hints: list[str] = field(default_factory=list)


DIAGNOSTIC_HINTS: dict[str, list[str]] = {
    AUTHENTICATION: [
        "Verify the API key/credential was pasted completely (no leading/trailing spaces).",
        "Rotate the credential in the provider dashboard and save it again under Providers.",
        "Check that the provider account is active and the key is not scoped to another project.",
    ],
    CONNECTIVITY: [
        "Confirm the base URL is reachable from the Nexa AI server (not from your laptop).",
        "Check firewall/DNS rules; private and loopback destinations are blocked by the SSRF guard.",
        "Run the layered diagnosis on the server: python -m app.cli provider-check --provider <slug> "
        "(reports DNS, TCP, TLS, the provider's own error body, plus a chat and a streamed-chat probe).",
    ],
    RATE_LIMIT: [
        "Lower the provider requests-per-minute limit in provider settings.",
        "Add another provider credential or wait for the provider's limit window to reset.",
    ],
    QUOTA_EXHAUSTED: [
        "The upstream account has run out of quota or billing credit.",
        "Top up the provider account or switch to another provider/model.",
    ],
    MODEL_NOT_FOUND: [
        "Re-run 'Synchronize models' for this provider and pick the current provider model id.",
    ],
    UNSUPPORTED_OPERATION: [
        "This provider does not implement that endpoint; choose a model whose capabilities include the operation.",
    ],
    TIMEOUT: [
        "Increase the provider read timeout or reduce max output tokens.",
        "Large models with long generations may legitimately exceed 120s — stream instead of buffering.",
        "Run python -m app.cli provider-check --provider <slug> to see how long each provider layer takes.",
    ],
    UPSTREAM_ERROR: [
        "The provider reported a server-side failure; retry with backoff (automatic retries are configured per provider).",
    ],
    MALFORMED_RESPONSE: [
        "The provider returned a shape Nexa AI does not recognise. Check the base URL points to a compatible API version.",
    ],
    CONFIGURATION: [
        "No provider is enabled for this operation yet: add a provider under Admin → AI Infrastructure → Providers.",
    ],
}


def hints_for(category: str) -> list[str]:
    return DIAGNOSTIC_HINTS.get(category, [])
