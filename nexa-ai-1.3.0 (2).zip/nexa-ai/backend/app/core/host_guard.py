"""Host-header guard with an actionable refusal.

Why this module exists
----------------------
``starlette.middleware.trustedhost.TrustedHostMiddleware`` does its job, but when it says *no* the
browser receives a bare ``400 Invalid host header`` with no body — no JSON, no reason, nothing the
SPA can show and nothing the operator can act on.  That is exactly how a deployment looks "broken"
when the app is reached through a host name the installer did not know about (a forwarded GitHub
Codespaces URL, a tunnel, a proxy, a domain added after the fact): the sign-in page loads, and every
request — including registration — dies with an empty 400.

This guard keeps the same protection (an unknown ``Host`` is refused, so Host-header injection and
DNS-rebinding cannot reach the app), but it answers with the real diagnosis:

* which Host arrived,
* which hosts *are* allowed,
* the exact environment variable to change (``NEXA_TRUSTED_HOSTS``), and how to add a wildcard.

Wildcards mirror Starlette's rules: ``*`` allows everything, ``*.example.com`` allows one label plus
the bare domain, anything else is an exact match (case-insensitive, port stripped).
"""
from __future__ import annotations

from typing import Any

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

#: Development/preview hosts that are pointless to reject: a forwarded port in a cloud workspace
#: changes its host name on every rebuild, and only the person running the workspace can reach it.
#: They are allowed **only** when the operator asks for it (``NEXA_ALLOW_DEV_HOSTS=true``, the
#: default outside production — see config).
DEVELOPMENT_HOST_SUFFIXES = (
    ".app.github.dev",          # GitHub Codespaces forwarded ports
    ".githubpreview.dev",       # legacy Codespaces domain
    ".gitpod.io",               # Gitpod workspaces
    ".e2b.app",                 # the sandbox preview domain
    ".daytona.work",            # Daytona preview links
    ".ngrok-free.app", ".ngrok.io", ".trycloudflare.com", ".localtunnel.me",
)


def _normalise(host: str) -> str:
    host = (host or "").strip().lower()
    if host.startswith("[") and "]" in host:      # IPv6 literal, optionally with a port
        host = host[1:host.index("]")]
    elif host.count(":") == 1:                    # name:port (IPv6 has more than one colon)
        host = host.split(":", 1)[0]
    return host


def _matches(host: str, pattern: str) -> bool:
    pattern = _normalise(pattern)
    if pattern == "*":
        return True
    if pattern.startswith("*."):
        suffix = pattern[1:]                      # ".example.com"
        return host.endswith(suffix) or host == pattern[2:]
    return host == pattern


class HostGuardMiddleware(BaseHTTPMiddleware):
    """Refuse unknown Host headers **with an explanation** (and allow dev preview hosts)."""

    def __init__(self, app, allowed_hosts: list[str], *, allow_dev_hosts: bool = False) -> None:
        super().__init__(app)
        self.allowed = [h for h in allowed_hosts if h.strip()]
        self.allow_dev_hosts = allow_dev_hosts

    def is_allowed(self, host: str) -> bool:
        host = _normalise(host)
        if not host:
            return False
        if any(_matches(host, pattern) for pattern in self.allowed):
            return True
        if self.allow_dev_hosts and any(host.endswith(suffix) for suffix in DEVELOPMENT_HOST_SUFFIXES):
            return True
        return False

    async def dispatch(self, request: Request, call_next):  # noqa: ANN001, ANN201
        host = request.headers.get("host", "")
        if self.is_allowed(host):
            return await call_next(request)
        allowed = ", ".join(self.allowed) or "(none)"
        normalised = _normalise(host)
        looks_like_dev_workspace = any(normalised.endswith(suffix) for suffix in DEVELOPMENT_HOST_SUFFIXES)
        details: dict[str, Any] = {
            "host": host,
            "allowed_hosts": self.allowed,
            "how_to_fix": (
                "Add the host name (or a wildcard such as *.example.com) to NEXA_TRUSTED_HOSTS, "
                "then restart the service: sudo systemctl restart nexa-api (or the launcher)."
            ),
            "tool": "deployment/linux/check_public_access.sh --port <port>",
        }
        if looks_like_dev_workspace:
            # A forwarded port in a cloud workspace (GitHub Codespaces, Gitpod, a tunnel) changes its host
            # name on every rebuild, so no list can ever be complete. Say which switch lifts the refusal.
            details["development_workspace"] = True
            details["how_to_fix"] = (
                "This host name belongs to a cloud development workspace (GitHub Codespaces / Gitpod / a "
                "tunnel) whose URL changes on every rebuild. Either set NEXA_ALLOW_DEV_HOSTS=true in the "
                "environment file, or list the current host in NEXA_TRUSTED_HOSTS — then restart the API."
            )
        return JSONResponse(
            status_code=400,
            content={
                "error": {
                    "code": "host_not_allowed",
                    "message": (
                        f"The request arrived with Host: {host or '(missing)'}, which this deployment does not "
                        f"accept. Add it to NEXA_TRUSTED_HOSTS in the environment file and restart the API."
                        + (
                            " This looks like a GitHub Codespaces / Gitpod forwarded URL: set "
                            "NEXA_ALLOW_DEV_HOSTS=true to accept such host names."
                            if looks_like_dev_workspace
                            else ""
                        )
                    ),
                    "category": "configuration_error",
                    "details": details,
                }
            },
        )


__all__ = ["HostGuardMiddleware", "DEVELOPMENT_HOST_SUFFIXES"]
