"""Structured logging with secret redaction and request correlation IDs.

Design notes:
* Every log record carries a correlation id (``request_id``) so a browser error
  can be traced to the exact backend request (see ``X-Request-ID`` header).
* A redaction filter scrubs obviously sensitive keys/values (API keys, bearer
  tokens, passwords, cookies) before anything is written to disk.
"""
from __future__ import annotations

import contextvars
import json
import logging
import re
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

REQUEST_ID: contextvars.ContextVar[str] = contextvars.ContextVar("nexa_request_id", default="-")
USER_ID: contextvars.ContextVar[str] = contextvars.ContextVar("nexa_user_id", default="-")

_SECRET_PATTERNS = [
    re.compile(r"(sk-[A-Za-z0-9_\-]{8,})"),
    re.compile(r"(?i)(api[_-]?key|authorization|bearer|password|passwd|secret|token|x-api-key)([\"'=:\s]+)([^\s\"',}]{4,})"),
    re.compile(r"(?i)(nexa_session|csrf_token)=([^;\s]+)"),
]


def redact(text: str) -> str:
    if not text:
        return text
    out = text
    for rx in _SECRET_PATTERNS:
        if rx.groups >= 3:
            out = rx.sub(lambda m: f"{m.group(1)}{m.group(2)}***REDACTED***", out)
        else:
            out = rx.sub("***REDACTED***", out)
    return out


class RedactionFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:  # noqa: A003
        try:
            msg = record.getMessage()
        except Exception:  # pragma: no cover - defensive
            return True
        cleaned = redact(msg)
        if cleaned != msg:
            record.msg = cleaned
            record.args = ()
        return True


class ContextFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:  # noqa: A003
        record.request_id = REQUEST_ID.get()
        record.user_id = USER_ID.get()
        return True


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S%z"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "request_id": getattr(record, "request_id", "-"),
            "user_id": getattr(record, "user_id", "-"),
        }
        for extra in ("event", "provider", "model", "job_id", "path", "method", "status", "latency_ms", "error_category"):
            value = getattr(record, extra, None)
            if value is not None:
                payload[extra] = value
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


class TextFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        base = (
            f"{self.formatTime(record, '%Y-%m-%d %H:%M:%S')} {record.levelname:<8} "
            f"[{getattr(record, 'request_id', '-')}] {record.name}: {record.getMessage()}"
        )
        return redact(base)


_configured = False


class DynamicStreamHandler(logging.StreamHandler):
    """A stream handler that always writes to the *current* ``sys.stdout``/``sys.stderr``.

    ``logging.StreamHandler`` captures whatever stream object it was given at construction time.
    That leaks: a handler created while a test framework (or a caller that redirects output) holds
    a temporary ``sys.stdout`` keeps writing into the closed capture buffer afterwards, so the
    final output of the process — pytest's own "N passed" summary, for example — is written into a
    dead stream and silently lost. Resolving the stream on every emit keeps logging attached to the
    real console, and lets ``capsys``/``redirect_stdout`` work as users expect.
    """

    def __init__(self, which: str = "stdout") -> None:
        super().__init__(sys.stdout if which == "stdout" else sys.stderr)
        self._which = "stdout" if which == "stdout" else "stderr"

    def _target(self):  # noqa: ANN202 - TextIO
        return sys.stdout if self._which == "stdout" else sys.stderr

    def emit(self, record: logging.LogRecord) -> None:
        self.stream = self._target()
        super().emit(record)

    def flush(self) -> None:
        self.stream = self._target()
        super().flush()


def configure_logging(
    level: str = "INFO",
    json_output: bool = False,
    log_dir: str | None = None,
    *,
    stream: str = "stdout",
) -> None:
    """Configure the root logger.

    ``stream="stderr"`` is used by the CLI commands that print a JSON report on stdout
    (``doctor``, ``check-secrets``, ``provider-check``) so the report stays machine-parseable:
    application log lines must not land in the middle of it.
    """
    global _configured
    root = logging.getLogger()
    root.setLevel(level)

    # Replace the handlers a previous call installed (the API imports this, the CLI calls it again
    # in the same process with stream="stderr"; tests call it repeatedly). The old code bailed out
    # after the first call, so a later call could not change the stream or the level, and handlers
    # piled up until every log line was printed several times.
    for handler in [h for h in list(root.handlers) if getattr(h, "_nexa_managed", False)]:
        root.removeHandler(handler)
        try:
            handler.close()
        except Exception:  # pragma: no cover - closing must never break logging setup
            pass

    stream_handler = DynamicStreamHandler(stream)
    stream_handler._nexa_managed = True  # type: ignore[attr-defined]
    formatter: logging.Formatter = JsonFormatter() if json_output else TextFormatter()
    stream_handler.setFormatter(formatter)
    stream_handler.addFilter(ContextFilter())
    stream_handler.addFilter(RedactionFilter())
    root.addHandler(stream_handler)

    if log_dir:
        path = Path(log_dir)
        path.mkdir(parents=True, exist_ok=True)
        file_handler = RotatingFileHandler(path / "nexa.log", maxBytes=20 * 1024 * 1024, backupCount=10, encoding="utf-8")
        file_handler.setFormatter(formatter)
        file_handler.addFilter(ContextFilter())
        file_handler.addFilter(RedactionFilter())
        file_handler._nexa_managed = True  # type: ignore[attr-defined]
        root.addHandler(file_handler)

    # Quieten noisy third-party loggers but keep warnings.
    for noisy in ("uvicorn.access", "httpx", "httpcore"):
        logging.getLogger(noisy).setLevel(max(logging.WARNING, logging.getLevelName(level)))
    _configured = True


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
