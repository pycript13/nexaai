"""Session, token and CSRF primitives.

Design:
* Opaque 256-bit session tokens are stored **hashed** (SHA-256) in the database,
  so a database leak does not hand over live sessions. The raw token lives only
  in an HttpOnly cookie (never in localStorage / never readable by JS).
* JWTs are supported for programmatic API access (``Authorization: Bearer``)
  with short lifetimes; interactive sessions remain revocable server-side.
* CSRF uses the double-submit pattern bound to the session record.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import hmac
import secrets
from typing import Any

import jwt

from app.core.config import settings
from app.core.crypto import random_token

SESSION_COOKIE = "nexa_session"
CSRF_COOKIE = "nexa_csrf"
CSRF_HEADER = "x-csrf-token"

ALGORITHM = "HS256"
ACCESS_TOKEN_TTL_MINUTES = 60
REFRESH_TOKEN_TTL_DAYS = 30


def utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def hash_session_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def generate_session_token() -> str:
    return random_token(32)


def generate_csrf_token() -> str:
    return random_token(24)


def generate_otp(length: int = 6) -> str:
    return "".join(str(secrets.randbelow(10)) for _ in range(length))


def constant_time_equals(a: str | bytes | None, b: str | bytes | None) -> bool:
    if a is None or b is None:
        return False
    if isinstance(a, str):
        a = a.encode()
    if isinstance(b, str):
        b = b.encode()
    return hmac.compare_digest(a, b)


# --- JWT (programmatic API access) -----------------------------------------
def create_access_token(subject: str, *, scopes: list[str] | None = None, expires_minutes: int = ACCESS_TOKEN_TTL_MINUTES) -> str:
    now = utcnow()
    payload: dict[str, Any] = {
        "sub": subject,
        "iat": int(now.timestamp()),
        "exp": int((now + dt.timedelta(minutes=expires_minutes)).timestamp()),
        "typ": "access",
        "scopes": scopes or [],
        "jti": random_token(8),
    }
    return jwt.encode(payload, settings.secret_key, algorithm=ALGORITHM)


def decode_access_token(token: str) -> dict[str, Any]:
    return jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM], options={"require": ["exp", "sub"]})


def create_action_token(subject: str, purpose: str, *, ttl_minutes: int = 60, extra: dict[str, Any] | None = None) -> str:
    now = utcnow()
    payload: dict[str, Any] = {
        "sub": subject,
        "typ": purpose,
        "iat": int(now.timestamp()),
        "exp": int((now + dt.timedelta(minutes=ttl_minutes)).timestamp()),
        "nonce": random_token(8),
    }
    if extra:
        payload.update(extra)
    return jwt.encode(payload, settings.secret_key, algorithm=ALGORITHM)


def decode_action_token(token: str, purpose: str) -> dict[str, Any]:
    payload = jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM], options={"require": ["exp", "sub"]})
    if payload.get("typ") != purpose:
        raise jwt.InvalidTokenError(f"Expected token purpose '{purpose}'")
    return payload
