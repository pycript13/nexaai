"""Rate limiting: Redis-backed when available, in-process token buckets otherwise.

The in-process limiter is documented as *per replica* — for multi-replica
deployments configure Redis (``NEXA_REDIS_URL``) so limits are shared, as
required for auth abuse protection.
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass

from app.core.config import settings
from app.core.errors import RateLimited
from app.core.logging import get_logger

log = get_logger(__name__)

try:  # optional dependency
    import redis as _redis  # type: ignore
except Exception:  # pragma: no cover
    _redis = None


@dataclass
class _Bucket:
    tokens: float
    updated: float


class InProcessLimiter:
    def __init__(self) -> None:
        self._buckets: dict[str, _Bucket] = {}
        self._lock = threading.Lock()

    def check(self, key: str, limit: int, window_seconds: int = 60) -> tuple[bool, int]:
        now = time.monotonic()
        rate = limit / float(window_seconds)
        with self._lock:
            bucket = self._buckets.get(key)
            if bucket is None:
                self._buckets[key] = _Bucket(tokens=limit - 1, updated=now)
                return True, limit - 1
            elapsed = now - bucket.updated
            bucket.tokens = min(limit, bucket.tokens + elapsed * rate)
            bucket.updated = now
            if bucket.tokens < 1:
                retry = int((1 - bucket.tokens) / rate) + 1
                return False, max(retry, 1)
            bucket.tokens -= 1
            if len(self._buckets) > 50_000:  # bound memory
                self._prune(now, window_seconds)
            return True, int(bucket.tokens)

    def _prune(self, now: float, window_seconds: int) -> None:
        cutoff = now - window_seconds * 2
        for key in [k for k, b in self._buckets.items() if b.updated < cutoff]:
            self._buckets.pop(key, None)


class RedisLimiter:
    def __init__(self, client) -> None:  # noqa: ANN001
        self.client = client

    def check(self, key: str, limit: int, window_seconds: int = 60) -> tuple[bool, int]:
        redis_key = f"nexa:rl:{key}:{int(time.time() // window_seconds)}"
        try:
            pipe = self.client.pipeline()
            pipe.incr(redis_key, 1)
            pipe.expire(redis_key, window_seconds + 1)
            count, _ = pipe.execute()
        except Exception as exc:  # pragma: no cover - redis outage
            log.warning("rate limiter backend unavailable, allowing request: %s", exc)
            return True, limit
        if int(count) > limit:
            ttl = self.client.ttl(redis_key)
            return False, max(int(ttl), 1)
        return True, limit - int(count)


class RateLimiter:
    def __init__(self) -> None:
        self._memory = InProcessLimiter()
        self._redis = None
        if settings.redis_url and _redis is not None:
            try:
                client = _redis.Redis.from_url(settings.redis_url, socket_connect_timeout=2, socket_timeout=2)
                client.ping()
                self._redis = RedisLimiter(client)
                log.info("rate limiting using Redis backend at %s", settings.redis_url)
            except Exception as exc:
                log.warning("Redis configured but unavailable (%s); falling back to in-process rate limiting", exc)

    @property
    def backend(self) -> str:
        return "redis" if self._redis else "in-process"

    def check(self, key: str, limit: int, window_seconds: int = 60, *, raise_on_limit: bool = True) -> tuple[bool, int]:
        if not settings.rate_limit_enabled or limit <= 0:
            return True, limit
        limiter = self._redis or self._memory
        allowed, remaining = limiter.check(key, limit, window_seconds)
        if not allowed and raise_on_limit:
            raise RateLimited(
                f"Rate limit exceeded for this action. Try again in {remaining} seconds.",
                retry_after=max(remaining, 1),
            )
        return allowed, remaining

    def peek(self, key: str, limit: int, window_seconds: int = 60) -> bool:
        return self.check(key, limit, window_seconds, raise_on_limit=False)[0]


limiter = RateLimiter()
