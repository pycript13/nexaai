"""Network safety helpers — SSRF protection for operator- and user-supplied URLs.

Threat model: provider base URLs are configured by administrators, and some
endpoints (e.g. image URLs for image-understanding) can be influenced by
ordinary users. Both must never be able to reach cloud metadata services,
loopback, or private address ranges from the server.

Policy:
1. Scheme must be https (http only when explicitly allowed AND the host is in
   the operator allowlist).
2. Host must not be a private/loopback/link-local/reserved literal.
3. Hostname is resolved (all A/AAAA records) and *every* resolved address is
   validated, so DNS names pointing at 169.254.169.254 or 10.0.0.0/8 are refused.
4. An explicit operator allowlist (NEXA_PROVIDER_ALLOWED_HOSTS) can permit a
   known-private destination (e.g. a self-hosted Ollama gateway on the LAN).
5. `NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=true` relaxes rules 2/3 for trusted
   single-tenant installs. Metadata endpoints stay blocked unless the host is
   explicitly allowlisted.
"""
from __future__ import annotations

import ipaddress
import socket
from dataclasses import dataclass
from urllib.parse import urlparse

from app.core.config import settings
from app.core.errors import ValidationError

METADATA_HOSTS = {
    "169.254.169.254", "metadata.google.internal", "metadata.goog",
    "100.100.100.200",  # Alibaba Cloud metadata
    "fd00:ec2::254",
}
METADATA_NETWORKS = [ipaddress.ip_network("169.254.0.0/16")]


@dataclass
class UrlCheck:
    ok: bool
    reason: str = ""
    resolved: list[str] | None = None


def _is_blocked_ip(ip: ipaddress._BaseAddress) -> bool:
    return bool(
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_reserved
        or ip.is_multicast
        or ip.is_unspecified
        or (ip.version == 6 and ip.ipv4_mapped is not None and _is_blocked_ip(ip.ipv4_mapped))
    )


def validate_outbound_url(url: str, *, purpose: str = "provider endpoint", allow_http: bool | None = None) -> UrlCheck:
    allow_http = settings.provider_allow_insecure_http if allow_http is None else allow_http
    if not url or not url.strip():
        return UrlCheck(False, "URL is empty")
    parsed = urlparse(url.strip())
    host = (parsed.hostname or "").lower()
    if parsed.scheme not in ("http", "https"):
        return UrlCheck(False, f"Unsupported URL scheme '{parsed.scheme}': only http/https are allowed")
    if parsed.scheme == "http" and not allow_http:
        return UrlCheck(False, "Plain http:// endpoints are disabled (set NEXA_PROVIDER_ALLOW_INSECURE_HTTP=true to permit, HTTPS recommended)")
    if not host:
        return UrlCheck(False, "URL has no host")
    allowlist = settings.private_endpoint_allowlist

    def allowed_by_operator(h: str) -> bool:
        return any(h == a or h.endswith("." + a) for a in allowlist)

    if host in METADATA_HOSTS:
        # Metadata service is *never* reachable, even through the allowlist.
        return UrlCheck(False, f"Access to cloud metadata endpoint '{host}' is permanently blocked")
    if allowed_by_operator(host):
        return UrlCheck(True, "operator allowlist", [])
    try:
        literal = ipaddress.ip_address(host)
        if any(literal in net for net in METADATA_NETWORKS):
            return UrlCheck(False, f"Address {host} belongs to a cloud metadata range and is blocked")
        if _is_blocked_ip(literal) and not settings.allow_private_provider_endpoints:
            return UrlCheck(False, f"Address {host} is in a private/loopback/reserved range and is blocked (SSRF policy)")
        return UrlCheck(True, "", [host])
    except ValueError:
        pass  # not an IP literal -> resolve it

    try:
        infos = socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80), proto=socket.IPPROTO_TCP)
    except socket.gaierror as exc:
        return UrlCheck(False, f"DNS resolution of '{host}' failed: {exc}")
    addresses = sorted({info[4][0] for info in infos})
    if not addresses:
        return UrlCheck(False, f"DNS resolution of '{host}' returned no addresses")
    for addr in addresses:
        ip = ipaddress.ip_address(addr)
        if any(ip in net for net in METADATA_NETWORKS):
            return UrlCheck(False, f"'{host}' resolves to metadata range {addr} — blocked")
        if _is_blocked_ip(ip) and not settings.allow_private_provider_endpoints:
            return UrlCheck(
                False,
                f"'{host}' resolves to private/loopback address {addr} — blocked by SSRF policy",
            )
    return UrlCheck(True, "", addresses)


def assert_outbound_url(url: str, *, purpose: str = "provider endpoint") -> str:
    check = validate_outbound_url(url, purpose=purpose)
    if not check.ok:
        raise ValidationError(
            f"Blocked outbound URL for {purpose}: {check.reason}",
            details={"url": _redact_url(url), "reason": check.reason, "policy": "SSRF protection"},
        )
    return url


def _redact_url(url: str) -> str:
    parsed = urlparse(url)
    if parsed.username or parsed.password:
        netloc = parsed.hostname or ""
        if parsed.port:
            netloc += f":{parsed.port}"
        return parsed._replace(netloc=netloc).geturl()
    return url


def is_url_safe(url: str) -> bool:
    return validate_outbound_url(url).ok
