# Database

Nexa AI uses **PostgreSQL in production** and **SQLite for local development only**.
Everything below assumes the PostgreSQL path, which is what the installers configure.

## Files

| File | Purpose |
| --- | --- |
| `postgres_init.sql` | Creates the application role + database, a read-only monitoring role and the `pg_trgm` extension. Run once as the `postgres` superuser. |
| `create_tables.sql` | Documentation-only rendering of the schema created by Alembic (kept in sync by `scripts/dump_schema.py`). Never run this against a live database. |
| `schema.md` | Human-readable overview of the 30 tables, the money columns and the integrity rules. |

## Creating the database

```bash
sudo -u postgres psql -v db_password="'CHANGE_ME'" -f database/postgres_init.sql
```

Then point the application at it:

```
NEXA_DATABASE_URL=postgresql+psycopg2://nexa:CHANGE_ME@127.0.0.1:5432/nexa
```

## Migrations

Alembic owns the schema. Never edit tables by hand.

```bash
cd backend
python -m alembic upgrade head        # apply
python -m alembic current             # what is applied now
python -m alembic history --verbose   # full revision list
python -m alembic downgrade -1        # one step back (used in restore drills)
python -m alembic upgrade head        # back forward
```

The API container/image runs `alembic upgrade head` on start, so a rolling deploy
migrates itself. Migrations are additive; removing a column requires an explicit
data migration and is documented in `docs/KNOWN_LIMITATIONS.md` when not yet done.

## Money and integrity rules

* Credits are stored as **micro-credits** in `BIGINT` columns (1 credit = 1 000 000 micro).
  No float or `Numeric` rounding is used anywhere in the ledger path.
* `credit_ledger` is append-only: rows are inserted, never updated or deleted.
  Corrections are new rows (`adjustment`, `refund`).
* Each ledger row carries a unique `idempotency_key`; a duplicate insert is rejected by
  the database, not by application logic alone.
* `credit_accounts.balance_micro` is a cached projection of the ledger. `reconcile()`
  (and `python -m app.cli doctor`) recomputes it from the ledger and reports drift.
* Foreign keys are enforced (`PRAGMA foreign_keys=ON` for SQLite, native FKs for
  PostgreSQL); deleting a user keeps billing/audit history (`ON DELETE RESTRICT`
  on financial tables).

## Backup

See `docs/BACKUP_RESTORE.md`. Short version: `scripts/backup.sh` (uses `pg_dump -Fc`
or SQLite's online backup API), `scripts/verify_backup.sh` to prove the file is readable,
`scripts/restore.sh --yes` to restore, then `scripts/health_check.sh`.
