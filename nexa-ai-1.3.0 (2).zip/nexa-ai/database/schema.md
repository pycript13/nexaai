# Nexa AI — schema overview

30 tables, owned by Alembic (`backend/alembic/versions/`). A full DDL rendering
for PostgreSQL lives in `database/create_tables.sql`.

| Table | Cols | Purpose |
| --- | --- | --- |
| `admin_model_tests` | 24 | audited administrator model tests: request summary, latency, tokens, platform cost, diagnostics |
| `app_settings` | 11 | runtime settings with value type, category, public exposure flag and last editor |
| `audit_events` | 16 | append-only audit trail: actor, entity, before/after state, request id |
| `conversations` | 15 | chat conversations with aggregate usage counters |
| `credit_accounts` | 12 | cached balance in micro-credits + spend limits, freeze flag, lifetime totals |
| `credit_ledger` | 15 | append-only credit movements, unique idempotency key, balance_after_micro snapshot |
| `files` | 19 | uploaded + generated files: private storage path, checksums, validation/scan status, retention |
| `jobs` | 23 | asynchronous jobs (image/audio/video/document/index) with attempts, lease, progress, cost |
| `messages` | 21 | chat messages: role, content parts, token accounting, finish reason, error taxonomy |
| `model_categories_link` | 2 | model <-> category mapping |
| `model_category` | 8 | catalogue categories (chat, coding, vision, image, audio, video, embedding, rerank, document) |
| `model_grants` | 10 | user/role grants for restricted models, with optional daily/monthly spend caps and expiry |
| `model_tags` | 3 | free-form tags for admin filtering |
| `model_tags_link` | 2 | model <-> tag mapping |
| `models` | 53 | model catalogue: capabilities, modalities, costs, selling prices, visibility/availability/access tier, publish state |
| `payments` | 40 | manual bank-transfer / crypto / gateway payments incl. reviewer trail, refunds, FX and crypto confirmations |
| `permissions` | 4 | granular permission catalogue (users.read, providers.manage, models.test, pricing.manage, credits.manage, audit.read, backups.manage, ...) |
| `pricing_rules` | 26 | scoped price overrides (user/plan/model/provider/global) with versioning and markup |
| `provider_health_samples` | 8 | rolling provider latency/success samples used by the health views |
| `providers` | 36 | AI providers: type, base URL, encrypted API key, rate limits, health, sync state |
| `role_permissions` | 3 | role -> permission mapping edited in Admin -> Roles |
| `roles` | 7 | 6 built-in roles (super_admin, admin, model_manager, billing_manager, support_agent, user) |
| `subscription_plan_models` | 2 | which models a plan unlocks (access tier = subscription) |
| `subscription_plans` | 16 | plan catalogue: monthly price, included credit, request/token quotas, feature list |
| `subscriptions` | 14 | active user subscriptions: period, renewal count, cancel-at-period-end |
| `usage_records` | 33 | one row per billable operation: tokens/units, provider cost, charged amount, pricing rule + version |
| `user_activities` | 8 | per-user activity feed shown on Profile/Activity |
| `user_roles` | 5 | user -> role mapping |
| `user_sessions` | 11 | server-side sessions: token hash, CSRF token, idle/absolute expiry, revocation trail |
| `users` | 35 | accounts: status, locale/theme, argon2id password hash, lockout, storage usage, ToS acceptance |

## Money columns (BIGINT micro-credits — 1 credit = 1 000 000 micro)

| Table | Columns |
| --- | --- |
| `credit_accounts` | `balance_micro`, `lifetime_deposited_micro`, `lifetime_spent_micro`, `reserved_micro`, `daily_spend_limit_micro`, `monthly_spend_limit_micro` |
| `credit_ledger` | `amount_micro`, `balance_after_micro` |
| `payments` | `amount_micro`, `refunded_micro` (`amount_fiat`/`fx_rate` keep the fiat trail) |
| `subscription_plans` | `price_micro_monthly`, `included_credit_micro` |
| `usage_records` | `charged_micro`, `provider_cost_micro` |
| `pricing_rules` | `*_micro` price columns in both selling and provider-cost space |
| `models` | `provider_cost_*` (provider currency) and `selling_*` (credits) |
| `model_grants` | `daily_spend_limit_micro`, `monthly_spend_limit_micro` |
| `admin_model_tests` | `provider_cost_micro` (platform cost — never billed to a user) |
| `jobs` | `charged_micro`, `provider_cost_micro` |

Money never touches `FLOAT`/`DOUBLE`. Display conversion happens in the frontend only
(`formatCredits` divides by 1 000 000); everything the API returns is integer micro-credits
plus a human-readable `*_display` string.

## Uniqueness / integrity constraints

* `credit_ledger.idempotency_key` — UNIQUE: posting the same payment, admission or refund twice
  fails at the database level, not merely in application code.
* `users.email`, `users.username`, `providers.slug`, `roles.slug`, `permissions.slug`,
  `subscription_plans.slug`, `model_category.slug`, `model_tags.slug` — UNIQUE.
* `models` — UNIQUE(`provider_id`, `provider_model_id`): one catalogue row per upstream model.
* `model_grants` — UNIQUE(`model_id`, `subject_type`, `subject_id`).
* `user_sessions.token_hash` — UNIQUE and indexed: every authenticated request looks the session up by hash.
* `usage_records.idempotency_key`, `payments.idempotency_key` — UNIQUE when supplied, so retried
  client requests cannot double-charge.
* Financial and audit rows are never cascade-deleted with a user; `ON DELETE` is RESTRICT/NO ACTION
  for `credit_ledger`, `payments`, `usage_records`, `audit_events` so history survives account deletion.

## Enumerated values worth knowing

* `models.visibility`: `public`, `hidden`
* `models.availability`: `available`, `degraded_offline`, `maintenance`, `unavailable`
  (`ModelAvailability.OFFLINE == "degraded_offline"`)
* `models.access_tier`: `free`, `credit`, `subscription`, `restricted`, `internal`
  (internal models are admin-only; restricted needs a grant; subscription needs an active plan)
* `users.status`: `pending`, `active`, `suspended`, `disabled`, `deleted`
* `credit_ledger.entry_type`: `deposit`, `usage_charge`, `admin_grant`, `adjustment`, `refund`, `subscription_credit`
* `usage_records.status`: `succeeded`, `failed`, `rejected` — a failed provider call must show zero charge
* `jobs.status`: `pending`, `running`, `succeeded`, `failed`, `cancelled`, `expired`
* `providers.provider_type`: `openai`, `openai_compatible`, `anthropic`, `azure_openai`, `google_gemini`,
  `ollama`, `deepseek`, `mistral`, `groq`, `together`, `openrouter`, `custom_http`,
  `stability`, `elevenlabs`, `local_media` (see docs/PROVIDER_CONFIGURATION.md)

## Indexes

Every foreign key is indexed. Hot paths additionally have:

* `user_sessions(user_id, revoked_at)`, `user_sessions(expires_at)`
* `credit_ledger(user_id, created_at DESC)`, `credit_ledger(account_id)`
* `usage_records(user_id, created_at DESC)`, `usage_records(model_id)`, `usage_records(job_id)`
* `models(provider_id, enabled, published)`, `models(visibility, availability)`
* `jobs(status, priority, created_at)`, `jobs(lease_expires_at)`
* `audit_events(created_at DESC)`, `audit_events(category)`, `audit_events(actor_user_id)`
* `payments(status, created_at DESC)`, `payments(reference)`
* `files(user_id, deleted_at)`, `files(uuid)`
