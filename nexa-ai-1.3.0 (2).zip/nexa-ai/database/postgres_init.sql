-- Nexa AI - PostgreSQL bootstrap.
--
-- Run once as a superuser:
--   sudo -u postgres psql -v db_password="'REPLACE_ME'" -f database/postgres_init.sql
--
-- This script is idempotent: re-running it changes nothing except the password
-- of the application role.

\set ON_ERROR_STOP on

-- 1) application role -------------------------------------------------------
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'nexa') THEN
        EXECUTE format('CREATE ROLE nexa LOGIN PASSWORD %L', :'db_password');
    ELSE
        EXECUTE format('ALTER ROLE nexa WITH LOGIN PASSWORD %L', :'db_password');
    END IF;
END
$$;

-- Never let the application role create databases or roles.
ALTER ROLE nexa NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT;

-- 2) database ---------------------------------------------------------------
SELECT 'CREATE DATABASE nexa OWNER nexa ENCODING ''UTF8'''
WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = 'nexa')\gexec

\connect nexa

-- 3) extensions -------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pg_trgm;      -- fast ILIKE search in the admin lists
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";  -- optional helper if a future table needs uuid()

-- 4) schema hardening -------------------------------------------------------
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT USAGE, CREATE ON SCHEMA public TO nexa;

-- The application user only ever touches its own tables; Alembic runs as `nexa`.
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO nexa;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO nexa;

-- 5) read-only monitoring role (optional, used by external dashboards) ------
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'nexa_monitor') THEN
        CREATE ROLE nexa_monitor LOGIN PASSWORD 'CHANGE_ME_MONITOR_PASSWORD';
    END IF;
END
$$;
GRANT CONNECT ON DATABASE nexa TO nexa_monitor;
GRANT USAGE ON SCHEMA public TO nexa_monitor;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO nexa_monitor;

\echo 'Nexa AI database ready. Point NEXA_DATABASE_URL at postgresql+psycopg2://nexa:PASSWORD@HOST:5432/nexa'
