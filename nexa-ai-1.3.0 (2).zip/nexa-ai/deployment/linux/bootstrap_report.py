#!/usr/bin/env python3
"""Read a field of the `app.cli bootstrap` report from the installer's captured output.

Why this is a separate, tested file
    `deployment/linux/install.sh` runs bootstrap as

        BOOTSTRAP_JSON="$( ... python -m app.cli bootstrap )"

    and the CLI logs to **stdout** as well as printing the JSON report. The log line itself contains
    a Python dict — `bootstrap complete: {'permissions_created': 0, …}` — so the naive
    "first `{` … last `}`" slice used before this file existed handed `json.loads` a Python repr and
    always failed, silently. The consequence was visible on a real sandbox: the installer accepted
    `admin@nexa.test`, bootstrap refused to create the administrator ("reserved example/placeholder
    domains cannot be used for sign-in"), nobody noticed, and the deployment finished with an
    administrator account that could never sign in (the API answers 422 for that address).

    This helper scans for the first position where a *JSON object that contains `super_admin`*
    starts, which is the report, whatever else was printed around it.

Usage (install.sh calls it this way):

    python3 bootstrap_report.py created < captured-output      # yes | no | unparsed
    python3 bootstrap_report.py reason  < captured-output      # the human-readable reason, one line
"""
from __future__ import annotations

import json
import sys

FIELDS = ("created", "reason", "email")


def extract(raw: str) -> dict[str, object] | None:
    """Return the bootstrap report (the first JSON object that carries `super_admin`)."""
    decoder = json.JSONDecoder()
    for index, char in enumerate(raw):
        if char != "{":
            continue
        try:
            candidate, _ = decoder.raw_decode(raw[index:])
        except ValueError:
            continue
        if isinstance(candidate, dict) and "super_admin" in candidate:
            return candidate
    return None


def field_value(raw: str, field: str) -> str:
    report = extract(raw)
    if report is None:
        return "unparsed" if field == "created" else ""
    admin = report.get("super_admin") or {}
    if not isinstance(admin, dict):
        return "unparsed" if field == "created" else ""
    value = admin.get(field)
    if field == "created":
        return "yes" if value else "no"
    return "" if value is None else str(value).replace("\n", " ").strip()


def main(argv: list[str]) -> int:
    if len(argv) != 2 or argv[1] not in FIELDS:
        print(f"usage: {argv[0]} {{{'|'.join(FIELDS)}}} < bootstrap-output", file=sys.stderr)
        return 2
    print(field_value(sys.stdin.read(), argv[1]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
