#!/usr/bin/env bash
# Nexa AI — process launcher for hosts without systemd (containers, OpenVZ, WSL1, dev boxes).
#
# Usage:  deployment/linux/nexa-services.sh {start|stop|restart|status|logs|keepalive}
#
# `keepalive` restarts whichever process has died and prints one line per action. It exists for
# hosts without systemd (exactly where Restart=always is unavailable): the installer schedules it
# in cron (every minute) so a crashed API or worker comes back on its own instead of leaving the
# site down until somebody notices.
#
# It runs exactly the same two processes as the systemd units:
#   API    : venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8000
#   worker : venv/bin/python -m app.workers.worker
# with the install directory's .env loaded, PID files in <app>/run and logs in <app>/logs.
set -Eeuo pipefail

APP_DIR="${APP_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
RUN_DIR="${APP_DIR}/run"
LOG_DIR="${APP_DIR}/logs"
API_PORT="${API_PORT:-8000}"
HEALTH_URL="${HEALTH_URL:-http://127.0.0.1:${API_PORT}/healthz}"
PY="${APP_DIR}/venv/bin/python"
UVICORN="${APP_DIR}/venv/bin/uvicorn"

log()  { printf '[services] %s\n' "$*"; }
die()  { printf '[services][error] %s\n' "$*" >&2; exit 1; }

# Run a command as the owner of the install directory when we are root.
as_owner() {
  local owner
  owner="$(stat -c '%U' "${APP_DIR}" 2>/dev/null || echo root)"
  if [[ "$(id -u)" -eq 0 && "${owner}" != "root" ]]; then
    exec sudo -u "${owner}" -E "$@"
  fi
  exec "$@"
}

is_running() { # $1 = pid file
  local pid
  [[ -f "$1" ]] || return 1
  pid="$(cat "$1" 2>/dev/null || true)"
  [[ -n "${pid}" ]] || return 1
  kill -0 "${pid}" 2>/dev/null
}

start_one() { # $1 = name, rest = command
  local name="$1"; shift
  local pidfile="${RUN_DIR}/${name}.pid"
  if is_running "${pidfile}"; then
    log "${name} already running (pid $(cat "${pidfile}"))"
    return 0
  fi
  [[ -x "${PY}" ]] || die "${PY} not found — run the installer first"
  mkdir -p "${RUN_DIR}" "${LOG_DIR}"
  log "starting ${name}"
  (
    cd "${APP_DIR}/backend"
    # the application loads ${APP_DIR}/.env itself (pydantic-settings), so it is not sourced here
    as_owner nohup "$@" >>"${LOG_DIR}/${name}.log" 2>&1 &
    echo $! > "${pidfile}"
  )
  sleep 1
  is_running "${pidfile}" || { tail -n 20 "${LOG_DIR}/${name}.log" >&2 || true; die "${name} failed to start"; }
  log "${name} started (pid $(cat "${pidfile}"))"
}

stop_one() { # $1 = name
  local name="$1"
  local pidfile="${RUN_DIR}/${name}.pid"
  if ! is_running "${pidfile}"; then
    log "${name} is not running"
    rm -f "${pidfile}"
    return 0
  fi
  local pid; pid="$(cat "${pidfile}")"
  log "stopping ${name} (pid ${pid})"
  kill -TERM "${pid}" 2>/dev/null || true
  for _ in $(seq 1 20); do
    kill -0 "${pid}" 2>/dev/null || break
    sleep 0.5
  done
  if kill -0 "${pid}" 2>/dev/null; then
    warn_pid="${pid}"
    printf '[services][warning] %s did not stop gracefully — sending SIGKILL to %s\n' "${name}" "${warn_pid}" >&2
    kill -KILL "${pid}" 2>/dev/null || true
  fi
  rm -f "${pidfile}"
  log "${name} stopped"
}

start() {
  start_one api "${UVICORN}" app.main:app --host 127.0.0.1 --port "${API_PORT}" --proxy-headers --forwarded-allow-ips=127.0.0.1
  start_one worker "${PY}" -m app.workers.worker

  for _ in $(seq 1 30); do
    if command -v curl >/dev/null 2>&1 && curl -fsS "${HEALTH_URL}" >/dev/null 2>&1; then
      log "API health check passed (${HEALTH_URL})"
      return 0
    fi
    sleep 1
  done
  printf '[services][warning] %s did not answer within 30s — check %s/api.log\n' "${HEALTH_URL}" "${LOG_DIR}" >&2
  return 0
}

stop() {
  stop_one api
  stop_one worker
}

status() {
  local name pidfile pid state
  for name in api worker; do
    pidfile="${RUN_DIR}/${name}.pid"
    if is_running "${pidfile}"; then
      pid="$(cat "${pidfile}")"
      printf '%-7s running  pid=%s  log=%s/%s.log\n' "${name}" "${pid}" "${LOG_DIR}" "${name}"
    else
      printf '%-7s stopped\n' "${name}"
    fi
  done
  if command -v curl >/dev/null 2>&1; then
    if curl -fsS "${HEALTH_URL}" >/dev/null 2>&1; then
      printf 'health  ok       %s\n' "${HEALTH_URL}"
    else
      printf 'health  no answer at %s\n' "${HEALTH_URL}"
    fi
  fi
}

keepalive() {
  local name pidfile restarted=0
  for name in api worker; do
    pidfile="${RUN_DIR}/${name}.pid"
    if is_running "${pidfile}"; then
      continue
    fi
    log "${name} is not running — restarting it"
    restarted=1
  done
  [[ "${restarted}" -eq 1 ]] || return 0
  # `start` is idempotent: a process that is already up is left alone.
  start >/dev/null 2>&1 || true
  status
}

case "${1:-status}" in
  start)   start ;;
  keepalive) keepalive ;;
  stop)    stop ;;
  restart) stop; start ;;
  status)  status ;;
  logs)    tail -n 100 -f "${LOG_DIR}"/api.log "${LOG_DIR}"/worker.log ;;
  *) die "usage: $0 {start|stop|restart|status|logs}" ;;
esac
