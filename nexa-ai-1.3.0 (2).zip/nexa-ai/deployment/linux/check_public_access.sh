#!/usr/bin/env bash
# Nexa AI — can a browser outside this machine open the address the installer printed?
#
# Usage: bash deployment/linux/check_public_access.sh [--port N] [--host IP] [--public-ip IP]
#                                                    [--scheme http|https] [--host-header NAME]
#                                                    [--wait SECONDS]
#
# It answers one question honestly: "if I type http://<address>:<port> into a browser that is
# NOT this machine, will something open?"  The installer runs it at the end of the install and
# you can re-run it after you change a firewall rule.
#
# Exit codes:  0 = an address answered        (the app is reachable at the printed URL)
#              3 = no address answered        (the port is filtered, or the host is behind NAT
#                                              and the port is not forwarded/mapped to it)
#              4 = the outside address could not be tested (no public address / offline)
set -Eeuo pipefail

PORT="${NEXA_PUBLIC_PORT:-8080}"
HOST=""
HOST_IS_NAT=0
PUBLIC_IP="${NEXA_PUBLIC_IP:-}"
WAIT=15
PATH_PROBE="/readyz"
# A domain deployment is checked with --scheme https. --host-header sends "Host: <domain>" to a
# literal address, which is exactly what a browser does once DNS points here — so the TLS
# endpoint can be verified before touching DNS (use --insecure for a self-signed certificate).
SCHEME="${NEXA_PUBLIC_SCHEME:-http}"
HOST_HEADER=""
INSECURE=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --port)        PORT="$2"; shift 2 ;;
    --host)        HOST="$2"; shift 2 ;;
    --public-ip)   PUBLIC_IP="$2"; shift 2 ;;
    --scheme)      SCHEME="$2"; shift 2 ;;
    --host-header) HOST_HEADER="$2"; shift 2 ;;
    --insecure)    INSECURE=1; shift ;;
    --wait)        WAIT="$2"; shift 2 ;;
    -h|--help)
      sed -n '2,16p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
      exit 0 ;;
    *) printf '[error] unknown option: %s (try --help)\n' "$1" >&2; exit 2 ;;
  esac
done

say()  { printf '[check] %s\n' "$*"; }
ok()   { printf '[ok] %s\n' "$*"; }
warn() { printf '[warning] %s\n' "$*"; }
err()  { printf '[error] %s\n' "$*" >&2; }

have() { command -v "$1" >/dev/null 2>&1; }

# curl arguments shared by every probe: HTTPS/self-signed and an explicit Host header.
CURL_EXTRA=()
# --insecure is for a self-signed certificate (for example while verifying the domain path before
# certificate authority issuance); with a real certificate leave it off so the chain is validated.
if [[ "${SCHEME}" == "https" && "${INSECURE}" -eq 1 ]]; then
  CURL_EXTRA+=(-k)
fi
[[ -n "${HOST_HEADER}" ]] && CURL_EXTRA+=(-H "Host: ${HOST_HEADER}")

if ! have curl; then
  err "curl is required for this check —  apt-get install -y curl  (or use --no-public-check in the installer)"
  exit 4
fi

# --- address helpers ---------------------------------------------------------
# A private/CGNAT/link-local address is *not* something an outside browser can open.
is_private_ipv4() {
  local ip="$1"
  [[ "${ip}" =~ ^10\. ]] && return 0
  [[ "${ip}" =~ ^192\.168\. ]] && return 0
  [[ "${ip}" =~ ^172\.(1[6-9]|2[0-9]|3[01])\. ]] && return 0
  [[ "${ip}" =~ ^100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\. ]] && return 0
  [[ "${ip}" =~ ^169\.254\. ]] && return 0
  [[ "${ip}" =~ ^127\. ]] && return 0
  return 1
}

local_ipv4_addresses() { # every IPv4 this host answers on
  hostname -I 2>/dev/null | tr ' ' '\n' | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' || true
}

public_ipv4() { # the address the rest of the Internet sees us as (best effort)
  local service value
  for service in "https://api.ipify.org" "https://ifconfig.me/ip" "https://icanhazip.com"; do
    value="$(curl -4 -fsS --max-time 6 "${service}" 2>/dev/null | tr -d '[:space:]' || true)"
    if [[ "${value}" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
      printf '%s' "${value}"
      return 0
    fi
  done
  return 1
}

# probe <url> -> prints "<http code>|<reason>" and returns 1 when nothing answered
probe() {
  local url="$1" out code detail
  out="$(curl -s -o /dev/null -m 6 -w '%{http_code}|%{errormsg}' "${CURL_EXTRA[@]+"${CURL_EXTRA[@]}"}" "${url}" 2>/dev/null || true)"
  code="${out%%|*}"
  detail="${out#*|}"
  if [[ -n "${code}" && "${code}" != "000" ]]; then
    printf '%s|\n' "${code}"
    return 0
  fi
  # curl older than 7.75 does not understand %{errormsg} and echoes it literally
  case "${detail}" in ""|*'%{'*) detail="no answer" ;; esac
  printf '000|%s\n' "${detail}"
  return 1
}

# --- 1. is the application actually running on this machine? ------------------
if [[ "${WAIT}" -gt 0 ]]; then
  # A local readiness wait: with --scheme https this asks https on loopback, so the wait never
  # mistakes "port 443 refuses plain HTTP" (nginx answers 400 to that) for a dead service.
  waited=0
  while [[ "${waited}" -lt "${WAIT}" ]]; do
    if probe "${SCHEME}://127.0.0.1:${PORT}${PATH_PROBE}" >/dev/null 2>&1; then
      break
    fi
    sleep 1
    waited=$((waited + 1))
  done
  if ! probe "${SCHEME}://127.0.0.1:${PORT}${PATH_PROBE}" >/dev/null 2>&1; then
    warn "nothing is answering on ${SCHEME}://127.0.0.1:${PORT}${PATH_PROBE} on this machine either."
    warn "start the application first:  sudo systemctl start nexa-api nexa-worker"
    warn "                         or:  sudo deployment/linux/nexa-services.sh start"
  fi
fi

# --- 2. work out which addresses to test -------------------------------------
PUBLIC_TESTED=0
PUBLIC_REACHABLE=0
LAN_REACHABLE=0
NO_ADDRESS=1

declare -a TARGETS=()

if [[ -n "${HOST}" ]]; then
  TARGETS+=("${HOST}|requested")
else
  if [[ -z "${PUBLIC_IP}" ]]; then
    PUBLIC_IP="$(public_ipv4 || true)"
  fi
  if [[ -n "${PUBLIC_IP}" ]]; then
    say "public IPv4 address of this machine: ${PUBLIC_IP}"
    if is_private_ipv4 "${PUBLIC_IP}"; then
      warn "that address is private/CGNAT — a browser outside cannot use it directly"
    fi
    TARGETS+=("${PUBLIC_IP}|public")
  else
    warn "the public IPv4 address of this machine could not be determined (offline?)"
  fi
  local_ips="$(local_ipv4_addresses | tr '\n' ' ')"
  while IFS= read -r ip; do
    if [[ -n "${ip}" && "${ip}" != "${PUBLIC_IP}" ]]; then
      TARGETS+=("${ip}|local")
    fi
  done < <(local_ipv4_addresses)
  # If none of this machine's own addresses is the address the Internet sees, the host sits
  # behind NAT: opening a port on it is not enough, somebody has to forward/map the port.
  if [[ -n "${PUBLIC_IP}" ]]; then
    HOST_IS_NAT=1
    while IFS= read -r ip; do
      if [[ -n "${ip}" && "${ip}" == "${PUBLIC_IP}" ]]; then
        HOST_IS_NAT=0
      fi
    done < <(local_ipv4_addresses)
  fi
fi

for entry in "${TARGETS[@]:-}"; do
  if [[ -z "${entry}" ]]; then
    continue
  fi
  ip="${entry%%|*}"
  kind="${entry##*|}"
  NO_ADDRESS=0
  result="$(probe "${SCHEME}://${ip}:${PORT}${PATH_PROBE}" || true)"
  code="${result%%|*}"
  detail="${result#*|}"
  if [[ "${code}" != "000" && -n "${code}" ]]; then
    case "${kind}" in
      public) PUBLIC_TESTED=1; PUBLIC_REACHABLE=1
              ok "${SCHEME}://${ip}:${PORT}  answered with HTTP ${code} — reachable from outside (and from this machine)" ;;
      *)      LAN_REACHABLE=1
              ok "${SCHEME}://${ip}:${PORT}  answered with HTTP ${code} — reachable on this machine/network side" ;;
    esac
  else
    if [[ "${kind}" == "public" ]]; then
      PUBLIC_TESTED=1
    fi
    warn "${SCHEME}://${ip}:${PORT}  no answer (${detail:-connection failed})"
  fi
done

if [[ "${NO_ADDRESS}" -eq 1 ]]; then
  err "no address to test: pass --host <ip> or --public-ip <ip>"
  exit 4
fi

# --- 3. verdict --------------------------------------------------------------
if [[ "${PUBLIC_REACHABLE}" -eq 1 ]]; then
  ok "a browser outside this machine can open ${SCHEME}://${PUBLIC_IP}:${PORT}"
  exit 0
fi

# An explicitly requested address gets a definitive answer, nothing else is probed.
if [[ -n "${HOST}" ]]; then
  if probe "${SCHEME}://${HOST}:${PORT}${PATH_PROBE}" >/dev/null 2>&1; then
    ok "a browser pointed at ${SCHEME}://${HOST}:${PORT} gets an answer (a refusal from the app itself still counts)"
    exit 0
  fi
  err "${SCHEME}://${HOST}:${PORT} did not answer; the port is closed, filtered, or not forwarded here"
  exit 3
fi

if [[ "${PUBLIC_TESTED}" -eq 0 ]]; then
  if [[ "${LAN_REACHABLE}" -eq 1 ]]; then
    warn "the local address answered — this machine serves the app — but whether another machine"
    warn "can reach it could not be tested (no public IPv4 was determined; offline?)"
    exit 4
  fi
  err "nothing answered on port ${PORT} from this machine either — the application is not running"
  exit 3
fi

printf '\n'
err "${SCHEME}://${PUBLIC_IP}:${PORT} did NOT answer from this machine."
warn "That is what a browser on another machine would get: no connection."
if [[ "${HOST_IS_NAT}" -eq 1 ]]; then
  warn "This machine's own addresses ($(local_ipv4_addresses | paste -sd, -)) are private, so the app"
  warn "is only bound to it locally: the public address ${PUBLIC_IP} belongs to whoever runs the NAT"
  warn "(cloud provider, VPS panel, router). Inbound TCP ${PORT} has to be forwarded or 1:1-mapped"
  warn "to this machine there — until then no outside browser can connect, whatever is done here."
fi
warn "In addition, this host or the provider may filter the port:"
warn "  ufw (Debian/Ubuntu):   sudo ufw allow ${PORT}/tcp"
warn "  firewalld (RHEL):      sudo firewall-cmd --add-port=${PORT}/tcp --permanent && sudo firewall-cmd --reload"
warn "  nftables/iptables:     sudo iptables -I INPUT -p tcp --dport ${PORT} -j ACCEPT"
warn "  cloud / VPS / router:  add an inbound TCP ${PORT} rule to the security group / firewall"
warn "                         (AWS, GCP, Azure, Oracle, Hetzner, OVH, home router, ...)"
printf '\n'
warn "test again from a machine that is not this one:  curl -v ${SCHEME}://${PUBLIC_IP}:${PORT}/readyz"
warn "re-run here after a change:                      bash deployment/linux/check_public_access.sh --port ${PORT}"
printf '\n'
warn "The application itself is running — this is only about the path between a browser and this port."
exit 3
