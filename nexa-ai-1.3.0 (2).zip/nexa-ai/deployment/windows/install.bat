@echo off
REM ============================================================================
REM  Nexa AI - Windows installer (native install, no Docker required)
REM
REM  Run from an elevated Command Prompt:
REM     cd C:\path\to\nexa-ai
REM     deployment\windows\install.bat
REM
REM  Steps: check Python/Node, create the virtual environment, install the
REM  backend, build the frontend, create .env with fresh secrets, run migrations,
REM  bootstrap roles/settings and the first administrator, verify the install and
REM  print the next steps.
REM
REM  The script is idempotent: running it again keeps an existing .env, database
REM  and frontend build, and only refreshes what is missing.
REM ============================================================================
setlocal EnableDelayedExpansion
chcp 65001 >nul

set "ROOT=%~dp0..\.."
pushd "%ROOT%" || (echo [error] cannot find the project root & exit /b 1)
set "ROOT=%CD%"
set "PY=%ROOT%\.venv\Scripts\python.exe"

echo ============================================================
echo  Nexa AI installer
echo  Project root: %ROOT%
echo ============================================================
echo.

REM --- 1. prerequisites ------------------------------------------------------
where python >nul 2>&1
if errorlevel 1 (
  echo [error] Python 3.11 or newer is required.
  echo         Download: https://www.python.org/downloads/windows/
  echo         During setup tick "Add python.exe to PATH".
  exit /b 1
)
for /f "tokens=2" %%v in ('python --version 2^>^&1') do set "PYVER=%%v"
for /f "tokens=1,2 delims=." %%a in ("!PYVER!") do (
  set "PYMAJOR=%%a"
  set "PYMINOR=%%b"
)
if !PYMAJOR! LSS 3 (echo [error] Python !PYVER! is too old - 3.11+ required. & exit /b 1)
if !PYMAJOR! EQU 3 if !PYMINOR! LSS 11 (echo [error] Python !PYVER! is too old - 3.11+ required. & exit /b 1)
echo [1/8] Python found: %PYVER%

where node >nul 2>&1
if errorlevel 1 (
  echo [warning] Node.js was not found - the interface cannot be built.
  echo           Install Node.js 20 LTS from https://nodejs.org and re-run this
  echo           script, or build later with:
  echo               cd frontend ^&^& npm install ^&^& npm run build
  set "SKIP_FRONTEND=1"
) else (
  for /f "tokens=*" %%v in ('node --version 2^>^&1') do set "NODEVER=%%v"
  echo [1/8] Node.js found: !NODEVER!
  set "SKIP_FRONTEND=0"
)

REM --- 2. virtual environment ------------------------------------------------
echo [2/8] Creating the Python virtual environment (.venv)
if not exist "%PY%" (
  python -m venv "%ROOT%\.venv" || (echo [error] virtual environment creation failed & exit /b 1)
)
"%PY%" -m pip install --upgrade pip wheel >nul 2>&1
"%PY%" -m pip install -r "%ROOT%\backend\requirements.txt" || (echo [error] dependency installation failed & exit /b 1)
echo       backend dependencies installed

REM --- 3. environment file ---------------------------------------------------
echo [3/8] Preparing .env
if exist "%ROOT%\.env" (
  echo       .env already exists - keeping your settings ^(data and passwords are preserved^)
  for /f "tokens=1,* delims==" %%a in ('findstr /b "NEXA_BOOTSTRAP_ADMIN_PASSWORD" "%ROOT%\.env" 2^>nul') do set "ADMIN_PASSWORD=%%b"
  for /f "tokens=1,* delims==" %%a in ('findstr /b "NEXA_BOOTSTRAP_ADMIN_EMAIL" "%ROOT%\.env" 2^>nul') do set "ADMIN_EMAIL=%%b"
  for /f "tokens=1,* delims==" %%a in ('findstr /b "NEXA_DEPLOYMENT_MODE" "%ROOT%\.env" 2^>nul') do set "ACCESS_MODE_ENV=%%b"
  echo       To change the access mode or the administrator, delete/rename .env and run this again,
  echo       or use:  deployment\windows\set_admin.bat   (change e-mail/password later)
) else (
  REM ---- the operator decides: who can reach it, and which administrator exists ---------------
  set "ACCESS=local"
  set "PUBLIC_PORT=8000"
  choice /c 12 /n /m "Who should be able to open the application?   [1] only this PC (default)   [2] other machines on my network / the Internet: "
  if errorlevel 2 set "ACCESS=public"
  if errorlevel 1 if not errorlevel 2 set "ACCESS=local"

  if /i "!ACCESS!"=="public" (
    echo.
    echo       *** SECURITY WARNING ***
    echo       Public mode serves the application over PLAIN HTTP on a reachable address.
    echo       Traffic - including passwords and session cookies - is NOT encrypted. Use it
    echo       for testing only, and switch to a domain with HTTPS before real use.
    set /p PUBLIC_PORT=Port to publish [8000]:
    if "!PUBLIC_PORT!"=="" set "PUBLIC_PORT=8000"
    REM the address other machines will use: the public IP when there is one, else the LAN IPv4
    for /f "delims=" %%i in ('powershell -NoProfile -Command "try{(Invoke-RestMethod -TimeoutSec 6 https://api.ipify.org?format=json).ip}catch{}" 2^>nul') do set "PUBLIC_IP=%%i"
    if "!PUBLIC_IP!"=="" for /f "tokens=2 delims=:" %%i in ('ipconfig ^| findstr /c:"IPv4"') do (
      if not defined LAN_IP (
        set "LAN_IP=%%i"
        set "LAN_IP=!LAN_IP: =!"
      )
    )
    if "!PUBLIC_IP!"=="" if defined LAN_IP set "PUBLIC_IP=!LAN_IP!"
    if "!PUBLIC_IP!"=="" (
      echo       [warning] could not detect an address automatically.
      set /p PUBLIC_IP=Address other machines should use (e.g. 192.168.1.20):
    ) else (
      echo       Detected address: !PUBLIC_IP!
    )
  )

  set "ADMIN_EMAIL="
  set /p ADMIN_EMAIL=Administrator e-mail [admin@example.com]:
  if "!ADMIN_EMAIL!"=="" set "ADMIN_EMAIL=admin@example.com"
  echo !ADMIN_EMAIL!| findstr /r /c:"^[A-Za-z0-9._%%+-][A-Za-z0-9._%%+-]*@[A-Za-z0-9.-][A-Za-z0-9.-]*\.[A-Za-z][A-Za-z]*$" >nul || (
    echo       [warning] "!ADMIN_EMAIL!" does not look like an e-mail address - using admin@example.com
    set "ADMIN_EMAIL=admin@example.com"
  )

  set "ADMIN_NAME="
  set /p ADMIN_NAME=Administrator display name [Nexa Administrator]:
  if "!ADMIN_NAME!"=="" set "ADMIN_NAME=Nexa Administrator"

  echo.
  echo       Administrator password: typing is hidden and never ends up in a log file.
  echo       Press Enter alone to have a strong one generated instead.
  set "ADMIN_PASSWORD="
  for /f "delims=" %%p in ('powershell -NoProfile -Command "$s=Read-Host -AsSecureString -Prompt \"Password (min 10 chars)\"; [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s))" 2^>nul') do set "ADMIN_PASSWORD=%%p"
  if "!ADMIN_PASSWORD!"=="" (
    echo       ^(no password typed - generating one^)
  ) else (
    echo       password accepted ^(!ADMIN_PASSWORD:~0,0!hidden^)
  )
  for /f "delims=" %%s in ('"%PY%" -c "import secrets;print(secrets.token_urlsafe(48))"') do set "SECRET_KEY=%%s"
  for /f "delims=" %%k in ('"%PY%" -c "import base64,os;print(base64.urlsafe_b64encode(os.urandom(32)).decode())"') do set "ENCRYPTION_KEY=%%k"
  if "!ADMIN_PASSWORD!"=="" for /f "delims=" %%p in ('"%PY%" -c "import secrets;print('Aa1'+secrets.token_urlsafe(12))"') do set "ADMIN_PASSWORD=%%p"

  > "%ROOT%\.env" echo # Nexa AI configuration - generated by install.bat on %DATE% %TIME%
  >>"%ROOT%\.env" echo NEXA_ENVIRONMENT=development
  if /i "!ACCESS!"=="public" (
    >>"%ROOT%\.env" echo NEXA_DEPLOYMENT_MODE=public_ip
    >>"%ROOT%\.env" echo NEXA_PUBLIC_BASE_URL=http://!PUBLIC_IP!:!PUBLIC_PORT!
    >>"%ROOT%\.env" echo NEXA_PUBLIC_PORT=!PUBLIC_PORT!
    >>"%ROOT%\.env" echo NEXA_PUBLIC_IP=!PUBLIC_IP!
    >>"%ROOT%\.env" echo NEXA_TRUSTED_HOSTS=127.0.0.1,localhost,!PUBLIC_IP!
    >>"%ROOT%\.env" echo NEXA_CORS_ORIGINS=http://!PUBLIC_IP!:!PUBLIC_PORT!,http://127.0.0.1:!PUBLIC_PORT!
  ) else (
    >>"%ROOT%\.env" echo NEXA_DEPLOYMENT_MODE=local
    >>"%ROOT%\.env" echo NEXA_PUBLIC_BASE_URL=http://127.0.0.1:8000
  )
  >>"%ROOT%\.env" echo NEXA_SECRET_KEY=!SECRET_KEY!
  >>"%ROOT%\.env" echo NEXA_ENCRYPTION_KEY=!ENCRYPTION_KEY!
  >>"%ROOT%\.env" echo NEXA_DATABASE_URL=sqlite:///!ROOT:\=/!/data/nexa.db
  >>"%ROOT%\.env" echo NEXA_UPLOAD_DIR=!ROOT:\=/!/uploads
  >>"%ROOT%\.env" echo NEXA_SERVE_FRONTEND=true
  >>"%ROOT%\.env" echo NEXA_FRONTEND_DIST_DIR=!ROOT:\=/!/frontend/dist
  >>"%ROOT%\.env" echo NEXA_BOOTSTRAP_ADMIN_EMAIL=!ADMIN_EMAIL!
  >>"%ROOT%\.env" echo NEXA_BOOTSTRAP_ADMIN_NAME=!ADMIN_NAME!
  >>"%ROOT%\.env" echo NEXA_BOOTSTRAP_ADMIN_PASSWORD=!ADMIN_PASSWORD!
  >>"%ROOT%\.env" echo NEXA_LOG_LEVEL=INFO
  >>"%ROOT%\.env" echo NEXA_COOKIE_SECURE=false
  >>"%ROOT%\.env" echo NEXA_HSTS_ENABLED=false
  >>"%ROOT%\.env" echo NEXA_REGISTRATION_MODE=open
  >>"%ROOT%\.env" echo # true = the API process also runs jobs and Telegram polling (single-process local install)
  >>"%ROOT%\.env" echo NEXA_INLINE_WORKER=true
  >>"%ROOT%\.env" echo NEXA_MANUAL_PAYMENTS_ENABLED=true
  >>"%ROOT%\.env" echo NEXA_EMAIL_ENABLED=false
  >>"%ROOT%\.env" echo.
  >>"%ROOT%\.env" echo # --- optional: Telegram bot (see docs/TELEGRAM.md) ---------------------
  >>"%ROOT%\.env" echo # NEXA_TELEGRAM_ENABLED=false
  >>"%ROOT%\.env" echo # NEXA_TELEGRAM_BOT_TOKEN=
  >>"%ROOT%\.env" echo # NEXA_TELEGRAM_BOT_USERNAME=
  >>"%ROOT%\.env" echo # NEXA_TELEGRAM_MODE=polling
  echo       .env created. Administrator: !ADMIN_EMAIL!
  if /i "!ACCESS!"=="public" (
    echo       Access: http://!PUBLIC_IP!:!PUBLIC_PORT!  ^(plain HTTP - testing only^)
  ) else (
    echo       Access: this PC only ^(http://127.0.0.1:8000^)
  )
  if "!ADMIN_PASSWORD!"=="" (
    echo       Password: generated, stored in %ROOT%\.env ^(NEXA_BOOTSTRAP_ADMIN_PASSWORD^).
  ) else (
    echo       Password: the one you chose.
  )
  echo       This default configuration uses SQLite, which is meant for local testing.
)

REM --- 4. frontend -----------------------------------------------------------
if "%SKIP_FRONTEND%"=="0" (
  echo [4/8] Building the interface
  pushd "%ROOT%\frontend"
  call npm install --no-audit --no-fund || (echo [error] npm install failed & popd & exit /b 1)
  call npm run build || (echo [error] frontend build failed & popd & exit /b 1)
  popd
  echo       built into frontend\dist
) else (
  echo [4/8] skipped ^(Node.js missing^)
)

REM --- 5. migrations ---------------------------------------------------------
echo [5/8] Applying database migrations
pushd "%ROOT%\backend"
"%PY%" -m alembic upgrade head || (echo [error] database migration failed & popd & exit /b 1)
popd

REM --- 6. bootstrap ----------------------------------------------------------
echo [6/8] Seeding roles, permissions, settings and the administrator
pushd "%ROOT%\backend"
"%PY%" -m app.cli bootstrap || (echo [error] bootstrap failed & popd & exit /b 1)
"%PY%" -m app.cli check-secrets || echo       [warning] credential audit reported a problem - run diagnose.bat
popd

REM --- 7. data folders, firewall, shortcuts ----------------------------------
for %%d in (data uploads logs backups run) do (
  if not exist "%ROOT%\%%d" mkdir "%ROOT%\%%d"
)
for %%d in (avatars files images) do (
  if not exist "%ROOT%\uploads\%%d" mkdir "%ROOT%\uploads\%%d"
)
echo [7/8] Data folders ready

set "FWPORT=8000"
if /i "%ACCESS%"=="public" if defined PUBLIC_PORT set "FWPORT=%PUBLIC_PORT%"
netsh advfirewall firewall show rule name="Nexa AI API" >nul 2>&1
if errorlevel 1 (
  netsh advfirewall firewall add rule name="Nexa AI API" dir=in action=allow protocol=TCP localport=%FWPORT% >nul 2>&1
  if errorlevel 1 (
    echo       [warning] could not add the firewall rule - allow TCP %FWPORT% manually
    echo                 ^(Windows Security -^> Firewall -^> Advanced settings -^> Inbound rules^)
  ) else (
    echo       firewall rule added for TCP %FWPORT%
  )
)

call "%ROOT%\deployment\windows\make_shortcuts.bat"

REM --- 8. verify -------------------------------------------------------------
echo [8/8] Verifying the installation
pushd "%ROOT%\backend"
"%PY%" -m app.cli doctor
popd

echo.
echo ============================================================
echo  Installation finished.
echo.
echo    Start the application:  deployment\windows\start.bat
if /i "%ACCESS%"=="public" (
  echo    Then open on this PC:   http://127.0.0.1:%PUBLIC_PORT%
  echo    And share this address: http://%PUBLIC_IP%:%PUBLIC_PORT%
  echo      If other machines cannot open it: the Windows firewall rule for TCP %PUBLIC_PORT%
  echo      must exist ^(added above^); behind a router/NAT the port must also be forwarded to
  echo      this PC; a public IP from your provider is required for the Internet, and an
  echo      address starting with 192.168./10./172. is your own network only.
) else (
  echo    Then open:              http://127.0.0.1:8000
  echo      Other machines cannot reach it in this mode. To change that, delete .env and run
  echo      install.bat again choosing option 2 ^(or run start_public.bat for a one-off^).
)
echo    Administrator:          %ADMIN_EMAIL%
echo    Password:               %ADMIN_PASSWORD%
echo    Health check any time:  deployment\windows\verify.bat
echo.
echo  Production notes:
echo    * SQLite is used by default here. For a real deployment switch
echo      NEXA_DATABASE_URL to PostgreSQL (docs/INSTALL_WINDOWS.md).
echo    * Next steps in the browser: Admin -> Providers -> add a real
echo      provider and its API key, then Admin -> Models -> sync, test and
echo      publish. Nothing is published automatically; see docs/MODEL_MANAGEMENT.md.
echo    * start_public.bat still exists for a one-off exposure; the mode chosen above is
echo      permanent (it is written into .env and start.bat binds accordingly).
echo    * For HTTPS with a domain follow docs/PRODUCTION_DEPLOYMENT.md.
echo ============================================================
popd

REM --- keep the window open when this file was double-clicked -------------------
REM     (when it runs inside an already open console, nothing is paused)
echo "%CMDCMDLINE%" | find /i "%~nx0" >nul && pause

endlocal
