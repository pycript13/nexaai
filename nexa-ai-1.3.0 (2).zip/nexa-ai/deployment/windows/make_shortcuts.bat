@echo off
REM Nexa AI - create Desktop shortcuts for the start/stop/diagnose scripts.
setlocal
set "ROOT=%~dp0..\.."
set "DESKTOP=%USERPROFILE%\Desktop"
if not exist "%DESKTOP%" set "DESKTOP=%PUBLIC%\Desktop"

for %%s in (start start_public start_worker verify diagnose backup) do (
  > "%TEMP%\nexa_shortcut.vbs" echo Set oWS = WScript.CreateObject("WScript.Shell")
  >>"%TEMP%\nexa_shortcut.vbs" echo sLinkFile = "%DESKTOP%\Nexa AI - %%s.lnk"
  >>"%TEMP%\nexa_shortcut.vbs" echo Set oLink = oWS.CreateShortcut(sLinkFile)
  >>"%TEMP%\nexa_shortcut.vbs" echo oLink.TargetPath = "%ROOT%\deployment\windows\%%s.bat"
  >>"%TEMP%\nexa_shortcut.vbs" echo oLink.WorkingDirectory = "%ROOT%"
  >>"%TEMP%\nexa_shortcut.vbs" echo oLink.Save
  cscript //nologo "%TEMP%\nexa_shortcut.vbs" >nul 2>&1
)
del "%TEMP%\nexa_shortcut.vbs" >nul 2>&1
echo       shortcuts created on the Desktop ^(start / start_public / start_worker / verify / diagnose / backup^)
endlocal
