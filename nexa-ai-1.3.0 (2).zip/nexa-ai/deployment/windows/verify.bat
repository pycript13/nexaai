@echo off
REM ============================================================================
REM  Nexa AI - one-command health check ("did the installation actually work?")
REM
REM  Checks, in order:
REM    1. the virtual environment and dependencies,
REM    2. the configuration (masked report),
REM    3. the database schema is at the latest migration,
REM    4. stored provider credentials still decrypt,
REM    5. the running API answers /healthz and /readyz,
REM    6. the database, queue and inline worker state.
REM
REM  Exit code is 0 when everything is fine, 1 when something needs attention.
REM ============================================================================
setlocal EnableDelayedExpansion
chcp 65001 >nul
set "ROOT=%~dp0..\.."
set "PY=%ROOT%\.venv\Scripts\python.exe"
set "FAILED=0"
pushd "%ROOT%\backend" || exit /b 1

echo ============================================================
echo  Nexa AI verification
echo ============================================================
echo.

if not exist "%PY%" (
  echo [FAIL] .venv is missing - run deployment\windows\install.bat
  set "FAILED=1"
  goto :probes
)
echo [ok] virtual environment found

"%PY%" -m app.cli doctor
if errorlevel 1 (echo [FAIL] configuration report found problems & set "FAILED=1") else (echo [ok] configuration read successfully)

echo.
echo --- database migrations -------------------------------------
"%PY%" -m alembic current
if errorlevel 1 (echo [FAIL] cannot read the migration state & set "FAILED=1")

echo.
echo --- stored provider credentials -----------------------------
"%PY%" -m app.cli check-secrets
if errorlevel 1 (echo [FAIL] a stored credential cannot be decrypted - re-save the provider key in Admin ^> Providers & set "FAILED=1") else (echo [ok] credentials decrypt)

:probes
echo.
echo --- running API ---------------------------------------------
powershell -NoProfile -Command ^
  "foreach ($p in @('/healthz','/readyz')) { try { $r = Invoke-WebRequest -UseBasicParsing ('http://127.0.0.1:8000' + $p) -TimeoutSec 5; Write-Host ('[ok] ' + $p + ' -> ' + $r.StatusCode + ' ' + $r.Content) } catch { Write-Host ('[warn] ' + $p + ' not reachable - is the app running? (start.bat)') } }"

echo.
echo --- queue and inline worker ---------------------------------
powershell -NoProfile -Command ^
  "try { $r = Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:8000/api/v1/health/deep' -TimeoutSec 5; Write-Host $r.Content } catch { Write-Host '[warn] /api/v1/health/deep not reachable' }"

echo.
echo ============================================================
if "%FAILED%"=="1" (
  echo  RESULT: problems were found above. Start with docs/TROUBLESHOOTING.md
  echo          and run deployment\windows\diagnose.bat for more detail.
  popd
  
REM --- keep the window open when this file was double-clicked -------------------
REM     (when it runs inside an already open console, nothing is paused)
echo "%CMDCMDLINE%" | find /i "%~nx0" >nul && pause

endlocal
  exit /b 1
)
echo  RESULT: the installation looks healthy.
echo          If a provider fails, use the provider diagnosis:
echo            "%PY%" -m app.cli provider-check --provider ^<slug^>
echo          ^(run from the backend folder; see docs/PROVIDER_CONFIGURATION.md^)
popd

REM --- keep the window open when this file was double-clicked -------------------
REM     (when it runs inside an already open console, nothing is paused)
echo "%CMDCMDLINE%" | find /i "%~nx0" >nul && pause

endlocal
exit /b 0
