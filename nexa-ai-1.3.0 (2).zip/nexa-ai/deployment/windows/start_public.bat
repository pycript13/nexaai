@echo off
REM ============================================================================
REM  Nexa AI - start the API on 0.0.0.0 so other machines can reach it.
REM
REM  *** SECURITY WARNING ***
REM  This runs the application over PLAIN HTTP on a public IP. There is no
REM  transport encryption: session cookies, passwords and administrator actions
REM  travel in clear text and can be read or modified by anyone on the path.
REM  Use it only for short-lived testing/demonstration on a trusted network.
REM  For anything real, use a domain with HTTPS (docs/PRODUCTION_DEPLOYMENT.md)
REM  and set NEXA_COOKIE_SECURE=true / NEXA_HSTS_ENABLED=true.
REM
REM  Usage:  start_public.bat [port]      (default port: 8000)
REM ============================================================================
setlocal EnableDelayedExpansion
chcp 65001 >nul
set "ROOT=%~dp0..\.."
set "PY=%ROOT%\.venv\Scripts\python.exe"
set "PORT=%~1"
if "%PORT%"=="" set "PORT=8000"
pushd "%ROOT%" || exit /b 1

if not exist "%PY%" (
  echo [error] .venv is missing. Run deployment\windows\install.bat first.
  exit /b 1
)
if not exist "%ROOT%\.env" (echo [error] .env is missing - run install.bat first & exit /b 1)

REM --- pick the LAN address Windows would use to reach the internet -----------
set "IP="
for /f "tokens=2 delims=:" %%i in ('ipconfig ^| findstr /c:"IPv4"') do (
  if not defined IP (
    set "IP=%%i"
    set "IP=!IP: =!"
  )
)

echo ============================================================
echo  SECURITY WARNING
echo  - HTTP only, no TLS: traffic is unencrypted and can be intercepted.
echo  - Anyone who can reach this port can attempt to sign in.
echo  - Keep the registration mode limited ^(invite_only/closed^) while exposed.
echo  - Stop the server as soon as testing is finished.
echo ============================================================
echo.
if defined IP (
  echo   On this machine:      http://127.0.0.1:%PORT%
  echo   From other machines:  http://!IP!:%PORT%
  echo   ^(if that address does not open, the port is not reachable from outside:
  echo    check the Windows firewall, and whether you are behind a router/NAT -
  echo    see docs/REMOTE_TESTING.md^)
) else (
  echo   Could not detect a LAN address - run "ipconfig" and use the IPv4 address.
)
echo.

REM Make the deployment honest: the app itself must know it is serving plain HTTP on
REM a public address, so its own API responses and banners carry the warning.
set "NEXA_DEPLOYMENT_MODE=public_ip"
if defined IP set "NEXA_PUBLIC_BASE_URL=http://!IP!:%PORT%"
set "NEXA_PUBLIC_IP=!IP!"
set "NEXA_TRUSTED_HOSTS=*"

echo Starting on 0.0.0.0:%PORT% ...
cd /d "%ROOT%\backend"
"%PY%" -m uvicorn app.main:app --host 0.0.0.0 --port %PORT%
popd
endlocal
