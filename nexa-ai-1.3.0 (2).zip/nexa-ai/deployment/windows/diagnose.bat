@echo off
REM ============================================================================
REM  Nexa AI - detailed diagnosis. Output is safe to share: secrets are masked.
REM ============================================================================
setlocal EnableDelayedExpansion
chcp 65001 >nul
set "ROOT=%~dp0..\.."
set "PY=%ROOT%\.venv\Scripts\python.exe"
pushd "%ROOT%\backend" || exit /b 1

if not exist "%PY%" (echo [error] .venv is missing - run install.bat first & popd & exit /b 1)

echo --- configuration and integrity ---------------------------------
"%PY%" -m app.cli doctor

echo.
echo --- stored provider credentials ---------------------------------
"%PY%" -m app.cli check-secrets

echo.
echo --- database revision -------------------------------------------
"%PY%" -m alembic current

echo.
echo --- HTTP probes -------------------------------------------------
powershell -NoProfile -Command ^
  "foreach ($p in @('/healthz','/readyz','/api/v1/health/deep')) { try { $r = Invoke-WebRequest -UseBasicParsing ('http://127.0.0.1:8000' + $p) -TimeoutSec 5; Write-Host ($p + ' -> ' + $r.StatusCode + ' ' + $r.Content) } catch { Write-Host ($p + ' -> not reachable (is the app running?)') } }"

echo.
echo To diagnose one provider end to end (DNS, TCP, TLS, models, chat, stream):
echo    "%PY%" -m app.cli provider-check --provider ^<slug^>
popd

REM --- keep the window open when this file was double-clicked -------------------
REM     (when it runs inside an already open console, nothing is paused)
echo "%CMDCMDLINE%" | find /i "%~nx0" >nul && pause

endlocal
