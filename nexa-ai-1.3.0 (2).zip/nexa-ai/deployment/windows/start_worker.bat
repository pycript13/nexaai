@echo off
REM Nexa AI - run the background job worker in this window.
REM The module is started from backend\ so `app` is importable and .env is found.
set "ROOT=%~dp0..\.."
set "PY=%ROOT%\.venv\Scripts\python.exe"
if not exist "%PY%" (echo [error] .venv is missing - run install.bat first & exit /b 1)
cd /d "%ROOT%\backend"
"%PY%" -m app.workers.worker
