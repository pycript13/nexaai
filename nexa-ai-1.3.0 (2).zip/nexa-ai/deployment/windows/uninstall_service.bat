@echo off
REM Nexa AI - remove the Windows services/scheduled tasks created by install_service.bat.
net session >nul 2>&1 || (echo [error] run as Administrator & exit /b 1)
where nssm >nul 2>&1
if not errorlevel 1 (
  nssm stop NexaAIAPI  >nul 2>&1
  nssm stop NexaAIWorker >nul 2>&1
  nssm remove NexaAIAPI confirm >nul 2>&1
  nssm remove NexaAIWorker confirm >nul 2>&1
  echo [done] NSSM services removed.
)
schtasks /delete /f /tn "NexaAIAPI" >nul 2>&1
schtasks /delete /f /tn "NexaAIWorker" >nul 2>&1
echo [done] scheduled tasks removed (if they existed).
netsh advfirewall firewall delete rule name="Nexa AI API" >nul 2>&1
echo [done] firewall rule removed (if it existed).

REM --- keep the window open when this file was double-clicked -------------------
REM     (when it runs inside an already open console, nothing is paused)
echo "%CMDCMDLINE%" | find /i "%~nx0" >nul && pause
