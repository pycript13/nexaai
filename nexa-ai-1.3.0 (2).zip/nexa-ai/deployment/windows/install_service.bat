@echo off
REM ============================================================================
REM  Nexa AI - install the API and worker as Windows services.
REM
REM  Two options are supported. Run this script as Administrator.
REM
REM   1) NSSM (recommended, if nssm.exe is on PATH or in the project root):
REM        nssm install NexaAIAPI ...
REM   2) Task Scheduler (always available, starts the processes at boot):
REM        schtasks /create ...
REM
REM  Usage: deployment\windows\install_service.bat [--scheduler]
REM ============================================================================
setlocal EnableDelayedExpansion
set "ROOT=%~dp0..\.."
set "PY=%ROOT%\.venv\Scripts\python.exe"
set "USESCHED=0"
if /i "%~1"=="--scheduler" set "USESCHED=1"

net session >nul 2>&1 || (echo [error] run this script as Administrator & exit /b 1)
if not exist "%PY%" (echo [error] %PY% is missing - run install.bat first & exit /b 1)

where nssm >nul 2>&1
if errorlevel 1 if exist "%ROOT%\nssm.exe" (set "PATH=%ROOT%;%PATH%")
where nssm >nul 2>&1
if errorlevel 1 set "USESCHED=1"

if "%USESCHED%"=="0" (
  echo [info] installing services with NSSM
  nssm install NexaAIAPI "%PY%" "-m" "uvicorn" "app.main:app" "--host" "127.0.0.1" "--port" "8000"
  nssm set NexaAIAPI AppDirectory "%ROOT%\backend"
  nssm set NexaAIAPI AppStdout "%ROOT%\logs\api.log"
  nssm set NexaAIAPI AppStderr "%ROOT%\logs\api-error.log"
  nssm set NexaAIAPI Start SERVICE_AUTO_START
  nssm set NexaAIAPI AppExit Default Restart

  nssm install NexaAIWorker "%PY%" "-m" "app.workers.worker"
  nssm set NexaAIWorker AppDirectory "%ROOT%\backend"
  nssm set NexaAIWorker AppStdout "%ROOT%\logs\worker.log"
  nssm set NexaAIWorker AppStderr "%ROOT%\logs\worker-error.log"
  nssm set NexaAIWorker Start SERVICE_AUTO_START
  nssm set NexaAIWorker AppExit Default Restart

  nssm start NexaAIAPI
  nssm start NexaAIWorker
  echo [done] services installed: NexaAIAPI / NexaAIWorker ^(manage with: nssm edit NexaAIAPI^)
) else (
  echo [info] NSSM not found - using Task Scheduler ^(ONSTART^) instead
  if not exist "%ROOT%\logs" mkdir "%ROOT%\logs"
  REM the process must run with backend\ as the working directory
  set "CMDARGS=/c cd /d \"%ROOT%\backend\" && \"%PY%\" -m uvicorn app.main:app --host 127.0.0.1 --port 8000"
  schtasks /create /f /tn "NexaAIAPI" /sc onstart /ru SYSTEM /rl highest /tr "cmd %CMDARGS%"
  set "CMDARGS=/c cd /d \"%ROOT%\backend\" && \"%PY%\" -m app.workers.worker"
  schtasks /create /f /tn "NexaAIWorker" /sc onstart /ru SYSTEM /rl highest /tr "cmd %CMDARGS%"
  set "CMDARGS="
  schtasks /run /tn "NexaAIAPI"
  schtasks /run /tn "NexaAIWorker"
  echo [done] scheduled tasks created and started.
  echo        Note: Task Scheduler does not restart a crashed process. For
  echo        production use NSSM or a Windows container.
)

echo.
echo Remember: on a public IP this deployment is plain HTTP. Read the warning in
echo docs/PRODUCTION_DEPLOYMENT.md before exposing it to the internet.

REM --- keep the window open when this file was double-clicked -------------------
REM     (when it runs inside an already open console, nothing is paused)
echo "%CMDCMDLINE%" | find /i "%~nx0" >nul && pause

endlocal
