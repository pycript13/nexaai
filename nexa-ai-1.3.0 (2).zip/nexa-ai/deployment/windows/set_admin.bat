@echo off
REM ============================================================================
REM  Nexa AI - create or change the main administrator (e-mail / name / password)
REM
REM  Run from an elevated Command Prompt (or double-click):
REM      deployment\windows\set_admin.bat
REM
REM  What it does:
REM    * asks for the e-mail, the display name and the password (typing is hidden
REM      through PowerShell and the value never lands in a log file);
REM    * updates .env so the installer's own account data stays in sync;
REM    * creates the account when it does not exist yet, otherwise resets that
REM      account's password (the change is written to the audit log, and every
REM      session of that user is revoked).
REM
REM  Press Enter at the password question to have a strong one generated.
REM ============================================================================
setlocal EnableDelayedExpansion
chcp 65001 >nul
set "ROOT=%~dp0..\.."
pushd "%ROOT%" || (echo [error] cannot find the project root & exit /b 1)
set "ROOT=%CD%"
set "PY=%ROOT%\.venv\Scripts\python.exe"

if not exist "%PY%" (
  echo [error] .venv is missing - run deployment\windows\install.bat first.
  exit /b 1
)
if not exist "%ROOT%\.env" (
  echo [error] .env is missing - run deployment\windows\install.bat first.
  exit /b 1
)

REM --- current values, offered as defaults -------------------------------------
set "CURRENT_EMAIL="
set "CURRENT_NAME="
for /f "tokens=1,* delims==" %%a in ('findstr /b "NEXA_BOOTSTRAP_ADMIN_EMAIL" "%ROOT%\.env" 2^>nul') do set "CURRENT_EMAIL=%%b"
for /f "tokens=1,* delims==" %%a in ('findstr /b "NEXA_BOOTSTRAP_ADMIN_NAME" "%ROOT%\.env" 2^>nul') do set "CURRENT_NAME=%%b"
if "%CURRENT_EMAIL%"=="" set "CURRENT_EMAIL=admin@example.com"
if "%CURRENT_NAME%"=="" set "CURRENT_NAME=Nexa Administrator"

echo ============================================================
echo  Nexa AI - main administrator
echo ============================================================
echo.

set "ADMIN_EMAIL="
set /p ADMIN_EMAIL=E-mail ^(sign-in name^) [%CURRENT_EMAIL%]:
if "!ADMIN_EMAIL!"=="" set "ADMIN_EMAIL=%CURRENT_EMAIL%"
echo !ADMIN_EMAIL!| findstr /r /c:"^[A-Za-z0-9._%%+-][A-Za-z0-9._%%+-]*@[A-Za-z0-9.-][A-Za-z0-9.-]*\.[A-Za-z][A-Za-z]*$" >nul || (
  echo [error] "!ADMIN_EMAIL!" is not a valid e-mail address.
  popd & exit /b 2
)

set "ADMIN_NAME="
set /p ADMIN_NAME=Display name [%CURRENT_NAME%]:
if "!ADMIN_NAME!"=="" set "ADMIN_NAME=%CURRENT_NAME%"

echo.
echo Password: typing is hidden. At least 10 characters, or press Enter to generate one.
set "ADMIN_PASSWORD="
for /f "delims=" %%p in ('powershell -NoProfile -Command "$s=Read-Host -AsSecureString -Prompt \"Password\"; [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s))" 2^>nul') do set "ADMIN_PASSWORD=%%p"

set "GENERATE="
if "!ADMIN_PASSWORD!"=="" set "GENERATE=1"
if defined GENERATE (
  echo       no password typed - a strong one will be generated and printed once
) else (
  REM length check without echoing the value
  for /f "delims=" %%n in ('powershell -NoProfile -Command "Write-Output $env:ADMIN_PASSWORD.Length"') do set "PWLEN=%%n"
  if !PWLEN! LSS 10 (
    echo [error] the password must be at least 10 characters.
    popd & exit /b 2
  )
)

echo.
echo [1/2] updating .env
call :update_env "NEXA_BOOTSTRAP_ADMIN_EMAIL" "!ADMIN_EMAIL!"
call :update_env "NEXA_BOOTSTRAP_ADMIN_NAME"  "!ADMIN_NAME!"

echo [2/2] creating or updating the account
pushd "%ROOT%\backend"
if defined GENERATE (
  REM create-admin refuses to overwrite an existing account, which is exactly what we need:
  REM it proves the account is new, and the generator prints the password once.
  "%PY%" -m app.cli create-admin --email "!ADMIN_EMAIL!" --name "!ADMIN_NAME!" --generate --role super_admin
  if errorlevel 1 (
    echo       account already exists - generating a new password for it
    "%PY%" -m app.cli reset-password --email "!ADMIN_EMAIL!" --generate
    if errorlevel 1 (
      popd
      echo [error] could not update the administrator - see the message above.
      exit /b 1
    )
  )
) else (
  REM set the password through the environment so it never appears in the process list:
  REM the CLI falls back to NEXA_ADMIN_PASSWORD when the flag is omitted.
  set "NEXA_ADMIN_PASSWORD=!ADMIN_PASSWORD!"
  "%PY%" -m app.cli create-admin --email "!ADMIN_EMAIL!" --name "!ADMIN_NAME!" --role super_admin
  set "NEXA_ADMIN_PASSWORD="
  if errorlevel 1 (
    echo       account already exists - resetting its password instead
    set "NEXA_ADMIN_PASSWORD=!ADMIN_PASSWORD!"
    "%PY%" -m app.cli reset-password --email "!ADMIN_EMAIL!"
    set "NEXA_ADMIN_PASSWORD="
    if errorlevel 1 (
      popd
      echo [error] could not create or update the administrator - see the message above.
      exit /b 1
    )
  )
)
popd

echo.
echo ============================================================
echo  Administrator updated.
echo.
echo    E-mail:  !ADMIN_EMAIL!
echo    Name:    !ADMIN_NAME!
if defined GENERATE (
  echo    Password: printed above by the reset command - save it now ^(it is not stored^).
) else (
  echo    Password: the one you typed. It is also stored in %ROOT%\.env for the
  echo              installers, so keep that file private.
)
echo.
echo  Sign in at: http://127.0.0.1:8000  ^(or your public address when running in public mode^)
echo  Every session of this account was revoked by the password change.
echo ============================================================
popd

echo "%CMDCMDLINE%" | find /i "%~nx0" >nul && pause
endlocal
exit /b 0

:update_env
REM update_env <KEY> <VALUE> - rewrites one key in .env (adds it when missing).
REM A backup is kept once per run so a mistake never destroys the previous file.
set "KEY=%~1"
set "VALUE=%~2"
if not defined ENV_BACKED_UP (
  copy /y "%ROOT%\.env" "%ROOT%\.env.bak" >nul 2>&1
  set "ENV_BACKED_UP=1"
)
findstr /v /b "%KEY%=" "%ROOT%\.env" > "%ROOT%\.env.new" 2>nul
echo %KEY%=%VALUE%>> "%ROOT%\.env.new"
move /y "%ROOT%\.env.new" "%ROOT%\.env" >nul
exit /b 0
