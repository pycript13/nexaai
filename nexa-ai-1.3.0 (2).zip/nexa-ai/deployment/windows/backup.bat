@echo off
REM ============================================================================
REM  Nexa AI - back up the database and the uploads folder into backups\.
REM
REM  SQLite: the database file is copied while the app keeps running (SQLite's
REM  WAL keeps that consistent; stop the app if you want a byte-identical copy).
REM  PostgreSQL: pg_dump must be on PATH (it ships with the PostgreSQL client).
REM
REM  Restore instructions: docs/BACKUP_RESTORE.md  (always restore into a fresh
REM  database and verify before switching a live instance over).
REM ============================================================================
setlocal EnableDelayedExpansion
chcp 65001 >nul
set "ROOT=%~dp0..\.."
pushd "%ROOT%" || exit /b 1

set "DBURL="
set "UPLOADS="
for /f "usebackq tokens=1,* delims==" %%a in (`findstr /b "NEXA_DATABASE_URL" ".env" 2^>nul`) do set "DBURL=%%b"
for /f "usebackq tokens=1,* delims==" %%a in (`findstr /b "NEXA_UPLOAD_DIR" ".env" 2^>nul`) do set "UPLOADS=%%b"
if "!DBURL!"=="" set "DBURL=sqlite:///!ROOT:\=/!/data/nexa.db"
if "!UPLOADS!"=="" set "UPLOADS=!ROOT!\uploads"

REM Locale-independent timestamp (YYYYMMDD-HHMMSS) through PowerShell.
for /f "delims=" %%t in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmmss"') do set "STAMP=%%t"
if not exist "!ROOT!\backups" mkdir "!ROOT!\backups"

echo !DBURL! | findstr /b "sqlite" >nul
if errorlevel 1 (
  echo [info] PostgreSQL database detected - running pg_dump ...
  REM SQLAlchemy URLs look like postgresql+psycopg2://... - pg_dump wants postgresql://...
  set "PGURL=!DBURL:+psycopg2=!"
  set "PGURL=!PGURL:+psycopg=!"
  where pg_dump >nul 2>&1
  if errorlevel 1 (
    echo [error] pg_dump was not found on PATH. Install the PostgreSQL client tools
    echo         or add their bin folder to PATH, then run this script again.
    popd & endlocal & exit /b 1
  )
  pg_dump --format=custom --file="!ROOT!\backups\nexa-pg-!STAMP!.dump" "!PGURL!"
  if errorlevel 1 (echo [error] pg_dump failed - nothing was written & popd & endlocal & exit /b 1)
  echo [ok] backups\nexa-pg-!STAMP!.dump
) else (
  set "DBPATH=!DBURL:sqlite:///=!"
  if not exist "!DBPATH!" (echo [error] database file not found: !DBPATH! & popd & endlocal & exit /b 1)
  copy /y "!DBPATH!" "!ROOT!\backups\nexa-sqlite-!STAMP!.db" >nul
  if errorlevel 1 (echo [error] could not copy the database & popd & endlocal & exit /b 1)
  REM the WAL sidecar files belong to the same snapshot
  if exist "!DBPATH!-wal" copy /y "!DBPATH!-wal" "!ROOT!\backups\nexa-sqlite-!STAMP!.db-wal" >nul
  if exist "!DBPATH!-shm" copy /y "!DBPATH!-shm" "!ROOT!\backups\nexa-sqlite-!STAMP!.db-shm" >nul
  echo [ok] backups\nexa-sqlite-!STAMP!.db
)

echo [info] archiving uploads ...
if exist "!UPLOADS!" (
  powershell -NoProfile -Command "Compress-Archive -Path '!UPLOADS!\*' -DestinationPath '!ROOT!\backups\nexa-uploads-!STAMP!.zip' -Force" 2>nul
  if exist "!ROOT!\backups\nexa-uploads-!STAMP!.zip" (echo [ok] backups\nexa-uploads-!STAMP!.zip) else (echo [warn] uploads folder is empty or could not be archived)
) else (
  echo [warn] uploads folder not found: !UPLOADS!
)

echo.
echo [done] backups written to !ROOT!\backups
echo        Verify a backup before you rely on it: docs/BACKUP_RESTORE.md
popd
endlocal
