@echo off
REM ============================================================================
REM  Nexa AI - start the application
REM
REM  It reads .env and follows the access mode chosen during installation:
REM    * local       - listens on 127.0.0.1 (this PC only)
REM    * public_ip   - listens on 0.0.0.0 on NEXA_PUBLIC_PORT, so other machines can
REM                    open http://<your address>:<port>  (plain HTTP!)
REM
REM  The virtual environment is activated implicitly by using its interpreter, and
REM  the module is started from backend\ so that `app` is importable and .env (one
REM  directory up) is found. A separate worker window is only opened when
REM  NEXA_INLINE_WORKER is not true - otherwise the API process already consumes
REM  the job queue and polls Telegram.
REM ============================================================================
setlocal EnableDelayedExpansion
set "ROOT=%~dp0..\.."
set "PY=%ROOT%\.venv\Scripts\python.exe"
pushd "%ROOT%" || exit /b 1

if not exist "%PY%" (
  echo [error] .venv is missing. Run deployment\windows\install.bat first.
  exit /b 1
)

REM --- has the frontend been built? -------------------------------------------
if not exist "%ROOT%\frontend\dist\index.html" (
  echo [warning] frontend\dist is empty - the API will answer but the interface
  echo           will not load. Build it with:
  echo               cd frontend ^&^& npm install ^&^& npm run build
)

REM --- how was this installation configured to be reached? ---------------------
REM     local  -> 127.0.0.1 only (nobody else can connect)
REM     public -> 0.0.0.0 on the chosen port, so other machines / the Internet can
REM               reach it (the installer wrote NEXA_DEPLOYMENT_MODE=public_ip)
set "ACCESS_MODE=local"
set "BIND=127.0.0.1"
set "PORT=8000"
set "PUBLIC_URL="
for /f "tokens=1,* delims==" %%a in ('findstr /b "NEXA_DEPLOYMENT_MODE" "%ROOT%\.env" 2^>nul') do set "ENV_MODE=%%b"
for /f "tokens=1,* delims==" %%a in ('findstr /b "NEXA_PUBLIC_PORT" "%ROOT%\.env" 2^>nul') do set "ENV_PORT=%%b"
for /f "tokens=1,* delims==" %%a in ('findstr /b "NEXA_PUBLIC_BASE_URL" "%ROOT%\.env" 2^>nul') do set "PUBLIC_URL=%%b"
if /i "!ENV_MODE!"=="public_ip" (
  set "ACCESS_MODE=public"
  set "BIND=0.0.0.0"
)
if defined ENV_PORT if not "!ENV_PORT!"=="" set "PORT=!ENV_PORT!"

REM --- does this .env want an in-process worker? -------------------------------
set "INLINE="
for /f "tokens=1,* delims==" %%a in ('findstr /b "NEXA_INLINE_WORKER" "%ROOT%\.env" 2^>nul') do set "INLINE=%%b"
if "!INLINE!"=="" set "INLINE=true"

echo ============================================================
echo  Nexa AI is starting
echo    access mode: !ACCESS_MODE!  ^(bound to !BIND!:!PORT!^)
echo    interface:   http://127.0.0.1:!PORT!
if /i "!ACCESS_MODE!"=="public" (
  echo    for others:  !PUBLIC_URL!
  echo.
  echo    SECURITY WARNING: this mode serves plain HTTP on a reachable address -
  echo    traffic is not encrypted. Use it for testing, HTTPS before real use.
)
echo    API docs:    http://127.0.0.1:!PORT!/api/docs
echo    inline worker: !INLINE!
echo ============================================================
echo.

if /i "!INLINE!"=="true" (
  echo Starting the API ^(jobs and Telegram polling run inside it^) ...
  start "Nexa AI" /d "%ROOT%\backend" cmd /k ""%PY%" -m uvicorn app.main:app --host !BIND! --port !PORT!"
) else (
  echo Starting the API ...
  start "Nexa AI API" /d "%ROOT%\backend" cmd /k ""%PY%" -m uvicorn app.main:app --host !BIND! --port !PORT!"
  echo Starting the background worker ...
  start "Nexa AI worker" /d "%ROOT%\backend" cmd /k ""%PY%" -m app.workers.worker"
)

timeout /t 4 >nul
start "" "http://127.0.0.1:!PORT!"
popd
endlocal
