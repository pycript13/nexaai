#!/usr/bin/env bash
# Nexa AI — find the address a browser must open when the deployment sits behind the Daytona
# preview proxy (or any TLS reverse proxy in front of a NATed container).
#
# Why this exists
#   Inside a Daytona sandbox the machine's own IP (e.g. 172.20.0.63) is **not** reachable from the
#   outside — inbound traffic only arrives through the preview proxy at
#   https://<port>-<sandbox-id>.<proxy-domain>/ and that proxy authenticates the request unless the
#   sandbox is public. The installer therefore has to answer one question for the operator:
#   "which URL do I send people?", and until now it printed a placeholder and left it to them.
#
#   This file is both a library (sourced by install-daytona.sh, which uses the resolved URL for
#   trusted hosts, CORS, secure cookies and the public base URL) and a command you can run inside
#   the sandbox:
#
#       bash deployment/daytona/preview_link.sh --port 8080
#
#   It prints the candidate preview URLs with the status each one answers, whether the link needs
#   a token, and the exact command to run on your own machine.
#
# Exit codes (CLI mode): 0 = a working link was found, 3 = candidates exist but none is reachable
# from here, 4 = no candidate could be built (no sandbox id).

set -uo pipefail

# ------------------------------------------------------------------ helpers (safe to source) --
nexa_preview_domains() {
  # Overridable so tests (and other proxies) can drive the same logic without Daytona.
  if [[ -n "${NEXA_PREVIEW_DOMAINS+x}" ]]; then
    printf '%s\n' ${NEXA_PREVIEW_DOMAINS}
  else
    printf '%s\n' proxy.daytona.work proxy.daytona.works
  fi
}

nexa_preview_sandbox_id() {
  local candidate
  for candidate in \
      "${DAYTONA_SANDBOX_ID:-}" \
      "${DAYTONA_SANDBOX_NAME:-}" \
      "${DAYTONA_WS_ID:-}" \
      "${DAYTONA_WORKSPACE_ID:-}"; do
    if [[ -n "${candidate}" ]]; then
      printf '%s\n' "${candidate}"
      return 0
    fi
  done
  # On Daytona images the container hostname is the sandbox name.
  hostname 2>/dev/null || printf ''
}

nexa_preview_plausible_id() {  # $1 = id → 0 when it can be a Daytona sandbox id
  case "${1:-}" in
    ""|.*|*.*|localhost) return 1 ;;
    *) return 0 ;;
  esac
}

nexa_preview_candidate_urls() {  # $1 = sandbox id, $2 = port
  local id="${1:-}" port="${2:-8080}" domain
  if [[ -n "${id}" ]]; then
    while read -r domain; do
      [[ -n "${domain}" ]] && printf 'https://%s-%s.%s\n' "${port}" "${id}" "${domain}"
    done < <(nexa_preview_domains)
  fi
  if [[ -n "${NEXA_PREVIEW_EXTRA_URLS:-}" ]]; then
    printf '%s\n' ${NEXA_PREVIEW_EXTRA_URLS}
  fi
}

nexa_preview_probe() {  # $1 = base URL → prints the HTTP status of /readyz (000 = no answer)
  local url="${1%/}"
  curl -sS -o /dev/null -w '%{http_code}' \
    --max-time "${NEXA_PREVIEW_PROBE_TIMEOUT:-8}" \
    "${url}/readyz" 2>/dev/null || printf '000'
}

nexa_preview_classify() {  # $1 = status → public | private | unreachable
  case "${1:-000}" in
    2*)      printf 'public' ;;
    401|403) printf 'private' ;;
    *)       printf 'unreachable' ;;
  esac
}

nexa_preview_resolve() {  # $1 = sandbox id, $2 = port → prints the first URL that really answers
  local url status
  while read -r url; do
    [[ -n "${url}" ]] || continue
    status="$(nexa_preview_probe "${url}")"
    if [[ "${status}" == 2* ]]; then
      printf '%s\n' "${url}"
      return 0
    fi
  done < <(nexa_preview_candidate_urls "${1:-}" "${2:-8080}")
  return 1
}

# ------------------------------------------------------------------------------- CLI mode ------
_nexa_preview_main() {
  local port=8080 id="" status url kind found="" idx=0
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --port) port="${2:-8080}"; shift 2 ;;
      --sandbox-name|--sandbox) id="${2:-}"; shift 2 ;;
      -h|--help)
        cat <<'USAGE'
Usage: bash preview_link.sh [--port N] [--sandbox-name NAME]

Prints the preview address(es) for this deployment, the HTTP status each one answers and
whether it can be opened by other people.
USAGE
        return 0 ;;
      *) printf 'unknown option: %s\n' "$1" >&2; return 2 ;;
    esac
  done
  [[ -n "${id}" ]] || id="$(nexa_preview_sandbox_id)"
  local id_is_usable=1
  nexa_preview_plausible_id "${id}" || id_is_usable=0

  if [[ "${id_is_usable}" -eq 1 ]]; then
    printf 'sandbox id/name : %s\n' "${id}"
  else
    printf 'sandbox id/name : %s (this is the container hostname, not a sandbox id)\n' "${id:-<unknown>}"
    printf '                  → on your own machine run: daytona list\n'
    id=""
  fi
  printf 'port            : %s (the reverse proxy; the API itself listens on 8000 internally)\n\n' "${port}"

  while read -r url; do
    [[ -n "${url}" ]] || continue
    idx=$((idx + 1))
    status="$(nexa_preview_probe "${url}")"
    kind="$(nexa_preview_classify "${status}")"
    case "${kind}" in
      public)      printf '  [%d] %s → HTTP %s  ⇦ works for anyone right now\n' "${idx}" "${url}" "${status}"; found="${url}" ;;
      private)     printf '  [%d] %s → HTTP %s  ⇦ the URL is right, but the sandbox is private:\n' "${idx}" "${url}" "${status}"
                   printf '        open it with a signed link (see below) or make the sandbox public\n' ;;
      unreachable) printf '  [%d] %s → no answer from here (HTTP %s)\n' "${idx}" "${url}" "${status}" ;;
    esac
  done < <(nexa_preview_candidate_urls "${id}" "${port}")

  echo
  if [[ -n "${found}" ]]; then
    printf 'SHARE THIS LINK: %s\n' "${found}"
    return 0
  fi
  cat <<'NEXT'
No link answered from inside the sandbox — that is expected on a private sandbox (and whenever
this container cannot reach the proxy). Do this on YOUR OWN machine, where the Daytona CLI is
signed in:

    daytona list                                                 # find the sandbox name
    daytona preview-url <sandbox-name> --port PORT --expires 86400

That prints a signed HTTPS link that opens in any browser without extra headers, valid for the
chosen expiry. Give that link to whoever should test the platform.

Want a link with no token and no expiry instead? Make the sandbox public — it is a per-sandbox
switch:
    * dashboard: sandbox → settings → Public
    * CLI/SDK  : daytona create --public   (at creation time)
                 python -c "from daytona import Daytona; s=Daytona().get('<name>'); s.set_public(True)"
    * REST     : curl -X POST "$DAYTONA_API_URL/sandbox/<id>/public/true" -H "Authorization: Bearer $DAYTONA_API_KEY"

Security note: a preview token is not limited to one port — anyone holding it can also reach the
sandbox web terminal (22222) and run commands there. Share signed links, and unset the public
flag when you are done testing.
NEXT
  return 3
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  _nexa_preview_main "$@"
fi
