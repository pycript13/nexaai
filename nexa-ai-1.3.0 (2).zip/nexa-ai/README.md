# Nexa AI — Multi-Provider AI Platform

**فارسی** · [English](#english)

پلتفرم واقعی و تجاری هوش مصنوعی: چند ارائه‌دهنده (OpenAI، Anthropic، Google، سرویس‌های سازگار،
استبیلیتی، ElevenLabs، Deepgram، Replicate و …)، فروشگاه مدل با کنترل دسترسی، صورتحساب اعتباری با
دفتر کل تغییرناپذیر، پنل مدیریت کامل، ۴ زبان (فارسی پیش‌فرض + انگلیسی + عربی + کردی سورانی) با
راست‌به‌چپ، و نصب روی لینوکس و ویندوز.

> **هیچ‌چیز ساختگی نیست.** تا وقتی ارائه‌دهنده‌ی واقعی پیکربندی نشود، API با خطای صریح
> `503 not_configured` پاسخ می‌دهد و هیچ پاسخ هوش مصنوعی جعلی تولید نمی‌شود. مدل تازه‌همگام‌شده
> «مخفی و تأییدنشده» است تا مدیر آن را تست، قیمت‌گذاری و آگاهانه منتشر کند.

## نصب سریع

```bash
# ۱) با Docker (پیشنهادی)
git clone <repo-url> nexa-ai && cd nexa-ai
cp deployment/.env.production.example .env     # کلیدها و رمزها را پر کنید
docker compose up -d --build                   # سپس: http://IP:8080

# ۲) اوبونتو/دبیان بدون Docker
sudo bash deployment/linux/install.sh

# ۳) ویندوز
deployment\windows\install.bat
deployment\windows\start.bat

# ۴) فضای کاری ابری (GitHub Codespaces / Gitpod / dev container) — برای تست و اشتراک لینک
bash deployment/codespaces/setup.sh          # نصب، ساخت مدیر، build رابط کاربری
bash deployment/codespaces/start.sh --daemon # یک پورت: ۸۰۸۰ (خودِ API رابط کاربری را سرو می‌کند)
gh codespace ports visibility 8080:public -c "$CODESPACE_NAME"   # تا دیگران هم بتوانند لینک را باز کنند
```

**راهنمای کامل (نصب، استفاده، تست، پشتیبان، عیب‌یابی): [`docs/RAHNAMA.md`](docs/RAHNAMA.md)**
**اجرا در GitHub Codespaces و اشتراک لینک با دیگران: [`docs/CODESPACES.md`](docs/CODESPACES.md)**

## چه چیزی ساخته شده است

| لایه | فناوری | وضعیت |
| --- | --- | --- |
| بک‌اند | Python + FastAPI + Pydantic + SQLAlchemy 2 + Alembic | ۱۲۸ مسیر API، ۲۹ جدول، ۳۰۷ تست موفق |
| فرانت‌اند | React 18 + TypeScript + Vite | ساخت production موفق (SPA ~۳۶۲KB) |
| دیتابیس | PostgreSQL (بهره‌برداری) / SQLite (فقط توسعه) | مهاجرت اولیه + بذر اولیه (۶ نقش، ۳۰ مجوز، ۹ دسته، ۲۰ تنظیم) |
| ارائه‌دهنده‌ها | ۱۶ آداپتور | متن/جریان/تصویر/صدا/ویدئو/embedding/rerank، خطاهای دسته‌بندی‌شده |
| مالی | دفتر کل تغییرناپذیر، میکرواعتبار صحیح، idempotency | پرداخت دستی + رمزارز + آداپتور درگاه، بدون اعتبار خودکار |
| استقرار | Docker Compose، Nginx، systemd، اسکریپت‌های ویندوز | فایل‌های واقعی، آزمون‌پذیر |
| تست | pytest (بک‌اند) + تست زنده‌ی سرتاسری + `doctor` + چک‌های استقرار | ۱۳۷ + ۳۷ مسیر موفق در آخرین اجرا |

## ساختار پروژه

```
backend/    API، مدل‌های داده، سرویس‌ها، آداپتورها، تست‌ها، alembic
frontend/   رابط کاربری React/TS (صفحات کاربر و ۱۵ صفحه‌ی مدیریت)
database/   اسکریپت ساخت PostgreSQL، نمای schema
deployment/ Docker، Nginx، systemd، نصب‌کننده‌های لینوکس و ویندوز
docs/       همه‌ی مستندات (شروع از docs/RAHNAMA.md)
scripts/    پشتیبان/بازیابی/بررسی سلامت/CLI
tests/      تست زنده‌ی سرتاسری، شبیه‌ساز ارائه‌دهنده، آزمون‌های استقرار و UI
```

## اولین گام‌ها پس از نصب

1. با مدیر ساخته‌شده در `NEXA_BOOTSTRAP_ADMIN_EMAIL` وارد شوید و رمز را عوض کنید.
2. در **مدیر → ارائه‌دهنده‌ها** یک ارائه‌دهنده بسازید، **تست اتصال** و **همگام‌سازی مدل** بزنید.
3. مدل را قیمت‌گذاری کنید (**مدل‌ها → ویرایش**): قیمت فروش به «اعتبار»، هزینه‌ی ارائه‌دهنده به «دلار».
4. **تست مدل** را روی یک قابلیت واقعی اجرا کنید (ثبت در audit، با هزینه‌ی پلتفرم).
5. مدل را منتشر کنید (`public` + `published` + `access_tier` مناسب).
6. پرداخت دستی: کاربر درخواست می‌دهد، مدیر **تأیید** می‌کند و اعتبار یک‌بار در دفتر کل ثبت می‌شود.

## تست

```bash
cd backend && python -m pytest tests/ -q                 # ۳۰۷ تست
python -m pytest ../tests/deployment -q                  # آزمون فایل‌های استقرار
python3 tests/tools/mock_openai_upstream.py --port 9099 &   # شبیه‌ساز ارائه‌دهنده
python3 tests/integration/test_live_stack.py             # ۳۷ مسیر سرتاسری
```

---

## English

A real, commercial multi-provider AI platform: OpenAI-compatible, Anthropic, Google, Stability,
ElevenLabs, Deepgram, Replicate and more; a model catalogue with visibility ≠ availability ≠ access;
an immutable credit ledger with idempotent money movements; a full administration panel; four
languages (Persian default with RTL, English, Arabic, Kurdish Sorani); Linux and Windows installers.

**Nothing is faked.** Without a configured provider the API answers `503 not_configured` — never a
generated mock answer. A freshly synced model stays hidden and unverified until an administrator
tests, prices and publishes it deliberately.

### Quick start

```bash
# Docker (recommended)
cp deployment/.env.production.example .env     # fill in secrets
docker compose up -d --build                   # → http://SERVER-IP:8080

# Ubuntu/Debian without Docker
sudo bash deployment/linux/install.sh

# Windows
deployment\windows\install.bat && deployment\windows\start.bat

# Cloud workspace (GitHub Codespaces / Gitpod / dev container) — test it and share the link
bash deployment/codespaces/setup.sh            # install, create the admin, build the SPA
bash deployment/codespaces/start.sh --daemon   # one port: the API serves the built SPA on 8080
gh codespace ports visibility 8080:public -c "$CODESPACE_NAME"   # so others can open the link
```

Full manual — install, provider setup, users, billing, public-IP testing, backups, troubleshooting:
**[`docs/INSTALLATION_GUIDE.md`](docs/INSTALLATION_GUIDE.md)** (English) ·
**[`docs/RAHNAMA.md`](docs/RAHNAMA.md)** (فارسی)

### Verified in this repository

| Check | Result |
| --- | --- |
| Backend test suite | **368 passed / 0 failed / 0 errors** (`cd backend && python -m pytest`), including 22 round-12 contracts, the 28-test round-13 Telegram session suite, the 10 round-14 glass-button contracts, the 6 round-15 nested-menu contracts, the **8 round-16 live-stream bot contracts** and the **4 round-16 dashboard-summary contracts** |

| Repository + deployment suites | **239 passed / 12 skipped** (`python -m pytest tests/unit tests/deployment -q`) — Compose topology, installers, Nginx, CSP, workspace assets (one skip is environment-dependent: `test_python_acquisition` runs only when `uv` is on PATH — without it the count reads 238/13) |
| Frontend production build | **success** (`npm run build`, `tsc` clean; JS 579.32 kB / 170.91 kB gzip, CSS 80.47 kB / 16.19 kB gzip — bundle `index-0b24qJfc.js` + `index-C6UdpzN9.css`) |

| Live end-to-end stack test | **39 / 39 steps passed** against a running API + a real HTTP upstream double, plus model-variant and pricing round-trips |
| Served-app end-to-end smoke | **10 passed** (`python -m pytest tests/e2e -q` against a running instance) |
| Cloud workspace (GitHub Codespaces) | `deployment/codespaces/setup.sh` + `start.sh` executed here: install, migrations, bootstrap, SPA build, `readyz` 200, `--dev`/`--stop` verified |
| A stranger registering through the link | `tests/tools/browser/check-register.cjs` → **PROBLEMS: 0** (phone + desktop, fa + en): all four visitors created an account and were signed in |
| Admin console on a fresh installation | `tests/tools/browser/check-round12.cjs` → **PROBLEMS: 0**: user created from the panel with a role, one-time password signs in, 403s for ordinary users, Telegram card + profile gate |
| Field alignment / responsiveness | `tests/tools/browser/check-alignment.cjs` → **TOTAL FINDINGS: 0** at 390 / 768 / 1440 px on every route (the checker self-tests by injecting a 14 px offset) |
| Full route sweep (34 admin + user pages × phone/desktop) | `tests/tools/browser/check-admin-pages.cjs` → **PROBLEMS: 0**, no console error and no horizontal overflow, 31 permission checkboxes on the roles editor |
| Command palette + registration policy | `tests/tools/browser/check-round12b.cjs` → **PROBLEMS: 0**: Ctrl/⌘ K navigation (permission-aware, four languages), and a policy change verified through `/api/v1/auth/config` |
| Nested navigation + 3D splash (round 13) | `tests/tools/browser/check-nested-nav.cjs` → **PROBLEMS: 0**: collapsible tree with four admin subgroups, auto-expand + three-level breadcrumb, persisted choices, tab-order-safe collapse, 3D first-paint splash, ≥44 px drawer toggles at 390 px |
| Telegram bot redesign (round 13) | `tests/tools/browser/check-telegram-bot.cjs` → **PROBLEMS: 0** against the real Bot API: full session lifecycle (`/new … /close`), every fixed bottom-bar label routed, stranger gate, one-time-code link |
| Header popovers on phones (round 14) | `tests/tools/browser/check-header-popovers.cjs` → **PROBLEMS: 0**: profile and language cards measured inside the viewport at 360/390/768/1440 px in fa/RTL and en/LTR, no sideways page scroll; JS-clamped placement + glass sheet on phones |
| Glass-button Telegram bot (round 14) | `cd backend && python -m pytest tests/test_telegram_round14.py -q` → **10 passed**: model buttons carry ids and switch with an in-place edit (page remembered), sessions switch by button, rename waits for one message, close confirms, sections delete their predecessor, bodies are monolingual |
| Chat workspace redesign (round 15) | `preview-tools/check-chat-ui.cjs` → **PROBLEMS: 0** (5×): fixed-height glass shell that compensates for the deployment banner instead of hiding it, conversation rail with search/pin/rename/delete + previews, one-line model+variant composer row, per-message tools unlocked by the post-send reload, Markdown code-fence copy, 390 px drawer open/backdrop/close, delete-with-confirm, zero page errors |
| Nested-menu Telegram bot (round 15) | `cd backend && python -m pytest tests/test_telegram_round15.py -q` → **6 passed** (two-button bar in both languages, tracked inline hub, sections edit/delete in place, account sub-views keep their parent, chat mode clears the desk, stale round-13/14 keyboards still route) + live `check-telegram-bot.cjs` → **PROBLEMS: 0** |
| Responsive/touch audit, authenticated (round 15) | `mobile-audit.cjs` → **0 measured problems / 0 harness failures** across iphone-se, iphone-14, pixel-7, ipad-mini, laptop after the chat fixes (parked drawer `visibility:hidden`, 32 px convo buttons, 40 px chips/links, 44 px hero chips, 11.5 px hint) |
| Checker fleet on the shipping build (round 15) | `run-fleet.sh` → **20/20 tools green** (incl. alignment TOTAL FINDINGS: 0 with a non-blind self-test, chat-reasoning `problems: []`, user-flow/verify `problems: []`, theme-check coherent, features-check all-true) |
| Live-stream Telegram bot (round 16) | `cd backend && python -m pytest tests/test_telegram_round16.py -q` → **8 passed** (telegram suite **64 passed**): the answer grows inside ONE message with a ▍ cursor (placeholder at 24 chars, edits throttled to ≤ 1 per 1.5 s / 120 chars — inside Telegram's edit budget), 8000-char answers overflow into extra under-limit messages with the tail surviving, every failure deletes the half message and falls back to one-shot delivery, «پخش زنده» is a persisted per-user setting, refusals/errors carry a 🔁 retry that really replays the prompt, and the 👤 card reports today's spend with a ▰▱ daily-limit bar |
| Router-platform dashboard (round 16) | `cd backend && python -m pytest tests/test_dashboard_summary.py -q` → **4 passed** (user-scoped KPIs, dense 30-day series with honest zeros, top-5 models, latest traces; another user's traffic and admin-test rows are provably invisible; 422 outside 7–90 days) + live `check-round16.cjs` → **PROBLEMS: 0**: 5 KPI cards, hand-rolled SVG chart with 30 hover columns + 30 native tooltips, top-model bars, traces table, one-column phone collapse |
| Model cards + chat day separators (round 16) | live `check-round16.cjs` → provider initial tiles, emphasised per-1M price blocks, vision/tools/stream badges, a sort control that really orders the page ascending by input price, and localised day separators («امروز» measured live after a real round trip); every new string exists in en/fa/ar/ckb |
| Checker fleet on the shipping build (round 16) | `run-fleet.sh` → **21/21 tools green** (new: `check-round16.cjs` PROBLEMS: 0; all round-12…15 tools still green; `mobile-audit.cjs` **0 measured problems** across iphone-se / iphone-14 / pixel-7 / ipad-mini / laptop after the chart-label fix) |
| Live Bot API delivery probe (round 16) | `live-stream-check.cjs` against the **real** api.telegram.org: the injected turn was handled (1.9 s) and the bot's outgoing calls reached Telegram and were answered by Telegram itself — for the owner's *declared* chat id Telegram refused first contact with a genuine `Bad Request: chat not found` (a bot may never message a user who has not pressed Start), which is exactly the honest failure the delivery layer logs and falls back from; the preview now runs in **polling mode** so the owner's first `/start` is received and live-streamed |
| Provider sync + variant pipeline (round 13, re-proven self-contained) | `check-sync-ux.cjs` and `variant-stream-check.cjs` → **PROBLEMS: 0**: sync card counts → drafts list → cleanup; the variant's system prompt verified in the mock upstream's own request log |
| Installed production stack (PostgreSQL + Nginx + systemd) | live stack **37 / 37** and served-app smoke **10 passed** against `http://127.0.0.1:8080` |
| Backend suite on PostgreSQL | **137 passed** (same suite, PostgreSQL 17 dialect; the four newest test files are dialect-independent) |
| Browser sweep of the whole UI | **24 screenshots, no console errors** (`tests/tools/ui_smoke/verify-ui.cjs`; sign-in, user + admin screens, light/dark/glass, 390 px drawer) |
| Responsive layout measured | no horizontal page scroll at 390 / 430 / 820 / 1024 / 1280 / 1440 px |

### Documentation set

| Document | Contents |
| --- | --- |
| [`docs/RAHNAMA.md`](docs/RAHNAMA.md) / [`docs/INSTALLATION_GUIDE.md`](docs/INSTALLATION_GUIDE.md) | the complete install → operate → test manual (fa / en) |
| [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) | components, request flow, data model, design decisions |
| [`docs/INSTALL_UBUNTU.md`](docs/INSTALL_UBUNTU.md) / [`docs/INSTALL_WINDOWS.md`](docs/INSTALL_WINDOWS.md) | platform-specific install notes |
| [`docs/PROVIDER_CONFIGURATION.md`](docs/PROVIDER_CONFIGURATION.md) | every adapter, credentials, base URLs, timeouts |
| [`docs/TELEGRAM.md`](docs/TELEGRAM.md) | the optional Telegram bot: BotFather token, polling vs webhook, linking, billing, the fixed bottom bar and per-model sessions |
| [`docs/MODEL_MANAGEMENT.md`](docs/MODEL_MANAGEMENT.md) | sync, pricing, visibility/availability/tier, testing, grants |
| [`docs/BILLING.md`](docs/BILLING.md) | credits, ledger, payments, refunds, subscriptions, quotas |
| [`docs/SECURITY.md`](docs/SECURITY.md) | threat model and implemented controls |
| [`docs/BACKUP_RESTORE.md`](docs/BACKUP_RESTORE.md) | backup, verification and restore drills |
| [`docs/PRODUCTION_DEPLOYMENT.md`](docs/PRODUCTION_DEPLOYMENT.md) | public IP and domain/HTTPS deployment |
| [`docs/REMOTE_TESTING.md`](docs/REMOTE_TESTING.md) | sharing a public-IP instance with testers safely |
| [`docs/TROUBLESHOOTING.md`](docs/TROUBLESHOOTING.md) | symptom → cause → fix |
| [`docs/KNOWN_LIMITATIONS.md`](docs/KNOWN_LIMITATIONS.md) | honest list of what is not implemented/verified |
| [`docs/TEST_REPORT.md`](docs/TEST_REPORT.md) | what was executed, what was not, and why |

### Licence and third-party services

The application code ships with no AI provider credentials. You must configure your own provider keys
(`Admin → AI Infrastructure → Providers`) and comply with each provider's terms of service. Every
outbound call is made from your server with your credentials; the platform never proxies through a
third party of ours.
