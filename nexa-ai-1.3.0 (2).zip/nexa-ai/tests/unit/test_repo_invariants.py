"""Repository-level invariants that must hold regardless of runtime configuration.

These are static checks: they read the source tree and fail loudly if a rule the project
promises (money as integers, no committed secrets, one locale key set, guarded admin
routes, no raw-HTML injection) is ever broken by a later change.
"""
from __future__ import annotations

import ast
import json
import py_compile
import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / "backend"
FRONTEND = ROOT / "frontend" / "src"


def _python_files() -> list[Path]:
    return [
        path
        for base in (BACKEND / "app", BACKEND / "alembic", BACKEND / "tests", ROOT / "tests", ROOT / "scripts")
        for path in base.rglob("*.py")
        if "__pycache__" not in path.parts
    ]


def test_every_python_file_compiles() -> None:
    failures: list[str] = []
    for path in _python_files():
        try:
            py_compile.compile(str(path), doraise=True, cfile="/tmp/nexa_pyc_guard.pyc")
        except py_compile.PyCompileError as exc:  # pragma: no cover - failure path
            failures.append(f"{path.relative_to(ROOT)}: {exc.msg}")
    assert not failures, "files that do not compile:\n" + "\n".join(failures)


def test_money_columns_are_integer_types() -> None:
    """Every ``*_micro`` column must be BigInteger (never Float/Numeric)."""
    offenders: list[str] = []
    for path in (BACKEND / "app" / "models").glob("*.py"):
        source = path.read_text()
        for match in re.finditer(r"^\s*([a-z_]+_micro)\s*=\s*(?:mapped_column\()?([A-Za-z_][\w\.]*)", source, re.M):
            column, column_type = match.group(1), match.group(2)
            if "BigInteger" not in column_type:
                offenders.append(f"{path.name}:{column} -> {column_type}")
    assert not offenders, "money columns must be BigInteger:\n" + "\n".join(offenders)


def test_no_float_arithmetic_in_money_services() -> None:
    """The ledger/pricing/usage services must not introduce binary floats into amounts."""
    banned = re.compile(r"\bfloat\(\s*(?:amount|charge|price|balance)")
    offenders: list[str] = []
    for name in ("ledger.py", "pricing.py", "usage.py", "payments.py"):
        source = (BACKEND / "app" / "services" / name).read_text()
        if banned.search(source):
            offenders.append(name)
    assert not offenders, f"float() used on money values in: {offenders}"


def test_no_committed_secrets_in_templates_or_repo() -> None:
    """Placeholders only: no realistic provider/stripe/google keys anywhere in the tree."""
    patterns = [
        re.compile(r"sk-[A-Za-z0-9]{20,}"),          # OpenAI-style
        re.compile(r"sk-ant-[A-Za-z0-9-]{20,}"),      # Anthropic
        re.compile(r"AIza[0-9A-Za-z_\-]{30,}"),       # Google
        re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    ]
    allowed_names = {"mock_openai_upstream.py", "test_live_stack.py", "conftest.py", "test_repo_invariants.py"}
    offenders: list[str] = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.name in allowed_names:
            continue
        if any(
            part in {".git", "node_modules", "dist", "__pycache__", "uploads", "backups", ".venv", "venv", "site-packages"}
            for part in path.parts
        ):
            continue
        if path.suffix not in {".py", ".ts", ".tsx", ".md", ".json", ".yml", ".yaml", ".sh", ".bat", ".conf", ".ini", ".env", ".example", ".sql", ".txt"}:
            continue
        try:
            text = path.read_text(errors="ignore")
        except OSError:  # pragma: no cover
            continue
        for pattern in patterns:
            if pattern.search(text):
                offenders.append(f"{path.relative_to(ROOT)} matched {pattern.pattern}")
    assert not offenders, "possible committed secrets:\n" + "\n".join(offenders)


def _is_installed_tree() -> bool:
    """True when this is a copy produced by the installer, not the source checkout."""
    return (ROOT / ".install-info").exists()


def test_real_env_file_is_not_part_of_the_project() -> None:
    """`.env.example` may exist; a filled-in `.env` must never be shipped."""
    if _is_installed_tree():
        pytest.skip("installed tree (/opt/nexa-ai): a real .env is expected here, not in the archive")
    gitignore = (ROOT / ".gitignore").read_text()
    assert ".env" in gitignore
    env = ROOT / ".env"
    if env.exists():
        for line in env.read_text().splitlines():
            if line.startswith("NEXA_SECRET_KEY="):
                value = line.split("=", 1)[1].strip()
                assert "CHANGE_ME" in value.upper() or value == "" or len(value) < 40, (
                    "the workspace .env contains a real secret — it must not be included in the archive"
                )


def _locale_keys() -> dict[str, set[str]]:
    result: dict[str, set[str]] = {}
    for code in ("en", "fa", "ar", "ckb"):
        path = FRONTEND / "locales" / f"{code}.ts"
        text = path.read_text()
        result[code] = set(re.findall(r'^\s*"([^"]+)":', text, re.M))
    return result


def test_all_locale_dictionaries_share_the_same_keys() -> None:
    keys = _locale_keys()
    reference = keys["en"]
    assert len(reference) > 100, "the English dictionary looks truncated"
    for code, values in keys.items():
        missing = reference - values
        extra = values - reference
        assert not missing, f"{code} is missing keys: {sorted(missing)[:10]}"
        assert not extra, f"{code} has keys the English dictionary lacks: {sorted(extra)[:10]}"


def test_deployment_banner_title_matches_the_message_it_prints() -> None:
    """The banner used to pick its heading from the *mode*, not from the text it renders.

    The live preview runs with `NEXA_DEPLOYMENT_MODE=public_ip` behind an HTTPS proxy, so the API
    correctly returns no security warning — but the SPA still treated "not literally https" as
    insecure and printed the testing notice under the heading "insecure deployment", which is the
    wrong explanation. The heading must follow the presence of the warning text.
    """
    source = (FRONTEND / "components" / "layout.tsx").read_text()
    banner = source[source.index("export function DeploymentBanner"):]
    banner = banner[: banner.index("\n}")]
    assert 't("warning.deploymentTitle")' in banner and 't("warning.testingNotice")' in banner
    assert "securityWarning ?" in banner, "the banner heading must be chosen by the warning text"
    assert "deployment_mode !==" not in banner, "the banner heading must not be chosen by the mode"
    assert "[securityWarning, testingNotice].filter(Boolean).join" in banner, (
        "a deployment that has both a warning and a testing notice must show both"
    )


def test_frontend_never_injects_raw_html() -> None:
    """Model output is rendered through the markdown component, never as raw HTML."""
    pattern = re.compile(r"dangerouslySetInnerHTML\s*[=:]")
    offenders = [
        str(path.relative_to(ROOT))
        for path in FRONTEND.rglob("*.tsx")
        if pattern.search(path.read_text())
    ]
    assert not offenders, "raw HTML injection found in: " + ", ".join(offenders)


def test_admin_routes_are_permission_guarded() -> None:
    """Every admin route must be wrapped in a permission guard, and the API must agree.

    The frontend mirrors the permission slugs the backend enforces; hiding a menu entry is
    never the control (the API returns 403 regardless), but a missing guard would still be a
    real UI defect.
    """
    source = (FRONTEND / "App.tsx").read_text()
    admin_routes = re.findall(r'path="(admin[^"]*)"', source)
    assert len(admin_routes) >= 15, f"only {len(admin_routes)} admin routes found in App.tsx"
    guards = source.count("<RequirePermission")
    assert guards >= len(admin_routes), (
        f"{len(admin_routes)} admin routes but only {guards} permission guards"
    )

    # every permission slug used by the frontend must exist in the backend catalogue
    enums = (BACKEND / "app" / "models" / "enums.py").read_text()
    backend_permissions = set(re.findall(r'"([a-z_]+\.[a-z_.]+)"', enums))
    used = set(re.findall(r'hasPermission\(\s*"([^"]+)"', source))
    for path in FRONTEND.rglob("*.tsx"):
        used |= set(re.findall(r'hasPermission\(\s*"([^"]+)"', path.read_text()))
    unknown = {permission for permission in used if permission not in backend_permissions}
    assert not unknown, f"frontend uses permissions the backend does not define: {sorted(unknown)}"


def test_frontend_api_client_only_uses_relative_urls() -> None:
    """The bundle must never hardcode localhost/127.0.0.1 — it has to work behind any proxy."""
    offenders: list[str] = []
    for path in FRONTEND.rglob("*.ts*"):
        text = path.read_text()
        for pattern in ("http://localhost", "http://127.0.0.1", "https://localhost"):
            if pattern in text:
                offenders.append(f"{path.relative_to(ROOT)} contains {pattern}")
    assert not offenders, "\n".join(offenders)


def test_backend_has_no_module_level_database_engine() -> None:
    """Engines are created per process through get_engine(); no import-time connections."""
    source = (BACKEND / "app" / "db" / "session.py").read_text()
    tree = ast.parse(source)
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                assert not (isinstance(target, ast.Name) and target.id == "engine"), (
                    "app.db.session must not expose a module-level engine"
                )


def test_error_taxonomy_codes_are_documented() -> None:
    """The API error codes used in code must appear in the user-facing error documentation."""
    source = (BACKEND / "app" / "core" / "errors.py").read_text()
    codes = set(re.findall(r'code\s*=\s*"([a-z_]+)"', source))
    documented = ""
    for name in ("RAHNAMA.md", "INSTALLATION_GUIDE.md", "TROUBLESHOOTING.md"):
        path = ROOT / "docs" / name
        if path.exists():
            documented += path.read_text()
    if not documented:  # pragma: no cover - docs are part of the deliverable
        pytest.skip("no error documentation found")
    text = documented.lower()
    interesting = {code for code in codes if code in {"insufficient_balance", "not_configured", "payload_too_large", "rate_limited", "validation_error"}}
    missing = {code for code in interesting if code.replace("_", " ") not in text and code not in text}
    assert not missing, f"undocumented error codes: {sorted(missing)}"


def test_compose_project_never_publishes_stateful_services() -> None:
    """Belt-and-braces duplicate of the deployment test, kept in the unit layer for fast feedback."""
    import yaml

    data = yaml.safe_load((ROOT / "docker-compose.yml").read_text())
    for name in ("db", "redis"):
        assert not data["services"][name].get("ports"), f"{name} must not publish ports"
