"""End-to-end checks against a *running* deployment: the SPA, its assets and the public API surface.

Requires a reachable server (default `http://127.0.0.1:8000`, override with `NEXA_TEST_BASE_URL`).
When nothing answers, the module skips with instructions instead of failing, so the suite stays
runnable on a machine that has no deployment up.
"""
from __future__ import annotations

import os
import re

import httpx
import pytest

BASE_URL = os.environ.get("NEXA_TEST_BASE_URL", "http://127.0.0.1:8000").rstrip("/")


def _client() -> httpx.Client:
    return httpx.Client(base_url=BASE_URL, timeout=15.0, follow_redirects=False)


@pytest.fixture(scope="module")
def client() -> httpx.Client:
    with _client() as probe:
        try:
            response = probe.get("/healthz")
        except httpx.HTTPError as exc:  # pragma: no cover - depends on the environment
            pytest.skip(f"no Nexa AI server at {BASE_URL} ({exc}). Start one, then re-run.")
        if response.status_code != 200:
            pytest.skip(f"{BASE_URL}/healthz returned {response.status_code}; start a healthy server.")
    with _client() as http:
        yield http


def test_spa_index_is_served_with_mount_point(client: httpx.Client) -> None:
    response = client.get("/")
    assert response.status_code == 200, response.text[:200]
    body = response.text
    assert 'id="root"' in body or "id='root'" in body, "the SPA mount point is missing"
    assert re.search(r'src="/assets/[^"]+\.js"', body), "no built JavaScript bundle is referenced"
    assert "<title>" in body


def test_built_assets_are_downloadable_and_non_empty(client: httpx.Client) -> None:
    index = client.get("/").text
    assets = re.findall(r'(?:src|href)="(/assets/[^"]+)"', index)
    assert assets, "the index references no assets"
    for asset in assets:
        response = client.get(asset)
        assert response.status_code == 200, f"{asset} -> {response.status_code}"
        assert len(response.content) > 100, f"{asset} looks empty"


def test_client_side_routes_return_the_spa(client: httpx.Client) -> None:
    for route in ("/login", "/app", "/app/chat", "/app/admin/models"):
        response = client.get(route)
        assert response.status_code == 200, f"{route} -> {response.status_code}"
        assert 'id="root"' in response.text, f"{route} did not return the SPA shell"


def test_security_headers_are_present(client: httpx.Client) -> None:
    response = client.get("/")
    headers = {key.lower(): value for key, value in response.headers.items()}
    assert headers.get("x-content-type-options") == "nosniff"
    assert "referrer-policy" in headers
    assert "x-frame-options" in headers or "content-security-policy" in headers


def test_health_and_readiness_endpoints(client: httpx.Client) -> None:
    assert client.get("/healthz").json()["status"] == "ok"
    ready = client.get("/readyz")
    assert ready.status_code == 200 and ready.json()["database"] == "ok"
    deep = client.get("/api/v1/health/deep")
    assert deep.status_code == 200
    payload = deep.json()
    assert payload["components"]["database"]["ok"] is True


def test_meta_config_exposes_languages_modules_and_the_deployment_warning(client: httpx.Client) -> None:
    payload = client.get("/api/v1/meta/config").json()
    codes = {item["code"] for item in payload["languages"]}
    assert {"fa", "en", "ar", "ckb"} <= codes, f"missing languages: {codes}"
    directions = {item["code"]: item["dir"] for item in payload["languages"]}
    assert directions["en"] == "ltr" and directions["fa"] == "rtl" and directions["ckb"] == "rtl"
    assert payload["default_language"] == "fa"

    # the deployment mode must be reported as data, not only documented
    assert payload["deployment_mode"] in {"local", "public_ip", "domain_https"}
    if payload["deployment_mode"] in {"public_ip", "local"}:
        assert payload.get("security_warning") or payload.get("testing_notice")

    assert isinstance(payload.get("modules"), (list, dict)) and payload["modules"]
    assert payload.get("credit_display_name")
    assert payload.get("max_upload_mb", 0) > 0


def test_api_documentation_is_reachable(client: httpx.Client) -> None:
    docs = client.get("/api/docs")
    assert docs.status_code == 200, "/api/docs (Swagger UI) is not served"
    spec = client.get("/api/openapi.json")
    assert spec.status_code == 200, "/api/openapi.json is not served"
    paths = spec.json()["paths"]
    assert len(paths) > 50, f"the OpenAPI document looks incomplete ({len(paths)} paths)"
    for required in ("/api/v1/auth/login", "/api/v1/models", "/api/v1/chat/completions", "/api/v1/admin/models"):
        assert any(path.startswith(required) for path in paths), f"{required} is missing from the API"


def test_unauthenticated_catalogue_is_not_leaking_private_models(client: httpx.Client) -> None:
    response = client.get("/api/v1/models")
    assert response.status_code in (200, 401)
    if response.status_code == 200:
        items = response.json().get("items", [])
        assert all(item.get("published") and item.get("visibility") == "public" for item in items), (
            "an anonymous visitor can see unpublished or hidden models"
        )


def test_admin_surface_requires_authentication(client: httpx.Client) -> None:
    for route in ("/api/v1/admin/dashboard", "/api/v1/admin/users", "/api/v1/admin/models"):
        response = client.get(route)
        assert response.status_code in (401, 403), f"{route} answered {response.status_code} without a session"


def test_error_response_shape_is_consistent(client: httpx.Client) -> None:
    response = client.get("/api/v1/models/999999999")
    assert response.status_code in (401, 403, 404)
    if response.status_code == 404:
        payload = response.json()
        assert payload["error"]["code"] == "not_found"
        assert "request_id" in payload["error"] or "request_id" in payload
