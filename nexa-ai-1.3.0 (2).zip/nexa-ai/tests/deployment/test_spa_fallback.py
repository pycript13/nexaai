"""A missing SPA bundle must never look like an Nginx crash.

Found by installing the delivered archive on a clean Debian 13 machine and re-running the
installer with `--no-node` while `frontend/dist` did not exist yet (exactly what an operator
hits after cleaning the build, restoring a disk, or re-running the installer on a host without
Node): Nginx logged

    rewrite or internal redirection cycle while internally redirecting to "/index.html"

and answered a bare **500 Internal Server Error** for *every* page — while the API was healthy
and `/readyz` answered 200. Nothing told the operator what was missing or what to do.

Two rules keep that from happening again:
  * the templates fall back to a named location that returns 503 with the build command when
    `index.html` is absent (no second redirect, so no loop);
  * the installer refuses to finish a deployment whose bundle is missing.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
NGINX = ROOT / "deployment" / "nginx"
SPA_TEMPLATES = ["nexa.conf", "nexa-host.conf", "nexa-domain-http.conf", "nexa-domain-https.conf"]
INSTALLER = ROOT / "deployment" / "linux" / "install.sh"


@pytest.mark.parametrize("name", SPA_TEMPLATES)
def test_spa_templates_never_loop_on_a_missing_index(name: str) -> None:
    text = (NGINX / name).read_text(encoding="utf-8")
    assert "try_files $uri $uri/ /index.html;" not in text, "this redirects into itself and answers 500"
    assert "location / {\n        try_files $uri $uri/ @spa;" in text
    assert "location @spa {" in text and "try_files /index.html @spa_missing;" in text
    assert "location @spa_missing {" in text
    assert "return 503" in text


@pytest.mark.parametrize("name", SPA_TEMPLATES)
def test_the_503_body_tells_the_operator_what_to_do(name: str) -> None:
    text = (NGINX / name).read_text(encoding="utf-8")
    body = text[text.index("@spa_missing") :]
    body = body[: body.index("}", body.index("return 503"))]
    assert "__APP_DIR__/frontend" in body, "the message must name the real directory (the installer substitutes it)"
    assert "npm install" in body and "npm run build" in body
    assert "--no-node" in body, "name the installer flag that skipped the build"
    assert "/readyz" in body, "state that the API is still up, so the operator does not panic"
    # the placeholder must be substituted at install time, not printed literally
    assert "__APP_DIR__" in text and "FRONTEND_DIR" not in text


def test_example_https_template_does_not_loop_either() -> None:
    text = (NGINX / "nexa-https.conf.example").read_text(encoding="utf-8")
    assert "try_files $uri $uri/ /index.html;" not in text
    assert "location @spa { try_files /index.html =503; }" in text


def test_installer_refuses_to_finish_without_the_bundle() -> None:
    text = INSTALLER.read_text(encoding="utf-8")
    assert "the front-end bundle is missing" in text
    guard = text.index("the front-end bundle is missing")
    assert "die " in text[max(0, guard - 400) : guard], "the guard must abort, not warn"
    # and it must run before the configuration is declared good
    assert guard < text.index('log "checking the configuration (pre-flight)"')
    # the fix it prints has to be actionable
    snippet = text[guard : guard + 600]
    assert "npm install && npm run build" in snippet
    assert "without --no-node" in snippet
    assert "untouched" in snippet, "say that the data is safe, so the operator does not fear a re-run"
