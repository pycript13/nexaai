"""A cloud development workspace must be a first-class, working deployment target.

The operator now runs the project inside a **GitHub Codespaces** workspace and shares the forwarded
link with other people.  Two things broke there and must never break again:

* the forwarded host name changes on every rebuild, so a fixed ``NEXA_TRUSTED_HOSTS`` list answers
  ``400 host_not_allowed`` to *every* request — including sign-up, which made the shared link useless;
* a port in Codespaces is private by default, so somebody else opening the link sees nothing until
  the operator flips it to public.

These are static checks over the shipped workspace assets; the live end-to-end run is recorded in
``docs/TEST_REPORT.md`` and ``docs/CODESPACES.md``.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CODESPACES = ROOT / "deployment" / "codespaces"
SETUP = CODESPACES / "setup.sh"
START = CODESPACES / "start.sh"
DEVCONTAINER = ROOT / ".devcontainer" / "devcontainer.json"
DOC = ROOT / "docs" / "CODESPACES.md"
ENV_EXAMPLE = ROOT / ".env.example"
INSTALL = ROOT / "deployment" / "linux" / "install.sh"


def text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


# --------------------------------------------------------------------- the workspace is complete ---

def test_workspace_scripts_exist_are_executable_and_parse() -> None:
    for script in (SETUP, START):
        assert script.is_file(), f"{script.relative_to(ROOT)} is missing"
        assert os.access(script, os.X_OK), f"{script.relative_to(ROOT)} must ship with the executable bit"
        result = subprocess.run(["bash", "-n", str(script)], capture_output=True, text=True)
        assert result.returncode == 0, f"{script.name} does not parse: {result.stderr}"


def test_workspace_setup_is_idempotent_and_creates_a_working_configuration() -> None:
    body = text(SETUP)
    # Re-running must be safe: the operator will run it again after every rebuild.
    assert "keeping the existing" in body
    assert "reusing ${ROOT}/.venv" in body or "reusing" in body
    # It must produce the values that make sign-up work from a forwarded URL.
    for expected in (
        "NEXA_ALLOW_DEV_HOSTS=true",
        "NEXA_REGISTRATION_MODE=open",
        "NEXA_ALLOWED_REGISTRATION_MODES=open,invite_only,closed",
        "run_bootstrap",
        "alembic upgrade head",
        "npm run build",
    ):
        assert expected in body, f"setup.sh never mentions {expected}"
    # Python 3.14 is unsupported: the script must find a supported interpreter by itself.
    assert "3.11" in body and "3.13" in body
    assert "uv python install" in body, "no self-service interpreter path for a 3.14-only machine"


def test_workspace_start_binds_publicly_and_explains_the_shared_link() -> None:
    body = text(START)
    assert "--host 0.0.0.0" in body, "a forwarded port never sees a loopback-only bind"
    assert "--dev" in body and "--stop" in body and "--daemon" in body
    # The exact command that turns the private forwarded port into a link other people can open.
    assert "gh codespace ports visibility" in body
    assert "app.github.dev" in body
    # A workspace URL changes on every rebuild: strict host checking is a self-inflicted 400.
    assert "NEXA_ALLOW_DEV_HOSTS" in body


def test_devcontainer_opens_the_app_and_runs_setup() -> None:
    config = json.loads(text(DEVCONTAINER))
    assert "8080" in [str(p) for p in config["forwardPorts"]], "the app port is not forwarded"
    assert config["portsAttributes"]["8080"]["visibility"] == "public", (
        "a private port cannot be opened by the person the link is shared with"
    )
    assert config["postCreateCommand"].endswith("deployment/codespaces/setup.sh")
    assert config["containerEnv"]["NEXA_ALLOW_DEV_HOSTS"] == "true"
    assert config["containerEnv"]["NEXA_ENVIRONMENT"] == "development"


def test_workspace_documentation_covers_both_languages_and_the_real_pitfalls() -> None:
    body = text(DOC)
    for needle in (
        "deployment/codespaces/setup.sh",
        "deployment/codespaces/start.sh",
        "gh codespace ports visibility",
        "host_not_allowed",
        "registration.mode",
        "docs/RAHNAMA.md",  # the Persian-first guide stays the reference
    ):
        assert needle in body, f"docs/CODESPACES.md does not mention {needle}"
    assert re.search(r"[\u0600-\u06FF]", body), "the Persian half of the document is missing"


# ------------------------------------------------- the host guard must name the switch to flip ---

def test_refusal_explains_the_workspace_switch() -> None:
    body = text(ROOT / "backend" / "app" / "core" / "host_guard.py")
    assert "NEXA_ALLOW_DEV_HOSTS" in body
    assert "development_workspace" in body, "the refusal never says it is a workspace URL"
    assert ".app.github.dev" in body


# ------------------------------------------- the installer and the templates own the new keys ---

def test_installer_writes_and_documents_the_new_keys() -> None:
    body = text(INSTALL)
    for key in ("NEXA_ALLOW_DEV_HOSTS", "NEXA_REGISTRATION_MODE", "NEXA_ALLOWED_REGISTRATION_MODES"):
        assert key in body, f"the installer never writes {key}"
    assert "--allow-dev-hosts" in body and "--no-dev-hosts" in body
    assert "--registration-mode" in body
    # A detected cloud workspace must not be left with a strict allow-list.
    assert "CODESPACES" in body and "GITPOD_WORKSPACE_ID" in body


def test_env_templates_carry_real_lines_not_only_comments() -> None:
    body = text(ENV_EXAMPLE)
    for key in ("NEXA_ALLOW_DEV_HOSTS=", "NEXA_REGISTRATION_MODE=", "NEXA_ALLOWED_REGISTRATION_MODES="):
        assert key in body, f"{key} is missing from .env.example (a comment is not a value)"
        # No commented-out variant may be the only mention of the key.
        assert re.search(rf"^{re.escape(key)}", body, re.M), f"{key} must be an active line"

def test_start_script_reports_the_truth_about_what_it_started() -> None:
    """A wrapper that lies about success is worse than no wrapper.

    Iterating on this script in a real sandbox found three defects worth locking down: the pidfile
    used to hold a subshell (so ``--stop`` left the server running), an occupied port used to be
    reported as "started", and a dev server that had not bound yet counted as ready.
    """
    body = text(START)
    assert "exec \"${VENV_PY}\"" in body, "the pidfile must hold the server process, not a wrapper"
    assert "exec \"${ROOT}/frontend/node_modules/.bin/vite\"" in body, "npm would hide the real Vite pid"
    assert "is already in use by another program" in body, "an occupied port must never be reported as started"
    assert "NEXA_DEV_API_PORT" in body and "NEXA_PORT=8090" in body, "the refusal must name the variable to change"
    assert "the API process exited before it could answer" in body, "a dead server must be diagnosed, not waited on"
    assert "</dev/null" in body, "a detached server must not hold the caller's terminal"


def test_setup_script_survives_a_leftover_environment_file() -> None:
    """The workspace config must win over a stray .env one directory up (a real failure seen live)."""
    body = text(SETUP)
    assert "set -a" in body and '. "${ENV_FILE}"' in body, "backend/.env must be exported, not just written"
    assert "the values exported from backend/.env win" in body, "the shadowing case must be explained"
    assert 'NEXA_BOOTSTRAP_ADMIN_NAME="Platform Owner"' in body, "values with spaces must be quoted to survive sourcing"
