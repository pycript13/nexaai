#!/usr/bin/env python3
"""The installer must read the bootstrap report correctly — a silent parse failure ships a broken admin.

Real sequence behind these tests (found on a live Daytona sandbox): `app.cli bootstrap` logs to
stdout *and* prints its JSON report, and the log line contains a Python dict literal. The
"first `{` … last `}`" slice therefore fed `json.loads` a Python repr, the parse failed silently,
`ADMIN_CREATED` became "unknown", and the installer carried on — leaving a deployment whose
administrator (`admin@nexa.test`, a reserved domain the sign-in endpoint refuses with HTTP 422)
could never log in. `deployment/linux/bootstrap_report.py` replaces that slice and is covered here.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
PARSER = ROOT / "deployment" / "linux" / "bootstrap_report.py"
INSTALLER = ROOT / "deployment" / "linux" / "install.sh"

LOG_LINE = (
    "2026-10-14 13:43:19 INFO     [-] app.services.bootstrap: bootstrap complete: "
    "{'permissions_created': 0, 'roles_created': 0, 'super_admin': {'created': True}}\n"
)


def _run(field: str, raw: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(PARSER), field], input=raw, capture_output=True, text=True, timeout=30
    )


def test_it_finds_the_report_when_the_log_line_comes_first() -> None:
    report = {"super_admin": {"created": False, "reason": "bootstrap e-mail rejected: reserved domain"}}
    raw = LOG_LINE + json.dumps(report, indent=2) + "\n"
    assert _run("created", raw).stdout.strip() == "no"
    assert _run("reason", raw).stdout.strip() == "bootstrap e-mail rejected: reserved domain"


def test_it_reports_a_created_administrator() -> None:
    raw = LOG_LINE + json.dumps({"super_admin": {"created": True, "email": "ops@example.org"}}) + "\n"
    assert _run("created", raw).stdout.strip() == "yes"
    assert _run("email", raw).stdout.strip() == "ops@example.org"


def test_unparseable_output_says_so_instead_of_pretending_success() -> None:
    assert _run("created", "note: no report at all\n").stdout.strip() == "unparsed"
    assert _run("reason", "note: no report at all\n").stdout.strip() == ""


def test_a_python_repr_is_not_mistaken_for_a_report() -> None:
    # the exact shape that broke the old parser: a Python dict (single quotes) and nothing else
    raw = "{'super_admin': {'created': True}}\n"
    assert _run("created", raw).stdout.strip() == "unparsed"


@pytest.mark.parametrize("field", ["created", "reason", "email"])
def test_the_installer_uses_the_parser_for_every_field(field: str) -> None:
    text = INSTALLER.read_text(encoding="utf-8")
    assert "bootstrap_report.py" in text, "install.sh must call the tested parser"
    assert 'raw.find("{"), raw.rfind("}")' not in text, (
        "the fragile slice must not come back — it fails whenever the CLI logs first"
    )


def test_a_rejected_administrator_stops_the_install() -> None:
    text = INSTALLER.read_text(encoding="utf-8")
    assert '*"e-mail rejected"*' in text and "*\"password rejected\"*" in text, (
        "a refused administrator must abort the install instead of producing a deployment nobody "
        "can sign in to"
    )
