"""The operations scripts must speak about tables that really exist.

`scripts/verify_backup.sh` counted rows from ``ledger_entries``. The immutable ledger table is
called ``credit_ledger`` (the ORM class is ``LedgerEntry``), so the query always failed and the
verifier printed ``ledger_entries=0`` for every backup — a *verified* backup that appeared to
contain no ledger at all. Nothing failed, which is exactly why it survived several rounds.

These checks are static (no database, no imports): they read the shipped scripts and the model
definitions and compare the identifiers used in SQL against the real table names.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]

OPS_SCRIPTS = [
    *(ROOT / "scripts").glob("*.sh"),
    *(ROOT / "deployment" / "linux").glob("*.sh"),
    *(ROOT / "deployment" / "daytona").glob("*.sh"),
    *(ROOT / "deployment" / "windows").glob("*.bat"),
]

# Tables that are not part of the application schema but are legitimate to query.
ALLOWED = {
    "sqlite_master", "sqlite_schema", "information_schema", "pg_catalog",
    "pg_roles", "pg_database", "pg_tables", "pg_stat_activity", "pg_stat_database",
}

# SQL in the operations scripts is written in UPPERCASE (a convention these tests now rely on), and
# only real statements are inspected: a line must contain an uppercase keyword followed by the table
# identifier. Prose ("could not update the administrator") and comment lines are therefore ignored,
# which keeps the check precise instead of noisy.
STATEMENT_PATTERN = re.compile(
    r"(?:SELECT\s+[^;\n]{0,200}?\bFROM|INSERT\s+INTO|DELETE\s+FROM|UPDATE)\s+([a-z_][a-z0-9_]*)"
)


def _statements(text: str) -> list[str]:
    """Table identifiers in SQL statements, skipping shell/patch comment lines."""
    found: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith(("#", "REM", "::", "--")):  # comments
            continue
        if not re.search(r"\b(SELECT|INSERT|DELETE|UPDATE)\b", stripped):   # uppercase SQL only
            continue
        found.extend(STATEMENT_PATTERN.findall(stripped))
    return found


def _declared_tables() -> set[str]:
    """Every ``__tablename__`` in the ORM, plus the tables the migrations create."""
    names: set[str] = set()
    for path in (ROOT / "backend" / "app" / "models").rglob("*.py"):
        names.update(re.findall(r'__tablename__\s*=\s*"([a-z_][a-z0-9_]*)"', path.read_text(encoding="utf-8")))
    for path in (ROOT / "backend" / "alembic" / "versions").glob("*.py"):
        text = path.read_text(encoding="utf-8")
        names.update(re.findall(r'create_table\(\s*"([a-z_][a-z0-9_]*)"', text))
    assert names, "no tables found — the model/migration scan is broken"
    return names


def test_scripts_only_query_tables_that_exist() -> None:
    declared = _declared_tables()
    offenders: list[str] = []
    for script in OPS_SCRIPTS:
        text = script.read_text(encoding="utf-8", errors="replace")
        for table in _statements(text):
            if table.lower() in ALLOWED:
                continue
            if table not in declared:
                offenders.append(f"{script.relative_to(ROOT)}: unknown table '{table}'")
    assert not offenders, (
        "operations scripts reference tables that do not exist (a failed query here is silent):\n"
        + "\n".join(offenders)
    )


def test_backup_verifier_counts_the_real_ledger_table() -> None:
    text = (ROOT / "scripts" / "verify_backup.sh").read_text(encoding="utf-8")
    assert "FROM credit_ledger" in text, "the backup verifier must count the real ledger table"
    assert "FROM ledger_entries" not in text, "the stale table name is back"
    # and it must say so when the table is missing instead of printing a plausible 0
    assert "no credit_ledger table" in text


def test_restore_and_backup_scripts_are_paired_and_documented() -> None:
    """Every backup script has a matching restore/verify script and a documented procedure."""
    scripts = {path.name for path in (ROOT / "scripts").glob("*.sh")}
    for required in ("backup.sh", "restore.sh", "verify_backup.sh"):
        assert required in scripts, f"{required} is missing"
    docs = (ROOT / "docs" / "BACKUP_RESTORE.md").read_text(encoding="utf-8")
    for required in ("backup.sh", "restore.sh", "verify_backup.sh"):
        assert required in docs, f"{required} is not mentioned in docs/BACKUP_RESTORE.md"


# --------------------------------------------------------------------------- shell hygiene ----

OPS_SHELL = sorted((ROOT / "scripts").glob("*.sh"))


@pytest.mark.parametrize("path", OPS_SHELL, ids=lambda p: p.name)
def test_ops_scripts_never_source_the_env_file(path: Path) -> None:
    """`set -a; source .env` executes a user-editable file — and aborts on the shipped one.

    The installer writes ``NEXA_APP_NAME=Nexa AI``. Sourcing that line makes the shell execute
    ``AI``; under ``set -e`` the script exits 127 *before doing anything*, so backup.sh,
    restore.sh and health_check.sh failed on every real installation. Values must be *parsed*
    (``nexa_env_value`` / ``nexa_env_load`` from scripts/lib_env.sh).
    """
    text = path.read_text(encoding="utf-8")
    body = "\n".join(
        line for line in text.splitlines()
        if line.strip() and not line.strip().startswith("#")
    )
    assert "source" not in body or ".env" not in body, f"{path.name} sources .env again"
    if ".env" in body and "NEXA_" in body:
        assert "lib_env.sh" in body or "nexa_env_" in body or path.name in {
            "lib_env.sh", "install.sh",
        }, f"{path.name} reads .env without the safe parser"


def test_env_reader_handles_what_the_installer_writes() -> None:
    """Functional check of the parser, over exactly the shapes the installer produces."""
    import subprocess
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        env = Path(tmp) / ".env"
        env.write_text(
            'NEXA_APP_NAME="Nexa AI"\n'
            "NEXA_ENVIRONMENT=production\n"
            "export NEXA_DATABASE_URL=postgresql+psycopg2://nexa:pa$$word@127.0.0.1:5432/nexa\n"
            'NEXA_PUBLIC_BASE_URL="https://nexa.example.com"\n'
            "NEXA_EMPTY=\n"
            "NEXA_UPLOAD_DIR=/opt/nexa-ai/uploads\n",
            encoding="utf-8",
        )
        script = (
            "set -Eeuo pipefail\n"
            f". {ROOT / 'scripts' / 'lib_env.sh'}\n"
            f'printf "%s|%s|%s" "$(nexa_env_value {env} NEXA_APP_NAME)" '
            f'"$(nexa_env_value {env} NEXA_DATABASE_URL)" '
            f'"$(nexa_env_value {env} NEXA_UPLOAD_DIR)"\n'
        )
        result = subprocess.run(["bash", "-c", script], capture_output=True, text=True, check=True)
        name, url, uploads = result.stdout.strip().split("|")
        assert name == "Nexa AI", "a quoted value with a space must come back intact"
        assert url == "postgresql+psycopg2://nexa:pa$$word@127.0.0.1:5432/nexa"
        assert uploads == "/opt/nexa-ai/uploads"


def test_restore_drill_refuses_to_print_credentials_and_owns_its_scratch_database() -> None:
    text = (ROOT / "scripts" / "restore_drill.sh").read_text(encoding="utf-8")
    assert "redacted" in text, "the drill prints the database URL — it must be redacted"
    assert "createdb -O" in text, (
        "the scratch database must be created for the application role, otherwise the restored "
        "tables belong to another user and the app cannot read them"
    )
    assert "pg_restore" in text and "doctor" in text and "/readyz" in text
    assert "inconsistent" in text, "the drill must require the ledger to reconcile"


def test_backup_writes_atomically_and_never_leaves_empty_archives() -> None:
    text = (ROOT / "scripts" / "backup.sh").read_text(encoding="utf-8")
    assert ".partial" in text, "a failed dump must not leave a zero-byte .dump that looks finished"
    assert "trap" in text
    assert "--no-password" in text, "a scheduled backup must never wait for a password prompt"
    assert "libpq_url" in text, (
        "pg_dump does not understand SQLAlchemy URLs (postgresql+psycopg2://) — the driver suffix "
        "must be stripped or libpq silently connects to the local socket as the OS user"
    )
