"""The installer must let the operator choose, and must honour what they choose.

Two things are checked here, both of them learned the hard way:

* **Choice exists.** Everybody used to get public-IP mode and a fixed ``admin@example.com``.
  The installer now asks (or takes flags / environment values) for the access mode *and* the
  administrator identity + password, and validates both before installing anything.
* **The choice is coherent end to end.** The mode decides the public URL, the deployment mode,
  the cookie/HSTS flags, the CORS origins, the trusted hosts and the Nginx template — if the
  installer's summary and the running configuration can disagree, one of them is lying.

These are static/behavioural checks over the shipped files; the real end-to-end run is recorded in
docs/TEST_REPORT.md.
"""
from __future__ import annotations

import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
INSTALL = ROOT / "deployment" / "linux" / "install.sh"
WIN_INSTALL = ROOT / "deployment" / "windows" / "install.bat"
WIN_SET_ADMIN = ROOT / "deployment" / "windows" / "set_admin.bat"
WIN_START = ROOT / "deployment" / "windows" / "start.bat"
NGINX = ROOT / "deployment" / "nginx"


def text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


# --------------------------------------------------------------------------- options / wizard ---

def test_installer_offers_every_access_choice_and_the_admin_credentials() -> None:
    body = text(INSTALL)
    for option in (
        "--access",           # public | domain | local
        "--domain",           # the domain to serve
        "--acme-email",       # Let's Encrypt e-mail
        "--admin-email",
        "--admin-name",
        "--admin-password",
        "--generate-admin-password",
        "--non-interactive",
    ):
        assert option in body, f"the installer does not support {option}"
    assert "never ask anything" in body and "NEXA_ADMIN_PASSWORD" in body

    # the interactive wizard has to ask the questions the operator complained were missing
    for question in (
        "How should people reach this application?",
        "Domain that points at this server",
        "Administrator e-mail (the sign-in name)",
        "password",
    ):
        assert question in body, f"the wizard never asks: {question}"


def test_wizard_only_prompts_on_a_terminal_and_validates_every_answer() -> None:
    body = text(INSTALL)
    # a piped / scheduled install must never block on read
    assert "[[ -t 0 && -t 1 ]] || return 1" in body, "the wizard runs without a terminal"
    # e-mail, domain and password policy are checked before anything is installed
    assert "is_valid_email" in body and "is_valid_domain" in body and "is_weak_password" in body
    validation_at = body.index("is_valid_email \"${ADMIN_EMAIL}\" || die")
    first_install_step = body.index("apt-get update -y")
    assert validation_at < first_install_step, "inputs must be validated before packages are touched"


def test_an_existing_installation_is_never_overwritten_by_default() -> None:
    body = text(INSTALL)
    assert "an installation already exists in" in body, "the wizard does not notice an existing install"
    assert "the defaults below keep it as it is" in body, "the wizard does not default to the stored configuration"
    assert "Change the existing administrator password?" in body
    # the password is only rotated when the operator asked for it (flag, wizard answer, or .env key)
    sync_start = body.index("sync_access_env() {")
    sync_end = body.index("\n}\n", sync_start)
    sync = body[sync_start:sync_end]
    assert "ADMIN_PASSWORD_INPUT" in sync and "ADMIN_PASSWORD_ROTATED=1" in sync


# ------------------------------------------------------------------- access mode coherence ----

def test_every_access_mode_sets_the_whole_configuration_together() -> None:
    body = text(INSTALL)
    for value in ("ACCESS_DEPLOYMENT_MODE", "ACCESS_BASE_URL", "ACCESS_COOKIE_SECURE",
                  "ACCESS_HSTS", "ACCESS_ORIGINS", "ACCESS_TRUSTED"):
        assert value in body, f"compute_access_values does not set {value}"
    # https is only claimed once a certificate really exists
    assert re.search(r"ACCESS_HTTPS=0\b", body), "ACCESS_HTTPS must default to 0"
    https_on = [m.start() for m in re.finditer(r"ACCESS_HTTPS=1", body)]
    assert https_on, "nothing ever enables HTTPS"
    assert "fullchain.pem" in body and "certbot" in body
    # domain without a certificate must stay honest (plain HTTP, warning still shown in the UI)
    assert 'ACCESS_DEPLOYMENT_MODE="public_ip"' in body


def test_domain_mode_picks_the_right_nginx_template_and_verifies_tls() -> None:
    body = text(INSTALL)
    for template in ("nexa-host.conf", "nexa-domain-http.conf", "nexa-domain-https.conf"):
        assert template in body, f"{template} is never installed"
        assert (NGINX / template).exists(), f"{template} is missing from the repository"
    assert "--resolve" in body, "TLS is not verified against the domain name"
    assert "certbot renew" in body, "automatic certificate renewal is not set up"
    assert "ssl_certificate" in text(NGINX / "nexa-domain-https.conf")
    assert "acme-challenge" in text(NGINX / "nexa-domain-https.conf")
    assert "acme-challenge" in text(NGINX / "nexa-domain-http.conf")


def test_local_mode_never_exposes_the_application() -> None:
    body = text(INSTALL)
    assert 'if [[ "${ACCESS_MODE}" == "local" ]]; then\n  SETUP_NGINX=0\nfi' in body
    assert 'die "--no-nginx cannot be combined with a domain deployment' in body


def test_reachability_check_can_verify_https_and_a_domain() -> None:
    checker = text(ROOT / "deployment" / "linux" / "check_public_access.sh")
    for option in ("--scheme", "--host-header", "--insecure"):
        assert option in checker, f"the reachability check cannot do {option}"
    assert "CURL_EXTRA" in checker, "the probe ignores the scheme/host header flags"


# ------------------------------------------------------------------------------ windows ------

def test_windows_installer_asks_the_same_questions() -> None:
    body = text(WIN_INSTALL)
    assert "choice /c 12" in body, "no access-mode question"
    assert "Administrator e-mail" in body and "Administrator display name" in body
    assert "Read-Host -AsSecureString" in body, "the password prompt must hide what is typed"
    assert "NEXA_DEPLOYMENT_MODE=public_ip" in body and "NEXA_DEPLOYMENT_MODE=local" in body
    assert "NEXA_PUBLIC_IP=!PUBLIC_IP!" in body and "NEXA_TRUSTED_HOSTS=127.0.0.1,localhost,!PUBLIC_IP!" in body
    assert "api.ipify.org" in body, "public mode does not try to detect the public address"
    assert "deployment\\windows\\set_admin.bat" in body, "the summary does not point at the helper"
    # a password typed by the operator must not be replaced by a generated one
    assert 'if "!ADMIN_PASSWORD!"=="" for /f "delims=" %%p in' in body


def test_windows_start_follows_the_installed_mode() -> None:
    body = text(WIN_START)
    assert 'if /i "!ENV_MODE!"=="public_ip"' in body and 'set "BIND=0.0.0.0"' in body
    assert "--host !BIND! --port !PORT!" in body
    assert "SECURITY WARNING" in body


def test_windows_admin_helper_exists_and_uses_the_safe_password_path() -> None:
    body = text(WIN_SET_ADMIN)
    assert "Read-Host -AsSecureString" in body
    assert "NEXA_ADMIN_PASSWORD" in body, "the password would be visible in the process list"
    assert "reset-password" in body and "create-admin" in body
    assert "findstr /r" in body, "the e-mail is not validated"
    # a fenced code block or a bash heredoc would break cmd.exe
    assert "<<'" not in body and "PYEOF" not in body


def test_windows_helpers_are_utf8_with_crlf_and_no_tabs() -> None:
    for name in ("install.bat", "start.bat", "set_admin.bat", "start_public.bat"):
        raw = (ROOT / "deployment" / "windows" / name).read_bytes()
        assert b"\r\n" in raw, f"{name} lost its CRLF line endings"
        assert b"\t" not in raw, f"{name} contains a tab (cmd.exe treats it as a command separator)"
        raw.decode("utf-8")  # must stay valid UTF-8 for chcp 65001


# --------------------------------------------------------------- operator-intent protection ---

def test_a_requested_admin_email_is_never_silently_dropped() -> None:
    """An existing installation keeps its administrator — and the operator is told, loudly.

    ``.env`` becomes the source of truth early in the run, which used to overwrite the value the
    operator passed with ``--admin-email`` *before* anything compared the two: the flag was simply
    ignored and no message was printed. The requested value is now remembered separately.
    """
    body = text(INSTALL)
    assert "ADMIN_EMAIL_REQUESTED" in body, "the requested administrator e-mail is not remembered"
    assert "was NOT applied" in body, "the operator is not told when their choice is ignored"
    assert "create another administrator from the admin panel" in body, "no way forward is offered"
    # and the warning is not repeated by the second sync pass
    assert "ADMIN_EMAIL_WARNED" in body


def test_admin_login_selfcheck_talks_to_the_api_not_to_the_proxy() -> None:
    """The credential check must not depend on the proxy or the access mode.

    In domain+HTTPS mode port 80 redirects to the domain, which does not resolve from inside the
    host — the check then reported a perfectly good install as "the password is probably outdated".
    """
    body = text(INSTALL)
    assert 'local base="http://127.0.0.1:${API_PORT}"' in body
    assert 'base="http://127.0.0.1:${PUBLIC_PORT}"' not in body


def test_self_signed_certificates_are_detected_explained_and_handled() -> None:
    body = text(INSTALL)
    assert "CERT_SELF_SIGNED" in body
    assert "openssl x509" in body, "the certificate is never inspected"
    assert "SELF-SIGNED" in body and "certbot --nginx" in body, "no explanation / no way to fix it"
    # the reachability check gets --insecure only in that case
    assert "CHECK_INSECURE" in body


def test_reachability_check_never_mixes_http_into_an_https_probe() -> None:
    """Every probe must use the requested scheme.

    A leftover ``http://`` probe against port 443 makes nginx answer 400 ("plain HTTP request sent
    to HTTPS port") and the installation is reported as unreachable while it is perfectly fine.
    """
    checker = text(ROOT / "deployment" / "linux" / "check_public_access.sh")
    hardcoded = re.findall(r'probe "http://', checker)
    assert not hardcoded, f"a probe ignores --scheme: {len(hardcoded)} occurrence(s)"
    assert checker.count('probe "${SCHEME}://') >= 3, "not every probe follows the scheme"


def test_installer_never_prints_a_url_it_did_not_configure() -> None:
    """Local mode has no Nginx: the URL must be the API's own port, not the published one."""
    body = text(INSTALL)
    assert 'ACCESS_BASE_URL="http://127.0.0.1:${API_PORT}"' in body
    assert "(no Nginx in this mode)" in body


# --------------------------------------------------------------------------- nginx compatibility --
def test_https_vhost_never_uses_the_http2_directive_that_old_nginx_rejects() -> None:
    """Ubuntu 24.04 ships nginx 1.24, where `http2 on;` is a fatal error.

    The HTTPS template must therefore use the portable `listen 443 ssl http2;` form, and the
    installer must upgrade it to the modern two-line form only after checking the version. A
    template with a bare `http2 on;` made `nginx -t` fail on that distribution, i.e. the HTTPS
    vhost never came up.
    """
    template = (ROOT / "deployment" / "nginx" / "nexa-domain-https.conf").read_text()
    assert "listen 443 ssl http2;" in template, "the portable form is required for nginx 1.24"
    assert not re.search(r"^\s*http2 on;", template, re.M), (
        "a bare `http2 on;` breaks nginx 1.24 (Ubuntu 24.04) — the installer adds it only after a version check"
    )

    installer = (ROOT / "deployment" / "linux" / "install.sh").read_text()
    assert "nginx_supports_http2_directive" in installer, "no version guard for `http2 on;`"
    assert "nginx -v" in installer, "the guard must ask the installed nginx for its version"
    assert "http2 on;" in installer, "the modern form must still be written on new nginx"


def test_launcher_services_can_restart_a_crashed_process_without_systemd() -> None:
    """A systemd-less host must still recover on its own.

    `Restart=always` does not exist without systemd, so `nexa-services.sh` provides `keepalive`
    and the installer schedules it in cron (installing `cron` when the image does not ship it) —
    otherwise a crashed API stayed down until a human noticed.
    """
    launcher = (ROOT / "deployment" / "linux" / "nexa-services.sh").read_text()
    assert "keepalive)" in launcher, "the launcher has no keepalive action"
    assert re.search(r"keepalive\(\)", launcher), "keepalive must be a function, not just a word in the header"

    installer = (ROOT / "deployment" / "linux" / "install.sh").read_text()
    assert "nexa-keepalive" in installer, "the installer never schedules the keepalive job"
    assert "@reboot" in installer, "the services must also come back after a host reboot"
    assert "apt-get install -y cron" in installer, "cron itself must be installed when missing"
