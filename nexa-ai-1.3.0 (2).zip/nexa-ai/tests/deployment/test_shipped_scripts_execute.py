#!/usr/bin/env python3
"""The scripts we ship must actually run.

`scripts/seed_demo.py` called `user.set_password(...)` and `user.mark_email_verified()` — two
methods that do not exist on the `User` model. Importing the script is fine (the calls are inside
`main()`), so nothing noticed: the documented "populate a fresh installation" step crashed with
`AttributeError` the first time a real operator tried it, and `--with-provider` then hit a second
bug (the provider service refused a credential-less placeholder, although the script's whole point
is to create a *disabled* one).

Static greps did not catch either bug. These tests *execute* the shipped scripts against a
throw-away SQLite database, which is the only check that proves the code path works.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / "backend"


def _run_seed(tmp_path: Path, *args: str) -> subprocess.CompletedProcess[str]:
    env = dict(os.environ)
    env.update(
        {
            "PYTHONPATH": str(BACKEND),
            "NEXA_ENVIRONMENT": "test",
            "NEXA_DATABASE_URL": f"sqlite:///{tmp_path / 'seed.db'}",
            "NEXA_UPLOAD_DIR": str(tmp_path / "uploads"),
            "NEXA_SECRET_KEY": "seed-script-test-secret-key-0123456789abcdef",
            "NEXA_ENCRYPTION_KEY": "",
            "NEXA_LOG_LEVEL": "WARNING",
        }
    )
    # 1) create the schema the same way the app does (ORM metadata, no alembic needed here)
    create = subprocess.run(
        [sys.executable, "-c", _CREATE_SCHEMA],
        cwd=ROOT, env=env, capture_output=True, text=True, timeout=180,
    )
    assert create.returncode == 0, f"schema creation failed:\n{create.stdout}\n{create.stderr}"

    # 2) run the real script
    return subprocess.run(
        [sys.executable, str(ROOT / "scripts" / "seed_demo.py"), *args],
        cwd=ROOT, env=env, capture_output=True, text=True, timeout=180,
    )


_CREATE_SCHEMA = """
from app.db.base import Base
from app.db.session import get_engine
import app.models  # noqa: F401  (registers every mapper)
Base.metadata.create_all(bind=get_engine())
print("schema ready")
"""


def test_seed_demo_script_runs_and_creates_the_demo_user(tmp_path: Path) -> None:
    result = _run_seed(tmp_path)
    assert result.returncode == 0, f"seed_demo.py failed:\n{result.stdout}\n{result.stderr}"
    assert "created demo user demo.user@example.com" in result.stdout

    import sqlite3

    conn = sqlite3.connect(tmp_path / "seed.db")
    try:
        row = conn.execute(
            "SELECT email, password_hash, email_verified, status FROM users WHERE email = ?",
            ("demo.user@example.com",),
        ).fetchone()
    finally:
        conn.close()
    assert row is not None, "the demo user was reported but not stored"
    email, password_hash, email_verified, status = row
    assert email == "demo.user@example.com"
    assert password_hash and len(password_hash) > 20, "the password must be hashed, never stored raw"
    assert "Demo-User-Passw0rd!" not in password_hash
    assert email_verified == 1 and status == "active"


def test_seed_demo_script_runs_twice_without_duplicating_rows(tmp_path: Path) -> None:
    first = _run_seed(tmp_path)
    assert first.returncode == 0, first.stderr
    second = _run_seed(tmp_path)  # schema creation is idempotent; the script must be too

    result = subprocess.run(
        [sys.executable, str(ROOT / "scripts" / "seed_demo.py")],
        cwd=ROOT,
        env={**os.environ, "PYTHONPATH": str(BACKEND),
             "NEXA_DATABASE_URL": f"sqlite:///{tmp_path / 'seed.db'}",
             "NEXA_ENVIRONMENT": "test", "NEXA_SECRET_KEY": "seed-script-test-secret-key-0123456789abcdef"},
        capture_output=True, text=True, timeout=180,
    )
    assert second.returncode == 0, second.stderr
    assert result.returncode == 0, result.stderr
    assert "demo user already exists" in result.stdout

    import sqlite3

    conn = sqlite3.connect(tmp_path / "seed.db")
    try:
        count = conn.execute("SELECT COUNT(*) FROM users WHERE email = ?", ("demo.user@example.com",)).fetchone()[0]
    finally:
        conn.close()
    assert count == 1, "re-running the seed script duplicated the demo user"


def test_seed_demo_placeholder_provider_is_disabled_and_has_no_credentials(tmp_path: Path) -> None:
    result = _run_seed(tmp_path, "--with-provider")
    assert result.returncode == 0, f"seed_demo.py --with-provider failed:\n{result.stdout}\n{result.stderr}"

    import sqlite3

    conn = sqlite3.connect(tmp_path / "seed.db")
    try:
        rows = conn.execute(
            "SELECT enabled, api_key_encrypted, api_key_hint FROM providers WHERE slug = ?",
            ("demo-provider-disabled",),
        ).fetchall()
    finally:
        conn.close()
    assert len(rows) == 1, "the documented placeholder provider was not created"
    enabled, key_encrypted, key_hint = rows[0]
    assert enabled == 0, "the placeholder provider must ship DISABLED"
    assert key_encrypted is None and key_hint is None, "no credential may be invented for a placeholder"


@pytest.mark.parametrize("script", ["scripts/seed_demo.py", "scripts/create_admin.py", "scripts/backup.sh"])
def test_documented_scripts_exist_and_are_executable(script: str) -> None:
    path = ROOT / script
    assert path.exists(), f"{script} is referenced by the docs but missing from the archive"
    if path.suffix == ".py":
        compile(path.read_text(), str(path), "exec")  # syntax-check what we ship
    else:
        assert os.access(path, os.X_OK), f"{script} is not executable"
