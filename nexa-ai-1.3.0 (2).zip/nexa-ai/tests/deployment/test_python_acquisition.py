#!/usr/bin/env python3
"""A machine whose only `python3` is 3.14 must still be installable.

The operator hit this on a real Ubuntu server:

    [error] no supported Python interpreter found (need 3.11-3.13).
      "python3" in your PATH is : /usr/bin/python3 (3.14)

…and was told to run `apt-get install python3` (which installs 3.14 again) and
`install.sh --python /usr/bin/python3` (the same 3.14 — the install would fail a line later). The
installer now acquires a supported interpreter itself: versioned distro packages, then the
deadsnakes PPA on Ubuntu, then **uv**, which downloads a standalone CPython 3.13 that needs no
compiler, no Rust and no PPA — verified here by installing one and creating a venv with it.

These tests execute the real shell functions extracted from `install.sh`, so the selection logic is
proved rather than grepped.
"""
from __future__ import annotations

import os
import stat
import subprocess
import textwrap
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
INSTALLER = ROOT / "deployment" / "linux" / "install.sh"

# the shell functions under test, taken from the shipped installer itself
_FUNCTION_PATTERNS = (
    "/^python_version_of()/,/^}/p",
    "/^python_supported()/,/^}/p",
    "/^uv_python_binaries()/,/^}/p",
    "/^select_python()/,/^}/p",
    "/^NEXA_PYTHON_DIR=/p",
)


def _functions() -> str:
    script = ";".join(_FUNCTION_PATTERNS)
    result = subprocess.run(
        ["sed", "-n", script, str(INSTALLER)], capture_output=True, text=True, timeout=30, check=True
    )
    assert "select_python()" in result.stdout
    return result.stdout


def _stub(path: Path, version: str) -> Path:
    """A fake interpreter: `python_version_of` only asks it for `sys.version_info`.

    The shebang is absolute on purpose — the selection tests run with a PATH that contains nothing
    but the stubs, so no real interpreter can satisfy the search.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    major_minor = ".".join(version.split(".")[:2])   # `python_version_of` prints "3.13", not "3.13.7"
    path.write_text(
        "#!/bin/bash\n"
        'if [[ "$*" == *version_info* ]]; then echo "%s"; exit 0; fi\n'
        "exit 0\n" % major_minor
    )
    path.chmod(0o755)
    return path


def _run(body: str, env: dict[str, str] | None = None, path: Path | None = None) -> subprocess.CompletedProcess[str]:
    script = _functions() + "\n" + textwrap.dedent(body)
    merged = {**os.environ, **(env or {})}
    if path is not None:
        merged["PATH"] = str(path)          # nothing but the stubs: no ambient interpreter
    # an absolute bash: the PATH given to the test may contain nothing but the interpreter stubs
    return subprocess.run(
        ["/bin/bash", "-c", script], capture_output=True, text=True, timeout=60, env=merged
    )


def test_a_too_new_python_is_refused_by_the_supported_check(tmp_path: Path) -> None:
    stubs = tmp_path / "stubs"
    too_new = _stub(stubs / "python3.14", "3.14.0")
    supported = _stub(stubs / "python3.13", "3.13.7")
    result = _run(
        f'python_supported {too_new} && echo accepted || echo refused; '
        f'python_supported {supported} && echo accepted || echo refused',
        path=stubs,
    )
    assert result.stdout.split() == ["refused", "accepted"], result.stdout


def test_the_uv_managed_interpreter_is_found_when_the_system_one_is_too_new(tmp_path: Path) -> None:
    uv_dir = tmp_path / "nexa-python"
    uv_python = _stub(uv_dir / "cpython-3.13-linux-x86_64-gnu" / "bin" / "python3.13", "3.13.16")
    system_python = _stub(tmp_path / "usr-bin" / "python3", "3.14.0")
    result = _run(
        f'''
        export UV_PYTHON_INSTALL_DIR="{uv_dir}"
        export NEXA_PYTHON_DIR="{uv_dir}"
        echo "resolved=$(select_python || true)"
        ''',
        path=system_python.parent,   # PATH holds only the 3.14 stub
    )
    assert f"resolved={uv_python}" in result.stdout, result.stdout + result.stderr
    assert "3.14" not in result.stdout.split("resolved=")[1]


def test_a_newer_uv_interpreter_does_not_shadow_a_supported_one(tmp_path: Path) -> None:
    uv_dir = tmp_path / "nexa-python"
    _stub(uv_dir / "cpython-3.14-linux-x86_64-gnu" / "bin" / "python3.14", "3.14.1")
    good = _stub(uv_dir / "cpython-3.12-linux-x86_64-gnu" / "bin" / "python3.12", "3.12.9")
    result = _run(
        f'''
        export UV_PYTHON_INSTALL_DIR="{uv_dir}"
        export NEXA_PYTHON_DIR="{uv_dir}"
        echo "resolved=$(select_python || true)"
        ''',
        path=uv_dir,                 # PATH adds nothing real either
    )
    assert f"resolved={good}" in result.stdout, result.stdout


# ------------------------------------------------------------------ the chain itself --
def test_the_installer_tries_packages_then_the_ppa_then_uv() -> None:
    text = INSTALLER.read_text(encoding="utf-8")
    assert "try_distro_python_packages" in text
    assert "try_deadsnakes" in text
    assert "try_uv_python" in text
    assert "python install 3.13" in text, "uv must install an explicit supported version"
    for package in ("python3.13", "python3.12", "python3.11"):
        assert package in text
    # the call order matters: cheap and local first, network last
    assert text.index("try_distro_python_packages ||") < text.index("try_deadsnakes ||") < text.index(
        "try_uv_python ||"
    )


def test_uv_installs_system_wide_so_the_service_user_can_execute_it() -> None:
    text = INSTALLER.read_text(encoding="utf-8")
    assert "NEXA_PYTHON_DIR=\"${UV_PYTHON_INSTALL_DIR:-/opt/nexa-python}\"" in text
    assert 'chmod -R a+rX "${NEXA_PYTHON_DIR}"' in text, (
        "the interpreter lives outside the app directory and is executed by the service user"
    )


def test_the_dead_end_advice_is_gone() -> None:
    text = INSTALLER.read_text(encoding="utf-8")
    assert "sudo bash deployment/linux/install.sh --python /usr/bin/python3" not in text, (
        "on a 3.14-only machine that command points at the interpreter that was just refused"
    )
    assert "sudo apt-get install -y python3 python3-venv     # Debian 12/13, Ubuntu 22.04/24.04" not in text
    assert "deadsnakes" in text and "astral.sh/uv" in text, "the message must name working remedies"


def test_uv_can_really_provide_the_interpreter() -> None:
    """Executed only when uv is reachable (it was during development); skipped otherwise."""
    if not subprocess.run(["bash", "-c", "command -v uv || test -x /root/.local/bin/uv || test -x \"$HOME/.local/bin/uv\""],
                          capture_output=True).returncode == 0:
        pytest.skip("uv is not installed in this environment")
    result = subprocess.run(
        ["bash", "-c", 'UV_PYTHON_INSTALL_DIR=/tmp/nexa-uv-check "${UV_BIN:-$HOME/.local/bin/uv}" python install 3.13 >/dev/null 2>&1 '
                       '&& "${UV_BIN:-$HOME/.local/bin/uv}" python find 3.13'],
        capture_output=True, text=True, timeout=600,
        env={**os.environ, "UV_PYTHON_INSTALL_DIR": "/tmp/nexa-uv-check"},
    )
    if result.returncode != 0:
        pytest.skip("no network access to fetch a standalone CPython here")
    assert "3.13" in result.stdout, result.stdout + result.stderr
