"""Static verification of the Windows batch set.

The Windows installer cannot be executed in this workspace (no Windows host), and that stays
honest in `docs/TEST_REPORT.md`. What *can* be verified here is the class of defect that makes a
batch file fail on a customer machine in ways nobody sees in a Linux rehearsal:

* **LF-only line endings** — `cmd.exe` tolerates them for simple lines but loses its footing in
  parenthesised blocks, labels and `for /f` constructs. Every shipped `.bat` must be CRLF (and
  every `.sh` must NOT be, or Debian refuses the shebang).
* invoking the wrong interpreter — everything after the virtualenv exists must use `%PY%`; only
  the prerequisite probe and `python -m venv` may use the system interpreter.
* starting the app without making `backend/` the working directory (the package is imported from
  there and `.env` is found one level up).
* arguments the CLI does not have (a `--app-dir` that was removed).
* references to files that are absent from the archive.
* secrets committed into the scripts.
* a double-clicked window that closes before the operator can read the error.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
WINDOWS = ROOT / "deployment" / "windows"
BATCH_FILES = sorted(WINDOWS.glob("*.bat"))

# `cd /d "%ROOT%\backend"`, `pushd "%ROOT%\backend"` or `start /d "%ROOT%\backend"` — also with the
# escaped quotes used inside a variable assignment.
_BACKEND_ENTRY = re.compile(
    r'(?:cd\s+/d|pushd|/d)\s*\\?"?%ROOT%\\+backend', re.IGNORECASE
)
# Lines that legitimately use the *system* interpreter (the virtualenv does not exist yet).
_PREREQUISITE_PYTHON = re.compile(r"(where python|python --version|python\s+-m\s+venv)", re.IGNORECASE)
_APP_INVOCATION = re.compile(r"-%s\s+-m\s+(uvicorn|alembic|app\.)" % "PY", re.IGNORECASE)


def test_the_expected_batch_set_exists() -> None:
    names = {path.name for path in BATCH_FILES}
    for required in ("install.bat", "start.bat", "start_public.bat", "start_worker.bat", "backup.bat",
                     "verify.bat", "diagnose.bat", "make_shortcuts.bat"):
        assert required in names, f"{required} is missing from deployment/windows"


@pytest.mark.parametrize("path", BATCH_FILES, ids=lambda p: p.name)
def test_batch_files_use_crlf_line_endings(path: Path) -> None:
    data = path.read_bytes()
    assert b"\r\n" in data, f"{path.name} has no CRLF line endings"
    lonely_lf = data.replace(b"\r\n", b"").count(b"\n")
    assert lonely_lf == 0, f"{path.name} contains {lonely_lf} LF-only line ending(s)"


@pytest.mark.parametrize("path", sorted((ROOT / "scripts").glob("*.sh")) +
                         sorted((ROOT / "deployment" / "linux").glob("*.sh")) +
                         sorted((ROOT / "deployment" / "daytona").glob("*.sh")),
                         ids=lambda p: p.name)
def test_shell_scripts_never_use_crlf(path: Path) -> None:
    assert b"\r\n" not in path.read_bytes(), f"{path.name} must not contain CRLF"


@pytest.mark.parametrize("path", BATCH_FILES, ids=lambda p: p.name)
def test_batch_hygiene(path: Path) -> None:
    text = path.read_text(encoding="utf-8", errors="replace")
    assert text.lstrip().startswith("@echo off"), f"{path.name} must start with @echo off"
    assert "--app-dir" not in text, f"{path.name} passes --app-dir, which this CLI does not accept"
    assert "\t" not in text, f"{path.name} contains tabs (cmd handles them unpredictably)"


@pytest.mark.parametrize("path", BATCH_FILES, ids=lambda p: p.name)
def test_app_steps_use_the_virtualenv_interpreter(path: Path) -> None:
    text = path.read_text(encoding="utf-8", errors="replace")
    offenders = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.lower().startswith(("rem", "::", "echo")):
            continue
        if _PREREQUISITE_PYTHON.search(stripped):
            continue          # probing the system interpreter / creating the venv is correct
        if re.search(r"(?<!%)python(?!\.exe)\b", stripped) and "%PY%" not in stripped:
            offenders.append(stripped)
    assert not offenders, (
        f"{path.name} calls a bare python instead of the virtualenv interpreter:\n" + "\n".join(offenders)
    )


@pytest.mark.parametrize("path", BATCH_FILES, ids=lambda p: p.name)
def test_the_app_is_started_from_the_backend_directory(path: Path) -> None:
    """`app` is importable only from `backend/`, and `.env` is found one level above it."""
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    entry_index = next((i for i, line in enumerate(lines) if _BACKEND_ENTRY.search(line)), None)
    invocation_index = next((i for i, line in enumerate(lines) if _APP_INVOCATION.search(line)), None)
    if invocation_index is None:
        pytest.skip(f"{path.name} does not start an application module")
    assert entry_index is not None, f"{path.name} starts the app without entering backend/"
    assert entry_index < invocation_index, (
        f"{path.name} starts the app before switching to backend/ "
        f"(line {invocation_index + 1} vs {entry_index + 1})"
    )


def test_the_installer_starts_console_windows_without_nested_quote_traps() -> None:
    """`start "t" cmd /k "cd /d "quoted path" && ..."` breaks as soon as the path has a space.

    The directory belongs to `start /d`, and the interpreter must be passed with the doubled-quote
    idiom (`cmd /k ""C:\\path\\python.exe" -m uvicorn ..."`), which `cmd` handles correctly.
    """
    text = (WINDOWS / "start.bat").read_text(encoding="utf-8")
    launchers = [line.strip() for line in text.splitlines()
                 if line.strip().lower().startswith("start ") and "cmd /k" in line.lower()]
    assert launchers, "start.bat no longer launches a console"
    for line in launchers:
        assert '/d "%ROOT%\\backend"' in line, f"missing start /d working directory: {line}"
        assert 'cmd /k ""%PY%"' in line, f"the interpreter must use the doubled-quote idiom: {line}"
        assert "cd /d" not in line, f"the nested-quote form is fragile: {line}"


def test_installer_handles_missing_prerequisites_and_reports_failures() -> None:
    text = (WINDOWS / "install.bat").read_text(encoding="utf-8")
    assert "where python" in text and "where node" in text
    assert "SKIP_FRONTEND" in text, "a missing Node.js must skip the build instead of failing"
    for step in ("virtual environment creation failed", "dependency installation failed",
                 "database migration failed", "bootstrap failed"):
        assert step in text, f"install.bat does not handle: {step}"
    assert text.count("exit /b 1") >= 4
    assert "secrets.token_urlsafe" in text and "os.urandom" in text
    assert "NEXA_SECRET_KEY=!SECRET_KEY!" in text
    assert not re.search(r"NEXA_SECRET_KEY=[A-Za-z0-9_-]{16,}", text), "a secret is hard-coded"


def test_batch_files_only_reference_files_that_exist() -> None:
    missing: list[str] = []
    for path in BATCH_FILES:
        text = path.read_text(encoding="utf-8", errors="replace")
        for candidate in re.findall(r"%(?:ROOT|~dp0\.\.)\\\.\.\\([A-Za-z0-9_\\.-]+)", text):
            relative = candidate.replace("\\", "/")
            if relative.startswith("..") or relative.startswith("%"):
                continue
            if not (ROOT / relative).exists():
                missing.append(f"{path.name} -> {relative}")
    assert not missing, "batch files reference paths that do not exist:\n" + "\n".join(missing)


@pytest.mark.parametrize("name", ["install.bat", "verify.bat", "diagnose.bat", "install_service.bat"])
def test_interactive_scripts_keep_the_window_open_when_double_clicked(name: str) -> None:
    """A double-clicked .bat closes when it ends — including on failure.

    The guard pauses only when the script was *not* started from an open console, so automated
    runs (`backup.bat` in a scheduled task, CI) are never blocked.
    """
    text = (WINDOWS / name).read_text(encoding="utf-8")
    assert "CMDCMDLINE" in text, f"{name} would vanish on double-click"
    assert re.search(r'find\s+/i\s+"%~nx0"\s*>nul\s*&&\s*pause', text), (
        f"{name} must pause only when double-clicked"
    )


def test_backup_and_start_scripts_never_block_automation() -> None:
    for name in ("backup.bat", "start_worker.bat", "start.bat", "start_public.bat"):
        text = (WINDOWS / name).read_text(encoding="utf-8")
        assert "CMDCMDLINE" not in text, f"{name} must stay non-interactive (it may run from a scheduled task)"


def test_public_mode_warns_about_plain_http_and_declares_itself() -> None:
    text = (WINDOWS / "start_public.bat").read_text(encoding="utf-8")
    assert "SECURITY WARNING" in text
    assert "--host 0.0.0.0" in text
    for variable in ("NEXA_DEPLOYMENT_MODE=public_ip", "NEXA_PUBLIC_IP", "NEXA_TRUSTED_HOSTS"):
        assert variable in text, f"start_public.bat does not set {variable}"
