"""Deployment-asset checks: the files that make an installation possible must exist and be sane.

These run without Docker, PostgreSQL or a network, so they can be executed on any checkout and in CI.
They validate the Compose topology, the installers, the Nginx/systemd units, script syntax and the
consistency between the documentation set and the repository.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[2]
DEPLOYMENT = ROOT / "deployment"

REQUIRED_FILES = [
    "docker-compose.yml",
    "docker-compose.dev.yml",
    ".env.example",
    "README.md",
    "backend/requirements.txt",
    "backend/requirements-dev.txt",
    "backend/alembic.ini",
    "database/postgres_init.sql",
    "database/schema.md",
    "deployment/.env.production.example",
    "deployment/docker/Dockerfile.backend",
    "deployment/docker/Dockerfile.worker",
    "deployment/docker/Dockerfile.frontend",
    "deployment/nginx/nexa.conf",
    "deployment/nginx/nexa-host.conf",
    "deployment/nginx/nexa-https.conf.example",
    "deployment/linux/install.sh",
    "deployment/linux/nexa-services.sh",
    "deployment/linux/nexa-api.service",
    "deployment/linux/nexa-worker.service",
    "deployment/linux/nexa-backup.cron",
    "deployment/windows/install.bat",
    "deployment/windows/start.bat",
    "deployment/windows/start_public.bat",
    "deployment/windows/start_worker.bat",
    "deployment/windows/backup.bat",
    "deployment/windows/diagnose.bat",
    "deployment/windows/install_service.bat",
    "deployment/windows/uninstall_service.bat",
    "deployment/windows/make_shortcuts.bat",
    "deployment/windows/nexa.env.example",
    "scripts/backup.sh",
    "scripts/restore.sh",
    "scripts/verify_backup.sh",
    "scripts/health_check.sh",
    "scripts/run_worker.sh",
    "scripts/create_admin.py",
    "scripts/seed_demo.py",
    "tests/tools/mock_openai_upstream.py",
    "tests/integration/test_live_stack.py",
]


@pytest.mark.parametrize("relative", REQUIRED_FILES)
def test_required_deliverable_exists(relative: str) -> None:
    path = ROOT / relative
    assert path.is_file(), f"missing required file: {relative}"
    assert path.stat().st_size > 0, f"empty file: {relative}"


def test_compose_production_topology() -> None:
    data = yaml.safe_load((ROOT / "docker-compose.yml").read_text())
    services = data["services"]
    assert {"db", "redis", "api", "worker", "web"} <= set(services)

    # only the reverse proxy is reachable from the host
    published = {name: svc.get("ports") for name, svc in services.items() if svc.get("ports")}
    assert set(published) == {"web"}, f"unexpected published ports: {published}"
    assert "8080" in str(published["web"]) or "PUBLIC_PORT" in str(published["web"])

    # the API uses PostgreSQL and does not serve the SPA itself inside Compose
    api_env = services["api"]["environment"]
    assert "postgresql" in str(api_env["NEXA_DATABASE_URL"])
    assert api_env["NEXA_SERVE_FRONTEND"] == "false"
    assert api_env["NEXA_INLINE_WORKER"] == "false"

    # health checks exist for the stateful services
    assert "healthcheck" in services["db"]
    assert "healthcheck" in services["redis"]
    assert services["api"]["depends_on"]["db"]["condition"] == "service_healthy"


def test_compose_dev_topology_is_development_only() -> None:
    data = yaml.safe_load((ROOT / "docker-compose.dev.yml").read_text())
    api_env = data["services"]["api"]["environment"]
    assert api_env["NEXA_ENVIRONMENT"] == "development"
    assert "sqlite" in api_env["NEXA_DATABASE_URL"]
    assert data["services"]["api"]["environment"]["NEXA_COOKIE_SECURE"] == "false"


def test_docker_base_images_stay_within_the_supported_range() -> None:
    """The images must not silently move to a Python the pins cannot support."""
    backend = (DEPLOYMENT / "docker" / "Dockerfile.backend").read_text()
    worker = (DEPLOYMENT / "docker" / "Dockerfile.worker").read_text()
    match = re.search(r"FROM python:(\d+)\.(\d+)", backend)
    assert match, "Dockerfile.backend does not pin a python base image"
    version = (int(match.group(1)), int(match.group(2)))
    assert (3, 11) <= version <= (3, 13), f"Dockerfile.backend uses Python {match.group(0)}, outside 3.11-3.13"
    assert re.search(r"^FROM nexa-ai-backend", worker, re.M), (
        "Dockerfile.worker must reuse the backend image so both share one interpreter"
    )
    requirements = (ROOT / "backend" / "requirements.txt").read_text()
    assert "3.14" in requirements and "not supported" in requirements.lower()


def test_dockerfiles_are_complete() -> None:
    backend = (DEPLOYMENT / "docker" / "Dockerfile.backend").read_text()
    assert "requirements.txt" in backend
    assert "alembic upgrade head" in backend
    assert "app.cli bootstrap" in backend
    assert "USER nexa" in backend, "the API image must not run as root"
    assert "HEALTHCHECK" in backend

    frontend = (DEPLOYMENT / "docker" / "Dockerfile.frontend").read_text()
    assert "npm run build" in frontend
    assert "nginx" in frontend

    worker = (DEPLOYMENT / "docker" / "Dockerfile.worker").read_text()
    assert "app.workers.worker" in worker


def test_shell_scripts_parse_and_are_executable() -> None:
    scripts = [
        ROOT / "scripts" / name
        for name in ("backup.sh", "restore.sh", "verify_backup.sh", "health_check.sh", "run_worker.sh")
    ] + [DEPLOYMENT / "linux" / "install.sh", DEPLOYMENT / "linux" / "nexa-services.sh"]
    for path in scripts:
        assert path.is_file(), f"missing script {path}"
        completed = subprocess.run(["bash", "-n", str(path)], capture_output=True, text=True)
        assert completed.returncode == 0, f"{path.name} has a syntax error: {completed.stderr}"
        assert path.stat().st_mode & 0o111, f"{path.name} is not executable"


def test_installer_references_real_files() -> None:
    installer = (DEPLOYMENT / "linux" / "install.sh").read_text()
    for reference in (
        "deployment/linux/nexa-api.service",
        "deployment/linux/nexa-worker.service",
        "backend/requirements.txt",
    ):
        assert reference in installer, f"install.sh does not reference {reference}"
        assert (ROOT / reference).exists(), f"install.sh references a missing file: {reference}"

    # Nginx templates are rendered through install_nginx_site "${template}"; every template the
    # installer can pick must exist (the local/access-mode choice decides which one is used).
    templates = re.findall(r'install_nginx_site "(nexa-[a-z-]+\.conf)"', installer)
    assert set(templates) >= {"nexa-host.conf", "nexa-domain-http.conf", "nexa-domain-https.conf"}, templates
    for template in templates:
        assert (DEPLOYMENT / "nginx" / template).exists(), f"install.sh references a missing template: {template}"

    windows = (DEPLOYMENT / "windows" / "install.bat").read_text()
    for reference in ("backend\\requirements.txt", "frontend", "app.cli bootstrap", "alembic upgrade head"):
        assert reference in windows, f"install.bat does not mention {reference}"

    start = (DEPLOYMENT / "windows" / "start.bat").read_text()
    assert "app.main:app" in start, "start.bat does not start the API"
    assert "app.workers.worker" in start, "start.bat does not start the worker"


def test_windows_scripts_reference_existing_paths() -> None:
    """Scripts that need Python must use the virtualenv interpreter, not a global one."""
    for name, needle in (
        ("start.bat", "app.main:app"),
        ("start_public.bat", "app.main:app"),
        ("start_worker.bat", "app.workers.worker"),
        ("diagnose.bat", "app.cli"),
    ):
        text = (DEPLOYMENT / "windows" / name).read_text()
        assert ".venv\\Scripts\\python.exe" in text, f"{name} does not invoke the venv python"
        assert needle in text, f"{name} does not call {needle}"

    # backup.bat works with the database tooling (copy / pg_dump / PowerShell), not Python
    backup = (DEPLOYMENT / "windows" / "backup.bat").read_text()
    assert "backups" in backup and ("pg_dump" in backup or "copy /y" in backup)

    service = (DEPLOYMENT / "windows" / "install_service.bat").read_text()
    assert "app.main:app" in service or "app.workers.worker" in service


def test_installer_starts_services_in_any_environment() -> None:
    """An installer that assumes a running PostgreSQL rewrites history: it must start it itself."""
    installer = (DEPLOYMENT / "linux" / "install.sh").read_text()

    # PostgreSQL: readiness wait plus every documented start mechanism
    assert "pg_isready" in installer, "the installer does not wait for PostgreSQL readiness"
    assert "pg_ctlcluster" in installer, "no Debian/Ubuntu cluster fallback"
    assert "pg_ctl" in installer, "no raw pg_ctl fallback for containers"
    assert "systemctl start postgresql" in installer
    assert "service postgresql start" in installer

    # Redis is optional and must never abort the installation
    assert "start_redis" in installer
    assert "in-process rate limiting" in installer

    # systemd may be missing (containers): fall back to the process launcher
    assert "nexa-services.sh" in installer
    assert "systemd_usable" in installer

    # a wildcard host allow-list is refused by the API in production
    assert "NEXA_TRUSTED_HOSTS=${ACCESS_TRUSTED}" in installer, "the fresh .env must use the mode-aware trusted hosts"
    assert not re.search(r"^NEXA_TRUSTED_HOSTS=\*$", installer, re.M)

    # the installer must not source the .env (a hand-edited file breaks bash)
    assert "source \"${APP_DIR}/.env\"" not in installer

    # and it must verify that the result actually works
    assert "administrator sign-in verified" in installer
    assert "health check passed" in installer

    # re-running must never destroy data or secrets
    assert "--exclude '/data/'" in installer and "--exclude '/uploads/'" in installer
    assert "--exclude '/.env'" in installer


def test_installer_picks_a_supported_python() -> None:
    """Python 3.14+ cannot build the pinned pydantic-core wheels — the installer must avoid it."""
    installer = (DEPLOYMENT / "linux" / "install.sh").read_text()
    assert "SUPPORTED_PYTHON" in installer and "3.11-3.13" in installer
    assert "select_python" in installer and "python_supported" in installer
    assert "--python" in installer
    # candidates are tried in order and the distribution interpreter is one of them
    assert "python3.13 python3.12 python3.11" in installer
    assert "/usr/bin/python3" in installer
    # a stale virtualenv (built by another interpreter) is rebuilt, not reused
    assert "recreating it with" in installer
    # and the chosen interpreter is recorded for support
    assert "python=" in installer and ".install-info" in installer
    # minimal PATHs (cron, docker exec) must still find nginx/pg tools
    assert 'export PATH="/usr/sbin:/sbin:' in installer


def test_installer_repairs_legacy_env_values() -> None:
    """An .env written by an older installer (or copied from a template) must not block the upgrade."""
    installer = (DEPLOYMENT / "linux" / "install.sh").read_text()
    assert "repair_env" in installer
    assert "strip_inline_comments" in installer, "inline comments in a value line crash the API at boot"
    assert "replaced the wildcard NEXA_TRUSTED_HOSTS" in installer
    assert "secret_needs_replacement" in installer
    for key in ("NEXA_SECRET_KEY", "NEXA_ENCRYPTION_KEY", "NEXA_DATABASE_URL", "NEXA_PUBLIC_BASE_URL", "NEXA_CORS_ORIGINS"):
        assert key in installer, f"{key} is not repaired"
    assert "--reset-env" in installer


def test_installer_adapts_container_values_for_a_native_install() -> None:
    """Deployment/.env.production.example targets Compose; a native install must re-point it."""
    installer = (DEPLOYMENT / "linux" / "install.sh").read_text()
    for key in ("NEXA_UPLOAD_DIR", "NEXA_FRONTEND_DIST_DIR", "NEXA_REDIS_URL", "NEXA_SERVE_FRONTEND"):
        assert key in installer, f"{key} is not adapted"
    assert "container path" in installer
    assert "Docker service name 'redis'" in installer
    # a placeholder administrator password is a known credential and must never survive
    assert "NEXA_BOOTSTRAP_ADMIN_PASSWORD" in installer
    assert "ADMIN_PASSWORD_ROTATED" in installer
    assert "administrator password rotated and verified" in installer


def test_installer_never_reports_a_fake_admin_login() -> None:
    """The self-check must fail loudly: no 'verified' message without a real session."""
    installer = (DEPLOYMENT / "linux" / "install.sh").read_text()
    assert "admin_login_ok" in installer
    assert 'sys.exit(0 if ok else 1)' in installer, "the check must signal failure through its exit status"
    assert '[[ "${answer}" == "true" ]]' in installer, "the shell must compare the answer, not the exit code of print"
    assert "session_id" in installer or "csrf_token" in installer, "HTTP 200 alone is not proof of a session"
    assert "--reset-admin-password" in installer
    assert "reset-password" in installer and "app.cli reset-password" in installer


def test_installer_supports_help_and_reports_install_info() -> None:
    installer = (DEPLOYMENT / "linux" / "install.sh").read_text()
    assert "--help" in installer and "usage()" in installer, "no --help output"
    assert ".install-info" in installer, "the installer does not record how the tree was installed"
    for option in ("--no-packages", "--no-node", "--no-nginx", "--no-systemd", "--public-port"):
        assert option in installer, f"missing installer option {option}"


def _write_fake_binaries(directory, *, public_answers: bool) -> str:
    """A fake curl/hostname pair: a NATed host (172.20.0.45) whose public address may be open."""
    directory.mkdir(parents=True, exist_ok=True)
    public_case = (
        "  *203.0.113.9*) printf '200|'; exit 0 ;;"
        if public_answers
        else "  *203.0.113.9*) printf '000|Operation timed out'; exit 28 ;;"
    )
    curl = directory / "curl"
    curl.write_text("\n".join(
        [
            "#!/usr/bin/env bash",
            'url=""',
            'for arg in "$@"; do case "$arg" in http*) url="$arg";; esac; done',
            'case "$url" in',
            "  *ipify*|*ifconfig.me*|*icanhazip*) printf '203.0.113.9'; exit 0 ;;",
            public_case,
            "  *172.20.0.45*) printf '200|'; exit 0 ;;",
            "  *) printf '000|no route'; exit 7 ;;",
            "esac",
            "",
        ]
    ))
    curl.chmod(0o755)

    hostname = directory / "hostname"
    hostname.write_text("\n".join(
        [
            "#!/usr/bin/env bash",
            'if [[ "${1:-}" == "-I" ]]; then printf "172.20.0.45 \\n"; else printf "nexa-test\\n"; fi',
            "",
        ]
    ))
    hostname.chmod(0o755)
    return str(directory)


def test_public_access_checker_tells_the_truth_about_a_natted_host(tmp_path) -> None:
    """The situation this checker exists for: the app runs, the public address does not answer.

    172.20.0.45 is private (cloud/CGNAT style) with a public egress address of 203.0.113.9 and
    no port-forward, so a browser outside gets nothing. The checker must say exactly that —
    and it must not report success because the local address works.
    """
    env = dict(os.environ)
    env["PATH"] = _write_fake_binaries(tmp_path / "bin", public_answers=False) + os.pathsep + env["PATH"]
    result = subprocess.run(
        ["bash", str(DEPLOYMENT / "linux" / "check_public_access.sh"), "--port", "8080", "--wait", "0"],
        capture_output=True, text=True, env=env,
    )
    output = result.stdout + result.stderr
    assert result.returncode == 3, output
    assert "did NOT answer" in output
    assert "172.20.0.45" in output, "the working local address must still be reported"
    assert "private" in output and "forwarded" in output, "a NATed host needs the port-forward explanation"
    assert "ufw allow 8080/tcp" in output, "the firewall commands must be shown"
    assert "reachable from outside" not in output


def test_public_access_checker_confirms_a_reachable_host(tmp_path) -> None:
    env = dict(os.environ)
    env["PATH"] = _write_fake_binaries(tmp_path / "bin", public_answers=True) + os.pathsep + env["PATH"]
    result = subprocess.run(
        ["bash", str(DEPLOYMENT / "linux" / "check_public_access.sh"), "--port", "8080", "--wait", "0"],
        capture_output=True, text=True, env=env,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "reachable from outside" in result.stdout


def test_installer_verifies_the_url_it_prints() -> None:
    """A printed URL that does not open is worse than no URL: the installer must check it."""
    installer = (DEPLOYMENT / "linux" / "install.sh").read_text()
    assert "check_public_access.sh" in installer, "the installer never verifies the printed URL"
    assert "PUBLIC_CHECK_RC" in installer, "the check result is not used"
    assert "NOT reachable from another machine yet" in installer, "the summary cannot say 'does not open yet'"
    # the explanation of *why* it does not open moved into the mode-aware share block: it must
    # still name the three real causes (host firewall, cloud security group, NAT/port-forward)
    assert "SHARE IT WITH OTHERS" in installer
    for hint in ("ufw allow", "security-group rule", "port"): 
        assert hint in installer, f"the summary lost its guidance about {hint}"
    assert "port-forward" in installer.lower() or "forward inbound" in installer.lower()
    assert "--no-public-check" in installer, "the check cannot be skipped in a test environment"
    # the public address must be reachable as a Host header when the browser arrives through a
    # port-forward, otherwise the API answers 400 "Invalid host header"
    assert 'set_env_value "${file}" NEXA_TRUSTED_HOSTS "${value},${PUBLIC_IP}"' in installer
    # and it has to be the address the .env points at, not a hard-coded private one
    assert 'set_env_value "${file}" NEXA_PUBLIC_BASE_URL "http://${PUBLIC_HOST}:${PUBLIC_PORT}"' in installer

    completed = subprocess.run(["bash", str(DEPLOYMENT / "linux" / "install.sh"), "--help"],
                               capture_output=True, text=True)
    assert completed.returncode == 0
    assert "NEXA_PUBLIC_IP" in completed.stdout and "--no-public-check" in completed.stdout


def test_installer_credential_audit_runs_in_the_backend_directory() -> None:
    """The audit imports `app`, which only exists in <app dir>/backend.

    A first version of this check ran `venv/bin/python -m app.cli check-secrets` from the install
    root and swallowed stderr, so it silently did nothing on every install. The command path and
    the visibility of a failure are both pinned here.
    """
    installer = (DEPLOYMENT / "linux" / "install.sh").read_text()
    assert 'cd "${APP_DIR}/backend" && sudo -u "${APP_USER}" -E "${APP_DIR}/venv/bin/python" -m app.cli check-secrets' in installer
    assert 'warn "the provider-credential audit did not run' in installer, "a failing audit must be reported, never swallowed"
    assert 'SECRETS_ERR="$(mktemp)"' in installer
    assert "2>/dev/null || true" not in installer.split("SECRETS_OUT=")[1][:200], "the audit must not discard its own error output"


def test_process_launcher_manages_both_services() -> None:
    launcher = (DEPLOYMENT / "linux" / "nexa-services.sh").read_text()
    for verb in ("start", "stop", "restart", "status", "logs"):
        assert verb in launcher, f"launcher has no {verb} action"
    assert "app.main:app" in launcher and "app.workers.worker" in launcher
    assert "run" in launcher and ".pid" in launcher, "no PID files: services could not be stopped"
    # the launcher must behave exactly like the systemd units
    assert "--host 127.0.0.1" in launcher
    assert "healthz" in launcher


def test_nginx_configs_have_streaming_and_upload_settings() -> None:
    for name in ("nexa.conf", "nexa-host.conf"):
        text = (DEPLOYMENT / "nginx" / name).read_text()
        assert "proxy_buffering off" in text, f"{name} would buffer server-sent events"
        assert "client_max_body_size" in text, f"{name} does not raise the upload limit"
        assert "/api/" in text and "try_files" in text

    https = (DEPLOYMENT / "nginx" / "nexa-https.conf.example").read_text()
    assert "Strict-Transport-Security" in https
    assert "acme-challenge" in https

    # health endpoints are proxied explicitly: without an explicit Host header nginx sends
    # the upstream name and the API answers 400 "Invalid host header"
    for name in ("nexa.conf", "nexa-host.conf", "nexa-https.conf.example"):
        text = (DEPLOYMENT / "nginx" / name).read_text()
        health_blocks = re.findall(r"location = /(?:healthz|readyz)\s*\{(.*?)\}", text, re.S)
        assert health_blocks, f"{name} does not proxy the health endpoints"
        for block in health_blocks:
            assert "proxy_set_header Host $host;" in block, f"{name}: health location without Host header"


def test_systemd_units_bind_loopback_and_restart() -> None:
    api = (DEPLOYMENT / "linux" / "nexa-api.service").read_text()
    assert "--host 127.0.0.1" in api, "the API unit must not bind a public interface"
    assert "Restart=always" in api
    assert "EnvironmentFile=__APP_DIR__/.env" in api
    worker = (DEPLOYMENT / "linux" / "nexa-worker.service").read_text()
    assert "app.workers.worker" in worker
    assert "Restart=always" in worker


def test_env_templates_contain_no_real_secrets() -> None:
    for relative in (".env.example", "deployment/.env.production.example", "deployment/windows/nexa.env.example"):
        text = (ROOT / relative).read_text()
        for line in text.splitlines():
            if not line or line.strip().startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            value = value.strip().strip('"')
            if not value:
                continue
            if any(token in key.upper() for token in ("SECRET", "PASSWORD", "KEY", "MERCHANT", "WALLET")):
                assert any(marker in value.upper() for marker in ("CHANGE_ME", "EXAMPLE", "YOUR", "PLACEHOLDER", "XXX", "")), (
                    f"{relative} looks like it contains a real secret for {key}"
                )


def test_env_templates_have_no_inline_comments() -> None:
    """`KEY=value  # note` is read literally by pydantic-settings and crashes the API on boot."""
    pattern = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*=[^ \t]+[ \t]+#")
    for relative in (".env.example", "deployment/.env.production.example", "deployment/windows/nexa.env.example"):
        offenders = [
            line for line in (ROOT / relative).read_text().splitlines() if pattern.match(line)
        ]
        assert not offenders, f"{relative} has inline comments after values: {offenders[:3]}"


def test_env_templates_are_parseable_by_the_application(tmp_path) -> None:
    """Each shipped template must be loadable: the app reads it and reports its own problems."""
    backend = ROOT / "backend"
    scratch = tmp_path / "envcheck"
    (scratch / "backend").mkdir(parents=True)
    for child in backend.iterdir():
        if child.name in {"__pycache__", ".pytest_cache"}:
            continue
        (scratch / "backend" / child.name).symlink_to(child, target_is_directory=child.is_dir())

    database = scratch / "scratch.db"
    base_env = {
        **os.environ,
        "NEXA_DATABASE_URL": f"sqlite:///{database}",
        "NEXA_ALLOW_SQLITE_IN_PRODUCTION": "true",  # isolate the check from the SQLite rule
        "PYTHONPATH": str(backend),
    }
    migrated = subprocess.run(
        [sys.executable, "-m", "alembic", "upgrade", "head"],
        cwd=str(scratch / "backend"), env=base_env, capture_output=True, text=True,
    )
    assert migrated.returncode == 0, migrated.stderr[-500:]

    for relative in (".env.example", "deployment/.env.production.example", "deployment/windows/nexa.env.example"):
        text = (ROOT / relative).read_text()
        (scratch / ".env").write_text(text)
        result = subprocess.run(
            [sys.executable, "-m", "app.cli", "doctor"],
            cwd=str(scratch / "backend"), env=base_env, capture_output=True, text=True,
        )
        assert result.returncode == 0, f"{relative} could not be loaded:\n{result.stderr[-800:]}"
        assert "unable to interpret input" not in result.stderr, f"{relative}: pydantic rejected a value"
        report = json.loads(result.stdout)

        # prove the file was really read: the values must match what the template declares
        declared = dict(
            line.split("=", 1) for line in text.splitlines()
            if line.startswith("NEXA_") and "=" in line and "#" not in line
        )
        assert report["environment"] == declared.get("NEXA_ENVIRONMENT", "development"), (relative, report)
        assert report["deployment_mode"] == declared.get("NEXA_DEPLOYMENT_MODE", "local"), (relative, report)

        # a production template must additionally report its placeholder secrets
        if declared.get("NEXA_ENVIRONMENT") == "production":
            problems = report.get("production_problems") or []
            assert any("NEXA_SECRET_KEY" in problem for problem in problems), (relative, problems)


def test_env_templates_only_use_settings_that_exist() -> None:
    """A key in an env template that the app does not read is worse than no key at all."""
    config = (ROOT / "backend" / "app" / "core" / "config.py").read_text()
    declared = set(re.findall(r"^\s{4}([a-z][a-z0-9_]*)\s*:", config, re.M))
    assert len(declared) > 30, "could not read the settings model"

    for relative in (".env.example", "deployment/.env.production.example", "deployment/windows/nexa.env.example"):
        text = (ROOT / relative).read_text()
        keys = re.findall(r"^(NEXA_[A-Z0-9_]+)=", text, re.M)
        assert keys, f"{relative} declares no NEXA_ keys"
        unknown = sorted({key for key in keys if key[5:].lower() not in declared})
        assert not unknown, f"{relative} sets keys the application does not read: {unknown}"


def test_documentation_set_is_complete() -> None:
    docs = ROOT / "docs"
    required = [
        "RAHNAMA.md",
        "INSTALLATION_GUIDE.md",
        "ARCHITECTURE.md",
        "INSTALL_WINDOWS.md",
        "INSTALL_UBUNTU.md",
        "REMOTE_TESTING.md",
        "PROVIDER_CONFIGURATION.md",
        "MODEL_MANAGEMENT.md",
        "BILLING.md",
        "SECURITY.md",
        "BACKUP_RESTORE.md",
        "TROUBLESHOOTING.md",
        "PRODUCTION_DEPLOYMENT.md",
        "KNOWN_LIMITATIONS.md",
        "TEST_REPORT.md",
    ]
    missing = [name for name in required if not (docs / name).is_file()]
    assert not missing, f"missing documents: {missing}"


def test_readme_links_point_to_existing_files() -> None:
    readme = (ROOT / "README.md").read_text()
    links = re.findall(r"\]\((docs/[^)#]+)\)", readme)
    assert links, "README contains no documentation links"
    missing = [link for link in links if not (ROOT / link).exists()]
    assert not missing, f"README links to missing files: {missing}"


def test_gitignore_protects_secrets_and_artifacts() -> None:
    text = (ROOT / ".gitignore").read_text()
    for pattern in (".env", "node_modules", "dist", "__pycache__", "*.db", "uploads"):
        assert pattern in text, f".gitignore does not cover {pattern}"


def test_alembic_migration_present_and_single_head() -> None:
    versions = sorted((ROOT / "backend" / "alembic" / "versions").glob("*.py"))
    assert versions, "no Alembic migration found"
    revisions: dict[str, str | None] = {}
    for path in versions:
        text = path.read_text()
        revision = re.search(r"^revision(?::\s*str)?\s*=\s*['\"]([^'\"]+)['\"]", text, re.M)
        down = re.search(r"^down_revision(?::[^=]*)?\s*=\s*(?:['\"]([^'\"]+)['\"]|None)", text, re.M)
        assert revision, f"{path.name} has no revision id"
        revisions[revision.group(1)] = down.group(1) if down and down.group(1) else None
    referenced = {value for value in revisions.values() if value}
    heads = [rev for rev in revisions if rev not in referenced]
    assert len(heads) == 1, f"expected exactly one migration head, found {heads}"
