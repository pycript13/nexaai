"""Front-end build contracts that only a real browser reveals.

Two defects found by driving the installed deployment in a headless browser (see
docs/TEST_REPORT.md):

1. `frontend/index.html` shipped an *inline* `<script>` that applied the stored theme and text
   direction before first paint, while every Nginx config sends `script-src 'self'` — the
   browser therefore blocked it and logged a CSP violation on every page load in production,
   silently losing the pre-paint theme/locale. The bootstrap now lives in its own file.
2. Every admin table was rendered with a fixed `min-width` grid, so on a 390 px phone the
   columns were squeezed until `https://inference.dahl.global/v1` wrapped mid-word. The shared
   `DataTable` now marks its cells with `data-label` and mobile.css re-stacks each row into a
   label/value card.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
FRONTEND = ROOT / "frontend"
NGINX = ROOT / "deployment" / "nginx"
INLINE_SCRIPT = re.compile(r"<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>", re.S)


def _inline_scripts(html: str) -> list[str]:
    return [body.strip() for body in INLINE_SCRIPT.findall(html) if body.strip()]


def test_index_html_has_no_inline_script() -> None:
    index = (FRONTEND / "index.html").read_text(encoding="utf-8")
    assert _inline_scripts(index) == [], "an inline <script> is blocked by the shipped script-src 'self' policy"


def test_index_html_boots_theme_from_a_served_file() -> None:
    index = (FRONTEND / "index.html").read_text(encoding="utf-8")
    assert '<script src="/theme-boot.js"></script>' in index
    # it must still run before the module bundle so there is no flash of the wrong theme
    assert index.index("/theme-boot.js") < index.index("type=\"module\"")


def test_theme_boot_file_applies_theme_and_direction() -> None:
    boot = (FRONTEND / "public" / "theme-boot.js").read_text(encoding="utf-8")
    assert "nexa.theme" in boot and "data-theme" in boot
    assert "nexa.locale" in boot and '"dir"' in boot.replace("'", '"')
    assert "fa" in boot and "ar" in boot  # RTL languages
    assert "catch" in boot  # storage can be blocked; the app still has to load


def test_built_bundle_would_have_no_inline_script() -> None:
    """The same rule applied to the actual build output, when one is present."""
    dist_index = FRONTEND / "dist" / "index.html"
    if not dist_index.exists():
        pytest.skip("frontend/dist is not built in this checkout")
    assert _inline_scripts(dist_index.read_text(encoding="utf-8")) == []
    assert (FRONTEND / "dist" / "theme-boot.js").exists(), "public/theme-boot.js must be copied into dist/"


@pytest.mark.parametrize("name", sorted(p.name for p in NGINX.glob("*.conf")))
def test_nginx_csp_stays_strict_about_scripts(name: str) -> None:
    text = (NGINX / name).read_text(encoding="utf-8")
    match = re.search(r"Content-Security-Policy \"([^\"]+)\"", text)
    assert match, f"{name} has no CSP header"
    csp = match.group(1)
    script_src = next((part for part in csp.split(";") if part.strip().startswith("script-src")), "")
    assert script_src, f"{name} has no script-src directive"
    assert "'unsafe-inline'" not in script_src, f"{name} re-enabled inline scripts instead of serving theme-boot.js"


def test_datatable_marks_cells_for_the_stacked_layout() -> None:
    ui = (FRONTEND / "src" / "components" / "ui.tsx").read_text(encoding="utf-8")
    assert "data-label={columnLabel(column)}" in ui
    assert "table table--stack" in ui and "table-wrap table-wrap--stack" in ui
    # a column without a textual header must not print an empty label box
    assert "columnLabel" in ui


def test_mobile_css_stacks_rows_into_cards() -> None:
    css = (FRONTEND / "src" / "styles" / "mobile.css").read_text(encoding="utf-8")
    assert "@media (max-width: 760px)" in css
    stacked = css[css.index(".table-wrap--stack") :]
    assert "content: attr(data-label)" in stacked
    assert "overflow-wrap: anywhere" in stacked
    # a header cell with no label keeps the full width (action buttons, for example)
    assert '.table--stack td:not([data-label])' in stacked


def test_every_rendered_table_uses_the_stack_class() -> None:
    """New tables must not silently reintroduce the squeezed grid."""
    offenders = []
    for path in sorted((FRONTEND / "src").rglob("*.tsx")):
        text = path.read_text(encoding="utf-8")
        for match in re.finditer(r'<table className="([^"]*)"', text):
            if "table--stack" not in match.group(1):
                offenders.append(f"{path.relative_to(FRONTEND)}: {match.group(1)}")
    assert offenders == [], f"tables missing the responsive stack class: {offenders}"
