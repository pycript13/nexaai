# Test suites outside the backend package

`backend/tests/` holds the pytest suite that runs the API in-process (128 tests: auth, RBAC,
providers, billing/ledger, files, chat, jobs, catalogue, money units, module persistence).

This directory holds the tests that need the *repository* or a *running server*:

| Path | What it proves | How to run |
| --- | --- | --- |
| `unit/test_repo_invariants.py` | money columns are integers, no committed secrets, all sources compile, the four locale dictionaries share one key set, admin routes are permission-guarded, no raw HTML injection in the SPA | `python -m pytest tests/unit -q` |
| `deployment/test_deployment_assets.py` | Compose files are valid and never publish PostgreSQL/Redis, every installer/unit/config/doc referenced by the project exists, shell scripts parse, `.env` templates carry no real secrets | `python -m pytest tests/deployment -q` |
| `integration/test_live_stack.py` | the full commercial path against a running API and a real HTTP upstream (39 checks) | see below |
| `e2e/test_ui_smoke.py` | the served SPA, its assets, security headers, API docs and the four languages | `python -m pytest tests/e2e -q` (needs a running server) |
| `tools/mock_openai_upstream.py` | a real OpenAI-compatible HTTP double used by the integration test | `python tests/tools/mock_openai_upstream.py --port 9099` |

## Running everything

```bash
# 1. repository-level checks (no server needed)
python -m pytest tests/unit tests/deployment -q

# 2. backend suite
cd backend && python -m pytest tests/ -q && cd ..

# 3. live stack: start the mock upstream, then the API, then the test
python tests/tools/mock_openai_upstream.py --port 9099 &
NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=true python -m uvicorn app.main:app --port 8000 &   # from backend/
python tests/integration/test_live_stack.py --base-url http://127.0.0.1:8000
python -m pytest tests/e2e -q
```

`tests/e2e` and `tests/integration` skip with a clear message when no server answers at
`NEXA_TEST_BASE_URL` (default `http://127.0.0.1:8000`).
