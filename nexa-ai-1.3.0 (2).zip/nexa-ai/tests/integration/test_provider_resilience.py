#!/usr/bin/env python3
"""Prove, against a *running* deployment, that a flapping provider no longer breaks chat.

This is the regression test for the defect report "the connection test succeeds but the model
is never called — provider_connectivity". It drives the real stack:

    start tests/tools/flaky_upstream.py --port 9098
      (its /v1/models always answers; the first streaming chat request gets a TCP reset)

    an administrator adds that provider -> the connection test is GREEN
    models are synchronized      -> hidden, unpublished, untested (as always)
    the model is published+priced, then verified by an administrator test
    a user chats with streaming -> the UI's path: the first attempt is reset, the automatic
                                   retry answers, and the ledger records the real charge

Finally the same provider is pointed at a dead port and the test asserts that the failure
now carries the endpoint, the exception and actionable hints — instead of the bare
``Provider connectivity failure:`` message it used to.

Usage
    python tests/tools/flaky_upstream.py --port 9098 &
    python tests/integration/test_provider_resilience.py \
        --base-url http://127.0.0.1:8080 --admin-password "<NEXA_BOOTSTRAP_ADMIN_PASSWORD>"
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import uuid

import httpx

def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Arguments are parsed inside main() only.

    Import-time parsing used to abort pytest collection for the whole repository
    (``error: unrecognized arguments: tests -q``) whenever anyone ran the suite.
    """
    parser = argparse.ArgumentParser(
        prog="test_provider_resilience",
        description="Live check that a flapping provider no longer breaks chat.",
    )
    parser.add_argument("--base-url", default=os.environ.get("NEXA_TEST_BASE_URL", "http://127.0.0.1:8080"))
    parser.add_argument("--admin-email", default=os.environ.get("NEXA_ADMIN_EMAIL", "admin@example.com"))
    parser.add_argument("--admin-password", default=os.environ.get("NEXA_ADMIN_PASSWORD", ""))
    parser.add_argument("--flaky-url", default="http://127.0.0.1:9098/v1")
    parser.add_argument("--dead-url", default="http://127.0.0.1:9097/v1", help="a port where nothing listens")
    parser.add_argument("--host-header", default="", help="Host header to send (needed behind a proxy that validates it)")
    parser.add_argument("--app-dir", default="/opt/nexa-ai", help="install directory, used for grant-credits")
    return parser.parse_args(argv)


# Defaults come from the environment so importing this module is side-effect free.
BASE = os.environ.get("NEXA_TEST_BASE_URL", "http://127.0.0.1:8080")
ADMIN_EMAIL = os.environ.get("NEXA_ADMIN_EMAIL", "admin@example.com")
ADMIN_PASSWORD = os.environ.get("NEXA_ADMIN_PASSWORD", "")
FLAKY_URL = "http://127.0.0.1:9098/v1"
DEAD_URL = "http://127.0.0.1:9097/v1"
HOST = ""
APP_DIR = "/opt/nexa-ai"


def _apply_args(args: argparse.Namespace) -> None:
    global BASE, ADMIN_EMAIL, ADMIN_PASSWORD, FLAKY_URL, DEAD_URL, HOST, APP_DIR
    BASE = args.base_url
    ADMIN_EMAIL = args.admin_email
    ADMIN_PASSWORD = args.admin_password or os.environ.get("NEXA_ADMIN_PASSWORD", "")
    FLAKY_URL = args.flaky_url
    DEAD_URL = args.dead_url
    HOST = args.host_header
    APP_DIR = args.app_dir
class Client:
    def __init__(self, headers: dict[str, str] | None = None) -> None:
        self.http = httpx.Client(base_url=BASE, timeout=60.0, follow_redirects=False, headers=headers or {})

    def login(self, email: str, password: str) -> None:
        response = self.http.post("/api/v1/auth/login", json={"email": email, "password": password})
        assert response.status_code < 400, f"login failed: {response.status_code} {response.text[:200]}"
        token = self.http.cookies.get("nexa_csrf") or response.cookies.get("nexa_csrf")
        if token:
            self.http.headers["X-CSRF-Token"] = token
        cookies = "; ".join(f"{k}={v}" for k, v in response.cookies.items())
        if cookies and "secure" in response.headers.get("set-cookie", "").lower():
            self.http.headers["Cookie"] = cookies

    def json(self, method: str, url: str, **kw) -> tuple[int, dict]:
        response = self.http.request(method, url, **kw)
        try:
            return response.status_code, response.json()
        except Exception:
            return response.status_code, {"_raw": response.text[:300]}


def main(argv: list[str] | None = None) -> int:
    _apply_args(parse_args(argv))
    if not ADMIN_PASSWORD:
        print("Provide --admin-password (or NEXA_ADMIN_PASSWORD)", file=sys.stderr)
        return 2
    client = Client({"Host": HOST} if HOST else None)
    client.login(ADMIN_EMAIL, ADMIN_PASSWORD)
    suffix = uuid.uuid4().hex[:8]

    # ---- 1. a provider whose /models works but whose first stream request is reset ------
    status, body = client.json("POST", "/api/v1/admin/providers", json={
        "name": f"Flaky upstream {suffix}",
        "provider_type": "openai_compatible",
        "base_url": FLAKY_URL,
        "api_key": "sk-flaky-key",
        "enabled": True,
        "max_retries": 2,
    })
    assert status == 201, f"provider create failed: {status} {body}"
    provider_id = body["provider"]["id"]

    status, test = client.json("POST", f"/api/v1/admin/providers/{provider_id}/test", json={})
    ok = (test.get("result") or test).get("ok")
    print(f"1) connection test against the flaky provider: {'GREEN' if ok else 'RED'} — {(test.get('result') or test).get('message')}")

    status, sync = client.json("POST", f"/api/v1/admin/providers/{provider_id}/sync", json={})
    assert status < 400, f"sync failed: {status} {sync}"
    models = client.json("GET", f"/api/v1/admin/models?provider_id={provider_id}")[1]["items"]
    model = next(m for m in models if m["provider_model_id"] == "flaky-chat")
    print(f"2) synchronized {len(models)} model(s); the model stays hidden/unpublished: visibility={model['visibility']} published={model['published']}")

    patch_status, patch_body = client.json("PATCH", f"/api/v1/admin/models/{model['id']}", json={
        "visibility": "public", "published": True, "enabled": True,
        "capabilities": ["chat", "streaming"],
        # real field names: a typo here is a 422 (unknown field) instead of a silently
        # unpublished/unpriced model, so the response must be checked
        "selling_input_per_mtok": 0.10, "selling_output_per_mtok": 0.10,
    })
    assert patch_status < 400, f"publish/pricing patch failed: {patch_status} {patch_body}"
    # a published model still has to be verified by an administrator before users may spend on it
    status, test_result = client.json("POST", f"/api/v1/admin/models/{model['id']}/test",
                                      json={"operation": "chat", "input": "ping", "max_tokens": 8})
    print(f"2b) administrator verification test: status={status} success={test_result.get('result', {}).get('success')} detail={str(test_result)[:160]}")

    # give the administrator credit so the chat can be charged (best effort: a deployment may
    # already have credit, and an operator may prefer to top up in the UI). `--app-dir` points
    # at the real install; when it is absent (e.g. running against a checkout) the step is
    # skipped instead of crashing the whole test.
    app_backend = os.path.join(APP_DIR, "backend")
    if os.path.isdir(app_backend):
        python_bin = os.environ.get("NEXA_PYTHON") or os.path.join(APP_DIR, "venv", "bin", "python")
        command = [python_bin, "-m", "app.cli", "grant-credits",
                   "--email", ADMIN_EMAIL, "--credits", "5", "--reason", "flaky-transport verification"]
        if os.geteuid() == 0 and shutil.which("sudo"):
            command = ["sudo", "-u", "nexa"] + command
        try:
            subprocess.run(command, cwd=app_backend, check=False, capture_output=True, timeout=120)
        except (OSError, subprocess.SubprocessError) as exc:  # pragma: no cover - operator environment
            print(f"   (grant-credits skipped: {exc})")
    else:
        print(f"   (grant-credits skipped: {app_backend} does not exist)")

    # ---- 2. the streamed chat, exactly as the UI performs it ---------------------------
    del client.http.headers["X-CSRF-Token"]
    csrf = client.http.cookies.get("nexa_csrf")
    if csrf:
        client.http.headers["X-CSRF-Token"] = csrf

    with client.http.stream("POST", "/api/v1/chat/stream", json={
        "model_id": model["id"], "message": "hello after the reset", "stream": True,
    }) as response:
        events: list[str] = []
        error_payload: dict | None = None
        text = ""
        for line in response.iter_lines():
            if line.startswith("event:"):
                events.append(line.split(":", 1)[1].strip())
            elif line.startswith("data:"):
                payload = json.loads(line[5:].strip() or "{}")
                if payload.get("text"):
                    text += payload["text"]
                if payload.get("category"):
                    error_payload = payload
    print(f"3) streamed chat through the flapping provider: events={events} text={text[:80]!r}")
    if error_payload:
        print(f"   ERROR -> {error_payload.get('category')}: {error_payload.get('message')}")
    ok_chat = "done" in events and bool(text) and error_payload is None
    print(f"   => {'RECOVERED (the retry saved the chat)' if ok_chat else 'STILL FAILING'}")

    # ---- 3. now point the same provider at a dead port: the diagnosis must be complete --
    client.json("PATCH", f"/api/v1/admin/providers/{provider_id}", json={"base_url": DEAD_URL})
    with client.http.stream("POST", "/api/v1/chat/stream", json={
        "model_id": model["id"], "message": "this must fail with a full diagnosis", "stream": True,
    }) as response:
        for line in response.iter_lines():
            if line.startswith("data:"):
                payload = json.loads(line[5:].strip() or "{}")
                if payload.get("category"):
                    print(f"4) unreachable provider -> category={payload['category']}")
                    print(f"   message: {payload.get('message')}")
                    print(f"   hints  : {payload.get('hints')}")
    return 0 if ok_chat else 1


if __name__ == "__main__":
    sys.exit(main())


if __name__ == "__main__":
    raise SystemExit(main())
