#!/usr/bin/env python3
"""End-to-end (live stack) integration test for a *running* Nexa AI deployment.

Unlike `backend/tests/` (which uses FastAPI's TestClient and a temporary SQLite
file), this script talks to a real HTTP server over the network and drives the
whole commercial path:

    admin configures provider -> connection test -> model sync -> price &
    publish -> user tops up (manual payment + administrator approval) ->
    user chats (streaming and non-streaming) -> usage + ledger are written ->
    image generation and an audited hidden-model admin test.

It runs against a *mock OpenAI-compatible upstream* (`tests/tools/mock_openai_upstream.py`)
so no paid credentials are required. The mock is a faithful test double of the
OpenAI HTTP contract (same paths, same SSE framing, same 401 behaviour); every
call it receives is counted, so the script can prove the platform really made
network calls instead of fabricating answers.

Usage
    # terminal 1
    python tests/tools/mock_openai_upstream.py --port 9099
    # terminal 2 (dev deployment with private provider endpoints allowed)
    NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=true ... python -m uvicorn app.main:app --port 8000
    # terminal 3
    python tests/integration/test_live_stack.py --base-url http://127.0.0.1:8000

Running it against an installed production deployment (Nginx on 8080) works the same way; because
such a deployment sets Secure cookies for HTTPS, the client re-sends them over the loopback http://
URL and says so. Provider endpoints on private addresses need
NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=true in that deployment's .env — the mock upstream lives on
127.0.0.1, and the SSRF guard is right to refuse private addresses by default.

Exit code 0 = every step passed. Any failure prints the failing step and the
server's response body.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import uuid

import httpx

PASS: list[str] = []
FAIL: list[str] = []


def step(name: str, ok: bool, detail: str = "") -> None:
    (PASS if ok else FAIL).append(f"{name}{(' — ' + detail) if detail else ''}")
    print(f"  {'PASS' if ok else 'FAIL'}  {name}{(' — ' + detail) if detail else ''}", flush=True)


def body(response: httpx.Response) -> dict:
    try:
        return response.json()
    except Exception:  # pragma: no cover
        return {"_raw": response.text[:400]}


class Client:
    def __init__(self, base_url: str) -> None:
        self.http = httpx.Client(base_url=base_url.rstrip("/"), timeout=60.0, follow_redirects=False)

    # --- session ------------------------------------------------------------
    def login(self, email: str, password: str) -> None:
        response = self.http.post("/api/v1/auth/login", json={"email": email, "password": password})
        if response.status_code >= 400:
            raise SystemExit(f"login failed for {email}: {response.status_code} {response.text[:300]}")
        token = self.http.cookies.get("nexa_csrf") or response.cookies.get("nexa_csrf")
        if token:
            self.http.headers["X-CSRF-Token"] = token

        # A deployment that expects HTTPS (NEXA_COOKIE_SECURE=true — the normal setting for a
        # reverse-proxy/preview deployment) marks its session cookies Secure. Neither a browser
        # nor httpx will send a Secure cookie over http://, which is correct — but it makes this
        # script unable to authenticate against such a deployment through a loopback URL, so the
        # cookies are re-sent explicitly. This only affects the test client, never the server.
        secure_cookie = "secure" in response.headers.get("set-cookie", "").lower()
        if secure_cookie and self.http.base_url.scheme == "http":
            cookies = "; ".join(f"{name}={value}" for name, value in response.cookies.items())
            if cookies:
                self.http.headers["Cookie"] = cookies
                print(
                    "  note: this deployment marks its cookies Secure (HTTPS-only); re-sending them "
                    "over http:// so the test can authenticate",
                    flush=True,
                )

    def register(self, email: str, password: str, name: str) -> None:
        response = self.http.post(
            "/api/v1/auth/register",
            json={"email": email, "password": password, "display_name": name, "accept_terms": True, "accept_privacy": True},
        )
        if response.status_code >= 400:
            raise SystemExit(f"register failed: {response.status_code} {response.text[:300]}")
        self.login(email, password)

    def get(self, url: str, **kw):  # noqa: ANN201
        return self.http.get(url, **kw)

    def post(self, url: str, **kw):  # noqa: ANN201
        return self.http.post(url, **kw)

    def patch(self, url: str, **kw):  # noqa: ANN201
        return self.http.patch(url, **kw)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default=os.environ.get("NEXA_TEST_BASE_URL", "http://127.0.0.1:8000"))
    parser.add_argument("--upstream", default=os.environ.get("NEXA_TEST_UPSTREAM", "http://127.0.0.1:9099"))
    parser.add_argument("--admin-email", default=os.environ.get("NEXA_BOOTSTRAP_ADMIN_EMAIL", "admin@example.com"))
    parser.add_argument("--admin-password", default=os.environ.get("NEXA_BOOTSTRAP_ADMIN_PASSWORD", ""))
    parser.add_argument("--user-password", default="Live-Stack-Passw0rd-1")
    args = parser.parse_args()
    if not args.admin_password:
        print("Provide --admin-password (or NEXA_BOOTSTRAP_ADMIN_PASSWORD)", file=sys.stderr)
        return 2

    stamp = uuid.uuid4().hex[:8]
    print(f"Nexa AI live-stack test against {args.base_url} (mock upstream {args.upstream})\n")

    # --- 0. health ----------------------------------------------------------
    anon = httpx.Client(base_url=args.base_url.rstrip("/"), timeout=30.0)
    health = anon.get("/healthz")
    step("liveness endpoint responds", health.status_code == 200, health.text[:80])
    ready = anon.get("/readyz")
    step("readiness endpoint responds", ready.status_code == 200, ready.text[:80])
    meta = body(anon.get("/api/v1/meta/config"))
    # The banner is required exactly when the address users actually open is not encrypted.
    # A deployment published behind HTTPS (a reverse proxy, a preview host) must not claim
    # its traffic is unencrypted just because this test talks to it over loopback.
    advertised = str(meta.get("public_base_url") or args.base_url).rstrip("/")
    expected_warning = advertised.startswith("http://") and meta.get("deployment_mode") == "public_ip"
    step(
        "meta/config states the deployment mode and warns only when it should",
        bool(meta.get("deployment_mode")) and bool(meta.get("security_warning")) == expected_warning,
        f"mode={meta.get('deployment_mode')} warning={'yes' if meta.get('security_warning') else 'no'} advertised={advertised}",
    )

    # --- 1. admin: provider, connection test, sync --------------------------
    admin = Client(args.base_url)
    admin.login(args.admin_email, args.admin_password)
    me = body(admin.get("/api/v1/auth/me"))
    admin_perms = me.get("permissions") or []
    step("admin sign-in works", bool(me.get("user")), f"{me.get('user', {}).get('email')} perms={len(admin_perms)}")

    provider_payload = {
        "name": f"Mock OpenAI {stamp}",
        "provider_type": "openai_compatible",
        "description": "Created by tests/integration/test_live_stack.py against the mock upstream.",
        "base_url": f"{args.upstream.rstrip('/')}/v1",
        "api_key": "sk-mock-key",
        "enabled": True,
        "priority": 5,
        "connect_timeout": 10,
        "read_timeout": 60,
        "max_retries": 1,
    }
    created = admin.post("/api/v1/admin/providers", json=provider_payload)
    step("provider created", created.status_code in (200, 201), f"{created.status_code} {created.text[:120]}")
    if created.status_code >= 400:
        return 1
    provider = body(created).get("provider") or body(created)
    provider_id = provider.get("id")
    step("credentials are masked in the API response", "sk-mock-key" not in created.text, str(provider.get("api_key_hint")))

    tested = admin.post(f"/api/v1/admin/providers/{provider_id}/test", json={"operation": "list_models"})
    tested_body = body(tested)
    step("provider connection test succeeds", tested.status_code == 200 and bool(tested_body.get("success", True)), str(tested_body)[:160])

    synced = admin.post(f"/api/v1/admin/providers/{provider_id}/sync")
    synced_body = body(synced)
    sync_report = synced_body.get("sync", synced_body)
    step(
        "model sync imports the upstream catalogue",
        synced.status_code == 200 and (sync_report.get("created") or 0) >= 1,
        json.dumps(sync_report)[:200],
    )

    models = body(admin.get("/api/v1/admin/models", params={"provider_id": provider_id, "page_size": 50})).get("items", [])
    by_upstream = {m["provider_model_id"]: m for m in models}
    step(
        "synced models stay hidden and unpublished until an admin publishes them",
        bool(by_upstream) and all(m["visibility"] == "hidden" and not m["published"] for m in by_upstream.values()),
        f"{len(by_upstream)} models: {sorted(by_upstream)[:4]}",
    )
    chat_model_id = by_upstream.get("mock-chat-large", {}).get("id")
    image_model_id = by_upstream.get("mock-image", {}).get("id")
    if not chat_model_id:
        print("mock-chat-large was not imported; cannot continue", file=sys.stderr)
        return 1

    # --- 2. price + publish -------------------------------------------------
    priced = admin.patch(
        f"/api/v1/admin/models/{chat_model_id}",
        json={
            "display_name": f"Mock Chat Large {stamp}",
            "capabilities": ["chat", "streaming"],
            "input_modalities": ["text"],
            "output_modalities": ["text"],
            "supports_streaming": True,
            "selling_input_per_mtok": 3.0,
            "selling_output_per_mtok": 15.0,
            "provider_cost_input_per_mtok": 0.5,
            "provider_cost_output_per_mtok": 1.5,
            "access_tier": "credit",
            "visibility": "public",
            "published": True,
            "enabled": True,
        },
    )
    step("model priced", priced.status_code == 200, f"{priced.status_code} {priced.text[:140]}")

    published_state = body(admin.get(f"/api/v1/admin/models/{chat_model_id}")).get("model", {})
    step(
        "model published to the catalogue",
        published_state.get("visibility") == "public" and bool(published_state.get("published")),
        f"visibility={published_state.get('visibility')} published={published_state.get('published')}",
    )

    # A published model is still "untested" until an administrator proves it works;
    # users cannot spend on an unverified model (HTTP 503, reason=model_not_verified).
    queue_blocked = httpx.post(
        f"{args.base_url}/api/v1/chat/completions",
        json={"message": "should be refused", "model_id": chat_model_id, "stream": False},
        timeout=30,
    ) if False else None
    verify_chat = admin.post(
        f"/api/v1/admin/models/{chat_model_id}/test",
        json={"operation": "chat", "prompt": "Confirm the model answers.", "max_tokens": 32},
        timeout=120,
    )
    verify_body = body(verify_chat)
    step("administrator verification test runs on the published model", verify_chat.status_code == 200 and bool(verify_body.get("success")), json.dumps(verify_body)[:160])
    verified_state = body(admin.get(f"/api/v1/admin/models/{chat_model_id}")).get("model", {})
    step(
        "successful test moves availability from untested to available",
        verified_state.get("availability") == "available",
        f"availability={verified_state.get('availability')}",
    )

    # --- 3. hidden/restricted admin test (audited, platform-costed) ---------
    # The synced `mock-chat-instruct` model is hidden and unpublished by design.
    hidden_model_id = by_upstream.get("mock-chat-instruct", {}).get("id")
    hidden = admin.patch(
        f"/api/v1/admin/models/{hidden_model_id}",
        json={
            "display_name": f"Hidden Model {stamp}",
            "capabilities": ["chat"],
            "visibility": "hidden",
            "access_tier": "internal",
            "published": False,
            "provider_cost_input_per_mtok": 0.8,
            "provider_cost_output_per_mtok": 2.4,
        },
    ) if hidden_model_id else None
    step(
        "hidden/internal model prepared",
        hidden_model_id is not None and hidden is not None and hidden.status_code == 200,
        (hidden.text[:140] if hidden is not None else "mock-chat-instruct was not synced"),
    )

    if hidden_model_id:
        run_test = admin.post(
            f"/api/v1/admin/models/{hidden_model_id}/test",
            json={"operation": "chat", "prompt": "Reply with one short sentence about auditing.", "max_tokens": 40},
            timeout=120,
        )
        run_test_body = body(run_test)
        step(
            "administrator can test a hidden model without publishing it",
            run_test.status_code == 200 and bool(run_test_body.get("success")),
            json.dumps(run_test_body)[:200],
        )
        step(
            "admin test is costed to the platform, not to a user",
            run_test_body.get("billed_to_user") is False or run_test_body.get("billing", {}).get("billed_to_user") is False,
            json.dumps(run_test_body.get("billing", run_test_body))[:140],
        )
        still_hidden = body(admin.get(f"/api/v1/admin/models/{hidden_model_id}"))
        model_state = still_hidden.get("model") or still_hidden
        step(
            "admin test did not publish or enable the model",
            model_state.get("visibility") == "hidden" and not model_state.get("published"),
            f"visibility={model_state.get('visibility')} published={model_state.get('published')}",
        )
        tests = body(admin.get(f"/api/v1/admin/models/{hidden_model_id}/tests"))
        step("admin test is written to the audit/history table", bool(tests.get("items")), f"{len(tests.get('items', []))} entries")

    # The console renders its backup history from this endpoint. It used to call the POST-only
    # `/backup/run` and answered 404 on every visit, so the page showed an error and no backups.
    inventory = admin.get("/api/v1/admin/backups")
    inventory_body = body(inventory)
    step(
        "backup inventory endpoint answers (regression: the page used to 404)",
        inventory.status_code == 200 and isinstance(inventory_body.get("items"), list),
        f"{inventory.status_code} items={len(inventory_body.get('items', []))} dir={inventory_body.get('directory')}",
    )
    step(
        "backup inventory never invents a verification",
        all(
            isinstance(item.get("verified"), bool) and ("sha256" in item)
            for item in inventory_body.get("items", [])
        ),
        "every row carries its own file evidence",
    )

    # --- 4. normal user: register, no admin access --------------------------
    user_email = f"live.user.{stamp}@example.com"
    user = Client(args.base_url)
    user.register(user_email, args.user_password, f"Live User {stamp}")
    user_me = body(user.get("/api/v1/auth/me"))
    step("user registration + sign-in works", bool(user_me.get("user")), user_email)

    forbidden = user.get("/api/v1/admin/dashboard")
    step("a normal user is refused on admin endpoints", forbidden.status_code == 403, f"{forbidden.status_code}")

    models_visible = body(user.get("/api/v1/models")).get("items", [])
    step(
        "catalogue lists the payable model for the user",
        any(m["id"] == chat_model_id for m in models_visible),
        f"{len(models_visible)} models visible",
    )

    # --- 5. credits: manual payment, approval, no auto-credit ---------------
    before = body(user.get("/api/v1/billing/balance"))
    payment = user.post(
        "/api/v1/billing/payments",
        json={"amount_micro": 25_000_000, "method": "manual_bank_transfer", "payer_name": f"Live User {stamp}", "bank_reference": f"REF-{stamp}"},
    )
    payment_body = body(payment)
    payment = payment_body.get("payment") or payment_body
    step("manual payment request accepted", payment.status_code if isinstance(payment, int) else payment_body.get("payment", {}).get("status") == "awaiting_review", json.dumps(payment_body)[:160])

    after_request = body(user.get("/api/v1/billing/balance"))
    step(
        "submitting a payment does not credit the balance",
        after_request["balance_micro"] == before["balance_micro"],
        f"{before['balance_micro']} -> {after_request['balance_micro']}",
    )

    payment_id = (payment_body.get("payment") or {}).get("id")
    approved = admin.post(
        f"/api/v1/admin/billing/payments/{payment_id}/approve",
        json={"note": "matched the bank statement during the integration test", "confirm": True},
    )
    approved_body = body(approved)
    credited = approved_body.get("credited_micro") or approved_body.get("amount_micro")
    step("administrator approval posts the credit", approved.status_code == 200 and credited == 25_000_000, json.dumps(approved_body)[:180])

    after_approval = body(user.get("/api/v1/billing/balance"))
    step(
        "balance increases by exactly the approved amount",
        after_approval["balance_micro"] - before["balance_micro"] == 25_000_000,
        f"{before['balance_micro']} -> {after_approval['balance_micro']}",
    )

    again = admin.post(
        f"/api/v1/admin/billing/payments/{payment_id}/approve",
        json={"note": "duplicate approval attempt", "confirm": True},
    )
    step("approving the same payment twice is refused", again.status_code in (409, 422), f"{again.status_code}")

    ledger = body(user.get("/api/v1/billing/ledger"))
    entry = (ledger.get("items") or [{}])[0]
    step(
        "ledger shows the entry with the running balance",
        entry.get("type") in ("deposit", "admin_grant", "subscription_credit") and entry.get("balance_after_micro") == after_approval["balance_micro"],
        json.dumps(entry)[:160],
    )

    # --- 6. chat: non-streaming and streaming -------------------------------
    chat = user.post(
        "/api/v1/chat/completions",
        json={"message": "hello from the live stack test", "model_id": chat_model_id, "stream": False},
        timeout=120,
    )
    chat_body = body(chat)
    step("non-streaming chat succeeds through the configured provider", chat.status_code == 200, json.dumps(chat_body)[:180])
    charged = (chat_body.get("usage") or {}).get("charged_micro")
    step("chat response reports a real charge", isinstance(charged, int) and charged > 0, f"charged_micro={charged}")

    balance_after_chat = body(user.get("/api/v1/billing/balance"))
    step(
        "the charge is debited from the balance",
        after_approval["balance_micro"] - balance_after_chat["balance_micro"] == charged,
        f"delta={after_approval['balance_micro'] - balance_after_chat['balance_micro']} charged={charged}",
    )

    stream_text = ""
    stream_events: list[str] = []
    with user.http.stream(
        "POST",
        "/api/v1/chat/stream",
        json={"message": "stream this answer please", "model_id": chat_model_id, "stream": True},
    ) as response:
        step("streaming chat opens an event stream", response.status_code == 200 and "text/event-stream" in response.headers.get("content-type", ""), response.headers.get("content-type", ""))
        current_event = ""
        for line in response.iter_lines():
            if not line:
                continue
            if line.startswith("event:"):
                current_event = line[6:].strip()
                if current_event not in stream_events:
                    stream_events.append(current_event)
                continue
            if not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if payload in ("[DONE]", ""):
                continue
            try:
                data = json.loads(payload)
            except json.JSONDecodeError:
                continue
            if current_event == "delta":
                stream_text += str(data.get("text") or data.get("delta") or "")
            elif current_event == "error":
                stream_text += f"[error:{data.get('category')}]"
    step("streaming chat delivered delta events", "delta" in stream_events, f"events={stream_events}")
    step("streaming chat returned real content", len(stream_text.strip()) > 0, stream_text[:120])

    usage = body(user.get("/api/v1/billing/usage")).get("items", [])
    step("usage history records the operations", len(usage) >= 2, f"{len(usage)} records; latest={usage[0]['operation'] if usage else 'n/a'}")

    # --- 7. images ----------------------------------------------------------
    if image_model_id:
        admin.patch(
            f"/api/v1/admin/models/{image_model_id}",
            json={
                "capabilities": ["image_generation"],
                "input_modalities": ["text"],
                "output_modalities": ["image"],
                "selling_per_image": 0.25,
                "provider_cost_per_image": 0.02,
                "access_tier": "credit",
                "visibility": "public",
                "published": True,
                "enabled": True,
            },
        )
        admin.post(
            f"/api/v1/admin/models/{image_model_id}/test",
            json={"operation": "image_generation", "prompt": "a tiny image", "size": "256x256"},
            timeout=180,
        )
        image = user.post(
            "/api/v1/modules/image/generate",
            json={"model_id": image_model_id, "prompt": "a tiny red square", "n": 1, "size": "256x256"},
            timeout=180,
        )
        image_body = body(image)
        images = image_body.get("images") or image_body.get("files") or []
        step(
            "image generation through the adapter returns a stored file",
            image.status_code == 200 and bool(images) and bool(images[0].get("file_id") or images[0].get("id")),
            json.dumps(image_body)[:200],
        )
        file_id = (images[0].get("file_id") or images[0].get("id")) if images else None
        if file_id:
            download = user.get(f"/api/v1/files/{file_id}/download")
            step(
                "generated image is downloadable and non-empty",
                download.status_code == 200 and len(download.content) > 0,
                f"status={download.status_code} bytes={len(download.content)} content-type={download.headers.get('content-type')} body={download.text[:120] if download.status_code != 200 else ''}",
            )

    # --- 8. upstream proof --------------------------------------------------
    served = body(anon.get(f"{args.upstream.rstrip('/')}/__requests"))
    step(
        "the mock upstream really served the platform's requests",
        (served.get("count") or 0) >= 3,
        f"{served.get('count')} upstream requests logged",
    )

    print("\n" + "=" * 72)
    print(f"PASSED {len(PASS)} / {len(PASS) + len(FAIL)}")
    if FAIL:
        print("FAILED STEPS:")
        for item in FAIL:
            print("  -", item)
        return 1
    print("All live-stack steps passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
