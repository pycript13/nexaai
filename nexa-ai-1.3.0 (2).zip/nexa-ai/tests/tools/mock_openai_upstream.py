#!/usr/bin/env python3
"""A minimal OpenAI-compatible upstream used by the live-stack integration test.

It is a *test double* for an OpenAI-shaped HTTP API: the Nexa AI platform talks to
it exactly as it would talk to api.openai.com (same paths, same streaming format),
which lets the integration test prove the real request/usage/billing path without
needing a paid provider account.

Endpoints
    GET  /v1/models                      -> model list (used by provider sync)
    POST /v1/chat/completions            -> text completion (streaming + non streaming)
    POST /v1/images/generations          -> returns a tiny PNG as b64_json
    POST /v1/audio/transcriptions        -> literal transcript of the received bytes
    POST /v1/audio/speech                -> returns a short WAV file
    GET  /__requests                     -> the requests this double has served

Auth: requires `Authorization: Bearer <key>` and rejects wrong keys with 401 so the
platform's error taxonomy (authentication vs rate_limit vs timeout) can be exercised.

Run:  python tests/tools/mock_openai_upstream.py --port 9099 --api-key sk-mock-key
"""
from __future__ import annotations

import argparse
import base64
import json
import struct
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

SERVED: list[dict] = []

TINY_PNG = base64.b64encode(
    bytes.fromhex(
        "89504e470d0a1a0a0000000d4948445200000001000000010806000000"
        "1f15c4890000000a49444154789c63000100000500010d0a2db4000000"
        "0049454e44ae426082"
    )
).decode()


def tiny_wav(payload: bytes = b"") -> bytes:
    sample_rate, seconds = 8000, 1
    frames = b"\x00\x00" * (sample_rate * seconds)
    header = b"RIFF" + struct.pack("<I", 36 + len(frames)) + b"WAVEfmt " + struct.pack(
        "<IHHIIHH", 16, 1, 1, sample_rate, sample_rate * 2, 2, 16
    ) + b"data" + struct.pack("<I", len(frames))
    return header + frames


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "MockOpenAI/1.0"

    api_key = "sk-mock-key"
    latency = 0.0

    # -- helpers ------------------------------------------------------------
    def _json(self, code: int, payload: dict) -> None:
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _bytes(self, code: int, body: bytes, content_type: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _authorised(self) -> bool:
        header = self.headers.get("Authorization", "")
        return header == f"Bearer {self.api_key}"

    def _read_body(self) -> bytes:
        length = int(self.headers.get("Content-Length") or 0)
        return self.rfile.read(length) if length else b""

    def log_message(self, fmt, *args):  # keep the console quiet
        return

    # -- routes -------------------------------------------------------------
    def do_GET(self):  # noqa: N802
        SERVED.append({"method": "GET", "path": self.path, "at": time.time()})
        if self.path.startswith("/v1/models"):
            if not self._authorised():
                return self._json(401, {"error": {"message": "invalid api key", "type": "invalid_request_error"}})
            return self._json(
                200,
                {
                    "object": "list",
                    "data": [
                        {"id": "mock-chat-large", "object": "model", "created": 1700000000, "owned_by": "mock"},
                        {"id": "mock-chat-instruct", "object": "model", "created": 1700000000, "owned_by": "mock"},
                        {"id": "mock-embedding", "object": "model", "created": 1700000000, "owned_by": "mock"},
                        {"id": "mock-image", "object": "model", "created": 1700000000, "owned_by": "mock"},
                        {"id": "mock-whisper", "object": "model", "created": 1700000000, "owned_by": "mock"},
                        {"id": "mock-tts", "object": "model", "created": 1700000000, "owned_by": "mock"},
                    ],
                },
            )
        if self.path.startswith("/__requests"):
            return self._json(200, {"count": len(SERVED), "requests": SERVED[-50:]})
        return self._json(404, {"error": {"message": f"no route {self.path}"}})

    def do_POST(self):  # noqa: N802
        raw = self._read_body()
        try:
            payload = json.loads(raw or b"{}")
        except json.JSONDecodeError:
            payload = {}
        # The body is recorded so integration tests can assert what the platform really
        # sent upstream (e.g. a sub-model's system prompt). Headers — and therefore the
        # Authorization token — are deliberately never stored.
        try:
            parsed = json.loads(raw or b"{}")
        except ValueError:
            parsed = {"_raw_bytes": len(raw)}
        SERVED.append({"method": "POST", "path": self.path, "at": time.time(), "bytes": len(raw), "body": parsed})

        if not self._authorised():
            return self._json(401, {"error": {"message": "invalid api key", "type": "invalid_request_error"}})

        if Handler.latency:
            time.sleep(Handler.latency)

        if self.path.endswith("/chat/completions"):
            return self._chat(payload)
        if self.path.endswith("/images/generations"):
            return self._image(payload)
        if self.path.endswith("/audio/transcriptions"):
            return self._transcribe(raw)
        if self.path.endswith("/audio/speech"):
            return self._speech(payload)
        if self.path.endswith("/embeddings"):
            return self._embeddings(payload)
        if self.path.endswith("/rerank"):
            return self._json(200, {"results": [{"index": 0, "relevance_score": 0.9}]})
        return self._json(404, {"error": {"message": f"no route {self.path}"}})

    # -- individual operations ---------------------------------------------
    def _chat(self, payload: dict):
        messages = payload.get("messages") or []
        last = ""
        for message in reversed(messages):
            content = message.get("content")
            if isinstance(content, str):
                last = content
                break
            if isinstance(content, list):
                last = " ".join(part.get("text", "") for part in content if isinstance(part, dict))
                break
        prompt_tokens = max(1, len(last) // 4)
        completion = f"mock-answer: {last[:400]}"
        completion_tokens = max(1, len(completion) // 4)
        model = payload.get("model", "mock-chat-large")
        created = int(time.time())

        if payload.get("stream"):
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "close")
            self.end_headers()
            words = completion.split(" ")
            for index, word in enumerate(words):
                chunk = {
                    "id": "chatcmpl-mock",
                    "object": "chat.completion.chunk",
                    "created": created,
                    "model": model,
                    "choices": [{"index": 0, "delta": {"content": (word if index == 0 else " " + word)}, "finish_reason": None}],
                }
                self.wfile.write(f"data: {json.dumps(chunk)}\n\n".encode())
                self.wfile.flush()
            final = {
                "id": "chatcmpl-mock",
                "object": "chat.completion.chunk",
                "created": created,
                "model": model,
                "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
                "usage": {"prompt_tokens": prompt_tokens, "completion_tokens": completion_tokens, "total_tokens": prompt_tokens + completion_tokens},
            }
            self.wfile.write(f"data: {json.dumps(final)}\n\n".encode())
            self.wfile.write(b"data: [DONE]\n\n")
            self.wfile.flush()
            self.close_connection = True
            return

        return self._json(
            200,
            {
                "id": "chatcmpl-mock",
                "object": "chat.completion",
                "created": created,
                "model": model,
                "choices": [{"index": 0, "message": {"role": "assistant", "content": completion}, "finish_reason": "stop"}],
                "usage": {"prompt_tokens": prompt_tokens, "completion_tokens": completion_tokens, "total_tokens": prompt_tokens + completion_tokens},
            },
        )

    def _image(self, payload: dict):
        count = int(payload.get("n") or 1)
        return self._json(200, {"created": int(time.time()), "data": [{"b64_json": TINY_PNG, "revised_prompt": payload.get("prompt", "")} for _ in range(count)]})

    def _transcribe(self, raw: bytes):
        return self._json(200, {"text": "mock transcript of the uploaded audio", "duration": 3.0, "language": "en", "segments": [{"start": 0.0, "end": 3.0, "text": "mock transcript"}]})

    def _speech(self, payload: dict):
        return self._bytes(200, tiny_wav(payload.get("input", "").encode()), "audio/wav")

    def _embeddings(self, payload: dict):
        text = payload.get("input")
        items = text if isinstance(text, list) else [text or ""]
        return self._json(200, {"object": "list", "data": [{"object": "embedding", "index": i, "embedding": [0.01] * 8} for i, _ in enumerate(items)], "model": payload.get("model", "mock-embedding"), "usage": {"prompt_tokens": 5, "total_tokens": 5}})


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=9099)
    parser.add_argument("--api-key", default="sk-mock-key")
    parser.add_argument("--latency", type=float, default=0.0)
    args = parser.parse_args()
    Handler.api_key = args.api_key
    Handler.latency = args.latency
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"mock OpenAI-compatible upstream listening on http://{args.host}:{args.port} (key={args.api_key[:6]}…)", flush=True)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
