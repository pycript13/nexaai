"""End-to-end proof for sub-models (variants): create -> chat -> inspect the upstream.

Runs against the live preview stack, so every step uses the real HTTP API and the real
mock provider upstream. Nothing here stubs the platform.
"""
import json
import sys
import urllib.request
from http.cookiejar import CookieJar

BASE = "http://127.0.0.1:8081"
UPSTREAM = "http://127.0.0.1:9099"
EMAIL = "admin@example.com"
PASSWORD = "Nexa-Preview-Admin-2026!"

jar = CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))


def call(method, path, payload=None, base=BASE):
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(base + path, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    csrf = next((c.value for c in jar if c.name == "nexa_csrf"), None)
    if csrf:
        req.add_header("X-CSRF-Token", csrf)
    try:
        with opener.open(req, timeout=30) as response:
            raw = response.read()
            return response.status, (json.loads(raw) if raw else None)
    except urllib.error.HTTPError as error:  # expected for refusals — return the payload
        raw = error.read()
        return error.code, (json.loads(raw) if raw else None)


status, body = call("POST", "/api/v1/auth/login", {"email": EMAIL, "password": PASSWORD})
print("1. login                    ->", status)
assert status == 200, body

status, catalog = call("GET", "/api/v1/models?page_size=50")
model = next((m for m in catalog["items"] if "chat" in (m.get("capabilities") or [])), None)
assert model, "no chat-capable model"
print(f"2. model                    -> {model['id']} {model['display_name']} ({model['provider_model_id']})")

PROMPT = "VARIANT-MARKER-7788: reply only with the word CODE."
status, created = call("POST", f"/api/v1/models/{model['id']}/variants", {
    "name": "Code writer (e2e)",
    "emoji": "🧪",
    "system_prompt": PROMPT,
    "default_temperature": 0.1,
    "default_max_tokens": 64,
    "scope": "system",
})
assert status == 201, created
variant = created["variant"] if "variant" in created else created
vid = variant["id"]
print(f"3. create sub-model         -> id={vid} slug={variant['slug']} enabled={variant['enabled']}")

status, listed = call("GET", f"/api/v1/models/{model['id']}/variants")
print("4. list sub-models          ->", status, [v["name"] for v in listed["items"]])

status, chat = call("POST", "/api/v1/chat/completions", {
    "model_id": model["id"], "message": "hello", "variant_id": vid,
})
print("5. chat with sub-model      ->", status, "charged_micro=", (chat or {}).get("usage", {}).get("charged_micro"))

with urllib.request.urlopen(UPSTREAM + "/__requests", timeout=15) as response:
    served = json.loads(response.read())["requests"]
chat_requests = [r for r in served if str(r.get("path", "")).endswith("/chat/completions")]
last = chat_requests[-1]
blob = json.dumps(last)
print("6. upstream saw prompt      ->", PROMPT in blob)
print("   temperature sent         ->", last.get("body", {}).get("temperature"))
assert PROMPT in blob, "the variant system prompt never reached the provider"
assert (last.get("body") or {}).get("temperature") == 0.1, "variant sampling default not applied"

status, toggled = call("POST", f"/api/v1/models/variants/{vid}/toggle")
print("7. switch off               ->", status, "enabled=", toggled.get("enabled"))
status, refused = call("POST", "/api/v1/chat/completions", {"model_id": model["id"], "message": "hi", "variant_id": vid})
print("8. disabled variant refused ->", status, (refused or {}).get("error", {}).get("code"))

call("POST", f"/api/v1/models/variants/{vid}/toggle")
status, admin_list = call("GET", "/api/v1/admin/model-variants")
print("9. admin monitoring         ->", status, "total=", admin_list["total"])
entry = next(v for v in admin_list["items"] if v["id"] == vid)
print("   usage counted            ->", entry["usage_count"])

status, admin_toggle = call("PATCH", f"/api/v1/admin/model-variants/{vid}", {"enabled": False})
print("10. admin switch            ->", status, "enabled=", admin_toggle["variant"]["enabled"])
call("PATCH", f"/api/v1/admin/model-variants/{vid}", {"enabled": True})

status, deleted = call("DELETE", f"/api/v1/models/variants/{vid}")
print("11. delete sub-model        ->", status, deleted)
# housekeeping: remove anything a previous run of this script left behind
for variant in listed["items"]:
    if variant["name"].startswith("Code writer (e2e)"):
        call("DELETE", f"/api/v1/models/variants/{variant['id']}")
status, after = call("GET", f"/api/v1/models/{model['id']}/variants")
print("   remaining sub-models     ->", [v["name"] for v in after["items"]])

status, telegram = call("GET", "/api/v1/telegram/status")
print("12. telegram status         ->", status, "linked=", telegram["linked"], "configured=", telegram["bot_configured"])
print("\nALL VARIANT STEPS PASSED")
