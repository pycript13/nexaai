#!/usr/bin/env python3
"""A deliberately flaky OpenAI-compatible upstream, used to prove two fixes.

* ``GET /v1/models`` always answers (this is what the admin "Test connection" button calls).
* The **first** streaming ``POST /v1/chat/completions`` is answered with a TCP reset (RST),
  exactly what a firewall, a flapping proxy or an overloaded provider does to a server.
  Every later request is served normally.

So: before the fix the connection test looked green while the chat failed with
``provider_connectivity``; after the fix the chat retries once and answers.
"""
from __future__ import annotations

import json
import socket
import struct
import sys
import threading
import time

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 9098
reset_once = {"done": False}
stats = {"models": 0, "chat_stream": 0, "chat": 0, "resets": 0}

MODELS = [
    {"id": "flaky-chat", "object": "model", "created": 0, "owned_by": "flaky"},
]

SSE = (
    'data: {"id":"x","object":"chat.completion.chunk","choices":[{"index":0,"delta":{"role":"assistant","content":"rec"},"finish_reason":null}]}\n\n'
    'data: {"id":"x","object":"chat.completion.chunk","choices":[{"index":0,"delta":{"content":"overed"}}]}\n\n'
    'data: {"id":"x","object":"chat.completion.chunk","choices":[{"index":0,"delta":{},"finish_reason":"stop"}]}\n\n'
    "data: [DONE]\n\n"
)


def respond(sock: socket.socket, status: int, body: bytes, content_type: str = "application/json") -> None:
    head = (
        f"HTTP/1.1 {status} OK\r\nContent-Type: {content_type}\r\nContent-Length: {len(body)}\r\n"
        "Connection: close\r\n\r\n"
    ).encode()
    sock.sendall(head + body)


def hard_reset(sock: socket.socket) -> None:
    """Send a TCP RST instead of a FIN — a 'connection reset by peer' at the client."""
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack("ii", 1, 0))
    except OSError:
        pass
    sock.close()
    stats["resets"] += 1


def handle(conn: socket.socket) -> None:
    conn.settimeout(10)
    data = b""
    try:
        while b"\r\n\r\n" not in data:
            chunk = conn.recv(65536)
            if not chunk:
                return
            data += chunk
        head, _, rest = data.partition(b"\r\n\r\n")
        lines = head.decode("latin-1").split("\r\n")
        method, path, _ = lines[0].split(" ", 2)
        headers = {}
        for line in lines[1:]:
            if ":" in line:
                key, _, value = line.partition(":")
                headers[key.strip().lower()] = value.strip()
        length = int(headers.get("content-length") or 0)
        body = rest
        while len(body) < length:
            chunk = conn.recv(65536)
            if not chunk:
                break
            body += chunk
        payload = json.loads(body.decode("utf-8") or "{}")

        if path.endswith("/models") and method == "GET":
            stats["models"] += 1
            respond(conn, 200, json.dumps({"object": "list", "data": MODELS}).encode())
            return

        if path.endswith("/chat/completions") and method == "POST":
            if payload.get("stream"):
                stats["chat_stream"] += 1
                if not reset_once["done"]:
                    reset_once["done"] = True
                    print(f"[flaky] resetting the first streaming request (attempt {stats['chat_stream']})", flush=True)
                    hard_reset(conn)
                    return
                print(f"[flaky] serving the retried streaming request (attempt {stats['chat_stream']})", flush=True)
                respond(conn, 200, SSE.encode(), content_type="text/event-stream")
                return
            stats["chat"] += 1
            respond(conn, 200, json.dumps({
                "id": "x", "object": "chat.completion", "model": payload.get("model", "flaky-chat"),
                "choices": [{"index": 0, "message": {"role": "assistant", "content": "recovered"}, "finish_reason": "stop"}],
                "usage": {"prompt_tokens": 3, "completion_tokens": 2, "total_tokens": 5},
            }).encode())
            return

        respond(conn, 404, json.dumps({"error": {"message": f"no route for {method} {path}"}}).encode())
    except Exception as exc:  # noqa: BLE001
        print(f"[flaky] handler error: {type(exc).__name__}: {exc}", flush=True)
    finally:
        try:
            conn.close()
        except OSError:
            pass


def main() -> None:
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("127.0.0.1", PORT))
    server.listen(16)
    print(f"[flaky] listening on 127.0.0.1:{PORT} — first streaming chat request will be reset", flush=True)
    while True:
        conn, _ = server.accept()
        threading.Thread(target=handle, args=(conn,), daemon=True).start()


if __name__ == "__main__":
    main()
