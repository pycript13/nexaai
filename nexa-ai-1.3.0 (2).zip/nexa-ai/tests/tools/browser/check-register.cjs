#!/usr/bin/env node
/**
 * End-to-end proof that a stranger who is handed the link can actually create an account and sign in
 * — through the real browser UI, in every language, on a phone and on a desktop.
 *
 * Round 12 regression: the sign-up form sent only `accept_terms` while the API required
 * `accept_privacy` as well, so *every* registration ended in 422 and the screen showed a generic
 * error. This suite would have caught it, and now guards it.
 *
 * Usage: node check-register.cjs [baseUrl]
 * Exit code 0 = every visitor could register and sign in.
 */
const puppeteer = require("puppeteer-core");

const BASE = (process.argv[2] || "http://127.0.0.1:8081").replace(/\/$/, "");
const SHOT_DIR = process.env.SHOT_DIR || "/tmp/nexa-register";
const VIEWPORTS = [
  { name: "phone", width: 390, height: 844 },
  { name: "desktop", width: 1440, height: 900 },
];
const LOCALES = ["fa", "en"];

const problems = [];
const note = (message) => {
  problems.push(message);
  console.log(`  ✗ ${message}`);
};

(async () => {
  const fs = require("fs");
  fs.mkdirSync(SHOT_DIR, { recursive: true });
  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium",
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader"],
  });

  for (const viewport of VIEWPORTS) {
    for (const locale of LOCALES) {
      const email = `e2e-${viewport.name}-${locale}-${Date.now().toString().slice(-6)}@example.org`;
      const password = "Str0ng-Passphrase-2026";
      console.log(`\n== register/sign-in · ${viewport.name} · ${locale} · ${email}`);
      const page = await browser.newPage();
      await page.setViewport({ width: viewport.width, height: viewport.height });
      const failures = [];
      page.on("response", (response) => {
        const url = response.url();
        if (url.includes("/api/v1/") && response.status() >= 400) {
          failures.push(`${response.status()} ${url.replace(BASE, "")}`);
        }
      });

      await page.goto(`${BASE}/register`, { waitUntil: "networkidle2" });
      await page.select("select", locale).catch(() => {});
      await page.waitForSelector('input[type="email"]', { timeout: 15000 });
      if (!(await page.$('input[type="email"]'))) note("the sign-up form lost its e-mail field");
      // Index order matches the form markup: 0 e-mail, 1 display name, 2 company, 3/4 the passwords.
      const fields = await page.$$("form input");
      const [emailField, nameField, , passwordField, confirmField] = fields;
      const passwordFields = await page.$$('input[type="password"]');
      if (passwordFields.length !== 2) note(`the form asks for the password ${passwordFields.length} time(s), expected twice`);
      if (fields.length < 5) note(`the sign-up form only has ${fields.length} inputs — expected e-mail, name, company and two passwords`);
      await emailField.type(email);
      await nameField.type(`Visitor ${locale}`);
      await passwordField.type(password);
      await confirmField.type(password);
      const typed = await page.$eval("form", (form) => [...form.querySelectorAll("input")].map((el) => el.value).join("|"));
      console.log(`  · typed into the form: ${typed.replace(/Str0ng-Passphrase-2026/g, "•••")}`);

      const checkbox = await page.$('form input[type="checkbox"]');
      if (!checkbox) note("no consent checkbox on the sign-up form");
      await checkbox?.click();

      const submit = await page.$('form button[type="submit"]');
      if (!submit) note("no submit button on the sign-up form");
      await Promise.all([
        page.waitForNavigation({ waitUntil: "networkidle2", timeout: 20000 }).catch(() => {}),
        submit?.click(),
      ]);
      await new Promise((resolve) => setTimeout(resolve, 1200));

      const url = page.url();
      const body = await page.$eval("body", (el) => el.innerText).catch(() => "");
      const apiErrors = failures.filter((entry) => entry.startsWith("422") || entry.startsWith("5"));
      if (apiErrors.length) note(`API rejected the form: ${apiErrors.join(", ")}`);
      const landed = url.includes("/app");
      const askedToVerify = /verify|تأیید|دڵنیا|التأكيد/i.test(body);
      if (!landed && !askedToVerify) note(`after submitting, the page stayed on ${url} without a verification notice`);
      else console.log(`  · result: ${landed ? "signed in immediately" : "asked to verify the address"} (${url})`);

      // Sign out, then sign in again with the same credentials — the second half of the report.
      const page2 = await browser.newPage();
      await page2.setViewport({ width: viewport.width, height: viewport.height });
      const loginFailures = [];
      page2.on("response", (response) => {
        if (response.url().includes("/api/v1/auth/login") && response.status() >= 400) loginFailures.push(String(response.status()));
      });
      await page2.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
      await page2.type('input[type="email"]', email);
      await page2.type('input[type="password"]', password);
      await Promise.all([
        page2.waitForNavigation({ waitUntil: "networkidle2", timeout: 20000 }).catch(() => {}),
        page2.click('button[type="submit"]'),
      ]);
      await new Promise((resolve) => setTimeout(resolve, 1200));
      if (!page2.url().includes("/app") || loginFailures.length) {
        note(`sign-in failed (status ${loginFailures.join(",") || "none"}, landed on ${page2.url()})`);
        await page2.screenshot({ path: `${SHOT_DIR}/login-failed-${viewport.name}-${locale}.png` });
      } else {
        console.log(`  · sign-in: ok (${page2.url()})`);
      }
      await page.screenshot({ path: `${SHOT_DIR}/register-${viewport.name}-${locale}.png` });
      await page.close();
      await page2.close();
    }
  }

  await browser.close();
  console.log(`\nPROBLEMS: ${problems.length}`);
  process.exit(problems.length ? 1 : 0);
})().catch((error) => {
  console.error(error);
  process.exit(2);
});
