const puppeteer = require("puppeteer-core");
const BASE = "http://127.0.0.1:8081";
(async () => {
  const browser = await puppeteer.launch({ executablePath: "/usr/bin/chromium", headless: true,
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 900 });
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
  await page.waitForSelector(".auth__card");
  await page.type('input[type="email"]', "admin@example.com");
  await page.type('input[type="password"]', "Nexa-Preview-Admin-2026!");
  await page.click('button[type="submit"]');
  await page.waitForSelector(".hero", { timeout: 20000 });
  await new Promise((r) => setTimeout(r, 1000));

  const state = async (tag) => {
    const info = await page.evaluate(() => ({
      theme: document.documentElement.dataset.theme,
      choice: document.documentElement.dataset.themeChoice,
      stored: localStorage.getItem("nexa.theme"),
      pressed: Array.from(document.querySelectorAll(".segmented button")).map((b) => b.getAttribute("aria-pressed")),
    }));
    console.log(tag, JSON.stringify(info));
  };

  await state("initial          ");

  // The segmented control order is [system, light, dark, glass] — label what is really clicked.
  for (const [index, label] of [[1, "light"], [3, "glass"], [2, "dark"], [0, "system"]]) {
    await page.evaluate((i) => document.querySelectorAll(".segmented button")[i].click(), index);
    await new Promise((r) => setTimeout(r, 700));
    await state(`after click ${label.padEnd(6)}`);
  }
  await page.reload({ waitUntil: "networkidle2" });
  await page.waitForSelector(".hero", { timeout: 20000 });
  await new Promise((r) => setTimeout(r, 900));
  await state("after reload     ");
  await browser.close();
})();
