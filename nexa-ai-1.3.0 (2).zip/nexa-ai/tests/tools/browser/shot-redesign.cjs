const puppeteer = require("puppeteer-core");
const BASE = "http://127.0.0.1:8081";
const EMAIL = process.env.NEXA_EMAIL, PASS = process.env.NEXA_PASSWORD;
(async () => {
  const browser = await puppeteer.launch({ executablePath: "/usr/bin/chromium", args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader"] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 900 });
  page.setCacheEnabled(false);
  // landing (guest, fresh storage => default dark)
  await page.goto(BASE + "/", { waitUntil: "networkidle2", timeout: 45000 });
  await new Promise(r => setTimeout(r, 1200));
  await page.screenshot({ path: "/tmp/shot-landing-dark.png" });
  // login -> chat
  await page.goto(BASE + "/login", { waitUntil: "networkidle2" });
  await page.type('input[type="email"]', EMAIL); await page.type('input[type="password"]', PASS);
  await page.click('button[type="submit"]');
  await page.waitForFunction(() => location.pathname.startsWith("/app"), { timeout: 20000 });
  await page.goto(BASE + "/app/chat", { waitUntil: "networkidle2" }); await new Promise(r => setTimeout(r, 1800));
  await page.screenshot({ path: "/tmp/shot-chat-dark.png" });
  await page.goto(BASE + "/app/models", { waitUntil: "networkidle2" }); await new Promise(r => setTimeout(r, 1500));
  await page.screenshot({ path: "/tmp/shot-models-dark.png" });
  await page.goto(BASE + "/app", { waitUntil: "networkidle2" }); await new Promise(r => setTimeout(r, 1500));
  await page.screenshot({ path: "/tmp/shot-dashboard-dark.png" });
  // light theme: set localStorage + reload
  await page.evaluate(() => localStorage.setItem("nexa.theme", "light"));
  await page.goto(BASE + "/app/chat", { waitUntil: "networkidle2" }); await new Promise(r => setTimeout(r, 1800));
  await page.screenshot({ path: "/tmp/shot-chat-light.png" });
  await page.evaluate(() => localStorage.clear());
  await page.goto(BASE + "/", { waitUntil: "networkidle2" }); await new Promise(r => setTimeout(r, 800));
  await page.screenshot({ path: "/tmp/shot-landing-light.png" });
  // mobile landing
  await page.setViewport({ width: 390, height: 844 });
  await page.goto(BASE + "/", { waitUntil: "networkidle2" }); await new Promise(r => setTimeout(r, 800));
  await page.screenshot({ path: "/tmp/shot-landing-mobile.png" });
  await browser.close();
  console.log("shots done");
})().catch(e => { console.error("FAILED:", e.message); process.exit(1); });
