#!/usr/bin/env node
/**
 * Provider catalogue import dialog + router-style Models page, verified live.
 * Uses whichever provider already has a remote catalogue on this stack (the live
 * OpenRouter provider when present): opens Admin → Providers → Model catalogue,
 * expects summary badges + rows, filters to Free, reads the selection counter,
 * then checks the Models page renders router rows. Imports nothing.
 *
 * Usage: node check-catalog-import.cjs [baseUrl] <email> <password>
 */
const BASE = (process.argv[2] || "http://127.0.0.1:8081").replace(/\/$/, "");
const EMAIL = process.argv[3] || "";
const PASSWORD = process.argv[4] || "";
const puppeteer = require("puppeteer-core");
const problems = [];
const ok = (m) => console.log(`  ✓ ${m}`);
const fail = (m) => { problems.push(m); console.log(`  ✗ ${m}`); };
const check = (c, m) => (c ? ok(m) : fail(m));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium",
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader"],
  });
  const page = await browser.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e).slice(0, 120)));
  await page.setViewport({ width: 1440, height: 900 });
  await page.goto(`${BASE}/login`, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.waitForSelector('input[type="email"]', { timeout: 45000 });
  await page.type('input[type="email"]', EMAIL);
  await page.type('input[type="password"]', PASSWORD);
  await page.waitForFunction(() => !document.querySelector(".splash-stage"), { timeout: 30000 });
  await page.click('button[type="submit"]');
  await page.waitForFunction(() => location.pathname.startsWith("/app"), { timeout: 45000 });
  ok("signed in");

  await page.goto(`${BASE}/app/admin/providers`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector("table, .table", { timeout: 30000 }).catch(() => null);
  await sleep(1500);
  const opened = await page.evaluate(() => {
    const rows = [...document.querySelectorAll("tr")];
    const target = rows.find((r) => /openrouter/i.test(r.textContent || "")) || rows[1];
    const btn = target && [...target.querySelectorAll("button")].find((b) => /catalogue|کاتالوگ/.test(b.textContent || ""));
    if (btn) { btn.click(); return true; }
    return false;
  });
  check(opened, "catalogue button exists on the providers page");

  await page.waitForSelector(".catalog-list", { timeout: 90000 });
  const stats = await page.evaluate(() => ({
    rows: document.querySelectorAll(".catalog-row").length,
    badges: [...document.querySelectorAll(".modal .badge, [role=dialog] .badge")].slice(0, 10).map((b) => b.textContent.trim()),
    chips: [...document.querySelectorAll(".chip")].map((b) => b.textContent.trim()),
  }));
  check(stats.rows > 50, `catalogue rows rendered (${stats.rows})`);
  console.log("   badges:", JSON.stringify(stats.badges));

  // filter: free only
  await page.evaluate(() => {
    const chip = [...document.querySelectorAll(".chip")].find((b) => /free|رایگان/i.test(b.textContent || ""));
    if (chip) chip.click();
  });
  await sleep(800);
  const freeState = await page.evaluate(() => {
    const rows = [...document.querySelectorAll(".catalog-row")];
    const firstBox = rows.map((r) => r.querySelector('input[type="checkbox"]:not(:disabled)')).find(Boolean);
    if (firstBox) firstBox.click();
    return { rows: rows.length };
  });
  await sleep(400);
  const counter = await page.evaluate(() => document.body.textContent.match(/1\s*(مدل انتخاب شده|models selected)/)?.[0] || null);
  check(freeState.rows > 0 && !!counter, `free filter works (${freeState.rows} rows) and selection counter updates (${counter})`);

  // models page: router rows
  await page.goto(`${BASE}/app/models`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector(".router-row", { timeout: 30000 });
  const rowCount = await page.evaluate(() => document.querySelectorAll(".router-row").length);
  check(rowCount > 0, `models page renders router rows (${rowCount})`);
  check(errors.length === 0, `no page errors (${errors.length}) ${errors[0] || ""}`);
  await browser.close();
  console.log(`\nPROBLEMS: ${problems.length}`);
  process.exit(problems.length ? 1 : 0);
})().catch((e) => { console.log("PROBE FAILED:", String(e).slice(0, 240)); console.log("\nPROBLEMS: 1"); process.exit(1); });
