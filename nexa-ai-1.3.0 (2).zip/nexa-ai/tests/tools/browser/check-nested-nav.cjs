#!/usr/bin/env node
/**
 * Round-13 UI: the nested collapsible navigation and the 3D splash, verified live.
 *
 *   * the served HTML carries the full 3D splash scene (cube, rings, glow, particles, reduced-motion);
 *   * the sidebar is a real tree: group toggles with aria-expanded, four nested admin sections;
 *   * navigating into a collapsed branch re-opens it and the breadcrumb shows all three levels;
 *   * collapsing hides the branch from the tab order (visibility, not just height);
 *   * manual expand/collapse choices persist across a reload (localStorage);
 *   * the command palette still reaches every destination (flat list over the nested tree);
 *   * on a 390px phone the drawer works and every toggle is a ≥44px touch target.
 *
 * Usage: node check-nested-nav.cjs [baseUrl] <adminEmail> <adminPassword>
 */
const BASE = (process.argv[2] || "http://127.0.0.1:8081").replace(/\/$/, "");
const EMAIL = process.argv[3] || "admin@example.com";
const PASSWORD = process.argv[4] || "";

const puppeteer = require("puppeteer-core");

const problems = [];
const ok = (message) => console.log(`  ✓ ${message}`);
const fail = (message) => {
  problems.push(message);
  console.log(`  ✗ ${message}`);
};
const check = (condition, message) => (condition ? ok(message) : fail(message));

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
/** Persian texts mix ZWNJ forms (پشتیبان‌گیری / پشتیبانگیری); comparisons must not care. */
const norm = (text) => (text || "").replace(/\u200c/g, "").replace(/\s+/g, " ").trim();

(async () => {
  // ------------------------------------------------- 0. the first-paint splash is in the HTML
  console.log("== the 3D splash (first paint)");
  const html = await (await fetch(`${BASE}/login`)).text();
  for (const marker of ["splash-stage", "splash-cube", "splash-ring--b", "splash-glow", "splash-particle p4", "splash-spin", "prefers-reduced-motion"]) {
    check(html.includes(marker), `index.html carries “${marker}”`);
  }
  const faces = (html.match(/splash-face f-/g) || []).length;
  check(faces === 6, `the cube has all 6 glass faces (${faces})`);
  const bundleName = (html.match(/assets\/(index-[^"]+\.js)/) || [])[1];
  if (bundleName) {
    const js = await (await fetch(`${BASE}/assets/${bundleName}`)).text();
    check(js.includes("splash3d__cube"), "the in-app SplashLoader is compiled into the bundle");
  } else fail("could not find the JS bundle name in the served HTML");

  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium",
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader"],
  });
  const page = await browser.newPage();
  // The same ZWNJ-tolerant comparator, injected into the page so evaluate() callbacks can use it.
  await page.evaluateOnNewDocument(() => {
    window.norm = (text) => (text || "").replace(/\u200c/g, "").replace(/\s+/g, " ").trim();
  });
  await page.setViewport({ width: 1440, height: 900 });

  // ------------------------------------------------- login
  await page.goto(`${BASE}/login`, { waitUntil: "domcontentloaded", timeout: 30000 });
  await page.waitForSelector('input[type="email"]', { timeout: 25000 });
  await page.type('input[type="email"]', EMAIL);
  await page.type('input[type="password"]', PASSWORD);
  await page.click('button[type="submit"]');
  await page.waitForFunction(() => location.pathname.startsWith("/app"), { timeout: 35000 });
  ok("admin signed in");
  await page.waitForSelector(".sidebar__nav", { timeout: 15000 });

  // ------------------------------------------------- 1. the tree on the dashboard
  console.log("\n== the nested tree (desktop, fa/RTL)");
  const structure = await page.evaluate(() => {
    const groups = [...document.querySelectorAll(".sidebar__nav .navgroup")];
    return groups.map((group) => ({
      single: group.classList.contains("navgroup--single"),
      label: group.querySelector(".navgroup__label, .navlink__text")?.textContent?.trim() || "",
      expanded: group.querySelector(".navgroup__toggle")?.getAttribute("aria-expanded") ?? null,
      count: group.querySelector(".navgroup__count")?.textContent?.trim() ?? null,
      sections: [...group.querySelectorAll(".navsection")].map((section) => ({
        label: section.querySelector(".navsection__label")?.textContent?.trim() || "",
        expanded: section.querySelector(".navsection__toggle")?.getAttribute("aria-expanded") ?? null,
        links: section.querySelectorAll(".navlink").length,
      })),
    }));
  });
  const byLabel = Object.fromEntries(structure.map((entry) => [norm(entry.label), entry]));
  check(!!byLabel["داشبورد"]?.single, "the dashboard group renders as a single direct link (no pointless toggle)");
  for (const label of ["میزکار", "فهرست مدل‌ها", "حساب کاربری", "مدیریت"].map(norm)) {
    check(byLabel[label]?.expanded === "false" || byLabel[label]?.expanded === "true", `group “${label}” is a real toggle (aria-expanded=${byLabel[label]?.expanded})`);
  }
  check(byLabel["میزکار"]?.count === "8", `workspace shows its item count (8), got ${byLabel["میزکار"]?.count}`);
  const adminSections = byLabel["مدیریت"]?.sections || [];
  check(adminSections.length === 4, `administration nests 4 sections, got ${adminSections.length}`);
  check(adminSections.map((s) => norm(s.label)).join("|") === norm("دسترسی‌ها|پلتفرم|مالی|عملیات"), `subgroup labels: ${adminSections.map((s) => s.label).join(" · ")}`);
  check(adminSections.reduce((sum, s) => sum + s.links, 0) === 14, "the 4 subgroups hold all 14 nested admin pages");

  // collapsed branches must leave the tab order
  const hiddenFromTab = await page.evaluate(() => {
    const body = document.querySelector(".navgroup:not(.navgroup--open) .navgroup__body");
    return body ? getComputedStyle(body).visibility === "hidden" : null;
  });
  check(hiddenFromTab === true, "a collapsed branch is visibility:hidden (not focusable)");

  // ------------------------------------------------- 2. navigating re-opens and breadcrumbs
  console.log("\n== auto-expand + three-level breadcrumb");
  await page.goto(`${BASE}/app/admin/backups`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector(".sidebar__nav", { timeout: 15000 });
  await sleep(600);
  const opened = await page.evaluate(() => {
    const admin = [...document.querySelectorAll(".navgroup")].find((g) => norm(g.querySelector(".navgroup__label")?.textContent) === "مدیریت");
    const ops = [...document.querySelectorAll(".navsection")].find((s) => norm(s.querySelector(".navsection__label")?.textContent) === "عملیات");
    const active = [...document.querySelectorAll(".navlink--active")].map((el) => el.querySelector(".navlink__text")?.textContent || "").join("|");
    const crumbs = document.querySelector(".crumbs")?.textContent?.replace(/\s+/g, " ").trim() || "";
    return {
      adminOpen: admin?.classList.contains("navgroup--open") ?? false,
      opsOpen: ops?.classList.contains("navsection--open") ?? false,
      active,
      crumbs,
      backupsVisible: !!ops?.querySelector('a[href="/app/admin/backups"]')?.offsetParent,
    };
  });
  check(opened.adminOpen, "navigating to /app/admin/backups re-opened the administration group");
  check(opened.opsOpen, "…and its «عملیات» subgroup");
  check(opened.backupsVisible, "the active page's link is visible inside the opened branch");
  check(norm(opened.active) === norm("پشتیبان‌گیری و بازیابی"), `exactly one active link: ${opened.active}`);
  const crumbs = norm(opened.crumbs);
  check(crumbs.includes("مدیریت") && crumbs.includes("عملیات") && crumbs.includes(norm("پشتیبان‌گیری و بازیابی")), `breadcrumb shows all three levels: «${opened.crumbs}»`);

  // ------------------------------------------------- 3. manual collapse + persistence
  console.log("\n== manual collapse and persistence");
  await page.evaluate(() => {
    const admin = [...document.querySelectorAll(".navgroup")].find((g) => norm(g.querySelector(".navgroup__label")?.textContent) === "مدیریت");
    admin.querySelector(".navgroup__toggle").click();
  });
  await sleep(450);
  const collapsed = await page.evaluate(() => {
    const admin = [...document.querySelectorAll(".navgroup")].find((g) => norm(g.querySelector(".navgroup__label")?.textContent) === "مدیریت");
    return {
      expanded: admin.querySelector(".navgroup__toggle").getAttribute("aria-expanded"),
      stored: window.localStorage.getItem("nexa.nav.open.v1"),
    };
  });
  check(collapsed.expanded === "false", "clicking the header collapses even the active group (aria-expanded=false)");
  check(JSON.parse(collapsed.stored || "{}").admin === false, "the choice was persisted to localStorage");

  await page.evaluate(() => {
    const ws = [...document.querySelectorAll(".navgroup")].find((g) => norm(g.querySelector(".navgroup__label")?.textContent) === "میزکار");
    ws.querySelector(".navgroup__toggle").click();
  });
  await sleep(450);
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.waitForSelector(".sidebar__nav", { timeout: 15000 });
  await sleep(500);
  const afterReload = await page.evaluate(() => {
    const get = (label) => {
      const group = [...document.querySelectorAll(".navgroup")].find((g) => g.querySelector(".navgroup__label")?.textContent?.trim() === label);
      return group?.classList.contains("navgroup--open") ?? null;
    };
    return { workspace: get("میزکار"), admin: get("مدیریت") };
  });
  check(afterReload.workspace === true, "after a reload the manually opened «میزکار» is still open");
  check(afterReload.admin === true, "…and the active «مدیریت» re-opened from the route (admin=false persisted, route wins)");

  // ------------------------------------------------- 4. the palette still reaches everything
  console.log("\n== command palette over the nested tree");
  await page.keyboard.down("Control");
  await page.keyboard.press("KeyK");
  await page.keyboard.up("Control");
  await page.waitForSelector(".palette__search input", { timeout: 8000 });
  await page.evaluate(() => {
    const input = document.querySelector(".palette__search input");
    // React tracks the value property: assigning it directly hides the change from onChange,
    // so the native setter must be used before dispatching the input event.
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
    setter.call(input, "پشتیبان");
    input.dispatchEvent(new Event("input", { bubbles: true }));
  });
  await sleep(350);
  const paletteHit = await page.evaluate(() => {
    const entry = [...document.querySelectorAll(".palette__list button, .palette__list [role='option']")]
      .find((el) => el.textContent.replace(/\u200c/g, "").includes("پشتیبانگیری"));
    return entry ? entry.textContent.replace(/\s+/g, " ").trim().slice(0, 60) : null;
  });
  check(!!paletteHit, `the palette finds the nested page despite the collapsed tree (${paletteHit || "not found"})`);
  await page.keyboard.press("Enter");
  await page.waitForFunction(() => location.pathname === "/app/admin/backups", { timeout: 8000 });
  ok("Enter navigated to /app/admin/backups");
  await page.keyboard.press("Escape");

  // ------------------------------------------------- 5. the phone drawer
  console.log("\n== the 390px phone drawer");
  await page.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true });
  await page.goto(`${BASE}/app`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector(".topbar__menu", { timeout: 15000 });
  await page.click(".topbar__menu");
  await page.waitForSelector(".sidebar--open", { timeout: 8000 });
  await sleep(400);
  const mobile = await page.evaluate(() => {
    const toggles = [...document.querySelectorAll(".sidebar--open .navgroup__toggle, .sidebar--open .navsection__toggle")];
    const heights = toggles.map((el) => el.getBoundingClientRect().height);
    const ws = [...document.querySelectorAll(".sidebar--open .navgroup")].find((g) => norm(g.querySelector(".navgroup__label")?.textContent) === "میزکار");
    return {
      toggles: toggles.length,
      min: heights.length ? Math.min(...heights) : 0,
      wsOpen: ws?.classList.contains("navgroup--open") ?? null,
      noHScroll: document.documentElement.scrollWidth <= window.innerWidth + 1,
    };
  });
  check(mobile.toggles === 8, `the drawer holds 4 group toggles + 4 admin subgroups (${mobile.toggles})`);
  check(mobile.min >= 43.5, `every toggle is a ≥44px touch target (min ${mobile.min.toFixed(1)}px)`);
  check(mobile.noHScroll, "no horizontal overflow at 390px");
  // expand workspace with a real tap, then a subgroup of admin
  await page.evaluate(() => {
    const ws = [...document.querySelectorAll(".sidebar--open .navgroup")].find((g) => norm(g.querySelector(".navgroup__label")?.textContent) === "میزکار");
    ws.querySelector(".navgroup__toggle").click();
  });
  await sleep(450);
  const wsLinks = await page.evaluate(() => {
    const ws = [...document.querySelectorAll(".sidebar--open .navgroup")].find((g) => norm(g.querySelector(".navgroup__label")?.textContent) === "میزکار");
    return ws.querySelectorAll(".navlink").length;
  });
  check(wsLinks === 8, `tapping «میزکار» reveals its 8 pages in the drawer (${wsLinks})`);
  await page.evaluate(() => document.querySelector(".sidebar-backdrop").click());
  await sleep(400);
  const drawerClosed = await page.evaluate(() => !document.querySelector(".sidebar--open"));
  check(drawerClosed, "the backdrop closes the drawer");

  await browser.close();
  console.log(`\nPROBLEMS: ${problems.length}`);
  process.exit(problems.length ? 1 : 0);
})().catch((error) => {
  console.error(error);
  process.exit(2);
});
