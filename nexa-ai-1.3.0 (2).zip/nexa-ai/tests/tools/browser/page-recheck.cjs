/**
 * Re-checks a single page at a single viewport with the same measurement rules as
 * mobile-audit.cjs. Used to confirm that a "navigation-error" entry in the audit report
 * was a Puppeteer screenshot hiccup rather than a real layout problem.
 *
 *   node page-recheck.cjs --vp 412x915 --page /app/billing
 */
const fs = require("fs");
const path = require("path");
const puppeteer = require("puppeteer-core");

const BASE = process.env.BASE_URL || "http://127.0.0.1:8081";
const EMAIL = process.env.NEXA_EMAIL || "admin@example.com";
const PASSWORD = process.env.NEXA_PASSWORD || "";
const OUT = process.env.OUT_DIR || "/home/user/responsive-shots";

// Reuse the exact audit function from mobile-audit.cjs so the rules cannot drift.
const source = fs.readFileSync(path.join(__dirname, "mobile-audit.cjs"), "utf8");
const auditSource = source.slice(source.indexOf("const AUDIT = () => {"), source.indexOf("async function main()"));
// eslint-disable-next-line no-eval
const AUDIT = eval(`${auditSource}; AUDIT`);

function arg(name, fallback) {
  const index = process.argv.indexOf(`--${name}`);
  return index === -1 ? fallback : process.argv[index + 1];
}

async function main() {
  const [width, height] = arg("vp", "412x915").split("x").map(Number);
  const pagePath = arg("page", "/app/billing");
  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium",
    headless: true,
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--force-device-scale-factor=1"],
  });
  try {
    const page = await browser.newPage();
    await page.setViewport({ width, height, deviceScaleFactor: 2.6, isMobile: true, hasTouch: true });
    await page.goto(`${BASE}/login`, { waitUntil: "networkidle2", timeout: 45000 });
    await page.type('input[type="email"]', EMAIL);
    await page.type('input[type="password"]', PASSWORD);
    await Promise.all([
      page.waitForNavigation({ waitUntil: "networkidle2", timeout: 45000 }).catch(() => {}),
      page.evaluate(() => {
        const button = [...document.querySelectorAll("button")].find((b) =>
          /ورود|sign in|login/i.test(b.textContent || ""),
        );
        if (button) button.click();
      }),
    ]);
    await page.goto(`${BASE}${pagePath}`, { waitUntil: "networkidle2", timeout: 45000 });
    await new Promise((r) => setTimeout(r, 900));
    const problems = await page.evaluate(AUDIT);
    const shot = path.join(OUT, `recheck--${width}x${height}--${pagePath.replace(/\W+/g, "_")}.png`);
    await page.screenshot({ path: shot, fullPage: false });
    console.log(`viewport ${width}x${height} page ${pagePath}`);
    console.log(`problems: ${problems.length}`);
    for (const problem of problems) console.log("  -", JSON.stringify(problem));
    console.log(`screenshot: ${shot}`);
  } finally {
    await browser.close();
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
