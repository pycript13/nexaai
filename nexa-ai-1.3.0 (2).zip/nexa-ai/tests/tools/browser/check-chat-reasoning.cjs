// Verifies the reasoning-model chat experience in a real browser:
//   * a real answer from the live Dahl model is rendered with NO raw <think> tags,
//   * the chain of thought appears in its own collapsible panel,
//   * a reasoning-only reply explains itself instead of showing an empty bubble.
const puppeteer = require("puppeteer-core");
const fs = require("fs");

const BASE = process.env.BASE_URL || "http://127.0.0.1:8081";
const SHOT_DIR = process.env.SHOT_DIR || "/home/user/preview-shots-20261014";
const USER = { email: "demo.user@example.com", password: "Demo-User-Passw0rd!" };

(async () => {
  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium",
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader"],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 1000, deviceScaleFactor: 1 });
  const problems = [];

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
  await page.type('input[type="email"]', USER.email);
  await page.type('input[type="password"]', USER.password);
  await Promise.all([
    page.waitForNavigation({ waitUntil: "networkidle2" }).catch(() => {}),
    page.click('button[type="submit"]'),
  ]);
  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle2" });
  await new Promise((r) => setTimeout(r, 1500));

  // pick the real MiniMax model in the selector
  const picked = await page.evaluate(() => {
    const select = document.querySelector("select");
    if (!select) return null;
    const option = [...select.options].find((o) => /MiniMax|DeepSeek|GLM/.test(o.textContent || ""));
    if (!option) return null;
    select.value = option.value;
    select.dispatchEvent(new Event("change", { bubbles: true }));
    return option.textContent.trim();
  });
  if (!picked) problems.push("no real model was selectable in the chat screen");
  else console.log("model selected:", picked);

  const ask = async (text) => {
    const box = await page.$("textarea");
    if (!box) throw new Error("no message textarea");
    await box.click();
    await box.type(text);
    await page.keyboard.press("Enter");
    // wait for the answer: the send button stops being disabled / text appears
    await new Promise((r) => setTimeout(r, 1000));
    for (let i = 0; i < 60; i++) {
      const busy = await page.evaluate(() => !!document.querySelector(".typing"));
      const body = await page.evaluate(() => document.body.innerText);
      if (!busy && /assistant/.test(body) && body.length > 0) {
        await new Promise((r) => setTimeout(r, 700));
        const stillBusy = await page.evaluate(() => !!document.querySelector(".typing"));
        if (!stillBusy) break;
      }
      await new Promise((r) => setTimeout(r, 1000));
    }
    return page.evaluate(() => {
      const bubbles = [...document.querySelectorAll(".bubble--assistant")];
      const last = bubbles[bubbles.length - 1];
      if (!last) return null;
      return {
        text: last.innerText.trim(),
        rawTags: /<\s*\/?\s*(think|thinking|reasoning)\b/i.test(last.innerText),
        reasoningPanel: !!last.querySelector(".bubble__reasoning"),
        reasoningText: last.querySelector(".bubble__reasoning pre")?.textContent?.slice(0, 120) || "",
        emptyNote: last.querySelector(".bubble__note")?.textContent?.trim() || "",
      };
    });
  };

  const first = await ask("What is 21 times 2? Answer with the number only.");
  console.log("answer 1:", JSON.stringify(first));
  if (!first) problems.push("no assistant bubble was rendered");
  else {
    if (first.rawTags) problems.push("raw reasoning tags leaked into the answer bubble");
    if (!first.text) problems.push("the answer bubble is empty");
  }
  await page.screenshot({ path: `${SHOT_DIR}/41-chat-reasoning-model.png`, fullPage: false });

  const second = await ask("Say one word: hello");
  console.log("answer 2:", JSON.stringify(second));
  if (second?.rawTags) problems.push("raw reasoning tags leaked into the answer bubble (second turn)");
  await page.screenshot({ path: `${SHOT_DIR}/42-chat-second-turn.png`, fullPage: false });

  // reload: the reasoning panel must survive a page refresh
  await page.reload({ waitUntil: "networkidle2" });
  await new Promise((r) => setTimeout(r, 2000));
  const afterReload = await page.evaluate(() => {
    const panels = document.querySelectorAll(".bubble__reasoning");
    const body = document.body.innerText;
    return {
      panels: panels.length,
      rawTags: /<\s*think\s*>/i.test(body),
      firstReasoning: panels[0]?.querySelector("pre")?.textContent?.slice(0, 80) || "",
    };
  });
  console.log("after reload:", JSON.stringify(afterReload));
  if (afterReload.rawTags) problems.push("raw <think> tags visible after a reload");
  await page.screenshot({ path: `${SHOT_DIR}/43-chat-reasoning-reload.png`, fullPage: false });

  fs.mkdirSync(SHOT_DIR, { recursive: true });
  console.log(JSON.stringify({ problems, shots: fs.readdirSync(SHOT_DIR).filter((f) => f.startsWith("4")) }, null, 2));
  await browser.close();
  process.exit(problems.length ? 1 : 0);
})().catch((error) => {
  console.error("checker crashed:", error);
  process.exit(2);
});
