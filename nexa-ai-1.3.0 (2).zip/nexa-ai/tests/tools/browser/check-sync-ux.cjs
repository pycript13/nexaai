#!/usr/bin/env node
/**
 * The admin path that was reported as "the provider connects but the models never arrive":
 *   Admin → Providers → Sync must show a readable result and lead to the imported drafts,
 *   Admin → Models?published=false must list them.
 *
 * Self-contained: the checker creates its own provider against the live mock upstream
 * (the old hard-coded "Shapes Test" row pointed at a fixture port that this runtime does
 * not serve, so the sync legitimately failed and the checker called that a UI defect),
 * syncs it through the real UI, follows the card's link, then deletes the provider with
 * force so no drafts accumulate. Labels are matched in fa and en — the admin UI runs in
 * the operator's own language.
 *
 * Usage: node check-sync-ux.cjs [baseUrl] <adminEmail> <adminPassword>
 * Env:   BASE_URL / NEXA_EMAIL / NEXA_PASSWORD / SHOT_DIR override the arguments.
 */
const puppeteer = require("puppeteer-core");
const fs = require("fs");

const BASE = (process.env.BASE_URL || process.argv[2] || "http://127.0.0.1:8081").replace(/\/$/, "");
const EMAIL = process.env.NEXA_EMAIL || process.argv[3] || "admin@example.com";
const PASSWORD = process.env.NEXA_PASSWORD || process.argv[4] || "";
const SHOT_DIR = process.env.SHOT_DIR || "/home/user/responsive-shots";
const UPSTREAM_URL = process.env.UPSTREAM_URL || "http://127.0.0.1:9099/v1";
const UPSTREAM_KEY = process.env.UPSTREAM_KEY || "sk-mock-key";
const PROVIDER_NAME = `Sync UX check ${Date.now().toString(36)}`;

const problems = [];
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const ok = (message) => console.log(`  ✓ ${message}`);
const fail = (message) => {
  problems.push(message);
  console.log(`  ✗ ${message}`);
};
const either = (fa, en) => new RegExp(`${fa}|${en}`, "i");

(async () => {
  fs.mkdirSync(SHOT_DIR, { recursive: true });
  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium",
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader"],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 1000 });

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
  await page.type('input[type="email"]', EMAIL);
  await page.type('input[type="password"]', PASSWORD);
  await Promise.all([
    page.waitForNavigation({ waitUntil: "networkidle2" }).catch(() => {}),
    page.click('button[type="submit"]'),
  ]);
  if (!page.url().includes("/app")) {
    console.error("FAILED: sign-in did not reach /app");
    process.exit(2);
  }
  ok("admin signed in");

  // ---- create a provider that points at the live mock upstream --------------
  const created = await page.evaluate(async ({ name, baseUrl, apiKey }) => {
    const csrf = (document.cookie.match(/(?:^|;\s*)nexa_csrf=([^;]+)/) || [])[1] || "";
    const response = await fetch("/api/v1/admin/providers", {
      method: "POST",
      headers: { "content-type": "application/json", "x-csrf-token": csrf },
      body: JSON.stringify({ name, provider_type: "openai_compatible", base_url: baseUrl, api_key: apiKey }),
    });
    const body = await response.json().catch(() => ({}));
    return { status: response.status, id: body?.provider?.id ?? body?.id ?? null };
  }, { name: PROVIDER_NAME, baseUrl: UPSTREAM_URL, apiKey: UPSTREAM_KEY });
  if (created.status !== 201 || !created.id) {
    fail(`could not create the check provider (HTTP ${created.status})`);
    await browser.close();
    console.log(`\nPROBLEMS: ${problems.length}`);
    process.exit(1);
  }
  ok(`provider “${PROVIDER_NAME}” created (#${created.id}) against the live mock upstream`);

  try {
    // ---- sync it through the real UI -----------------------------------------
    await page.goto(`${BASE}/app/admin/providers`, { waitUntil: "networkidle2" });
    await sleep(1500);
    const clicked = await page.evaluate((name) => {
      const rows = [...document.querySelectorAll("tbody tr")];
      const row = rows.find((candidate) => (candidate.innerText || "").includes(name));
      if (!row) return null;
      const buttons = [...row.querySelectorAll("button")];
      const button = buttons.find((candidate) => /sync|همگام/i.test(candidate.innerText || "")) || buttons[buttons.length - 1];
      if (!button) return null;
      button.click();
      return true;
    }, PROVIDER_NAME);
    if (!clicked) fail("the sync button was not found on the provider's row");
    else ok("Sync pressed on the provider's row");

    // The result card (fa or en) with real counts. Careful: every provider row carries a
    // "همگام‌سازی مدل‌ها" *button*, so waiting for the title would pass before the sync even
    // finished — wait for the count badges, which only the result card renders.
    try {
      await page.waitForFunction(
        () => /\d+\s*(وارد شد|imported)/i.test(document.body.innerText),
        { timeout: 20000 },
      );
      ok("the synchronisation result card appeared with counts");
    } catch {
      fail("the synchronisation result card with counts did not appear within 20s");
    }
    const card = await page.evaluate(() => {
      const cards = [...document.querySelectorAll(".card, section")]
        .filter((candidate) => /\d+\s*(وارد شد|imported)/i.test(candidate.innerText || ""))
        .sort((a, b) => (a.innerText || "").length - (b.innerText || "").length);
      return cards.length ? cards[0].innerText.replace(/\s+/g, " ").slice(0, 400) : null;
    });
    if (card) {
      if (/وارد شد|imported/i.test(card) && /در سرویس‌دهنده|at the provider/i.test(card)) ok(`the card reports counts: ${card.slice(0, 120)}`);
      else fail(`the card shows no counts: ${card.slice(0, 120)}`);
    }
    await page.screenshot({ path: `${SHOT_DIR}/50-provider-sync-result.png` }).catch(() => undefined);

    // ---- follow the card's link to the drafts --------------------------------
    const went = await page.evaluate(() => {
      const button = [...document.querySelectorAll("button")].find((candidate) =>
        /نمایش مدل‌های منتشرنشده|Open the unpublished models/i.test(candidate.innerText || ""),
      );
      if (!button) return false;
      button.click();
      return true;
    });
    if (!went) fail("the 'open the unpublished models' button was missing (fa/en)");
    else ok("followed the card's link");
    try {
      await page.waitForFunction(() => location.pathname.includes("/admin/models") && location.search.includes("published=false"), { timeout: 10000 });
      ok("landed on /app/admin/models?published=false");
    } catch {
      fail(`the link did not land on the drafts view (${await page.evaluate(() => location.pathname + location.search)})`);
    }
    await sleep(2000);
    const drafts = await page.evaluate(() => ({
      url: location.pathname + location.search,
      rows: [...document.querySelectorAll("tbody tr")].filter((row) => /mock/i.test(row.innerText || "")).length,
    }));
    console.log(`  draft rows matching the mock upstream: ${drafts.rows} (${drafts.url})`);
    if (drafts.rows < 2) fail("the imported models are not listed on the models page");
    else ok("the imported drafts are listed, waiting for verification");
    await page.screenshot({ path: `${SHOT_DIR}/51-models-waiting-for-verification.png` }).catch(() => undefined);
  } finally {
    // ---- hygiene: remove the provider and everything it imported --------------
    const removed = await page.evaluate(async (id) => {
      const csrf = (document.cookie.match(/(?:^|;\s*)nexa_csrf=([^;]+)/) || [])[1] || "";
      const response = await fetch(`/api/v1/admin/providers/${id}?force=true`, { method: "DELETE", headers: { "x-csrf-token": csrf } });
      return response.status;
    }, created.id);
    console.log(`  cleanup: provider deleted (HTTP ${removed})`);
    if (removed !== 200) fail(`cleanup failed: DELETE /admin/providers/${created.id} → HTTP ${removed}`);
  }

  await browser.close();
  console.log(`\nPROBLEMS: ${problems.length}`);
  process.exit(problems.length ? 1 : 0);
})().catch((error) => {
  console.error("checker crashed:", error);
  process.exit(2);
});
