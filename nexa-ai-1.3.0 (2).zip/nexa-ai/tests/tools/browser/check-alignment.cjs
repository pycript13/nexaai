#!/usr/bin/env node
/**
 * Alignment / responsiveness audit for the Nexa AI panel.
 *
 * Operators reported that “boxes and fields are not responsive or sit higher/lower than their
 * neighbours”. This scans every route at three viewports and reports, with concrete measurements:
 *
 *   ALIGN  — two controls sharing a visual row whose top edges differ by more than 3 px
 *   HEIGHT — ditto but differing heights (input vs select vs button)
 *   NARROW — a control squeezed below 72 px of usable width
 *   ESCAPE — an element that paints past the right edge of its nearest scrollable ancestor
 *   HSCROLL/PAGE overflows horizontally (the same check the other suites run)
 *
 * Values are thresholds, not opinions: anything under 3 px is left alone deliberately (browser
 * sub-pixel layout), anything above is listed with the exact numbers so it can be fixed or waived.
 *
 * Usage: node check-alignment.cjs [baseUrl] [email] [password]
 */
const puppeteer = require("puppeteer-core");

const BASE = (process.argv[2] || "http://127.0.0.1:8081").replace(/\/$/, "");
const EMAIL = process.argv[3] || "admin@example.com";
const PASSWORD = process.argv[4] || "Nexa-Preview-Admin-2026!";
const SHOT_DIR = process.env.SHOT_DIR || "/tmp/nexa-alignment";
const VIEWPORTS = [
  { name: "phone", width: 390, height: 844 },
  { name: "tablet", width: 820, height: 1180 },
  { name: "desktop", width: 1440, height: 900 },
];
const ROUTES = [
  ["landing", "/"],
  ["login", "/login"],
  ["register", "/register"],
  ["dashboard", "/app"],
  ["chat", "/app/chat"],
  ["coding", "/app/coding"],
  ["images", "/app/images"],
  ["documents", "/app/documents"],
  ["translation", "/app/translation"],
  ["data", "/app/data"],
  ["audio", "/app/audio"],
  ["video", "/app/video"],
  ["models", "/app/models"],
  ["billing", "/app/billing"],
  ["payments", "/app/payments"],
  ["usage", "/app/usage"],
  ["api-keys", "/app/api-keys"],
  ["files", "/app/files"],
  ["profile", "/app/profile"],
  ["admin", "/app/admin"],
  ["admin.users", "/app/admin/users"],
  ["admin.roles", "/app/admin/roles"],
  ["admin.providers", "/app/admin/providers"],
  ["admin.models", "/app/admin/models"],
  ["admin.settings", "/app/admin/settings"],
  ["admin.payments", "/app/admin/payments"],
  ["admin.audit", "/app/admin/audit"],
  ["admin.errors", "/app/admin/errors"],
  ["admin.health", "/app/admin/health"],
  ["admin.pricing", "/app/admin/pricing"],
  ["admin.plans", "/app/admin/plans"],
  ["admin.jobs", "/app/admin/jobs"],
  ["admin.security", "/app/admin/security"],
  ["admin.system", "/app/admin/system"],
  ["admin.backups", "/app/admin/backups"],
  ["invite", "/register?invite=probe-token"],
];

const AUDIT = () => {
  const TOL = 3;
  const out = [];
  const describe = (el) => {
    const tag = el.tagName.toLowerCase();
    const type = el.getAttribute("type");
    const id = el.id ? `#${el.id}` : "";
    const name = el.getAttribute("name") ? `[name=${el.getAttribute("name")}]` : "";
    const cls = (el.className || "").toString().split(/\s+/).filter(Boolean).slice(0, 3).join(".");
    const label = (el.closest(".field")?.querySelector(".field__label")?.textContent || el.textContent || "")
      .trim()
      .slice(0, 32);
    return `${tag}${type ? `[${type}]` : ""}${id}${name}${cls ? `.${cls}` : ""}${label ? ` “${label}”` : ""}`;
  };
  const visible = (el) => {
    const r = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && style.visibility !== "hidden" && style.display !== "none";
  };
  const controls = [...document.querySelectorAll("input, select, textarea, .btn")]
    .filter((el) => visible(el))
    .filter((el) => !["checkbox", "radio", "hidden", "file"].includes(el.getAttribute("type") || ""))
    .filter((el) => !el.closest(".sidebar, .topbar"))
    .map((el) => ({
      el,
      r: el.getBoundingClientRect(),
      container: el.closest(".grid, .row, .stack, .card__body, .modal__body, td, form, .kv, .page-head") || document.body,
    }));

  for (let i = 0; i < controls.length; i += 1) {
    for (let j = i + 1; j < controls.length; j += 1) {
      const a = controls[i];
      const b = controls[j];
      // Two controls in the same container that share a visual line must sit on the same baseline —
      // whether they are side by side (horizontal overlap) or in adjacent columns of a grid (no
      // horizontal overlap at all). The earlier version only compared horizontally overlapping
      // controls, which made it blind to exactly the case the operator complained about.
      if (a.container !== b.container) continue;
      const overlapY = Math.min(a.r.bottom, b.r.bottom) - Math.max(a.r.top, b.r.top);
      if (overlapY < Math.min(a.r.height, b.r.height) * 0.45) continue;
      const dTop = Math.abs(a.r.top - b.r.top);
      const dHeight = Math.abs(a.r.height - b.r.height);
      if (dTop > TOL) out.push({ kind: "ALIGN", detail: `${describe(a.el)} vs ${describe(b.el)}`, value: `${dTop.toFixed(1)}px` });
      if (dHeight > TOL) out.push({ kind: "HEIGHT", detail: `${describe(a.el)} vs ${describe(b.el)}`, value: `${dHeight.toFixed(1)}px` });
    }
  }

  for (const { el, r } of controls) {
    const isButton = el.classList.contains("btn");
    if (r.width < (isButton ? 64 : 72) && !el.classList.contains("btn--sm")) {
      out.push({ kind: "NARROW", detail: describe(el), value: `${r.width.toFixed(0)}px wide` });
    }
    const parent = el.parentElement?.closest(".card__body, .card, .modal__body, .grid, .row, .stack") || document.body;
    const pr = parent.getBoundingClientRect();
    if (r.right > pr.right + 2 && getComputedStyle(parent).overflowX === "visible") {
      out.push({ kind: "ESCAPE", detail: describe(el), value: `${(r.right - pr.right).toFixed(0)}px past its container` });
    }
  }

  const docOverflow = document.documentElement.scrollWidth - document.documentElement.clientWidth;
  if (docOverflow > 1) out.push({ kind: "HSCROLL", detail: "document", value: `${docOverflow}px` });
  return out;
};

(async () => {
  const fs = require("fs");
  fs.mkdirSync(SHOT_DIR, { recursive: true });
  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium",
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader", "--font-render-hinting=none"],
  });
  let problems = 0;
  const seen = new Set();
  for (const viewport of VIEWPORTS) {
    const page = await browser.newPage();
    await page.setViewport({ width: viewport.width, height: viewport.height, deviceScaleFactor: 1 });
    const consoleErrors = [];
    page.on("pageerror", (err) => consoleErrors.push(String(err).slice(0, 200)));

    // Sign in once per viewport (the register page is inspected while signed out).
    try {
      await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
      await page.type('input[type="email"]', EMAIL);
      await page.type('input[type="password"]', PASSWORD);
      await page.click('button[type="submit"]');
      await page.waitForFunction(() => window.location.pathname.startsWith("/app"), { timeout: 35000 });
    } catch (error) {
      // A failed sign-in makes every authenticated route irrelevant: report it as a problem instead of
      // scanning the sign-in screen thirty times and calling the result "clean".
      problems += 1;
      console.log(`!! sign-in failed at ${viewport.name}: ${String(error).slice(0, 140)}`);
    }

    for (const [name, route] of ROUTES) {
      const signedOut = ["landing", "login", "register"].includes(name);
      if (signedOut) {
        const anon = await browser.newPage();
        await anon.setViewport({ width: viewport.width, height: viewport.height });
        await anon.goto(`${BASE}${route}`, { waitUntil: "networkidle2" });
        const findings = await anon.evaluate(AUDIT);
        report(name, viewport.name, findings, anon);
        await anon.close();
        continue;
      }
      await page.goto(`${BASE}${route}`, { waitUntil: "networkidle2" });
      await new Promise((resolve) => setTimeout(resolve, 700));
      const findings = await page.evaluate(AUDIT);
      report(name, viewport.name, findings, page);
      if (name === "admin.settings" || name === "profile" || name === "register") {
        await page.screenshot({ path: `${SHOT_DIR}/${name}-${viewport.name}.png`, fullPage: false });
      }
    }
    if (consoleErrors.length) {
      console.log(`  JS errors at ${viewport.name}: ${consoleErrors.slice(0, 3).join(" | ")}`);
      problems += consoleErrors.length;
    }
    await page.close();
  }

  function report(name, viewport, findings, page) {
    const unique = [];
    for (const finding of findings) {
      const key = `${viewport}:${name}:${finding.kind}:${finding.detail}`;
      if (seen.has(key)) continue;
      seen.add(key);
      unique.push(finding);
    }
    if (!unique.length) return;
    problems += unique.length;
    console.log(`\n${name} @ ${viewport} — ${unique.length} finding(s)`);
    for (const item of unique.slice(0, 8)) console.log(`  ${item.kind}: ${item.detail} → ${item.value}`);
    if (unique.length > 8) console.log(`  … ${unique.length - 8} more`);
  }

  if (process.argv.includes("--self-test")) {
    // Prove the checker is not blind: shift one control in a two-column grid and require a finding.
    const page = await browser.newPage();
    await page.setViewport({ width: 1440, height: 900 });
    await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
    await page.addStyleTag({ content: "form .field:nth-child(1) input { margin-top: 14px }" });
    await page.evaluate(() => {
      const form = document.querySelector("form");
      if (form && form.children.length >= 2) {
        const style = document.createElement("style");
        style.textContent = "form { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem }";
        document.head.appendChild(style);
      }
    });
    await new Promise((resolve) => setTimeout(resolve, 400));
    const findings = await page.evaluate(AUDIT);
    const caught = findings.filter((item) => item.kind === "ALIGN" || item.kind === "HEIGHT");
    console.log(`\nSELF-TEST: injected a 14 px offset, checker reported ${caught.length} alignment finding(s)`);
    if (!caught.length) problems += 1;
    await page.close();
  }

  await browser.close();
  console.log(`\nTOTAL FINDINGS: ${problems}`);
  process.exit(problems ? 1 : 0);
})().catch((error) => {
  console.error(error);
  process.exit(2);
});
