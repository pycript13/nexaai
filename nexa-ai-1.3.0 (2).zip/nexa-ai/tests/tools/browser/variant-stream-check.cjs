/**
 * Proves the whole variant→stream pipeline through the UI, deterministically:
 *
 *   1. resolve a MOCK chat model from the catalogue (never a real provider — a canned
 *      check must not spend real credits, and its answer must be the identifiable echo);
 *   2. make sure that model carries a "code-only" sub-model, creating a temporary one
 *      through the real API when missing and deleting it afterwards;
 *   3. pick parent + sub-model in the chat composer and send a prompt with a unique marker;
 *   4. the streamed answer must contain the mock echo of exactly that marker;
 *   5. the mock upstream's request log must show OUR request — system prompt first
 *      (proving the variant's prompt was applied server-side), then the marked user text.
 *
 * Every assertion is pinned to this run's marker, so stale conversations or other
 * checkers' traffic can neither fake a pass nor cause a false alarm.
 *
 * Env: BASE_URL, UPSTREAM_URL, NEXA_EMAIL, NEXA_PASSWORD, OUT
 */
const puppeteer = require("puppeteer-core");
const BASE = process.env.BASE_URL || "http://127.0.0.1:8081";
const UPSTREAM = process.env.UPSTREAM_URL || "http://127.0.0.1:9099";
const OUT = process.env.OUT || "/home/user/responsive-shots/features/chat-stream-with-variant.png";
const MARKER = `variant-stream-${Date.now().toString(36)}`;
const PROMPT = `${MARKER}: write a python function to reverse a string`;
const SYSTEM_PROMPT = "You only write code. Never add explanations. Reply in the user's language.";

const problems = [];
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const log = (label, value) => console.log(`${label.padEnd(26)}-> ${value}`);

(async () => {
  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium",
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader"],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 1000 });

  // ---- sign in -------------------------------------------------------------
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
  await page.type('input[type="email"]', process.env.NEXA_EMAIL || "admin@example.com");
  await page.type('input[type="password"]', process.env.NEXA_PASSWORD || "");
  await Promise.all([
    page.waitForNavigation({ waitUntil: "networkidle2" }).catch(() => {}),
    page.click('button[type="submit"]'),
  ]);
  if (!page.url().includes("/app")) {
    console.error("FAILED: sign-in did not reach /app");
    process.exit(2);
  }

  // ---- 1+2. a mock model carrying a code-only variant -----------------------
  const setup = await page.evaluate(async ({ systemPrompt, marker }) => {
    const csrf = (document.cookie.match(/(?:^|;\s*)nexa_csrf=([^;]+)/) || [])[1] || "";
    const catalogue = await fetch("/api/v1/models?page_size=100", { headers: { accept: "application/json" } })
      .then((response) => response.json())
      .catch(() => ({}));
    const mock = (catalogue.items || []).find((model) => /mock chat/i.test(model.display_name || ""));
    if (!mock) return { error: "no mock chat model in the catalogue" };
    const listing = await fetch(`/api/v1/models/${mock.id}/variants`, { headers: { accept: "application/json" } })
      .then((response) => response.json())
      .catch(() => ({}));
    let variant = (listing.items || []).find((row) => (row.system_prompt || "").includes("only write code") && row.enabled !== false);
    let created = false;
    if (!variant) {
      const response = await fetch(`/api/v1/models/${mock.id}/variants`, {
        method: "POST",
        headers: { "content-type": "application/json", "x-csrf-token": csrf },
        body: JSON.stringify({ name: `Stream check ${marker}`, system_prompt: systemPrompt }),
      });
      if (response.status !== 201) return { error: `creating the temporary variant failed (HTTP ${response.status})` };
      variant = (await response.json()).variant;
      created = true;
    }
    return { modelId: String(mock.id), modelName: mock.display_name, variantId: variant.id, variantName: variant.name, created };
  }, { systemPrompt: SYSTEM_PROMPT, marker: MARKER });

  if (setup.error) {
    console.error("FAILED:", setup.error);
    await browser.close();
    process.exit(2);
  }
  log("mock model", `${setup.modelName} (#${setup.modelId})`);
  log("code-only sub-model", `${setup.variantName} (#${setup.variantId}${setup.created ? ", created for this run" : ", already present"})`);

  // ---- 3. composer: parent model, then the sub-model ------------------------
  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle2" });
  await sleep(1500);
  const parent = await page.evaluate((id) => {
    const select = document.querySelector(".composer select");
    if (!select) return null;
    const option = [...select.options].find((item) => item.value === id);
    if (!option) return null;
    select.value = id;
    select.dispatchEvent(new Event("change", { bubbles: true }));
    return option.textContent.trim();
  }, setup.modelId);
  if (!parent) problems.push(`the composer did not offer the mock model #${setup.modelId}`);
  else log("parent selected", parent);
  await sleep(1200);

  const chosen = await page.evaluate((needle) => {
    const selects = [...document.querySelectorAll(".composer select")];
    const picker = selects.find((select) => [...select.options].some((option) => (option.textContent || "").includes(needle)));
    if (!picker) return null;
    const option = [...picker.options].find((item) => (item.textContent || "").includes(needle));
    picker.value = option.value;
    picker.dispatchEvent(new Event("change", { bubbles: true }));
    return option.textContent.trim();
  }, setup.variantName);
  if (!chosen) problems.push("the variant picker did not offer the code-only sub-model");
  else log("sub-model selected", chosen);

  // ---- 4. send the marked prompt and wait for the echoed answer -------------
  await page.type(".composer textarea", PROMPT);
  await sleep(300);
  await page.evaluate(() => {
    const send = [...document.querySelectorAll(".composer button")].find((button) =>
      /send|ارسال/i.test(button.textContent || "") || /send|ارسال/i.test(button.getAttribute("aria-label") || ""),
    );
    if (send) send.click();
  });
  try {
    await page.waitForFunction(
      (marker) => Array.from(document.querySelectorAll(".bubble--assistant")).some((node) =>
        (node.textContent || "").includes(`mock-answer: ${marker}`),
      ),
      { timeout: 45000 },
      MARKER,
    );
    log("answer streamed", `the thread shows “mock-answer: ${MARKER}…”`);
  } catch {
    problems.push("no streamed answer containing this run's marker arrived within 45s");
  }
  await sleep(600);
  await page.screenshot({ path: OUT, fullPage: true }).catch(() => undefined);

  // ---- 5. the upstream saw OUR request, system prompt first -----------------
  let mine = null;
  for (let attempt = 0; attempt < 10 && !mine; attempt += 1) {
    const upstream = await fetch(`${UPSTREAM}/__requests`).then((response) => response.json()).catch(() => ({ requests: [] }));
    mine = [...(upstream.requests || [])].reverse().find((entry) => {
      if (!String(entry.path || "").endsWith("/chat/completions")) return false;
      const messages = (entry.body || {}).messages || [];
      return messages.some((message) => String(message.content || "").includes(MARKER));
    });
    if (!mine) await sleep(700);
  }
  if (!mine) {
    problems.push("the mock upstream never received this run's marked request");
  } else {
    const messages = (mine.body || {}).messages || [];
    const system = messages.find((message) => message.role === "system");
    log("upstream messages", JSON.stringify(messages.map((message) => message.role)).slice(0, 120));
    if (system && String(system.content || "").includes("only write code")) log("system prompt applied", true);
    else problems.push("the variant's system prompt was not sent to the provider");
  }

  // ---- cleanup: only remove what this run created ---------------------------
  if (setup.created) {
    const removed = await page.evaluate(async (variantId) => {
      const csrf = (document.cookie.match(/(?:^|;\s*)nexa_csrf=([^;]+)/) || [])[1] || "";
      const response = await fetch(`/api/v1/models/variants/${variantId}`, { method: "DELETE", headers: { "x-csrf-token": csrf } });
      return response.status;
    }, setup.variantId);
    log("cleanup", removed === 200 ? "the temporary sub-model was deleted" : `DELETE returned HTTP ${removed}`);
    if (removed !== 200) problems.push(`the temporary variant could not be deleted (HTTP ${removed})`);
  }

  await browser.close();
  console.log(`\nPROBLEMS: ${problems.length}`);
  for (const problem of problems) console.log(`  ✗ ${problem}`);
  process.exit(problems.length ? 1 : 0);
})().catch((error) => {
  console.error("FAILED:", error.message);
  process.exit(2);
});
