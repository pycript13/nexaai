#!/usr/bin/env node
/**
 * Round-16 LIVE proof: the bot streams a real answer into a real Telegram chat.
 *
 * An update is injected through the platform's own fail-closed webhook (the exact handler
 * Telegram calls), from the owner's registered numeric id. The bot then talks to the REAL
 * api.telegram.org with the REAL bot token: it opens a placeholder message with a ▍ cursor
 * and edits it as the model writes (throttled to Telegram's edit budget), finalising it with
 * the footer and the glass action row. The owner sees the answer grow live on their phone.
 *
 * What this script verifies:
 *   * the webhook handles the injected update and reports handled:"answer";
 *   * the service log shows the live-stream summary line with N ≥ 1 in-loop edits and
 *     fallback=false — proof the answer really streamed through edits, not one shot;
 *   * no delivery error was logged during the turn.
 *
 * Usage: node live-stream-check.cjs [baseUrl] <adminEmail> <adminPassword> <ownerTelegramId> [prompt]
 */
const fs = require("fs");
const BASE = (process.argv[2] || "http://127.0.0.1:8081").replace(/\/$/, "");
const EMAIL = process.argv[3] || "";
const PASSWORD = process.argv[4] || "";
const OWNER_ID = Number(process.argv[5] || 0);
const PROMPT =
  process.argv[6] ||
  "لطفاً در سه پاراگراف کوتاه توضیح بده: روتر هوش مصنوعی چیست، چرا پخش زندهٔ پاسخ در تلگرام تجربهٔ بهتری است، و سقف مصرف روزانه چطور کار می‌کند.";
const LOG = "/home/user/preview-data/preview.log";

if (!OWNER_ID) {
  console.error("owner telegram id is required");
  process.exit(2);
}

const problems = [];
const ok = (m) => console.log(`  ✓ ${m}`);
const fail = (m) => {
  problems.push(m);
  console.log(`  ✗ ${m}`);
};
const check = (c, m) => (c ? ok(m) : fail(m));

const makeSession = () => {
  const session = { cookie: "", csrf: "" };
  const request = async (path, { method = "GET", body = null } = {}) => {
    const headers = {};
    if (body) headers["content-type"] = "application/json";
    if (session.cookie) headers.cookie = session.cookie;
    if (method !== "GET" && session.csrf) headers["x-csrf-token"] = session.csrf;
    const response = await fetch(`${BASE}${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined });
    const setCookie = response.headers.getSetCookie?.() || [];
    if (setCookie.length) {
      session.cookie = setCookie.map((entry) => entry.split(";")[0]).join("; ");
      const csrf = setCookie.find((entry) => entry.startsWith("nexa_csrf="));
      if (csrf) session.csrf = csrf.split("=")[1].split(";")[0];
    }
    let payload = null;
    try {
      payload = await response.json();
    } catch {
      payload = null;
    }
    return { status: response.status, body: payload };
  };
  return { request };
};

(async () => {
  const logBefore = fs.existsSync(LOG) ? fs.statSync(LOG).size : 0;

  const admin = makeSession();
  const login = await admin.request("/api/v1/auth/login", { method: "POST", body: { email: EMAIL, password: PASSWORD } });
  if (login.status !== 200) {
    console.error(`admin sign-in failed: ${login.status}`);
    process.exit(2);
  }
  ok("admin signed in");

  const secret = `live-stream-secret-${Date.now().toString().slice(-6)}`;
  const secretSave = await admin.request("/api/v1/admin/telegram/webhook-secret", { method: "PUT", body: { secret } });
  check(secretSave.status === 200, `webhook secret stored (HTTP ${secretSave.status})`);

  const update = {
    update_id: Math.floor(Math.random() * 1e9),
    message: {
      message_id: Math.floor(Math.random() * 1e6),
      date: Math.floor(Date.now() / 1000),
      chat: { id: OWNER_ID, type: "private" },
      from: { id: OWNER_ID, is_bot: false, first_name: "Owner" },
      text: PROMPT,
    },
  };

  console.log(`  … injecting a live prompt for chat ${OWNER_ID} (the real bot will stream into real Telegram)…`);
  const started = Date.now();
  const response = await fetch(`${BASE}/api/v1/telegram/webhook`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-telegram-bot-api-secret-token": secret },
    body: JSON.stringify(update),
  });
  let body = null;
  try {
    body = await response.json();
  } catch {
    body = null;
  }
  const seconds = ((Date.now() - started) / 1000).toFixed(1);
  check(response.status === 200 && body?.handled === "answer", `the bot handled the turn in ${seconds}s (handled=${body?.handled})`);

  await new Promise((r) => setTimeout(r, 800));
  const fresh = fs.existsSync(LOG)
    ? fs.readFileSync(LOG, "utf8").slice(logBefore)
    : "";
  const streamLine = (fresh.match(/telegram: live stream to chat .*finished: [^\n]+/) || [])[0] || "";
  console.log(`  log: ${streamLine || "<no live-stream line found>"}`);
  const editsMatch = streamLine.match(/finished: (\d+) in-loop edit\(s\), (\d+) chars, fallback=(\w+)/);
  check(!!editsMatch, "the service logged the live-stream summary");
  if (editsMatch) {
    const edits = Number(editsMatch[1]);
    const chars = Number(editsMatch[2]);
    check(edits >= 1, `the answer really streamed through ${edits} live edit(s) of the same message (${chars} chars)`);
    check(editsMatch[3] === "False", "no fallback was needed — Telegram accepted the streaming edits");
  }
  const deliveryErrors = fresh.split("\n").filter((l) => /telegram.*(delivery|failed|error)/i.test(l) && !/error_note|live stream/.test(l));
  check(deliveryErrors.length === 0, `no delivery errors were logged (${deliveryErrors.length})`);
  deliveryErrors.slice(0, 3).forEach((l) => console.log(`    ! ${l.trim().slice(0, 160)}`));

  console.log(`\nPROBLEMS: ${problems.length}`);
  problems.forEach((p) => console.log(`  - ${p}`));
  process.exit(problems.length ? 1 : 0);
})().catch((error) => {
  console.error("CHECKER CRASHED:", error.message);
  process.exit(2);
});
