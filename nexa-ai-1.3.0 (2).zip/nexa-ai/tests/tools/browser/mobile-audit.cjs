/**
 * Mobile responsiveness audit + screenshots.
 *
 * Loads the real SPA (served by the preview stack) at phone/tablet/desktop widths, signs in,
 * then reports *measured* problems instead of impressions:
 *   - horizontal overflow (document wider than the viewport)
 *   - elements sticking out of the viewport (left/right)
 *   - tap targets smaller than 40x40 CSS px
 *   - text smaller than 11 px
 *   - tables without a scroll container
 * Writes one screenshot per (page, viewport) into /home/user/responsive-shots.
 */
const fs = require("fs");
const path = require("path");
const puppeteer = require("puppeteer-core");

const BASE = process.env.BASE_URL || "http://127.0.0.1:8081";
const OUT = process.env.OUT_DIR || "/home/user/responsive-shots";
const EMAIL = process.env.NEXA_EMAIL || "admin@example.com";
const PASSWORD = process.env.NEXA_PASSWORD || "";

const VIEWPORTS = [
  { name: "iphone-se", width: 375, height: 667, dpr: 2, mobile: true },
  { name: "iphone-14", width: 390, height: 844, dpr: 3, mobile: true },
  { name: "pixel-7", width: 412, height: 915, dpr: 2.6, mobile: true },
  { name: "ipad-mini", width: 768, height: 1024, dpr: 2, mobile: true },
  { name: "laptop", width: 1440, height: 900, dpr: 1, mobile: false },
];

const PAGES = [
  ["login", "/login"],
  ["dashboard", "/app"],
  ["chat", "/app/chat"],
  ["models", "/app/models"],
  ["images", "/app/images"],
  ["billing", "/app/billing"],
  ["profile", "/app/profile"],
  ["admin-providers", "/app/admin/providers"],
  ["admin-models", "/app/admin/models"],
  ["admin-users", "/app/admin/users"],
  ["admin-settings", "/app/admin/settings"],
];

const AUDIT = () => {
  const problems = [];
  const vw = document.documentElement.clientWidth;
  if (document.documentElement.scrollWidth > vw + 1) {
    problems.push({
      kind: "page-overflow",
      detail: `document scrollWidth ${document.documentElement.scrollWidth} > viewport ${vw}`,
    });
  }
  const describe = (el) => {
    const cls = (el.className || "").toString().split(/\s+/).slice(0, 3).join(".");
    const text = (el.textContent || "").trim().slice(0, 40);
    return `${el.tagName.toLowerCase()}${cls ? "." + cls : ""}${text ? ` "${text}"` : ""}`;
  };
  const seen = new Set();
  for (const el of document.querySelectorAll("body *")) {
    const style = getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) continue;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) continue;
    const key = describe(el);
    // The sidebar is a deliberate off-canvas drawer on small screens: it parks outside the
    // viewport until the menu button opens it. Ignore everything inside a *closed* drawer,
    // otherwise every audit reports the same false positive.
    const closedDrawer = el.closest(".sidebar:not(.sidebar--open), .sidebar-backdrop:not(.sidebar-backdrop--open)");
    if (closedDrawer) continue;
    // off-screen horizontally (drawers parked outside are legitimately negative-left)
    const parked = style.transform && style.transform !== "none" && (rect.right < 0 || rect.left > vw);
    if (rect.right > vw + 1 && style.position !== "fixed" && !parked) {
      const nearestScrollable = (() => {
        let node = el.parentElement;
        while (node && node !== document.body) {
          const s = getComputedStyle(node);
          if (/(auto|scroll)/.test(s.overflowX) && node.scrollWidth > node.clientWidth) return node;
          node = node.parentElement;
        }
        return null;
      })();
      if (!nearestScrollable && !seen.has("overflow:" + key)) {
        seen.add("overflow:" + key);
        problems.push({ kind: "off-viewport-right", detail: `${key} right=${Math.round(rect.right)} > ${vw}` });
      }
    }
    const minTarget = window.innerWidth <= 960 ? 40 : 30;
    // A checkbox/radio is never drawn as a 40px square; its label owns the hit area.
    if (el.tagName === "INPUT" && (el.type === "checkbox" || el.type === "radio")) continue;
    const smallTarget = rect.width + 0.5 < minTarget || rect.height + 0.5 < minTarget;
    const interactive = ["BUTTON", "A", "INPUT", "SELECT", "TEXTAREA"].includes(el.tagName) ||
      el.getAttribute("role") === "button";
    if (interactive && smallTarget && rect.width > 0 && !seen.has("tap:" + key)) {
      const parentSmall = el.parentElement && el.parentElement.closest(".iconbtn, .tabs, .chip, .pill, .nav__link");
      if (!parentSmall) {
        seen.add("tap:" + key);
        problems.push({ kind: "small-tap-target", detail: `${key} ${Math.round(rect.width)}x${Math.round(rect.height)}` });
      }
    }
    const fs = parseFloat(style.fontSize || "16");
    if (fs < 11 && (el.textContent || "").trim().length > 3 && !seen.has("font:" + key)) {
      seen.add("font:" + key);
      problems.push({ kind: "tiny-text", detail: `${key} font-size ${fs}px` });
    }
  }
  return problems.slice(0, 25);
};

async function main() {
  fs.mkdirSync(OUT, { recursive: true });
  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium",
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader"],
  });
  const report = {};
  try {
    const context = browser.defaultBrowserContext();
    const page = await browser.newPage();
    await page.setViewport({ width: 1440, height: 900 });
    await page.goto(`${BASE}/login`, { waitUntil: "networkidle2", timeout: 45000 });
    if (PASSWORD) {
      await page.type('input[type="email"]', EMAIL);
      await page.type('input[type="password"]', PASSWORD);
      await page.click('button[type="submit"]');
      await page.waitForFunction(() => !location.pathname.includes("/login"), { timeout: 20000 });
    }
    const cookies = await page.cookies();

    const only = (process.env.VIEWPORTS || "").split(",").map((x) => x.trim()).filter(Boolean);
    for (const vp of VIEWPORTS.filter((entry) => !only.length || only.includes(entry.name))) {
      const p = await browser.newPage();
      await p.setViewport({ width: vp.width, height: vp.height, deviceScaleFactor: vp.dpr, isMobile: vp.mobile, hasTouch: vp.mobile });
      await p.setCookie(...cookies);
      report[vp.name] = {};
      for (const [name, url] of PAGES) {
        try {
          await p.goto(`${BASE}${url}`, { waitUntil: "networkidle2", timeout: 45000 });
          await new Promise((r) => setTimeout(r, 450));
          const problems = await p.evaluate(AUDIT);
          report[vp.name][name] = problems;
          // A screenshot stall (SwiftShader under a mobile DPR) must not masquerade as a page
          // problem — the measurement above already succeeded, so label the harness failure.
          try {
            await p.screenshot({ path: path.join(OUT, `${vp.name}--${name}.png`), fullPage: false, protocolTimeout: 60000 });
          } catch (shotError) {
            report[vp.name][name].push({ kind: "screenshot-error", detail: String(shotError).slice(0, 160) });
          }
        } catch (error) {
          report[vp.name][name] = [{ kind: "navigation-error", detail: String(error).slice(0, 160) }];
        }
      }
      await p.close();
    }
  } finally {
    await browser.close();
  }

  let total = 0;
  let harness = 0;
  for (const [vp, pages] of Object.entries(report)) {
    const counts = Object.entries(pages).map(([name, list]) => {
      total += list.filter((x) => x.kind !== "navigation-error" && x.kind !== "screenshot-error").length;
      harness += list.filter((x) => x.kind === "navigation-error" || x.kind === "screenshot-error").length;
      return list.length ? `${name}:${list.length}` : null;
    }).filter(Boolean);
    console.log(`${vp.padEnd(12)} ${counts.length ? counts.join("  ") : "clean"}`);
  }
  fs.writeFileSync(path.join(OUT, "report.json"), JSON.stringify(report, null, 2));
  console.log(`\ntotal measured problems: ${total}`);
  console.log(`harness failures (navigation/screenshot — evidence gaps, not page defects): ${harness}`);
  console.log(`screenshots: ${OUT}`);
}

main().catch((error) => { console.error(error); process.exit(1); });
