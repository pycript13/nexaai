const puppeteer = require("puppeteer-core");
const BASE = "http://127.0.0.1:8081";
(async () => {
  const browser = await puppeteer.launch({ executablePath: "/usr/bin/chromium", args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader"] });
  const page = await browser.newPage();
  page.setCacheEnabled(false);
  await page.setViewport({ width: 1440, height: 1200 });
  await page.goto(BASE + "/", { waitUntil: "networkidle2", timeout: 45000 });
  await new Promise(r => setTimeout(r, 1000));
  await page.screenshot({ path: "/tmp/shot-landing-dark2.png" });
  await page.evaluate(() => localStorage.setItem("nexa.theme", "light"));
  await page.reload({ waitUntil: "networkidle2" }); await new Promise(r => setTimeout(r, 800));
  await page.screenshot({ path: "/tmp/shot-landing-light2.png" });
  await page.evaluate(() => localStorage.setItem("nexa.theme", "dark"));
  await page.setViewport({ width: 390, height: 844 });
  await page.reload({ waitUntil: "networkidle2" }); await new Promise(r => setTimeout(r, 800));
  await page.screenshot({ path: "/tmp/shot-landing-mobile2.png" });
  await browser.close(); console.log("guest shots done");
})().catch(e => { console.error("FAILED:", e.message); process.exit(1); });
