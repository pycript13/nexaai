#!/usr/bin/env node
/**
 * Round 12 acceptance in a real browser.
 *
 *   1. Admin → Settings → Telegram: the operator types the bot token in the panel (no `.env`),
 *      saves it, watches the card flip to “Running”, and presses Test — the panel performs a real
 *      `getMe` against Telegram and reports the bot identity. Then the command menu is published and
 *      a one-time link code is created from a user profile.
 *   2. Admin → Users: the operator creates an account with two roles and an initial credit; the
 *      generated password is shown once.
 *   3. The account created that way signs in, sees the workspace, and is refused by the admin API —
 *      ordinary users stay policy-bound.
 *
 * Usage: node check-round12.cjs [baseUrl] [adminEmail] [adminPassword] [botToken]
 */
const puppeteer = require("puppeteer-core");

const BASE = (process.argv[2] || "http://127.0.0.1:8081").replace(/\/$/, "");
const ADMIN_EMAIL = process.argv[3] || "admin@example.com";
const ADMIN_PASSWORD = process.argv[4] || "Nexa-Preview-Admin-2026!";
const BOT_TOKEN = process.argv[5] || "";
const SHOT_DIR = process.env.SHOT_DIR || "/tmp/nexa-round12";

const problems = [];
const ok = (message) => console.log(`  ✓ ${message}`);
const note = (message) => console.log(`  · ${message}`);
const fail = (message) => {
  problems.push(message);
  console.log(`  ✗ ${message}`);
};

const typeInto = async (page, selector, value) => {
  const handle = await page.$(selector);
  if (!handle) throw new Error(`missing ${selector}`);
  await handle.click({ clickCount: 3 });
  await handle.type(value);
};

(async () => {
  const fs = require("fs");
  fs.mkdirSync(SHOT_DIR, { recursive: true });
  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium",
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader"],
  });
  /** Sign in and wait for the workspace to appear. Retries once: a cold API can be slow. */
  const signInAs = async (email, password) => {
    const page = await browser.newPage();
    await page.setViewport({ width: 1440, height: 1000 });
    for (let attempt = 1; attempt <= 2; attempt += 1) {
      await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
      await page.type('input[type="email"]', email);
      await page.type('input[type="password"]', password);
      await page.click('button[type="submit"]');
      try {
        await page.waitForFunction(() => window.location.pathname.startsWith("/app"), { timeout: 30000 });
        return page;
      } catch (error) {
        if (attempt === 2) throw error;
        await new Promise((resolve) => setTimeout(resolve, 1500));
      }
    }
    return page;
  };

  const signIn = async (email, password) => {
    const page = await signInAs(email, password);
    await new Promise((resolve) => setTimeout(resolve, 600));
    return page;
  };

  const admin = await signIn(ADMIN_EMAIL, ADMIN_PASSWORD);
  if (!admin.url().includes("/app")) fail(`admin sign-in failed (${admin.url()})`);

  // ---------------------------------------------------------------- 1. Telegram settings card
  console.log("\n== Admin → Settings → Telegram");
  await admin.goto(`${BASE}/app/admin/settings`, { waitUntil: "networkidle2" });
  await new Promise((resolve) => setTimeout(resolve, 900));
  const cardText = await admin.$eval("body", (el) => el.innerText);
  if (!/Telegram|تلگرام|تلغرام|تێلێگرام/.test(cardText)) fail("no Telegram card on the settings page");
  else ok("the Telegram card is present on Admin → Settings");
  const formCount = await admin.$$eval('input[type="password"]', (els) => els.length);
  if (!formCount) fail("the Telegram card has no token field");
  else ok(`${formCount} write-only field(s) on the card (token + webhook secret)`);

  if (BOT_TOKEN) {
    await typeInto(admin, 'input[type="password"]', BOT_TOKEN);
    const saveButtons = await admin.$$("xpath///button[contains(., 'ذخیرهٔ توکن') or contains(., 'Save token')]");
    if (!saveButtons.length) fail("no “Save token” button");
    await saveButtons[0].click();
    await new Promise((resolve) => setTimeout(resolve, 2500));
    const after = await admin.$eval("body", (el) => el.innerText);
    if (/ذخیره و رمزنگاری شد|saved and encrypted/i.test(after)) ok("the token was accepted and stored (encrypted)");
    else fail("saving the token produced no confirmation");
    if (/در حال اجرا|Running/.test(after)) ok("the card turned green: the bot is running");
    else fail("the card did not report a running bot");
    if (/database/.test(after)) ok("the panel reports the token source as `database` (not the environment file)");

    // Watch the real request the panel makes: the assertion is on Telegram's own answer.
    let testPayload = null;
    admin.on("response", async (response) => {
      if (response.url().includes("/api/v1/admin/telegram/test")) {
        try {
          testPayload = { status: response.status(), body: await response.json() };
        } catch {
          testPayload = { status: response.status(), body: null };
        }
      }
    });
    const buttons = await admin.$$("button");
    let clickedTest = false;
    for (const button of buttons) {
      const label = (await button.evaluate((el) => el.textContent || "")).trim();
      if (!/تست|آزمون|^Test/.test(label) || /حذف|Remove/i.test(label)) continue;
      await button.click();
      await new Promise((resolve) => setTimeout(resolve, 4000));
      clickedTest = true;
      break;
    }
    if (!clickedTest) fail("no Test button on the Telegram card");
    if (testPayload && testPayload.status === 200 && testPayload.body?.bot?.username) {
      ok(`the Test button really called Telegram: getMe answered @${testPayload.body.bot.username} (source: ${testPayload.body.token_source})`);
    } else {
      fail(`the Test button did not reach Telegram (payload: ${JSON.stringify(testPayload).slice(0, 200)})`);
    }

    const commandButtons = await admin.$$("xpath///button[contains(., 'انتشار فهرست فرمان‌ها') or contains(., 'Publish command menu')]");
    if (commandButtons.length) {
      await commandButtons[0].click();
      await new Promise((resolve) => setTimeout(resolve, 2500));
      const body = await admin.$eval("body", (el) => el.innerText);
      if (/فهرست فرمان‌ها به تلگرام|command menu was sent/i.test(body)) ok("the command menu was published to Telegram");
      else fail("publishing the command menu reported no success");
    }
  } else {
    console.log("  · skipped the token-entry steps (no token passed on the command line)");
  }
  await admin.screenshot({ path: `${SHOT_DIR}/admin-settings-telegram.png` });

  // ---------------------------------------------------------------- 2. Create a user with roles
  console.log("\n== Admin → Users → create a user with roles");
  await admin.goto(`${BASE}/app/admin/users`, { waitUntil: "networkidle2" });
  await new Promise((resolve) => setTimeout(resolve, 900));
  const createButtons = await admin.$$("xpath///button[contains(., 'ساخت کاربر') or contains(., 'Create a user')]");
  if (!createButtons.length) fail("no “create a user” button on Admin → Users");
  await createButtons[0]?.click();
  await new Promise((resolve) => setTimeout(resolve, 700));
  const dialog = await admin.$(".modal");
  if (!dialog) fail("the create-user dialog did not open");
  const checkboxCount = await admin.$$eval(".modal .pill-list input[type=checkbox]", (els) => els.length);
  if (checkboxCount < 6) fail(`the dialog offers ${checkboxCount} roles, expected the full catalogue (6)`);
  else ok(`the role picker lists ${checkboxCount} roles`);
  const email = `panel-${Date.now().toString().slice(-6)}@example.org`;
  await typeInto(admin, '.modal input[type="email"]', email);
  await typeInto(admin, '.modal input[type="text"]', "Panel Created");
  // Pick “support_agent” on top of the default “user”.
  const support = await admin.$$(".modal .pill-list input[type=checkbox]");
  const labels = await admin.$$eval(".modal .pill-list label", (els) => els.map((el) => el.textContent.trim()));
  const index = labels.findIndex((label) => /support_agent/.test(label));
  if (index >= 0) await support[index].click();
  const credit = await admin.$('.modal input[type="number"]');
  if (credit) {
    await credit.click({ clickCount: 3 });
    await credit.type("25");
  }
  const confirmBox = await admin.$(".modal input[type=checkbox], .modal .confirm input");
  const boxes = await admin.$$(".modal input[type=checkbox]");
  await boxes[boxes.length - 1].click();
  const createSubmit = await admin.$$("xpath///button[contains(., 'بساز') or contains(., 'Create')]");
  const submitButton = createSubmit[createSubmit.length - 1];
  await submitButton.click();
  await new Promise((resolve) => setTimeout(resolve, 2500));
  const resultText = await admin.$eval("body", (el) => el.innerText);
  if (resultText.includes(email)) ok(`the account ${email} was created from the panel`);
  else fail("the create-user dialog did not confirm the new account");
  // The password lives in a read-only input (innerText does not include input values).
  const password = await admin.$$eval(".modal input", (els) => {
    const found = els.map((el) => el.value).find((value) => value && value.startsWith("Nx-"));
    return found || null;
  });
  if (password) ok(`a one-time password was shown (${password.slice(0, 6)}…)`);
  else fail("no generated password was shown after creating the user");
  const copyButton = await admin.$(".modal .btn");
  if (copyButton) ok("the dialog offers a copy button for the one-time password");
  if (/support_agent/.test(resultText)) ok("the roles were applied as chosen");
  await admin.screenshot({ path: `${SHOT_DIR}/admin-users-create.png` });

  // ---------------------------------------------------------------- 3. The new user's limits
  console.log("\n== the account created by the panel");
  if (password) {
    const member = await signIn(email, password);
    if (member.url().includes("/app")) ok("the new account signs in with the password the panel showed");
    else fail(`the new account could not sign in (${member.url()})`);

    // What the chosen roles must and must not open. `support_agent` legitimately carries `users.read`
    // (customer support needs it) but nothing in the settings, provider or user-creation area.
    const probes = await member.evaluate(async () => {
      const call = async (path, method = "GET", body = null) => {
        const response = await fetch(path, {
          method,
          credentials: "include",
          headers: body ? { "content-type": "application/json" } : undefined,
          body: body ? JSON.stringify(body) : undefined,
        });
        return { path, status: response.status };
      };
      return [
        await call("/api/v1/admin/users?page=1"),
        await call("/api/v1/admin/settings"),
        await call("/api/v1/admin/providers"),
        await call("/api/v1/admin/users", "POST", { email: "x@example.org", display_name: "x", confirm: true }),
        await call("/api/v1/admin/telegram/status"),
      ];
    });
    const status = Object.fromEntries(probes.map((probe) => [probe.path, probe.status]));
    const expects = [
      ["/api/v1/admin/users?page=1", [200], "users.read (support role)"],
      ["/api/v1/admin/settings", [403], "settings.manage"],
      ["/api/v1/admin/providers", [403], "providers.read"],
      ["/api/v1/admin/users", [403], "users.create"],
      ["/api/v1/admin/telegram/status", [403], "settings.manage (Telegram card)"],
    ];
    for (const [path, allowed, label] of expects) {
      const found = status[path];
      if (allowed.includes(found)) ok(`${path} → ${found} (needs ${label})`);
      else fail(`${path} answered ${found}, expected ${allowed.join(" or ")} for ${label}`);
    }

    await member.goto(`${BASE}/app/admin/settings`, { waitUntil: "networkidle2" });
    await new Promise((resolve) => setTimeout(resolve, 900));
    const adminBody = await member.$eval("body", (el) => el.innerText).catch(() => "");
    if (/403|دسترسی|forbidden|ندارید|مجاز/i.test(adminBody)) ok("the admin screen shows a permission notice instead of data");
    else fail("the admin screen did not explain the missing permission");
    await member.screenshot({ path: `${SHOT_DIR}/member-admin-blocked.png` });

    // ---------------------------------------------------------------- 4. the profile card
    console.log("\n== Profile → Telegram (the user's side of the bot gate)");
    await member.goto(`${BASE}/app/profile`, { waitUntil: "networkidle2" });
    await new Promise((resolve) => setTimeout(resolve, 900));
    const profileText = await member.$eval("body", (el) => el.innerText);
    if (/Telegram|تلگرام|تلغرام|تێلێگرام/.test(profileText)) ok("the profile shows the Telegram card");
    else fail("the profile has no Telegram card");
    const numericField = await member.$('input[inputmode="numeric"]');
    if (!numericField) {
      fail("the profile card has no numeric-id field");
    } else {
      const telegramId = String(780000000 + Math.floor(Math.random() * 999999));
      await numericField.type(telegramId);
      const saveButton = await member.$$("xpath///button[contains(., 'ذخیره') or contains(., 'Save')]");
      await saveButton[saveButton.length - 1].click();
      await new Promise((resolve) => setTimeout(resolve, 2000));
      const after = await member.$eval("body", (el) => el.innerText);
      if (after.includes(telegramId)) ok(`the numeric id ${telegramId} is shown as registered on the profile`);
      else fail("the numeric id was not confirmed on the profile");
      if (/شناسهٔ تلگرام شما ثبت شد|Telegram id is registered/i.test(after)) ok("the user is told the bot will recognise them");
      else fail("no confirmation message after saving the numeric id");
    }
    const codeButtons = await member.$$("xpath///button[contains(., 'کد یک‌بارمصرف') or contains(., 'one-time code')]");
    if (!codeButtons.length) {
      fail("the profile card does not offer the one-time code path");
    } else {
      await codeButtons[0].click();
      await new Promise((resolve) => setTimeout(resolve, 2000));
      const codeBody = await member.$eval("body", (el) => el.innerText);
      const codeMatch = codeBody.match(/\/start\s+([A-Z0-9]{4,})/i);
      if (codeMatch) {
        ok(`the panel issued a one-time code (${codeMatch[1]}) with the /start command to send`);
      } else if (/not configured|تنظیم نشده|پیکربندی نشده/i.test(codeBody)) {
        // Honest skip: without a bot token the panel *must* refuse to mint a code. Set the token in
        // Admin → Settings → Telegram (or install a stack that has one) to exercise this path.
        note("the Telegram bot is not configured on this deployment — the one-time code path is untested here");
      } else {
        fail("no /start command was shown after requesting a link code");
      }
    }
    await member.screenshot({ path: `${SHOT_DIR}/member-profile-telegram.png` });
    await member.close();
  } else {
    fail("cannot verify the new account: no password was captured");
  }

  await admin.close();
  await browser.close();
  console.log(`\nPROBLEMS: ${problems.length}`);
  process.exit(problems.length ? 1 : 0);
})().catch((error) => {
  console.error(error);
  process.exit(2);
});
