#!/usr/bin/env node
/**
 * Answer-variant carousel, verified live: regeneration keeps the previous answer
 * as a pageable variant instead of destroying it.
 *
 *   * send -> regenerate: the carousel appears at "2 / 2" and only one bubble shows;
 *   * prev pages to "1 / 2"; the switch persists server-side (activate-variant), so
 *     after a full page reload the conversation opens on the activated variant;
 *   * no page errors during the whole flow.
 *
 * Usage: node check-variant-carousel.cjs [baseUrl] <email> <password>
 */
const BASE = (process.argv[2] || "http://127.0.0.1:8081").replace(/\/$/, "");
const EMAIL = process.argv[3] || "";
const PASSWORD = process.argv[4] || "";
const puppeteer = require("puppeteer-core");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium",
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader"],
  });
  const page = await browser.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e).slice(0, 120)));
  await page.setViewport({ width: 1440, height: 900 });
  await page.goto(`${BASE}/login`, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.waitForSelector('input[type="email"]', { timeout: 45000 });
  await page.type('input[type="email"]', EMAIL);
  await page.type('input[type="password"]', PASSWORD);
  await page.waitForFunction(() => !document.querySelector(".splash-stage"), { timeout: 30000 });
  await page.click('button[type="submit"]');
  await page.waitForFunction(() => location.pathname.startsWith("/app"), { timeout: 45000 });
  await page.goto(`${BASE}/app/chat`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector(".composer__input", { timeout: 30000 });
  await page.waitForFunction(
    () => [...document.querySelectorAll("select")].some((sel) => [...sel.options].some((o) => /mock/i.test(o.textContent || ""))),
    { timeout: 30000 },
  ).catch(() => console.log("WARN: no mock option appeared"));

  const picked = await page.evaluate(() => {
    const select = [...document.querySelectorAll("select")].find((sel) => [...sel.options].some((o) => /mock/i.test(o.textContent || "")));
    if (!select) return null;
    const option = [...select.options].find((o) => /mock/i.test(o.textContent || ""));
    if (!option) return null;
    Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value").set.call(select, option.value);
    select.dispatchEvent(new Event("change", { bubbles: true }));
    return option.textContent;
  });
  if (!picked) { console.log("PROBLEMS: 1\n  ✗ no mock model available"); process.exit(1); }
  console.log("  ✓ model:", picked);

  await page.type(".composer__input", "variant probe question");
  await page.keyboard.press("Enter");
  await page.waitForFunction(
    () => [...document.querySelectorAll(".bubble--assistant .bubble__text, .bubble--assistant .md")].some((n) => (n.textContent || "").includes("mock-answer")),
    { timeout: 45000 },
  );
  console.log("  ✓ first answer rendered");

  const clicked = await page.evaluate(() => {
    const labels = [...document.querySelectorAll("button")].map((b) => b.getAttribute("aria-label") || b.title || "");
    const btn = [...document.querySelectorAll("button")].find((b) =>
      /regener|دوباره|تولید/i.test(b.getAttribute("aria-label") || b.title || ""),
    );
    if (btn) btn.click();
    return { clicked: !!btn, labels: labels.filter(Boolean).slice(0, 30) };
  });
  console.log("regenerate click:", JSON.stringify(clicked));

  try {
    await page.waitForFunction(
      () => document.body.textContent.includes("2 / 2"),
      { timeout: 20000 },
    );
  } catch {
    const dump = await page.evaluate(async () => {
      const convs = await (await fetch("/api/v1/chat/conversations")).json();
      const first = convs.items && convs.items[0];
      let detail = null;
      if (first) detail = await (await fetch(`/api/v1/chat/conversations/${first.id}`)).json();
      return {
        counterInDom: (document.body.textContent.match(/\d+ \/ \d+/) || [])[0] || null,
        bubbles: [...document.querySelectorAll(".bubble")].map((b) => (b.className || "") + ":" + (b.textContent || "").slice(0, 60)),
        detail: detail ? detail.messages.map((m) => `${m.role}/${m.status}`) : null,
      };
    });
    console.log("DUMP:", JSON.stringify(dump, null, 1));
    throw new Error("carousel counter never appeared");
  }
  console.log("  ✓ carousel shows 2 / 2 after regenerate, one bubble");

  await page.evaluate(() => {
    const btn = [...document.querySelectorAll("button")].find((b) => (b.textContent || "").trim() === "‹");
    if (btn) btn.click();
  });
  await sleep(600);
  const state = await page.evaluate(() => ({
    counter: (document.body.textContent.match(/[12] \/ 2/) || [])[0] || null,
    bubbles: document.querySelectorAll(".bubble--assistant").length,
  }));
  console.log("  ✓ after prev:", JSON.stringify(state));
  if (state.counter !== "1 / 2" || state.bubbles !== 1) throw new Error("prev did not page to variant 1");

  // persistence: reload and reopen — variants must survive (server-side)
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.waitForSelector(".composer__input", { timeout: 30000 });
  await sleep(1500);
  const afterReload = await page.evaluate(() => ({
    counter: (document.body.textContent.match(/[12] \/ 2/) || [])[0] || null,
  }));
  console.log("  ✓ after reload:", JSON.stringify(afterReload));
  if (afterReload.counter !== "1 / 2") throw new Error("activated variant did not survive reload");
  console.log("  ✓ pageerrors:", JSON.stringify(errors));
  if (errors.length) throw new Error("page errors during variant flow");
  console.log("\nPROBLEMS: 0");
  await browser.close();
})().catch((e) => {
  console.log("PROBE FAILED:", String(e).slice(0, 300));
  process.exit(1);
});
