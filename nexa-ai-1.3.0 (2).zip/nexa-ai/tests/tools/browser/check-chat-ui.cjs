#!/usr/bin/env node
/**
 * Round-15 UI: the rebuilt chat workspace, verified live.
 *
 *   * the shell: conversation rail (search + new), chat bar, full-height thread, glass composer;
 *   * the hero: four suggestion chips that fill the composer;
 *   * a real round trip against the mock model: user + assistant bubbles, meta with credits;
 *   * rail actions hit the real API: pin, rename (inline), server-side search, delete with confirm;
 *   * per-message tools: edit & re-run (resubmit), delete message;
 *   * on a 390px phone: the rail becomes a drawer (toggle opens, backdrop closes), the composer
 *     stays inside the viewport and the page never scrolls sideways or doubles up vertically;
 *   * the Markdown upgrade (code copy button + codebar) is compiled into the served bundle.
 *
 * Usage: node check-chat-ui.cjs [baseUrl] <email> <password>
 */
const BASE = (process.argv[2] || "http://127.0.0.1:8081").replace(/\/$/, "");
const EMAIL = process.argv[3] || "";
const PASSWORD = process.argv[4] || "";
const SHOTS = process.env.SHOTS_DIR || "/home/user/responsive-shots";

const puppeteer = require("puppeteer-core");
const problems = [];
const ok = (m) => console.log(`  ✓ ${m}`);
const fail = (m) => {
  problems.push(m);
  console.log(`  ✗ ${m}`);
};
const check = (c, m) => (c ? ok(m) : fail(m));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const norm = (t) => (t || "").replace(/\u200c/g, "").replace(/\s+/g, " ").trim();

const setValue = async (page, selector, value) => {
  await page.evaluate(
    (sel, val) => {
      const node = document.querySelector(sel);
      const proto = node instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value").set.call(node, val);
      node.dispatchEvent(new Event("input", { bubbles: true }));
      node.dispatchEvent(new Event("change", { bubbles: true }));
    },
    selector,
    value,
  );
};

(async () => {
  // ------------------------------------------------------- bundle-level proof
  const html = await (await fetch(`${BASE}/login`)).text();
  const jsName = (html.match(/assets\/(index-[^"]+\.js)/) || [])[1];
  const cssName = (html.match(/assets\/(index-[^"]+\.css)/) || [])[1];
  const js = jsName ? await (await fetch(`${BASE}/assets/${jsName}`)).text() : "";
  const css = cssName ? await (await fetch(`${BASE}/assets/${cssName}`)).text() : "";
  check(js.includes("md__copy") && js.includes("chat-hero__chips"), "the served bundle carries the new chat shell + code copy button");
  check(css.includes(".chat-side__search") && css.includes(".md__codebar"), "the served CSS carries the rail + codebar styles");

  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium",
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader"],
  });
  const page = await browser.newPage();
  const consoleErrors = [];
  page.on("pageerror", (e) => consoleErrors.push(String(e).slice(0, 140)));
  await page.setViewport({ width: 1440, height: 900 });
  await page.goto(`${BASE}/login`, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.waitForSelector('input[type="email"]', { timeout: 45000 });
  await page.type('input[type="email"]', EMAIL);
  await page.type('input[type="password"]', PASSWORD);
  await page.waitForFunction(() => !document.querySelector(".splash-stage"), { timeout: 30000 });
  await page.click('button[type="submit"]');
  await page.waitForFunction(() => location.pathname.startsWith("/app"), { timeout: 45000 });
  ok("signed in");

  // ------------------------------------------------------------- the shell
  await page.goto(`${BASE}/app/chat`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector(".chat-layout", { timeout: 30000 });
  await page.waitForSelector(".chat-side__search input", { timeout: 15000 });
  await page.waitForSelector(".composer__input", { timeout: 15000 });
  const shell = await page.evaluate(() => {
    const rect = (sel) => {
      const node = document.querySelector(sel);
      if (!node) return null;
      const r = node.getBoundingClientRect();
      return { x: r.x, y: r.y, w: r.width, h: r.height };
    };
    return {
      side: rect(".chat-side"),
      bar: rect(".chat-bar"),
      thread: rect(".chat-thread"),
      composer: rect(".composer"),
      hero: rect(".chat-hero"),
      chips: document.querySelectorAll(".chat-hero__chips button").length,
      banner: rect(".banner")?.h || 0,
      vh: innerHeight,
      docScroll: document.documentElement.scrollHeight,
    };
  });
  check(!!shell.side && shell.side.w >= 250 && shell.side.h > 300, `the conversation rail is a real column (${Math.round(shell.side?.w || 0)}×${Math.round(shell.side?.h || 0)})`);
  check(!!shell.bar && !!shell.thread && !!shell.composer, "bar + thread + composer are all present");
  // The deployment banner (when present) legitimately pushes the page down by its own height.
  const banner = shell.banner || 0;
  check(shell.thread.h > 250 && shell.composer.y + shell.composer.h <= shell.vh + banner + 4, `the thread fills the viewport and the composer ends inside it (thread h=${Math.round(shell.thread?.h || 0)}, banner ${Math.round(banner)})`);
  check(shell.docScroll <= shell.vh + banner + 40, `the page itself does not grow a second scrollbar (doc ${shell.docScroll} vs vh ${shell.vh} + banner ${Math.round(banner)})`);
  check(shell.chips === 4, `the hero offers 4 suggestion chips (got ${shell.chips})`);

  // a chip fills the composer
  await page.evaluate(() => document.querySelectorAll(".chat-hero__chips button")[0].click());
  await sleep(200);
  const chipText = await page.evaluate(() => document.querySelector(".composer__input")?.value || "");
  check(chipText.length > 5, `clicking a suggestion fills the composer (“${chipText.slice(0, 30)}…”)`);
  await setValue(page, ".composer__input", "");

  // ------------------------------------------------- a real round trip (mock)
  const picked = await page.evaluate(() => {
    const select = document.querySelector(".composer select");
    const option = [...select.options].find((o) => /mock/i.test(o.textContent || ""));
    if (!option) return null;
    Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value").set.call(select, option.value);
    select.dispatchEvent(new Event("change", { bubbles: true }));
    return option.textContent;
  });
  check(!!picked, `the composer offers a mock model (${picked || "none"})`);

  const marker = `r15-${Date.now().toString().slice(-6)}`;
  await setValue(page, ".composer__input", marker);
  await page.click('.composer button.btn--primary, .composer .row button:not([variant])');
  await page.waitForFunction(
    (m) => document.querySelectorAll(".bubble--assistant").length > 0 && [...document.querySelectorAll(".bubble--assistant")].some((b) => (b.textContent || "").includes(m)),
    { timeout: 45000 },
    marker,
  );
  ok("the mock model answered in a real streamed bubble");
  // the meta gains its time/cost when the post-send reload lands — wait for it instead of racing it
  await page
    .waitForFunction(
      () => {
        const bubbles = document.querySelectorAll(".bubble--assistant");
        const meta = (bubbles[bubbles.length - 1]?.querySelector(".bubble__meta")?.textContent || "").trim();
        return /credits|اعتبار|\d|·/.test(meta);
      },
      { timeout: 15000 },
    )
    .catch(() => {});
  const bubbleBits = await page.evaluate(() => {
    const bubbles = document.querySelectorAll(".bubble--assistant");
    const last = bubbles[bubbles.length - 1];
    return {
      tools: last.querySelectorAll(".bubble__tools .iconbtn").length,
      meta: (last.querySelector(".bubble__meta")?.textContent || "").trim(),
      userTools: document.querySelectorAll(".bubble--user .bubble__tools .iconbtn").length,
      convoItems: document.querySelectorAll(".chat-side__list .convo").length,
    };
  });
  check(bubbleBits.tools >= 2, `the assistant bubble carries its tools (${bubbleBits.tools})`);
  check(bubbleBits.userTools >= 2, `the user bubble carries copy/edit tools (${bubbleBits.userTools})`);
  check(/credits|اعتبار/i.test(bubbleBits.meta) || bubbleBits.meta.length > 3, `the bubble meta reports time/cost (“${bubbleBits.meta.slice(0, 60)}”)`);
  check(bubbleBits.convoItems >= 1, "the conversation appeared in the rail");

  // ------------------------------------------------------------ rail actions
  // pin
  await page.evaluate(() => document.querySelector(".convo .convo__tools .iconbtn")?.click());
  await sleep(500);
  const pinned = await page.evaluate(() => !!document.querySelector(".convo__title svg"));
  check(pinned, "pinning a conversation marks it (real PATCH)");

  // rename (inline, Enter commits)
  await page.evaluate(() => {
    const tools = document.querySelector(".convo .convo__tools");
    tools.querySelectorAll(".iconbtn")[1].click();
  });
  await page.waitForSelector(".convo__rename input", { timeout: 8000 });
  await setValue(page, ".convo__rename input", "بررسی-۱۵");
  await page.keyboard.press("Enter");
  await sleep(700);
  const renamed = await page.evaluate(() => (document.querySelector(".convo__title")?.textContent || ""));
  check(norm(renamed).includes(norm("بررسی-۱۵")), `inline rename saved through the API (“${renamed.trim()}”)`);

  // server-side search
  await setValue(page, ".chat-side__search input", "بررسی-۱۵");
  await sleep(800);
  const found = await page.evaluate(() => document.querySelectorAll(".chat-side__list .convo").length);
  check(found === 1, `search finds the renamed conversation server-side (${found} result)`);
  await setValue(page, ".chat-side__search input", "zzz-no-match-zzz");
  await sleep(800);
  const empty = await page.evaluate(() => document.querySelectorAll(".chat-side__list .convo").length);
  check(empty === 0, "a search with no match empties the rail (no fake results)");
  await setValue(page, ".chat-side__search input", "");
  await sleep(800);

  // ------------------------------------------------------- per-message tools
  // edit & re-run the user message
  await page.evaluate(() => {
    const userBubble = document.querySelector(".bubble--user");
    userBubble.querySelectorAll(".bubble__tools .iconbtn")[1].click();
  });
  await page.waitForSelector(".bubble__edit textarea", { timeout: 8000 });
  const marker2 = `${marker}-edited`;
  await setValue(page, ".bubble__edit textarea", marker2);
  await page.evaluate(() => document.querySelector(".bubble__edit .btn--primary, .bubble__edit button")?.click());
  await page.waitForFunction(
    (m) => [...document.querySelectorAll(".bubble--assistant")].some((b) => (b.textContent || "").includes(m)),
    { timeout: 45000 },
    marker2,
  );
  ok("edit & re-run resubmitted the prompt and the answer followed (real /resubmit)");

  // delete the assistant message
  const before = await page.evaluate(() => document.querySelectorAll(".bubble").length);
  await page.evaluate(() => {
    const bubbles = document.querySelectorAll(".bubble--assistant");
    const last = bubbles[bubbles.length - 1];
    const tools = last.querySelectorAll(".bubble__tools .iconbtn");
    tools[tools.length - 1].click();
  });
  await sleep(1200);
  const after = await page.evaluate(() => document.querySelectorAll(".bubble").length);
  check(after === before - 1, `deleting a message removes exactly one bubble (${before} → ${after})`);

  // ------------------------------------------------------------ phone (390)
  await page.setViewport({ width: 390, height: 844 });
  // Headless Chromium can stall transform transitions (no vsync → frozen computed values);
  // the drawer geometry is what this section verifies, so pin the transitions off for measurement.
  await page.addStyleTag({
    content: ".chat-side, .chat-side__backdrop { transition: none !important; animation: none !important; }",
  });
  await sleep(400);
  const mobile = await page.evaluate(() => {
    const toggle = document.querySelector(".chat-bar__side-toggle");
    const composer = document.querySelector(".composer")?.getBoundingClientRect();
    const banner = document.querySelector(".banner")?.getBoundingClientRect().height || 0;
    return {
      toggleVisible: !!toggle && toggle.getBoundingClientRect().width > 0,
      sideHidden: (() => {
        const r = document.querySelector(".chat-side")?.getBoundingClientRect();
        return !r || r.x + r.width <= 2 || r.x >= innerWidth - 2;
      })(),
      // the deployment banner legitimately pushes the page down by its own height
      composerInside: !!composer && composer.x >= -1 && composer.x + composer.width <= innerWidth + 1 && composer.y + composer.height <= innerHeight + banner + 4,
      sideways: document.documentElement.scrollWidth > innerWidth + 1,
    };
  });
  check(mobile.toggleVisible, "the phone bar shows the rail toggle");
  check(mobile.sideHidden, "the rail is parked off-canvas until opened");
  check(mobile.composerInside, "the composer sits fully inside the phone viewport");
  check(!mobile.sideways, "no horizontal page scroll on the phone");

  await page.evaluate(() => document.querySelector(".chat-bar__side-toggle")?.click());
  // deterministic: wait for the slide-in transition to actually finish (fleet runs are slow)
  const drawerOpenFn = () => {
    const side = document.querySelector(".chat-side")?.getBoundingClientRect();
    const parked = !side || side.x + side.width <= 2 || side.x >= innerWidth - 2;
    return !!side && !parked && side.width > 200;
  };
  await page.waitForFunction(drawerOpenFn, { timeout: 4000 }).catch(() => {});
  await sleep(200);
  const drawer = await page.evaluate(() => {
    const side = document.querySelector(".chat-side")?.getBoundingClientRect();
    const backdrop = document.querySelector(".chat-side__backdrop");
    // direction-agnostic: open = on-screen; parked = fully off either edge
    const parked = !side || side.x + side.width <= 2 || side.x >= innerWidth - 2;
    return {
      open: !!side && !parked && side.width > 200,
      backdropShown: !!backdrop && getComputedStyle(backdrop).display !== "none",
    };
  });
  check(drawer.open, "the toggle slides the rail in as a drawer");
  check(drawer.backdropShown, "a backdrop dims the thread while the drawer is open");
  await page.evaluate(() => document.querySelector(".chat-side__backdrop")?.click());
  await sleep(500);
  const closed = await page.evaluate(() => {
    const r = document.querySelector(".chat-side")?.getBoundingClientRect();
    return !r || r.x + r.width <= 2 || r.x >= innerWidth - 2;
  });
  check(closed, "tapping the backdrop closes the drawer");
  await page.screenshot({ path: `${SHOTS}/round15-chat-390.png` });

  // ---------------------------------------------- delete the test conversation
  await page.setViewport({ width: 1440, height: 900 });
  await sleep(500);
  await page.screenshot({ path: `${SHOTS}/round15-chat-1440.png` });
  const railBefore = await page.evaluate(() => document.querySelectorAll(".chat-side__list .convo").length);
  const deleted = await page.evaluate(async () => {
    const convo = document.querySelector(".convo");
    if (!convo) return "no-convo";
    const tools = convo.querySelectorAll(".convo__tools .iconbtn");
    tools[tools.length - 1].click(); // trash → confirm state
    await new Promise((r) => setTimeout(r, 200));
    const confirmTools = document.querySelector(".convo--confirm .convo__tools");
    confirmTools.querySelector(".iconbtn").click(); // check → delete
    return "clicked";
  });
  await sleep(1200);
  const railAfter = await page.evaluate(() => document.querySelectorAll(".chat-side__list .convo").length);
  check(deleted === "clicked" && railAfter === railBefore - 1, `delete asks for confirmation and really removes the conversation (${railBefore} → ${railAfter})`);

  check(consoleErrors.length === 0, `no page errors during the whole flow (${consoleErrors.length})`);
  consoleErrors.slice(0, 3).forEach((e) => console.log(`    ! ${e}`));

  await browser.close();
  console.log(`\nPROBLEMS: ${problems.length}`);
  problems.forEach((p) => console.log(`  - ${p}`));
  process.exit(problems.length ? 1 : 0);
})().catch((error) => {
  console.error("CHECKER CRASHED:", error.message);
  process.exit(2);
});
