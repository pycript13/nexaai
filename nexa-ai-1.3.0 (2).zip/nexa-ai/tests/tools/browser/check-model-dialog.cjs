/**
 * Round-11 proof for the admin model dialog, run against the preview build on :8081.
 *
 * The user reported (screenshot): the model-edit dialog showed **two** close buttons and **no**
 * save button.  This script drives the real UI in a real browser and asserts the opposite:
 *   - exactly one dismiss control ("Close") in the dialog,
 *   - a visible Save button that actually persists a change (checked by re-opening the dialog),
 *   - no console errors, and both a phone (390x844) and a desktop screenshot.
 *
 * Usage: BASE=http://127.0.0.1:8081 EMAIL=… PASSWORD=… node check-model-dialog.cjs
 */
const fs = require("fs");
const path = require("path");
const puppeteer = require("puppeteer-core");

const BASE = process.env.BASE || "http://127.0.0.1:8081";
const EMAIL = process.env.EMAIL || "admin@example.com";
const PASSWORD = process.env.PASSWORD || "Nexa-Preview-Admin-2026!";
const OUT = process.env.SHOT_DIR || "/tmp/nexa-browser-shots";
const CHROME = process.env.CHROME || "/usr/bin/chromium";

fs.mkdirSync(OUT, { recursive: true });
const problems = [];

let signedIn = false;

function note(list, message) {
  list.push(message);
  console.log("  ! " + message);
}

async function login(page) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
  await page.waitForSelector('input[type="email"]', { timeout: 20000 });
  await page.type('input[type="email"]', EMAIL);
  await page.type('input[type="password"]', PASSWORD);
  await Promise.all([
    page.waitForNavigation({ waitUntil: "networkidle2", timeout: 30000 }).catch(() => {}),
    page.click('button[type="submit"]'),
  ]);
  await page.waitForFunction(() => !location.pathname.startsWith("/login"), { timeout: 30000 });
  signedIn = true;
}

async function dialogAudit(page, label) {
  const dialog = await page.$('[role="dialog"]');
  if (!dialog) {
    note(problems, `${label}: no dialog opened`);
    return null;
  }
  const names = await page.$$eval('[role="dialog"] button', (buttons) =>
    buttons.map((b) => (b.getAttribute("aria-label") || b.textContent || "").trim()).filter(Boolean),
  );
  const closes = names.filter((n) => n === "بستن" || n === "Close");
  const saves = names.filter((n) => n === "ذخیره" || n === "Save");
  console.log(`${label}: dialog buttons = ${JSON.stringify(names)}`);
  if (closes.length !== 1) note(problems, `${label}: expected exactly 1 close control, found ${closes.length}`);
  if (saves.length !== 1) note(problems, `${label}: expected exactly 1 save button, found ${saves.length}`);

  // Nothing may stick out of the viewport on a phone.
  const overflow = await page.evaluate(() => {
    const panel = document.querySelector('[role="dialog"] .modal__panel') || document.querySelector('[role="dialog"]');
    if (!panel) return null;
    const rect = panel.getBoundingClientRect();
    return { left: rect.left, right: rect.right, width: rect.width, viewport: window.innerWidth };
  });
  if (overflow && (overflow.left < -1 || overflow.right > overflow.viewport + 1)) {
    note(problems, `${label}: dialog overflows horizontally (${JSON.stringify(overflow)})`);
  }
  return { names, overflow };
}

(async () => {
  const browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--force-device-scale-factor=1", "--font-render-hinting=none"],
  });
  try {
    const page = await browser.newPage();
    page.on("console", (message) => {
      if (message.type() !== "error") return;
      // The pre-login "who am I?" probe logs a 401 in the console; everything else matters.
      if (!signedIn && /401|Unauthorized/i.test(message.text())) return;
      note(problems, `console error: ${message.text().slice(0, 200)}`);
    });
    page.on("requestfailed", (request) => {
      if (!request.url().includes("/api/v1/auth/me")) note(problems, `request failed: ${request.url()}`);
    });
    page.on("response", async (response) => {
      // `GET /api/v1/auth/me` answers 401 before sign-in; that is the normal "who am I?" probe.
      if (response.url().includes("/api/v1/auth/me") && response.status() === 401) return;
      if (response.status() >= 400 && response.url().includes("/api/v1/") && signedIn) {
        note(problems, `HTTP ${response.status()} ${response.request().method()} ${response.url()}`);
      }
    });

    // Persian, phone-sized viewport: exactly the situation in the user's screenshot.
    await page.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
    await page.evaluateOnNewDocument(() => localStorage.setItem("nexa.locale", "fa"));
    await login(page);

    await page.goto(`${BASE}/app/admin/models`, { waitUntil: "networkidle2" });
    await page.waitForSelector("table tbody tr, .table tbody tr, .table--stack", { timeout: 30000 });

    const rows = await page.$$('table tbody tr, .table tbody tr');
    if (!rows.length) throw new Error("the models table rendered no rows");
    // The row actions cell holds the Edit button; on stacked (phone) tables it is the last button.
    const opened = await page.evaluate(() => {
      const rows = Array.from(document.querySelectorAll("table tbody tr, .table tbody tr"));
      for (const row of rows) {
        const buttons = Array.from(row.querySelectorAll("button"));
        const edit = buttons.find((b) => (b.textContent || "").trim() === "ویرایش") || buttons[buttons.length - 1];
        if (edit) {
          edit.click();
          return (row.textContent || "").slice(0, 60);
        }
      }
      return null;
    });
    if (!opened) throw new Error("could not click an edit button");
    console.log("opened the editor for:", opened.replace(/\s+/g, " ").trim());

    await page.waitForSelector('[role="dialog"]', { timeout: 15000 });
    await new Promise((resolve) => setTimeout(resolve, 400));
    await dialogAudit(page, "phone dialog");
    await page.screenshot({ path: path.join(OUT, "model-dialog-phone.png"), fullPage: false });

    // ---- does Save actually persist? -------------------------------------
    const description = `round-11 check ${new Date().toISOString()}`;
    const changed = await page.evaluate((text) => {
      const dialog = document.querySelector('[role="dialog"]');
      if (!dialog) return false;
      const areas = Array.from(dialog.querySelectorAll("textarea"));
      if (!areas.length) return false;
      const target = areas[0];
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set;
      setter.call(target, text);
      target.dispatchEvent(new Event("input", { bubbles: true }));
      const box = dialog.querySelector('input[type="checkbox"]');
      if (box && !box.checked) box.click();
      return true;
    }, description);
    if (!changed) note(problems, "could not type into the description field");

    const saved = await page.evaluate(() => {
      const dialog = document.querySelector('[role="dialog"]');
      const button = Array.from(dialog.querySelectorAll("button")).find(
        (b) => (b.textContent || "").trim() === "ذخیره",
      );
      if (!button) return false;
      if (button.disabled) return "disabled";
      button.click();
      return true;
    });
    if (saved !== true) note(problems, `the Save button was not clickable (${saved})`);
    await new Promise((resolve) => setTimeout(resolve, 2500));
    await page.screenshot({ path: path.join(OUT, "model-dialog-phone-saved.png"), fullPage: false });

    // Re-open and read the value back from the server.
    await page.reload({ waitUntil: "networkidle2" });
    await page.waitForSelector("table tbody tr, .table tbody tr", { timeout: 30000 });
    await page.evaluate(() => {
      const rows = Array.from(document.querySelectorAll("table tbody tr, .table tbody tr"));
      for (const row of rows) {
        const buttons = Array.from(row.querySelectorAll("button"));
        const edit = buttons.find((b) => (b.textContent || "").trim() === "ویرایش") || buttons[buttons.length - 1];
        if (edit) {
          edit.click();
          return true;
        }
      }
      return false;
    });
    await page.waitForSelector('[role="dialog"] textarea', { timeout: 15000 });
    const readBack = await page.evaluate(() => {
      const area = document.querySelector('[role="dialog"] textarea');
      return area ? area.value : null;
    });
    if (readBack !== description) {
      note(problems, `the saved value did not come back from the server (${JSON.stringify(readBack)})`);
    } else {
      console.log("save persisted and was re-read from the server ✔");
    }

    // ---- desktop screenshot ---------------------------------------------
    await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 1 });
    await page.screenshot({ path: path.join(OUT, "model-dialog-desktop.png"), fullPage: false });

    // ---- the owner must not be told "credits needed" ---------------------
    await page.goto(`${BASE}/app/models`, { waitUntil: "networkidle2" });
    await page.waitForSelector("body", { timeout: 15000 });
    await new Promise((resolve) => setTimeout(resolve, 1500));
    const text = await page.evaluate(() => document.body.innerText);
    const unwanted = ["اعتبار کافی نیست", "Credits needed"];
    const hit = unwanted.find((needle) => text.includes(needle));
    if (hit) note(problems, `the catalogue still shows "${hit}" to the super admin`);
    else console.log("catalogue shows no credits-required message for the super admin ✔");
    await page.screenshot({ path: path.join(OUT, "catalogue-owner-phone.png"), fullPage: false });

    fs.writeFileSync(
      path.join(OUT, "report.json"),
      JSON.stringify({ base: BASE, problems, savedDescription: description, readBack }, null, 2),
    );
    console.log(problems.length ? `PROBLEMS: ${problems.length}` : "PROBLEMS: 0");
    process.exitCode = problems.length ? 1 : 0;
  } catch (error) {
    console.error("check failed:", error.message);
    process.exitCode = 2;
  } finally {
    await browser.close();
  }
})();
