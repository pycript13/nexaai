#!/usr/bin/env node
/**
 * Round-12 (part 2) checks — the two capabilities added after the first pass:
 *
 *   1. Command palette (Ctrl/⌘ K): opens from the keyboard, filters as you type, navigates with the
 *      arrow keys + Enter, closes with Escape — and, for an ordinary account, never offers an
 *      administration page (it is built from the permission-filtered navigation).
 *   2. Registration policy card on Admin → Settings: shows the effective policy read back from the
 *      API, really changes it (verified through `/api/v1/auth/config`), and publishes the sign-up
 *      link that the bug report said was missing.
 *
 * Usage: node check-round12b.cjs [baseUrl] [adminEmail] [adminPassword]
 * Exit code 0 = everything verified.
 */
const puppeteer = require("puppeteer-core");
const fs = require("fs");

const BASE = (process.argv[2] || "http://127.0.0.1:8081").replace(/\/$/, "");
const ADMIN_EMAIL = process.argv[3] || "admin@example.com";
const ADMIN_PASSWORD = process.argv[4] || "Nexa-Preview-Admin-2026!";
const SHOT_DIR = process.env.SHOT_DIR || "/tmp/nexa-round12b";
const CHROME = process.env.CHROME || "/usr/bin/chromium";
const API = `${BASE}/api/v1`;

const problems = [];
const ok = (message) => console.log(`  ✓ ${message}`);
const note = (message) => console.log(`  · ${message}`);
const fail = (message) => {
  problems.push(message);
  console.log(`  ✗ ${message}`);
};

fs.mkdirSync(SHOT_DIR, { recursive: true });

async function signIn(page, email, password) {
  let lastError = "";
  for (let attempt = 1; attempt <= 2; attempt += 1) {
    try {
      await page.goto(`${BASE}/login`, { waitUntil: "domcontentloaded", timeout: 30000 });
      await page.waitForSelector('input[type="email"]', { timeout: 25000 });
      await page.$eval('input[type="email"]', (el) => {
        el.value = "";
      });
      await page.type('input[type="email"]', email);
      await page.type('input[type="password"]', password);
      await page.click('button[type="submit"]');
      await page.waitForFunction(() => location.pathname.startsWith("/app"), { timeout: 35000 });
      return;
    } catch (error) {
      lastError = String(error && error.message ? error.message : error);
      await new Promise((resolve) => setTimeout(resolve, 1500));
    }
  }
  throw new Error(`sign-in failed for ${email}: ${lastError}`);
}

const bodyText = (page) => page.$eval("body", (el) => el.innerText);

/** Type into the palette's search box, whatever the script (Persian included). */
async function typeInPalette(page, text) {
  await page.$eval(
    ".palette__search input",
    (el, value) => {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
      setter.call(el, value);
      el.dispatchEvent(new Event("input", { bubbles: true }));
    },
    text,
  );
  await new Promise((resolve) => setTimeout(resolve, 350));
}

/**
 * Open the palette with the keyboard.
 *
 * `Ctrl+K` is pressed only after the shell exists (before that the shortcut has no listener at all),
 * and the press is repeated a couple of times instead of silently falling back to a click — a broken
 * shortcut must fail this check, not be papered over.
 */
async function openPalette(page) {
  await page.waitForSelector(".command-trigger", { timeout: 25000 });
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    await page.keyboard.down("Control");
    await page.keyboard.press("KeyK");
    await page.keyboard.up("Control");
    try {
      await page.waitForSelector(".palette__panel", { timeout: 4000 });
      return;
    } catch (error) {
      if (attempt === 3) throw new Error("Ctrl+K never opened the command palette");
    }
  }
}

(async () => {
  const browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage"],
  });

  try {
    // ---------------------------------------------------------------- admin: the palette
    const admin = await browser.newPage();
    await admin.setViewport({ width: 1440, height: 900 });
    await admin.evaluateOnNewDocument(() => localStorage.setItem("nexa.locale", "fa"));
    await signIn(admin, ADMIN_EMAIL, ADMIN_PASSWORD);
    console.log("\n== Command palette (Super Admin)");
    await openPalette(admin);
    ok("Ctrl+K opened the palette");
    const items = await admin.$$eval(".palette__item", (nodes) => nodes.map((n) => n.innerText.trim()));
    if (items.length >= 20) ok(`${items.length} destinations listed (permission-aware navigation)`);
    else fail(`only ${items.length} destinations listed`);

    // Real typing, on an ASCII query that matches the route (the palette indexes both the label in
    // the current language and the path).
    await admin.type(".palette__search input", "backups");
    await new Promise((resolve) => setTimeout(resolve, 400));
    const filtered = await admin.$$eval(".palette__item", (nodes) => nodes.map((n) => n.innerText.trim()));
    if (filtered.length === 1 && filtered[0].includes("پشتیبان")) ok(`typing "backups" narrowed 41 items to: ${filtered[0]}`);
    else if (filtered.length && filtered.length < items.length) ok(`typing narrowed the list to ${filtered.join(" / ")}`);
    else fail(`filtering did not narrow the list (${filtered.length} items)`);

    // The same search in Persian must work too (the label is matched in the active language).
    await typeInPalette(admin, "پشتیبان");
    const persianFiltered = await admin.$$eval(".palette__item", (nodes) => nodes.map((n) => n.innerText.trim()));
    if (persianFiltered.length && persianFiltered.length < items.length) ok(`Persian search works: "پشتیبان" → ${persianFiltered.join(" / ")}`);
    else fail(`Persian search did not narrow the list (${persianFiltered.length} items)`);

    await admin.screenshot({ path: `${SHOT_DIR}/palette-desktop.png` });

    // Keyboard navigation must actually move.
    await admin.keyboard.press("ArrowDown");
    await admin.keyboard.press("ArrowUp");
    await admin.keyboard.press("Enter");
    await admin.waitForFunction(() => location.pathname.startsWith("/app/"), { timeout: 15000 });
    const landed = await admin.evaluate(() => location.pathname);
    if (landed.includes("backup")) ok(`Enter navigated to ${landed}`);
    else fail(`Enter navigated to ${landed}, which is not the filtered page`);

    // Escape closes without navigating.
    await openPalette(admin);
    await admin.keyboard.press("Escape");
    await new Promise((resolve) => setTimeout(resolve, 300));
    const closed = await admin.$(".palette__panel");
    if (!closed) ok("Escape closed the palette");
    else fail("Escape did not close the palette");

    // The topbar trigger must work too (mouse users).
    await admin.click(".command-trigger");
    await admin.waitForSelector(".palette__panel", { timeout: 8000 });
    ok("the topbar search box opens the palette");
    await admin.keyboard.press("Escape");

    await admin.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
    await new Promise((resolve) => setTimeout(resolve, 500));
    await openPalette(admin);
    const phoneLayout = await admin.evaluate(() => {
      const panel = document.querySelector(".palette__panel");
      const list = document.querySelector(".palette__list");
      const rect = panel ? panel.getBoundingClientRect() : null;
      return {
        scrollWidth: document.documentElement.scrollWidth,
        viewport: window.innerWidth,
        panelWidth: rect ? Math.round(rect.width) : 0,
        listScrolls: list ? list.scrollHeight > list.clientHeight : false,
      };
    });
    if (phoneLayout.scrollWidth <= phoneLayout.viewport + 2) ok(`no horizontal overflow on the phone (${phoneLayout.scrollWidth})`);
    else fail(`palette overflows on the phone (${phoneLayout.scrollWidth} > ${phoneLayout.viewport})`);
    if (phoneLayout.panelWidth > 0 && phoneLayout.panelWidth <= phoneLayout.viewport) ok(`panel fits the phone (${phoneLayout.panelWidth}px)`);
    else fail(`panel too wide for the phone (${phoneLayout.panelWidth}px)`);
    await admin.screenshot({ path: `${SHOT_DIR}/palette-phone.png` });
    await admin.keyboard.press("Escape");
    await admin.setViewport({ width: 1440, height: 900 });

    // ---------------------------------------------------- admin: the registration policy
    console.log("\n== Registration policy card (Admin → Settings)");
    await admin.goto(`${BASE}/app/admin/settings`, { waitUntil: "domcontentloaded" });
    await admin.waitForSelector(".policy__option", { timeout: 20000 });
    const options = await admin.$$eval(".policy__option", (nodes) =>
      nodes.map((node) => ({ label: node.innerText.split("\n")[0].trim(), checked: node.getAttribute("aria-checked"), disabled: node.disabled })),
    );
    if (options.length === 3) ok(`three policies offered: ${options.map((o) => o.label).join(" / ")}`);
    else fail(`expected 3 policy options, found ${options.length}`);
    const current = options.find((o) => o.checked === "true");
    if (current && current.disabled) ok(`the policy in force (${current.label}) is shown as selected and cannot be re-applied`);
    else fail("no policy was marked as the one in force");

    const share = await admin.$eval(".share-link__url", (el) => el.innerText.trim()).catch(() => "");
    if (share.endsWith("/register")) ok(`the sign-up link is published on the page (${share})`);
    else fail(`the sign-up link is missing or wrong (${share})`);

    const readMode = async () => (await (await fetch(`${API}/auth/config`)).json()).registration_mode;
    const before = await readMode();

    await admin.screenshot({ path: `${SHOT_DIR}/policy-desktop.png` });

    // Really switch the policy: click "closed", verify through the API, then restore.
    const closedIndex = options.findIndex((o) => o.label.includes("بسته") || o.label.toLowerCase().includes("closed"));
    const buttons = await admin.$$(".policy__option");
    if (closedIndex >= 0 && !options[closedIndex].disabled) {
      await buttons[closedIndex].click();
      await admin.waitForFunction(
        () => document.querySelectorAll(".policy__option")[2]?.getAttribute("aria-checked") === "true",
        { timeout: 15000 },
      ).catch(() => undefined);
      const during = await readMode();
      if (during === "closed") ok(`the policy really changed (${before} → closed) — verified through /api/v1/auth/config`);
      else fail(`the API still reports ${during} after clicking "closed"`);

      const configNow = await (await fetch(`${API}/auth/config`)).json();
      if (configNow.registration_enabled === false) ok("the API now reports registration as closed");
      else fail("registration_enabled is still true while the policy is closed");

      const openIndex = options.findIndex((o) => o.label.includes("باز") || o.label.toLowerCase().includes("open"));
      const afterButtons = await admin.$$(".policy__option");
      await afterButtons[openIndex].click();
      await admin.waitForFunction(() => document.querySelector(".policy__option")?.getAttribute("aria-checked") === "true", {
        timeout: 15000,
      }).catch(() => undefined);
      const restored = await readMode();
      if (restored === before) ok(`the policy was restored to ${restored}`);
      else fail(`the policy was not restored (now ${restored}, expected ${before})`);
    } else {
      note("the closed policy is not offered by this deployment — skipping the change test");
    }

    // -------------------------------------------------- an ordinary account sees no admin pages
    console.log("\n== Command palette (ordinary account)");
    const email = `palette-${Date.now()}@example.org`;
    const password = "Palette-Check-2026!";
    const registered = await fetch(`${API}/auth/register`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        email,
        display_name: "Palette Visitor",
        password,
        locale: "fa",
        accept_terms: true,
        accept_privacy: true,
      }),
    });
    if (registered.status === 201) ok(`a fresh ordinary account was created (${email})`);
    else fail(`could not create the ordinary account (HTTP ${registered.status})`);

    const member = await browser.newPage();
    await member.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
    await member.evaluateOnNewDocument(() => localStorage.setItem("nexa.locale", "fa"));
    await signIn(member, email, password);
    await openPalette(member);
    const memberItems = await member.$$eval(".palette__item", (nodes) => nodes.map((n) => n.innerText.trim()));
    const adminish = memberItems.filter((label) =>
      /مدیریت|مدل‌ها\b|ارائه‌دهنده|صورت‌حساب‌های کاربران|پشتیبان‌گیری|تنظیمات|کاربران|نقش/.test(label),
    );
    if (adminish.length === 0) ok(`no administration destination is offered (${memberItems.length} user destinations only)`);
    else fail(`the palette offered administration pages to an ordinary account: ${adminish.join(" / ")}`);

    // Very short text: check the ordinary account can reach its own pages.
    await typeInPalette(member, "گفتگو");
    const chatItem = await member.$(".palette__item");
    if (chatItem) {
      await chatItem.click();
      await member.waitForFunction(() => location.pathname.includes("/chat"), { timeout: 15000 });
      ok("the ordinary account navigated to its own chat page from the palette");
    } else {
      fail("the ordinary account could not find its chat page in the palette");
    }
    await member.close();

    await admin.close();
  } finally {
    await browser.close();
  }

  console.log(`\nPROBLEMS: ${problems.length}`);
  if (problems.length) {
    for (const problem of problems) console.log(` - ${problem}`);
    process.exit(1);
  }
  console.log(`screenshots: ${SHOT_DIR}`);
})();
