# Browser smoke test (optional)

`verify-ui.cjs` drives a **running** Nexa AI deployment with a real Chromium/Chrome:
it signs in, opens the user and admin screens in the light / dark / glass themes and
at phone width, writes screenshots into `ui-shots/`, and exits non-zero if the
browser reports a console error, a failed request, a leaked object in the rendered
text, or a screen that never rendered.

It is deliberately **not** part of `pytest`: it needs Node, a Chromium binary and a
live server, so it is a manual/CI-optional check.

## Requirements

* Node 18+ and a Chromium or Google Chrome binary (`CHROME_PATH`, default `/usr/bin/chromium`)
* `npm install --no-save puppeteer-core` (only puppeteer-core is needed — no browser download)

## Run

```bash
NEXA_UI_BASE_URL=http://127.0.0.1:8080 \
NEXA_UI_EMAIL=admin@example.com \
NEXA_UI_PASSWORD='your-admin-password' \
CHROME_PATH=/usr/bin/chromium \
NEXA_UI_SHOT_DIR=/tmp/nexa-ui-shots \
node tests/tools/ui_smoke/verify-ui.cjs | tee /tmp/nexa-ui-smoke.json
```

Exit codes: `0` clean · `1` problems (printed as JSON under `problems`) · `2` the tool
could not start (missing password or browser).

The password is only ever read from the environment — never from the repository and
never written to disk.

## What it proves (and what it does not)

Proves: the SPA boots against the real API, authentication works in a browser, every
listed screen renders with real data, the theme switcher changes the applied theme,
the layout does not overflow at 390 px, and the console stays clean.

Does not prove: that a configured provider answers (that is
`tests/integration/test_live_stack.py`), that money movements are correct (that is
`backend/tests/test_billing.py`), or anything about browsers other than the one used.
