/**
 * Nexa AI — browser smoke test (optional tool, not part of the pytest suites).
 *
 * It drives a running Nexa AI deployment with a real Chromium/Chrome, signs in,
 * walks the user and admin screens in the light/dark/glass themes and at phone
 * width, captures screenshots and fails if the browser reports a console error,
 * a failed request or a page that never rendered.
 *
 * Usage:
 *   npm install --no-save puppeteer-core
 *   NEXA_UI_BASE_URL=http://127.0.0.1:8080 \
 *   NEXA_UI_EMAIL=admin@example.com \
 *   NEXA_UI_PASSWORD='…' \
 *   CHROME_PATH=/usr/bin/chromium \
 *   node tests/tools/ui_smoke/verify-ui.cjs
 *
 * Exit code 0 = clean, 1 = problems found (they are printed as JSON).
 */
const puppeteer = require("puppeteer-core");
const fs = require("fs");
const path = require("path");

const BASE = process.env.NEXA_UI_BASE_URL || "http://127.0.0.1:8080";
const EMAIL = process.env.NEXA_UI_EMAIL || "admin@example.com";
const PASSWORD = process.env.NEXA_UI_PASSWORD || "";
const CHROME = process.env.CHROME_PATH || "/usr/bin/chromium";
const OUT = process.env.NEXA_UI_SHOT_DIR || path.resolve("ui-shots");

const problems = [];
const shots = [];

async function shot(page, name, fullPage = true) {
  const file = path.join(OUT, `${name}.png`);
  await page.screenshot({ path: file, fullPage });
  shots.push(`${name}.png`);
}

async function main() {
  if (!PASSWORD) {
    console.error("NEXA_UI_PASSWORD is required (the account is never read from a file).");
    process.exit(2);
  }
  fs.mkdirSync(OUT, { recursive: true });
  const browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: true,
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 950 });

  page.on("console", (message) => {
    if (message.type() === "error") problems.push(`console: ${message.text().slice(0, 300)}`);
  });
  page.on("pageerror", (error) => problems.push(`pageerror: ${String(error).slice(0, 300)}`));
  page.on("requestfailed", (request) => {
    if (!request.url().includes("favicon")) problems.push(`request failed: ${request.url()}`);
  });
  page.on("response", (response) => {
    // The pre-login session probe is expected to answer 401.
    if (response.status() === 401 && response.url().includes("/auth/me")) return;
    if (response.status() >= 400 && !response.url().includes("favicon")) {
      problems.push(`http ${response.status()}: ${response.url()}`);
    }
  });

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
  await page.waitForSelector(".auth__card", { timeout: 20000 });
  await shot(page, "01-login");

  await page.type('input[type="email"]', EMAIL);
  await page.type('input[type="password"]', PASSWORD);
  await Promise.all([
    page.waitForFunction(() => window.location.pathname.startsWith("/app"), { timeout: 25000 }),
    page.click('button[type="submit"]'),
  ]);
  await page.waitForSelector(".hero, .card", { timeout: 25000 });
  await shot(page, "02-dashboard");

  for (const [theme, name] of [["dark", "03-dashboard-dark"], ["glass", "04-dashboard-glass"]]) {
    const applied = await page.evaluate((value) => {
      const button = Array.from(document.querySelectorAll(".segmented button")).find((node) =>
        (node.getAttribute("aria-label") || "").toLowerCase().includes(value),
      );
      if (button) button.click();
      return Boolean(button);
    }, theme);
    if (!applied) problems.push(`theme switcher: no "${theme}" button found`);
    await new Promise((resolve) => setTimeout(resolve, 900));
    await shot(page, name);
  }

  await page.evaluate(() => {
    const button = Array.from(document.querySelectorAll(".segmented button")).find((node) =>
      (node.getAttribute("aria-label") || "").toLowerCase().includes("light"),
    );
    if (button) button.click();
  });

  const screens = [
    ["/app/chat", "05-chat"],
    ["/app/models", "06-models"],
    ["/app/billing", "07-billing"],
    ["/app/payments", "08-payments"],
    ["/app/usage", "09-usage"],
    ["/app/admin/settings", "10-admin-settings"],
  ];
  for (const [route, name] of screens) {
    await page.goto(`${BASE}${route}`, { waitUntil: "networkidle2" });
    try {
      await page.waitForSelector(".card, .empty, .table-wrap", { timeout: 20000 });
    } catch (error) {
      problems.push(`${route}: nothing rendered`);
    }
    await new Promise((resolve) => setTimeout(resolve, 800));
    const leaked = await page.evaluate(() => {
      const text = document.body.innerText || "";
      const hits = [];
      if (text.includes("[object Object]")) hits.push("[object Object]");
      if (/\bundefined\b/.test(text)) hits.push("undefined");
      if (/\bNaN\b/.test(text)) hits.push("NaN");
      return hits;
    });
    if (leaked.length) problems.push(`${route}: rendered text leaks ${leaked.join(", ")}`);
    await shot(page, name);
  }

  await page.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true });
  await page.goto(`${BASE}/app`, { waitUntil: "networkidle2" });
  await page.waitForSelector(".hero, .card", { timeout: 25000 });
  await shot(page, "11-mobile-dashboard");
  const drawer = await page.$(".topbar__menu");
  if (drawer) {
    await drawer.click();
    await new Promise((resolve) => setTimeout(resolve, 600));
    await shot(page, "12-mobile-drawer");
  } else {
    problems.push("mobile: the drawer button is missing at 390px");
  }

  await browser.close();
  console.log(JSON.stringify({ base: BASE, shots, problems }, null, 2));
  if (problems.length) process.exitCode = 1;
}

main().catch((error) => {
  console.error("smoke test crashed:", error);
  process.exit(2);
});
