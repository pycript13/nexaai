#!/usr/bin/env python3
"""End-to-end check with a **real, paid** OpenAI-compatible provider.

This is the same journey as `tests/integration/test_live_stack.py`, except that nothing is
mocked: the platform is pointed at an actual inference service with an actual API key, and every
step below therefore spends real money (a few tokens at most).

Nothing is hard-coded: the endpoint and the key come from the environment, and the script never
prints or stores the key.

    export NEXA_REAL_BASE_URL='https://inference.example.com/v1'
    export NEXA_REAL_API_KEY='<provider key>'
    python3 tests/tools/real_provider_check.py \
        --base-url http://127.0.0.1:8080 \
        --admin-email admin@example.com --admin-password '...'

Optional:
    --provider-name   display name for the provider row (default: "Real provider")
    --model           provider_model_id to publish and chat with (default: first chat model found)
    --skip-publish    only run the connection test + model sync (spends nothing)

Exit code 0 = every step passed. The last lines print a summary you can paste into a report.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import uuid

import httpx

PASS: list[str] = []
FAIL: list[str] = []


def step(name: str, ok: bool, detail: str = "") -> None:
    (PASS if ok else FAIL).append(name)
    print(f"  {'PASS' if ok else 'FAIL'}  {name}{(' — ' + detail) if detail else ''}", flush=True)


def body(response: httpx.Response) -> dict:
    try:
        return response.json()
    except Exception:  # pragma: no cover
        return {"_raw": response.text[:400]}


class Client:
    def __init__(self, base_url: str) -> None:
        self.http = httpx.Client(base_url=base_url.rstrip("/"), timeout=180.0, follow_redirects=False)

    def login(self, email: str, password: str) -> None:
        response = self.http.post("/api/v1/auth/login", json={"email": email, "password": password})
        if response.status_code >= 400:
            raise SystemExit(f"login failed for {email}: {response.status_code} {response.text[:300]}")
        token = self.http.cookies.get("nexa_csrf") or response.cookies.get("nexa_csrf")
        if token:
            self.http.headers["X-CSRF-Token"] = token
        if "secure" in response.headers.get("set-cookie", "").lower() and self.http.base_url.scheme == "http":
            cookies = "; ".join(f"{name}={value}" for name, value in response.cookies.items())
            if cookies:
                self.http.headers["Cookie"] = cookies

    def register(self, email: str, password: str, name: str) -> None:
        response = self.http.post(
            "/api/v1/auth/register",
            json={"email": email, "password": password, "display_name": name,
                  "accept_terms": True, "accept_privacy": True},
        )
        if response.status_code >= 400:
            raise SystemExit(f"register failed: {response.status_code} {response.text[:300]}")
        self.login(email, password)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default=os.environ.get("NEXA_TEST_BASE_URL", "http://127.0.0.1:8000"),
                        help="the Nexa AI deployment under test")
    parser.add_argument("--admin-email", default=os.environ.get("NEXA_BOOTSTRAP_ADMIN_EMAIL", "admin@example.com"))
    parser.add_argument("--admin-password", default=os.environ.get("NEXA_BOOTSTRAP_ADMIN_PASSWORD", ""))
    parser.add_argument("--provider-name", default="Real provider")
    parser.add_argument("--model", default=os.environ.get("NEXA_REAL_MODEL", ""))
    parser.add_argument("--skip-publish", action="store_true")
    parser.add_argument("--user-password", default="Real-Provider-Check-1")
    args = parser.parse_args()

    base_url = os.environ.get("NEXA_REAL_BASE_URL", "").rstrip("/")
    api_key = os.environ.get("NEXA_REAL_API_KEY", "")
    if not base_url or not api_key or not args.admin_password:
        print(
            "Set NEXA_REAL_BASE_URL and NEXA_REAL_API_KEY in the environment and pass --admin-password.",
            file=sys.stderr,
        )
        return 2

    stamp = uuid.uuid4().hex[:6]
    print(f"Nexa AI real-provider check against {args.base_url}")
    print(f"provider endpoint: {base_url}   key: {api_key[:4]}…{api_key[-4:]} ({len(api_key)} chars)\n")

    admin = Client(args.base_url)
    admin.login(args.admin_email, args.admin_password)
    step("administrator signed in", True, args.admin_email)

    # --- 1. the platform is told about the provider ------------------------------
    listing = body(admin.http.get("/api/v1/admin/providers", params={"page_size": 100}))
    existing = next(
        (item for item in listing.get("items", []) if item.get("base_url", "").rstrip("/") == base_url),
        None,
    )
    if existing is None:
        created = admin.http.post(
            "/api/v1/admin/providers",
            json={
                "name": f"{args.provider_name} {stamp}",
                "provider_type": "openai_compatible",
                "base_url": base_url,
                "api_key": api_key,
                "enabled": True,
            },
        )
        payload = body(created)
        ok = created.status_code == 201
        step("provider stored with an encrypted credential", ok,
             f"id={payload.get('provider', {}).get('id')} hint={payload.get('provider', {}).get('api_key_hint')}"
             if ok else f"{created.status_code} {created.text[:200]}")
        if not ok:
            return 1
        provider = payload["provider"]
        assert api_key not in created.text, "the API key leaked into the response"
    else:
        provider = existing
        admin.http.patch(f"/api/v1/admin/providers/{provider['id']}", json={"api_key": api_key, "enabled": True})
        step("existing provider row reused and its credential rotated", True, f"id={provider['id']}")

    provider_id = provider["id"]

    # --- 2. connection test: a real HTTPS call to a real endpoint ----------------
    test = admin.http.post(f"/api/v1/admin/providers/{provider_id}/test",
                           json={"with_model_request": False})
    payload = body(test)
    result = payload.get("result", payload)
    step(
        "provider connection test succeeded against the real endpoint",
        test.status_code == 200 and bool(result.get("ok")),
        f"latency={result.get('latency_ms')}ms models_visible={result.get('model_count')} "
        f"message={str(result.get('message'))[:120]}",
    )
    if not result.get("ok"):
        print("\nThe provider refused the request — the platform reported it honestly instead of faking a reply:")
        print(json.dumps(payload, indent=2)[:1200])
        return 1

    # --- 3. synchronise the catalogue (no model is ever auto-published) ----------
    sync = admin.http.post(f"/api/v1/admin/providers/{provider_id}/sync")
    synced = body(sync).get("sync", {})
    created_ids = set(synced.get("new_model_ids") or [])
    step(
        "model catalogue synced from the provider",
        sync.status_code == 200,
        f"created={synced.get('created')} updated={synced.get('updated')} total_remote={synced.get('total_remote')}",
    )
    remote = synced.get("models") or []
    if not remote:
        fetched = body(admin.http.get(f"/api/v1/admin/providers/{provider_id}/models"))
        remote = fetched.get("items") or fetched.get("models") or []
    chat_models = [m for m in remote if "chat" in (m.get("capabilities") or ["chat"])]
    chosen = None
    if args.model:
        chosen = next((m for m in remote if m.get("provider_model_id") == args.model), None)
    if chosen is None and chat_models:
        chosen = chat_models[0]
    step("a chat model is available to test with", chosen is not None,
         f"{[(m.get('provider_model_id')) for m in remote][:6]}")
    if chosen is None or args.skip_publish:
        return 0 if not FAIL else 1

    model_id = chosen["id"]
    if str(chosen.get("provider_model_id")) in created_ids or chosen.get("published") is False:
        step("synced models stay hidden and unpublished until an admin says otherwise",
             chosen.get("visibility") == "hidden" and chosen.get("published") is False,
             f"visibility={chosen.get('visibility')} published={chosen.get('published')}")
    else:
        step("this model was published by an earlier run and is reused",
             True, f"visibility={chosen.get('visibility')} published={chosen.get('published')}")

    # --- 4. price it, test it, publish it ---------------------------------------
    priced = admin.http.patch(f"/api/v1/admin/models/{model_id}", json={
        "selling_input_per_mtok": "1.00",
        "selling_output_per_mtok": "2.00",
    })
    step("model priced with credit rates", priced.status_code == 200, "")

    tested = admin.http.post(f"/api/v1/admin/models/{model_id}/test",
                             json={"operation": "chat", "input": "Reply with the single word: pong"})
    tested_body = body(tested)
    step(
        "administrator verification test returned a real completion",
        tested.status_code == 200 and bool(tested_body.get("success")),
        f"latency={tested_body.get('latency_ms')}ms provider_cost_micro={tested_body.get('provider_cost_micro')} "
        f"tokens={tested_body.get('prompt_tokens')}/{tested_body.get('completion_tokens')} "
        f"sample={str(tested_body.get('response_text'))[:70]!r}",
    )
    if tested.status_code != 200 or not tested_body.get("success"):
        detail = tested_body.get("error") or tested_body.get("error_message")
        print("        the platform refused or failed the test: " + str(detail)[:300])
        return 1
    step("the test was billed to the platform, not to a user", tested_body.get("billed_to_user") is False,
         f"cost_uncertain={tested_body.get('cost_uncertain')}")

    # The platform never guesses capabilities: the admin declares what the verification showed.
    suggested = tested_body.get("suggested_capabilities") or []
    if suggested and not tested_body.get("capability_verified"):
        admin.http.patch(f"/api/v1/admin/models/{model_id}", json={"capabilities": suggested})
        step("the administrator declared the capability the test verified", True, f"capabilities={suggested}")

    stream_test = admin.http.post(f"/api/v1/admin/models/{model_id}/test",
                                  json={"operation": "streaming", "input": "Count from one to three."})
    stream_body = body(stream_test)
    streaming_ok = stream_test.status_code == 200 and bool(stream_body.get("success"))
    step("administrator streaming test returned real deltas", streaming_ok,
         f"latency={stream_body.get('latency_ms')}ms chars={len(str(stream_body.get('response_text') or ''))}")
    declared = set(tested_body.get("declared_capabilities") or []) | set(suggested)
    declared |= set(stream_body.get("suggested_capabilities") or [])
    if streaming_ok:
        declared.add("streaming")
    if declared:
        admin.http.patch(f"/api/v1/admin/models/{model_id}", json={"capabilities": sorted(declared)})

    published = admin.http.patch(f"/api/v1/admin/models/{model_id}",
                                 json={"published": True, "visibility": "public", "enabled": True})
    publish_body = body(published)
    step("model published to the user catalogue", published.status_code == 200,
         f"visibility={publish_body.get('model', {}).get('visibility')} "
         f"published={publish_body.get('model', {}).get('published')}")

    # --- 5. a real user pays and chats ------------------------------------------
    user_email = f"real.user.{stamp}@example.com"
    user = Client(args.base_url)
    user.register(user_email, args.user_password, "Real Check User")
    step("a normal user registered and signed in", True, user_email)

    payment = user.http.post("/api/v1/billing/payments", json={
        "method": "manual_bank_transfer",
        "amount_micro": 5_000_000,
        "note": f"real-provider check {stamp}",
    })
    payment_body = body(payment)
    if payment.status_code >= 400:
        step("manual payment request accepted", False, f"{payment.status_code} {payment.text[:200]}")
        return 1
    reference = payment_body.get("payment", {}).get("reference")
    balance_before = body(user.http.get("/api/v1/billing/balance")).get("balance_display")
    approve = admin.http.post(f"/api/v1/admin/billing/payments/{payment_body.get('payment', {}).get('id')}/approve",
                              json={"confirm": True, "note": "approved by real-provider check"})
    balance_after = body(user.http.get("/api/v1/billing/balance")).get("balance_display")
    step("credit added only after administrator approval",
         approve.status_code == 200 and balance_before != balance_after,
         f"{balance_before} → {balance_after} credits (reference={reference}); "
         f"approve={approve.status_code} {('' if approve.status_code < 400 else approve.text[:160])}")

    catalogue = body(user.http.get("/api/v1/models", params={"page_size": 100}))
    usable = [m for m in catalogue.get("items", []) if m.get("id") == model_id and m.get("accessible")]
    step("the published model is accessible to the user", bool(usable), f"accessible={bool(usable)}")

    conversation = body(user.http.post("/api/v1/chat/conversations", json={"model_id": model_id}))
    conversation_id = conversation.get("conversation", {}).get("id") or conversation.get("id")
    question = "Reply with a single short sentence: what is 17 times 3?"
    answer = user.http.post("/api/v1/chat/completions", json={
        "conversation_id": conversation_id,
        "model_id": model_id,
        "messages": [{"role": "user", "content": question}],
        "stream": False,
        "max_tokens": 64,
    })
    answer_body = body(answer)
    content = str((answer_body.get("message") or {}).get("content") or "")
    charged = answer_body.get("usage", {}).get("charged_micro") or answer_body.get("charged_micro")
    step("the real model answered through the platform", answer.status_code == 200 and len(content) > 1,
         f"{len(content)} chars, charged={charged} micro, model={answer_body.get('usage', {}).get('model')}")
    print(f"        answer: {content[:220]!r}")

    streamed = ""
    reasoning_seen = 0
    saw_done = False
    with user.http.stream("POST", "/api/v1/chat/stream", json={
        "conversation_id": conversation_id,
        "model_id": model_id,
        "messages": [{"role": "user", "content": "Now count from 1 to 5, one number per line."}],
        "max_tokens": 64,
        "stream": True,
    }) as stream_response:
        stream_status = stream_response.status_code
        event_name = ""
        for line in stream_response.iter_lines():
            if line.startswith("event:"):
                event_name = line.split(":", 1)[1].strip()
            elif line.startswith("data:") and event_name:
                try:
                    payload_event = json.loads(line.split(":", 1)[1].strip())
                except json.JSONDecodeError:
                    continue
                if event_name == "delta":
                    streamed += str(payload_event.get("text") or "")
                elif event_name == "reasoning":
                    reasoning_seen += 1
                elif event_name == "done":
                    saw_done = True
                elif event_name == "error":
                    streamed = ""
                    print(f"        stream error: {payload_event}")
                    break
    step("streaming works against the real provider",
         stream_status == 200 and saw_done and len(streamed) > 1,
         f"{len(streamed)} chars streamed, done={saw_done}, reasoning events={reasoning_seen}")
    print(f"        stream: {streamed[:200]!r}")

    usage = body(user.http.get("/api/v1/billing/usage", params={"page_size": 5}))
    rows = usage.get("items", [])
    step("usage and the immutable ledger recorded the real spend", bool(rows),
         f"{len(rows)} usage row(s); latest charged={rows[0].get('charged_micro') if rows else None} micro")
    ledger = body(user.http.get("/api/v1/billing/ledger", params={"page_size": 5}))
    balances = [entry.get("balance_after_micro") for entry in ledger.get("items", [])]
    step("ledger keeps a running balance", bool(balances), f"latest balance_after={balances[0] if balances else None} micro")

    print("\n" + "=" * 72)
    print(f"PASSED {len(PASS)} / {len(PASS) + len(FAIL)}")
    if FAIL:
        print("FAILED: " + ", ".join(FAIL))
    print("=" * 72)
    return 0 if not FAIL else 1


if __name__ == "__main__":
    raise SystemExit(main())
