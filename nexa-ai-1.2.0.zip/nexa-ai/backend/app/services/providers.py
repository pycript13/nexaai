"""Provider lifecycle: create/update with encrypted credentials, connectivity
tests, model synchronization and health statistics."""
from __future__ import annotations

import datetime as dt
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.crypto import decrypt_secret, encrypt_secret, mask_secret
from app.core.errors import ConfigurationError, ValidationError
from app.core.logging import get_logger
from app.core.net import validate_outbound_url
from app.models.provider import (
    AccessTier,
    Model,
    ModelAvailability,
    Provider,
    ProviderHealthSample,
    ProviderType,
)
from app.models.user import User
from app.providers.capabilities import Operation
from app.providers.registry import PROVIDER_PRESETS, adapter_for_provider, adapter_for_type, describe_adapters
from app.services import audit as audit_service

log = get_logger(__name__)

# Safe defaults for newly discovered models: hidden, unpublished, untested.
NEW_MODEL_DEFAULTS: dict[str, Any] = {
    "visibility": "hidden",
    "published": False,
    "enabled": True,
    "availability": ModelAvailability.UNTESTED,
    "access_tier": AccessTier.CREDIT,
}


def slugify(value: str) -> str:
    cleaned = "".join(ch.lower() if ch.isalnum() else "-" for ch in value.strip())
    while "--" in cleaned:
        cleaned = cleaned.replace("--", "-")
    return cleaned.strip("-")[:64] or "provider"


def unique_slug(db: Session, base: str) -> str:
    slug = slugify(base)
    candidate = slug
    index = 2
    while db.scalars(select(Provider).where(Provider.slug == candidate)).first() is not None:
        candidate = f"{slug[:58]}-{index}"
        index += 1
    return candidate


def validate_base_url(provider_type: str, base_url: str, *, api_key: str | None = None) -> str:
    if not base_url:
        preset = PROVIDER_PRESETS.get(provider_type, {}).get("base_url", "")
        if preset:
            base_url = preset
        else:
            raise ValidationError("A base URL is required for this provider type.")
    check = validate_outbound_url(base_url, purpose=f"provider base URL")
    if not check.ok:
        raise ValidationError(
            f"The provider base URL is not allowed: {check.reason}",
            details={
                "reason": check.reason,
                "hint": (
                    "Use a public HTTPS endpoint. Self-hosted/private endpoints must be explicitly allowlisted via "
                    "NEXA_PROVIDER_ALLOWED_HOSTS, and cloud metadata addresses are always blocked."
                ),
            },
        )
    return base_url


def create_provider(db: Session, *, actor: User | None, data: dict[str, Any]) -> Provider:
    provider_type = str(data.get("provider_type") or "openai_compatible")
    if provider_type not in {a["provider_type"] for a in describe_adapters()}:
        raise ValidationError(f"Unknown provider type '{provider_type}'.")
    name = str(data.get("name") or "").strip()
    if not name:
        raise ValidationError("Provider name is required.")
    base_url = validate_base_url(provider_type, str(data.get("base_url") or "").strip())
    api_key = (data.get("api_key") or "").strip()
    adapter_cls = adapter_for_type(provider_type)
    requested_enabled = bool(data.get("enabled", True))
    if adapter_cls.requires_api_key and not api_key and requested_enabled:
        # A provider without credentials may only exist as a *disabled draft*; an enabled one that
        # cannot authenticate would fail at request time with a confusing upstream error.
        raise ValidationError(
            f"Provider type '{provider_type}' requires an API key.",
            details={"hint": "Create the provider with enabled=false to keep it as a credential-less draft, then add the key before enabling it."},
        )

    provider = Provider(
        slug=unique_slug(db, data.get("slug") or name),
        name=name,
        provider_type=provider_type,
        description=str(data.get("description") or ""),
        base_url=base_url,
        organization_id=data.get("organization_id") or None,
        project_id=data.get("project_id") or None,
        api_version=data.get("api_version") or None,
        region=data.get("region") or None,
        enabled=bool(data.get("enabled", True)),
        priority=int(data.get("priority") or 100),
        api_key_encrypted=encrypt_secret(api_key) if api_key else None,
        api_key_hint=mask_secret(api_key) if api_key else None,
        credential_rotated_at=dt.datetime.now(dt.timezone.utc) if api_key else None,
        extra_headers_encrypted=encrypt_secret(json_dumps(data.get("extra_headers") or {})) if data.get("extra_headers") else None,
        extra_config=data.get("extra_config") or None,
        connect_timeout=float(data.get("connect_timeout") or 10),
        read_timeout=float(data.get("read_timeout") or 120),
        max_retries=int(data.get("max_retries") or 2),
        requests_per_minute=int(data.get("requests_per_minute") or 0),
        max_concurrency=int(data.get("max_concurrency") or 4),
        proxy_url=data.get("proxy_url") or None,
        network_preference=str(data.get("network_preference") or "auto"),
        created_by_id=actor.id if actor else None,
    )
    db.add(provider)
    db.flush()
    audit_service.record_audit(
        db, action="provider.created", summary=f"Provider '{provider.name}' ({provider.provider_type}) created.",
        actor=actor, entity_type="provider", entity_id=provider.id,
        after={"name": provider.name, "type": provider.provider_type, "base_url": provider.base_url, "enabled": provider.enabled},
    )
    db.commit()
    return provider


def json_dumps(value: Any) -> str:
    import json

    return json.dumps(value)


def update_provider(db: Session, *, actor: User | None, provider: Provider, data: dict[str, Any]) -> Provider:
    before = {
        "name": provider.name,
        "base_url": provider.base_url,
        "enabled": provider.enabled,
        "priority": provider.priority,
        "requests_per_minute": provider.requests_per_minute,
        "read_timeout": provider.read_timeout,
    }
    if "name" in data and data["name"]:
        provider.name = str(data["name"]).strip()
    if "description" in data:
        provider.description = str(data["description"] or "")
    if "base_url" in data and data["base_url"]:
        provider.base_url = validate_base_url(provider.provider_type, str(data["base_url"]).strip())
    for field in ("organization_id", "project_id", "api_version", "region", "proxy_url"):
        if field in data:
            setattr(provider, field, data[field] or None)
    if "network_preference" in data:
        value = str(data["network_preference"] or "auto")
        provider.network_preference = value if value in ("auto", "ipv4", "ipv6") else "auto"
    for field, caster in (("connect_timeout", float), ("read_timeout", float), ("max_retries", int),
                          ("requests_per_minute", int), ("max_concurrency", int), ("priority", int)):
        if field in data and data[field] is not None:
            setattr(provider, field, caster(data[field]))
    if "enabled" in data:
        wants_enabled = bool(data["enabled"])
        will_have_credentials = bool(
            provider.api_key_encrypted
            or data.get("api_key")
        ) and not data.get("clear_api_key")
        adapter_cls = adapter_for_type(provider.provider_type)
        if wants_enabled and adapter_cls.requires_api_key and not will_have_credentials:
            raise ValidationError(
                f"Provider '{provider.name}' cannot be enabled without an API key.",
                details={"hint": "Save the credential first (API key field), then enable the provider."},
            )
        provider.enabled = wants_enabled
    if "extra_config" in data:
        provider.extra_config = data["extra_config"] or None
    if data.get("extra_headers") is not None:
        provider.extra_headers_encrypted = encrypt_secret(json_dumps(data["extra_headers"]))
    credential_changed = False
    if data.get("api_key"):
        api_key = str(data["api_key"]).strip()
        provider.api_key_encrypted = encrypt_secret(api_key)
        provider.api_key_hint = mask_secret(api_key)
        provider.credential_rotated_at = dt.datetime.now(dt.timezone.utc)
        credential_changed = True
    if data.get("clear_api_key"):
        provider.api_key_encrypted = None
        provider.api_key_hint = None
        credential_changed = True
    db.flush()
    audit_service.record_audit(
        db, action="provider.credentials_rotated" if credential_changed else "provider.updated",
        summary=f"Provider '{provider.name}' updated." + (" Credential rotated." if credential_changed else ""),
        actor=actor, entity_type="provider", entity_id=provider.id, before=before,
        after={"name": provider.name, "base_url": provider.base_url, "enabled": provider.enabled,
               "priority": provider.priority, "credentials_replaced": credential_changed},
    )
    db.commit()
    return provider


def provider_to_dict(provider: Provider, *, include_health: bool = False, health: dict | None = None) -> dict[str, Any]:
    adapter_cls = adapter_for_type(provider.provider_type)
    data = {
        "id": provider.id,
        "slug": provider.slug,
        "name": provider.name,
        "provider_type": provider.provider_type,
        "provider_type_label": ProviderType.LABELS.get(provider.provider_type, provider.provider_type),
        "description": provider.description,
        "base_url": provider.base_url,
        "organization_id": provider.organization_id,
        "project_id": provider.project_id,
        "api_version": provider.api_version,
        "region": provider.region,
        "enabled": provider.enabled,
        "priority": provider.priority,
        "has_credentials": bool(provider.api_key_encrypted),
        "api_key_hint": provider.api_key_hint or None,
        "credential_rotated_at": provider.credential_rotated_at,
        "requires_api_key": adapter_cls.requires_api_key,
        "supported_operations": list(adapter_cls.supports_operations),
        "connect_timeout": provider.connect_timeout,
        "read_timeout": provider.read_timeout,
        "max_retries": provider.max_retries,
        "requests_per_minute": provider.requests_per_minute,
        "max_concurrency": provider.max_concurrency,
        "proxy_url": provider.proxy_url,
        "network_preference": getattr(provider, "network_preference", "auto") or "auto",
        "extra_config": provider.extra_config or {},
        "last_sync_at": provider.last_sync_at,
        "last_sync_status": provider.last_sync_status,
        "last_sync_message": provider.last_sync_message,
        "last_sync_model_count": provider.last_sync_model_count,
        "last_test_at": provider.last_test_at,
        "last_test_status": provider.last_test_status,
        "last_test_message": provider.last_test_message,
        "last_error_category": provider.last_error_category,
        "last_error_at": provider.last_error_at,
        "model_count": len(provider.models) if provider.models else 0,
        "created_at": provider.created_at,
        "updated_at": provider.updated_at,
    }
    if include_health:
        data["health"] = health or {}
    return data


async def test_provider(db: Session, *, actor: User | None, provider: Provider, with_model_request: bool = False) -> dict[str, Any]:
    """Run a real connectivity/auth test. Never reports success it did not observe."""
    if not provider.enabled and not with_model_request:
        # an admin may still test a disabled provider *explicitly*; this flag documents intent
        pass
    try:
        adapter = adapter_for_provider(provider, require_key=True)
    except ConfigurationError as exc:
        provider.last_test_at = dt.datetime.now(dt.timezone.utc)
        provider.last_test_status = "error"
        provider.last_test_message = exc.detail[:400]
        provider.last_error_category = "configuration_error"
        db.commit()
        return {"ok": False, "message": exc.detail, "error_category": "configuration_error", "hints": exc.details.get("hints", [])}

    result = await adapter.test_connection()  # type: ignore[misc]
    provider.last_test_at = dt.datetime.now(dt.timezone.utc)
    provider.last_test_status = "ok" if result.get("ok") else "error"
    provider.last_test_message = str(result.get("message", ""))[:400]
    provider.last_error_category = None if result.get("ok") else result.get("error_category")
    if not result.get("ok"):
        provider.last_error_at = dt.datetime.now(dt.timezone.utc)
    db.add(
        ProviderHealthSample(
            provider_id=provider.id,
            operation="test_connection",
            success=bool(result.get("ok")),
            latency_ms=result.get("latency_ms"),
            error_category=None if result.get("ok") else result.get("error_category"),
        )
    )
    audit_service.record_audit(
        db,
        action="provider.tested",
        summary=f"Connectivity test for '{provider.name}': {'success' if result.get('ok') else result.get('error_category')}.",
        actor=actor, entity_type="provider", entity_id=provider.id,
        after={"ok": bool(result.get("ok")), "message": provider.last_test_message},
    )
    db.commit()
    result["hints"] = (result.get("details") or {}).get("hints", [])
    return result


async def sync_models(db: Session, *, actor: User | None, provider: Provider) -> dict[str, Any]:
    """Synchronize the provider's model list.

    Newly discovered models are always inserted with SAFE defaults
    (hidden, unpublished, untested) — synchronization never publishes.
    """
    adapter = adapter_for_provider(provider, require_key=True)
    if not adapter.supports_model_listing:
        raise ValidationError(f"Provider type '{provider.provider_type}' does not expose a model list endpoint.")
    try:
        remote_models = await adapter.list_models()  # type: ignore[misc]
    except Exception as exc:  # noqa: BLE001
        from app.core.errors import ProviderError

        category = exc.category if isinstance(exc, ProviderError) else "internal_error"
        provider.last_sync_at = dt.datetime.now(dt.timezone.utc)
        provider.last_sync_status = "error"
        provider.last_sync_message = str(exc)[:400]
        provider.last_error_category = category
        db.commit()
        raise

    existing = {m.provider_model_id: m for m in db.scalars(select(Model).where(Model.provider_id == provider.id)).all()}
    created = updated = skipped = 0
    new_ids: list[str] = []
    for remote in remote_models:
        model_id = str(remote.get("provider_model_id") or "").strip()
        if not model_id:
            skipped += 1
            continue
        model = existing.get(model_id)
        if model is None:
            model = Model(
                provider_id=provider.id,
                provider_model_id=model_id,
                display_name=str(remote.get("display_name") or model_id)[:200],
                description="Discovered by synchronization. Capabilities must be verified before publishing.",
                capabilities=[],           # never guessed
                input_modalities=["text"],
                output_modalities=["text"],
                context_window=remote.get("context_window"),
                max_output_tokens=remote.get("max_output_tokens"),
                visibility=NEW_MODEL_DEFAULTS["visibility"],
                availability=NEW_MODEL_DEFAULTS["availability"],
                access_tier=NEW_MODEL_DEFAULTS["access_tier"],
                enabled=NEW_MODEL_DEFAULTS["enabled"],
                published=NEW_MODEL_DEFAULTS["published"],
                discovered_by_sync=True,
                provider_metadata=remote.get("raw") or None,
                created_by_id=None,
            )
            db.add(model)
            created += 1
            new_ids.append(model_id)
        else:
            if remote.get("context_window") and not model.context_window:
                model.context_window = remote.get("context_window")
            if remote.get("max_output_tokens") and not model.max_output_tokens:
                model.max_output_tokens = remote.get("max_output_tokens")
            model.provider_metadata = remote.get("raw") or model.provider_metadata
            updated += 1
    # The operator sees these notes in the admin panel: a sync that "did nothing" must say why.
    notes: list[str] = []
    if not remote_models:
        notes.append(
            "The provider answered with an empty model list. That is legal (a key can be scoped to "
            "one model) but often means the base URL points at the wrong catalogue endpoint."
        )
    if skipped:
        notes.append(f"{skipped} entr{'y' if skipped == 1 else 'ies'} had no usable model id and were ignored.")
    if created:
        notes.append(
            f"{created} new model(s) were imported as HIDDEN and UNPUBLISHED. Open Admin -> Models, run "
            "the test to verify what each one really supports, declare its capabilities, then publish it."
        )
    if not created and remote_models:
        notes.append("Nothing new to import — every model the provider offers is already in the catalogue.")
    provider.last_sync_at = dt.datetime.now(dt.timezone.utc)
    provider.last_sync_status = "ok"
    provider.last_sync_model_count = len(remote_models)
    provider.last_sync_message = f"{created} new, {updated} refreshed, {skipped} skipped."
    provider.last_error_category = None
    audit_service.record_audit(
        db, action="provider.synced",
        summary=f"Model sync for '{provider.name}': {created} new, {updated} refreshed (new models stay hidden/unpublished).",
        actor=actor, entity_type="provider", entity_id=provider.id,
        after={"created": created, "updated": updated, "new_model_ids": new_ids[:50]},
    )
    db.commit()
    return {
        "provider_id": provider.id,
        "created": created,
        "updated": updated,
        "skipped": skipped,
        "total_remote": len(remote_models),
        "new_model_ids": new_ids,
        "notes": notes,
        "next_step": (
            "Admin -> Models: the models listed there with a HIDDEN / NOT PUBLISHED badge are the ones "
            "this sync just imported — verify, declare capabilities, publish."
        ),
        "message": provider.last_sync_message,
    }


def provider_health(db: Session, provider_id: int) -> dict[str, Any]:
    from app.services.ai import provider_health_summary

    samples = db.scalars(
        select(ProviderHealthSample)
        .where(ProviderHealthSample.provider_id == provider_id)
        .order_by(ProviderHealthSample.created_at.desc())
        .limit(50)
    ).all()
    summary = provider_health_summary(db, provider_id)
    summary["recent"] = [
        {
            "operation": s.operation,
            "success": s.success,
            "latency_ms": s.latency_ms,
            "error_category": s.error_category,
            "created_at": s.created_at,
        }
        for s in samples[:20]
    ]
    return summary


def delete_provider(db: Session, *, actor: User | None, provider: Provider, force: bool = False) -> dict[str, Any]:
    models = db.scalars(select(Model).where(Model.provider_id == provider.id)).all()
    if models and not force:
        raise ValidationError(
            f"Provider '{provider.name}' still has {len(models)} model(s). Delete or archive them first, "
            "or repeat with force=true to remove provider and models together.",
            details={"model_count": len(models), "model_ids": [m.id for m in models][:50]},
        )
    from app.models.billing import UsageRecord
    from app.models.chat import Message

    usage_count = db.scalar(select(UsageRecord.id).where(UsageRecord.provider_id == provider.id).limit(1))
    if usage_count is not None and not force:
        raise ValidationError(
            "This provider has usage history. Deleting it would orphan financial records. "
            "Disable the provider instead (recommended), or repeat with force=true and archive exports first.",
        )
    name = provider.name
    # usage_records / messages keep NULL provider references (ondelete SET NULL) preserving history
    db.delete(provider)
    db.flush()
    audit_service.record_audit(
        db, action="provider.deleted", summary=f"Provider '{name}' deleted (force={force}).", actor=actor,
        entity_type="provider", entity_id=f"{name}", severity="critical",
    )
    db.commit()
    return {"deleted": True, "name": name, "models_deleted": len(models)}
