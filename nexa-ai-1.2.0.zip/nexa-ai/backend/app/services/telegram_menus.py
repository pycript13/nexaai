"""Keyboards and texts for the Telegram bot: a fixed bottom bar + glass inline buttons.

Round-14 design (the owner's brief, turned into code):

* **fixed buttons at the bottom** — one persistent ``ReplyKeyboardMarkup`` with the six sections and
  nothing else. It is set once (welcome / menu) and then never replaced, because Telegram keeps a
  reply keyboard on screen until another one arrives;
* **glass buttons inside the messages** — every section message carries an ``InlineKeyboardMarkup``
  (the translucent buttons Telegram draws over the chat wallpaper): one button per model, per
  session, per setting, per help topic. Telegram allows exactly **one** ``reply_markup`` per
  message, so a message either holds the bottom bar (menu / welcome) or glass buttons (sections) —
  ``send_message`` enforces that instead of silently dropping one of them;
* **navigation edits in place** — paging, toggling and choosing edit the very message that was
  tapped; going back deletes it and restores the menu. The chat stays tidy;
* **commands too** — everything reachable by button is reachable by command, published with
  ``setMyCommands``;
* **one language at a time** — message bodies follow the account's setting (``/settings``).

Button labels of the bottom bar are the contract with ``handle_message``: a reply-keyboard tap
arrives as a plain text message, so ``LABEL_ACTIONS`` maps every label (both languages, including
the legacy per-section labels of round 13) back to the action it stands for.
"""
from __future__ import annotations

from typing import Any

from app.models.provider import Model

#: The persistent bottom bar (round 15): only the two indispensable buttons — talk, or open the
#: glass hub. Everything else lives inside messages as inline buttons, nested section by section.
BAR_SECTIONS: list[tuple[str, str, str]] = [
    ("chat", "💬 گفتگو", "💬 Chat"),
    ("menu", "🧭 منو", "🧭 Menu"),
]

#: Every section known to the router. The ones beyond the bar are opened from the hub's glass
#: buttons, but their round-13/14 bar labels still arrive as plain text from stale keyboards
#: (Telegram clients keep an old reply keyboard until a new one is delivered), so all of them
#: stay mapped and keep working after the upgrade.
SECTIONS: list[tuple[str, str, str]] = BAR_SECTIONS + [
    ("models", "🧠 مدل‌ها", "🧠 Models"),
    ("sessions", "🗂 سشن‌ها", "🗂 Sessions"),
    ("account", "💳 حساب من", "💳 Account"),
    ("settings", "⚙️ تنظیمات", "⚙️ Settings"),
    ("help", "❓ راهنما", "❓ Help"),
]

BACK_LABEL = ("🔙 بازگشت", "🔙 Back")

#: Legacy per-section reply rows of round 13. They are no longer drawn (the bar is fixed now) but
#: taps on them still arrive from old chats, so their labels keep mapping to actions.
SECTION_ROWS: dict[str, list[list[tuple[str, str, str]]]] = {
    "models": [
        [("models_list", "📋 فهرست مدل‌ها", "📋 Model list")],
        [("variants", "🧩 نسخه‌ها", "🧩 Variants"), ("model_current", "🎯 مدل فعلی", "🎯 Current model")],
    ],
    "sessions": [
        [("sessions_list", "📂 نمایش سشن‌ها", "📂 List sessions")],
        [("session_new", "🆕 سشن تازه", "🆕 New session"), ("session_close", "🗑 بستن سشن فعلی", "🗑 Close current")],
        [("session_rename", "✏️ تغییر نام", "✏️ Rename")],
    ],
    "account": [
        [("balance", "💳 اعتبار", "💳 Balance"), ("usage", "📊 مصرف", "📊 Usage")],
        [("stats", "📈 آمار سشن‌ها", "📈 Session stats"), ("status", "👤 وضعیت حساب", "👤 Account status")],
        [("whoami", "🔢 شناسهٔ من", "🔢 My id"), ("export", "⬇️ خروجی گفتگو", "⬇️ Export chat")],
    ],
    "settings": [
        [("lang_fa", "🇮🇷 فارسی", "🇮🇷 Persian"), ("lang_en", "🇬🇧 English", "🇬🇧 English")],
        [("toggle_cost", "💰 نمایش هزینه", "💰 Show cost"), ("toggle_typing", "⌨️ نشانگر تایپ", "⌨️ Typing indicator")],
        [("history_short", "🧠 حافظهٔ کوتاه", "🧠 Short memory"), ("history_long", "🧠 حافظهٔ بلند", "🧠 Long memory")],
    ],
    "help": [
        [("help_commands", "📜 دستورها", "📜 Commands"), ("help_chat", "💬 چطور بپرسیم", "💬 How to ask")],
        [("help_sessions", "🗂 سشن‌ها چیست", "🗂 What sessions are"), ("help_billing", "💳 هزینه‌ها", "💳 Costs")],
    ],
    "chat": [
        [("chat_new", "🆕 گفتگوی تازه", "🆕 New chat"), ("chat_retry", "🔁 تکرار آخرین", "🔁 Retry last")],
    ],
}

#: label → (action, section). Filled from the tables above, both languages.
LABEL_ACTIONS: dict[str, tuple[str, str]] = {}


def label_for(action: str, language: str = "fa") -> str:
    """The button text of an action in the account's language."""
    for _, fa, en in SECTIONS:
        if fa == action or en == action:
            return fa if language == "fa" else en
    for rows in SECTION_ROWS.values():
        for row in rows:
            for item_action, fa, en in row:
                if item_action == action:
                    return fa if language == "fa" else en
    return action


def _rebuild_labels() -> None:
    LABEL_ACTIONS.clear()
    for action, fa, en in SECTIONS:
        LABEL_ACTIONS[fa] = (action, action)
        LABEL_ACTIONS[en] = (action, action)
    LABEL_ACTIONS[BACK_LABEL[0]] = ("back", "main")
    LABEL_ACTIONS[BACK_LABEL[1]] = ("back", "main")
    for section, rows in SECTION_ROWS.items():
        for row in rows:
            for action, fa, en in row:
                LABEL_ACTIONS[fa] = (action, section)
                LABEL_ACTIONS[en] = (action, section)


_rebuild_labels()


def action_for_label(text: str) -> tuple[str, str] | None:
    """Map a reply-keyboard tap back to its action (``None`` for ordinary text)."""
    return LABEL_ACTIONS.get((text or "").strip())


def fixed_bar(language: str = "fa") -> dict[str, Any]:
    """The persistent bottom bar: one thumb-sized row — talk, or open the glass hub."""
    bar = [fa if language == "fa" else en for _action, fa, en in BAR_SECTIONS]
    rows: list[list[str]] = [bar[index:index + 2] for index in range(0, len(bar), 2)]
    return {
        "keyboard": [[{"text": text} for text in row] for row in rows],
        "resize_keyboard": True,
        "is_persistent": True,
        "input_field_placeholder": "پیام بنویسید…" if language == "fa" else "Type a message…",
    }


def reply_keyboard(section: str = "main", language: str = "fa") -> dict[str, Any]:
    """The bottom bar. ``section`` is accepted for compatibility and ignored: the bar is fixed."""
    return fixed_bar(language)


def remove_keyboard() -> dict[str, Any]:
    return {"remove_keyboard": True}


# ------------------------------------------------------------------- inline ----
def button(text: str, data: str) -> dict[str, str]:
    return {"text": text, "callback_data": data[:64]}


def url_button(text: str, url: str) -> dict[str, str]:
    return {"text": text, "url": url}


def home_button(language: str = "fa") -> dict[str, str]:
    """The way back from every nested view: it re-opens the glass hub in place."""
    return button("↩️ بازگشت به منو" if language == "fa" else "↩️ Back to menu", "nav:home")


def cancel_button(language: str = "fa") -> dict[str, str]:
    return button("🔙 انصراف" if language == "fa" else "🔙 Cancel", "nav:cancel")


def main_inline(link_state: dict[str, Any], site_url: str | None = None) -> dict[str, Any]:
    """Inline quick actions (used where a message carries no bottom bar of its own)."""
    from app.services import telegram_sessions as sessions_service

    language = sessions_service.language(link_state)
    fa = language == "fa"
    rows = [
        [
            button("🧠 مدل‌ها" if fa else "🧠 Models", "menu:models"),
            button("🗂 سشن‌ها" if fa else "🗂 Sessions", "menu:sessions"),
        ],
        [
            button("💳 حساب من" if fa else "💳 Account", "menu:account"),
            button("⚙️ تنظیمات" if fa else "⚙️ Settings", "menu:settings"),
        ],
        [
            button("❓ راهنما" if fa else "❓ Help", "menu:help"),
            button("🆕 گفتگوی تازه" if fa else "🆕 New chat", "menu:new"),
        ],
    ]
    if site_url:
        rows.append([url_button("🌐 سایت" if fa else "🌐 Site", site_url)])
    return rows


def answer_actions(language: str = "fa") -> dict[str, Any]:
    """The glass row Telegram shows under every model answer."""
    if language == "fa":
        return [
            [button("🔁 تکرار", "chat:retry"), button("🆕 سشن تازه", "chat:new")],
            [button("🧠 مدل‌ها", "menu:models"), button("🗂 سشن‌ها", "menu:sessions")],
        ]
    return [
        [button("🔁 Retry", "chat:retry"), button("🆕 New session", "chat:new")],
        [button("🧠 Models", "menu:models"), button("🗂 Sessions", "menu:sessions")],
    ]


def models_inline(models: list[Model], state: dict[str, Any], page: int, per_page: int,
                  language: str = "fa") -> tuple[dict[str, Any], int, int]:
    """Paged glass buttons, one per model; tapping one switches the active model in place."""
    import math

    from app.services import telegram_sessions as sessions_service

    pages = max(1, math.ceil(len(models) / per_page))
    page = min(max(page, 1), pages)
    start = (page - 1) * per_page
    window = models[start:start + per_page]
    current_model = (sessions_service.active(state) or {}).get("model_id") or state.get("model_id")
    rows: list[list[dict[str, str]]] = []
    for number, model in enumerate(window, start=start + 1):
        mark = "✅ " if model.id == current_model else ""
        label = f"{mark}{number}. {model.display_name}"[:60]
        rows.append([button(label, f"model:{model.id}")])
    nav: list[dict[str, str]] = []
    if page > 1:
        nav.append(button("⬅️", f"models:{page - 1}"))
    nav.append(button(f"{page}/{pages}", "noop"))
    if page < pages:
        nav.append(button("➡️", f"models:{page + 1}"))
    rows.append(nav)
    rows.append(
        [
            button("🆕 سشن تازه" if language == "fa" else "🆕 New session", "chat:new"),
            home_button(language),
        ]
    )
    return {"inline_keyboard": rows}, page, pages


def sessions_inline(sessions: list[dict[str, Any]], active_id: int | None, language: str = "fa",
                    *, page: int = 1, per_page: int = 10) -> dict[str, Any]:
    """The session picker: one glass button per session, plus actions for the active one."""
    fa = language == "fa"
    pages = max(1, -(-len(sessions) // per_page))
    page = min(max(1, page), pages)
    rows: list[list[dict[str, str]]] = []
    for row in sessions[(page - 1) * per_page: page * per_page]:
        mark = "✅ " if row.get("id") == active_id else ""
        label = f"{mark}{row.get('id')}. {str(row.get('title') or '')[:38]}"[:60]
        rows.append([button(label, f"session:{row.get('id')}")])
    if not rows:
        rows.append([button("—" , "noop")])
    if pages > 1:
        pager: list[dict[str, str]] = []
        if page > 1:
            pager.append(button("⬅️", f"sessions:page:{page - 1}"))
        pager.append(button(f"{page}/{pages}", "noop"))
        if page < pages:
            pager.append(button("➡️", f"sessions:page:{page + 1}"))
        rows.append(pager)
    if active_id is not None:
        rows.append(
            [
                button("✏️ تغییر نام" if fa else "✏️ Rename", "session:rename:begin"),
                button("🗑 بستن" if fa else "🗑 Close", "session:close"),
                button("⬇️ خروجی" if fa else "⬇️ Export", "menu:export"),
            ]
        )
    rows.append(
        [
            button("🆕 تازه" if fa else "🆕 New", "chat:new"),
            home_button(language),
        ]
    )
    return {"inline_keyboard": rows}


def confirm_close_inline(language: str = "fa") -> dict[str, Any]:
    fa = language == "fa"
    return {"inline_keyboard": [
        [button("🗑 بله، بسته شود" if fa else "🗑 Yes, close it", "session:close:yes")],
        [cancel_button(language), home_button(language)],
    ]}


def variants_inline(variants: list[Any], active_variant: int | None, language: str = "fa") -> dict[str, Any]:
    fa = language == "fa"
    rows: list[list[dict[str, str]]] = []
    raw_mark = "✅ " if not active_variant else ""
    rows.append([button(f"{raw_mark}0. {'مدل خام' if fa else 'raw model'}", "variant:0")])
    for index, variant in enumerate(variants, start=1):
        mark = "✅ " if variant.id == active_variant else ""
        rows.append([button(f"{mark}{index}. {variant.name}"[:60], f"variant:{variant.id}")])
    rows.append([button("🧠 فهرست مدل‌ها" if fa else "🧠 Model list", "menu:models"), home_button(language)])
    return {"inline_keyboard": rows}


def settings_inline(state: dict[str, Any]) -> dict[str, Any]:
    from app.services import telegram_sessions as sessions_service

    current = sessions_service.settings_of(state)
    language = sessions_service.language(state)
    fa = language == "fa"

    def tick(value: bool) -> str:
        return "✅" if value else "▫️"

    rows = [
        [
            button("🇮🇷 فارسی" + (" ✅" if current["language"] == "fa" else ""), "settings:lang:fa"),
            button("🇬🇧 English" + (" ✅" if current["language"] == "en" else ""), "settings:lang:en"),
        ],
        [
            button(f"{tick(current['show_cost'])} " + ("نمایش هزینه" if fa else "Show cost"), "settings:cost:toggle"),
            button(f"{tick(current['typing_indicator'])} " + ("نشانگر تایپ" if fa else "Typing indicator"), "settings:typing:toggle"),
        ],
        [
            button(f"{tick(current['history_depth'] <= 6)} " + ("حافظهٔ کوتاه" if fa else "Short memory"), "settings:history:short"),
            button(f"{tick(current['history_depth'] > 6)} " + ("حافظهٔ بلند" if fa else "Long memory"), "settings:history:long"),
        ],
        [home_button(language)],
    ]
    return {"inline_keyboard": rows}


def account_inline(language: str = "fa") -> dict[str, Any]:
    fa = language == "fa"
    return {"inline_keyboard": [
        [button("📊 مصرف" if fa else "📊 Usage", "menu:usage"),
         button("📈 آمار ربات" if fa else "📈 Bot stats", "menu:stats")],
        [button("👤 وضعیت حساب" if fa else "👤 Account status", "menu:status"),
         button("🔢 شناسهٔ من" if fa else "🔢 My id", "menu:whoami")],
        [button("⬇️ خروجی گفتگو" if fa else "⬇️ Export chat", "menu:export"), home_button(language)],
    ]}


def help_inline(language: str = "fa") -> dict[str, Any]:
    fa = language == "fa"
    return {"inline_keyboard": [
        [button("📜 دستورها" if fa else "📜 Commands", "help:commands"),
         button("💬 چطور بپرسیم" if fa else "💬 How to ask", "help:chat")],
        [button("🗂 سشن‌ها چیست" if fa else "🗂 What sessions are", "help:sessions"),
         button("💳 هزینه‌ها" if fa else "💳 Costs", "help:billing")],
        [home_button(language)],
    ]}


# ------------------------------------------------------------------- texts ----
HELP_SECTIONS = ("commands", "chat", "sessions", "billing")


def help_text(section: str = "main", language: str = "fa") -> str:
    if language == "en":
        blocks = {
            "main": (
                "❓ <b>Help</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "The bottom bar keeps only two buttons: 💬 Chat clears the screen for typing and "
                "🧭 Menu opens the glass hub.\n"
                "Every section is nested inside the hub and carries its own glass buttons: pick a "
                "model, switch a session, flip a setting. Paging and “back” edit the message in "
                "place, so the chat stays tidy.\n\n"
                "Send any text to talk to the selected model; it is charged to your site balance, "
                "exactly like the website.\n\n"
                "Commands: /new · /sessions · /switch · /models · /use · /balance · /usage · "
                "/status · /menu · /cancel\n\n"
                "Hub sections: 🧠 Models · 🗂 Sessions · 💳 Account · ⚙️ Settings · ❓ Help\n"
                "Help sections: /help commands · /help chat · /help sessions · /help billing"
            ),
            "commands": (
                "📜 <b>Commands</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "/new [title] — start a new session\n"
                "/sessions — list your sessions (per model)\n"
                "/switch N — make session N active\n"
                "/rename title — rename the active session\n"
                "/close — close the active session\n"
                "/models [page] — model list\n"
                "/use N — select model N\n"
                "/variants · /usev N — sub-models and their system prompts\n"
                "/balance · /usage · /stats — money and usage\n"
                "/settings — language, cost display, memory\n"
                "/export — the transcript of this session\n"
                "/retry — send the last message again\n"
                "/cancel — leave a waiting prompt (rename…)\n"
                "/status · /whoami · /menu · /help"
            ),
            "chat": (
                "💬 <b>How to ask</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "1. Pick a model (🧠 Models) — the ticked one answers, and its glass button moves "
                "the tick.\n"
                "2. Type your question as a normal message.\n"
                "3. The answer arrives with its cost; 🔁 Retry sends the same question again.\n\n"
                "Long answers are split automatically. Nothing is executed on the server — code "
                "you ask for is returned as text."
            ),
            "sessions": (
                "🗂 <b>Sessions</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "A session is one conversation with one model, with its own memory. Keep several "
                "per model: switch with a glass button or /switch N, rename with ✏️ or /rename, "
                "close with 🗑 or /close.\n\n"
                "Every session is also saved on the website under Chat, so you can continue on a "
                "computer."
            ),
            "billing": (
                "💳 <b>Costs</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "Each message is charged from your site balance at the catalogue price of the "
                "selected model — the same charge as a message typed on the website. /balance "
                "shows what is left, /usage the last charges, /stats what this bot alone has cost."
            ),
        }
        return blocks.get(section, blocks["main"])

    blocks = {
        "main": (
            "❓ <b>راهنما</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "نوار پایین فقط دو دکمه دارد: 💬 گفتگو صفحه را برای نوشتن خالی می‌کند و 🧭 منو قطبِ "
            "شیشه‌ای را باز می‌کند.\n"
            "همهٔ بخش‌ها داخل منو تو در تو قرار دارند و دکمه‌های شیشه‌ای خودشان را دارند: انتخاب "
            "مدل، جابه‌جایی سشن، تغییر تنظیمات. صفحه‌بندی و «بازگشت» همان پیام را در جا ویرایش "
            "می‌کنند، پس گفتگو شلوغ نمی‌شود.\n\n"
            "هر پیام متنی به مدل انتخاب‌شده می‌رود و از اعتبار همان حساب سایت شما کم می‌شود.\n\n"
            "دستورها: /new · /sessions · /switch · /models · /use · /balance · /usage · /status · "
            "/menu · /cancel\n\n"
            "بخش‌های منو: 🧠 مدل‌ها · 🗂 سشن‌ها · 💳 حساب من · ⚙️ تنظیمات · ❓ راهنما\n"
            "بخش‌های راهنما: /help commands · /help chat · /help sessions · /help billing"
        ),
        "commands": (
            "📜 <b>دستورها</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "/new [عنوان] — سشن تازه\n"
            "/sessions — فهرست سشن‌ها (به تفکیک مدل)\n"
            "/switch N — فعال کردن سشن شمارهٔ N\n"
            "/rename عنوان — تغییر نام سشن فعال\n"
            "/close — بستن سشن فعال\n"
            "/models [صفحه] — فهرست مدل‌ها\n"
            "/use N — انتخاب مدل شمارهٔ N\n"
            "/variants · /usev N — نسخه‌ها و پرامپت سیستمی هرکدام\n"
            "/balance · /usage · /stats — اعتبار و مصرف\n"
            "/settings — زبان، نمایش هزینه، حافظه\n"
            "/export — خروجی متنی همین سشن\n"
            "/retry — فرستادن دوبارهٔ آخرین پیام\n"
            "/cancel — خروج از حالت انتظار (مثلاً تغییر نام)\n"
            "/status · /whoami · /menu · /help"
        ),
        "chat": (
            "💬 <b>چطور بپرسیم</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "۱) یک مدل انتخاب کنید (🧠 مدل‌ها) — علامت ✅ با زدن دکمهٔ شیشه‌ای همان مدل جابه‌جا می‌شود.\n"
            "۲) سؤال خود را مثل یک پیام معمولی بنویسید.\n"
            "۳) پاسخ همراه هزینه می‌آید؛ با 🔁 تکرار همان سؤال دوباره فرستاده می‌شود.\n\n"
            "پاسخ‌های بلند خودکار تقسیم می‌شوند. هیچ کدی روی سرور اجرا نمی‌شود."
        ),
        "sessions": (
            "🗂 <b>سشن‌ها</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "هر سشن یک گفتگو با یک مدل و حافظهٔ مستقل خودش است. برای هر مدل می‌توانید چند سشن داشته "
            "باشید: با دکمهٔ شیشه‌ای یا /switch N جابه‌جا شوید، با ✏️ یا /rename نام عوض کنید و با "
            "🗑 یا /close ببندید.\n\n"
            "همهٔ سشن‌ها در سایت (بخش گفتگو) هم ذخیره می‌شوند، پس می‌توانید روی کامپیوتر ادامه دهید."
        ),
        "billing": (
            "💳 <b>هزینه‌ها</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "هر پیام با قیمت کاتالوگ همان مدل از اعتبار حساب سایت شما کسر می‌شود — دقیقاً مثل ارسال "
            "پیام در وب‌سایت. /balance مانده، /usage آخرین مصرف‌ها و /stats هزینهٔ همین ربات را "
            "نشان می‌دهد."
        ),
    }
    return blocks.get(section, blocks["main"])


def section_intro(section: str, language: str = "fa") -> str:
    if language == "en":
        return {
            "main": (
                "🧭 <b>Main menu</b>\n"
                "Every section opens from the glass buttons below, and each one carries its own "
                "buttons inside — models, sessions, account, settings, help.\n"
                "The bottom bar keeps only the two essentials: 💬 Chat and 🧭 Menu.\n"
                "Type a message any time to talk to the selected model."
            ),
            "models": "🧠 <b>Models</b>\nThe ticked model answers your messages. Tap a model's glass button to switch — the list updates in place.",
            "sessions": "🗂 <b>Sessions</b>\nOne conversation per model, with independent memory. Tap a session to switch to it.",
            "account": "💳 <b>Account</b>\nBalance, usage and this bot's own statistics.",
            "settings": "⚙️ <b>Settings</b>\nLanguage, cost display and how much memory a session keeps. Toggles apply at once.",
            "help": "❓ <b>Help</b>\nPick a topic — the glass buttons below.",
            "chat": "💬 <b>Chat</b>\nThe menu card is gone — type your message, or open 🧭 Menu any time.",
        }.get(section, "🧭")
    return {
        "main": (
            "🧭 <b>منوی اصلی</b>\n"
            "همهٔ بخش‌ها از دکمه‌های شیشه‌ای زیر باز می‌شوند و داخل هر بخش هم دکمه‌های خودش "
            "قرار دارد — مدل‌ها، سشن‌ها، حساب، تنظیمات، راهنما.\n"
            "نوار پایین فقط دو دکمهٔ ضروری دارد: 💬 گفتگو و 🧭 منو.\n"
            "هر وقت پیامی بنویسید، به مدل انتخاب‌شده می‌رود."
        ),
        "models": "🧠 <b>مدل‌ها</b>\nمدلی که ✅ دارد به پیام‌های شما پاسخ می‌دهد. برای تغییر مدل، دکمهٔ شیشه‌ای همان مدل را بزنید — فهرست در جا به‌روز می‌شود.",
        "sessions": "🗂 <b>سشن‌ها</b>\nبرای هر مدل یک گفتگوی مستقل با حافظهٔ جداگانه. برای جابه‌جایی، دکمهٔ همان سشن را بزنید.",
        "account": "💳 <b>حساب من</b>\nاعتبار، مصرف و آمار همین ربات.",
        "settings": "⚙️ <b>تنظیمات</b>\nزبان، نمایش هزینه و میزان حافظهٔ هر سشن. تغییرها همان لحظه اعمال می‌شوند.",
        "help": "❓ <b>راهنما</b>\nیک موضوع را با دکمه‌های شیشه‌ای پایین انتخاب کنید.",
        "chat": "💬 <b>گفتگو</b>\nکارت منو جمع شد — پیام خود را بنویسید؛ هر وقت خواستید 🧭 منو را بزنید.",
    }.get(section, "🧭")
