"""Per-model, per-conversation sessions for the Telegram bot.

Why this module exists
----------------------
The bot used to keep exactly one conversation per Telegram account (``state["conversation_id"]``):
starting something new threw the previous thread away *on the bot side* and switching model silently
reused the same thread. The owner asked for real sessions — several conversations per model, each one
listed, switchable, renameable — so the bookkeeping lives here, in one place, as pure functions over
the ``telegram_links.state`` JSON document.

Shape stored under ``state["sessions"]`` (a list, newest first)::

    {
      "id": 3,                       # small integer, stable per link, shown to the user
      "title": "Sessions · 2026-10-15 21:04"   or  the first words of the first message
      "model_id": 12,
      "model_name": "DeepSeek-V4-Flash-0731",
      "variant_id": 4 | None,
      "conversation_id": 987,        # the platform conversation this session writes to
      "created_at": "2026-10-15T21:04:11+00:00",
      "updated_at": "...",
      "messages": 7,
      "tokens": 1234,                # prompt+completion tokens reported by the provider
      "charged_micro": 4200          # what this session cost (integer micro-credits)
    }

Rules kept deliberately strict:

* a session always belongs to **one** model and **one** variant (that is what "per model" means);
* ``state["conversation_id"]`` stays in sync with the active session, because the web UI and the
  older code paths read it;
* nothing here deletes platform data: removing a session forgets the *bot's* pointer, the conversation
  remains visible in the website's chat list (documented in ``docs/TELEGRAM.md``);
* a cap (``MAX_SESSIONS``) bounds the JSON document so a chatty account cannot bloat the row.
"""
from __future__ import annotations

import datetime as dt
from typing import Any

SESSIONS_KEY = "sessions"
ACTIVE_KEY = "active_session_id"
SETTINGS_KEY = "settings"
COUNTER_KEY = "session_counter"

#: How many sessions one Telegram account may keep. Older, inactive ones are dropped first.
MAX_SESSIONS = 20

DEFAULT_SETTINGS: dict[str, Any] = {
    "language": "fa",        # fa | en — the language of the bot's own texts
    "show_cost": True,       # append "— 0.004 credits" to every answer
    "typing_indicator": True,
    "history_depth": 12,     # how many past messages are sent as context
}


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


# ------------------------------------------------------------------ settings ----
def settings_of(state: dict[str, Any]) -> dict[str, Any]:
    """The account's bot preferences, with every default filled in."""
    current = dict(DEFAULT_SETTINGS)
    stored = state.get(SETTINGS_KEY)
    if isinstance(stored, dict):
        for key, value in stored.items():
            if key in DEFAULT_SETTINGS:
                current[key] = value
    return current


def update_settings(state: dict[str, Any], **changes: Any) -> dict[str, Any]:
    current = settings_of(state)
    for key, value in changes.items():
        if key in DEFAULT_SETTINGS:
            current[key] = value
    state[SETTINGS_KEY] = current
    return current


def language(state: dict[str, Any]) -> str:
    value = str(settings_of(state).get("language") or "fa").lower()
    return value if value in ("fa", "en") else "fa"


def bilingual(state: dict[str, Any], fa: str, en: str) -> str:
    """One line in the configured language.

    The bot's texts used to print both languages on every line ("مدل‌ها / models"), which is honest but
    noisy. With a language setting the messages stay short; ``/settings`` switches them.
    """
    return fa if language(state) == "fa" else en


# ------------------------------------------------------------------ sessions ----
def sessions(state: dict[str, Any]) -> list[dict[str, Any]]:
    rows = state.get(SESSIONS_KEY)
    if not isinstance(rows, list):
        return []
    clean: list[dict[str, Any]] = []
    for row in rows:
        if isinstance(row, dict) and row.get("id") is not None:
            clean.append(row)
    return clean


def active(state: dict[str, Any]) -> dict[str, Any] | None:
    active_id = state.get(ACTIVE_KEY)
    for row in sessions(state):
        if row.get("id") == active_id:
            return row
    return None


def find(state: dict[str, Any], session_id: int) -> dict[str, Any] | None:
    for row in sessions(state):
        if int(row.get("id") or 0) == int(session_id):
            return row
    return None


def _next_id(state: dict[str, Any]) -> int:
    counter = int(state.get(COUNTER_KEY) or 0) + 1
    state[COUNTER_KEY] = counter
    return counter


def _store(state: dict[str, Any], rows: list[dict[str, Any]]) -> None:
    state[SESSIONS_KEY] = rows[:MAX_SESSIONS]


def create(
    state: dict[str, Any],
    *,
    model_id: int,
    model_name: str,
    conversation_id: int,
    variant_id: int | None = None,
    title: str | None = None,
) -> dict[str, Any]:
    """Register a new session and make it active."""
    stamp = now_iso()
    row = {
        "id": _next_id(state),
        "title": (title or f"{model_name} · {stamp[11:16]}")[:80],
        "model_id": int(model_id),
        "model_name": model_name[:80],
        "variant_id": variant_id,
        "conversation_id": int(conversation_id),
        "created_at": stamp,
        "updated_at": stamp,
        "messages": 0,
        "tokens": 0,
        "charged_micro": 0,
    }
    rows = [row, *sessions(state)]
    # Beyond the cap the OLDEST rows are evicted. The row just created is first, so it always
    # survives; a long-idle old session may be dropped to bound the JSON document.
    if len(rows) > MAX_SESSIONS:
        rows = rows[:MAX_SESSIONS]
    _store(state, rows)
    state[ACTIVE_KEY] = row["id"]
    state["conversation_id"] = row["conversation_id"]
    if variant_id is None:
        state.pop("variant_id", None)
    else:
        state["variant_id"] = variant_id
    state["model_id"] = row["model_id"]
    return row


def activate(state: dict[str, Any], session_id: int) -> dict[str, Any] | None:
    row = find(state, session_id)
    if row is None:
        return None
    state[ACTIVE_KEY] = row["id"]
    state["conversation_id"] = row.get("conversation_id")
    state["model_id"] = row.get("model_id")
    if row.get("variant_id") is None:
        state.pop("variant_id", None)
    else:
        state["variant_id"] = row.get("variant_id")
    return row


def rename(state: dict[str, Any], session_id: int, title: str) -> dict[str, Any] | None:
    row = find(state, session_id)
    if row is None:
        return None
    row["title"] = (title or "").strip()[:80] or row.get("title") or "—"
    row["updated_at"] = now_iso()
    return row


def remove(state: dict[str, Any], session_id: int) -> dict[str, Any] | None:
    row = find(state, session_id)
    if row is None:
        return None
    remaining = [r for r in sessions(state) if r.get("id") != row["id"]]
    _store(state, remaining)
    if state.get(ACTIVE_KEY) == row["id"]:
        # Fall back to the newest remaining session of the same model (or any session at all).
        same_model = [r for r in remaining if r.get("model_id") == row.get("model_id")]
        nxt = (same_model or remaining or [None])[0]
        if nxt is None:
            state.pop(ACTIVE_KEY, None)
            state.pop("conversation_id", None)
        else:
            activate(state, int(nxt["id"]))
    return row


def touch(state: dict[str, Any], session_id: int, *, messages: int = 0, tokens: int = 0, charged_micro: int = 0) -> None:
    row = find(state, session_id)
    if row is None:
        return
    row["messages"] = int(row.get("messages") or 0) + messages
    row["tokens"] = int(row.get("tokens") or 0) + tokens
    row["charged_micro"] = int(row.get("charged_micro") or 0) + charged_micro
    row["updated_at"] = now_iso()


def maybe_autotitle(state: dict[str, Any], session_id: int, text: str) -> bool:
    """Give a session a title from its first user message — exactly once.

    The original rule was "only while the session has no messages", which retitled a session whenever
    its first turn failed (the counter never moved). An explicit flag states the fact instead.
    """
    row = find(state, session_id)
    if row is None or row.get("titled"):
        return False
    title = " ".join((text or "").split())[:40]
    if not title:
        return False
    row["title"] = title
    row["titled"] = True
    return True


def for_model(state: dict[str, Any], model_id: int) -> list[dict[str, Any]]:
    return [row for row in sessions(state) if row.get("model_id") == model_id]


def latest_for_model(state: dict[str, Any], model_id: int) -> dict[str, Any] | None:
    rows = for_model(state, model_id)
    return rows[0] if rows else None


def summary(state: dict[str, Any]) -> dict[str, int]:
    rows = sessions(state)
    return {
        "total": len(rows),
        "models": len({row.get("model_id") for row in rows}),
        "messages": sum(int(row.get("messages") or 0) for row in rows),
        "tokens": sum(int(row.get("tokens") or 0) for row in rows),
        "charged_micro": sum(int(row.get("charged_micro") or 0) for row in rows),
    }
