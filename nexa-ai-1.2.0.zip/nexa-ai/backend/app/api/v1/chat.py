"""Conversational workspace: conversations, messages, streaming chat (spec §10)."""
from __future__ import annotations

import datetime as dt
import json
import re
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy import func, or_, select

from app.api.deps import Client, CurrentUser, DbDep, PageDep, paginated
from app.core.config import settings
from app.core.errors import NotFound, RateLimited, ValidationError
from app.core.logging import get_logger
from app.core.ratelimit import limiter
from app.models.chat import Conversation, Message, MessageRole
from app.models.files import StoredFile
from app.providers.base import ChatMessage
from app.providers.capabilities import Operation
from app.services import ai as ai_service
from app.services import variants as variant_service
from app.services import files as file_service
from app.services.settings_store import get_value
from app.schemas.common import StrictModel

log = get_logger(__name__)
_REASONING_BLOCK_RE = re.compile(
    r"<\s*(?:think|thinking|reasoning)\b[^>]*>[\s\S]*?(?:<\s*/\s*(?:think|thinking|reasoning)\s*>|$)",
    re.IGNORECASE,
)

router = APIRouter(prefix="/chat", tags=["chat"])


class ConversationCreate(StrictModel):
    title: str | None = None
    module: str = "chat"
    model_id: int | None = None
    system_prompt: str | None = None
    settings: dict[str, Any] | None = None


class ConversationUpdate(StrictModel):
    title: str | None = None
    pinned: bool | None = None
    archived: bool | None = None
    model_id: int | None = None
    system_prompt: str | None = None
    settings: dict[str, Any] | None = None


class ChatRequest(StrictModel):
    message: str | None = None
    messages: list[dict[str, Any]] | None = None
    model_id: int | None = None
    conversation_id: int | None = None
    system_prompt: str | None = None
    temperature: float | None = Field(default=None, ge=0, le=2)
    max_tokens: int | None = Field(default=None, ge=1, le=200_000)
    top_p: float | None = Field(default=None, ge=0, le=1)
    json_mode: bool = False
    attachment_ids: list[int] = Field(default_factory=list)
    module: str = "chat"
    stream: bool = True
    variant_id: int | None = None
    """Use a model variant (a named system prompt + generation defaults) under the same model."""


def _conversation_payload(conversation: Conversation, *, message_count: int | None = None) -> dict[str, Any]:
    return {
        "id": conversation.id,
        "title": conversation.title,
        "module": conversation.module,
        "model_id": conversation.model_id,
        "system_prompt": conversation.system_prompt,
        "settings": conversation.settings_json or {},
        "pinned": conversation.pinned,
        "archived": conversation.archived,
        "message_count": message_count if message_count is not None else conversation.message_count,
        "total_tokens": conversation.total_tokens,
        "total_charged_micro": conversation.total_charged_micro,
        "created_at": conversation.created_at,
        "updated_at": conversation.updated_at,
    }


def _message_payload(message: Message, *, include_ids: bool = True) -> dict[str, Any]:
    return {
        "id": message.id if include_ids else None,
        "role": message.role,
        "content": message.content,
        "content_parts": message.content_parts,
        "model_id": message.model_id,
        "provider_model_id": message.provider_model_id,
        "prompt_tokens": message.prompt_tokens,
        "completion_tokens": message.completion_tokens,
        "total_tokens": message.total_tokens,
        "latency_ms": message.latency_ms,
        "status": message.status,
        "error_category": message.error_category,
        "error_message": message.error_message,
        "finish_reason": message.finish_reason,
        "attachments": message.attachments or [],
        "provider_request_id": message.provider_request_id,
        "created_at": message.created_at,
    }


def _load_history(db, conversation: Conversation, *, limit: int = 40) -> list[Message]:  # noqa: ANN001
    """Load the most recent messages (bounded) oldest-first."""
    rows = db.scalars(
        select(Message).where(Message.conversation_id == conversation.id)
        .order_by(Message.id.desc()).limit(limit)
    ).all()
    return list(reversed(rows))


@router.get("/conversations")
def list_conversations(
    db: DbDep,
    user: CurrentUser,
    page: PageDep,
    search: str | None = None,
    archived: bool = False,
    module: str | None = None,
    pinned_first: bool = True,
) -> dict[str, Any]:
    stmt = select(Conversation).where(Conversation.user_id == user.id, Conversation.archived.is_(archived))
    if module:
        stmt = stmt.where(Conversation.module == module)
    if search:
        term = f"%{search.lower()}%"
        stmt = stmt.where(or_(func.lower(Conversation.title).like(term), func.lower(func.coalesce(Conversation.search_text, "")).like(term)))
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    ordering = [Conversation.pinned.desc()] if pinned_first else []
    ordering.append(Conversation.updated_at.desc())
    conversations = db.scalars(stmt.order_by(*ordering).offset(page.offset).limit(page.limit)).all()
    # One preview line per conversation (the newest message), fetched with a single grouped
    # subquery — the sidebar shows it without a second round-trip per row.
    ids = [conversation.id for conversation in conversations]
    previews: dict[int, str] = {}
    if ids:
        last_ids = (
            select(func.max(Message.id))
            .where(Message.conversation_id.in_(ids))
            .group_by(Message.conversation_id)
        )
        for conversation_id, content in db.execute(
            select(Message.conversation_id, Message.content).where(Message.id.in_(last_ids))
        ).all():
            # the preview mirrors the visible answer: reasoning blocks (<think>/<thinking>/
            # <reasoning>) live in their own panel, never in the rail snippet
            previews[conversation_id] = _REASONING_BLOCK_RE.sub("", content or "").strip()
    return paginated(
        [
            {
                **_conversation_payload(conversation),
                "last_message_preview": (previews.get(conversation.id) or "")[:140] or None,
            }
            for conversation in conversations
        ],
        int(total),
        page,
    )


@router.post("/conversations", status_code=201)
def create_conversation(payload: ConversationCreate, db: DbDep, user: CurrentUser) -> dict[str, Any]:
    conversation = Conversation(
        user_id=user.id,
        title=(payload.title or "New conversation")[:200],
        module=payload.module[:32],
        model_id=payload.model_id,
        system_prompt=payload.system_prompt,
        settings_json=payload.settings or {},
    )
    db.add(conversation)
    db.commit()
    return {"conversation": _conversation_payload(conversation)}


@router.get("/conversations/{conversation_id}")
def get_conversation(
    conversation_id: int,
    db: DbDep,
    user: CurrentUser,
    messages_limit: int = Query(50, ge=1, le=200),
    before_id: int | None = None,
) -> dict[str, Any]:
    conversation = db.get(Conversation, conversation_id)
    if conversation is None or conversation.user_id != user.id:
        raise NotFound("Conversation not found.")
    stmt = select(Message).where(Message.conversation_id == conversation.id)
    if before_id:
        stmt = stmt.where(Message.id < before_id)
    rows = db.scalars(stmt.order_by(Message.id.desc()).limit(messages_limit)).all()
    messages = list(reversed(rows))
    total = db.scalar(select(func.count(Message.id)).where(Message.conversation_id == conversation.id)) or 0
    return {
        "conversation": _conversation_payload(conversation),
        "messages": [_message_payload(m) for m in messages],
        "pagination": {
            "total_messages": int(total),
            "returned": len(messages),
            "has_more": bool(messages and int(total) > len(messages) and messages[0].id > 1),
            "oldest_returned_id": messages[0].id if messages else None,
        },
    }


@router.patch("/conversations/{conversation_id}")
def update_conversation(
    conversation_id: int, payload: ConversationUpdate, db: DbDep, user: CurrentUser
) -> dict[str, Any]:
    conversation = db.get(Conversation, conversation_id)
    if conversation is None or conversation.user_id != user.id:
        raise NotFound("Conversation not found.")
    if payload.title is not None:
        conversation.title = payload.title.strip()[:200] or conversation.title
    if payload.pinned is not None:
        conversation.pinned = payload.pinned
    if payload.archived is not None:
        conversation.archived = payload.archived
    if payload.model_id is not None:
        conversation.model_id = payload.model_id
    if payload.system_prompt is not None:
        conversation.system_prompt = payload.system_prompt
    if payload.settings is not None:
        conversation.settings_json = payload.settings
    db.commit()
    return {"conversation": _conversation_payload(conversation)}


@router.delete("/conversations/{conversation_id}")
def delete_conversation(conversation_id: int, db: DbDep, user: CurrentUser) -> dict[str, Any]:
    conversation = db.get(Conversation, conversation_id)
    if conversation is None or conversation.user_id != user.id:
        raise NotFound("Conversation not found.")
    db.delete(conversation)
    db.commit()
    return {"deleted": True, "conversation_id": conversation_id}


@router.delete("/messages/{message_id}")
def delete_message(message_id: int, db: DbDep, user: CurrentUser) -> dict[str, Any]:
    message = db.get(Message, message_id)
    if message is None:
        raise NotFound("Message not found.")
    conversation = db.get(Conversation, message.conversation_id)
    if conversation is None or conversation.user_id != user.id:
        raise NotFound("Message not found.")
    db.delete(message)
    conversation.message_count = max(0, conversation.message_count - 1)
    db.commit()
    return {"deleted": True, "message_id": message_id}


@router.get("/conversations/{conversation_id}/export")
def export_conversation(
    conversation_id: int,
    db: DbDep,
    user: CurrentUser,
    export_format: str = Query("markdown", alias="format", pattern="^(markdown|json|txt)$"),
) -> dict[str, Any]:
    conversation = db.get(Conversation, conversation_id)
    if conversation is None or conversation.user_id != user.id:
        raise NotFound("Conversation not found.")
    messages = db.scalars(select(Message).where(Message.conversation_id == conversation.id).order_by(Message.id)).all()
    if export_format == "json":
        content = json.dumps(
            {"conversation": _conversation_payload(conversation), "messages": [_message_payload(m) for m in messages]},
            ensure_ascii=False,
            indent=2,
            default=str,
        )
        filename = f"conversation-{conversation.id}.json"
        mime = "application/json"
    elif export_format == "txt":
        content = "\n\n".join(f"[{m.role.upper()}]\n{m.content}" for m in messages)
        filename = f"conversation-{conversation.id}.txt"
        mime = "text/plain"
    else:
        lines = [f"# {conversation.title}", ""]
        for message in messages:
            lines.append(f"## {message.role.capitalize()}")
            lines.append(message.content)
            lines.append("")
        content = "\n".join(lines)
        filename = f"conversation-{conversation.id}.md"
        mime = "text/markdown"
    return {"filename": filename, "mime_type": mime, "content": content}


# ------------------------------------------------------------------ chat -----
def _prepare_request(db, user, payload: ChatRequest, client) -> tuple[ai_service.ModelRef, list[ChatMessage], Conversation | None]:  # noqa: ANN001
    """Resolve model + variant + history. The variant (if any) is stored on ``payload`` so the
    caller can put its id on the usage record."""

    if not payload.message and not payload.messages:
        raise ValidationError("Provide either 'message' or a non-empty 'messages' array.")
    max_prompt_chars = int(get_value(db, "usage.max_prompt_chars", 24000))
    if payload.message and len(payload.message) > max_prompt_chars:
        raise ValidationError(
            f"Prompt is too long ({len(payload.message)} characters). The limit is {max_prompt_chars}.",
            details={"max_prompt_chars": max_prompt_chars},
        )
    conversation: Conversation | None = None
    if payload.conversation_id:
        conversation = db.get(Conversation, payload.conversation_id)
        if conversation is None or conversation.user_id != user.id:
            raise NotFound("Conversation not found.")
    model_id = payload.model_id or (conversation.model_id if conversation else None)
    if model_id is None:
        raise ValidationError("Select a model (model_id) before sending a message.")
    operation = Operation.CHAT.value
    ref = ai_service.resolve_model(db, user=user, model_id=model_id, operation=operation)

    # A model variant (a named system prompt + generation defaults) may be requested with the
    # message. It is resolved against the *same* model, so pricing, access tier and availability
    # stay those of the parent model; asking for a disabled/foreign variant fails loudly.
    variant = variant_service.resolve_for_request(
        db, model=ref.model, user=user, variant_id=payload.variant_id or (conversation.variant_id if conversation else None)
    )
    variant_service.mark_used(db, variant)
    if variant is not None and payload.system_prompt is None and not (conversation.system_prompt if conversation else None):
        payload.system_prompt = variant_service.system_prompt_for(variant)
    if variant is not None:
        if payload.temperature is None and variant.default_temperature is not None:
            payload.temperature = float(variant.default_temperature)
        if payload.top_p is None and variant.default_top_p is not None:
            payload.top_p = float(variant.default_top_p)
        if payload.max_tokens is None and variant.default_max_tokens is not None:
            payload.max_tokens = int(variant.default_max_tokens)
        if conversation is not None and conversation.variant_id != variant.id:
            conversation.variant_id = variant.id
            conversation.system_prompt = variant.system_prompt or conversation.system_prompt

    history: list[ChatMessage] = []
    if conversation is not None:
        for stored in _load_history(db, conversation, limit=40):
            if stored.role in (MessageRole.USER, MessageRole.ASSISTANT) and stored.content:
                history.append(ChatMessage(role=stored.role, content=stored.content))
    if payload.messages:
        history = [
            ChatMessage(role=str(m.get("role", "user")), content=m.get("content", ""))
            for m in payload.messages if isinstance(m, dict)
        ]
    attachments = []
    if payload.attachment_ids:
        files = db.scalars(select(StoredFile).where(StoredFile.id.in_(payload.attachment_ids))).all()
        for stored_file in files:
            if stored_file.user_id != user.id:
                raise NotFound("Attachment not found.")
            attachments.append(stored_file)
    user_content: str | list[dict[str, Any]] = payload.message or ""
    if attachments:
        parts: list[dict[str, Any]] = [{"type": "text", "text": payload.message or ""}]
        extracted_note = []
        for stored_file in attachments:
            if stored_file.extension in file_service.IMAGE_EXTENSIONS:
                if not ref.model.supports_vision:
                    raise ValidationError(
                        f"Model '{ref.model.display_name}' does not support image input. "
                        "Pick a vision-capable model (Models → filter by 'Image understanding')."
                    )
                import base64

                data = file_service.read_bytes(stored_file)
                parts.append(
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:{stored_file.mime_type};base64,{base64.b64encode(data).decode()}",
                        },
                    }
                )
            else:
                try:
                    text = stored_file.extracted_text or file_service.extract_text(stored_file, max_chars=60_000)
                    stored_file.extracted_text = text
                    extracted_note.append(f"--- Attached file: {stored_file.original_name} ---\n{text}")
                except Exception as exc:  # noqa: BLE001
                    raise ValidationError(f"Could not read attachment '{stored_file.original_name}': {exc}") from exc
        if extracted_note:
            parts[0]["text"] = (payload.message or "") + "\n\n" + "\n\n".join(extracted_note)
        user_content = parts if len(parts) > 1 or attachments else (payload.message or "")
    history.append(ChatMessage(role="user", content=user_content))
    return ref, history, conversation


def _variant_from_payload(db, payload: ChatRequest, ref):  # noqa: ANN001
    """The variant a request used, if any (for the response payload and usage records)."""
    if not payload.variant_id:
        return None
    from app.models.provider import ModelVariant

    return db.get(ModelVariant, payload.variant_id)


def _persist_user_message(db, conversation: Conversation | None, user, payload: ChatRequest, ref, attachments) -> Message:  # noqa: ANN001
    if conversation is None:
        conversation = Conversation(
            user_id=user.id,
            title=(payload.message or "New conversation")[:60] or "New conversation",
            module=payload.module[:32],
            model_id=ref.model.id,
            system_prompt=payload.system_prompt,
            variant_id=payload.variant_id,
        )
        db.add(conversation)
        db.flush()
    message = Message(
        conversation_id=conversation.id,
        user_id=user.id,
        role=MessageRole.USER,
        content=payload.message or "",
        model_id=ref.model.id,
        attachments=[{"file_id": f.id, "name": f.original_name, "mime": f.mime_type} for f in attachments] or None,
    )
    db.add(message)
    conversation.message_count = (conversation.message_count or 0) + 1
    conversation.search_text = ((conversation.search_text or "") + " " + (payload.message or ""))[:20000].lower()
    conversation.updated_at = dt.datetime.now(dt.timezone.utc)
    db.commit()
    return message


def _empty_answer_note(*, text: str, finish_reason: str | None, completion_tokens: int | None,
                       reasoning: str | None) -> str | None:
    """Explain an answer with no visible text instead of showing an empty bubble.

    Reasoning models (the live check used `zai-org/GLM-5.3-Flash` and `MiniMax-M2.7`) can spend the
    entire output budget on internal reasoning and return `finish_reason: length` with **no visible
    content**. The provider really worked and really billed its tokens, so the platform still
    records the cost — but the user must not be left staring at an empty message: the reason is
    stored on the message and rendered by the chat screen.
    """
    if text.strip():
        return None
    if reasoning:
        if (finish_reason or "") == "length":
            return ("The model used its entire output budget on internal reasoning and produced no "
                    "visible answer. Raise 'Maximum output tokens' for this model under Admin → Models, "
                    "or ask a shorter question.")
        return "The model returned only internal reasoning and no visible answer for this request."
    if completion_tokens:
        return "The provider returned an empty answer while still reporting token usage."
    return None


@router.post("/completions")
async def chat_completion(payload: ChatRequest, request: Request, db: DbDep, user: CurrentUser, client: Client) -> dict[str, Any]:
    """Non-streaming completion (also used by batch/automation clients)."""
    limiter.check(f"chat:{user.id}", settings.api_rate_limit_per_minute, 60)
    ref, history, conversation = _prepare_request(db, user, payload, client)
    user_message = _persist_user_message(db, conversation, user, payload, ref, [])
    response, outcome = await ai_service.run_chat(
        db,
        user=user,
        model_ref=ref,
        messages=history,
        system=payload.system_prompt or (conversation.system_prompt if conversation else None),
        temperature=payload.temperature,
        max_tokens=payload.max_tokens or ref.model.max_output_tokens or None,
        top_p=payload.top_p,
        json_mode=payload.json_mode,
        module=payload.module,
        conversation_id=user_message.conversation_id,
        variant_id=payload.variant_id,
        idempotency_key=f"msg:{user_message.id}",
    )
    empty_note = _empty_answer_note(
        text=response.text, finish_reason=response.finish_reason,
        completion_tokens=response.completion_tokens, reasoning=getattr(response, "reasoning", None),
    )
    assistant = Message(
        conversation_id=user_message.conversation_id,
        user_id=user.id,
        role=MessageRole.ASSISTANT,
        content=response.text,
        status="incomplete" if empty_note else "complete",
        error_category="empty_answer" if empty_note else None,
        error_message=empty_note,
        content_parts=([{"type": "reasoning", "text": (response.reasoning or "")[:8000]}]
                       if getattr(response, "reasoning", None) else None),
        model_id=ref.model.id,
        provider_model_id=ref.model.provider_model_id,
        prompt_tokens=outcome.usage.prompt_tokens,
        completion_tokens=outcome.usage.completion_tokens,
        total_tokens=outcome.usage.total_tokens,
        provider_request_id=response.provider_request_id,
        finish_reason=response.finish_reason,
        latency_ms=response.latency_ms,
        usage_id=outcome.usage.id,
    )
    db.add(assistant)
    conversation_row = db.get(Conversation, user_message.conversation_id)
    if conversation_row is not None:
        conversation_row.message_count = (conversation_row.message_count or 0) + 1
        conversation_row.total_tokens = (conversation_row.total_tokens or 0) + (outcome.usage.total_tokens or 0)
        conversation_row.total_charged_micro = (conversation_row.total_charged_micro or 0) + outcome.usage.charged_micro
        conversation_row.search_text = ((conversation_row.search_text or "") + " " + response.text)[:20000].lower()
        conversation_row.updated_at = dt.datetime.now(dt.timezone.utc)
    db.commit()
    return {
        "message": _message_payload(assistant),
        "variant": (
            {"id": variant.id, "name": variant.name, "emoji": variant.emoji}
            if (variant := _variant_from_payload(db, payload, ref)) is not None else None
        ),
        "conversation": _conversation_payload(conversation_row) if conversation_row else None,
        "usage": {
            "prompt_tokens": outcome.usage.prompt_tokens,
            "completion_tokens": outcome.usage.completion_tokens,
            "usage_source": outcome.usage.usage_source,
            "charged_micro": outcome.usage.charged_micro,
            "balance_after_micro": outcome.charge.balance_after_micro if outcome.charge else None,
            "pricing_uncertain": outcome.usage.pricing_uncertain,
        },
        "model": {"id": ref.model.id, "display_name": ref.model.display_name, "provider": ref.provider.name},
    }


@router.post("/stream")
async def chat_stream(payload: ChatRequest, request: Request, db: DbDep, user: CurrentUser, client: Client) -> StreamingResponse:
    """Server-sent-events streaming completion.

    Events: ``meta`` (conversation/message ids) → ``delta``* → ``done`` | ``error``.
    Charging happens at the end using the tokens the provider reported; partial
    streams are charged for what was actually produced and marked accordingly.
    """
    limiter.check(f"chat:{user.id}", settings.api_rate_limit_per_minute, 60)
    ref, history, conversation = _prepare_request(db, user, payload, client)
    user_message = _persist_user_message(db, conversation, user, payload, ref, [])
    # Resolve the sub-model *before* the generator starts: inside `event_source` the
    # request-scoped session may already be closed, so the lookup has to happen here.
    variant = _variant_from_payload(db, payload, ref)

    async def event_source():
        yield _sse("meta", {
            "conversation_id": user_message.conversation_id,
            "user_message_id": user_message.id,
            "model": {
                "id": ref.model.id,
                "display_name": ref.model.display_name,
                "provider": ref.provider.name,
                "provider_model_id": ref.model.provider_model_id,
            },
            "variant": (
                {"id": variant.id, "name": variant.name, "emoji": variant.emoji, "system_prompt_chars": len(variant.system_prompt or "")}
                if variant is not None else None
            ),
        })
        collected: list[str] = []
        reasoning_collected: list[str] = []
        try:
            async for event in ai_service.stream_chat(
                db,
                user=user,
                model_ref=ref,
                messages=history,
                system=payload.system_prompt or (conversation.system_prompt if conversation else None),
                temperature=payload.temperature,
                max_tokens=payload.max_tokens or ref.model.max_output_tokens or None,
                top_p=payload.top_p,
                module=payload.module,
                conversation_id=user_message.conversation_id,
                variant_id=variant.id if variant is not None else None,
                idempotency_key=f"msg:{user_message.id}",
            ):
                if event.type == "delta":
                    collected.append(event.data.get("text", ""))
                    yield _sse("delta", event.data)
                elif event.type == "reasoning":
                    reasoning_collected.append(event.data.get("text", ""))
                    yield _sse("reasoning", event.data)
                elif event.type == "error":
                    assistant = _store_assistant_message(db, user_message, ref, "".join(collected), status="error",
                                                         error_category=event.data.get("category"),
                                                         error_message=event.data.get("message"))
                    yield _sse("error", {**event.data, "assistant_message_id": assistant.id})
                elif event.type == "done":
                    # A stream can finish with reasoning events only — the same "empty answer" case as
                    # the non-streaming path, and it must explain itself rather than leave a blank bubble.
                    finished_text = event.data.get("text", "")
                    stream_reasoning = event.data.get("reasoning") or "".join(reasoning_collected)
                    stream_note = _empty_answer_note(
                        text=finished_text, finish_reason=event.data.get("finish_reason"),
                        completion_tokens=event.data.get("completion_tokens"), reasoning=stream_reasoning,
                    )
                    assistant = _store_assistant_message(
                        db, user_message, ref, finished_text,
                        prompt_tokens=event.data.get("prompt_tokens"), completion_tokens=event.data.get("completion_tokens"),
                        latency_ms=event.data.get("latency_ms"), provider_request_id=event.data.get("provider_request_id"),
                        finish_reason=event.data.get("finish_reason"),
                        status="incomplete" if stream_note else "complete",
                        error_category="empty_answer" if stream_note else None,
                        error_message=stream_note,
                        content_parts=([{"type": "reasoning", "text": stream_reasoning[:8000]}]
                                       if stream_reasoning else None),
                    )
                    conversation_row = db.get(Conversation, user_message.conversation_id)
                    if conversation_row is not None:
                        conversation_row.message_count = (conversation_row.message_count or 0) + 1
                        conversation_row.total_tokens = (conversation_row.total_tokens or 0) + (event.data.get("prompt_tokens", 0) + event.data.get("completion_tokens", 0))
                        conversation_row.total_charged_micro = (conversation_row.total_charged_micro or 0) + (event.data.get("charged_micro") or 0)
                        conversation_row.search_text = ((conversation_row.search_text or "") + " " + event.data.get("text", ""))[:20000].lower()
                        conversation_row.updated_at = dt.datetime.now(dt.timezone.utc)
                    db.commit()
                    yield _sse("done", {**event.data, "assistant_message_id": assistant.id,
                                      "empty_answer": stream_note})
        except Exception as exc:  # noqa: BLE001 - stream must always terminate cleanly
            log.exception("stream failed user=%s model=%s", user.id, ref.model.id)
            from app.core.errors import NexaError

            code = getattr(exc, "code", "internal_error")
            message = exc.detail if isinstance(exc, NexaError) else "The response stream failed unexpectedly."
            yield _sse("error", {"category": code, "message": message, "partial_text": "".join(collected)})

    return StreamingResponse(
        event_source(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no", "Connection": "keep-alive"},
    )


def _sse(event: str, data: dict[str, Any]) -> str:
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False, default=str)}\n\n"


def _store_assistant_message(db, user_message: Message, ref, text: str, **kwargs: Any) -> Message:  # noqa: ANN001
    message = Message(
        conversation_id=user_message.conversation_id,
        user_id=user_message.user_id,
        role=MessageRole.ASSISTANT,
        content=text,
        model_id=ref.model.id,
        provider_model_id=ref.model.provider_model_id,
        status=kwargs.get("status", "complete"),
        error_category=kwargs.get("error_category"),
        error_message=kwargs.get("error_message"),
        prompt_tokens=kwargs.get("prompt_tokens"),
        completion_tokens=kwargs.get("completion_tokens"),
        total_tokens=(kwargs.get("prompt_tokens") or 0) + (kwargs.get("completion_tokens") or 0) or None,
        latency_ms=kwargs.get("latency_ms"),
        provider_request_id=kwargs.get("provider_request_id"),
        finish_reason=kwargs.get("finish_reason"),
        content_parts=kwargs.get("content_parts"),
    )
    db.add(message)
    db.commit()
    return message


@router.post("/conversations/{conversation_id}/regenerate")
async def regenerate(
    conversation_id: int,
    db: DbDep,
    user: CurrentUser,
    model_id: int | None = None,
    temperature: float | None = None,
    max_tokens: int | None = None,
) -> dict[str, Any]:
    """Regenerate the last assistant reply from the existing history."""
    conversation = db.get(Conversation, conversation_id)
    if conversation is None or conversation.user_id != user.id:
        raise NotFound("Conversation not found.")
    history = _load_history(db, conversation, limit=40)
    if not history:
        raise ValidationError("This conversation has no messages to regenerate from.")
    last_assistant = next((m for m in reversed(history) if m.role == MessageRole.ASSISTANT), None)
    if last_assistant is not None:
        db.delete(last_assistant)
        db.flush()
    chat_messages = [ChatMessage(role=m.role, content=m.content) for m in history if m.role in (MessageRole.USER, MessageRole.ASSISTANT)]
    while chat_messages and chat_messages[-1].role == MessageRole.ASSISTANT:
        chat_messages.pop()
    if not chat_messages:
        raise ValidationError("There is no user prompt to regenerate from.")
    ref = ai_service.resolve_model(db, user=user, model_id=model_id or conversation.model_id, operation="chat")
    response, outcome = await ai_service.run_chat(
        db, user=user, model_ref=ref, messages=chat_messages, system=conversation.system_prompt,
        temperature=temperature, max_tokens=max_tokens or ref.model.max_output_tokens or None,
        module=conversation.module, conversation_id=conversation.id,
        idempotency_key=f"regen:{conversation.id}:{int(dt.datetime.now(dt.timezone.utc).timestamp())}",
    )
    assistant = Message(
        conversation_id=conversation.id, user_id=user.id, role=MessageRole.ASSISTANT, content=response.text,
        model_id=ref.model.id, provider_model_id=ref.model.provider_model_id, prompt_tokens=outcome.usage.prompt_tokens,
        completion_tokens=outcome.usage.completion_tokens, total_tokens=outcome.usage.total_tokens,
        latency_ms=response.latency_ms, provider_request_id=response.provider_request_id, status="complete",
        usage_id=outcome.usage.id,
    )
    db.add(assistant)
    conversation.message_count = (conversation.message_count or 0) + 1
    conversation.total_charged_micro = (conversation.total_charged_micro or 0) + outcome.usage.charged_micro
    conversation.updated_at = dt.datetime.now(dt.timezone.utc)
    db.commit()
    return {"message": _message_payload(assistant),
            "usage": {"charged_micro": outcome.usage.charged_micro, "usage_source": outcome.usage.usage_source}}


@router.post("/messages/{message_id}/resubmit")
async def edit_and_resubmit(
    message_id: int,
    payload: dict[str, Any],
    db: DbDep,
    user: CurrentUser,
) -> dict[str, Any]:
    """Edit a user prompt and re-run the conversation from that point."""
    message = db.get(Message, message_id)
    if message is None or message.role != MessageRole.USER:
        raise NotFound("User message not found.")
    conversation = db.get(Conversation, message.conversation_id)
    if conversation is None or conversation.user_id != user.id:
        raise NotFound("Message not found.")
    new_content = str(payload.get("content") or "").strip()
    if not new_content:
        raise ValidationError("The edited prompt must not be empty.")
    message.content = new_content
    # drop every message after the edited prompt (they are regenerated)
    for later in db.scalars(select(Message).where(Message.conversation_id == conversation.id, Message.id > message.id)).all():
        db.delete(later)
    db.flush()
    history = _load_history(db, conversation, limit=40)
    chat_messages = [ChatMessage(role=m.role, content=m.content) for m in history if m.role in (MessageRole.USER, MessageRole.ASSISTANT)]
    ref = ai_service.resolve_model(db, user=user, model_id=conversation.model_id, operation="chat")
    response, outcome = await ai_service.run_chat(
        db, user=user, model_ref=ref, messages=chat_messages, system=conversation.system_prompt,
        module=conversation.module, conversation_id=conversation.id,
        idempotency_key=f"resubmit:{message.id}:{int(dt.datetime.now(dt.timezone.utc).timestamp())}",
    )
    assistant = Message(
        conversation_id=conversation.id, user_id=user.id, role=MessageRole.ASSISTANT, content=response.text,
        model_id=ref.model.id, provider_model_id=ref.model.provider_model_id, prompt_tokens=outcome.usage.prompt_tokens,
        completion_tokens=outcome.usage.completion_tokens, total_tokens=outcome.usage.total_tokens,
        latency_ms=response.latency_ms, status="complete", usage_id=outcome.usage.id,
    )
    db.add(assistant)
    conversation.updated_at = dt.datetime.now(dt.timezone.utc)
    db.commit()
    return {"message": _message_payload(assistant), "edited_prompt": new_content}
