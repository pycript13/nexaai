# راهنمای کامل نصب، راه‌اندازی، استفاده و تست — Nexa AI

> این سند تنها راهنمای عملیاتی پروژه است: از صفر تا نصب روی سرور، راه‌اندازی ارائه‌دهنده‌ی هوش مصنوعی،
> فعال‌کردن کاربران، پرداخت اعتبار، پشتیبان‌گیری و تست کردن همه‌ی مسیرها.
> نسخه‌ی انگلیسی همین راهنما: [`INSTALLATION_GUIDE.md`](INSTALLATION_GUIDE.md)

---

## فهرست

1. [این راهنما برای کیست](#۱-این-راهنما-برای-کیست)
2. [اجزای سیستم در یک نگاه](#۲-اجزای-سیستم-در-یک-نگاه)
3. [پیش‌نیازها](#۳-پیشنیازها)
4. [نصب سریع (خلاصه‌ی چند مسیر)](#۴-نصب-سریع-خلاصهی-سه-مسیر)
5. [مسیر A — نصب با Docker روی هر سروری (پیشنهادی)](#۵-مسیر-a--نصب-با-docker-روی-هر-سروری-پیشنهادی)
6. [مسیر B — نصب بومی روی Ubuntu/Debian (بدون Docker)](#۶-مسیر-b--نصب-بومی-روی-ubuntudebian-بدون-docker)
7. [مسیر C — نصب روی ویندوز](#۷-مسیر-c--نصب-روی-ویندوز)
8. [مسیر D — اجرای توسعه‌دهنده (سبک، SQLite)](#۸-مسیر-d--اجرای-توسعهدهنده-سبک-sqlite)
9. [تنظیم فایل .env](#۹-تنظیم-فایل-env)
10. [راه‌اندازی اولیه‌ی پلتفرم (مدیر سیستم)](#۱۰-راهاندازی-اولیهی-پلتفرم-مدیر-سیستم)
11. [استفاده‌ی روزمره (کاربر و مدیر)](#۱۱-استفادهی-روزمره-کاربر-و-مدیر)
12. [انتشار روی IP عمومی بدون دامنه (الزامی)](#۱۲-انتشار-روی-ip-عمومی-بدون-دامنه-الزامی)
13. [HTTPS با دامنه (اختیاری، برای بهره‌برداری واقعی)](#۱۳-https-با-دامنه-اختیاری-برای-بهرهبرداری-واقعی)
14. [تست: چطور مطمئن شویم همه‌چیز کار می‌کند](#۱۴-تست-چطور-مطمئن-شویم-همهچیز-کار-میکند)
15. [پشتیبان‌گیری و بازیابی](#۱۵-پشتیبانگیری-و-بازیابی)
16. [نگهداری، به‌روزرسانی و کارهای دوره‌ای](#۱۶-نگهداری-بهروزرسانی-و-کارهای-دورهای)
17. [عیب‌یابی](#۱۷-عیبیابی)
18. [چک‌لیست امنیتی](#۱۸-چکلیست-امنیتی)
19. [پیوست‌ها: دستورها، نقش‌ها، متغیرها](#۱۹-پیوستها-دستورها-نقشها-متغیرها)

---

## ۱. این راهنما برای کیست

| شما | از کدام بخش شروع کنید |
| --- | --- |
| می‌خواهم سریع روی یک سرور بالا بیاورم | [نصب سریع](#۴-نصب-سریع-خلاصهی-سه-مسیر) → [مسیر A](#۵-مسیر-a--نصب-با-docker-روی-هر-سروری-پیشنهادی) |
| سرور اوبونتو دارم و Docker نمی‌خواهم | [مسیر B](#۶-مسیر-b--نصب-بومی-روی-ubuntudebian-بدون-docker) |
| روی ویندوز اجرا می‌کنم | [مسیر C](#۷-مسیر-c--نصب-روی-ویندوز) |
| می‌خواهم روی لپ‌تاپ توسعه بدهم/تست کنم | [مسیر D](#۸-مسیر-d--اجرای-توسعهدهنده-سبک-sqlite) |
| مدیری و می‌خواهی مدل و قیمت اضافه کنی | [راه‌اندازی اولیه](#۱۰-راهاندازی-اولیهی-پلتفرم-مدیر-سیستم) |
| می‌خواهی به دوستان/کارفرما نشان بدهی | [IP عمومی](#۱۲-انتشار-روی-ip-عمومی-بدون-دامنه-الزامی) → [تست](#۱۴-تست-چطور-مطمئن-شویم-همهچیز-کار-میکند) |
| چیزی خراب شده | [عیب‌یابی](#۱۷-عیبیابی) |

---

## ۲. اجزای سیستم در یک نگاه

```
مرورگر کاربر
   │  HTTP/HTTPS
   ▼
┌──────────────────────────────┐
│ Nginx (پورت ۸۰۸۰ یا ۸۰/۴۴۳)  │  ← سرو کردن SPA و پروکسی /api
└──────────────┬───────────────┘
               ▼
      ┌──────────────────┐        ┌───────────────────┐
      │ API (FastAPI)    │───────▶│ PostgreSQL (داده) │
      │ app.main:app     │        └───────────────────┘
      └───────┬──────────┘        ┌───────────────────┐
              │                   │ Redis (اختیاری)   │
              ▼                   └───────────────────┘
      ┌──────────────────┐        ┌───────────────────┐
      │ Worker (صف کار)  │───────▶│ ذخیره‌سازی فایل‌ها │
      └───────┬──────────┘        └───────────────────┘
              ▼
      ┌──────────────────────────────────────────────┐
      │ ارائه‌دهنده‌های هوش مصنوعی (OpenAI/Anthropic/…) │
      └──────────────────────────────────────────────┘
```

| جزء | فناوری | نقش | الزامی؟ |
| --- | --- | --- | --- |
| `frontend/` | React 18 + TypeScript + Vite | رابط کاربری، چیدمان راست‌به‌چپ، ۴ زبان، ۳ پوسته | بله |
| `backend/` | Python 3.11–3.13 + FastAPI + SQLAlchemy 2 + Alembic | API، احراز هویت، صورتحساب، مدیریت ارائه‌دهنده و مدل، تست مدل | بله |
| PostgreSQL | نسخه‌ی ۱۵/۱۶ | پایگاه داده در بهره‌برداری واقعی | بله (مگر تست) |
| Redis | نسخه‌ی ۷ | محدودسازی نرخ و هماهنگی کارگرها | خیر (در نبودش هشدار می‌دهد و درون‌فرایندی کار می‌کند) |
| Worker | `python -m app.workers.worker` | پردازش کارهای تصویر/صدا/ویدئو/سند | بله برای کارهای غیرهمزمان |
| Nginx | ۱.۲۴+ | وب‌سرور استاتیک + پروکسی + پخش بدون بافر پاسخ‌های جریانی | بله در بهره‌برداری |
| Docker Compose | v2 | اجرای یکپارچه‌ی همه‌ی بالا | اختیاری |

**نکته‌ی مهم درباره‌ی «واقعی بودن»:** این پلتفرم هیچ پاسخ ساختگی تولید نمی‌کند. تا وقتی ارائه‌دهنده‌ی واقعی
پیکربندی نشود، درخواست‌ها با خطای صریح `503 not_configured` پاسخ داده می‌شوند. مدل‌ها تا زمانی که مدیر
تست تأییدشده انجام ندهد، برای کاربر تغییر وضعیت نمی‌دهند (`availability: untested`).

---

## ۳. پیش‌نیازها

### ۳.۱ سخت‌افزار

| سطح | CPU | RAM | دیسک | مناسب برای |
| --- | --- | --- | --- | --- |
| تست/نمایش | ۱ هسته | ۱ گیگابایت | ۱۰ گیگابایت | چند کاربر، بدون Docker |
| کوچک | ۲ هسته | ۲ گیگابایت | ۲۰ گیگابایت | تا ~۵۰ کاربر، Docker + PostgreSQL |
| متوسط | ۴ هسته | ۸ گیگابایت | ۵۰ گیگابایت | تا ~۳۰۰ کاربر، Nginx + چند worker |
| بزرگ | ۸+ هسته | ۱۶+ گیگابایت | ۲۰۰ گیگابایت | نیازمند تفکیک PostgreSQL/Redis به سرور جدا |

### ۳.۲ نرم‌افزار

| مورد | نسخه‌ی حداقل | توضیح |
| --- | --- | --- |
| Python | 3.11 (آزمایش‌شده تا 3.13) | برای API، CLI، تست‌ها |
| Node.js | 20 LTS | فقط برای ساختن بسته‌ی رابط کاربری |
| PostgreSQL | 15 (توصیه: 16) | در بهره‌برداری واقعی الزامی |
| Redis | 7 (اختیاری) | بدون آن هم بالا می‌آید |
| Docker + Compose | 24 / v2 | فقط در مسیر A |
| Nginx | 1.24 | مسیرهای B و C (سمت لینوکس) |

پورت‌های پیش‌فرض: `8080` (ورودی کاربر از طریق Nginx)، `8000` (API، فقط روی loopback در نصب بومی)،
`5432` (PostgreSQL، **نباید عمومی شود**)، `6379` (Redis، **نباید عمومی شود**)، `5173` (سرور توسعه‌ی Vite).

---

## ۴. نصب سریع (خلاصه‌ی چند مسیر)

### مسیر A — Docker (توصیه‌شده)

```bash
git clone <آدرس-مخزن> nexa-ai && cd nexa-ai
cp deployment/.env.production.example .env
# ویرایش .env: POSTGRES_PASSWORD، NEXA_SECRET_KEY، NEXA_ENCRYPTION_KEY،
#             NEXA_BOOTSTRAP_ADMIN_EMAIL/PASSWORD، NEXA_PUBLIC_BASE_URL
docker compose up -d --build
docker compose exec api python -m app.cli doctor
```

سپس مرورگر: `http://IP-سرور:8080`

### مسیر B — اوبونتو بدون Docker

```bash
git clone <آدرس-مخزن> nexa-ai && cd nexa-ai
sudo bash deployment/linux/install.sh
```

نصب‌کننده خودش PostgreSQL، Redis، Nginx، سرویس‌های systemd، کلیدهای امن و مدیر اول را می‌سازد.

### مسیر C — ویندوز

```bat
deployment\windows\install.bat      :: نصب (پایتون + Node + دیتابیس + مدیر)
deployment\windows\start.bat        :: اجرا روی 127.0.0.1:8000
deployment\windows\start_public.bat :: اجرا روی 0.0.0.0:8000 برای دسترسی از شبکه
deployment\windows\diagnose.bat     :: گزارش وضعیت و عیب‌یابی
```

### مسیر D — توسعه‌ی محلی

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r backend/requirements-dev.txt
cp .env.example .env      # NEXA_DATABASE_URL=sqlite:///./data/nexa.db
cd backend && python -m alembic upgrade head && python -m app.cli bootstrap
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
# ترمینال دوم:
cd frontend && npm install && npm run dev     # http://localhost:5173
```

### مسیر E — GitHub Codespaces (برای تست سریع و اشتراک لینک با دیگران)

اگر می‌خواهید پروژه را در یک فضای کاری ابری (GitHub Codespaces) اجرا کنید و لینک را برای کسی
بفرستید تا **حساب بسازد و وارد شود**، این سه دستور کافی است:

```bash
bash deployment/codespaces/setup.sh            # نصب کامل + ساخت مدیر + build رابط کاربری
bash deployment/codespaces/start.sh --daemon   # یک پورت: ۸۰۸۰ (خودِ API رابط کاربری را سرو می‌کند)
gh codespace ports visibility 8080:public -c "$CODESPACE_NAME"   # تا دیگران هم لینک را باز کنند
```

* لینک نهایی مثل `https://<نام-workspace>-8080.app.github.dev` است؛ همین را برای دوستتان بفرستید.
* پورت‌ها در Codespaces پیش‌فرض **خصوصی** هستند؛ بدون دستور بالا دیگران صفحه‌ای نمی‌بینند.
* ثبت‌نام در این حالت **باز** است (`NEXA_REGISTRATION_MODE=open`). برای حالت دعوت‌نامه‌ای:
  **Admin → Settings → registration.mode = invite_only**.
* اگر خطای `400 host_not_allowed` دیدید، در `backend/.env` مقدار `NEXA_ALLOW_DEV_HOSTS=true` را
  بگذارید و سرویس را دوباره اجرا کنید (آدرس workspace با هر rebuild تغییر می‌کند).
* راهنمای کامل دوزبانه: [`docs/CODESPACES.md`](CODESPACES.md).

---

## ۵. مسیر A — نصب با Docker روی هر سروری (پیشنهادی)

### ۵.۱ آماده‌سازی سرور

```bash
# اوبونتو ۲۲/۲۴
sudo apt update && sudo apt -y upgrade
curl -fsSL https://get.docker.com | sudo sh          # Docker + Compose v2
sudo usermod -aG docker "$USER" && newgrp docker
sudo apt -y install git unzip curl
```

### ۵.۲ گرفتن پروژه و ساختن `.env`

```bash
git clone <آدرس-مخزن> nexa-ai && cd nexa-ai
cp deployment/.env.production.example .env
```

تولید کلیدها و رمزها:

```bash
python3 -c "import secrets;print('NEXA_SECRET_KEY=' + secrets.token_urlsafe(48))"
python3 -c "from cryptography.fernet import Fernet;print('NEXA_ENCRYPTION_KEY=' + Fernet.generate_key().decode())"
python3 -c "import secrets;print('POSTGRES_PASSWORD=' + secrets.token_urlsafe(24))"
```

مقادیر زیر را در `.env` **باید** عوض کنید:

| کلید | مقدار نمونه |
| --- | --- |
| `POSTGRES_PASSWORD` | رمز تصادفی قوی |
| `NEXA_SECRET_KEY` | ۶۴ کاراکتر تصادفی |
| `NEXA_ENCRYPTION_KEY` | کلید Fernet (۴۴ کاراکتر) |
| `NEXA_BOOTSTRAP_ADMIN_EMAIL` | `admin@example.com` |
| `NEXA_BOOTSTRAP_ADMIN_PASSWORD` | رمز قوی (۱۲+ کاراکتر با حرف و عدد) |
| `NEXA_PUBLIC_BASE_URL` | `http://203.0.113.10:8080` (IP واقعی سرور) |
| `NEXA_PUBLIC_PORT` | پورت ورودی (پیش‌فرض ۸۰۸۰) |

### ۵.۳ اجرا

```bash
docker compose up -d --build          # ساخت و اجرا
docker compose ps                     # همه باید healthy/up باشند
docker compose logs -f api            # لاگ API
docker compose exec api python -m app.cli doctor
```

سرویس‌ها: `db` (PostgreSQL، بدون انتشار پورت)، `redis`، `api`، `worker`، `web` (Nginx، تنها پورت منتشرشده).

### ۵.۴ تحلیل خودکار: جدول بررسی

```bash
curl -s http://127.0.0.1:8080/healthz          # {"status":"ok",...}
curl -s http://127.0.0.1:8080/readyz           # آماده‌بودن دیتابیس
curl -s http://127.0.0.1:8080/api/v1/health/deep | python3 -m json.tool
```

### ۵.۵ مهاجرت‌ها و مدیر

مهاجرت‌ها هنگام بالا آمدن کانتینر `api` اجرا می‌شوند (`alembic upgrade head`) و سپس `bootstrap`.
اگر لازم شد دستی اجرا کنید:

```bash
docker compose exec api python -m alembic upgrade head
docker compose exec api python -m app.cli bootstrap
docker compose exec api python -m app.cli create-admin --email me@example.com --password 'رمز-قوی' --name "مدیر دوم"
```

### ۵.۶ به‌روزرسانی و توقف

```bash
git pull
docker compose build --pull
docker compose up -d                 # مهاجرت‌ها خودکار اجرا می‌شوند
docker compose down                  # توقف (داده‌ها در volume می‌ماند)
docker compose down -v               # ⚠️ حذف کامل داده‌ها و volume‌ها
```

---

## ۶. مسیر B — نصب بومی روی Ubuntu/Debian (بدون Docker)

### ۶.۱ روش خودکار

```bash
git clone <آدرس-مخزن> nexa-ai && cd nexa-ai
sudo bash deployment/linux/install.sh
```

**نصب‌کننده از شما می‌پرسد، خودش تصمیم نمی‌گیرد.** روی ترمینال سه پرسش می‌بینید:

```
How should people reach this application?
  1) Public IP, no domain      — http://<server-ip>:<port>  (سریع، بدون رمزنگاری)
  2) A domain (with HTTPS)     — مثلاً ai.example.com  (Nginx + گواهی Let's Encrypt)
  3) This machine only         — فقط روی همین ماشین: http://127.0.0.1:8000
Administrator e-mail (the sign-in name) [admin@example.com]:
Administrator display name [Nexa Administrator]:
Password: حداقل ۱۰ کاراکتر، تایپ مخفی است — Enter تنها = ساخت رمز قوی
```

یعنی **حالت دسترسی** و **ایمیل/نام/رمز مدیر اصلی** را خودتان انتخاب می‌کنید. همه‌چیز پیش از نصب اعتبارسنجی
می‌شود و اجرای دوباره روی یک نصب موجود، آن را دست‌نخورده نگه می‌دارد (مقادیر قبلی به‌عنوان پیش‌فرض نشان داده
می‌شوند و رمز فقط وقتی خودتان بخواهید عوض می‌شود).

اجرای غیرتعاملی (اسکریپت/cloud-init/cron) — همان پاسخ‌ها با پرچم:

| پرچم | معنا |
| --- | --- |
| `--access public` \| `domain` \| `local` | حالت دسترسی (پیش‌فرض در حالت غیرتعاملی: `public`) |
| `--domain ai.example.com` | دامنه‌ای که به این سرور اشاره می‌کند (خودش `--access domain` را فعال می‌کند) |
| `--acme-email you@example.com` | ایمیل Let's Encrypt (برای صدور خودکار گواهی) |
| `--public-port N` | پورت انتشار (پیش‌فرض ۸۰۸۰؛ در حالت دامنه ۸۰) |
| `--admin-email A` و `--admin-name N` | مدیر اصلی |
| `--admin-password P` | رمزی که خودتان می‌گذارید (اگر ندهید، پرسیده می‌شود یا رمز قوی ساخته می‌شود) |
| `--generate-admin-password` | بدون پرسش، رمز قوی بساز و در `.env` ذخیره کن |
| `--non-interactive` | هیچ پرسشی نپرس (روی ترمینال نبودن هم خودکار همین است) |
| `--app-dir`، `--python` | مسیر نصب / مفسر پایتون |
| `--no-packages`، `--no-node`، `--no-nginx`، `--no-systemd` | رد کردن مراحلی که خودتان مدیریت می‌کنید |
| `--reset-env`، `--reset-admin-password`، `--no-public-check` | تعمیر و اجرای مجدد |

برای اتوماسیونی که نمی‌خواهد رمز در خط فرمان دیده شود، `NEXA_ADMIN_PASSWORD` را در محیط بگذارید.
`-h` فهرست کامل را چاپ می‌کند. متغیر `NEXA_PUBLIC_IP` آدرس عمومی را دستی تعیین می‌کند (NAT دوگانه/CGNAT/پروکسی).

**تغییر حالت بعداً = اجرای مجدد، نه نصب دوباره:** دیتابیس، فایل‌ها و تنظیمات می‌مانند و `--access …` فقط
پیکربندی دسترسی را بازنویسی می‌کند (از `.env` یک نسخه‌ی پشتیبان گرفته می‌شود).

**نسخه‌ی پایتون:** این نسخه از پروژه **Python 3.11 تا 3.13** را پشتیبانی می‌کند. بسته‌های قفل‌شده
(`pydantic 2.10` / `pydantic-core 2.27`) فقط تا پایتون ۳.۱۳ ویل آماده دارند؛ روی ۳.۱۴ مجبور به کامپایل
با Rust می‌شود و خطای `Failed building wheel for pydantic-core` می‌دهد. خود اسکریپت مفسر مناسب را پیدا
می‌کند (`python3.13` → `python3.12` → `python3.11` → `/usr/bin/python3`)، در صورت نیاز `python3` را نصب
می‌کند، اگر محیط مجازی قبلی با نسخه‌ی نامناسب ساخته شده باشد آن را بازمی‌سازد و `--python` خارج از
محدوده را رد می‌کند.

این اسکریپت به‌ترتیب:

1. بسته‌های سیستمی (python3-venv، postgresql، redis، nginx، nodejs/npm، curl، git، sqlite3، rsync) را نصب می‌کند.
2. **خودش PostgreSQL و Redis را روشن می‌کند** (systemd ← `service` ← `pg_ctlcluster` ← `pg_ctl` خام) و با
   `pg_isready` صبر می‌کند تا واقعاً اتصال بپذیرد؛ سپس منتظر پایان کار می‌ماند. دیگر فرض نمی‌کند سرور شما
   سرویس‌ها را خودکار اجرا کرده است.
3. کاربر سیستمی `nexa` و مسیر `/opt/nexa-ai` را می‌سازد و پروژه را کپی می‌کند — **بدون** دست‌زدن به
   `.env`، `venv/`، `data/`، `uploads/`، `backups/` و `logs/` (اجرای مجدد = ارتقا، نه پاک‌سازی).
4. پایگاه داده و نقش PostgreSQL را می‌سازد؛ اگر `.env` قبلی باشد رمز همان را برمی‌دارد تا برنامه از
   پایگاه داده‌ی خودش قفل نشود.
5. فایل `/opt/nexa-ai/.env` را با کلیدهای تازه می‌سازد (مجوز `600`).
6. محیط مجازی پایتون و وابستگی‌ها را نصب می‌کند.
7. رابط کاربری را می‌سازد (اگر Node نصب باشد).
8. **پیش‌بررسی** با `app.cli doctor`: اگر برنامه با این پیکربندی بالا نیاید (کلید جای‌گزین، SQLite در
   production، `NEXA_TRUSTED_HOSTS=*`) همان‌جا با پیام دقیق متوقف می‌شود.
9. `alembic upgrade head` و `bootstrap` را اجرا می‌کند.
10. سرویس‌های systemd (`nexa-api`, `nexa-worker`) و سایت Nginx روی پورت ۸۰۸۰ را نصب می‌کند — و اگر
    systemd وجود نداشت (کانتینر)، همان دو پروسه را با `deployment/linux/nexa-services.sh` اجرا می‌کند.
11. در پایان **سلامت سرویس** (`/readyz`) و **ورود واقعی مدیر** را آزمایش می‌کند؛ خروجی موفق:
    `[ok] administrator sign-in verified`.
12. آدرس عمومی سرور را تشخیص می‌دهد (اگر سرور پشت NAT باشد، آدرس داخلی `172.x` را به‌عنوان «آدرس کاربر»
    چاپ نمی‌کند) و سپس با `deployment/linux/check_public_access.sh` **آزمایش می‌کند که آیا مرورگرِ بیرون
    از سرور می‌تواند همان آدرس را باز کند یا نه**؛ نتیجه را درست و بی‌روتوش گزارش می‌کند:
    `[verified: answers from another machine]` یا `[NOT reachable from another machine yet]`.

### ۶.۱.۱ محیط‌های کانتینری (بدون systemd) و خطای رایج PostgreSQL

روی بعضی سرورها (کانتینرهای Docker/LXC، ایمیج‌های ابری مینیمال) سرویس‌ها هنگام نصب با apt خودکار
اجرا نمی‌شوند. اگر با این خطا روبه‌رو شدید:

```
psql: error: connection to server on socket "/var/run/postgresql/.s.PGSQL.5432" failed
        Is the server running locally and accepting connections on that socket?
```

یعنی PostgreSQL نصب شده ولی اجرا نشده است. کافی است:

```bash
sudo pg_ctlcluster 17 main start     # نسخه را از: ls /usr/lib/postgresql/ بردارید
# یا:  sudo service postgresql start
pg_isready                           # باید بگوید: accepting connections
sudo bash deployment/linux/install.sh    # دوباره اجرا کنید؛ اکنون کامل انجام می‌شود
```

### ۶.۱.۲ تعمیر خودکار فایل `.env`

اگر فایل `.env` از نسخه‌های قبلی مانده باشد یا از قالب `deployment/.env.production.example` (که برای
Docker نوشته شده) کپی شده باشد، نصب‌کننده آن را **خودکار تعمیر می‌کند** و هر تغییر را با هشدار اعلام
می‌کند و یک نسخه‌ی پشتیبان `.env.bak.<زمان>` می‌سازد:

| مقدار پیدا‌شده | مقدار اصلاح‌شده |
| --- | --- |
| `NEXA_SECRET_KEY` / `NEXA_ENCRYPTION_KEY` خالی، کوتاه یا شامل `CHANGE_ME` | کلید تصادفی تازه (پس از تغییر کلید رمزنگاری، باید اعتبارنامه‌های ارائه‌دهنده را دوباره وارد کنید) |
| `NEXA_BOOTSTRAP_ADMIN_PASSWORD=CHANGE_ME…` | رمز قوی تازه؛ سپس حساب مدیر موجود به همان رمز بازنشانی می‌شود (ثبت در Audit و ابطال نشست‌ها) |
| `NEXA_TRUSTED_HOSTS=*` | آدرس‌های واقعی سرور + `localhost`, `127.0.0.1` |
| `NEXA_DATABASE_URL` با `@db:5432` یا رمز جای‌گزین | پایگاه داده‌ی محلی با اعتبارنامه‌های نصب |
| `NEXA_UPLOAD_DIR=/app/uploads` و `NEXA_FRONTEND_DIST_DIR=/app/frontend/dist` | مسیرهای همین نصب |
| `NEXA_REDIS_URL=redis://redis:6379/0` | `redis://127.0.0.1:6379/0` |
| `NEXA_PUBLIC_BASE_URL` / `NEXA_CORS_ORIGINS` با `CHANGE_ME_SERVER_IP` | `http://<آی‌پی>:<پورت>` واقعی |
| `KEY=value   # توضیح` (کامنت در همان خط) | `KEY=value` — برنامه کامنت را جزء مقدار می‌خواند و بالا نمی‌آید |

گزینه‌ها: `--reset-env` برای ساخت کامل فایل تازه (با پشتیبان) و `--reset-admin-password` برای هم‌سان‌کردن
رمز حساب مدیر با مقدار موجود در `.env`.

اگر خطای مربوط به پایتون دیدید (مثلاً `Failed building wheel for pydantic-core`):

```bash
rm -rf /opt/nexa-ai/venv                     # محیط مجازی ساخته‌شده با نسخه‌ی نامناسب
sudo bash deployment/linux/install.sh        # خودش ۳.۱۳ را انتخاب می‌کند
# یا صریح: sudo bash deployment/linux/install.sh --python /usr/bin/python3
```

و اگر systemd در دسترس نیست:

```bash
sudo bash deployment/linux/install.sh --no-systemd
/opt/nexa-ai/deployment/linux/nexa-services.sh start|stop|restart|status|logs|keepalive
tail -f /opt/nexa-ai/logs/api.log
```

روی سروری که systemd ندارد، دستور `Restart=always` وجود ندارد؛ پس نصب‌کننده خودش این کار را با کرون
انجام می‌دهد: هر دو دقیقه `nexa-services.sh keepalive` اجرا می‌شود (به‌علاوه یک خط `@reboot` برای بعد از
ری‌استارت سرور) و اگر بسته‌ی `cron` نصب نباشد، خودِ نصب‌کننده نصبش می‌کند. یعنی اگر API یا worker از کار
بیفتد، حداکثر تا دو دقیقه بعد خودش برمی‌گردد — سایت بدون شما پایین نمی‌ماند. برای آزمایش:

```bash
crontab -l | grep nexa-keepalive     # دو خط زمان‌بندی‌شده باید دیده شود
sudo pkill -f 'uvicorn app.main:app' # شبیه‌سازی از کار افتادن سرویس
sleep 120 && curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8000/healthz
```

نکته‌ی مهم: اگر سایت بالا می‌آید ولی `/healthz` یا `/readyz` خطای `Invalid host header` داد، یعنی آدرس یا
دامنه‌ی مورد استفاده در `NEXA_TRUSTED_HOSTS` نیست (هرگز `*` نگذارید) — و در پیکربندی Nginx هر
`location` که `proxy_pass` دارد باید `proxy_set_header Host $host;` داشته باشد (در قالب‌های پروژه هست).

بررسی وضعیت (systemd):

```bash
systemctl status nexa-api nexa-worker nginx postgresql
journalctl -u nexa-api -f                 # لاگ زنده
sudo nginx -t                             # صحت پیکربندی وب‌سرور
/opt/nexa-ai/scripts/health_check.sh http://127.0.0.1:8080
```

بررسی وضعیت (بدون systemd):

```bash
/opt/nexa-ai/deployment/linux/nexa-services.sh status
tail -n 50 /opt/nexa-ai/logs/api.log
```

اگر اجرای مجدد اسکریپت را دیدید که می‌گوید «administrator account already existed»، یعنی کاربر مدیر از
قبل وجود دارد و رمز داخل `.env` قدیمی است؛ رمز تازه بسازید:

```bash
cd /opt/nexa-ai/backend && sudo -u nexa ../venv/bin/python -m app.cli create-admin \
    --email admin@example.com --password '<رمز-قوی-جدید>'
```

### ۶.۱.۳ اگر آدرسِ چاپ‌شده در مرورگر باز نشد (این بخش را بخوانید)

اسکریپت نصب در پایان، آدرس را چاپ می‌کند و **همان‌جا آن را از بیرون آزمایش می‌کند**. سه حالت ممکن است:

| خط `URL:` در پایان نصب | معنا |
|---|---|
| `[verified: answers from another machine]` | آدرس از یک ماشین دیگر پاسخ می‌دهد؛ لینک را به تستر بدهید |
| `[NOT reachable from another machine yet]` | خود برنامه سالم است (سلامت و ورود مدیر پاس شده) ولی مسیر «مرورگر → پورت» بسته است |
| `[not checked]` | نصب را با `--no-public-check` اجرا کرده‌اید |

**شایع‌ترین دلیل: سرور شما آدرس عمومی مالِ خودش را ندارد.** اگر `hostname -I` روی سرور آدرسی مثل
`172.17.0.2` یا `172.20.0.45` یا `10.x` نشان می‌دهد، آن ماشین داخل یک شبکه‌ی خصوصی است (کانتینر،
LXC، نمونه‌ی ابری، NAT دیتاسنتر). مرورگر بیرونی باید به **آدرس عمومی** وصل شود؛ و آن آدرس عمومی مال
ماشین دیگری است (روتر/ابر). تا وقتی کسی پورت ورودی را به این ماشین **Forward/Map** نکند، هیچ تغییری
روی خود سرور این را درست نمی‌کند.

برای تشخیص دقیق، روی سرور اجرا کنید:

```bash
sudo bash /opt/nexa-ai/deployment/linux/check_public_access.sh --port 8080
```

این اسکریپت چهار کار می‌کند: (۱) می‌بیند خودِ برنامه روی `127.0.0.1:8080` پاسخ می‌دهد یا نه،
(۲) آدرس عمومی را از `api.ipify.org` می‌پرسد، (۳) هر دو آدرس را با `curl` آزمایش می‌کند، و
(۴) می‌گوید کدام لایه بسته است و دستور بازکردنش را چاپ می‌کند. کدهای خروجی: `0` = باز است،
`3` = پاسخ نداد، `4` = آدرس بیرونی قابل آزمایش نبود.

سه لایه‌ای که همه باید باز باشند:

| لایه | چطور بفهمیم | چطور باز کنیم |
|---|---|---|
| پورت روی خود ماشین | `sudo ss -ltnp \| grep 8080` باید `0.0.0.0:8080` باشد (نه `127.0.0.1:8080`) | نصب را دوباره اجرا کنید؛ سایت Nginx روی همه‌ی آدرس‌ها گوش می‌دهد |
| فایروال خود ماشین | `sudo ufw status verbose` یا `sudo firewall-cmd --list-ports` | `sudo ufw allow 8080/tcp` |
| NAT / Security Group ابری | خروجی `check_public_access.sh`: «آدرس عمومی پاسخ نداد» | در پنل ابری یک قانون Inbound برای `TCP 8080` به این ماشین اضافه کنید |

**اگر واقعاً آدرس عمومی دارید و باز هم باز نمی‌شود:**

* مرورگرها گاهی `http` را خودکار به `https` ارتقا می‌دهند (در Chrome: `Always use secure connections`).
  آدرس را کامل با `http://` و پورت بزنید: `http://<آدرس-عمومی>:8080`
* از یک ماشین دیگر آزمایش کنید (نه از خود سرور):
  `curl -v http://<آدرس-عمومی>:8080/readyz` — پاسخ `HTTP/1.1 200` یعنی مسیر باز است.
* اگر سرور پشت NAT است و نمی‌توانید Forward کنید، این جایگزین‌ها کار می‌کنند:
  تونل SSH معکوس (`ssh -R 8080:127.0.0.1:8080 user@vps`)، Cloudflare Tunnel، یا اجرای نصب روی
  سروری که خودش IP عمومی دارد.

> در همه‌ی این حالت‌ها سایت روی خود سرور سالم است و می‌توانید با `http://127.0.0.1:8080` آن را ببینید.

**دو هشدار دیگر در پایان نصب** (اگر مربوط باشند چاپ می‌شوند):

* اگر کلید رمزنگاری (`NEXA_ENCRYPTION_KEY`) تازه ساخته شده باشد و در پایگاه داده از قبل اعتبارنامه‌ی
  ارائه‌دهنده ذخیره شده باشد، اسکریپت می‌گوید کدام ارائه‌دهنده‌ها دیگر قابل رمزگشایی نیستند و باید کلیدشان را
  دوباره وارد کنید (`Admin → AI Infrastructure → Providers`). این کار با دستور
  `python -m app.cli check-secrets` هم قابل بررسی است.
* اگر فایل `.env` قبلی تعمیر شده باشد، مسیر نسخه‌ی پشتیبان (`/opt/nexa-ai/.env.bak.<زمان>`) چاپ می‌شود.

### ۶.۲ روش دستی (اگر اسکریپت را نمی‌خواهید)

```bash
sudo apt -y install python3 python3-venv python3-dev build-essential libpq-dev \
                    postgresql redis-server nginx curl git unzip
sudo -u postgres psql -v db_password="'رمز-تصادفی'" -f database/postgres_init.sql
sudo mkdir -p /opt/nexa-ai && sudo chown "$USER" /opt/nexa-ai
cp -a . /opt/nexa-ai && cd /opt/nexa-ai

python3 -m venv venv && ./venv/bin/pip install -r backend/requirements.txt
( cd frontend && npm install && npm run build )

cp deployment/.env.production.example .env
# .env را ویرایش کنید: NEXA_DATABASE_URL=postgresql+psycopg2://nexa:رمز@127.0.0.1:5432/nexa
#                       NEXA_SERVE_FRONTEND=true
#                       NEXA_FRONTEND_DIST_DIR=/opt/nexa-ai/frontend/dist

set -a; source .env; set +a
cd backend && ../venv/bin/python -m alembic upgrade head && ../venv/bin/python -m app.cli bootstrap
../venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 &
```

سپس سرویس‌ها را از الگوهای آماده نصب کنید:

```bash
sudo sed "s|__APP_DIR__|/opt/nexa-ai|g; s|__APP_USER__|$USER|g" deployment/linux/nexa-api.service    | sudo tee /etc/systemd/system/nexa-api.service
sudo sed "s|__APP_DIR__|/opt/nexa-ai|g; s|__APP_USER__|$USER|g" deployment/linux/nexa-worker.service | sudo tee /etc/systemd/system/nexa-worker.service
sudo sed "s|__APP_DIR__|/opt/nexa-ai|g; s|__PUBLIC_PORT__|8080|g" deployment/nginx/nexa-host.conf    | sudo tee /etc/nginx/sites-available/nexa-ai
sudo ln -sf /etc/nginx/sites-available/nexa-ai /etc/nginx/sites-enabled/nexa-ai
sudo systemctl daemon-reload && sudo systemctl enable --now nexa-api nexa-worker nginx
```

### ۶.۳ فایروال

```bash
sudo ufw allow 8080/tcp        # یا 80/443 در حالت دامنه
sudo ufw allow OpenSSH         # هرگز SSH را نبندید
sudo ufw enable
# پورت‌های 5432 و 6379 را باز نکنید
```

---

## ۷. مسیر C — نصب روی ویندوز

### ۷.۱ پیش‌نیاز

* Python 3.11+ از python.org (گزینه‌ی «Add Python to PATH» را تیک بزنید)
* Node.js 20 LTS از nodejs.org (فقط برای ساختن رابط کاربری)
* PostgreSQL 16 (اختیاری ولی برای بهره‌برداری واقعی لازم) — نسخه‌ی نصبی ویندوز

### ۷.۲ نصب

```bat
cd C:\path\to\nexa-ai
deployment\windows\install.bat
```

اسکریپت: محیط مجازی `.venv` می‌سازد، وابستگی‌ها را نصب می‌کند، فایل `.env` را با کلیدهای تازه و رمز
تصادفی مدیر می‌سازد، رابط کاربری را build می‌کند، مهاجرت‌ها و bootstrap را اجرا می‌کند، قاعده‌ی فایروال
TCP 8000 را اضافه کرده و میان‌برهای دسکتاپ می‌سازد.

### ۷.۳ اجرا

| فایل | کار |
| --- | --- |
| `deployment\windows\start.bat` | اجرای API و worker در دو پنجره + باز کردن مرورگر روی `127.0.0.1:8000` |
| `deployment\windows\start_public.bat` | اجرای API روی `0.0.0.0:8000` (نمایش IP و هشدار امنیتی) |
| `deployment\windows\start_worker.bat` | اجرای فقط کارگر |
| `deployment\windows\backup.bat` | پشتیبان‌گیری از دیتابیس و پوشه‌ی `uploads` |
| `deployment\windows\diagnose.bat` | گزارش `app.cli doctor` + بررسی سلامت API |
| `deployment\windows\install_service.bat` | نصب به‌عنوان سرویس ویندوز (NSSM یا Task Scheduler) |
| `deployment\windows\uninstall_service.bat` | حذف سرویس‌ها |

### ۷.۴ PostgreSQL روی ویندوز (برای بهره‌برداری واقعی)

```bat
:: در psql به‌عنوان کاربر postgres
CREATE ROLE nexa LOGIN PASSWORD 'رمز-تصادفی';
CREATE DATABASE nexa OWNER nexa ENCODING 'UTF8';
```

سپس در `.env`:

```ini
NEXA_DATABASE_URL=postgresql+psycopg2://nexa:رمز-تصادفی@127.0.0.1:5432/nexa
NEXA_ENVIRONMENT=production
```

و دوباره مهاجرت‌ها را اجرا کنید:

```bat
cd backend
..\.venv\Scripts\python.exe -m alembic upgrade head
..\.venv\Scripts\python.exe -m app.cli bootstrap
```

---

## ۸. مسیر D — اجرای توسعه‌دهنده (سبک، SQLite)

SQLite فقط برای توسعه و تست است. برنامه در حالت `production` استفاده از SQLite را رد می‌کند
(مگر `NEXA_ALLOW_SQLITE_IN_PRODUCTION=true` که توصیه نمی‌شود).

```bash
# ۱) بک‌اند
python3 -m venv .venv && source .venv/bin/activate
pip install -r backend/requirements-dev.txt
cp .env.example .env
# حداقل این‌ها را ست کنید:
#   NEXA_SECRET_KEY / NEXA_ENCRYPTION_KEY / NEXA_DATABASE_URL=sqlite:///./data/nexa.db
cd backend
python -m alembic upgrade head
python -m app.cli bootstrap
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# ۲) فرانت‌اند (ترمینال دوم)
cd frontend
npm install
npm run dev        # http://localhost:5173  (پروکسی /api به 127.0.0.1:8000)
```

نکته: در حالت توسعه، فرانت‌اند از سرور Vite و API از ۸۰۰۰ اجرا می‌شود. برای یکپارچه‌سازی کامل
(یک پورت، مثل بهره‌برداری) فرانت‌اند را build کنید و `NEXA_SERVE_FRONTEND=true` بگذارید:

```bash
cd frontend && npm run build
cd ../backend && NEXA_SERVE_FRONTEND=true python -m uvicorn app.main:app --port 8000
# مرورگر: http://localhost:8000  (SPA از خود API سرو می‌شود)
```

---

## ۹. تنظیم فایل `.env`

فایل `.env` در ریشه‌ی پروژه قرار می‌گیرد. الگوهای آماده:

| الگو | کاربرد |
| --- | --- |
| `.env.example` | قالب کامل با همه‌ی کلیدها (توسعه) |
| `deployment/.env.production.example` | قالب بهره‌برداری با PostgreSQL و Redis |
| `deployment/windows/nexa.env.example` | قالب ویندوز (مسیرها با `/`) |

### ۹.۱ کلیدهای حتماً لازم

| کلید | توضیح |
| --- | --- |
| `NEXA_DATABASE_URL` | آدرس دیتابیس. نمونه: `postgresql+psycopg2://nexa:رمز@db:5432/nexa` |
| `NEXA_SECRET_KEY` | امضای نشست/توکن‌ها. با `secrets.token_urlsafe(48)` بسازید |
| `NEXA_ENCRYPTION_KEY` | رمزنگاری کلید API ارائه‌دهنده‌ها (Fernet). در `production` اجباری است |
| `NEXA_BOOTSTRAP_ADMIN_EMAIL` / `..._PASSWORD` | مدیر اولیه هنگام bootstrap |
| `NEXA_PUBLIC_BASE_URL` | آدرسی که کاربر می‌بیند (لینک‌ها و هشدارها بر اساس آن ساخته می‌شود) |
| `NEXA_DEPLOYMENT_MODE` | `local` یا `public_ip` یا `domain_https` — روی بنر و پاسخ‌های API اثر دارد |

### ۹.۲ کلیدهای پرکاربرد دیگر

| کلید | پیش‌فرض | کاربرد |
| --- | --- | --- |
| `NEXA_ENVIRONMENT` | `development` | `production` سختگیری‌ها را فعال می‌کند (SQLite رد، کوکی امن، هشدار) |
| `NEXA_PUBLIC_PORT` | `8080` | پورت ورودی Nginx |
| `NEXA_REGISTRATION_MODE` | `open` | `open` / `invite_only` / `closed` |
| `NEXA_COOKIE_SECURE` | `false` | در HTTPS باید `true` شود |
| `NEXA_HSTS_ENABLED` | `false` | فقط پشت HTTPS روشن شود |
| `NEXA_SESSION_TTL_HOURS` | `720` | عمر نشست |
| `NEXA_AUTH_RATE_LIMIT_PER_MINUTE` | `10` | محدودیت نرخ ورود/ثبت‌نام |
| `NEXA_API_RATE_LIMIT_PER_MINUTE` | `240` | محدودیت نرخ عمومی API |
| `NEXA_MAX_UPLOAD_MB` | `50` | حداکثر حجم فایل (در Nginx هم `client_max_body_size` را هم‌تراز کنید) |
| `NEXA_USER_STORAGE_QUOTA_MB` | `2048` | سهمیه‌ی ذخیره‌سازی هر کاربر |
| `NEXA_MANUAL_PAYMENTS_ENABLED` | `true` | پرداخت دستی (کارت به کارت/بانکی) |
| `NEXA_BANK_TRANSFER_INSTRUCTIONS` | خالی | متن راهنمای واریز که به کاربر نشان داده می‌شود |
| `NEXA_CRYPTO_PAYMENTS_ENABLED` + `NEXA_CRYPTO_WALLETS` | `false` | پرداخت رمزارزی (نیازمند کیف پول واقعی) |
| `NEXA_CREDIT_USD_RATE` | `1.0` | ارزش یک اعتبار به دلار |
| `NEXA_DEFAULT_MARKUP_PERCENT` | `30` | سود پیش‌فرض روی هزینه‌ی ارائه‌دهنده |
| `NEXA_MINIMUM_CHARGE_MICRO` | `1000` | کمینه‌ی هزینه‌ی هر درخواست (میکرواعتبار) |
| `NEXA_EMAIL_ENABLED` + SMTP | `false` | ارسال ایمیل تأیید/بازنشانی رمز |
| `NEXA_REQUIRE_EMAIL_VERIFICATION` | `false` | الزام تأیید ایمیل هنگام ثبت‌نام |
| `NEXA_INLINE_WORKER` | `true` | در بهره‌برداری `false` و از سرویس worker استفاده کنید |
| `NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS` | `false` | فقط برای تست محلی با ارائه‌دهنده‌ی داخلی |
| `NEXA_PROVIDER_ALLOWED_HOSTS` | خالی | فهرست سفید دامنه‌ها برای سیاست SSRF |
| `NEXA_SERVE_FRONTEND` / `NEXA_FRONTEND_DIST_DIR` | `true` / `../frontend/dist` | سرو کردن SPA از خود API |

> ⚠️ هرگز فایل `.env` واقعی را در گیت قرار ندهید. پروژه با `.gitignore` جلوی آن را می‌گیرد.

---

## ۱۰. راه‌اندازی اولیه‌ی پلتفرم (مدیر سیستم)

پس از بالا آمدن سرویس:

### گام ۱ — ورود مدیر

به `http://IP:PORT` بروید و با ایمیل/رمز ساخته‌شده در bootstrap وارد شوید (رمز در `.env` است).
اگر حساب با پرچم «تغییر رمز در اولین ورود» ساخته شده، بلافاصله رمز را از **حساب → امنیت** عوض کنید.

### گام ۲ — ساخت ارائه‌دهنده (Providers)

منوی **مدیر → زیرساخت هوش مصنوعی → ارائه‌دهنده‌ها → افزودن**:

| فیلد | نمونه | توضیح |
| --- | --- | --- |
| نوع ارائه‌دهنده | `openai` / `openai_compatible` / `anthropic` / `azure_openai` / `google` / `groq` / `mistral` / `together` / `deepseek` / `openrouter` / `ollama` / `stability` / `elevenlabs` / `deepgram` / `replicate` / `custom` | آداپتور مناسب انتخاب می‌شود |
| نام | `OpenAI Production` | فقط برچسب |
| Base URL | `https://api.openai.com/v1` | اگر خالی بماند از پیش‌فرض همان نوع استفاده می‌شود |
| API Key | `sk-...` | رمزنگاری‌شده ذخیره می‌شود؛ در پاسخ‌های API فقط به‌صورت `sk-********1234` دیده می‌شود |
| فعال | ✅ | اگر تیک نخورد، استفاده از آن ممنوع است و تست مدیر هم انجام نمی‌شود |

سپس **تست اتصال** را بزنید. نتیجه‌ی موفق یعنی کلید و آدرس درست است و تعداد مدل‌های قابل مشاهده گزارش می‌شود.

### گام ۳ — واکشی مدل‌ها (Sync)

دکمه‌ی **همگام‌سازی مدل‌ها** فهرست مدل‌های ارائه‌دهنده را می‌گیرد و هر مدل جدید را با این وضعیت می‌سازد:

* `visibility = hidden` (در فروشگاه کاربران دیده نمی‌شود)
* `published = false`
* `availability = untested` (تا زمان تست تأییدشده قابل استفاده نیست)

این رفتار عمدی است: هیچ مدلی خودبه‌خود منتشر نمی‌شود.

### گام ۴ — قیمت‌گذاری

در **مدیر → مدل‌ها → ویرایش**:

| فیلد | واحد | نمونه |
| --- | --- | --- |
| `selling_input_per_mtok` | اعتبار به‌ازای هر میلیون توکن ورودی | `3` |
| `selling_output_per_mtok` | اعتبار به‌ازای هر میلیون توکن خروجی | `15` |
| `selling_per_image` | اعتبار برای هر تصویر | `0.25` |
| `selling_per_request` | اعتبار برای هر درخواست | `0.05` |
| `selling_per_audio_minute` | اعتبار برای هر دقیقه صدا | `1.2` |
| `provider_cost_*` | **دلار** (هزینه‌ی پرداختی شما به ارائه‌دهنده) | `0.5` / `1.5` |

اگر قیمت فروش را خالی بگذارید و هزینه‌ی ارائه‌دهنده را پر کنید، سیستم قیمت را با
«هزینه‌ی ارائه‌دهنده + درصد سود» می‌سازد و هشدار `derived_from_provider_cost` می‌دهد.
در صورت نبود هر دو، مدل `unpriced` می‌شود، هزینه صفر ثبت می‌گردد و هشدار در API و UI دیده می‌شود.

### گام ۵ — تست تأیید مدل (اجباری برای مدل‌های مخفی)

در تب **تست مدل**، عملیات را از میان قابلیت‌های خود مدل انتخاب کنید
(`chat`, `streaming`, `completion`, `embeddings`, `image_generation`, `image_understanding`,
`audio_transcription`, `speech_generation`, `video_generation`, `rerank`, `tools`, `json_mode`,
`reasoning`, `document_qa`). نتیجه:

* تست در جدول `admin_model_tests` با هزینه‌ی پلتفرم (`billed_to_user: false`) ثبت و audit می‌شود.
* در صورت موفقیت، `availability` از `untested` به `available` می‌رود.
* تست، مدل را **منتشر نمی‌کند** و قفل کاربران را باز نمی‌کند؛ انتشار یک اقدام جدا است.
* سقف روزانه‌ی تست مدیر (`NEXA_ADMIN_TEST_DAILY_LIMIT_MICRO`) از سوءمصرف جلوگیری می‌کند.

### گام ۶ — انتشار برای کاربران

سه کلید را با هم تنظیم کنید:

| کلید | معنا |
| --- | --- |
| `visibility` | `public` = در فروشگاه دیده شود، `hidden` = فقط مدیر |
| `published` | `true` = قابل استفاده توسط کاربران |
| `access_tier` | `free` (رایگان توسط شما)، `credit` (از موجودی کاربر)، `subscription` (فقط با اشتراک فعال)، `restricted` (فقط با مجوز ویژه)، `internal` (فقط مدیر) |

برای مدل‌های `restricted` از **مدل‌ها → مجوزها** برای کاربر یا نقش خاص مجوز بدهید، با سقف مصرف
روزانه/ماهانه و تاریخ انقضا.

### گام ۷ — تنظیم پرداخت

* **کارت به کارت/بانکی:** `NEXA_MANUAL_PAYMENTS_ENABLED=true` و متن `NEXA_BANK_TRANSFER_INSTRUCTIONS`.
  کاربر درخواست پرداخت ثبت می‌کند؛ **هیچ اعتباری خودکار و بدون تأیید مدیر ثبت نمی‌شود**.
  مدیر در «مالی → پرداخت‌ها» با تأیید (و تیک تأییدیه) یک و تنها یک قید دفتر کل با کلید یکتا
  `payment:{reference}` می‌سازد؛ تأیید دوباره خطای `422` می‌دهد.
* **رمزارز:** `NEXA_CRYPTO_PAYMENTS_ENABLED=true` و `NEXA_CRYPTO_WALLETS=BTC=...,ETH=...,USDT-TRC20=...`.
  بررسی تراکنش با «تأیید روی زنجیره» ثبت می‌شود؛ بدون پیکربندی، درخواست با `503` رد می‌شود.
* **درگاه (Stripe / Zarinpal):** آداپتور پیاده‌سازی شده اما برای فعال‌سازی به کلید واقعی و
  نقطه‌ی پایانی webhook نیاز دارد. بازگشت موفق از درگاه **به‌تنهایی** مبنای افزودن اعتبار نیست.
* **اشتراک‌ها:** فعال‌سازی اشتراک یک اقدام مدیر است (`POST /api/v1/admin/billing/subscriptions`)
  و می‌تواند اعتبار شامل‌شده‌ی پلن را به‌صورت قید دفتر کل ثبت کند.

### گام ۸ — کاربران و نقش‌ها

| نقش | دسترسی کلی |
| --- | --- |
| `super_admin` | همه‌ی مجوزها (`*`) |
| `admin` | عملیات روزمره: کاربران، ارائه‌دهنده‌ها، مدل‌ها، قیمت‌گذاری، پشتیبان‌گیری از دید مدیریت (بدون عملیات خطرناک سیستمی) |
| `finance_manager` | قیمت‌گذاری، پرداخت‌ها، بازگشت وجه، اعتبار، گزارش‌ها |
| `model_manager` | ارائه‌دهنده‌ها، مدل‌ها، تست مدل، انتشار، مجوزهای مدل |
| `support_agent` | مشاهده‌ی کاربران و مصرف، تعلیق کاربر متخلف |
| `user` | استفاده‌ی معمولی از پلتفرم |

مجوزها در **مدیر → نقش‌ها** قابل تغییرند؛ هر عملیات حساس در `audit_events` ثبت می‌شود.
ثبت‌نام کاربران با `NEXA_REGISTRATION_MODE` کنترل می‌شود (`closed` = فقط توسط مدیر).

---

## ۱۱. استفاده‌ی روزمره (کاربر و مدیر)

### ۱۱.۱ فضای کار کاربر

| بخش | کار |
| --- | --- |
| داشبورد | موجودی، مصرف امروز/ماه، کارهای در جریان، هشدارهای سیستم |
| چت | گفتگو با پخش زنده (Server-Sent Events)، ساخت/تغییرنام/حذف گفتگو، تولید دوباره، خروجی Markdown |
| کدنویسی | تولید/توضیح/بازبینی/بهینه‌سازی/تست کد. **کد تولیدشده هرگز روی سرور اجرا نمی‌شود** |
| تصویر | تولید تصویر با اندازه/کیفیت، تحلیل تصویر (فقط مدل‌های بینایی) |
| اسناد | خلاصه‌سازی، پرسش‌وپاسخ، استخراج، ترجمه، فهرست‌سازی (embedding) روی PDF/Word/متن |
| تحلیل داده | آمار کاملاً روی سرور از CSV/Excel محاسبه می‌شود و مدل فقط روایت می‌نویسد |
| ترجمه | ترجمه‌ی متنی و دسته‌ای با واژه‌نامه و لحن؛ زبان مبدأ در صورت ارسال نشدن، ادعای تشخیص نمی‌شود |
| صدا | رونویسی و تولید گفتار (فایل خروجی ذخیره و قابل دانلود است) |
| ویدئو | تولید ویدئو (وابسته به ارائه‌دهنده)؛ در نبود ارائه‌دهنده، خطای صریح پیکربندی |
| فایل‌ها | بارگذاری امن (بررسی امضا/حجم/سهمیه)، دانلود خصوصی، حذف، سهمیه‌ی ذخیره‌سازی |
| کارها | وضعیت کارهای غیرهمزمان با درصد پیشرفت و امکان لغو |
| صورتحساب | موجودی، دفتر کل با «موجودی پس از هر تراکنش»، پرداخت‌ها، اشتراک‌ها، مصرف |
| حساب | پروفایل، امنیت (تغییر رمز، فهرست نشست‌ها، خروج همه‌جا)، فعالیت‌ها |

زبان و پوسته: فارسی (پیش‌فرض، راست‌به‌چپ)، انگلیسی، عربی، کردی سورانی + پوسته‌های روشن/تیره/سیستم
(و پوسته‌ی شیشه‌ای در صورت فعال بودن).

### ۱۱.۲ مدیریت

| صفحه‌ی مدیر | کار |
| --- | --- |
| داشبورد | آمار کاربران، مصرف، مالی، خطاها، audit، وضعیت استقرار |
| کاربران | ساخت/ویرایش، تعلیق/فعال‌سازی، نقش‌ها، ثبت اعتبار (با قید دفتر کل)، بازنشانی رمز، قطع نشست‌ها، دفتر کل کاربر |
| نقش‌ها | ویرایش مجوزها به تفکیک گروه |
| ارائه‌دهنده‌ها | ساخت/ویرایش/تست/همگام‌سازی/جایگزینی کلید/حذف |
| مدل‌ها | فهرست با فیلترهای visibility/availability/published/only_problems، ویرایش قیمت و قابلیت، عملیات گروهی (publish/unpublish/enable/disable)، تست و تاریخچه‌ی تست، مجوزها |
| قیمت‌گذاری | قواعد قیمت در سطوح user/plan/model/provider/global با نسخه‌بندی و markup |
| پرداخت‌ها | بررسی، تأیید، رد، بازگشت وجه (قید جبرانی)، تأیید رمزارز |
| پلن‌ها | ساخت پلن و فعال‌سازی اشتراک برای کاربر |
| کارها | صف و تلاش دوباره‌ی کارهای ناموفق |
| تنظیمات | تنظیمات مجاز زمان اجرا (فقط کلیدهای غیرحساس) |
| audit | جست‌وجو در رخدادهای مدیریتی (فقط خواندنی) |
| امنیت | رویدادهای امنیتی (ورود ناموفق، رد مجوز) |
| سیستم | وضعیت مولفه‌ها، فضای دیسک، حالت استقرار |
| خطاها | خطاهای دسته‌بندی‌شده با شناسه‌ی درخواست |
| پشتیبان | اجرای پشتیبان و تاریخچه |

---

## ۱۲. انتشار روی IP عمومی بدون دامنه (الزامی)

این حالت **پشتیبانی‌شده** است ولی ناامن؛ برای تست و نمایش کوتاه‌مدت طراحی شده و پلتفرم خودش هشدار می‌دهد.

### ۱۲.۱ Docker

```ini
# .env
NEXA_DEPLOYMENT_MODE=public_ip
NEXA_PUBLIC_BASE_URL=http://203.0.113.10:8080
NEXA_PUBLIC_PORT=8080
NEXA_COOKIE_SECURE=false
NEXA_HSTS_ENABLED=false
NEXA_REGISTRATION_MODE=invite_only     # یا closed
```

```bash
docker compose up -d
# باز کردن پورت در فایروال سرور/ابری:
sudo ufw allow 8080/tcp
```

### ۱۲.۲ نصب بومی (ساده‌ترین راه امروز برای این‌که دیگران باز کنند)

همه‌ی این کارها خودکار است:

```bash
sudo bash deployment/linux/install.sh --access public --public-port 8080 \
     --admin-email you@example.com --admin-name "Your Name"      # رمز را می‌پرسد
```

در پایان، نصب‌کننده بلوک **SHARE IT WITH OTHERS** را چاپ می‌کند: آدرسی که باید برای دیگران بفرستید، و اگر
برای آن‌ها باز نشد، دقیقاً سه علت ممکن را نام می‌برد (فایروال میزبان، Security Group ابری، NAT/port-forward)
همراه با دستور بررسی مجدد:

```bash
sudo bash deployment/linux/check_public_access.sh --port 8080
```

برای «فقط یک بار» بدون تغییر تنظیمات دائمی هم می‌توانید مثل قبل دستی عمل کنید:

* `NEXA_PUBLIC_BASE_URL=http://IP:8080` و `NEXA_DEPLOYMENT_MODE=public_ip` را در `.env` بگذارید.
* Nginx روی پورت ۸۰۸۰ گوش می‌دهد (`deployment/nginx/nexa-host.conf`) و `/api` را به `127.0.0.1:8000`
  پروکسی می‌کند؛ سرویس API فقط روی loopback بالا می‌آید.
* `sudo ufw allow 8080/tcp` و در صورت وجود فایروال ابری (AWS/GCP/Hetzner) هم پورت را باز کنید.

### ۱۲.۳ ویندوز

```bat
deployment\windows\start_public.bat
```

IP قابل دسترسی چاپ می‌شود؛ قاعده‌ی فایروال در نصب ساخته شده است (در صورت شکست، دستی TCP 8000 را باز کنید).

### ۱۲.۴ چه چیزی به کاربر نشان داده می‌شود

بنر زرد بالای همه‌ی صفحات و فیلد `security_warning` در `GET /api/v1/meta/config` قرار می‌گیرد؛
هیچ صفحه‌ای این هشدار را پنهان نمی‌کند. متن هشدار: ترافیک رمزنگاری نشده است و رمز/کوکی نشست
قابل شنود است — فقط داده‌ی آزمایشی استفاده کنید.

### ۱۲.۵ چک‌لیست پیش از اشتراک‌گذاری لینک

```
[ ] NEXA_DEPLOYMENT_MODE=public_ip و NEXA_PUBLIC_BASE_URL درست است
[ ] رمز مدیر پیش‌فرض عوض شده
[ ] NEXA_REGISTRATION_MODE روی invite_only یا closed است
[ ] اعتبار آزمایشی فقط برای حساب‌های آزمایشی تعیین شده
[ ] کاربران ترجیحاً is_test_account ساخته شده‌اند
[ ] فایروال: فقط پورت ورودی باز است (نه 5432/6379/8000)
[ ] آزمایش از بیرون: `sudo bash deployment/linux/check_public_access.sh --port 8080` باید پایانش `exit 0` و پیام «reachable from outside» بدهد
[ ] پس از پایان تست، سرویس را متوقف یا به حالت HTTPS منتقل کنید
```

---

## ۱۳. HTTPS با دامنه (الان کاملاً خودکار)

```bash
sudo bash deployment/linux/install.sh --access domain --domain ai.example.com --acme-email you@example.com
```

نصب‌کننده: رکورد A را بررسی می‌کند، certbot را (در صورت نبود) نصب می‌کند، گواهی Let's Encrypt می‌گیرد، سایت
`nexa-domain-https.conf` را می‌نشاند، `NEXA_DEPLOYMENT_MODE=domain_https` + `NEXA_COOKIE_SECURE=true` +
`NEXA_HSTS_ENABLED=true` را در `.env` می‌نویسد، TLS را با نام دامنه از طریق `curl --resolve` می‌سنجد و
یک کرون روزانه‌ی `certbot renew` می‌سازد. اگر DNS آماده نباشد، هیچ‌چیز ادعای HTTPS نمی‌کند: سایت روی HTTP
می‌ماند، هشدار امنیتی در رابط کاربری باقی می‌ماند و دستور دقیق certbot چاپ می‌شود؛ بعد از آماده‌شدن DNS همان
دستور نصب را دوباره بزنید تا خودش به HTTPS سوییچ کند.

گواهی self-signed هم تشخیص داده می‌شود و صادقانه گزارش می‌شود (بازدیدکننده هشدار مرورگر می‌بیند؛ تا گواهی
واقعی نصب نشود، «HTTPS آماده» اعلام نمی‌شود).

### روش دستی (اگر ترجیح می‌دهید خودتان انجام دهید)

۱. رکورد A دامنه را به IP سرور بدهید.
۲. نسخه‌ی HTTP را برای چالش ACME اجرا کنید.
۳. گواهی بگیرید:

```bash
sudo apt -y install certbot python3-certbot-nginx
sudo certbot --nginx -d app.example.com --agree-tos -m admin@example.com --redirect
```

۴. الگوی HTTPS را جای‌گزین کنید و `.env` را به‌روز کنید:

```bash
sudo cp deployment/nginx/nexa-https.conf.example /etc/nginx/sites-available/nexa-ai-https
sudo sed -i 's/YOUR.DOMAIN.TLD/app.example.com/g' /etc/nginx/sites-available/nexa-ai-https
sudo ln -sf /etc/nginx/sites-available/nexa-ai-https /etc/nginx/sites-enabled/nexa-ai-https
sudo nginx -t && sudo systemctl reload nginx
```

```ini
NEXA_DEPLOYMENT_MODE=domain_https
NEXA_PUBLIC_BASE_URL=https://app.example.com
NEXA_COOKIE_SECURE=true
NEXA_HSTS_ENABLED=true
NEXA_CORS_ORIGINS=https://app.example.com
```

۵. سرویس‌ها را ری‌استارت و بررسی کنید:

```bash
sudo systemctl restart nexa-api nexa-worker
curl -sI https://app.example.com/healthz
python -m app.cli doctor                    # دیگر هشدار HTTP نباید بدهد
```

با تنظیم `NEXA_COOKIE_SECURE=true` بدون HTTPS، ورود کار نمی‌کند؛ پس ترتیب بالا را رعایت کنید.

---

## ۱۴. تست: چطور مطمئن شویم همه‌چیز کار می‌کند

### ۱۴.۱ تست‌های خودکار بک‌اند (اجرا در این مخزن: **۱۳۷ تست موفق**)

```bash
cd backend
python -m pytest tests/ -q                       # همه
python -m pytest tests/test_billing.py -q         # مالی
python -m pytest tests/ -q -m "not db"            # فقط تست‌های بدون دیتابیس
```

پوشش: احراز هویت، مجوزدهی و RBAC، ارائه‌دهنده‌ها و آداپتورها، صورتحساب و دفتر کل، فایل‌ها، چت و جریان،
کارها، فروشگاه مدل‌های عمومی، واحدهای پول، و پایداری ماژول‌ها (تصویر/صدا/کد/ترجمه/داده).

### ۱۴.۲ ساخت فرانت‌اند

```bash
cd frontend
npm install
npm run build      # باید بدون خطا با موفقیت تمام شود و dist/ ساخته شود
npm run preview    # اجرای پیش‌نمایش بسته‌ی ساخته‌شده
```

### ۱۴.۳ بررسی سلامت سرور در حال اجرا

```bash
scripts/health_check.sh http://127.0.0.1:8080
# یا در Docker:
docker compose exec api python -m app.cli doctor
```

خروجی `doctor` شامل: محیط، حالت استقرار، وضعیت دیتابیس، مشکلات بهره‌برداری، تنظیم کلید رمزنگاری،
تعداد کاربران/ارائه‌دهنده‌ها/مدل‌ها و **تطابق دفتر کل با موجودی حساب‌ها**.

### ۱۴.۴ تست سرتاسری زنده (بدون نیاز به کلید واقعی)

این تست به یک API در حال اجرا وصل می‌شود و کل مسیر تجاری را می‌سنجد. برای تأمین «ارائه‌دهنده» از یک
شبیه‌ساز سازگار با OpenAI استفاده می‌کند که در `tests/tools/mock_openai_upstream.py` قرار دارد؛
این شبیه‌ساز یک HTTP API واقعی است (نه mock درون‌برنامه‌ای) و درخواست‌هایش شمرده می‌شود.

```bash
# ترمینال ۱ — شبیه‌ساز ارائه‌دهنده
python3 tests/tools/mock_openai_upstream.py --port 9099 --api-key sk-mock-key

# ترمینال ۲ — سرور محلی با اجازه‌ی اتصال به سرور داخلی
export NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=true      # فقط برای تست محلی!
export NEXA_BOOTSTRAP_ADMIN_PASSWORD='رمز-مدیر'
cd backend && python3 -m uvicorn app.main:app --port 8000 --host 0.0.0.0

# ترمینال ۳ — اجرای تست
python3 tests/integration/test_live_stack.py \
  --base-url http://127.0.0.1:8000 \
  --upstream http://127.0.0.1:9099 \
  --admin-email admin@example.com \
  --admin-password 'رمز-مدیر'
```

نتایجی که این تست اثبات می‌کند (آخرین اجرا: **۳۷ از ۳۷ موفق**):

1. سلامت/آمادگی و وجود هشدار استقرار در `meta/config`
2. ساخت ارائه‌دهنده، پوشیده‌بودن کلید در پاسخ، تست اتصال موفق
3. همگام‌سازی مدل‌ها و ماندن آن‌ها روی «مخفی/منتشرنشده»
4. قیمت‌گذاری و انتشار آگاهانه‌ی مدل
5. تست مدیر روی مدل مخفی/داخلی، بدون انتشار، با هزینه‌ی پلتفرم و ثبت در تاریخچه
6. ثبت‌نام کاربر و دریافت `403` روی مسیرهای مدیریتی
7. پرداخت دستی: عدم افزودن اعتبار پیش از تأیید، افزودن دقیق پس از تأیید، رد تأیید دوباره
8. چت غیرجریانی و جریانی (SSE) با ثبت مصرف و **کسر دقیق اعتبار**
9. تولید تصویر با ذخیره‌ی فایل و دانلود موفق
10. شمارش درخواست‌های واقعی در سمت ارائه‌دهنده (اثبات تماس شبکه‌ای واقعی)

### ۱۴.۵ تست دستی کاربری (۱۰ دقیقه)

```
[ ] ثبت‌نام کاربر جدید → ورود → تغییر زبان به فارسی/عربی/کردی → تغییر پوسته
[ ] بدون اعتبار: درخواست چت → خطای 402 کمبود اعتبار با پیام روشن
[ ] ثبت پرداخت دستی → مدیریت: تأیید → اعتبار در دفتر کل ظاهر شود
[ ] چت، کدنویسی، تصویر، سند، تحلیل داده، صدا، ترجمه را یکی‌یکی اجرا کنید
[ ] دانلود فایل خروجی و بررسی «تاریخچه‌ی مصرف» و «کارها»
[ ] با کاربر عادی به /app/admin بروید → صفحه‌ی ۴۰۳
[ ] اجرای پشتیبان، سپس بازیابی در یک دیتابیس آزمایشی
```

---

## ۱۵. پشتیبان‌گیری و بازیابی

### ۱۵.۱ پشتیبان‌گیری

```bash
# لینوکس/مک (از ریشه‌ی پروژه)
scripts/backup.sh --keep 14                 # دیتابیس + آرشیو uploads + چرخش ۱۴ روزه
scripts/backup.sh --no-uploads --output-dir /mnt/backups
```

اسکریپت خودش تشخیص می‌دهد PostgreSQL است یا SQLite، سپس فایل را با `verify_backup.sh` بررسی می‌کند.

```bat
:: ویندوز
deployment\windows\backup.bat
```

در Docker:

```bash
docker compose exec db pg_dump -U nexa -Fc nexa > backups/nexa-$(date +%F).dump
docker compose cp api:/app/uploads ./backups/uploads-$(date +%F)  # پوشه‌ی فایل‌ها
```

پشتیبان‌گیری خودکار: `deployment/linux/nexa-backup.cron` را در crontab نصب کنید.

### ۱۵.۲ بررسی سالم‌بودن پشتیبان

```bash
scripts/verify_backup.sh backups/nexa-pg-20260101T023000Z.dump   # pg_restore --list
scripts/verify_backup.sh backups/nexa-sqlite-20260101T023000Z.db # PRAGMA integrity_check + شمارش جدول‌ها
```

### ۱۵.۳ بازیابی (آزمایش‌شده روی SQLite و PostgreSQL)

```bash
sudo systemctl stop nexa-api nexa-worker         # یا: docker compose stop api worker
scripts/restore.sh backups/nexa-sqlite-20260101T023000Z.db --yes
scripts/restore.sh backups/nexa-pg-....dump --yes --uploads backups/nexa-uploads-....tar.gz
sudo systemctl start nexa-api nexa-worker
scripts/health_check.sh http://127.0.0.1:8080
cd backend && python -m app.cli doctor           # تطابق دفتر کل باید گزارش شود
```

**تمرین بازیابی (ماهانه — با یک فرمان):** پشتیبان را در یک دیتابیس موقت بازیابی کنید، API را روی همان دیتا
بالا بیاورید، ورود مدیر را بررسی کنید و تطابق دفتر کل را بسنجید:

```bash
sudo bash scripts/restore_drill.sh            # جدیدترین پشتیبان؛ با --keep دیتابیس موقت پاک نمی‌شود
```

اگر هر مرحله رد شود (جدول‌ها برای نقش برنامه خوانده نشوند، API بالا نیاید، ورود مدیر کار نکند یا
`inconsistent` صفر نباشد) اسکریپت با پیام روشن شکست می‌خورد. جزئیات در `BACKUP_RESTORE.md` بخش ۵.
نکته: این اسکریپت هرگز رمز دیتابیس را چاپ نمی‌کند.

---

## ۱۶. نگهداری، به‌روزرسانی و کارهای دوره‌ای

| کار | دستور |
| --- | --- |
| وضعیت سرویس‌ها | `systemctl status nexa-api nexa-worker nginx postgresql` |
| لاگ زنده | `journalctl -u nexa-api -f` / `docker compose logs -f api` |
| کارهای دوره‌ای (انقضای فایل، اشتراک‌ها) | `cd backend && python -m app.cli maintenance` |
| اجرای کارگر یک‌باره | `python -m app.cli run-jobs --once` |
| اعتبار دستی به کاربر | `python -m app.cli grant-credits --email user@example.com --credits 10 --reason "هدیه"` |
| ساخت مدیر جدید | `python -m app.cli create-admin --email me@example.com --password '...' --name "مدیر"` |
| گزارش کامل وضعیت | `python -m app.cli doctor` |
| به‌روزرسانی کد | `git pull` → `bash deployment/linux/install.sh` (بدون تخریب `.env`) یا `docker compose up -d --build` |
| مهاجرت دیتابیس | `cd backend && python -m alembic upgrade head` (و `alembic current/history`) |
| بازگردانی نسخه‌ی دیتابیس | `python -m alembic downgrade -1` سپس `upgrade head` |
| چرخش کلید ارائه‌دهنده | پنل مدیر → ارائه‌دهنده → ویرایش → کلید جدید (یا `clear_api_key`) |
| چرخش کلیدهای امنیتی | `NEXA_ENCRYPTION_KEY` را عوض نکنید مگر کلیدهای ارائه‌دهنده را دوباره وارد کنید |

پس از تعویض `NEXA_ENCRYPTION_KEY`، کلیدهای ذخیره‌شده قابل رمزگشایی نیستند و باید از نو ثبت شوند.

---

## ۱۷. عیب‌یابی

| نشانه | علت احتمالی | راه‌حل |
| --- | --- | --- |
| صفحه سفید/۴۰۴ روی `/` | رابط کاربری ساخته نشده یا `NEXA_SERVE_FRONTEND=false` | `cd frontend && npm run build` و تنظیم `NEXA_FRONTEND_DIST_DIR` |
| `503 not_configured` هنگام چت | ارائه‌دهنده/مدل پیکربندی نشده یا مدل `untested` | ارائه‌دهنده را فعال و تست کنید، مدل را با تست مدیر تأیید و منتشر کنید |
| `model_not_verified` | تست تأیید مدل انجام نشده | مدیر → مدل → تست مدل (با عملیات موجود در قابلیت‌های مدل) |
| `402 insufficient_balance` | موجودی کافی نیست | ثبت پرداخت دستی و تأیید مدیر، یا ثبت اعتبار توسط مدیر |
| `403 model_not_accessible` | سطح دسترسی مدل (`internal`/`restricted`/`subscription`) | تغییر `access_tier`، افزودن مجوز، یا فعال‌سازی اشتراک |
| `429 daily_request_limit` / سقف مصرف | سقف روزانه/ماهانه‌ی کاربر یا اشتراک | افزایش سقف در داشبورد، ویرایش کاربر، یا انتظار تا روز بعد |
| `413 payload_too_large` | حجم فایل بیش از حد | `NEXA_MAX_UPLOAD_MB` و `client_max_body_size` در Nginx را هم‌تراز کنید |
| `502 ProviderError` با `authentication` | کلید API نادرست/منقضی | کلید را در ارائه‌دهنده به‌روز کنید |
| `502` با `rate_limit` | محدودیت سمت ارائه‌دهنده | `requests_per_minute` و `max_concurrency` را کم کنید یا بعداً تلاش کنید |
| `502` با `timeout` | `read_timeout` کم است | مقدار `read_timeout` ارائه‌دهنده را افزایش دهید (برای تصویر/ویدئو ۱۲۰+ ثانیه) |
| `502` با `unsupported_operation` | آداپتور آن عملیات را ندارد | نوع ارائه‌دهنده/مدل مناسب را انتخاب کنید (مثلاً برای تصویر `stability` یا مدل تصویری) |
| خطای CORS/CSRF هنگام ورود | دامنه/Origin با `NEXA_CORS_ORIGINS` نمی‌خواند | آدرس دقیق مرورگر را به `NEXA_CORS_ORIGINS` و `NEXA_PUBLIC_BASE_URL` اضافه کنید |
| ورود بعد از فعال‌سازی HTTPS کار نمی‌کند | `NEXA_COOKIE_SECURE=true` بدون HTTPS | کوکی را موقتاً `false` کنید یا HTTPS را کامل کنید |
| «Redis configured but unavailable» | Redis نصب/در دسترس نیست | برای تست نادیده بگیرید؛ در بهره‌برداری Redis را نصب یا `NEXA_REDIS_URL` را خالی کنید |
| برنامه با SQLite در `production` بالا نمی‌آید | سیاست ضد‌SQLite | PostgreSQL بگذارید یا (ناخواسته) `NEXA_ALLOW_SQLITE_IN_PRODUCTION=true` |
| «NEXA_ENCRYPTION_KEY is not set» | کلید رمزنگاری خالی/الگو | کلید Fernet تولید و در `.env` ثبت کنید |
| `api_key_hint` تغییر نمی‌کند | جایگزینی کلید ذخیره نشده | کلید جدید را بفرستید یا `clear_api_key=true` برای پاک کردن |
| «تست اتصال سبز است ولی مدل فراخوانی نمی‌شود» (خطای `provider_connectivity`) | تماس واقعی با ارائه‌دهنده در لایهٔ شبکه شکست می‌خورد (فایروال/DNS/TLS/قطع لحظه‌ای) — پیام `models` سبز بوده | یک دستور تشخیص لایه‌به‌لایه: `cd /opt/nexa-ai/backend && sudo -u nexa /opt/nexa-ai/venv/bin/python -m app.cli provider-check --provider <slug>` — خروجی می‌گوید کدام لایه (DNS، TCP، TLS، لیست مدل‌ها، چت، استریم) و با چه خطایی شکست خورده. قطعی‌های لحظه‌ای روی چت استریم خودکار تکرار می‌شوند |
| خطای `provider_connectivity` با متن کوتاه | جزئیات در پیام/راهنماها می‌آید: آدرس Endpoint، نوع خطا و علت محتمل | همان گزارش `provider-check` را بفرستید؛ راهنماها داخل خودِ پیام خطا هم نمایش داده می‌شوند |
| مدل در فروشگاه کاربر نیست ولی تست مدیر کار می‌کند | همان رفتار طراحی‌شده | `visibility=public` + `published=true` + `available` + `access_tier` مناسب |
| کارها پیشرفت نمی‌کنند | سرویس worker خاموش یا `NEXA_INLINE_WORKER=false` بدون worker | `systemctl start nexa-worker` یا `docker compose up -d worker` |
| فایل بارگذاری نمی‌شود | امضای فایل یا پسوند مجاز نیست | پسوندها در `NEXA_ALLOWED_UPLOAD_EXTENSIONS`؛ فایل واقعی همان نوع را بفرستید |
| خطای مایگریشن | نسخه‌ی دیتابیس عقب‌تر است | `cd backend && python -m alembic upgrade head` |
| خطای `sqlite3` روی دیسک لینوکس در حالت SQLite | نبود دسترسی نوشتن | مالکیت پوشه‌ی `data/` را به کاربر سرویس بدهید |

---

## ۱۸. چک‌لیست امنیتی

```
[ ] NEXA_SECRET_KEY و NEXA_ENCRYPTION_KEY تصادفی و یکتا هستند
[ ] رمز مدیر پیش‌فرض عوض شده و MFA سازمانی/رمز قوی استفاده می‌شود
[ ] .env با مجوز 600 و خارج از گیت است
[ ] PostgreSQL و Redis هیچ‌گاه پورت عمومی ندارند
[ ] NEXA_REGISTRATION_MODE روی invite_only یا closed در محیط عمومی
[ ] NEXA_TRUSTED_HOSTS در صورت داشتن دامنه محدود شده
[ ] NEXA_COOKIE_SECURE=true و NEXA_HSTS_ENABLED=true فقط پشت HTTPS
[ ] محدودیت نرخ ورود (NEXA_AUTH_RATE_LIMIT_PER_MINUTE) متناسب است
[ ] سیاست SSRF: NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=false و در صورت نیاز فهرست سفید دامنه
[ ] سقف مصرف روزانه/ماهانه‌ی کاربران و سقف تست مدیر فعال است
[ ] نوتیفیکیشن و بررسی دوره‌ای audit/security events
[ ] پشتیبان‌گیری زمان‌بندی‌شده + تمرین بازیابی ماهانه
[ ] به‌روزرسانی دوره‌ای سیستم و وابستگی‌ها
```

---

## ۱۹. پیوست‌ها: دستورها، نقش‌ها، متغیرها

### ۱۹.۱ درخت پروژه (مسیرهای مهم)

```
nexa-ai/
├─ backend/            API، مدل‌ها، سرویس‌ها، آداپتورها، تست‌ها، alembic
├─ frontend/           React + TS + Vite (src/pages، src/components، src/locales)
├─ database/           postgres_init.sql، schema.md، create_tables.sql
├─ deployment/
│  ├─ docker/          Dockerfile.backend / worker / frontend
│  ├─ nginx/           nexa.conf (داکر) / nexa-host.conf (بومی) / nexa-https.conf.example
│  ├─ linux/           install.sh، nexa-api.service، nexa-worker.service، nexa-backup.cron
│  ├─ windows/         install.bat، start*.bat، backup.bat، diagnose.bat، install_service.bat
│  └─ .env.production.example
├─ scripts/            backup.sh، restore.sh، verify_backup.sh، health_check.sh،
│                      run_worker.sh، create_admin.py، seed_demo.py
├─ tests/              tools/mock_openai_upstream.py، integration/test_live_stack.py
├─ docs/               همه‌ی مستندات (این فایل یکی از آن‌هاست)
├─ docker-compose.yml  و docker-compose.dev.yml
├─ uploads/            private/، generated/، tmp/
└─ .env.example
```

### ۱۹.۲ دستورهای پرکاربرد

```bash
# راه‌اندازی
docker compose up -d --build
sudo bash deployment/linux/install.sh
deployment\windows\install.bat

# دیتابیس
cd backend && python -m alembic upgrade head
cd backend && python -m alembic current && python -m alembic history --verbose

# عملیات
python -m app.cli bootstrap
python -m app.cli doctor
python -m app.cli create-admin --email a@b.com --password '...' --name "مدیر"
python -m app.cli grant-credits --email u@b.com --credits 10 --reason "تست"
python -m app.cli maintenance
python -m app.cli run-jobs --once

# تست
cd backend && python -m pytest tests/ -q
cd frontend && npm run build
python3 tests/tools/mock_openai_upstream.py --port 9099 &
python3 tests/integration/test_live_stack.py --base-url http://127.0.0.1:8000

# پشتیبان
scripts/backup.sh --keep 14
scripts/verify_backup.sh backups/<file>
scripts/restore.sh backups/<file> --yes
scripts/health_check.sh http://127.0.0.1:8080
```

### ۱۹.۳ مرجع API

* مستندات تعاملی: `http://IP:PORT/api/docs` (Swagger) و `/api/redoc`
* فهرست JSON: `http://IP:PORT/api/openapi.json`
* سلامت: `/healthz`، `/readyz`، `/api/v1/health`، `/api/v1/health/deep`، `/api/v1/health/worker`

### ۱۹.۴ نقش‌ها و مجوزها (خلاصه)

| گروه | مجوزها |
| --- | --- |
| کاربران | `users.read`، `users.create`، `users.update`، `users.suspend`، `users.impersonate` |
| نقش‌ها | `roles.manage` |
| ارائه‌دهنده‌ها | `providers.read`، `providers.manage`، `providers.credentials`، `providers.test`، `providers.sync` |
| مدل‌ها | `models.read`، `models.manage`، `models.test`، `models.publish`، `models.grants.manage` |
| مالی | `pricing.manage`، `subscriptions.manage`، `payments.read`، `payments.manage`، `payments.approve`، `refunds.manage`، `credits.manage`، `usage.read`، `reports.read` |
| سیستم | `settings.manage`، `audit.read`، `backups.manage`، `jobs.manage`، `security.read` |

### ۱۹.۵ حالت‌های خطای API

| کد | معنا |
| --- | --- |
| `402 insufficient_balance` | موجودی کاربر کافی نیست |
| `403 model_not_accessible` | مدل برای این کاربر مجاز نیست (`model_not_allowed`/`subscription_required`/`grant_required`) |
| `404` | منبع یافت نشد |
| `413 payload_too_large` | حجم درخواست/فایل بیش از حد |
| `422 validation_error` | داده‌ی نامعتبر (جزئیات در `details.fields`) |
| `429 rate_limited` | محدودیت نرخ یا سقف مصرف |
| `502 provider_error` | خطای ارائه‌دهنده با دسته‌بندی (`authentication`, `rate_limit`, `timeout`, `unsupported_operation`, `malformed_response`, …) |
| `503 not_configured` | پیکربندی ناقص (`unconfigured`, `model_not_verified`, درگاه پرداخت بدون کلید) |

---

### پیوست پایانی: نکات طلایی

1. **هیچ‌چیز الکی موفق نمی‌شود:** اگر ارائه‌دهنده نباشد، خطای صریح می‌گیرید؛ این یعنی سیستم سالم است، نه خراب.
2. **مدل تازه همگام‌شده، مخفی است:** مسیر درست «تست → قیمت → انتشار» است.
3. **پرداخت دستی بدون تأیید مدیر اعتبار نمی‌شود** و بازگشت موفق از درگاه تنها مدرک نیست.
4. **اعتبار فقط از دفتر کل** قابل تغییر است؛ هیچ‌جا موجودی مستقیم ویرایش نمی‌شود.
5. **اول پشتیبان، بعد تغییر.** `scripts/backup.sh` سریع و کم‌هزینه است.
6. **برای تست سریع بدون کلید واقعی** از `tests/tools/mock_openai_upstream.py` استفاده کنید.

---

## پیوست تازه (۱۴ اکتبر ۲۰۲۶): دو مشکلی که کاربران واقعی گزارش کردند

### الف) سرور اوبونتو فقط پایتون ۳.۱۴ دارد

نصب‌کننده حالا **خودش** یک پایتون پشتیبانی‌شده (۳.۱۱ تا ۳.۱۳) می‌سازد؛ نیازی به کار دستی نیست:

1. بستهٔ نسخه‌دار توزیع (`python3.13` / `python3.12` / `python3.11`)
2. مخزن deadsnakes روی اوبونتو
3. **uv** — یک فایل اجرایی تک‌تکه که یک CPython مستقل را در `/opt/nexa-python` می‌گذارد
   (نه کامپایلری لازم است، نه Rust، نه مخزن اضافه)

اگر می‌خواهید دستی همان مسیر آخر را بروید:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sudo sh
sudo env UV_PYTHON_INSTALL_DIR=/opt/nexa-python /root/.local/bin/uv python install 3.13
sudo bash deployment/linux/install.sh
```

نصب‌کننده خودش آن را پیدا می‌کند؛ اگر بخواهید صریح بدهید:

```bash
sudo bash deployment/linux/install.sh --python /opt/nexa-python/cpython-3.13-linux-x86_64-gnu/bin/python3.13
```

### ب) «سرویس‌دهنده وصل می‌شود ولی مدل‌ها نمی‌آیند»

سه چیز را پشت‌سرهم بررسی کنید:

1. **تست اتصال** را بزنید. اگر پیام «… model(s) visible at the provider» بود، یعنی کلید سالم است و
   باید دکمهٔ **همگام‌سازی مدل‌ها** (Sync) را بزنید. اگر شکل پاسخ سرویس‌دهنده غیرمعمول باشد،
   همین پیام دقیقاً می‌گوید چه چیزی برگشته (کلیدهای سطح‌بالا) و مشکل «پروتکل» است نه «کلید»
   (رایج‌ترین علت: آدرس باید به `/v1` ختم شود).
2. بعد از Sync، مدل‌ها **عمداً پنهان و منتشرنشده** ساخته می‌شوند (اصل ایمنی: پلتفرم هیچ قابلیتی را
   حدس نمی‌زند). کارت نتیجهٔ Sync حالا شمارش می‌دهد و یک دکمه دارد: **«Open the unpublished models»**
   که شما را به فهرست همان مدل‌های تازه می‌برد.
3. برای هر مدل: **آزمون** بزنید (تأیید واقعی)، قابلیت‌ها را اعلام کنید، قیمت بگذارید و بعد **انتشار**.
   تا وقتی منتشر نشود، در فهرست کاربران دیده نمی‌شود — این طراحی است، نه خرابی.

نکتهٔ تلگرام: از نسخهٔ ۱.۰.۰ کارت مدیریتی تلگرام در «مدیریت ← تنظیمات» است و دکمهٔ تستش واقعاً
`getMe` می‌زند.

## پیوست دوم (۱۴ اکتبر ۲۰۲۶): یک ساعت داخل سندباکس خودتان — چه دیدیم و چه درست شد

این نوبت به‌جای حدس‌زدن، با کلید SSH شما وارد سندباکس Daytona شدیم، همان پروژه را نصب و اجرا
کردیم و با مرورگر واقعی (Chromium) از آن استفاده کردیم. هفت اشکال واقعی پیدا و رفع شد؛ همه
داخل همان سندباکس دوباره تست شدند.

### ۱) خطای «فراخوانی مدل‌های سرویس‌دهنده» — علت واقعی پیدا شد

لاگ سرور نشان داد درخواست به `https://inference.dahl.global/v1/models` با `ConnectError` و پاسخ
۵۰۲ برمی‌گردد. تست شبکه داخل سندباکس ثابت کرد دامنه resolve می‌شود ولی دست‌دادن TLS با
`Recv failure: Connection reset by peer` قطع می‌شود، در حالی که pypi، npm، github،
api.anthropic.com و **api.telegram.org** سالم بودند. یعنی **فهرست مجاز خروجی سندباکس Daytona**
آن دامنه را بسته است — مشکل کلید، آدرس یا `/v1` نبود.

* ابزار `provider-check` حالا یک گام **control** دارد: وقتی اتصال سرویس‌دهنده شکست بخورد، یک
  آدرس سالم (`https://pypi.org/simple/`) را هم تست می‌کند و صریح می‌گوید «این مسدودسازی مخصوص
  همان دامنه است، نه قطعی شبکه» (کد خروج ۵). همین را داخل سندباکس شما دیدیم.
* راه‌حل دقیق (مجاز کردن دامنه در تنظیمات شبکهٔ سندباکس) در `docs/RAHNAMA-DAYTONA.md` بند ۷.۱ با
  دستور `curl` کامل آمده است. اگر Tier حساب اجازه نداد، همان بند راه جایگزین (سرویس‌دهندهٔ در
  دسترس) را می‌دهد.
* در همان سندباکس، مسیر تجاری کامل را با یک upstream آزمایشی واقعی اجرا کردیم:
  **۳۹ از ۳۹ گام سبز** — افزودن سرویس‌دهنده، تست اتصال، همگام‌سازی ۶ مدل، قیمت‌گذاری، انتشار،
  تست مدل مخفی توسط مدیر، ثبت‌نام کاربر، مسدودسازی مسیرهای مدیریتی، پرداخت دستی + تأیید +
  دفتر کل، چت معمولی و استریم، و ساخت تصویر با فایل قابل دانلود (mock واقعاً ۲۰ درخواست HTTP
  دریافت کرد).

### ۲) اشکال‌هایی که فقط با اجرای واقعی و مرورگر پیدا می‌شوند (همه رفع شدند)

| اشکال | نشانهٔ دیده‌شده | اصلاح |
| --- | --- | --- |
| نقض CSP و از‌دست‌رفتن تم/زبان پیش از رندر | در **هر بار** باز شدن صفحه: `Executing inline script violates … 'script-src 'self''` | اسکریپت کوچک تم از داخل `index.html` بیرون آمد و در فایل `frontend/public/theme-boot.js` قرار گرفت؛ سیاست امنیتی سخت‌گیرانه ماند (بدون hash و بدون `unsafe-inline`) |
| جدول‌های پنل مدیر روی موبایل ناخوانا بودند | در عرض ۳۹۰ پیکسل: `openai_compatible` و `https://inference.dahl.global/v1` وسط کلمه می‌شکستند و سرستون `CREDENTIALS` به `IALS` بریده می‌شد | جدول‌ها زیر ۷۶۰ پیکسل به **کارت‌های برچسب/مقدار** تبدیل می‌شوند (`data-label` + CSS). اندازه‌گیری پس از اصلاح: ۲۴/۲۴ و ۱۰۸/۱۰۸ سلول برچسب‌دار، عریض‌ترین عنصر ۳۳۳ پیکسل داخل صفحهٔ ۳۹۰، بدون سرریز افقی |
| صفحهٔ «پشتیبان‌گیری» همیشه خطا می‌داد | `GET /api/v1/admin/backup/run` روی هر بازدید ۴۰۴ | مسیر تازهٔ خواندنی `GET /api/v1/admin/backups` + سرویس فهرست پشتیبان‌ها؛ `backup.sh` بعد از تأیید، فایل `.sha256` و `.meta.json` می‌نویسد و «تأییدشده» فقط وقتی نمایش داده می‌شود که آن مدرک موجود و منطبق باشد |
| فایل پشتیبان واقعی روی همین ماشین ساخته و تأیید شد | — | `pg_dump` واقعی → `pg_restore` توانست آرشیو را بخواند (۳۹۶ شیء) → رکورد تأیید نوشته شد → پنل همان ردیف را «تأییدشده» نشان داد |
| «ورود کار نمی‌کند» روی آدرس http | کوکی‌ها Secure هستند و مرورگر روی `http://` آن‌ها را دور می‌ریزد | اسکریپت نصب Daytona حالا در خلاصهٔ پایانی همین را توضیح می‌دهد و راه‌حل (`--http` یا لینک HTTPS) را می‌گوید |
| سرستون‌های انگلیسی در پنل فارسی | `Name`, `Adapter`, `Base URL`, `Credentials`, `Models`, `Last test` … | ۱۷ کلید تازه به **هر چهار زبان** (fa, ar, ckb, en) اضافه شد؛ کارت‌های موبایل حالا «نام / آداپتور / نشانی پایه / کلید دسترسی / وضعیت / مدل‌ها / آخرین آزمون / عملیات» را نشان می‌دهند |
| `service nexa-api restart` روی میزبان بدون systemd بی‌صدا هیچ‌کار نمی‌کند | در همین سندباکس تجربه شد | در راهنمای Daytona (بند ۷.۱) دستور درست `deployment/linux/nexa-services.sh restart` به‌عنوان پاسخ اصلی آمده است |

### ۳) عددهای تست این نوبت (همه اجراشده)

* `backend`: **۲۵۰ تست سبز** (۹ تست تازه برای فهرست پشتیبان‌ها).
* مخزن: **۲۲۴ تست سبز / ۱۲ رد‌شده** (۱۲ مورد فقط باینری ویندوز و ابزار `uv` که در این محیط
  نیستند) — از جمله ۱۱ تست تازه برای CSP و جدول‌های واکنش‌گرا.
* `tsc -b` + `npm run build` بدون خطا؛ بستهٔ نهایی ساخته شد.
* روی سندباکس خودتان: **۳۹/۳۹** مسیر تجاری، **صفر** خطای کنسول/شبکه در مرورگر، **صفر** سرریز
  افقی در ۴۳۰/۳۹۰/۳۶۰ پیکسل.

اگر همین حالا خطای سرویس‌دهنده را می‌بینید: اول بند ۷.۱ راهنمای Daytona را ببینید؛ با یک دستور
`provider-check` معلوم می‌شود که مسدودسازی سمت Daytona است یا خود سرویس‌دهنده.

## پیوست سوم (۱۴ اکتبر ۲۰۲۶، پایان روز): لینک عمومی روی Daytona + نصب تازه از همان زیپ روی یک ماشین تمیز

### الف) لینک کارکننده روی سندباکس شما (تست‌شده از بیرون)

```
https://8080-b15fbf0d-e8f1-49a2-b775-367025358f4d.proxy.daytona.work
```

این آدرس را از **بیرون** سندباکس (از یک ماشین دیگر) با مرورگر واقعی تست کردم:

* `/readyz` → `200 {"status":"ready","database":"ok"}`
* صفحهٔ ورود و همهٔ دارایی‌های ساخته‌شده (`index-CGenLjzG.js` و `theme-boot.js`) → ۲۰۰
* ورود با `coder13@gmail.com` → موفق؛ کوکی `nexa_session` با پرچم‌های **Secure + HttpOnly + SameSite=Lax**؛
  صفحهٔ «خوش آمدید، Coder13»
* پنل مدیر از طریق همین لینک: سرویس‌دهنده‌ها ۳ ردیف، مدل‌ها ۱۲ ردیف، کاربران ۳ ردیف، پشتیبان‌گیری ۱ ردیف — همه ۲۰۰
* در دسکتاپ و موبایل: **بدون هیچ خطای کنسول/شبکه**، بدون سرریز افقی، جدول‌ها روی موبایل کارتی

نکته: `NEXA_PUBLIC_BASE_URL` را هم روی همین لینک تنظیم کردم تا هر آدرسی که برنامه تولید می‌کند درست باشد.
رمز مدیر در `/opt/nexa-ai/.env` است؛ دستور خواندن:

```bash
sudo grep NEXA_BOOTSTRAP_ADMIN_PASSWORD /opt/nexa-ai/.env
```

تنها موردی که هنوز روی سندباکس باز است، همان محدودیت شبکهٔ Daytona برای دامنهٔ
`inference.dahl.global` است (بند ۷.۱ همین راهنما برای Daytona) — یک دستور `curl` روی سیستم خودتان
یا یک کلیک در داشبورد. تا آن زمان این سرویس‌دهنده از داخل سندباکس در دسترس نیست.

### ب) نصب تازه از همین زیپ روی یک ماشین تمیز (جانشین سرور اوبونتو)

زیپ تحویلی را روی یک میزبان Debian 13 تمیز باز کردم و سه بار مسیر نصب واقعی را اجرا کردم:

| مرحله | دستور | نتیجه |
| --- | --- | --- |
| نصب «فقط همین ماشین» | `install.sh --access local --public-port 8090 …` | خروج ۰؛ PostgreSQL ساخته شد، مهاجرت‌ها و bootstrap اجرا شد، **ورود مدیر تأیید شد** |
| مسیر تجاری کامل روی همان نصب | `tests/integration/test_live_stack.py` | **۳۹ از ۳۹ سبز** |
| اجرای دوباره در حالت **آی‌پی عمومی** | `install.sh --access public --public-port 8090` | خروج ۰؛ Nginx تنظیم شد، راهنمای صادقانهٔ NAT/فایروال/گروه امنیتی چاپ شد، SPA سرو شد، **سلامت و ورود مدیر تأیید شد** |
| تستِ اپلیکیشن سروشده از پشت Nginx | `NEXA_TEST_BASE_URL=http://127.0.0.1:8090 pytest tests/e2e -q` | **۱۰ از ۱۰ سبز** |
| مرورگر واقعی روی همان نصب | Chromium روی `:8090` | ورود موفق، **صفر** خطا، داشبورد/سرویس‌دهنده‌ها/مدل‌ها/کاربران با داده‌های واقعی، جدول‌ها روی موبایل کارتی |

### ج) دو اشکالی که همین نصب تازه لو داد (رفع شد)

1. **نبودن باندل فرانت‌اند ⇒ خطای ۵۰۰ خالی روی همهٔ صفحه‌ها.** اگر `frontend/dist` ساخته نشده
   باشد (مثلاً اجرای دوبارهٔ نصب‌کننده با `--no-node`، یا پاک‌شدن پوشهٔ build)، Nginx در
   `try_files … /index.html` داخل خودش حلقه می‌خورد و به‌جای توضیح، ۵۰۰ می‌داد.
   الان: پیام **۵۰۳ روشن** («باندل `index.html` نیست؛ این دستورها را بزنید…») و نصب‌کننده هم
   **قبل از پایان کار متوقف می‌شود** و می‌گوید داده‌ها (دیتابیس، `.env`، آپلودها) دست‌نخورده است.
2. **هشدار بی‌ربط systemd در خلاصهٔ نصب.** روی میزبان بدون systemd، دستور `systemctl stop` پیام
   «systemd is not running in this container» را روی stdout چاپ می‌کرد و وسط خروجی موفق می‌افتاد؛
   حالا کامل خاموش شده است.

### د) برای سرور اوبونتو خودتان

زیپ همین حالا برای هر دو کار می‌کند. روی سرور اوبونتو کافی است:

```bash
sudo bash deployment/linux/install.sh --access public --public-port 8080
# یا با دامنه و HTTPS:
sudo bash deployment/linux/install.sh --access domain --domain ai.example.com --acme-email you@example.com
```

اسکریپت خودش پایتون سازگار (۳.۱۱–۳.۱۳) را می‌آورد — حتی اگر سیستم فقط پایتون ۳.۱۴ داشته باشد —
PostgreSQL و Redis را بالا می‌آورد، فرانت‌اند را می‌سازد، Nginx را تنظیم می‌کند و در پایان خودش
ورود مدیر را آزمایش می‌کند. اگر رمز مدیر را نگه نداشتید، از `.env` بخوانید یا با
`--reset-admin-password` بازنشانی کنید.
