# Running Nexa AI in a cloud development workspace

**فارسی در پایین همین صفحه — [English below](#english)**

این راهنما برای اجرای پروژه در **GitHub Codespaces** (و هر محیط مشابه ابری: Gitpod، dev container،
یک ماشین مجازی) نوشته شده است. هدف: از لحظهٔ باز کردن Workspace تا لحظه‌ای که یک نفر دیگر با لینک
می‌تواند **حساب بسازد و وارد شود**، بدون سردرگمی.

---

## ۱. سه دستور

```bash
# ۱) نصب و آماده‌سازی (یک‌بار برای هر Workspace؛ اجرای دوباره بی‌خطر است)
bash deployment/codespaces/setup.sh

# ۲) اجرا (پیش‌فرض: یک پورت ۸۰۸۰ که خودِ API رابط کاربری ساخته‌شده را سرو می‌کند)
bash deployment/codespaces/start.sh --daemon

# ۳) نگه‌داشتن و توقف
bash deployment/codespaces/start.sh --stop
```

`setup.sh` این کارها را انجام می‌دهد:

* یک پایتون پشتیبانی‌شده (۳٫۱۱ تا ۳٫۱۳) پیدا می‌کند؛ اگر نبود، با `uv` خودش نسخهٔ ۳٫۱۲ را
  نصب می‌کند (پایتون ۳٫۱۴ هنوز پشتیبانی نمی‌شود).
* محیط مجازی `.venv`، وابستگی‌های بک‌اند و فرانت‌اند (npm) را نصب می‌کند.
* فایل `backend/.env` را با مقادیر توسعه می‌سازد: SQLite، کلیدهای رمزنگاری تصادفی،
  `NEXA_ALLOW_DEV_HOSTS=true` و ثبت‌نام **باز**؛ رمز مدیر را یک‌بار چاپ می‌کند.
* مهاجرت‌های دیتابیس و ساخت نقش‌ها/مجوزها/کاتالوگ + نخستین مدیر را اجرا می‌کند.
* فرانت‌اند را build می‌کند تا همان یک پورت برای همه کافی باشد.

## ۲. لینکی که به دیگران می‌دهید

پورت‌ها در Codespaces پیش‌فرض **خصوصی** هستند: هر کسی که وارد حساب شما نیست، همان لینک را هم باز
کند صفحه‌ای نمی‌بیند. برای اینکه دوستتان بتواند ثبت‌نام کند، پورت را **عمومی** کنید:

```bash
gh codespace ports visibility 8080:public -c "$CODESPACE_NAME"
```

یا: پنل **Ports** در VS Code → روی پورت ۸۰۸۰ راست‌کلیک → **Port Visibility → Public**.
لینک نهایی چیزی شبیه این است:

```
https://<codespace-name>-8080.app.github.dev
```

همین لینک را بفرستید؛ ثبت‌نام باز است و هر کسی می‌تواند حساب بسازد و وارد شود.
اگر می‌خواهید فقط افراد دعوت‌شده وارد شوند: **Admin → Settings → registration.mode = invite_only**
و بعد از **Admin → Users → دعوت یک نفر** لینک دعوت بگیرید.

## ۳. عیب‌یابی سریع

| نشانه | علت | راه‌حل |
| --- | --- | --- |
| `400 host_not_allowed` | دامنهٔ Workspace در فهرست مجاز نیست (آدرس با هر rebuild تغییر می‌کند) | در `backend/.env` مقدار `NEXA_ALLOW_DEV_HOSTS=true` و سرویس را دوباره اجرا کنید؛ یا همان دامنه را به `NEXA_TRUSTED_HOSTS` اضافه کنید |
| دوستتان «صفحه پیدا نشد» می‌بیند | پورت خصوصی است | `gh codespace ports visibility 8080:public -c "$CODESPACE_NAME"` |
| «این پلتفرم فقط با دعوت‌نامه است» | `registration.mode = invite_only` | در Admin → Settings حالت را `open` کنید یا لینک دعوت بفرستید |
| «رمز عبور کافی نیست» | حداقل طول رمز | رمز ۱۰ کاراکتری با حرف بزرگ/کوچک و رقم |
| پورت مشغول است | نسخهٔ قبلی هنوز در حال اجراست | `bash deployment/codespaces/start.sh --stop` |
| لاگ‌ها | `cat .run/api.log` | `--dev` حالت توسعه: Vite روی ۵۱۷۳ و API روی ۸۰۸۱ |

## ۴. حالت توسعه (Hot reload)

```bash
bash deployment/codespaces/start.sh --dev          # Vite روی ۵۱۷۳ (پروکسی /api → ۸۰۸۱)
```

در این حالت پورت ۵۱۷۳ را عمومی کنید. برای اجرای دوبارهٔ فقط بک‌اند:

```bash
cd backend && set -a && . .env && set +a && ../.venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8081
```

## ۵. تفاوت با نصب روی سرور واقعی

این محیط برای **تست و نمایش** است: SQLite، رمزهای تصادفی، هشدار HTTP ساده. برای سرور واقعی از
`deployment/linux/install.sh` (PostgreSQL، systemd/Nginx، HTTPS) یا `deployment/windows/install.bat`
استفاده کنید — نگاه کنید به `docs/INSTALLATION_GUIDE.md` و `docs/RAHNAMA.md`.

---

<a id="english"></a>
# English

Run the project in any cloud workspace (GitHub Codespaces, Gitpod, dev container, VM):

```bash
bash deployment/codespaces/setup.sh            # install everything, create the admin, build the SPA
bash deployment/codespaces/start.sh --daemon   # one port: API serves the built SPA on 8080
bash deployment/codespaces/start.sh --dev      # development: Vite 5173 + API 8081
bash deployment/codespaces/start.sh --stop     # stop it
```

**Sharing the link.** Forwarded ports are *private* by default, so a friend who is not signed in to
your account sees nothing. Make the port public, then send the link:

```bash
gh codespace ports visibility 8080:public -c "$CODESPACE_NAME"
# https://<codespace-name>-8080.app.github.dev
```

Registration is open in a workspace (`NEXA_REGISTRATION_MODE=open`), so anybody with that link can
create an account and sign in. Switch to `invite_only` in **Admin → Settings** when you want invite
links only.

**Troubleshooting.** `400 host_not_allowed` → set `NEXA_ALLOW_DEV_HOSTS=true` in `backend/.env` and
restart (a workspace URL changes on every rebuild, so no fixed list can stay complete). A friend
seeing "page not found" → the port is still private. "Invitation-only platform" → the registration
policy is `invite_only`. Port already in use → `start.sh --stop`. Logs live in `.run/`.

**Not a production deployment.** Workspaces use SQLite and generated secrets; for a real server use
`deployment/linux/install.sh` or `deployment/windows/install.bat` as described in
`docs/INSTALLATION_GUIDE.md` (English) and `docs/RAHNAMA.md` (فارسی).
