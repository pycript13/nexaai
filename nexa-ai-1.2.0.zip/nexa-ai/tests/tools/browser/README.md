# Browser checks (headless Chromium via `puppeteer-core`)

Optional, developer-facing checks that drive the **running** application in a real browser. They are
not part of the pytest suites (they need a browser binary and a live server); they exist because two
rounds of operator-reported bugs — a dialog with two close buttons and no save, and an admin screen
that crashed — were invisible to API tests and only reproducible in a browser.

```bash
# a live server (SQLite preview stack, or your own deployment)
npm install puppeteer-core                 # in this folder, or anywhere on NODE_PATH
BASE=http://127.0.0.1:8080 \
EMAIL=admin@example.com PASSWORD='…' \
CHROME=/usr/bin/chromium \
node check-admin-pages.cjs                # every admin + workspace route, phone + desktop
BASE=… EMAIL=… PASSWORD=… node check-model-dialog.cjs   # the model dialog, end to end
```

What `check-admin-pages.cjs` asserts: no console errors, no failed `/api/v1/*` calls, no horizontal
overflow at 390×844 and 1440×900, and that the role-permission editor really renders its checkboxes.

What `check-model-dialog.cjs` asserts: the model-edit dialog contains exactly **one** dismiss control
and exactly **one** save button, that typing a change and pressing Save persists it (re-read from the
server after a reload), and that the platform owner is never shown the “credits needed” message in the
catalogue. Screenshots and a `report.json` land in `SHOT_DIR` (default `/tmp/nexa-browser-shots`).

## The round-12 checks

The four scripts below are the ones the round-12 report quotes. They run against a live server and a
real browser, and each of them exits non-zero with the exact reason when something regressed.

| Script | What it proves |
| --- | --- |
| `check-register.cjs` | a stranger handed the link can create an account and sign in (phone + desktop, fa + en) |
| `check-round12.cjs` | the admin console: Telegram card, user creation with roles from the panel, the one-time password really signs in, 403s for ordinary accounts, the profile's Telegram gate |
| `check-alignment.cjs` | every control in the same container shares a height and a baseline at 390 / 768 / 1440 px (`--self-test` injects a 14 px offset and requires the checker to report it) |
| `check-round12b.cjs` | the command palette (Ctrl/⌘ K, permission-aware, four languages) and the registration-policy card (a real change, verified through `/api/v1/auth/config`) |
| `check-telegram-bot.cjs` | the bot with a real token: the webhook secret is enforced, a stranger is refused, a registered id is greeted with its real data, buttons and commands work |

```bash
npm install puppeteer-core
BASE=http://127.0.0.1:8080 EMAIL=admin@example.com PASSWORD='…' node check-round12b.cjs
node check-alignment.cjs http://127.0.0.1:8080 admin@example.com '…'      # or positional arguments
```

`CHROME=/usr/bin/chromium` (or the path to your Chrome/Chromium) and `SHOT_DIR` (default
`/tmp/nexa-*`) are honoured by all of them.

## The rest of the harnesses quoted in `docs/TEST_REPORT.md`

| Script | Round it belongs to |
| --- | --- |
| `check-chat-reasoning.cjs` | reasoning models: the chain of thought is separated from the answer (streaming included) |
| `check-sync-ux.cjs` | provider sync: counts, drafts, and the button that opens the imported models |
| `variant-stream-check.cjs` | sub-model variants: the variant's system prompt really reaches the provider |
| `user-flow-check.cjs` | the workspace journey of an ordinary account (chat, images, files, billing …) |
| `mobile-audit.cjs` | responsiveness measured at five phone/tablet widths (overflow, tap targets, text size) |
| `page-recheck.cjs` | re-checks a single page that a sweep reported (used to separate a real defect from a screenshot hiccup) |
| `verify-preview.cjs` | a quick end-to-end sanity pass over a running preview |

## The round-13 checks

| Script | What it proves |
| --- | --- |
| `check-nested-nav.cjs` | the 3D splash (first paint + compiled SplashLoader), the nested collapsible sidebar (aria-expanded, four admin subgroups, auto-expand on navigation, three-level breadcrumb, collapsed branches leave the tab order, localStorage persistence), the palette over the nested tree, and the 390px drawer with ≥44px toggles |
| `check-telegram-bot.cjs` | the bot's decision engine through the real webhook: the stranger gate, the recognised profile id, **the whole session lifecycle** (`/new → answer → /retry → /sessions → /switch → /rename → /stats → /export → /settings → /close`) and **every fixed bottom-bar label** routed like its command, plus the one-time-code link |
| `check-sync-ux.cjs` | provider sync end to end — now self-contained: creates its own provider against the mock upstream, syncs through the real UI (fa/en labels), follows the result card to the drafts, then deletes it with `force` |
| `variant-stream-check.cjs` | variant → provider pipeline, deterministically: pins a **mock** model (never spends real credits), creates a temporary code-only sub-model when missing, sends a marked prompt, and verifies the mock upstream received `[system, user]` — the variant's system prompt first — then cleans up |

Round-13 hardening of existing harnesses: `mobile-audit.cjs` separates screenshot stalls from real
findings (a SwiftShader capture timeout is an evidence gap, not a page defect); `user-flow-check.cjs`
reads the account's actual catalogue access from the API and demands the chat page tell the truth
about it (blocked explanation with a Billing link, or a working composer) instead of assuming the
seeded user stays blocked forever; `verify-preview.cjs` prefers a mock model and accepts any real
provider answer — it no longer demands a canned echo from a live LLM.

## The round-14 checks

| Script | What it proves |
| --- | --- |
| `check-header-popovers.cjs` | every header popover (profile, language) opens **inside the viewport** at 360/390/768/1440 px, in fa/RTL and en/LTR, and the page never scrolls sideways — the round-14 fix for the profile card that hung off a phone screen |
| `theme-check.cjs` | diagnostic: clicks the segmented theme control by its real order `[system, light, dark, glass]` (the labels used to name the wrong buttons) and follows `data-theme`, `data-theme-choice`, localStorage and `aria-pressed` through every click and a reload |

Round-14 product fixes the checkers pin: header popovers are placed in JS (fixed, hung under
their trigger, clamped to the viewport) because the trigger cluster wraps to different physical
sides per width and direction; on phones they become a scrollable glass sheet; the icon-only
command-palette trigger keeps a 44 px tap target.

## The round-15 checks

| Script | What it proves |
| --- | --- |
| `check-chat-ui.cjs` | the rebuilt chat workspace, live: the fixed-height glass shell (which *compensates* for the deployment banner via `--chat-offset` instead of hiding it), the conversation rail (search, new, pin, rename, delete-with-confirm and a real removal), the one-line model+variant composer row, streaming + edit/resubmit + message deletion against the mock upstream, the Markdown code-fence copy button, and the 390 px drawer (toggle opens, backdrop closes) with zero page errors |
| `check-telegram-bot.cjs` | updated for the round-15 bar: the two persistent labels («💬 گفتگو» → chat mode, «🧭 منو» → the nested glass hub) **and** every legacy round-13/14 label still routing, because a stale reply keyboard stays on the user's screen until a new bar arrives |

Round-15 hardening of existing harnesses (all three were false-negative lessons, fixed in the
checker without weakening the contract): `check-header-popovers.cjs` waits for the popover to
open/close with bounded retries — a viewport resize re-renders the topbar and a click landing
mid-render is lost; `check-chat-ui.cjs` pins the drawer's CSS transitions during measurement —
headless Chromium can freeze transform transitions without vsync, leaving computed geometry
mid-air — and waits for the post-send conversation reload before reading a bubble's meta;
`mobile-audit.cjs` must be run **authenticated** (its verdicts are meaningless on the login
page alone — an unattended run without credentials once reported a falsely clean audit).

Round-15 product fixes the checkers pin: the parked chat drawer sets `visibility:hidden` (out of
the tab order, correct for screen readers); convo tool buttons are 32 px, the chat-bar model chip
and pricing link keep 40 px, hero suggestion chips 44 px, the composer hint stays ≥ 11 px; and
reasoning blocks (`<think>`) never leak into the rail preview or the rendered answer —
the Markdown renderer, the API preview and the client-side preview helper all strip them.
