import { Link } from "react-router-dom";
import { api } from "../api/client";
import type { Balance, CatalogModel, Job, ModuleCapability, Paged } from "../api/types";
import { Badge, Card, EmptyState, Progress, Stat, useApi } from "../components/ui";
import { Icon, type IconName } from "../components/icons";
import { formatCredits, formatDateTime, humanize } from "../utils/format";
import { useApp, useI18n } from "../state/app";
import { accessReason } from "./shared";

const QUICK_ACTIONS: { to: string; key: "nav.chat" | "nav.images" | "nav.documents" | "nav.data"; icon: IconName }[] = [
  { to: "/app/chat", key: "nav.chat", icon: "chat" },
  { to: "/app/images", key: "nav.images", icon: "image" },
  { to: "/app/documents", key: "nav.documents", icon: "document" },
  { to: "/app/data", key: "nav.data", icon: "data" },
];

const MODULE_ICONS: Record<string, IconName> = {
  chat: "chat",
  coding: "code",
  image_generation: "image",
  document: "document",
  translation: "translate",
  audio: "audio",
  video: "video",
  embedding: "brain",
  rerank: "list",
  data_analysis: "data",
};

const USAGE_LABELS: Record<string, string> = {
  charged_micro: "Credits charged",
  charged_credits: "Credits charged",
  prompt_tokens: "Prompt tokens",
  completion_tokens: "Completion tokens",
  total_tokens: "Total tokens",
  requests: "Requests",
  records: "Records",
  count: "Records",
};

export function Dashboard(): JSX.Element {
  const { t, locale } = useI18n();
  const { user, meta } = useApp();
  const balance = useApi<Balance>(() => api.get("/api/v1/billing/balance"), []);
  const capabilities = useApi<{ modules: Record<string, ModuleCapability> }>(() => api.get("/api/v1/modules/capabilities"), []);
  const models = useApi<Paged<CatalogModel>>(() => api.get("/api/v1/models", { page_size: 8 }), []);
  const jobs = useApi<Paged<Job>>(() => api.get("/api/v1/jobs", { page_size: 5 }), []);
  const usage = useApi<{ totals?: Record<string, number> }>(() => api.get("/api/v1/billing/usage", { page_size: 1 }), []);

  const modules = capabilities.data?.modules || {};
  const moduleEntries = Object.entries(modules);
  const operational = moduleEntries.filter(([, value]) => value.available);
  const unavailable = moduleEntries.filter(([, value]) => !value.available);
  const ready = moduleEntries.length > 0 ? operational.length : 0;

  return (
    <div className="stack">
      <section className="hero">
        <div className="hero__content">
          <span className="eyebrow">
            <Icon name="sparkles" size={14} />
            {meta?.app_name || t("app.name")}
          </span>
          <h1 className="hero__title">
            {t("hero.welcome")}
            {user?.display_name ? `، ${user.display_name}` : user?.email ? `، ${user.email}` : ""}
          </h1>
          <p className="hero__text">
            {t("app.tagline")} · {operational.length}/{moduleEntries.length || "—"} {t("label.modules")}
            {unavailable.length > 0 ? ` · ${unavailable.length} ${t("common.notConfigured")}` : ""}
          </p>
        </div>
        <div className="row">
          <span className="muted small">{t("hero.quickActions")}:</span>
          {QUICK_ACTIONS.map((action) => (
            <Link key={action.to} className="chip" to={action.to}>
              <Icon name={action.icon} size={15} />
              {t(action.key)}
            </Link>
          ))}
        </div>
      </section>

      <div className="grid grid--4">
        <Stat
          icon="wallet"
          label={t("billing.balance")}
          value={`${balance.data?.balance_display ?? "—"} ${balance.data?.credit_display_name ?? t("label.credits")}`}
          hint={balance.data?.is_frozen ? t("warning.deploymentTitle") : t("billing.manualNote")}
          tone={balance.data?.is_frozen ? "danger" : undefined}
        />
        <Stat
          icon="chart-line"
          label={`${t("nav.usage")} · ${t("label.today")}`}
          value={formatCredits(balance.data?.spent_today_micro ?? 0)}
          hint={`${t("label.credits")} · ${t("label.status")}: ${balance.data?.is_frozen ? "frozen" : "active"}`}
        />
        <Stat
          icon="brain"
          label={t("nav.catalog")}
          value={models.data?.pagination?.total ?? models.data?.items?.length ?? 0}
          hint={t("label.model")}
        />
        <Stat
          icon="cpu"
          label={t("label.modules")}
          value={`${ready}/${moduleEntries.length || 0}`}
          hint={unavailable.length ? `${unavailable.length} ${t("common.notConfigured")}` : t("status.success")}
          tone={moduleEntries.length > 0 && operational.length === moduleEntries.length ? "success" : undefined}
        />
      </div>

      <div className="grid grid--2">
        <Card
          icon="cpu"
          title={t("label.modules")}
          subtitle="Reported by the backend from the real provider/model configuration."
        >
          {capabilities.loading ? (
            <Progress value={0} max={100} label={t("status.loading")} />
          ) : moduleEntries.length === 0 ? (
            <EmptyState icon="cpu" hint={t("common.notConfigured")} />
          ) : (
            <div className="stack stack--tight">
              <Progress
                value={operational.length}
                max={moduleEntries.length}
                label={`${operational.length}/${moduleEntries.length}`}
                tone={operational.length === moduleEntries.length ? "success" : "warning"}
              />
              <ul className="stack stack--tight" style={{ listStyle: "none", padding: 0, margin: "0.4rem 0 0" }}>
                {moduleEntries.map(([key, module]) => (
                  <li key={key} className="row row--between">
                    <span className="row" style={{ gap: "0.5rem" }}>
                      <Icon name={MODULE_ICONS[key] || "bolt"} size={16} />
                      {module.label}
                    </span>
                    {module.available ? (
                      <Badge tone="success">{module.options.length}</Badge>
                    ) : (
                      <Badge tone="warning">{t("common.notConfigured")}</Badge>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </Card>

        <Card
          icon="list"
          title={t("nav.jobs")}
          subtitle="Background work (images, audio, video, documents, exports)."
          actions={<Link to="/app/jobs">{t("common.all")}</Link>}
        >
          {jobs.loading ? (
            <EmptyState icon="list" hint={t("status.loading")} />
          ) : jobs.data && jobs.data.items.length === 0 ? (
            <EmptyState icon="list" title={t("status.empty")} hint={t("nav.jobs")} />
          ) : (
            <ul className="stack stack--tight" style={{ listStyle: "none", padding: 0, margin: 0 }}>
              {(jobs.data?.items || []).map((job) => (
                <li key={job.id} className="row row--between">
                  <span className="row" style={{ gap: "0.5rem" }}>
                    <Icon name="bolt" size={15} />
                    <span className="mono small">#{job.id}</span>
                    {job.type}
                  </span>
                  <Badge tone={job.status === "succeeded" ? "success" : job.status === "failed" ? "danger" : "warning"}>
                    {job.status}
                  </Badge>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <Card
        icon="brain"
        title={t("nav.catalog")}
        subtitle="Priced and permission-filtered server-side."
        actions={<Link to="/app/models">{t("common.all")}</Link>}
      >
        {models.data && models.data.items.length === 0 ? (
          <EmptyState icon="brain" hint={t("chat.noModels")} />
        ) : (
          <div className="table-wrap table-wrap--stack">
            <table className="table table--stack">
              <thead>
                <tr>
                  <th>{t("label.model")}</th>
                  <th>{t("label.provider")}</th>
                  <th>{t("label.tier")}</th>
                  <th>Input / 1M</th>
                  <th>{t("label.status")}</th>
                </tr>
              </thead>
              <tbody>
                {(models.data?.items || []).map((model) => (
                  <tr key={model.id}>
                    <td data-label={t("label.model")}>
                      <Link to={`/app/models/${model.id}`}>{model.display_name}</Link>
                    </td>
                    <td className="muted" data-label={t("label.provider")}>{model.provider}</td>
                    <td data-label={t("label.tier")}>
                      <Badge tone={model.access_tier === "free" ? "success" : "info"}>{model.access_tier}</Badge>
                    </td>
                    <td className="mono" data-label="Input / 1M">{model.pricing?.input_credits_per_mtok ?? "—"}</td>
                    <td data-label={t("label.status")}>
                      {model.accessible ? (
                        <Badge tone="success">{t("status.available")}</Badge>
                      ) : (
                        <Badge tone="warning">{accessReason(t, model, "short")}</Badge>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Card icon="chart-line" title={t("nav.usage")} subtitle="Totals from your usage records.">
        {usage.data?.totals ? (
          <div className="kv">
            {Object.entries(usage.data.totals).map(([key, value]) => (
              <div key={key}>
                <span>{USAGE_LABELS[key] || humanize(key)}</span>
                <span className="mono">{typeof value === "number" ? value.toLocaleString(locale) : String(value)}</span>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            icon="chart-line"
            title={t("status.empty")}
            hint={`last refreshed ${formatDateTime(new Date().toISOString(), locale)}`}
          />
        )}
      </Card>
    </div>
  );
}
