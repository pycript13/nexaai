"""Central configuration for Nexa AI.

All runtime configuration is environment-driven (12-factor). Nothing secret is
ever hard-coded here; `Settings.assert_production_ready()` refuses to boot a
production instance that still carries placeholder secrets.
"""
from __future__ import annotations

import ipaddress
import os
from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

PLACEHOLDER_MARKERS = ("CHANGE_ME", "changeme", "your-secret", "example.com")


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="NEXA_",
        env_file=(".env", "../.env", "../../.env"),
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # --- core ---------------------------------------------------------------
    app_name: str = "Nexa AI"
    version: str = "1.1.0"
    environment: Literal["development", "staging", "production", "test"] = "development"
    deployment_mode: Literal["local", "public_ip", "domain_https"] = "local"
    public_base_url: str = "http://localhost:8080"
    public_port: int = 8080
    # The address a browser outside this machine must use. It is deployment metadata: the
    # installer writes it, the reachability check (deployment/linux/check_public_access.sh)
    # reads it, and it is "pinned" by hand when the outbound address (api.ipify.org) is not
    # the reachable one (double NAT, CGNAT, or a proxy in front of the host).
    public_ip: str = ""
    log_level: str = "INFO"
    log_json: bool = False
    log_retention_days: int = 30
    admin_email_hint: str = ""
    support_message: str = ""
    # Browser framing policy. Empty = refuse to be framed (clickjacking protection, the default
    # for a public-IP deployment). Set it only when the app is deliberately embedded — for
    # example behind an internal portal: NEXA_FRAME_ANCESTORS="https://portal.example.com".
    # Space-separated origins; "https://*.example.com" wildcards are allowed by CSP.
    frame_ancestors: str = ""

    # --- secrets ------------------------------------------------------------
    secret_key: str = "dev-insecure-secret-key-do-not-use-in-production"
    encryption_key: str = ""  # Fernet key; derived from secret_key only in dev
    extra_secret: str = ""

    # --- database -----------------------------------------------------------
    database_url: str = "sqlite:///./data/nexa.db"
    db_pool_size: int = 10
    db_max_overflow: int = 20
    db_pool_recycle: int = 1800
    db_echo: bool = False
    db_statement_timeout_ms: int = 30000

    # --- redis (optional) ---------------------------------------------------
    redis_url: str = ""
    use_redis_rate_limit: bool = False

    # --- http / security ----------------------------------------------------
    cors_origins: str = "http://localhost:8080,http://localhost:5173"
    cookie_secure: bool = False
    cookie_samesite: Literal["lax", "strict", "none"] = "lax"
    cookie_domain: str = ""
    session_ttl_hours: int = 720
    session_idle_timeout_minutes: int = 1440
    csrf_enabled: bool = True
    trusted_hosts: str = "*"
    allow_dev_hosts: bool | None = None
    """Allow the host names of cloud development workspaces (GitHub Codespaces, Gitpod, …).

    ``HostGuard`` correctly refuses a host the operator never listed, but a Codespaces forwarded URL
    changes on every rebuild, so a workspace deployment would answer ``400 host_not_allowed`` to every
    request — including sign-up.  Unset means "yes outside production, no in production"; the
    installers write ``NEXA_ALLOW_DEV_HOSTS=false`` explicitly into a production ``.env``.
    """
    max_request_body_mb: int = 52
    security_headers: bool = True
    hsts_enabled: bool = False
    rate_limit_enabled: bool = True
    auth_rate_limit_per_minute: int = 10
    api_rate_limit_per_minute: int = 240
    registration_mode: Literal["open", "invite_only", "closed"] = "open"
    #: Which of the three registration policies an operator is allowed to select at runtime
    #: (Admin → Settings). A locked-down deployment can set, for example,
    #: ``NEXA_ALLOWED_REGISTRATION_MODES=invite_only`` so nobody can open the door by accident —
    #: and ``closed`` can still be *removed* from the list to guarantee that the sign-up page
    #: keeps working for the people the operator shares the link with.
    allowed_registration_modes: str = "open,invite_only,closed"
    password_min_length: int = 10
    lockout_threshold: int = 10
    lockout_minutes: int = 15

    # --- provider / SSRF ----------------------------------------------------
    allow_private_provider_endpoints: bool = False
    # --- Telegram bot (optional integration; disabled unless a token is configured) ---
    telegram_enabled: bool = False
    telegram_bot_token: str = ""
    telegram_bot_username: str = ""          # without the @, used to build t.me deep links
    telegram_mode: str = "polling"           # polling | webhook | off
    telegram_webhook_secret: str = ""        # required by /api/v1/telegram/webhook when set
    telegram_api_base: str = "https://api.telegram.org"   # override only for tests/self-hosted Bot API servers
    telegram_admin_chat_id: str = ""         # optional: receives a start-up notice

    provider_allowed_hosts: str = ""
    provider_connect_timeout: float = 10.0
    provider_read_timeout: float = 120.0
    provider_max_retries: int = 2
    provider_allow_insecure_http: bool = False

    # --- files --------------------------------------------------------------
    upload_dir: str = "./uploads"
    max_upload_mb: int = 50
    user_storage_quota_mb: int = 2048
    file_retention_days: int = 180
    malware_scan_enabled: bool = False
    malware_scan_command: str = ""
    allowed_upload_extensions: str = (
        "png,jpg,jpeg,webp,gif,bmp,pdf,txt,md,csv,tsv,json,xlsx,xls,docx,doc,"
        "mp3,wav,m4a,ogg,flac,webm,mp4,mov,zip"
    )

    # --- billing ------------------------------------------------------------
    default_currency: str = "USD"
    credit_usd_rate: float = 1.0          # how many USD one Nexa credit is worth
    credit_display_name: str = "credits"
    default_markup_percent: float = 30.0
    minimum_charge_micro: int = 1000
    global_daily_spend_limit_micro: int = 0
    admin_test_max_cost_per_request_micro: int = 200_000
    admin_test_daily_limit_micro: int = 5_000_000
    free_trial_credit_micro: int = 0
    manual_payments_enabled: bool = True
    bank_transfer_instructions: str = ""
    crypto_payments_enabled: bool = False
    crypto_assets: str = "BTC,ETH,USDT-TRC20"
    crypto_wallets: str = ""
    crypto_min_confirmations: int = 2
    gateway_stripe_enabled: bool = False
    gateway_stripe_secret_key: str = ""
    gateway_stripe_webhook_secret: str = ""
    gateway_zarinpal_enabled: bool = False
    gateway_zarinpal_merchant_id: str = ""

    # --- email --------------------------------------------------------------
    email_enabled: bool = False
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    smtp_starttls: bool = True
    email_from: str = "Nexa AI <no-reply@example.com>"
    require_email_verification: bool = False

    # --- worker / jobs ------------------------------------------------------
    inline_worker: bool = True
    worker_concurrency: int = 2
    job_max_attempts: int = 3
    job_lease_seconds: int = 300
    job_poll_seconds: float = 2.0
    queue_max_pending_per_user: int = 20

    # --- bootstrap ----------------------------------------------------------
    bootstrap_admin_email: str = ""
    bootstrap_admin_password: str = ""
    bootstrap_admin_name: str = "Nexa Administrator"
    allow_sqlite_in_production: bool = False

    # --- deployment helpers -------------------------------------------------
    serve_frontend: bool = True
    frontend_dist_dir: str = "../frontend/dist"

    @field_validator("log_level")
    @classmethod
    def _upper(cls, v: str) -> str:
        return (v or "INFO").upper()

    @field_validator("allow_dev_hosts")
    @classmethod
    def _dev_hosts_default(cls, v: bool | None, info) -> bool:  # noqa: ANN001
        if v is not None:
            return bool(v)
        environment = (info.data or {}).get("environment", "development")
        return environment != "production"

    # -- derived helpers -----------------------------------------------------
    @property
    def is_production(self) -> bool:
        return self.environment == "production"

    @property
    def is_sqlite(self) -> bool:
        return self.database_url.startswith("sqlite")

    @property
    def cors_origin_list(self) -> list[str]:
        if self.public_base_url:
            origins = [o.strip() for o in self.cors_origins.split(",") if o.strip()]
            base = self.public_base_url.rstrip("/")
            for candidate in (base, base.replace("http://", "https://", 1)):
                if candidate and candidate not in origins:
                    origins.append(candidate)
            return origins
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def trusted_host_list(self) -> list[str]:
        hosts = [h.strip() for h in self.trusted_hosts.split(",") if h.strip()]
        return hosts or ["*"]

    @property
    def allowed_registration_mode_set(self) -> set[str]:
        """The registration policies this deployment permits (always at least one).

        An unknown or empty list falls back to the full set: refusing every policy would make the
        sign-up page a dead end, which is precisely the failure this option exists to prevent.
        """
        known = {"open", "invite_only", "closed"}
        values = {m.strip().lower() for m in self.allowed_registration_modes.split(",") if m.strip()}
        chosen = values & known
        return chosen or known

    def registration_mode_allowed(self, mode: str | None) -> bool:
        return str(mode or "").strip().lower() in self.allowed_registration_mode_set

    def effective_registration_mode(self, stored: str | None) -> str:
        """Never hand out a policy the deployment forbids: fall back to a permitted one."""
        candidate = str(stored or self.registration_mode).strip().lower()
        if candidate in self.allowed_registration_mode_set:
            return candidate
        allowed = self.allowed_registration_mode_set
        return "invite_only" if "invite_only" in allowed else sorted(allowed)[0]

    @property
    def allowed_extension_set(self) -> set[str]:
        return {e.strip().lower().lstrip(".") for e in self.allowed_upload_extensions.split(",") if e.strip()}

    @property
    def crypto_wallet_map(self) -> dict[str, str]:
        out: dict[str, str] = {}
        for chunk in self.crypto_wallets.split(","):
            if "=" in chunk:
                asset, addr = chunk.split("=", 1)
                out[asset.strip().upper()] = addr.strip()
        return out

    @property
    def private_endpoint_allowlist(self) -> list[str]:
        return [h.strip().lower() for h in self.provider_allowed_hosts.split(",") if h.strip()]

    @property
    def is_public_deployment(self) -> bool:
        return self.deployment_mode in ("public_ip", "domain_https")

    @property
    def plain_http_warning(self) -> str | None:
        """A warning shown in the UI + API meta when traffic is not encrypted."""
        if self.deployment_mode == "public_ip" and self.public_base_url.startswith("http://"):
            return (
                "This deployment is reachable over plain HTTP ({url}). Traffic — including "
                "passwords and session cookies — is NOT encrypted in transit. Use only "
                "throw-away test accounts and non-sensitive data, or configure a domain with "
                "HTTPS (docs/PRODUCTION_DEPLOYMENT.md).".format(url=self.public_base_url)
            )
        return None

    def secret_is_placeholder(self, value: str | None) -> bool:
        if not value:
            return True
        return any(marker.lower() in value.lower() for marker in PLACEHOLDER_MARKERS) or len(value) < 16

    def assert_production_ready(self) -> list[str]:
        """Return a list of fatal production misconfigurations (empty == OK)."""
        problems: list[str] = []
        if not self.is_production:
            return problems
        if self.secret_is_placeholder(self.secret_key):
            problems.append("NEXA_SECRET_KEY is missing or still a placeholder value.")
        if self.secret_is_placeholder(self.encryption_key):
            problems.append("NEXA_ENCRYPTION_KEY is missing or still a placeholder value.")
        if self.is_sqlite and not self.allow_sqlite_in_production:
            problems.append(
                "SQLite is not supported as a production database for concurrent users. "
                "Set NEXA_DATABASE_URL to PostgreSQL, or explicitly set "
                "NEXA_ALLOW_SQLITE_IN_PRODUCTION=true for single-user evaluation only."
            )
        if self.is_public_deployment and "*" in self.trusted_host_list:
            problems.append(
                "NEXA_TRUSTED_HOSTS must list your public hostname/IP when "
                "NEXA_DEPLOYMENT_MODE is public_ip/domain_https."
            )
        if self.environment == "production" and self.cookie_samesite == "none" and not self.cookie_secure:
            problems.append("SameSite=None cookies require NEXA_COOKIE_SECURE=true (HTTPS).")
        return problems

    def deployment_warnings(self) -> list[str]:
        warnings: list[str] = list(self.assert_production_ready())
        if self.frame_ancestors:
            warnings.append(
                "NEXA_FRAME_ANCESTORS is set: this deployment may be embedded in "
                f"{self.frame_ancestors}. Keep the list as short as possible — framing protection "
                "is what stops clickjacking."
            )
        if self.plain_http_warning:
            warnings.append(self.plain_http_warning)
        if self.is_production and not self.cookie_secure and self.deployment_mode == "domain_https":
            warnings.append(
                "NEXA_DEPLOYMENT_MODE=domain_https but NEXA_COOKIE_SECURE=false — session cookies "
                "would be sent over HTTP too. Set NEXA_COOKIE_SECURE=true."
            )
        if self.is_production and not self.email_enabled:
            warnings.append(
                "Email delivery is not configured (NEXA_EMAIL_ENABLED=false): email verification, "
                "password-reset e-mails and notifications are disabled. See docs/PROVIDER_CONFIGURATION.md."
            )
        return warnings


@lru_cache
def get_settings() -> Settings:
    """Build the settings object, turning an unreadable `.env` into a usable error message.

    ``BaseSettings`` reads the env file lazily and raises a bare ``PermissionError`` from deep
    inside pydantic. The operator-visible symptom is a wall of traceback while systemd still
    reports the unit as *active* (the process was restarted, the children died) — and it happens
    whenever someone edits or replaces `.env` as root, which is the normal way to change it. The
    installer chowns the file, but a manual ``cp``/``mv`` as root does not. Name the file, name the
    fix, and refuse to start silently.
    """
    try:
        return Settings()
    except PermissionError as exc:
        target = getattr(exc, "filename", None) or ".env"
        raise SystemExit(
            f"Nexa AI cannot read its configuration file: {target} (permission denied).\n"
            f"The service runs as an unprivileged user and must be able to read the file. Fix it with:\n"
            f"    sudo chown <service-user>:<service-user> '{target}'\n"
            f"    sudo chmod 600 '{target}'\n"
            f"then restart the service (systemctl restart nexa-api nexa-worker, or docker compose restart)."
        ) from exc
    except OSError as exc:  # missing interpreter-level problems (bad encoding, I/O errors)
        target = getattr(exc, "filename", None) or ".env"
        raise SystemExit(f"Nexa AI could not read its configuration file {target}: {exc}") from exc


def reset_settings_cache() -> None:
    get_settings.cache_clear()


def is_private_host(host: str) -> bool:
    """True when a host literal (or resolvable name) points at a non-public address."""
    try:
        ip = ipaddress.ip_address(host)
        return bool(ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast)
    except ValueError:
        return host.lower() in {"localhost", "localhost.localdomain", "metadata", "metadata.google.internal"}


def env_flag(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


settings = get_settings()
