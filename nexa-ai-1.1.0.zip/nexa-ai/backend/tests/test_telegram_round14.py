"""Round-14 Telegram contracts: glass buttons that really work, and a chat that stays tidy.

The owner's round-14 report from the live bot: the model list printed numbers but offered no way
to change the model, sessions switched only by typing numbers, and every tap piled a new message
onto the chat. These tests pin the fix:

* section messages carry **inline (glass) buttons** and never re-send the bottom bar;
* a model/variant button carries the **id** (not a list index) and switches at once;
* paging, toggling, switching and choosing **edit the tapped message in place**;
* entering another section **deletes** the previous section message; «منو» deletes and restores
  the fixed bar;
* rename and close are **button flows** (wait-for-message / confirm) instead of bare commands;
* every tap is acknowledged with a toast (``answerCallbackQuery``);
* message bodies speak **one language at a time**.
"""
from __future__ import annotations

import asyncio
import re
import uuid

import pytest
from sqlalchemy import select

from app.core.config import settings
from app.models.provider import Model
from app.models.telegram import TelegramLink
from app.services import telegram as telegram_service
from app.services import telegram_menus as menus
from app.services import telegram_sessions as session_service
from tests.conftest import create_provider_and_model, grant_credits
from tests.tools.fake_telegram import FakeTelegramServer


@pytest.fixture()
def telegram(monkeypatch: pytest.MonkeyPatch):
    server = FakeTelegramServer()
    port = server.start()
    monkeypatch.setattr(settings, "telegram_enabled", True)
    monkeypatch.setattr(settings, "telegram_bot_token", "123456:TEST-TOKEN")
    monkeypatch.setattr(settings, "telegram_bot_username", "nexa_test_bot")
    monkeypatch.setattr(settings, "telegram_api_base", f"http://127.0.0.1:{port}")
    monkeypatch.setattr(settings, "telegram_mode", "polling")
    yield server
    server.stop()


# ------------------------------------------------------------------ helpers -----
def _unique_id() -> int:
    return 700_000_000 + (uuid.uuid4().int % 200_000_000)


def _update(server: FakeTelegramServer, text: str, *, telegram_user_id: int) -> dict:
    return {
        "update_id": server.next_update_id(),
        "message": {
            "message_id": server.next_message_id(),
            "from": {"id": telegram_user_id, "is_bot": False, "first_name": "Tester"},
            "chat": {"id": telegram_user_id, "type": "private"},
            "date": 1_700_000_000,
            "text": text,
        },
    }


def _tap(server: FakeTelegramServer, data: str, *, telegram_user_id: int, message_id: int) -> dict:
    return {
        "update_id": server.next_update_id(),
        "callback_query": {
            "id": str(server.next_update_id()),
            "from": {"id": telegram_user_id, "is_bot": False, "first_name": "Tester"},
            "message": {"message_id": message_id, "chat": {"id": telegram_user_id, "type": "private"},
                        "date": 1_700_000_000},
            "data": data,
        },
    }


def _deliver(db, server: FakeTelegramServer, update: dict) -> tuple[str, list[dict]]:
    before = len(server.sent)
    result = asyncio.run(telegram_service.handle_update(db, update))
    return result, server.sent[before:]


def _say(db, server: FakeTelegramServer, text: str, *, telegram_user_id: int):
    return _deliver(db, server, _update(server, text, telegram_user_id=telegram_user_id))


def _linked_account(user_client, db, server: FakeTelegramServer) -> int:
    telegram_user_id = _unique_id()
    code = user_client.post("/api/v1/telegram/link-code").json()["code"]
    result, _ = _say(db, server, f"/start {code}", telegram_user_id=telegram_user_id)
    assert result == "linked", result
    return telegram_user_id


def _state(db, telegram_user_id: int) -> dict:
    db.expire_all()
    link = db.scalars(
        select(TelegramLink).where(TelegramLink.telegram_user_id == telegram_user_id)
    ).first()
    assert link is not None
    return dict(link.state or {})


def _inline(message: dict) -> list[list[dict]]:
    markup = message.get("reply_markup") or {}
    assert "inline_keyboard" in markup, f"no glass buttons on: {message['text'][:60]}"
    return markup["inline_keyboard"]


def _idata(message: dict) -> list[str]:
    return [button.get("callback_data", "") for row in _inline(message) for button in row]


def _model_ids(db) -> dict[str, int]:
    return {row.display_name: row.id for row in db.scalars(select(Model)).all()}


def _models_page_with(db, server: FakeTelegramServer, telegram_user_id: int, needle: str) -> dict:
    """Walk /models pages until one carries ``needle`` (text or button) — the catalogue is shared."""
    page = 1
    while page <= 40:
        _result, sent = _say(db, server, f"/models {page}", telegram_user_id=telegram_user_id)
        message = sent[-1]
        blob = message["text"] + " ".join(_idata(message))
        if needle in blob:
            return message
        texts = [button.get("text", "") for row in _inline(message) for button in row]
        if "➡️" not in texts:
            break
        page += 1
    raise AssertionError(f"{needle!r} not reachable through /models; last page body:\n{message['text']}")


PERSIAN = re.compile("[\u0600-\u06FF]")


# ------------------------------------------------------------------ contracts ---
def test_section_messages_carry_glass_buttons_and_the_menu_carries_the_bar(
    user_client, db, telegram
) -> None:
    create_provider_and_model(db, published=True, display_name="Markup Model")
    telegram_user_id = _linked_account(user_client, db, telegram)

    _result, sent = _say(db, telegram, "🧠 مدل‌ها", telegram_user_id=telegram_user_id)
    markup = sent[-1].get("reply_markup") or {}
    assert "inline_keyboard" in markup and "keyboard" not in markup, markup

    _result, sent = _say(db, telegram, "💬 گفتگو", telegram_user_id=telegram_user_id)
    markup = sent[-1].get("reply_markup") or {}
    assert "keyboard" in markup and "inline_keyboard" not in markup, markup
    labels = [button["text"] for row in markup["keyboard"] for button in row]
    assert labels == [fa for _a, fa, _e in menus.SECTIONS], "the bar is exactly the six sections"


def test_a_glass_button_switches_the_model_and_edits_the_list_in_place(
    user_client, db, telegram
) -> None:
    create_provider_and_model(db, published=True, display_name="Alpha Glass")
    create_provider_and_model(db, published=True, display_name="Beta Glass")
    grant_credits(db, user_client.email, 20.0)
    telegram_user_id = _linked_account(user_client, db, telegram)
    ids = _model_ids(db)

    target = f"model:{ids['Beta Glass']}"
    listing = _models_page_with(db, telegram, telegram_user_id, target)
    data = _idata(listing)

    result, after = _deliver(db, telegram, _tap(telegram, target, telegram_user_id=telegram_user_id,
                                                message_id=listing["message_id"]))
    assert result == "model_selected"
    assert _state(db, telegram_user_id)["model_id"] == ids["Beta Glass"]
    # In place: the very same message is edited, nothing new is sent.
    assert after == [], "switching must not send a second message"
    edit = next(item for item in telegram.edits if item["message_id"] == listing["message_id"])
    assert "Beta Glass" in edit["text"] and "✅" in edit["text"]
    # ...and the tap is acknowledged with a toast.
    assert telegram.callbacks, "answerCallbackQuery must acknowledge the tap"
    assert "مدل فعال شد" in telegram.callbacks[-1]["text"]


def test_use_still_counts_the_list_while_buttons_carry_ids(user_client, db, telegram) -> None:
    create_provider_and_model(db, published=True, display_name="First Index")
    create_provider_and_model(db, published=True, display_name="Second Index")
    telegram_user_id = _linked_account(user_client, db, telegram)
    ids = _model_ids(db)

    def printed_number(name: str) -> int:
        page = 1
        while page <= 40:
            _result, sent = _say(db, telegram, f"/models {page}", telegram_user_id=telegram_user_id)
            for line in sent[-1]["text"].splitlines():
                if name in line:
                    import re as _re
                    match = _re.search(r"<b>(\d+)\.", line)
                    assert match, line
                    return int(match.group(1))
            page += 1
        raise AssertionError(f"{name} not listed")

    # /use counts the *visible list*, exactly like the printed numbers — never the raw id.
    first_number = printed_number("First Index")
    result, _sent = _say(db, telegram, f"/use {first_number}", telegram_user_id=telegram_user_id)
    assert result == "model_selected"
    assert _state(db, telegram_user_id)["model_id"] == ids["First Index"]

    second_number = printed_number("Second Index")
    result, _sent = _say(db, telegram, f"/use {second_number}", telegram_user_id=telegram_user_id)
    assert result == "model_selected"
    assert _state(db, telegram_user_id)["model_id"] == ids["Second Index"]


def test_a_glass_button_switches_the_session_and_edits_the_list(user_client, db, telegram) -> None:
    telegram_user_id = _linked_account(user_client, db, telegram)
    assert _say(db, telegram, "/new گفتگوی یک", telegram_user_id=telegram_user_id)[0] == "session_created"
    assert _say(db, telegram, "/new گفتگوی دو", telegram_user_id=telegram_user_id)[0] == "session_created"

    _result, sent = _say(db, telegram, "/sessions", telegram_user_id=telegram_user_id)
    listing = sent[-1]
    data = _idata(listing)
    assert "session:1" in data and "session:2" in data, data

    result, after = _deliver(db, telegram, _tap(telegram, "session:1", telegram_user_id=telegram_user_id,
                                                message_id=listing["message_id"]))
    assert result == "session_switched"
    assert _state(db, telegram_user_id)["active_session_id"] == 1
    assert after == [], "the session list must edit itself, not repeat"
    assert any(edit["message_id"] == listing["message_id"] for edit in telegram.edits)
    assert "سشن فعال شد" in telegram.callbacks[-1]["text"]


def test_rename_waits_for_one_message_and_cancel_escapes(user_client, db, telegram) -> None:
    telegram_user_id = _linked_account(user_client, db, telegram)
    assert _say(db, telegram, "/new عنوان اولیه", telegram_user_id=telegram_user_id)[0] == "session_created"
    _result, sent = _say(db, telegram, "/sessions", telegram_user_id=telegram_user_id)
    listing = sent[-1]

    result, _after = _deliver(db, telegram, _tap(telegram, "session:rename:begin",
                                                 telegram_user_id=telegram_user_id,
                                                 message_id=listing["message_id"]))
    assert result == "rename_waiting"
    assert _state(db, telegram_user_id).get("awaiting_rename") is True

    result, _after = _say(db, telegram, "نام نو", telegram_user_id=telegram_user_id)
    assert result == "session_renamed"
    state = _state(db, telegram_user_id)
    assert state["sessions"][0]["title"] == "نام نو"
    assert state.get("awaiting_rename") is None

    # Cancel leaves the waiting mode: the next text is ordinary navigation again.
    _result, sent = _say(db, telegram, "/sessions", telegram_user_id=telegram_user_id)
    listing = sent[-1]
    _deliver(db, telegram, _tap(telegram, "session:rename:begin", telegram_user_id=telegram_user_id,
                                message_id=listing["message_id"]))
    result, _after = _say(db, telegram, "/cancel", telegram_user_id=telegram_user_id)
    assert result == "cancelled"
    result, _after = _say(db, telegram, "🗂 سشن‌ها", telegram_user_id=telegram_user_id)
    assert result == "sessions", "after /cancel the text must not be swallowed as a title"
    assert _state(db, telegram_user_id)["sessions"][0]["title"] == "نام نو"


def test_close_confirms_before_closing(user_client, db, telegram) -> None:
    telegram_user_id = _linked_account(user_client, db, telegram)
    assert _say(db, telegram, "/new بسته شود", telegram_user_id=telegram_user_id)[0] == "session_created"
    _result, sent = _say(db, telegram, "/sessions", telegram_user_id=telegram_user_id)
    listing = sent[-1]

    result, _after = _deliver(db, telegram, _tap(telegram, "session:close",
                                                 telegram_user_id=telegram_user_id,
                                                 message_id=listing["message_id"]))
    assert result == "close_confirm"
    assert len(_state(db, telegram_user_id)["sessions"]) == 1, "a question must not close anything"
    # The confirmation replaced the list's glass buttons, in place.
    edit = next(item for item in telegram.edits if item["message_id"] == listing["message_id"])
    confirm_data = [button.get("callback_data") for row in edit["reply_markup"]["inline_keyboard"]
                    for button in row]
    assert "session:close:yes" in confirm_data, confirm_data

    result, _after = _deliver(db, telegram, _tap(telegram, "session:close:yes",
                                                 telegram_user_id=telegram_user_id,
                                                 message_id=listing["message_id"]))
    assert result == "session_closed"
    assert _state(db, telegram_user_id)["sessions"] == []
    assert "سشن بسته شد" in telegram.callbacks[-1]["text"]


def test_entering_a_section_deletes_the_previous_one(user_client, db, telegram) -> None:
    telegram_user_id = _linked_account(user_client, db, telegram)

    _result, sent = _say(db, telegram, "🧠 مدل‌ها", telegram_user_id=telegram_user_id)
    models_message = sent[-1]["message_id"]
    _result, sent = _say(db, telegram, "⚙️ تنظیمات", telegram_user_id=telegram_user_id)
    settings_message = sent[-1]["message_id"]
    assert {"chat_id": telegram_user_id, "message_id": models_message} in telegram.deletes

    _result, sent = _say(db, telegram, "💬 گفتگو", telegram_user_id=telegram_user_id)
    assert {"chat_id": telegram_user_id, "message_id": settings_message} in telegram.deletes
    assert _state(db, telegram_user_id).get("ui_msg_id") in (None, 0)


def test_bodies_speak_one_language_at_a_time(user_client, db, telegram) -> None:
    create_provider_and_model(db, published=True, display_name="Single Lang")
    telegram_user_id = _linked_account(user_client, db, telegram)

    _result, sent = _say(db, telegram, "/models", telegram_user_id=telegram_user_id)
    body = sent[-1]["text"]
    assert "page " not in body and "available models" not in body, body
    assert PERSIAN.search(body), body

    english_label = "\U0001F1EC\U0001F1E7 English"
    _result, sent = _say(db, telegram, english_label, telegram_user_id=telegram_user_id)
    assert _state(db, telegram_user_id)["settings"]["language"] == "en"
    _result, sent = _say(db, telegram, "/models", telegram_user_id=telegram_user_id)
    body = sent[-1]["text"]
    assert not PERSIAN.search(body), body
    assert "Page 1 of" in body and "Tap a model" in body


def test_send_message_prefers_the_glass_buttons_when_both_markups_are_given(telegram) -> None:
    ok = asyncio.run(telegram_service.send_message(
        42, "both", keyboard=[[{"text": "glass", "callback_data": "noop"}]],
        reply_keyboard=menus.fixed_bar("fa"),
    ))
    assert ok is True
    markup = telegram.sent[-1]["reply_markup"]
    assert "inline_keyboard" in markup, "silently dropping the inline keyboard is the round-13 bug"


def test_the_model_list_shows_descriptions_under_each_model(user_client, db, telegram) -> None:
    create_provider_and_model(db, published=True, display_name="Described Model")
    model = db.scalars(select(Model).where(Model.display_name == "Described Model")).first()
    model.description = "یک مدل آزمایشی با توضیح کامل برای نمایش در ربات."
    db.commit()
    telegram_user_id = _linked_account(user_client, db, telegram)

    message = _models_page_with(db, telegram, telegram_user_id, "یک مدل آزمایشی با توضیح کامل")
    assert "یک مدل آزمایشی با توضیح کامل" in message["text"]
