#!/usr/bin/env node
/**
 * Round-14 UI: header popovers must never leave the viewport, in either direction.
 *
 * The owner's phone showed the profile menu hanging half off-screen: the card was anchored
 * with `inset-inline-end`, which resolves to the WRONG physical side under RTL (the trigger
 * cluster sits at the trailing/right edge in both directions). This checker opens every header
 * popover at four widths, in fa/RTL and en/LTR, and asserts each card is fully inside the
 * viewport, that the page itself never scrolls sideways, and leaves screenshots as evidence.
 *
 * Usage: node check-header-popovers.cjs [baseUrl] <email> <password>
 */
const BASE = (process.argv[2] || "http://127.0.0.1:8081").replace(/\/$/, "");
const EMAIL = process.argv[3] || "";
const PASSWORD = process.argv[4] || "";
const SHOTS = process.env.SHOTS_DIR || "/home/user/responsive-shots";

const puppeteer = require("puppeteer-core");
const problems = [];
const ok = (m) => console.log(`  ✓ ${m}`);
const fail = (m) => {
  problems.push(m);
  console.log(`  ✗ ${m}`);
};
const check = (condition, message) => (condition ? ok(message) : fail(message));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium",
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader"],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 900 });
  await page.goto(`${BASE}/login`, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.waitForSelector('input[type="email"]', { timeout: 45000 });
  await page.type('input[type="email"]', EMAIL);
  await page.type('input[type="password"]', PASSWORD);
  await page.waitForFunction(() => !document.querySelector(".splash-stage"), { timeout: 30000 });
  await page.click('button[type="submit"]');
  await page.waitForFunction(() => location.pathname.startsWith("/app"), { timeout: 45000 });
  await page.waitForSelector(".topbar", { timeout: 30000 });
  await sleep(1000);
  ok("signed in");

  const measure = () =>
    page.evaluate(() => {
      const menu = document.querySelector(".menu");
      if (!menu) return null;
      const r = menu.getBoundingClientRect();
      return { x: r.x, y: r.y, w: r.width, h: r.height, vw: innerWidth, vh: innerHeight };
    });

  const openAndMeasure = async (label, trigger) => {
    await page.click(trigger);
    await sleep(350);
    const box = await measure();
    if (!box) {
      fail(`${label}: no popover appeared`);
      return null;
    }
    const inside = box.x >= -1 && box.y >= -1 && box.x + box.w <= box.vw + 1 && box.y + box.h <= box.vh + 1;
    check(inside, `${label}: popover inside the viewport (x=${box.x.toFixed(0)} w=${box.w.toFixed(0)} vw=${box.vw})`);
    const sideways = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth + 1);
    check(!sideways, `${label}: the page itself does not scroll sideways`);
    await page.keyboard.press("Escape");
    await sleep(250);
    return box;
  };

  for (const width of [360, 390, 768, 1440]) {
    await page.setViewport({ width, height: 820 });
    await sleep(500);
    console.log(`\n== ${width}px (fa / RTL)`);
    await openAndMeasure(`${width}px profile menu`, ".user-chip__button");
    await openAndMeasure(`${width}px language menu`, ".user-chip .iconbtn");
    if (width === 390) {
      await page.screenshot({ path: `${SHOTS}/round14-sheet-390.png` });
    }
  }

  // ---------------------------------------------------------- en / LTR ----------
  console.log("\n== 390px (en / LTR)");
  await page.setViewport({ width: 390, height: 820 });
  await sleep(400);
  await page.click(".user-chip .iconbtn");
  await sleep(350);
  const clicked = await page.evaluate(() => {
    const button = [...document.querySelectorAll(".menu button")].find((b) => /English/.test(b.textContent || ""));
    if (button) button.click();
    return !!button;
  });
  check(clicked, "language switched to English from the popover");
  await sleep(800);
  const dir = await page.evaluate(() => document.documentElement.dir || document.dir);
  check(dir === "ltr", `document direction follows the locale (dir=${dir})`);
  await openAndMeasure("390px en profile menu", ".user-chip__button");
  await openAndMeasure("390px en language menu", ".user-chip .iconbtn");

  // back to Persian for the other checkers
  await page.click(".user-chip .iconbtn");
  await sleep(350);
  await page.evaluate(() => {
    const button = [...document.querySelectorAll(".menu button")].find((b) => /فارسی/.test(b.textContent || ""));
    if (button) button.click();
  });
  await sleep(600);

  await browser.close();
  console.log(`\nPROBLEMS: ${problems.length}`);
  problems.forEach((p) => console.log(`  - ${p}`));
  process.exit(problems.length ? 1 : 0);
})().catch((error) => {
  console.error("CHECKER CRASHED:", error.message);
  process.exit(2);
});
