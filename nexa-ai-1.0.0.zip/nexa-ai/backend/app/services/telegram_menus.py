"""Keyboards and texts for the Telegram bot: a fixed button bar, nested sections, tidy copy.

The owner's requirements, turned into code:

* **fixed buttons at the bottom** — a persistent ``ReplyKeyboardMarkup`` (Telegram keeps it above the
  input field, so the bot is usable with one thumb and never shows a bare text box);
* **sections, nested** — tapping a button in the bottom bar opens that section *in place*: the bar
  switches to the section's own buttons (including «بازگشت»), and the message carries the inline
  actions of that section. Nothing is a dead end;
* **commands too** — everything reachable by button is reachable by command, and the command list is
  published with ``setMyCommands`` so Telegram's own menu shows it;
* **one language at a time** — the labels follow the account's setting (``/settings``) instead of
  printing both languages on every line.

Button labels are the contract with ``handle_message``: a reply-keyboard tap arrives as a plain text
message, so ``LABEL_ACTIONS`` maps every label back to the action it stands for (in both languages).
"""
from __future__ import annotations

from typing import Any

from app.models.provider import Model

#: The sections of the fixed bottom bar, in order. Each entry is (action, fa, en).
SECTIONS: list[tuple[str, str, str]] = [
    ("chat", "💬 گفتگو", "💬 Chat"),
    ("models", "🧠 مدل‌ها", "🧠 Models"),
    ("sessions", "🗂 سشن‌ها", "🗂 Sessions"),
    ("account", "💳 حساب من", "💳 Account"),
    ("settings", "⚙️ تنظیمات", "⚙️ Settings"),
    ("help", "❓ راهنما", "❓ Help"),
]

BACK_LABEL = ("🔙 بازگشت", "🔙 Back")

#: Sub-keyboards per section: (action, fa, en) plus the row on which they sit.
SECTION_ROWS: dict[str, list[list[tuple[str, str, str]]]] = {
    "models": [
        [("models_list", "📋 فهرست مدل‌ها", "📋 Model list")],
        [("variants", "🧩 نسخه‌ها", "🧩 Variants"), ("model_current", "🎯 مدل فعلی", "🎯 Current model")],
    ],
    "sessions": [
        [("sessions_list", "📂 نمایش سشن‌ها", "📂 List sessions")],
        [("session_new", "🆕 سشن تازه", "🆕 New session"), ("session_close", "🗑 بستن سشن فعلی", "🗑 Close current")],
        [("session_rename", "✏️ تغییر نام", "✏️ Rename")],
    ],
    "account": [
        [("balance", "💳 اعتبار", "💳 Balance"), ("usage", "📊 مصرف", "📊 Usage")],
        [("stats", "📈 آمار سشن‌ها", "📈 Session stats"), ("status", "👤 وضعیت حساب", "👤 Account status")],
        [("whoami", "🔢 شناسهٔ من", "🔢 My id"), ("export", "⬇️ خروجی گفتگو", "⬇️ Export chat")],
    ],
    "settings": [
        [("lang_fa", "🇮🇷 فارسی", "🇮🇷 Persian"), ("lang_en", "🇬🇧 English", "🇬🇧 English")],
        [("toggle_cost", "💰 نمایش هزینه", "💰 Show cost"), ("toggle_typing", "⌨️ نشانگر تایپ", "⌨️ Typing indicator")],
        [("history_short", "🧠 حافظهٔ کوتاه", "🧠 Short memory"), ("history_long", "🧠 حافظهٔ بلند", "🧠 Long memory")],
    ],
    "help": [
        [("help_commands", "📜 دستورها", "📜 Commands"), ("help_chat", "💬 چطور بپرسیم", "💬 How to ask")],
        [("help_sessions", "🗂 سشن‌ها چیست", "🗂 What sessions are"), ("help_billing", "💳 هزینه‌ها", "💳 Costs")],
    ],
    "chat": [
        [("chat_new", "🆕 گفتگوی تازه", "🆕 New chat"), ("chat_retry", "🔁 تکرار آخرین", "🔁 Retry last")],
    ],
}

#: label → (action, section). Filled from the tables above, both languages.
LABEL_ACTIONS: dict[str, tuple[str, str]] = {}


def label_for(action: str, language: str = "fa") -> str:
    """The button text of an action in the account's language."""
    for _, fa, en in SECTIONS:
        if fa == action or en == action:
            return fa if language == "fa" else en
    for rows in SECTION_ROWS.values():
        for row in rows:
            for item_action, fa, en in row:
                if item_action == action:
                    return fa if language == "fa" else en
    return action


def _rebuild_labels() -> None:
    LABEL_ACTIONS.clear()
    for action, fa, en in SECTIONS:
        LABEL_ACTIONS[fa] = (action, action)
        LABEL_ACTIONS[en] = (action, action)
    LABEL_ACTIONS[BACK_LABEL[0]] = ("back", "main")
    LABEL_ACTIONS[BACK_LABEL[1]] = ("back", "main")
    for section, rows in SECTION_ROWS.items():
        for row in rows:
            for action, fa, en in row:
                LABEL_ACTIONS[fa] = (action, section)
                LABEL_ACTIONS[en] = (action, section)


_rebuild_labels()


def action_for_label(text: str) -> tuple[str, str] | None:
    """Map a reply-keyboard tap back to its action (``None`` for ordinary text)."""
    return LABEL_ACTIONS.get((text or "").strip())


def _reply_rows(section: str, language: str) -> list[list[str]]:
    rows: list[list[str]] = []
    if section in SECTION_ROWS:
        for row in SECTION_ROWS[section]:
            rows.append([fa if language == "fa" else en for _action, fa, en in row])
    # The fixed bar is always the last rows, so the bottom buttons never disappear.
    bar: list[str] = []
    for _action, fa, en in SECTIONS:
        bar.append(fa if language == "fa" else en)
    for index in range(0, len(bar), 2):
        rows.append(bar[index:index + 2])
    if section != "main":
        rows.append([BACK_LABEL[0] if language == "fa" else BACK_LABEL[1]])
    return rows


def reply_keyboard(section: str = "main", language: str = "fa") -> dict[str, Any]:
    """The persistent button bar: section buttons on top of the fixed main rows."""
    return {
        "keyboard": [[{"text": text} for text in row] for row in _reply_rows(section, language)],
        "resize_keyboard": True,
        "is_persistent": True,
        "input_field_placeholder": "پیام بنویسید…" if language == "fa" else "Type a message…",
    }


def remove_keyboard() -> dict[str, Any]:
    return {"remove_keyboard": True}


# ------------------------------------------------------------------- inline ----
def button(text: str, data: str) -> dict[str, str]:
    return {"text": text, "callback_data": data[:64]}


def url_button(text: str, url: str) -> dict[str, str]:
    return {"text": text, "url": url}


def main_inline(link_state: dict[str, Any], site_url: str | None = None) -> dict[str, Any]:
    """Inline actions of the start/help message (the bottom bar does the heavy lifting)."""
    from app.services import telegram_sessions as sessions_service

    language = sessions_service.language(link_state)
    rows = [
        [
            button("🧠 مدل‌ها / Models" if language == "fa" else "🧠 Models", "menu:models"),
            button("🗂 سشن‌ها / Sessions" if language == "fa" else "🗂 Sessions", "menu:sessions"),
        ],
        [
            button("💳 اعتبار / Balance" if language == "fa" else "💳 Balance", "menu:balance"),
            button("📊 مصرف / Usage" if language == "fa" else "📊 Usage", "menu:usage"),
        ],
        [
            button("🆕 گفتگوی تازه / New chat" if language == "fa" else "🆕 New chat", "menu:new"),
            button("⚙️ تنظیمات / Settings" if language == "fa" else "⚙️ Settings", "menu:settings"),
        ],
    ]
    if site_url:
        rows.append([url_button("🌐 سایت / Site", site_url)])
    return rows


def answer_actions(language: str = "fa") -> dict[str, Any]:
    """The row Telegram shows under every model answer."""
    if language == "fa":
        return [
            [button("🔁 تکرار", "chat:retry"), button("🆕 سشن تازه", "chat:new"), button("🧠 مدل‌ها", "menu:models")]
        ]
    return [[button("🔁 Retry", "chat:retry"), button("🆕 New session", "chat:new"), button("🧠 Models", "menu:models")]]


def models_inline(models: list[Model], state: dict[str, Any], page: int, per_page: int,
                  language: str = "fa") -> tuple[dict[str, Any], int, int]:
    """Paged model list with the active model ticked; returns (keyboard, page, pages)."""
    import math

    from app.services import telegram_sessions as sessions_service

    pages = max(1, math.ceil(len(models) / per_page))
    page = min(max(page, 1), pages)
    start = (page - 1) * per_page
    window = models[start:start + per_page]
    current_model = (sessions_service.active(state) or {}).get("model_id") or state.get("model_id")
    rows: list[list[dict[str, str]]] = []
    for number, model in enumerate(window, start=start + 1):
        mark = "✅ " if model.id == current_model else ""
        label = f"{mark}{number}. {model.display_name}"[:60]
        rows.append([button(label, f"model:{model.id}")])
    nav: list[dict[str, str]] = []
    if page > 1:
        nav.append(button("⬅️", f"models:{page - 1}"))
    nav.append(button(f"{page}/{pages}", "noop"))
    if page < pages:
        nav.append(button("➡️", f"models:{page + 1}"))
    rows.append(nav)
    rows.append(
        [
            button("🆕 سشن تازه" if language == "fa" else "🆕 New session", "chat:new"),
            button("🧭 منو" if language == "fa" else "🧭 Menu", "menu:home"),
        ]
    )
    return {"inline_keyboard": rows}, page, pages


def sessions_inline(sessions: list[dict[str, Any]], active_id: int | None, language: str = "fa",
                    *, page: int = 1, per_page: int = 10) -> dict[str, Any]:
    """The session picker, paged.

    The store holds up to 20 sessions; a keyboard without paging silently hid everything past
    its first page — listed in the text, unreachable by button. `sessions:page:N` callbacks are
    routed by telegram._handle_reply_action like every other inline action.
    """
    pages = max(1, -(-len(sessions) // per_page))
    page = min(max(1, page), pages)
    rows: list[list[dict[str, str]]] = []
    for row in sessions[(page - 1) * per_page: page * per_page]:
        mark = "✅ " if row.get("id") == active_id else ""
        label = f"{mark}{row.get('id')}. {str(row.get('title') or '')[:38]}"[:60]
        rows.append([button(label, f"session:{row.get('id')}")])
    if not rows:
        rows.append([button("—", "noop")])
    if pages > 1:
        pager: list[dict[str, str]] = []
        if page > 1:
            pager.append(button("⬅️", f"sessions:page:{page - 1}"))
        pager.append(button(f"{page}/{pages}", "noop"))
        if page < pages:
            pager.append(button("➡️", f"sessions:page:{page + 1}"))
        rows.append(pager)
    rows.append(
        [
            button("🆕 تازه" if language == "fa" else "🆕 New", "chat:new"),
            button("🗑 بستن" if language == "fa" else "🗑 Close", "session:close"),
            button("🧭 منو" if language == "fa" else "🧭 Menu", "menu:home"),
        ]
    )
    return {"inline_keyboard": rows}


def variants_inline(variants: list[Any], active_variant: int | None, language: str = "fa") -> dict[str, Any]:
    rows: list[list[dict[str, str]]] = []
    raw_mark = "✅ " if not active_variant else ""
    rows.append([button(f"{raw_mark}0. {'مدل خام' if language == 'fa' else 'raw model'}", "variant:0")])
    for index, variant in enumerate(variants, start=1):
        mark = "✅ " if variant.id == active_variant else ""
        rows.append([button(f"{mark}{index}. {variant.name}"[:60], f"variant:{variant.id}")])
    rows.append([button("🧭 منو" if language == "fa" else "🧭 Menu", "menu:home")])
    return {"inline_keyboard": rows}


def settings_inline(state: dict[str, Any]) -> dict[str, Any]:
    from app.services import telegram_sessions as sessions_service

    current = sessions_service.settings_of(state)
    language = sessions_service.language(state)
    fa = language == "fa"

    def tick(value: bool) -> str:
        return "✅" if value else "▫️"

    rows = [
        [
            button(("🇮🇷 فارسی" if current["language"] == "fa" else "🇮🇷 فارسی") + (" ✅" if current["language"] == "fa" else ""), "settings:lang:fa"),
            button("🇬🇧 English" + (" ✅" if current["language"] == "en" else ""), "settings:lang:en"),
        ],
        [
            button(f"{tick(current['show_cost'])} " + ("نمایش هزینه" if fa else "Show cost"), "settings:cost:toggle"),
            button(f"{tick(current['typing_indicator'])} " + ("نشانگر تایپ" if fa else "Typing indicator"), "settings:typing:toggle"),
        ],
        [
            button(f"{tick(current['history_depth'] <= 6)} " + ("حافظهٔ کوتاه" if fa else "Short memory"), "settings:history:short"),
            button(f"{tick(current['history_depth'] > 6)} " + ("حافظهٔ بلند" if fa else "Long memory"), "settings:history:long"),
        ],
        [button("🧭 منو" if fa else "🧭 Menu", "menu:home")],
    ]
    return {"inline_keyboard": rows}


# ------------------------------------------------------------------- texts ----
HELP_SECTIONS = ("commands", "chat", "sessions", "billing")


def help_text(section: str = "main", language: str = "fa") -> str:
    if language == "en":
        blocks = {
            "main": (
                "❓ <b>Help</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "Use the buttons at the bottom of the screen — they are always there.\n"
                "Sections: 💬 Chat · 🧠 Models · 🗂 Sessions · 💳 Account · ⚙️ Settings\n\n"
                "Send any text to talk to the selected model. Everything is charged to your site balance, "
                "exactly like the website.\n\n"
                "دستورهای مهم: /new · /sessions · /switch · /models · /use · /balance · /usage · /status · /menu\n\n"
                "Sections: /help commands · /help chat · /help sessions · /help billing"
            ),
            "commands": (
                "📜 <b>Commands</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "/new [title] — start a new session\n"
                "/sessions — list your sessions (per model)\n"
                "/switch N — make session N active\n"
                "/rename title — rename the active session\n"
                "/close — close the active session\n"
                "/models [page] — model list\n"
                "/use N — select model N\n"
                "/variants · /usev N — sub-models and their system prompts\n"
                "/balance · /usage · /stats — money and usage\n"
                "/settings — language, cost display, memory\n"
                "/export — the transcript of this session\n"
                "/retry — send the last message again\n"
                "/status · /whoami · /menu · /help"
            ),
            "chat": (
                "💬 <b>How to ask</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "1. Pick a model (🧠 Models) — the ticked one is used.\n"
                "2. Type your question as a normal message.\n"
                "3. The answer arrives with its cost; 🔁 Retry sends the same question again.\n\n"
                "Long answers are split automatically. Nothing is executed on the server — code you ask "
                "for is returned as text."
            ),
            "sessions": (
                "🗂 <b>Sessions</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "A session is one conversation with one model, with its own memory. You can keep several "
                "per model: switch with /switch N, rename with /rename, close with /close.\n\n"
                "Every session is also saved on the website under Chat, so you can continue on a computer."
            ),
            "billing": (
                "💳 <b>Costs</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "Each message is charged from your site balance at the catalogue price of the selected "
                "model — the same charge as a message typed on the website. /balance shows what is left, "
                "/usage the last charges, /stats what this bot alone has cost."
            ),
        }
        return blocks.get(section, blocks["main"])

    blocks = {
        "main": (
            "❓ <b>راهنما</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "از دکمه‌های ثابت پایین صفحه استفاده کنید — همیشه آن‌جا هستند.\n"
            "بخش‌ها: 💬 گفتگو · 🧠 مدل‌ها · 🗂 سشن‌ها · 💳 حساب من · ⚙️ تنظیمات\n\n"
            "هر پیام متنی به مدل انتخاب‌شده می‌رود و از اعتبار همان حساب سایت شما کم می‌شود.\n\n"
            "دستورهای مهم: /new · /sessions · /switch · /models · /use · /balance · /usage · /status · /menu\n\n"
            "بخش‌های راهنما: /help commands · /help chat · /help sessions · /help billing"
        ),
        "commands": (
            "📜 <b>دستورها</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "/new [عنوان] — سشن تازه\n"
            "/sessions — فهرست سشن‌ها (به تفکیک مدل)\n"
            "/switch N — فعال کردن سشن شمارهٔ N\n"
            "/rename عنوان — تغییر نام سشن فعال\n"
            "/close — بستن سشن فعال\n"
            "/models [صفحه] — فهرست مدل‌ها\n"
            "/use N — انتخاب مدل شمارهٔ N\n"
            "/variants · /usev N — نسخه‌ها و پرامپت سیستمی هرکدام\n"
            "/balance · /usage · /stats — اعتبار و مصرف\n"
            "/settings — زبان، نمایش هزینه، حافظه\n"
            "/export — خروجی متنی همین سشن\n"
            "/retry — فرستادن دوبارهٔ آخرین پیام\n"
            "/status · /whoami · /menu · /help"
        ),
        "chat": (
            "💬 <b>چطور بپرسیم</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "۱) یک مدل انتخاب کنید (🧠 مدل‌ها) — مدلی که ✅ دارد استفاده می‌شود.\n"
            "۲) سؤال خود را مثل یک پیام معمولی بنویسید.\n"
            "۳) پاسخ همراه هزینه می‌آید؛ با 🔁 تکرار همان سؤال دوباره فرستاده می‌شود.\n\n"
            "پاسخ‌های بلند خودکار تقسیم می‌شوند. هیچ کدی روی سرور اجرا نمی‌شود."
        ),
        "sessions": (
            "🗂 <b>سشن‌ها</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "هر سشن یک گفتگو با یک مدل و حافظهٔ مستقل خودش است. برای هر مدل می‌توانید چند سشن بسازید:\n"
            "با /switch N جابه‌جا شوید، با /rename نام عوض کنید و با /close ببندید.\n\n"
            "همهٔ سشن‌ها در سایت (بخش گفتگو) هم ذخیره می‌شوند، پس می‌توانید روی کامپیوتر ادامه دهید."
        ),
        "billing": (
            "💳 <b>هزینه‌ها</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "هر پیام با قیمت کاتالوگ همان مدل از اعتبار حساب سایت شما کسر می‌شود — دقیقاً مثل ارسال پیام\n"
            "در وب‌سایت. /balance مانده، /usage آخرین مصرف‌ها و /stats هزینهٔ همین ربات را نشان می‌دهد."
        ),
    }
    return blocks.get(section, blocks["main"])


def section_intro(section: str, language: str = "fa") -> str:
    if language == "en":
        return {
            "main": "🧭 <b>Main menu</b>\nUse the buttons below — they stay on screen.",
            "models": "🧠 <b>Models</b>\nThe ticked model answers your messages. Variants are sub-models with their own system prompt.",
            "sessions": "🗂 <b>Sessions</b>\nOne conversation per model, with independent memory.",
            "account": "💳 <b>Account</b>\nBalance, usage and this bot's own statistics.",
            "settings": "⚙️ <b>Settings</b>\nLanguage, cost display and how much memory a session keeps.",
            "help": "❓ <b>Help</b>\nPick a topic.",
            "chat": "💬 <b>Chat</b>\nType your message — or start a fresh session.",
        }.get(section, "🧭")
    return {
        "main": "🧭 <b>منوی اصلی</b>\nاز دکمه‌های پایین استفاده کنید — روی صفحه می‌مانند.",
        "models": "🧠 <b>مدل‌ها</b>\nمدلی که ✅ دارد به پیام‌های شما پاسخ می‌دهد. «نسخه‌ها» زیرمدل‌هایی با پرامپت سیستمی مستقل‌اند.",
        "sessions": "🗂 <b>سشن‌ها</b>\nبرای هر مدل یک گفتگوی مستقل با حافظهٔ جداگانه.",
        "account": "💳 <b>حساب من</b>\nاعتبار، مصرف و آمار همین ربات.",
        "settings": "⚙️ <b>تنظیمات</b>\nزبان، نمایش هزینه و میزان حافظهٔ هر سشن.",
        "help": "❓ <b>راهنما</b>\nیک موضوع را انتخاب کنید.",
        "chat": "💬 <b>گفتگو</b>\nپیام خود را بنویسید — یا یک سشن تازه بسازید.",
    }.get(section, "🧭")
