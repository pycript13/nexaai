"""Telegram bot: linking, welcome, guided commands and real model interaction.

How identity works (and why nothing secret ever travels through Telegram)
------------------------------------------------------------------------
Two supported paths, both stored on ``telegram_links``:

1. **One-time link code (verified).** A signed-in user opens *Profile → Telegram*, asks the site
   for a one-time code, and sends ``/start <code>`` to the bot. The code is short-lived and
   single-use; consuming it proves the human controls both accounts, and the numeric Telegram id is
   stored on their platform account.
2. **Numeric id set in the profile (declared).** The user types their numeric Telegram id in
   *Profile → Telegram*. The bot then accepts that id — which is what the owner asked for: a user
   who registered their number on the site is recognised the moment they press Start. Claims are
   one-to-one (a Telegram id can belong to exactly one account) and are labelled
   ``verified_via="profile"`` so the admin panel and the audit trail never present a declared id as
   a proven one.

From then on every message is resolved through ``telegram_links`` to the platform account, so the
bot acts *as that user*: same permissions, same balance, same rate limits, same model access rules,
same usage history. An id that is **not** registered on the site is refused with instructions — it
can never use somebody else's account.

Nothing is bypassed: a Telegram message runs through ``ai_service.stream_chat`` exactly like a web
request, so it is charged to the same ledger, refused when the balance is empty and recorded in the
same usage table (module ``telegram``).

The bot token itself can be entered in **Admin → Settings → Telegram** (stored encrypted in the
database) or left in ``NEXA_TELEGRAM_BOT_TOKEN``; the database wins, and the polling worker picks a
new token up without a restart.

Transports: long polling (default — works behind NAT, no public URL needed) and webhook (for
production domains). Both call the same handler.
"""
from __future__ import annotations

import copy

import datetime as dt
import html
import math
import json
import secrets
from typing import Any

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy.orm.attributes import flag_modified

from app.core.config import settings
from app.core.errors import NexaError, ValidationError
from app.core.logging import get_logger
from app.db.session import SessionLocal
from app.models.chat import Conversation, Message, MessageRole
from app.models.provider import Model
from app.models.telegram import TelegramLink
from app.models.billing import CreditAccount
from app.models.user import User
from app.services import access as access_service
from app.services import ai as ai_service
from app.services import settings_store
from app.services import telegram_menus as menus
from app.services import telegram_sessions as session_service
from app.services import variants as variant_service

log = get_logger(__name__)

LINK_CODE_TTL_MINUTES = 15
MAX_TELEGRAM_MESSAGE = 4000          # Telegram's own limit is 4096
MODELS_PER_PAGE = 10
BOT_TOKEN_SETTING_KEY = "telegram.bot_token"

#: The bot token most recently seen in the database (or a webhook/test call). Kept in a module
#: variable because every API/DTO helper below is sync and has no ``db`` handle: the polling loop
#: and the admin endpoints refresh it, and `bot_token()` falls back to the environment.
_runtime_token: str = ""

def help_text(section: str = "main", language: str = "fa") -> str:
    """The guide, by topic — the same text the help buttons show."""
    return menus.help_text(section, language)


def welcome_text(*, name: str, model: str, balance: str, verified: str, language: str = "fa",
                 sessions_total: int = 1) -> str:
    """The greeting sent after /start: who they are, what they have, and how to begin.

    It carries the command list because this message *is* the onboarding: the bot must be usable
    without reading any documentation, and the guide is reachable again with /help.
    """
    if language == "en":
        return (
            f"👋 <b>{name}</b>, welcome back!\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "✅ Your site account is connected to this chat.\n"
            f"🧠 Current model: <b>{model}</b>\n"
            f"💳 Balance: <b>{balance}</b> credits\n"
            f"🔐 Verification: {verified}\n"
            f"🗂 Sessions: <b>{sessions_total}</b>\n\n"
            "The buttons at the bottom stay on screen — just type a message to start.\n"
            "Key commands: /new · /sessions · /switch · /models · /use · /balance · /usage · /status · /menu\n"
            "/help explains everything by topic (/help commands · /help chat · /help sessions · /help billing)."
        )
    return (
        f"👋 <b>{name}</b> عزیز، خوش آمدید!\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "✅ حساب سایت شما به این گفتگو وصل است.\n"
        f"🧠 مدل فعلی: <b>{model}</b>\n"
        f"💳 اعتبار: <b>{balance}</b> credits\n"
        f"🔐 نوع تأیید: {verified}\n"
        f"🗂 سشن‌ها: <b>{sessions_total}</b>\n\n"
        "دکمه‌های پایین همیشه روی صفحه می‌مانند؛ برای شروع کافی است پیام بنویسید.\n"
        "دستورهای مهم: /new · /sessions · /switch · /models · /use · /balance · /usage · /status · /menu\n"
        "/help همه چیز را بخش‌به‌بخش توضیح می‌دهد (/help commands · /help chat · /help sessions · /help billing)."
    )


LINK_REQUIRED_TEXT = (
    "🔒 <b>این شناسهٔ تلگرام روی سایت ثبت نشده است</b>\n"
    "━━━━━━━━━━━━━━━━━━━━\n"
    "برای استفاده از ربات، اول باید شمارهٔ عددی تلگرام خودتان را در سایت ثبت کنید:\n\n"
    "۱) وارد سایت شوید → <b>پروفایل</b> → بخش <b>تلگرام</b>\n"
    "۲) شناسهٔ عددی خود را وارد کنید (همین عدد در پیام /whoami برایتان نشان داده می‌شود) یا دکمهٔ\n"
    "   «ساخت کد اتصال» را بزنید و <code>/start &lt;کد&gt;</code> را همین‌جا بفرستید.\n"
    "۳) سپس دوباره <code>/start</code> را بفرستید.\n\n"
    "This Telegram account is not registered on the site yet. Open the site → Profile → Telegram, "
    "save your numeric id (or create a link code and send <code>/start &lt;code&gt;</code>), then send "
    "<code>/start</code> again."
)


# ---------------------------------------------------------------- credentials ----
def refresh_token(db: Session | None = None) -> str:
    """Load the bot token from the settings table (encrypted) or fall back to the environment."""
    global _runtime_token
    if db is not None:
        try:
            stored = settings_store.get_secret(db, BOT_TOKEN_SETTING_KEY)
        except Exception as exc:  # noqa: BLE001 - a broken setting must never kill the bot loop
            log.warning("could not read the stored Telegram token: %s", exc)
            stored = ""
        if stored:
            _runtime_token = stored.strip()
            return _runtime_token
    _runtime_token = ""
    return ""


def api_base() -> str:
    return (settings.telegram_api_base or "https://api.telegram.org").rstrip("/")


def bot_token() -> str:
    return (_runtime_token or settings.telegram_bot_token or "").strip()


def token_source() -> str:
    if _runtime_token:
        return "database"
    if settings.telegram_bot_token:
        return "environment"
    return "none"


def is_configured(db: Session | None = None) -> bool:
    if db is not None:
        refresh_token(db)
    if not bot_token():
        return False
    if db is not None:
        enabled = settings_store.get_value(db, "telegram.enabled", settings.telegram_enabled)
        return bool(enabled)
    return bool(settings.telegram_enabled) or bool(_runtime_token)


def bot_username(db: Session | None = None) -> str:
    if db is not None:
        stored = str(settings_store.get_value(db, "telegram.bot_username", "") or "")
        if stored:
            return stored.lstrip("@")
    return (settings.telegram_bot_username or "").lstrip("@")


async def call_api(method: str, payload: dict[str, Any], *, timeout: float = 40.0) -> dict[str, Any]:
    """Call one Telegram Bot API method. Raises ValidationError with the real reason."""
    if not bot_token():
        raise ValidationError(
            "The Telegram bot token is not configured. Enter it under Admin → Settings → Telegram "
            "(or set NEXA_TELEGRAM_BOT_TOKEN)."
        )
    url = f"{api_base()}/bot{bot_token()}/{method}"
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(url, json=payload)
    except Exception as exc:  # noqa: BLE001
        raise ValidationError(f"Telegram is unreachable: {type(exc).__name__}: {exc}") from exc
    try:
        data = response.json()
    except Exception:  # noqa: BLE001
        raise ValidationError(f"Telegram answered HTTP {response.status_code} with a non-JSON body.") from None
    if not data.get("ok"):
        raise ValidationError(f"Telegram refused {method}: {data.get('description') or data}")
    return data.get("result") or {}


#: Last delivery problem reported by Telegram (chat blocked the bot, chat not found, …). The admin
#: status card shows it so an operator can see *why* nothing arrives instead of guessing.
LAST_DELIVERY_ERROR: dict[str, Any] = {}


def _record_delivery_error(method: str, chat_id: int | str, error: Exception) -> None:
    LAST_DELIVERY_ERROR.clear()
    LAST_DELIVERY_ERROR.update({"method": method, "chat_id": chat_id, "error": str(error)[:300],
                                "at": dt.datetime.now(dt.timezone.utc).isoformat()})
    log.warning("telegram %s to chat %s failed: %s", method, chat_id, error)


async def send_message(
    chat_id: int | str,
    text: str,
    *,
    markdown: bool = True,
    reply_to: int | None = None,
    keyboard: list[list[dict[str, str]]] | None = None,
    reply_keyboard: dict[str, Any] | None = None,
) -> bool:
    """Deliver one message. Returns False when Telegram refuses *this chat*.

    ``keyboard`` is the inline keyboard under the message; ``reply_keyboard`` is the persistent button
    bar above the input field (Telegram keeps it there until it is replaced or removed). Both are sent
    as the Bot API expects them — a raw ``reply_markup`` object.
    """
    payload: dict[str, Any] = {
        "chat_id": chat_id,
        "text": text[:MAX_TELEGRAM_MESSAGE],
        "disable_web_page_preview": True,
    }
    if markdown:
        payload["parse_mode"] = "HTML"
    if reply_to:
        payload["reply_parameters"] = json.dumps({"message_id": reply_to})
    if reply_keyboard is not None:
        payload["reply_markup"] = json.dumps(reply_keyboard)
    elif keyboard is not None:
        payload["reply_markup"] = json.dumps({"inline_keyboard": keyboard})
    try:
        await call_api("sendMessage", payload)
    except NexaError as exc:
        message = str(exc)
        if "not configured" in message or "unreachable" in message:
            raise
        _record_delivery_error("sendMessage", chat_id, exc)
        return False
    LAST_DELIVERY_ERROR.clear()
    return True


async def send_long_message(
    chat_id: int | str,
    text: str,
    *,
    keyboard: list[list[dict[str, str]]] | None = None,
    reply_keyboard: dict[str, Any] | None = None,
) -> int:
    """Send a long text as several messages, cutting on line breaks.

    Telegram refuses anything above 4096 characters. The bot used to truncate silently at 4000, which
    lost the end of a long answer (an export or a long model reply). Splitting keeps everything.
    """
    body = text or ""
    if len(body) <= MAX_TELEGRAM_MESSAGE:
        await send_message(chat_id, body, keyboard=keyboard, reply_keyboard=reply_keyboard)
        return 1
    # The "(1/2)" suffix is appended to every chunk, so a chunk must stop short of the limit by more
    # than the suffix: otherwise the suffix itself is what gets truncated away.
    room = MAX_TELEGRAM_MESSAGE - 32
    chunks: list[str] = []
    remaining = body
    while remaining:
        if len(remaining) <= MAX_TELEGRAM_MESSAGE - 32 and len(chunks) == 0:
            chunks.append(remaining)
            break
        window = remaining[:room]
        cut = window.rfind("\n")
        if cut < room // 2:
            cut = window.rfind(" ")
        if cut <= 0:
            cut = room
        chunks.append(remaining[:cut])
        remaining = remaining[cut:].lstrip("\n")
        if len(remaining) <= MAX_TELEGRAM_MESSAGE - 32:
            chunks.append(remaining)
            break
    for index, chunk in enumerate(chunks, start=1):
        suffix = f"\n\n<i>({index}/{len(chunks)})</i>" if len(chunks) > 1 else ""
        await send_message(
            chat_id,
            chunk + suffix,
            keyboard=keyboard if index == len(chunks) else None,
            reply_keyboard=reply_keyboard if index == len(chunks) else None,
        )
    return len(chunks)


async def edit_message(
    chat_id: int | str, message_id: int, text: str, *, keyboard: list[list[dict[str, str]]] | None = None
) -> bool:
    payload: dict[str, Any] = {"chat_id": chat_id, "message_id": message_id, "text": text[:MAX_TELEGRAM_MESSAGE], "parse_mode": "HTML"}
    if keyboard is not None:
        payload["reply_markup"] = json.dumps({"inline_keyboard": keyboard})
    try:
        await call_api("editMessageText", payload)
    except NexaError as exc:
        message = str(exc)
        if "not configured" in message or "unreachable" in message:
            raise
        # “message is not modified” is the normal answer when a user taps the button they are already
        # on; it is not a failure worth showing anyone.
        if "not modified" not in message:
            _record_delivery_error("editMessageText", chat_id, exc)
        return False
    return True


async def answer_callback(callback_id: str, text: str = "", *, alert: bool = False) -> None:
    try:
        await call_api("answerCallbackQuery", {"callback_query_id": callback_id, "text": text[:180], "show_alert": alert}, timeout=15)
    except NexaError:
        pass


async def send_typing(chat_id: int | str) -> None:
    try:
        await call_api("sendChatAction", {"chat_id": chat_id, "action": "typing"}, timeout=10)
    except NexaError:
        pass


async def get_me() -> dict[str, Any]:
    return await call_api("getMe", {})


async def delete_webhook() -> dict[str, Any]:
    return await call_api("deleteWebhook", {"drop_pending_updates": False})


async def get_webhook_info() -> dict[str, Any]:
    return await call_api("getWebhookInfo", {})


async def set_my_commands() -> dict[str, Any]:
    """Publish the command list so Telegram's own menu button shows a real, current list."""
    commands = [
        {"command": "start", "description": "🏠 شروع / start"},
        {"command": "menu", "description": "🧭 منوی اصلی / main menu"},
        {"command": "new", "description": "🆕 سشن تازه / new session"},
        {"command": "sessions", "description": "🗂 سشن‌ها / sessions"},
        {"command": "switch", "description": "🔀 جابه‌جایی سشن / switch session"},
        {"command": "rename", "description": "✏️ نام سشن / rename session"},
        {"command": "close", "description": "🗑 بستن سشن / close session"},
        {"command": "models", "description": "🧠 مدل‌ها / models"},
        {"command": "use", "description": "🎯 انتخاب مدل / select model"},
        {"command": "variants", "description": "🧩 نسخه‌ها / variants"},
        {"command": "usev", "description": "🧩 انتخاب نسخه / select variant"},
        {"command": "balance", "description": "💳 اعتبار / balance"},
        {"command": "usage", "description": "📊 مصرف / usage"},
        {"command": "stats", "description": "📈 آمار این ربات / bot stats"},
        {"command": "settings", "description": "⚙️ تنظیمات / settings"},
        {"command": "export", "description": "⬇️ خروجی گفتگو / export chat"},
        {"command": "retry", "description": "🔁 تکرار آخرین پیام / retry"},
        {"command": "status", "description": "👤 وضعیت حساب / account"},
        {"command": "whoami", "description": "🔢 شناسهٔ عددی من / my numeric id"},
        {"command": "help", "description": "❓ راهنما / help"},
    ]
    return await call_api("setMyCommands", {"commands": commands})


def _button(text: str, data: str) -> dict[str, str]:
    return {"text": text, "callback_data": data[:64]}


def _url_button(text: str, url: str) -> dict[str, str]:
    return {"text": text, "url": url}


def main_keyboard(db: Session, user: User | None) -> list[list[dict[str, str]]]:
    """Inline actions of the main menu (kept for the message-attached buttons)."""
    return menus.main_inline({}, (settings.public_base_url or "").strip() or None)


def site_url() -> str | None:
    base = (settings.public_base_url or "").strip()
    return base or None


async def open_section(chat_id: int | str, db: Session, user: User, link: TelegramLink, section: str,
                       *, message_id: int | None = None, extra: str = "") -> None:
    """Show a section: its text, its inline actions and its **fixed bottom bar**.

    One entry point for every section keeps the design consistent: the bottom bar always changes to
    the section's buttons (with «بازگشت»), and the message always carries the same inline actions, so
    the same destination is never two different things on two screens.
    """
    state = _state(link)
    language = session_service.language(state)
    text = menus.section_intro(section, language) + (("\n\n" + extra) if extra else "")
    await send_message(
        chat_id,
        text,
        keyboard=menus.main_inline(state, site_url()) if section == "main" else None,
        reply_keyboard=menus.reply_keyboard(section, language),
    )


# ---------------------------------------------------------------- linking -------
def create_link_code(db: Session, *, user: User) -> dict[str, Any]:
    """Create (or refresh) the one-time code the user sends as `/start <code>`."""
    code = f"{secrets.randbelow(1_000_000):06d}{secrets.token_hex(3)}"
    expires_at = dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=LINK_CODE_TTL_MINUTES)
    store = settings_store
    state_key = f"telegram.link_code.{user.id}"
    store.set_value(
        db, state_key, {"code": code, "expires_at": expires_at.isoformat()}, actor=user, commit=False,
    )
    db.commit()
    username = bot_username(db)
    return {
        "code": code,
        "expires_at": expires_at,
        "expires_in_minutes": LINK_CODE_TTL_MINUTES,
        "bot_username": username,
        "deep_link": f"https://t.me/{username}?start={code}" if username else None,
        "instructions": (
            f"Open @{username} in Telegram and send /start {code}" if username
            else f"Open your bot in Telegram and send /start {code}"
        ),
    }


def link_status(db: Session, *, user: User) -> dict[str, Any]:
    link = db.scalars(select(TelegramLink).where(TelegramLink.user_id == user.id)).first()
    pending = settings_store.get_value(db, f"telegram.link_code.{user.id}", {}) or {}
    expires = pending.get("expires_at")
    pending_valid = bool(
        pending.get("code") and expires and dt.datetime.fromisoformat(str(expires)) > dt.datetime.now(dt.timezone.utc)
    )
    return {
        "linked": link is not None,
        "enabled": bool(link.enabled) if link else False,
        "telegram_user_id": link.telegram_user_id if link else None,
        "telegram_username": link.telegram_username if link else None,
        "linked_at": link.linked_at if link else None,
        "last_message_at": link.last_message_at if link else None,
        "message_count": link.message_count if link else 0,
        "verified_via": getattr(link, "verified_via", None) if link else None,
        "numeric_id": link.telegram_user_id if link else None,
        "pending_code": bool(pending_valid),
        "bot_configured": is_configured(db),
        "bot_username": bot_username(db),
        "how_it_works": (
            "Set your numeric Telegram id here (or create a one-time code and send /start <code> to the bot). "
            "The bot only answers Telegram ids that are registered on the site."
        ),
    }


def set_numeric_id(db: Session, *, user: User, telegram_user_id: int) -> dict[str, Any]:
    """Register the numeric Telegram id typed in the profile (declared, not proven).

    The bot then recognises this account the moment the user presses Start. The mapping is
    one-to-one: an id already claimed by another account is refused, so two accounts can never share
    one Telegram identity (and nobody's credits can be spent under somebody else's chat).
    """
    telegram_user_id = int(telegram_user_id)
    if telegram_user_id <= 0 or telegram_user_id > 9_999_999_999_999:
        raise ValidationError("That does not look like a Telegram user id (a positive number such as 123456789).")
    existing = db.scalars(select(TelegramLink).where(TelegramLink.telegram_user_id == telegram_user_id)).first()
    if existing is not None and existing.user_id != user.id:
        raise ValidationError(
            "This Telegram id is already registered on another account. If it is yours, unlink it there first "
            "or contact the administrator."
        )
    link = db.scalars(select(TelegramLink).where(TelegramLink.user_id == user.id)).first()
    if link is not None and link.telegram_user_id and int(link.telegram_user_id) != telegram_user_id:
        # A code-verified link is a *proven* identity. Quietly moving it to a typed-in number would
        # keep the “proven” badge while pointing at an id nobody verified, so the user is asked to
        # unlink first — the badge must always describe reality.
        if getattr(link, "verified_via", None) == "code":
            raise ValidationError(
                "This account is already linked to a Telegram id that was proven with a one-time code: "
                f"{int(link.telegram_user_id)}. Unlink it first if you really want to declare a different id.",
                details={"reason": "code_verified_link", "telegram_user_id": int(link.telegram_user_id)},
            )
    if link is None:
        link = TelegramLink(user_id=user.id, telegram_user_id=telegram_user_id, chat_id=0, enabled=True,
                            verified_via="profile")
        db.add(link)
    else:
        link.telegram_user_id = telegram_user_id
        link.enabled = True
        if getattr(link, "verified_via", None) != "code":
            link.verified_via = "profile"
    db.commit()
    return link_status(db, user=user)


def unlink(db: Session, *, user: User) -> dict[str, Any]:
    link = db.scalars(select(TelegramLink).where(TelegramLink.user_id == user.id)).first()
    if link is not None:
        db.delete(link)
        db.commit()
    return link_status(db, user=user)


def consume_link_code(db: Session, *, code: str, telegram_user_id: int, chat_id: int,
                      username: str | None = None, first_name: str | None = None) -> User | None:
    code = (code or "").strip()
    if not code:
        return None
    rows = db.scalars(select(User)).all()
    match: User | None = None
    for candidate in rows:
        pending = settings_store.get_value(db, f"telegram.link_code.{candidate.id}")
        if isinstance(pending, dict) and pending.get("code") == code:
            expires = pending.get("expires_at")
            if expires and dt.datetime.fromisoformat(str(expires)) < dt.datetime.now(dt.timezone.utc):
                continue
            match = candidate
            break
    if match is None:
        return None
    existing = db.scalars(select(TelegramLink).where(TelegramLink.telegram_user_id == telegram_user_id)).first()
    if existing is not None and existing.user_id != match.id:
        raise ValidationError("This Telegram account is already linked to another user.")
    link = db.scalars(select(TelegramLink).where(TelegramLink.user_id == match.id)).first()
    if link is None:
        link = TelegramLink(user_id=match.id, telegram_user_id=telegram_user_id, chat_id=chat_id,
                            telegram_username=username, telegram_first_name=first_name, enabled=True,
                            verified_via="code")
        db.add(link)
    else:
        link.telegram_user_id = telegram_user_id
        link.chat_id = chat_id
        link.telegram_username = username
        link.telegram_first_name = first_name
        link.enabled = True
        link.verified_via = "code"
    settings_store.set_value(db, f"telegram.link_code.{match.id}", None, actor=match, commit=False)
    db.commit()
    return match


def resolve_user(db: Session, telegram_user_id: int) -> tuple[User | None, TelegramLink | None]:
    link = db.scalars(select(TelegramLink).where(TelegramLink.telegram_user_id == telegram_user_id)).first()
    if link is None or not link.enabled:
        return None, link
    return link.user, link


def _state(link: TelegramLink) -> dict[str, Any]:
    """A **deep** copy of the link state — never a shallow one.

    A shallow copy shares the nested session dictionaries with the object SQLAlchemy loaded, so an
    in-place change (rename a session, activate another one, toggle a setting) made the assigned value
    compare *equal* to the stored one and the UPDATE was skipped: the confirmation message was sent but
    nothing was saved. Deep-copying makes every mutation a genuinely new value.
    """
    return copy.deepcopy(link.state or {})


def _save_state(db: Session, link: TelegramLink, state: dict[str, Any]) -> None:
    link.state = state
    # Belt and braces: even a state that happens to equal the loaded value must be written.
    flag_modified(link, "state")
    db.commit()


def _accessible_models(db: Session, user: User, limit: int | None = None) -> list[Model]:
    """Every model this user may use, in a stable order.

    This used to stop after 12 entries with nothing telling the user that a cap existed:
    a catalogue larger than that simply could not be reached from the bot. The full list
    is returned now and ``/models`` paginates it, always printing the real total.
    """
    rows = db.scalars(access_service.visible_models_query(user).order_by(Model.sort_order, Model.id)).all()
    models = access_service.filter_models_for_user(db, user, list(rows))
    return models[:limit] if limit is not None else models


def _balance_text(db: Session, user: User) -> str:
    from app.services.pricing import micro_to_credits

    account = db.scalars(select(CreditAccount).where(CreditAccount.user_id == user.id)).first()
    if account is None:
        return "0"
    return f"{micro_to_credits(account.balance_micro):,}"


def _conversation_for(db: Session, user: User, model: Model, link: TelegramLink,
                      variant_id: int | None = None) -> tuple[Conversation, dict[str, Any]]:
    """The platform conversation of the active session, creating the session on first use.

    The bot no longer keeps one thread per account: a session is (model + variant + conversation), it
    is listed by /sessions, switchable, renameable, and switching model picks up that model's newest
    session (or starts one) — which is exactly what "sessions per model" means.
    """
    state = _state(link)
    session = session_service.active(state)
    if session is not None and (session.get("model_id") != model.id or session.get("variant_id") != variant_id):
        same = session_service.latest_for_model(state, model.id)
        if same is not None and same.get("variant_id") == variant_id:
            session_service.activate(state, int(same["id"]))
            session = same
        else:
            session = None
    if session is not None:
        conversation = db.get(Conversation, session.get("conversation_id"))
        if conversation is not None and conversation.user_id == user.id:
            _save_state(db, link, state)
            return conversation, session

    conversation = Conversation(
        user_id=user.id,
        title=f"Telegram · {model.display_name}"[:60],
        module="telegram",
        model_id=model.id,
        variant_id=variant_id,
    )
    db.add(conversation)
    db.flush()
    session = session_service.create(
        state,
        model_id=model.id,
        model_name=model.display_name,
        conversation_id=conversation.id,
        variant_id=variant_id,
    )
    _save_state(db, link, state)
    db.commit()
    # A brand-new session changes what the bottom bar should offer (rename/close become meaningful).
    return conversation, session


def _history(db: Session, conversation: Conversation, limit: int = 12) -> list[ai_service.ChatMessage]:
    rows = db.scalars(
        select(Message).where(Message.conversation_id == conversation.id).order_by(Message.id.desc()).limit(limit)
    ).all()
    history: list[ai_service.ChatMessage] = []
    for row in reversed(list(rows)):
        if row.role in (MessageRole.USER, MessageRole.ASSISTANT) and row.content:
            history.append(ai_service.ChatMessage(role=row.role, content=row.content))
    return history


def _verified_label(link: TelegramLink) -> str:
    kind = (getattr(link, "verified_via", "") or "").lower()
    if kind == "code":
        return "✅ کد یک‌بارمصرف / one-time code"
    if kind == "profile":
        return "🔖 ثبت‌شده در پروفایل / registered in the profile"
    return "—"


def _current_model(db: Session, user: User, link: TelegramLink) -> Model | None:
    models = _accessible_models(db, user)
    state = _state(link)
    return next((m for m in models if m.id == state.get("model_id")), models[0] if models else None)


def _set_section(db: Session, link: TelegramLink, section: str) -> None:
    """Remember which section bar the user is on, so answers do not move their buttons."""
    state = _state(link)
    if state.get("section") != section:
        state["section"] = section
        _save_state(db, link, state)


def _section_bar(db: Session, link: TelegramLink) -> dict[str, Any]:
    state = _state(link)
    return menus.reply_keyboard(str(state.get("section") or "chat"), session_service.language(state))


async def _send_menu(chat_id: int | str, db: Session, user: User, link: TelegramLink | None = None) -> None:
    state = _state(link) if link is not None else {}
    language = session_service.language(state)
    if link is not None:
        _set_section(db, link, "main")
    await send_message(
        chat_id,
        menus.section_intro("main", language),
        keyboard=menus.main_inline(state, site_url()),
        reply_keyboard=menus.reply_keyboard("main", language),
    )


async def _send_help(chat_id: int | str, db: Session, link: TelegramLink, section: str = "main") -> None:
    state = _state(link)
    language = session_service.language(state)
    _set_section(db, link, "help")
    await send_message(
        chat_id,
        menus.help_text(section, language),
        keyboard=[[menus.button("🧭 منو" if language == "fa" else "🧭 Menu", "menu:home")]],
        reply_keyboard=menus.reply_keyboard("help", language),
    )


async def _send_models(chat_id: int | str, db: Session, user: User, link: TelegramLink, page: int = 1,
                       *, edit: int | None = None) -> None:
    models = _accessible_models(db, user)
    state = _state(link)
    language = session_service.language(state)
    if not models:
        await send_message(
            chat_id,
            "⚠️ هیچ مدلی برای حساب شما منتشر نشده است / no model is published for your account.",
            reply_keyboard=menus.reply_keyboard("models", language),
        )
        return
    _set_section(db, link, "models")
    keyboard, page, pages = menus.models_inline(models, state, page, MODELS_PER_PAGE, language)
    start = (page - 1) * MODELS_PER_PAGE
    current = (session_service.active(state) or {}).get("model_id") or state.get("model_id")
    lines = ["🧠 <b>مدل‌های در دسترس / available models</b>", "━━━━━━━━━━━━━━━━━━━━"]
    for number, model in enumerate(models[start:start + MODELS_PER_PAGE], start=start + 1):
        mark = "✅" if model.id == current else "▫️"
        lines.append(f"{mark} <b>{number}.</b> {html.escape(model.display_name)} — <code>{html.escape(model.provider_model_id)}</code>")
    lines.append("")
    lines.append(f"📄 صفحه {page} از {pages} · مجموع {len(models)} مدل / page {page} of {pages}, {len(models)} models")
    body = "\n".join(lines)
    if edit:
        await edit_message(chat_id, edit, body, keyboard=keyboard)
        await send_message(chat_id, menus.section_intro("models", language),
                          reply_keyboard=menus.reply_keyboard("models", language))
    else:
        await send_message(chat_id, body, keyboard=keyboard,
                           reply_keyboard=menus.reply_keyboard("models", language))


async def _send_variants(chat_id: int | str, db: Session, user: User, link: TelegramLink,
                         *, edit: int | None = None) -> None:
    state = _state(link)
    language = session_service.language(state)
    model = _current_model(db, user, link)
    if model is None:
        await send_message(chat_id, "⚠️ ابتدا یک مدل انتخاب کنید / select a model first.",
                           reply_keyboard=menus.reply_keyboard("models", language))
        return
    variants = variant_service.list_variants(db, model_id=model.id, actor=user)
    if not variants:
        await send_message(
            chat_id,
            f"ℹ️ برای مدل <b>{html.escape(model.display_name)}</b> نسخه‌ای ثبت نشده است؛ خود مدل استفاده می‌شود.\n"
            "No variant is defined for this model — the raw model is used.",
            reply_keyboard=menus.reply_keyboard("models", language),
        )
        return
    keyboard = menus.variants_inline(variants, state.get("variant_id"), language)
    lines = [f"🧩 <b>نسخه‌های {html.escape(model.display_name)} / variants</b>", "━━━━━━━━━━━━━━━━━━━━"]
    for index, variant in enumerate(variants, start=1):
        mark = "✅" if variant.id == state.get("variant_id") else "▫️"
        lines.append(f"{mark} <b>{index}.</b> {html.escape(variant.name)} — {len(variant.system_prompt or '')} chars")
    body = "\n".join(lines)
    keyboard_rows = keyboard
    if edit:
        await edit_message(chat_id, edit, body, keyboard=keyboard_rows)
    else:
        await send_message(chat_id, body, keyboard=keyboard_rows,
                           reply_keyboard=menus.reply_keyboard("models", language))


async def _send_status(chat_id: int | str, db: Session, user: User, link: TelegramLink) -> None:
    state = _state(link)
    language = session_service.language(state)
    stats = session_service.summary(state)
    active = session_service.active(state)
    model = _current_model(db, user, link)
    from app.services.pricing import micro_to_credits

    lines = ["👤 <b>وضعیت حساب / account status</b>", "━━━━━━━━━━━━━━━━━━━━"]
    lines.append(f"✉️ {html.escape(user.email)}")
    lines.append(f"💳 اعتبار / balance: <b>{_balance_text(db, user)}</b> credits")
    lines.append(f"🧠 مدل / model: <b>{html.escape(model.display_name) if model else '—'}</b>")
    if state.get("variant_id"):
        lines.append(f"🧩 نسخه / variant: <code>{state['variant_id']}</code>")
    lines.append(f"🗂 سشن فعال / active session: <b>{active.get('id') if active else '—'}</b>"
                 f" {html.escape(str(active.get('title') or '')) if active else ''}")
    lines.append(f"📚 سشن‌ها / sessions: <b>{stats['total']}</b> در {stats['models']} مدل · "
                 f"{stats['messages']} پیام")
    lines.append(f"💸 هزینهٔ همین ربات / spent here: <b>{micro_to_credits(stats['charged_micro'])}</b> credits")
    lines.append(f"🔐 تأیید / verification: {_verified_label(link)}")
    lines.append(f"🔢 شناسه / id: <code>{link.telegram_user_id}</code>")
    await send_message(chat_id, "\n".join(lines),
                       keyboard=[[menus.button("🧭 منو" if language == "fa" else "🧭 Menu", "menu:home")]],
                       reply_keyboard=_section_bar(db, link))


async def _send_usage(chat_id: int | str, db: Session, user: User, link: TelegramLink | None = None) -> None:
    """The last charges of this account, and what the bot itself cost."""
    from app.models.billing import UsageRecord
    from app.services.pricing import micro_to_credits

    rows = db.scalars(
        select(UsageRecord).where(UsageRecord.user_id == user.id).order_by(UsageRecord.id.desc()).limit(8)
    ).all()
    language = session_service.language(_state(link)) if link is not None else "fa"
    lines = ["📊 <b>آخرین مصرف‌ها / recent usage</b>", "━━━━━━━━━━━━━━━━━━━━"]
    if not rows:
        lines.append("— هنوز مصرفی ثبت نشده / nothing recorded yet")
    for row in rows:
        when = row.created_at.strftime("%m-%d %H:%M") if getattr(row, "created_at", None) else "—"
        charge = micro_to_credits(row.charged_micro or 0)
        lines.append(f"• {when} · {html.escape(str(row.module or '—'))} · <b>{charge}</b> credits · {html.escape(str(row.status or ''))}")
    await send_message(chat_id, "\n".join(lines),
                       keyboard=[[menus.button("🧭 منو" if language == "fa" else "🧭 Menu", "menu:home")]],
                       reply_keyboard=_section_bar(db, link) if link is not None else None)


async def _send_stats(chat_id: int | str, db: Session, link: TelegramLink) -> None:
    from app.services.pricing import micro_to_credits

    state = _state(link)
    language = session_service.language(state)
    stats = session_service.summary(state)
    by_model: dict[str, int] = {}
    for row in session_service.sessions(state):
        by_model[str(row.get("model_name") or "—")] = by_model.get(str(row.get("model_name") or "—"), 0) + int(row.get("messages") or 0)
    lines = ["📈 <b>آمار این ربات / bot statistics</b>", "━━━━━━━━━━━━━━━━━━━━"]
    lines.append(f"🗂 سشن‌ها / sessions: <b>{stats['total']}</b>")
    lines.append(f"💬 پیام‌ها / messages: <b>{stats['messages']}</b>")
    lines.append(f"🔤 توکن‌ها / tokens: <b>{stats['tokens']:,}</b>")
    lines.append(f"💸 هزینه / cost: <b>{micro_to_credits(stats['charged_micro'])}</b> credits")
    if by_model:
        lines.append("")
        lines.append("🧠 به تفکیک مدل / per model:")
        for name, count in sorted(by_model.items(), key=lambda item: -item[1])[:8]:
            lines.append(f"• {html.escape(name)} — {count} پیام")
    await send_message(chat_id, "\n".join(lines),
                       keyboard=[[menus.button("🧭 منو" if language == "fa" else "🧭 Menu", "menu:home")]],
                       reply_keyboard=_section_bar(db, link))


async def _send_sessions(chat_id: int | str, db: Session, user: User, link: TelegramLink,
                         *, page: int = 1, edit: int | None = None) -> None:
    """List the account's sessions, grouped by model, with the active one ticked."""
    state = _state(link)
    language = session_service.language(state)
    rows = session_service.sessions(state)
    active = session_service.active(state)
    _set_section(db, link, "sessions")
    if not rows:
        await send_message(
            chat_id,
            "🗂 هنوز سشنی ندارید — با «🆕 سشن تازه» یا /new اولین گفتگو را بسازید.\n"
            "No session yet — create one with /new.",
            keyboard=menus.sessions_inline([], None, language),
            reply_keyboard=menus.reply_keyboard("sessions", language),
        )
        return
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        grouped.setdefault(str(row.get("model_name") or "—"), []).append(row)
    lines = ["🗂 <b>سشن‌های شما / your sessions</b>", "━━━━━━━━━━━━━━━━━━━━",
             "برای جابه‌جایی روی دکمه بزنید یا /switch N را بفرستید."]
    for model_name, items in grouped.items():
        lines.append("")
        lines.append(f"🧠 <b>{html.escape(model_name)}</b>")
        for row in items:
            mark = "✅" if active and row.get("id") == active.get("id") else "▫️"
            when = str(row.get("updated_at") or "")[5:16].replace("T", " ")
            lines.append(f"{mark} <b>{row.get('id')}.</b> {html.escape(str(row.get('title') or ''))} "
                         f"<i>({row.get('messages') or 0} پیام · {when})</i>")
    seen: set[int] = set()
    flat: list[dict[str, Any]] = []
    for row in rows:
        if int(row.get("id") or 0) in seen:
            continue
        seen.add(int(row.get("id") or 0))
        flat.append(row)
    keyboard = menus.sessions_inline(flat, (active or {}).get("id"), language, page=page)
    body = "\n".join(lines)
    if edit:
        await edit_message(chat_id, edit, body, keyboard=keyboard)
    else:
        await send_message(chat_id, body, keyboard=keyboard,
                           reply_keyboard=menus.reply_keyboard("sessions", language))


async def _send_settings(chat_id: int | str, db: Session, link: TelegramLink, *, edit: int | None = None) -> None:
    state = _state(link)
    language = session_service.language(state)
    current = session_service.settings_of(state)
    _set_section(db, link, "settings")
    lines = [
        "⚙️ <b>تنظیمات ربات / bot settings</b>",
        "━━━━━━━━━━━━━━━━━━━━",
        f"🌐 زبان / language: <b>{'فارسی' if current['language'] == 'fa' else 'English'}</b>",
        f"💰 نمایش هزینه / show cost: <b>{'روشن' if current['show_cost'] else 'خاموش'}</b>",
        f"⌨️ نشانگر تایپ / typing indicator: <b>{'روشن' if current['typing_indicator'] else 'خاموش'}</b>",
        f"🧠 حافظهٔ هر سشن / memory per session: <b>{current['history_depth']} پیام</b>",
    ]
    keyboard = menus.settings_inline(state)
    body = "\n".join(lines)
    if edit:
        await edit_message(chat_id, edit, body, keyboard=keyboard)
    else:
        await send_message(chat_id, body, keyboard=keyboard,
                           reply_keyboard=menus.reply_keyboard("settings", language))


async def _send_export(chat_id: int | str, db: Session, link: TelegramLink) -> None:
    """The transcript of the active session, as one (split) message."""
    state = _state(link)
    session = session_service.active(state)
    if session is None:
        await send_message(chat_id, "🗂 سشن فعالی وجود ندارد. اول /new را بفرستید.")
        return
    conversation = db.get(Conversation, session.get("conversation_id"))
    if conversation is None:
        await send_message(chat_id, "🗂 این سشن دیگر در دسترس نیست.")
        return
    rows = db.scalars(
        select(Message).where(Message.conversation_id == conversation.id).order_by(Message.id)
    ).all()
    lines = [
        f"⬇️ <b>خروجی سشن {session.get('id')} — {html.escape(str(session.get('title') or ''))}</b>",
        f"🧠 مدل: {html.escape(str(session.get('model_name') or ''))} · 💬 {len(rows)} پیام",
        "━━━━━━━━━━━━━━━━━━━━",
    ]
    for row in rows:
        who = "👤" if str(getattr(row, "role", "")) == "user" else "🤖"
        when = row.created_at.strftime("%Y-%m-%d %H:%M") if getattr(row, "created_at", None) else ""
        body = html.escape((row.content or "").strip())
        lines.append(f"{who} <i>{when}</i>\n{body}\n")
    await send_long_message(chat_id, "\n".join(lines), reply_keyboard=_section_bar(db, link))


def _account_text(db: Session, user: User, link: TelegramLink) -> str:
    from app.services.pricing import micro_to_credits

    stats = session_service.summary(_state(link))
    return (
        "💳 <b>حساب من / my account</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"✉️ {html.escape(user.email)}\n"
        f"💰 اعتبار / balance: <b>{_balance_text(db, user)}</b> credits\n"
        f"📈 هزینهٔ این ربات / spent here: <b>{micro_to_credits(stats['charged_micro'])}</b> credits\n"
        f"🗂 سشن‌ها / sessions: <b>{stats['total']}</b>"
    )


def _numeric_id_help(telegram_user_id: int) -> str:
    return (
        "🔢 <b>شناسهٔ عددی تلگرام شما / your numeric Telegram id</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"<code>{telegram_user_id}</code>\n\n"
        "این عدد را در سایت → <b>پروفایل</b> → بخش <b>تلگرام</b> ذخیره کنید تا ربات همیشه شما را بشناسد.\n"
        "Save this number on the site → Profile → Telegram so the bot always recognises you."
    )


# ---------------------------------------------------------------- the handler -----
# ---------------------------------------------------------------- the handler -----
async def _send_welcome(db: Session, *, user: User, link: TelegramLink, chat_id: int | str,
                        name: str | None = None, extra: str = "") -> None:
    """Greet a linked account: who they are, what they have, and how to start."""
    state = _state(link)
    language = session_service.language(state)
    model = _current_model(db, user, link)
    stats = session_service.summary(state)
    display = (name or getattr(user, "display_name", None) or getattr(user, "email", "") or "کاربر").strip()
    text = welcome_text(
        name=html.escape(display),
        model=html.escape(model.display_name) if model else "—",
        balance=_balance_text(db, user),
        verified=_verified_label(link),
        language=language,
        sessions_total=stats["total"],
    )
    if model is None:
        text += "\n\n⚠️ برای حساب شما هیچ مدلی منتشر نشده است؛ با مدیر تماس بگیرید."
    if extra:
        text += "\n\n" + extra
    _set_section(db, link, "chat")
    await send_message(
        chat_id,
        text,
        keyboard=menus.main_inline(state, site_url()),
        reply_keyboard=menus.reply_keyboard("chat", language),
    )


def _variant_for(db: Session, user: User, model: Model, link: TelegramLink):
    """The variant the user picked, or ``None`` (dropping a stale selection instead of failing)."""
    state = _state(link)
    variant_id = state.get("variant_id")
    if not variant_id:
        return None
    try:
        return variant_service.resolve_for_request(db, model=model, user=user, variant_id=variant_id)
    except ValidationError:
        state.pop("variant_id", None)
        _save_state(db, link, state)
        return None


async def _perform_new_session(db: Session, *, user: User, link: TelegramLink, chat_id: int | str,
                               title: str | None = None) -> str:
    """Start a fresh conversation with the current model — a real, independent session."""
    models = _accessible_models(db, user)
    state = _state(link)
    language = session_service.language(state)
    if not models:
        await send_message(chat_id, "⚠️ هیچ مدلی برای حساب شما منتشر نشده است. / no model published.",
                           reply_keyboard=menus.reply_keyboard("chat", language))
        return "no_model"
    model = _current_model(db, user, link) or models[0]
    variant = _variant_for(db, user, model, link)
    state.pop(session_service.ACTIVE_KEY, None)
    state.pop("conversation_id", None)
    _save_state(db, link, state)
    conversation, session = _conversation_for(db, user, model, link,
                                              variant_id=variant.id if variant else None)
    if title:
        state = _state(link)
        session_service.rename(state, int(session["id"]), title)
        _save_state(db, link, state)
        session = session_service.find(_state(link), int(session["id"])) or session
    _set_section(db, link, "chat")
    notice = (
        f"🆕 <b>سشن {session['id']} ساخته شد</b> — «{html.escape(str(session.get('title') or ''))}»\n"
        f"🧠 مدل: <b>{html.escape(model.display_name)}</b>"
        + (f" · 🧩 نسخه: {html.escape(variant.name)}" if variant else "")
        + "\nحافظهٔ این سشن از صفر شروع می‌شود؛ بقیهٔ سشن‌ها دست‌نخورده می‌مانند."
        if language == "fa" else
        f"🆕 <b>Session {session['id']} created</b> — “{html.escape(str(session.get('title') or ''))}”\n"
        f"🧠 Model: <b>{html.escape(model.display_name)}</b>"
        + (f" · 🧩 Variant: {html.escape(variant.name)}" if variant else "")
        + "\nThis session starts with an empty memory; your other sessions are untouched."
    )
    await send_message(chat_id, notice, reply_keyboard=menus.reply_keyboard("chat", language))
    return "session_created"


async def _activate_session(db: Session, *, user: User, link: TelegramLink, chat_id: int | str,
                            session_id: int, quiet: bool = False) -> str:
    """Make session ``session_id`` active (and follow it to its model)."""
    state = _state(link)
    language = session_service.language(state)
    row = session_service.find(state, session_id)
    if row is None:
        await send_message(chat_id, f"⚠️ سشن {session_id} پیدا نشد. /sessions → no such session.",
                           reply_keyboard=_section_bar(db, link))
        return "session_missing"
    session_service.activate(state, session_id)
    _save_state(db, link, state)
    _set_section(db, link, "chat")
    if quiet:
        return "session_switched"
    model = db.get(Model, row.get("model_id")) if row.get("model_id") else None
    await send_message(
        chat_id,
        (f"🔀 <b>سشن فعال: {session_id}</b> — «{html.escape(str(row.get('title') or ''))}»"
         f"\n🧠 مدل: <b>{html.escape(model.display_name) if model else '—'}</b> · "
         f"💬 {int(row.get('messages') or 0)} پیام\nاز اینجا به بعد پیام‌ها به همین سشن می‌روند."
         if language == "fa" else
         f"🔀 <b>Active session: {session_id}</b> — “{html.escape(str(row.get('title') or ''))}”"
         f"\n🧠 Model: <b>{html.escape(model.display_name) if model else '—'}</b> · "
         f"💬 {int(row.get('messages') or 0)} messages\nNew messages go to this session."),
        reply_keyboard=menus.reply_keyboard("chat", language),
    )
    return "session_switched"


async def _close_session(db: Session, *, link: TelegramLink, chat_id: int | str,
                         session_id: int | None = None) -> str:
    state = _state(link)
    language = session_service.language(state)
    target = session_service.find(state, session_id) if session_id else session_service.active(state)
    if target is None:
        await send_message(chat_id, "🗂 سشن فعالی وجود ندارد. / no active session.",
                           reply_keyboard=_section_bar(db, link))
        return "session_missing"
    session_service.remove(state, int(target["id"]))
    _save_state(db, link, state)
    nxt = session_service.active(state)
    await send_message(
        chat_id,
        (f"🗑 <b>سشن {target['id']} بسته شد</b> — «{html.escape(str(target.get('title') or ''))}»\n"
         + (f"سشن فعال اکنون <b>{nxt['id']}</b> است. / now active: {nxt['id']}." if nxt
            else "برای ادامه یک سشن تازه بسازید: /new"))
        if language == "fa" else
        (f"🗑 <b>Session {target['id']} closed</b> — “{html.escape(str(target.get('title') or ''))}”\n"
         + (f"The active session is now <b>{nxt['id']}</b>." if nxt else "Start a new one with /new.")),
        reply_keyboard=menus.reply_keyboard("chat", language),
    )
    return "session_closed"


async def _rename_session(db: Session, *, link: TelegramLink, chat_id: int | str,
                          title: str) -> str:
    state = _state(link)
    language = session_service.language(state)
    row = session_service.active(state)
    if row is None:
        await send_message(chat_id, "🗂 اول یک سشن بسازید. / no active session.",
                           reply_keyboard=_section_bar(db, link))
        return "session_missing"
    if not title.strip():
        await send_message(chat_id, "✏️ نام را بنویسید، مثلاً: <code>/rename گزارش فروش</code>")
        return "rename_needs_title"
    session_service.rename(state, int(row["id"]), title)
    _save_state(db, link, state)
    await send_message(
        chat_id,
        f"✏️ <b>سشن {row['id']}</b> اکنون «{html.escape(title.strip()[:80])}» نام دارد."
        if language == "fa" else
        f"✏️ <b>Session {row['id']}</b> is now called “{html.escape(title.strip()[:80])}”.",
        reply_keyboard=_section_bar(db, link),
    )
    return "session_renamed"


async def _handle_command(db: Session, *, user: User, link: TelegramLink, chat_id: int | str,
                          command: str, argument: str) -> str:
    """One place for every slash command, so the set of commands and the help text never drift."""
    state = _state(link)
    language = session_service.language(state)
    if command == "/start":
        # The greeting is the onboarding: it carries the balance, the model, the sessions and the
        # command list. /menu is the plain section menu.
        await _send_welcome(db, user=user, link=link, chat_id=chat_id)
        return "welcome"
    if command == "/menu":
        await _send_menu(chat_id, db, user, link)
        return "menu"
    if command == "/help":
        topic = argument.lower() if argument.lower() in menus.HELP_SECTIONS else "main"
        await _send_help(chat_id, db, link, topic)
        return "help"
    if command == "/models":
        page = int(argument) if argument.isdigit() else 1
        await _send_models(chat_id, db, user, link, page)
        return "models"
    if command == "/use":
        return await _select_model(db, user=user, link=link, chat_id=chat_id, argument=argument)
    if command == "/variants":
        await _send_variants(chat_id, db, user, link)
        return "variants"
    if command == "/usev":
        return await _select_variant(db, user=user, link=link, chat_id=chat_id, argument=argument)
    if command == "/new":
        return await _perform_new_session(db, user=user, link=link, chat_id=chat_id,
                                          title=argument if argument else None)
    if command == "/sessions":
        await _send_sessions(chat_id, db, user, link)
        return "sessions"
    if command == "/switch":
        if not argument.isdigit():
            await send_message(chat_id, "🔀 شمارهٔ سشن را بنویسید، مثلاً <code>/switch 2</code>\n"
                                        "Send the session number, e.g. <code>/switch 2</code>",
                               reply_keyboard=_section_bar(db, link))
            return "switch_needs_number"
        return await _activate_session(db, user=user, link=link, chat_id=chat_id,
                                       session_id=int(argument))
    if command == "/rename":
        return await _rename_session(db, link=link, chat_id=chat_id, title=argument)
    if command == "/close":
        session_id = int(argument) if argument.isdigit() else None
        return await _close_session(db, link=link, chat_id=chat_id, session_id=session_id)
    if command == "/stats":
        await _send_stats(chat_id, db, link)
        return "stats"
    if command == "/settings":
        await _send_settings(chat_id, db, link)
        return "settings"
    if command == "/export":
        await _send_export(chat_id, db, link)
        return "export"
    if command == "/retry":
        prompt = str(_state(link).get("last_prompt") or "").strip()
        if not prompt:
            await send_message(chat_id, "🔁 پیامی برای تکرار ذخیره نشده است. / nothing to retry yet.",
                               reply_keyboard=_section_bar(db, link))
            return "nothing_to_retry"
        return await _run_chat(db, user=user, link=link, chat_id=chat_id, text=prompt)
    if command == "/balance":
        await send_message(
            chat_id,
            f"💳 اعتبار شما: <b>{_balance_text(db, user)}</b> credits\n"
            "برای افزایش اعتبار از سایت → کیف پول استفاده کنید.\n"
            f"Balance: <b>{_balance_text(db, user)}</b> credits — top up in the site's wallet.",
            keyboard=[[menus.button("🧭 منو" if language == "fa" else "🧭 Menu", "menu:home")]],
            reply_keyboard=_section_bar(db, link),
        )
        return "balance"
    if command == "/usage":
        await _send_usage(chat_id, db, user, link)
        return "usage"
    if command == "/status":
        await _send_status(chat_id, db, user, link)
        return "status"
    if command == "/whoami":
        await send_message(chat_id, _numeric_id_help(link.telegram_user_id),
                           reply_keyboard=_section_bar(db, link))
        return "whoami"
    await send_message(
        chat_id,
        f"❓ دستور «{html.escape(command)}» را نمی‌شناسم. /help راهنما را نشان می‌دهد.\n"
        f"Unknown command “{html.escape(command)}” — /help lists everything.",
        reply_keyboard=_section_bar(db, link),
    )
    return "unknown_command"


async def _select_model(db: Session, *, user: User, link: TelegramLink, chat_id: int | str,
                        argument: str) -> str:
    """Choose a model from its number in /models; the model's newest session is picked up."""
    state = _state(link)
    language = session_service.language(state)
    models = _accessible_models(db, user)
    if not argument.isdigit():
        await send_message(chat_id, "🎯 شمارهٔ مدل را بنویسید، مثلاً <code>/use 3</code>\n"
                                    "Send the model number, e.g. <code>/use 3</code>",
                           reply_keyboard=menus.reply_keyboard("models", language))
        return "use_needs_number"
    index = int(argument)
    if not 1 <= index <= len(models):
        await send_message(chat_id, f"⚠️ شمارهٔ مدل نامعتبر است؛ باید بین ۱ و {len(models)} باشد. /models\n"
                                    f"Invalid model number — it must be between 1 and {len(models)}.",
                           reply_keyboard=menus.reply_keyboard("models", language))
        return "model_out_of_range"
    model = models[index - 1]
    state = _state(link)
    state["model_id"] = model.id
    state["use_index"] = index
    _save_state(db, link, state)
    session = session_service.latest_for_model(_state(link), model.id)
    if session is not None:
        await _activate_session(db, user=user, link=link, chat_id=chat_id,
                                session_id=int(session["id"]))
        return "model_selected"
    await send_message(
        chat_id,
        (f"✅ مدل انتخابی: <b>{html.escape(model.display_name)}</b>\n"
         f"🆕 سشن فعالی برای این مدل نبود؛ اولین پیام شما یک سشن تازه با همین مدل می‌سازد.\n"
         f"می‌توانید با /new هم از ابتدا شروع کنید.")
        if language == "fa" else
        (f"✅ Selected model: <b>{html.escape(model.display_name)}</b>\n"
         f"No session existed for this model — your next message starts one. /new also works."),
        reply_keyboard=menus.reply_keyboard("chat", language),
    )
    return "model_selected"


async def _select_variant(db: Session, *, user: User, link: TelegramLink, chat_id: int | str,
                          argument: str) -> str:
    state = _state(link)
    language = session_service.language(state)
    model = _current_model(db, user, link)
    if model is None:
        await send_message(chat_id, "⚠️ اول یک مدل انتخاب کنید. / select a model first.",
                           reply_keyboard=menus.reply_keyboard("models", language))
        return "no_model"
    variants = variant_service.list_variants(db, model_id=model.id, actor=user)
    if not argument.isdigit():
        await send_message(chat_id, "🧩 شمارهٔ نسخه را بنویسید (۰ = مدل خام)، مثلاً <code>/usev 1</code>")
        return "usev_needs_number"
    index = int(argument)
    state = _state(link)
    if index == 0:
        state.pop("variant_id", None)
        _save_state(db, link, state)
        await send_message(chat_id, f"🧩 از این پس <b>{html.escape(model.display_name)}</b> خام استفاده می‌شود.",
                           reply_keyboard=_section_bar(db, link))
        return "variant_selected"
    if not 1 <= index <= len(variants):
        await send_message(chat_id, f"⚠️ شمارهٔ نسخهٔ نامعتبر است؛ باید بین ۰ و {len(variants)} باشد. /variants")
        return "variant_out_of_range"
    variant = variants[index - 1]
    state["variant_id"] = variant.id
    _save_state(db, link, state)
    await send_message(
        chat_id,
        f"🧩 نسخهٔ انتخابی: <b>{html.escape(variant.name)}</b> روی مدل "
        f"<b>{html.escape(model.display_name)}</b>\n"
        f"<i>{html.escape((variant.system_prompt or '')[:200])}</i>",
        reply_keyboard=_section_bar(db, link),
    )
    return "variant_selected"




#: ``menus.LABEL_ACTIONS`` yields the bare action of a bottom-bar button (``"models_list"``, …); the
#: inline keyboards speak in ``group:value`` callback data. One table maps the first onto the second so
#: a tap and a callback land on exactly the same code path.
_ACTION_ALIASES: dict[str, str] = {
    "chat": "menu:home",
    "chat_new": "menu:new",
    "chat_retry": "chat:retry",
    "models": "menu:models",
    "models_list": "menu:models",
    "model_current": "menu:model_current",
    "variants": "menu:variants",
    "sessions": "menu:sessions",
    "sessions_list": "menu:sessions",
    "session_new": "menu:new",
    "session_close": "session:close",
    "session_rename": "menu:rename_hint",
    "account": "menu:account",
    "balance": "menu:balance",
    "usage": "menu:usage",
    "stats": "menu:stats",
    "status": "menu:status",
    "whoami": "menu:whoami",
    "export": "menu:export",
    "settings": "menu:settings",
    "lang_fa": "session:lang:fa",
    "lang_en": "session:lang:en",
    "toggle_cost": "session:toggle:cost",
    "toggle_typing": "session:toggle:typing",
    "history_short": "session:history:short",
    "history_long": "session:history:long",
    "help": "menu:help",
    "help_commands": "help:commands",
    "help_chat": "help:chat",
    "help_sessions": "help:sessions",
    "help_billing": "help:billing",
    "back": "menu:home",
}


async def _handle_reply_action(db: Session, *, user: User, link: TelegramLink, chat_id: int | str,
                               action: str, argument: str = "") -> str:
    """A tap on one of the fixed bottom buttons (or an inline action routed to the same code)."""
    state = _state(link)
    action = _ACTION_ALIASES.get(action, action)
    state = _state(link)
    language = session_service.language(state)
    if action == "menu:home":
        await _send_menu(chat_id, db, user, link)
        return "menu"
    if action == "menu:models":
        _set_section(db, link, "models")
        await _send_models(chat_id, db, user, link)
        return "models"
    if action == "menu:sessions":
        await _send_sessions(chat_id, db, user, link)
        return "sessions"
    if action == "menu:account":
        _set_section(db, link, "account")
        await send_message(chat_id, _account_text(db, user, link),
                           keyboard=[[menus.button("📊 مصرف / Usage", "menu:usage"),
                                      menus.button("📈 آمار ربات / Bot stats", "menu:stats")],
                                     [menus.button("🧭 منو" if language == "fa" else "🧭 Menu", "menu:home")]],
                           reply_keyboard=menus.reply_keyboard("account", language))
        return "account"
    if action == "menu:balance":
        return await _handle_command(db, user=user, link=link, chat_id=chat_id,
                                     command="/balance", argument="")
    if action == "menu:usage":
        _set_section(db, link, "account")
        await _send_usage(chat_id, db, user, link)
        return "usage"
    if action == "menu:stats":
        _set_section(db, link, "account")
        await _send_stats(chat_id, db, link)
        return "stats"
    if action == "menu:status":
        await _send_status(chat_id, db, user, link)
        return "status"
    if action == "menu:settings":
        await _send_settings(chat_id, db, link)
        return "settings"
    if action == "menu:help":
        await _send_help(chat_id, db, link)
        return "help"
    if action == "menu:new":
        return await _perform_new_session(db, user=user, link=link, chat_id=chat_id)
    if action == "menu:model_current":
        model = _current_model(db, user, link)
        state = _state(link)
        variant_id = state.get("variant_id")
        variants = variant_service.list_variants(db, model_id=model.id, actor=user) if model else []
        chosen = next((v for v in variants if v.id == variant_id), None)
        await send_message(
            chat_id,
            ("🎯 <b>مدل فعلی</b>\n"
             f"🧠 <b>{html.escape(model.display_name)}</b>\n"
             f"🧩 نسخه: <b>{html.escape(chosen.name) if chosen else 'مدل خام'}</b>\n"
             f"🗂 سشن فعال: <b>{(session_service.active(state) or {}).get('id') or '—'}</b>"
             + ("\n\nبرای تغییر مدل: «🧠 مدل‌ها» یا /models" if language == "fa" else
                "\n\nTo change it: “🧠 Models” or /models"))
            if language == "fa" else
            ("🎯 <b>Current model</b>\n"
             f"🧠 <b>{html.escape(model.display_name) if model else '—'}</b>\n"
             f"🧩 Variant: <b>{html.escape(chosen.name) if chosen else 'raw model'}</b>\n"
             f"🗂 Active session: <b>{(session_service.active(state) or {}).get('id') or '—'}</b>"
             "\n\nTo change it: “🧠 Models” or /models"),
            reply_keyboard=_section_bar(db, link),
        )
        return "model_current"
    if action == "menu:rename_hint":
        await send_message(chat_id, "✏️ نام تازه را بعد از دستور بنویسید: <code>/rename نام تازه</code>")
        return "rename_hint"
    if action == "menu:variants":
        await _send_variants(chat_id, db, user, link)
        return "variants"
    if action == "menu:export":
        await _send_export(chat_id, db, link)
        return "export"
    if action == "menu:whoami":
        await send_message(chat_id, _numeric_id_help(link.telegram_user_id),
                           reply_keyboard=_section_bar(db, link))
        return "whoami"
    if action == "session:sessions":
        return await _handle_reply_action(db, user=user, link=link, chat_id=chat_id,
                                         action="menu:sessions")
    if action == "session:new":
        return await _perform_new_session(db, user=user, link=link, chat_id=chat_id)
    if action == "session:switch":
        if argument.isdigit():
            return await _activate_session(db, user=user, link=link, chat_id=chat_id,
                                           session_id=int(argument))
        await _send_sessions(chat_id, db, user, link)
        return "sessions"
    if action == "session:rename":
        await send_message(chat_id, "✏️ نام تازه را بعد از دستور بنویسید: <code>/rename نام تازه</code>")
        return "rename_hint"
    if action == "session:close":
        return await _close_session(db, link=link, chat_id=chat_id)
    if action == "session:export":
        await _send_export(chat_id, db, link)
        return "export"
    if action == "chat:retry":
        return await _handle_command(db, user=user, link=link, chat_id=chat_id,
                                     command="/retry", argument="")
    if action == "chat:new":
        return await _perform_new_session(db, user=user, link=link, chat_id=chat_id)
    if action == "chat:models":
        return await _handle_reply_action(db, user=user, link=link, chat_id=chat_id,
                                         action="menu:models")
    if action.startswith("session:lang:") or action.startswith("settings:lang:"):
        code = action.rsplit(":", 1)[1]
        session_service.update_settings(state, language="fa" if code == "fa" else "en")
        _save_state(db, link, state)
        await _send_settings(chat_id, db, link)
        return "settings"
    if action in ("session:toggle:cost", "settings:cost:toggle"):
        session_service.update_settings(state, show_cost=not session_service.settings_of(state)["show_cost"])
        _save_state(db, link, state)
        await _send_settings(chat_id, db, link)
        return "settings"
    if action in ("session:toggle:typing", "settings:typing:toggle"):
        session_service.update_settings(state, typing_indicator=not session_service.settings_of(state)["typing_indicator"])
        _save_state(db, link, state)
        await _send_settings(chat_id, db, link)
        return "settings"
    if action.startswith("session:history:") or action.startswith("settings:history:"):
        depth = 24 if action.endswith("long") else 6
        session_service.update_settings(state, history_depth=depth)
        _save_state(db, link, state)
        await _send_settings(chat_id, db, link)
        return "settings"
    if action.startswith("help:"):
        await _send_help(chat_id, db, link, action.split(":", 1)[1])
        return "help"
    if action.startswith("models:"):
        page = int(action.split(":", 1)[1]) if action.split(":", 1)[1].isdigit() else 1
        await _send_models(chat_id, db, user, link, page)
        return "models"
    if action.startswith("model:"):
        return await _select_model(db, user=user, link=link, chat_id=chat_id,
                                   argument=action.split(":", 1)[1])
    if action.startswith("variant:"):
        return await _select_variant(db, user=user, link=link, chat_id=chat_id,
                                     argument=action.split(":", 1)[1])
    if action.startswith("sessions:page:"):
        number = action.rsplit(":", 1)[1]
        await _send_sessions(chat_id, db, user, link, page=int(number) if number.isdigit() else 1)
        return "sessions"
    if action.startswith("session:") and action.split(":", 1)[1].isdigit():
        return await _activate_session(db, user=user, link=link, chat_id=chat_id,
                                       session_id=int(action.split(":", 1)[1]))
    return "unknown_action"


async def handle_message(db: Session, update: dict[str, Any]) -> str:
    """A Telegram message: greet, navigate, or run one chat turn as the linked platform user."""
    message = update.get("message") or update.get("edited_message") or {}
    chat = message.get("chat") or {}
    chat_id = chat.get("id")
    text = (message.get("text") or "").strip()
    sender = message.get("from") or {}
    telegram_user_id = sender.get("id")
    if chat_id is None or telegram_user_id is None:
        return "ignored"
    if str(chat.get("type") or "private") != "private":
        await send_message(chat_id, "ℹ️ این ربات فقط در گفتگوی خصوصی کار می‌کند. / private chats only.")
        return "group_ignored"

    user, link = resolve_user(db, telegram_user_id)
    if user is None or link is None:
        return await _handle_unlinked(db, chat_id=chat_id, telegram_user_id=telegram_user_id,
                                      sender=sender, text=text)

    if not text:
        language = session_service.language(_state(link))
        await send_message(
            chat_id,
            "✍️ پیام متنی بفرستید یا از دکمه‌های پایین استفاده کنید. / send a text message."
            if language == "en" else
            "✍️ متن پیام را بنویسید یا از دکمه‌های پایین استفاده کنید.",
            reply_keyboard=_section_bar(db, link),
        )
        return "empty"

    if text.startswith("/"):
        head, _, tail = text.partition(" ")
        command = head.split("@")[0].strip().lower()
        named = _COMMAND_ALIASES.get(command)
        if named is not None:
            return await _handle_reply_action(db, user=user, link=link, chat_id=chat_id,
                                              action=named, argument=tail.strip())
        return await _handle_command(db, user=user, link=link, chat_id=chat_id,
                                     command=command, argument=tail.strip())

    tapped = menus.action_for_label(text)
    if tapped is not None:
        return await _handle_reply_action(db, user=user, link=link, chat_id=chat_id,
                                          action=tapped[0], argument="")

    return await _run_chat(db, user=user, link=link, chat_id=chat_id, text=text)


#: The reply-keyboard labels double as commands, so a tap and a typed line land on the same code.
_COMMAND_ALIASES: dict[str, str] = {
    "/chat": "menu:home",
    "/account": "menu:account",
    "/botstats": "menu:stats",
    "/variant": "menu:variants",
    "/welcome": "menu:home",
    "/hint": "menu:help",
}


def _looks_like_code(value: str) -> bool:
    """A one-time code is a single ASCII token — never an ordinary sentence."""
    token = (value or "").strip()
    if not 4 <= len(token) <= 64 or not token.isascii() or " " in token:
        return False
    return all(character.isalnum() or character in "-_" for character in token)


async def _handle_unlinked(db: Session, *, chat_id: int | str, telegram_user_id: int,
                           sender: dict[str, Any], text: str) -> str:
    """Someone the site does not know: explain how to connect, and accept a one-time code."""
    raw = (text or "").strip()
    head, _, tail = raw.partition(" ")
    command = head.split("@")[0].lower()
    payload = ""
    if command in ("/start", "/link"):
        payload = tail.strip()
    elif not raw.startswith("/") and _looks_like_code(raw):
        # People copy the code and send it on its own at least as often as the deep link.
        payload = raw
    if payload:
        try:
            linked_user = consume_link_code(
                db,
                code=payload,
                telegram_user_id=telegram_user_id,
                chat_id=chat_id,
                username=sender.get("username"),
                first_name=sender.get("first_name"),
            )
        except ValidationError as exc:
            await send_message(chat_id, f"⚠️ {html.escape(str(exc.detail))}\n\n"
                                        + _numeric_id_help(telegram_user_id))
            return "bad_link_code"
        if linked_user is not None:
            user, link = resolve_user(db, telegram_user_id)
            if user is not None and link is not None:
                await _send_welcome(db, user=user, link=link, chat_id=chat_id,
                                    name=sender.get("first_name"),
                                    extra="🔗 اتصال شما با کد یک‌بارمصرف تأیید شد. / linked with a one-time code.")
            return "linked"
        await send_message(chat_id, "⚠️ این کد نامعتبر یا منقضی است. یک کد تازه از سایت بگیرید.\n"
                                    "The code is invalid or expired — create a new one on the site.")
        return "bad_link_code"
    if command == "/whoami":
        await send_message(chat_id, _numeric_id_help(telegram_user_id))
        return "whoami_unlinked"
    if command in ("/start", "/menu", "/help"):
        await send_message(chat_id, LINK_REQUIRED_TEXT)
        return "unlinked"
    await send_message(chat_id, LINK_REQUIRED_TEXT)
    return "unlinked"


async def _run_chat(db: Session, *, user: User, link: TelegramLink, chat_id: int | str, text: str) -> str:
    """One chat turn inside the active session, charged to the account like the website."""
    models = _accessible_models(db, user)
    if not models:
        await send_message(chat_id, "⚠️ برای حساب شما مدلی منتشر نشده است. با مدیر تماس بگیرید.\n"
                                    "No model is published for your account — contact the administrator.")
        return "no_model"
    state = _state(link)
    language = session_service.language(state)
    settings_now = session_service.settings_of(state)
    model = next((m for m in models if m.id == state.get("model_id")), None)
    if model is None:
        model = models[0]
        state["model_id"] = model.id
        _save_state(db, link, state)
    variant = _variant_for(db, user, model, link)
    variant_id = variant.id if variant else None
    conversation, session = _conversation_for(db, user, model, link, variant_id=variant_id)
    if variant is not None and conversation.variant_id != variant.id:
        conversation.variant_id = variant.id
    state = _state(link)
    if session_service.maybe_autotitle(state, int(session["id"]), text):
        _save_state(db, link, state)

    if settings_now["typing_indicator"]:
        await send_typing(chat_id)
    try:
        ref = ai_service.resolve_model(db, user=user, model_id=model.id, operation="chat")
    except NexaError as exc:
        # Log *why* a message was refused (model, reason, balance): an operator reading the log should
        # never have to guess which model the bot picked for a user.
        log.info(
            "telegram: model %s (%s) refused for user %s: %s",
            model.id, model.provider_model_id, user.id, exc,
        )
        await send_message(chat_id, f"⛔️ {html.escape(exc.detail)}", reply_keyboard=_section_bar(db, link))
        return "not_allowed"

    user_message = Message(
        conversation_id=conversation.id,
        user_id=user.id,
        role=MessageRole.USER,
        content=text,
        model_id=model.id,
    )
    db.add(user_message)
    db.flush()

    answer_parts: list[str] = []
    charged_micro = 0
    tokens = 0
    error_note = ""
    async for event in ai_service.stream_chat(
        db,
        user=user,
        model_ref=ref,
        messages=_history(db, conversation, limit=int(settings_now["history_depth"]))
        or [ai_service.ChatMessage(role="user", content=text)],
        system=variant_service.system_prompt_for(variant),
        temperature=float(variant.default_temperature) if variant and variant.default_temperature is not None else None,
        max_tokens=variant.default_max_tokens if variant else None,
        module="telegram",
        conversation_id=conversation.id,
        variant_id=variant_id,
        idempotency_key=f"telegram:{user_message.id}",
    ):
        if event.type == "delta":
            answer_parts.append(event.data.get("text", ""))
        elif event.type == "done":
            charged_micro = int(event.data.get("charged_micro") or 0)
            tokens = int(event.data.get("total_tokens") or event.data.get("tokens") or 0)
        elif event.type == "error":
            error_note = event.data.get("message") or "provider failure"

    answer = "".join(answer_parts).strip()
    assistant = Message(
        conversation_id=conversation.id,
        user_id=user.id,
        role=MessageRole.ASSISTANT,
        content=answer,
        model_id=model.id,
        error_category=None if answer else error_note or "unknown",
    )
    db.add(assistant)
    conversation.message_count = (conversation.message_count or 0) + 1
    db.commit()

    state = _state(link)
    state["last_prompt"] = text[:1000]
    if session is not None:
        session_service.touch(state, int(session["id"]), messages=2, tokens=tokens,
                              charged_micro=charged_micro)
    _save_state(db, link, state)

    if not answer:
        await send_message(chat_id, f"⚠️ پاسخ سرویس‌دهنده دریافت نشد / no answer from the provider:\n{html.escape(error_note)}",
                           reply_keyboard=_section_bar(db, link))
        return "provider_error"
    return await _deliver_answer(db, user=user, link=link, chat_id=chat_id, answer=answer,
                                 charged_micro=charged_micro, session=session)


async def _deliver_answer(db: Session, *, user: User, link: TelegramLink, chat_id: int | str,
                          answer: str, charged_micro: int = 0, session: dict[str, Any] | None = None) -> str:
    """Send an answer (split when long) with the action row and the status line."""
    state = _state(link)
    language = session_service.language(state)
    settings_now = session_service.settings_of(state)
    active = session or session_service.active(state)
    footer: list[str] = []
    if active is not None:
        footer.append(("سشن" if language == "fa" else "session") + f" {active.get('id')}")
    if settings_now["show_cost"] and charged_micro:
        from app.services.pricing import micro_to_credits

        footer.append(f"{micro_to_credits(charged_micro)} credits")
    body = html.escape(answer)
    if footer:
        body += "\n\n<i>" + " · ".join(footer) + "</i>"
    await send_long_message(
        chat_id,
        body,
        keyboard=menus.answer_actions(language),
        reply_keyboard=_section_bar(db, link),
    )
    return "answer"


async def handle_callback(db: Session, update: dict[str, Any]) -> str:
    """Handle an inline-keyboard tap: menu navigation, model/variant/session choice."""
    query = update.get("callback_query") or {}
    data = (query.get("data") or "").strip()
    message = query.get("message") or {}
    chat = message.get("chat") or {}
    chat_id = chat.get("id")
    sender = query.get("from") or {}
    callback_id = str(query.get("id") or "")
    telegram_user_id = sender.get("id")
    if not data or telegram_user_id is None or chat_id is None:
        if callback_id:
            await answer_callback(callback_id)
        return "ignored"

    user, link = resolve_user(db, telegram_user_id)
    if user is None or link is None:
        if callback_id:
            await answer_callback(callback_id, "🔒 اول شناسهٔ تلگرام را در سایت ثبت کنید.", alert=True)
        return "callback_unlinked"

    if callback_id:
        await answer_callback(callback_id)
    if data == "noop":
        return "noop"

    head, _, tail = data.partition(":")
    if head == "menu":
        if tail == "sessions":
            return await _send_sessions(chat_id, db, user, link, edit=message.get("message_id"))
        if tail == "settings":
            return await _send_settings(chat_id, db, link, edit=message.get("message_id"))
        if tail == "models":
            await _send_models(chat_id, db, user, link)
            return "models"
        return await _handle_reply_action(db, user=user, link=link, chat_id=chat_id, action=data)
    if head == "sessions" and message.get("message_id"):  # pagination of the session list
        return await _send_sessions(chat_id, db, user, link, edit=message.get("message_id"))
    if head in ("models", "model", "variant", "session", "chat", "help", "settings"):
        return await _handle_reply_action(db, user=user, link=link, chat_id=chat_id, action=data)
    if head in ("use", "usev"):  # the pre-round-13 inline keyboards, still in old chats
        action = "model" if head == "use" else "variant"
        return await _handle_reply_action(db, user=user, link=link, chat_id=chat_id,
                                          action=f"{action}:{tail}")
    return "unknown_callback"


async def handle_update(db: Session, update: dict[str, Any]) -> str:
    """Route one Telegram update to the right handler."""
    if "callback_query" in update:
        return await handle_callback(db, update)
    if "message" in update or "edited_message" in update:
        return await handle_message(db, update)
    return "ignored"


# ---------------------------------------------------------------- transports -----
async def process_updates(offset: int | None = None, *, limit: int = 20, timeout: int = 30) -> tuple[int, int]:
    """One getUpdates round. Returns (next_offset, handled_count)."""
    payload: dict[str, Any] = {
        "timeout": timeout, "limit": limit,
        "allowed_updates": ["message", "edited_message", "callback_query"],
    }
    if offset is not None:
        payload["offset"] = offset
    updates = await call_api("getUpdates", payload, timeout=timeout + 15)
    handled = 0
    next_offset = offset or 0
    for update in updates:
        next_offset = max(next_offset, int(update.get("update_id", 0)) + 1)
        db = SessionLocal()
        try:
            result = await handle_update(db, update)
            handled += 1
            log.info("telegram update %s -> %s", update.get("update_id"), result)
        except Exception as exc:  # noqa: BLE001
            db.rollback()
            log.exception("telegram update failed: %s", exc)
        finally:
            db.close()
    return next_offset, handled


def _token_fingerprint(db: Session) -> str:
    refresh_token(db)
    token = bot_token()
    return token[-8:] if token else ""


async def run_polling(stop_event) -> None:  # noqa: ANN001
    """Long-polling loop (used by the worker when NEXA_TELEGRAM_MODE=polling).

    The bot token is re-read from the settings table on every idle cycle, so an operator who enters
    or rotates it in **Admin → Settings → Telegram** is served immediately — without restarting the
    service. The command list is published once per token so Telegram shows a tidy menu button.
    """
    offset: int | None = None
    announced = ""
    get_me_announced = ""
    failures = 0
    while not stop_event.is_set():
        db = SessionLocal()
        try:
            fingerprint = _token_fingerprint(db)
        finally:
            db.close()
        if not fingerprint:
            await _sleep(stop_event, 5)
            continue
        db = SessionLocal()
        try:
            enabled = bool(settings_store.get_value(db, "telegram.enabled", settings.telegram_enabled))
        finally:
            db.close()
        if not enabled:
            # A token exists but the operator switched the bot off in the panel: stay idle (and keep
            # checking) instead of answering messages the operator disabled.
            await _sleep(stop_event, 5)
            continue
        if fingerprint != announced:
            # `getMe` decides whether the token works; the two housekeeping calls are cosmetic and a
            # failure in either (an older Bot API that lacks setMyCommands, a transient 5xx) must never
            # delay answering messages.
            try:
                me = await get_me()
            except NexaError as exc:
                log.warning("telegram polling: %s", exc)
                await _sleep(stop_event, 5)
                continue
            get_me_announced = str(me.get("username") or "")
            log.info("telegram polling: connected as @%s", get_me_announced)
            for call, label in ((delete_webhook(), "deleteWebhook"), (set_my_commands(), "setMyCommands")):
                try:
                    await call
                except NexaError as exc:
                    log.warning("telegram polling: %s failed (not fatal): %s", label, exc)
            announced = fingerprint
        try:
            offset, handled = await process_updates(offset)
            if handled:
                log.info("telegram: handled %s update(s)", handled)
            failures = 0
        except NexaError as exc:
            # Back off gently: a single dropped long-poll must be retried within a second or two, while
            # a real outage must not hammer the API.
            failures += 1
            delay = min(1.5**failures, 20.0)
            log.warning("telegram polling: %s (retrying in %.1fs)", exc, delay)
            await _sleep(stop_event, delay)
        except Exception as exc:  # noqa: BLE001
            failures += 1
            log.exception("telegram polling crashed: %s", exc)
            await _sleep(stop_event, min(2.0**failures, 30.0))


async def _sleep(stop_event, seconds: float) -> None:  # noqa: ANN001
    """Sleep for `seconds`, waking early when the stop signal fires.

    The stop signal arrives as a `threading.Event` from both entry points (the worker
    process and the API's inline worker), and as an `asyncio.Event` from async callers.
    `threading.Event.wait()` returns a *bool* and cannot be awaited: awaiting it raised
    "object bool can't be used in 'await' expression", which killed the polling loop at
    the first transient network error. Both kinds are handled here.
    """
    import asyncio
    import inspect
    import threading

    if stop_event is None:
        await asyncio.sleep(seconds)
        return

    waiter = getattr(stop_event, "wait", None)
    if waiter is None:
        await asyncio.sleep(seconds)
        return

    if isinstance(stop_event, threading.Event):
        # Never call the blocking wait on the loop thread.
        await asyncio.get_running_loop().run_in_executor(None, waiter, seconds)
        return

    try:
        outcome = waiter(seconds)
    except TypeError:
        # asyncio.Event.wait() takes no timeout and returns a coroutine.
        outcome = waiter()

    if inspect.isawaitable(outcome):
        try:
            await asyncio.wait_for(outcome, timeout=seconds)
        except asyncio.TimeoutError:
            pass
        return


async def set_webhook(url: str) -> dict[str, Any]:
    payload: dict[str, Any] = {"url": url, "allowed_updates": ["message", "edited_message", "callback_query"]}
    secret = settings_store_secret_webhook()
    if secret:
        payload["secret_token"] = secret
    return await call_api("setWebhook", payload)


def settings_store_secret_webhook() -> str:
    """Webhook secret from the environment (the value is also accepted from the settings table)."""
    return settings.telegram_webhook_secret or ""

