/**
 * Chat workspace with real token streaming.
 *
 * Streaming uses `fetch` + a ReadableStream reader (not EventSource) so the session
 * cookie and CSRF header are sent exactly like every other API call. Server-sent
 * events carry meta / delta / usage / error / done frames.
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { api, ApiError, downloadFile, getCsrfToken } from "../api/client";
import type { CatalogModel, ChatMessageRecord, Conversation, Paged } from "../api/types";
import { Badge, Button, Card, EmptyState, ErrorNotice, Field, useApi } from "../components/ui";
import { Icon } from "../components/icons";
import { Markdown } from "../components/Markdown";
import { accessReason, NoModelsHint, useCatalog, UsageLine } from "./shared";
import { formatCredits, formatDateTime } from "../utils/format";
import { useApp, useI18n } from "../state/app";
import { VariantPicker } from "../components/variants";
import type { Variant } from "../components/variants";

/** Reasoning text of a stored message: either its own `reasoning` part or an inline `<think>` block. */
function reasoningTextOf(message: ChatMessageRecord): string | null {
  const parts = (message.content_parts || []) as Array<{ type?: string; text?: string }>;
  const fromParts = parts.filter((part) => part?.type === "reasoning").map((part) => part.text || "").join("\n\n");
  if (fromParts.trim()) return fromParts;
  const inline = /<\s*(?:think|thinking|reasoning)\b[^>]*>([\s\S]*?)(?:<\s*\/\s*(?:think|thinking|reasoning)\s*>|$)/i.exec(message.content || "");
  return inline?.[1]?.trim() || null;
}

interface ChatTurn {
  role: string;
  content: string;
  errorCategory?: string | null;
  errorMessage?: string | null;
  reasoning?: string | null;
  prompt_tokens?: number | null;
  completion_tokens?: number | null;
  charged_micro?: number;
  usage_source?: string;
  id?: number;
  created_at?: string;
}

export function Chat(): JSX.Element {
  const { t, locale } = useI18n();
  const { notify, meta, user } = useApp();
  const [params, setParams] = useSearchParams();
  const catalog = useCatalog();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [turns, setTurns] = useState<ChatTurn[]>([]);
  const [modelId, setModelId] = useState<number | null>(null);
  const [variantId, setVariantId] = useState<number | null>(null);
  const [input, setInput] = useState("");
  const [systemPrompt, setSystemPrompt] = useState("");
  const [temperature, setTemperature] = useState(0.7);
  const [streaming, setStreaming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [showSettings, setShowSettings] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const threadRef = useRef<HTMLDivElement | null>(null);

  const catalogModels = useMemo(() => catalog.data?.items || [], [catalog.data]);
  const usableModels = useMemo(() => catalogModels.filter((model) => model.accessible), [catalogModels]);
  // Why the model is not usable (balance empty, subscription missing, …) — straight from the API.
  const blockedModel = useMemo(() => catalogModels.find((model) => !model.accessible) || null, [catalogModels]);

  // Sub-models of the selected model: fetched from the real API and re-fetched when
  // the user switches model. A disabled variant stays visible but is not selectable.
  const variants = useApi<{ items: Variant[] }>(
    () => (modelId ? api.get<{ items: Variant[] }>(`/api/v1/models/${modelId}/variants`) : Promise.resolve({ items: [] })),
    [modelId],
  );
  const modelVariants = variants.data?.items || [];
  const activeVariant = modelVariants.find((variant) => variant.id === variantId) || null;

  useEffect(() => {
    if (!modelVariants.length) {
      setVariantId(null);
      return;
    }
    const preferred = modelVariants.find((variant) => variant.is_default && variant.enabled) || null;
    setVariantId((current) =>
      current !== null && modelVariants.some((variant) => variant.id === current && variant.enabled)
        ? current
        : preferred?.id ?? null,
    );
  }, [variants.data]);

  const loadConversations = async () => {
    const data = await api.get<Paged<Conversation>>("/api/v1/chat/conversations", { page_size: 50 });
    setConversations(data.items);
    return data.items;
  };

  useEffect(() => {
    loadConversations().catch(setError);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (modelId === null && usableModels.length > 0) {
      const preferred = Number(params.get("model") || 0);
      setModelId(preferred && usableModels.some((model) => model.id === preferred) ? preferred : usableModels[0].id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [usableModels]);

  useEffect(() => {
    const requested = Number(params.get("conversation") || 0);
    if (requested) openConversation(requested);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (threadRef.current) threadRef.current.scrollTop = threadRef.current.scrollHeight;
  }, [turns, streaming]);

  const openConversation = async (id: number) => {
    setError(null);
    setActiveId(id);
    const detail = await api.get<{ conversation: Conversation; messages: ChatMessageRecord[] }>(`/api/v1/chat/conversations/${id}`);
    setTurns(
      detail.messages.map((message) => ({
        id: message.id,
        role: message.role,
        content: message.content,
        created_at: message.created_at,
        prompt_tokens: message.prompt_tokens,
        completion_tokens: message.completion_tokens,
        charged_micro: message.charged_micro ?? undefined,
        errorCategory: message.error_category,
        errorMessage: message.error_message,
        reasoning: reasoningTextOf(message),
      })),
    );
    if (detail.conversation.model_id) setModelId(detail.conversation.model_id);
    setParams((current) => {
      current.set("conversation", String(id));
      return current;
    });
  };

  const newConversation = () => {
    setActiveId(null);
    setTurns([]);
    setError(null);
    setParams((current) => {
      current.delete("conversation");
      return current;
    });
  };

  const send = async (stream = true) => {
    if (!modelId || !input.trim()) return;
    setError(null);
    const message = input.trim();
    setInput("");
    const localTurns: ChatTurn[] = [...turns, { role: "user", content: message }];
    setTurns(localTurns);
    setBusy(true);
    setStreaming(stream);

    try {
      if (stream) {
        const controller = new AbortController();
        abortRef.current = controller;
        const response = await fetch("/api/v1/chat/stream", {
          method: "POST",
          credentials: "include",
          signal: controller.signal,
          headers: {
            "Content-Type": "application/json",
            Accept: "text/event-stream",
            "X-CSRF-Token": getCsrfToken() || "",
          },
          body: JSON.stringify({
            model_id: modelId,
            message,
            conversation_id: activeId,
            variant_id: variantId ?? undefined,
            system: systemPrompt || undefined,
            temperature,
          }),
        });
        if (!response.ok || !response.body) {
          const payload = await response.json().catch(() => null);
          throw new ApiError(response.status, payload?.error || { code: "stream_failed", message: "The stream could not be opened." });
        }
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let assistant = "";
        let reasoning = "";
        let event = "";
        setTurns((current) => [...current, { role: "assistant", content: "" }]);
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";
          for (const line of lines) {
            if (line.startsWith("event:")) {
              event = line.slice(6).trim();
              continue;
            }
            if (!line.startsWith("data:")) continue;
            const raw = line.slice(5).trim();
            if (!raw) continue;
            let payload: any = null;
            try {
              payload = JSON.parse(raw);
            } catch {
              continue;
            }
            if (event === "meta" && payload?.conversation_id) {
              setActiveId(payload.conversation_id);
              setParams((current) => {
                current.set("conversation", String(payload.conversation_id));
                return current;
              });
            } else if (event === "delta" && typeof payload?.text === "string") {
              assistant += payload.text;
              setTurns((current) => {
                const copy = [...current];
                // spread the previous turn: replacing the object would wipe the reasoning that
                // arrived before the first visible delta (reasoning models stream thinking first)
                copy[copy.length - 1] = { ...copy[copy.length - 1], role: "assistant", content: assistant };
                return copy;
              });
            } else if (event === "reasoning" && typeof payload?.text === "string") {
              // reasoning models stream their chain of thought (either in a separate `reasoning`
              // field or inline in the answer) — keep it in its own panel, never in the reply text
              reasoning += payload.text;
              setTurns((current) => {
                const copy = [...current];
                copy[copy.length - 1] = { ...copy[copy.length - 1], reasoning };
                return copy;
              });
            } else if (event === "usage") {
              setTurns((current) => {
                const copy = [...current];
                copy[copy.length - 1] = {
                  ...copy[copy.length - 1],
                  prompt_tokens: payload.prompt_tokens,
                  completion_tokens: payload.completion_tokens,
                  charged_micro: payload.charged_micro,
                  usage_source: payload.usage_source,
                };
                return copy;
              });
            } else if (event === "error") {
              setTurns((current) => {
                const copy = [...current];
                copy[copy.length - 1] = {
                  ...copy[copy.length - 1],
                  role: "assistant",
                  content: assistant,
                  errorCategory: payload?.category || "upstream_server_error",
                  charged_micro: 0,
                };
                return copy;
              });
              notify("error", payload?.message || t("status.error"), payload?.category_label);
            } else if (event === "done" && (payload?.message_id || payload?.assistant_message_id)) {
              setTurns((current) => {
                const copy = [...current];
                const last = copy[copy.length - 1];
                copy[copy.length - 1] = {
                  ...last,
                  id: payload.message_id ?? payload.assistant_message_id,
                  content: last.role === "assistant" && !last.content ? (payload.text || "") : last.content,
                  errorCategory: payload.empty_answer ? "empty_answer" : last.errorCategory,
                  errorMessage: payload.empty_answer ? payload.empty_answer : last.errorMessage,
                };
                return copy;
              });
            }
          }
        }
      } else {
        const response = await api.post<{
          conversation: Conversation;
          message: {
            id: number; content: string; content_parts?: Array<{ type?: string; text?: string }> | null;
            error_message?: string | null; error_category?: string | null;
          };
          usage: { prompt_tokens: number; completion_tokens: number; charged_micro: number; usage_source: string };
        }>("/api/v1/chat/completions", {
          model_id: modelId,
          message,
          conversation_id: activeId,
          variant_id: variantId ?? undefined,
          system: systemPrompt || undefined,
          temperature,
        });
        setActiveId(response.conversation.id);
        setTurns((current) => [
          ...current,
          {
            role: "assistant",
            id: response.message.id,
            content: response.message.content,
            // a non-streaming reply carries its reasoning in `content_parts`; without this the
            // reasoning panel would only appear after a page reload
            reasoning: reasoningTextOf({
              id: response.message.id,
              role: "assistant",
              content: response.message.content,
              created_at: "",
              content_parts: response.message.content_parts,
            }),
            errorMessage: response.message.error_message,
            errorCategory: response.message.error_category,
            prompt_tokens: response.usage.prompt_tokens,
            completion_tokens: response.usage.completion_tokens,
            charged_micro: response.usage.charged_micro,
            usage_source: response.usage.usage_source,
          },
        ]);
      }
      await loadConversations();
    } catch (caught) {
      if ((caught as Error)?.name !== "AbortError") setError(caught);
    } finally {
      abortRef.current = null;
      setStreaming(false);
      setBusy(false);
    }
  };

  const stop = () => {
    abortRef.current?.abort();
    setStreaming(false);
    setBusy(false);
  };

  const regenerate = async () => {
    if (!activeId) return;
    setBusy(true);
    setError(null);
    try {
      const response = await api.post<{ message?: { content: string; id: number; charged_micro?: number } }>(
        `/api/v1/chat/conversations/${activeId}/regenerate`,
      );
      await openConversation(activeId);
      notify("success", response?.message ? "Regenerated" : "Regenerated");
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.chat")}</h1>
          <p>
            {meta?.features?.streaming
              ? "Streaming is served by the configured provider."
              : "Streaming requires a model that advertises the streaming capability."}
          </p>
        </div>
        <div className="row">
          <Button variant="subtle" type="button" onClick={newConversation}>
            {t("chat.newConversation")}
          </Button>
          <Button variant="ghost" type="button" onClick={() => setShowSettings((value) => !value)}>
            {t("label.detail")}
          </Button>
          {activeId && (
            <Button
              variant="ghost"
              type="button"
              onClick={() =>
                downloadFile(`/api/v1/chat/conversations/${activeId}/export?format=markdown`, `conversation-${activeId}.md`)
              }
            >
              {t("chat.export")}
            </Button>
          )}
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      {!catalog.loading && usableModels.length === 0 && (
        <NoModelsHint reason={blockedModel ? accessReason(t, blockedModel) : null} />
      )}

      <div className="chat-layout">
        <Card
          icon="chat"
          title={t("chat.conversations")}
          actions={
            <Button variant="subtle" type="button" onClick={newConversation}>
              {t("chat.newConversation")}
            </Button>
          }
        >
          {conversations.length === 0 ? (
            <EmptyState icon="chat" hint={t("chat.newConversation")} />
          ) : (
            <ul className="stack stack--tight" style={{ listStyle: "none", padding: 0, margin: 0 }}>
              {conversations.map((conversation) => (
                <li key={conversation.id}>
                  <button
                    className={`navlink ${activeId === conversation.id ? "navlink--active" : ""}`}
                    type="button"
                    style={{ width: "100%", textAlign: "start", border: 0, background: activeId === conversation.id ? undefined : "transparent", font: "inherit" }}
                    onClick={() => openConversation(conversation.id)}
                  >
                    <span className="navlink__icon" aria-hidden>
                      <Icon name="chat" size={15} />
                    </span>
                    <span className="navlink__text" dir="auto" title={conversation.title || `#${conversation.id}`}>
                      {conversation.title || `#${conversation.id}`}
                    </span>
                    {conversation.pinned ? <Icon name="check" size={13} /> : null}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <div className="stack">
          <Card
            icon="chat"
            title={t("nav.chat")}
            actions={
              <div className="row">
                <Badge tone="info">{streaming ? "streaming" : busy ? "working" : "idle"}</Badge>
                {activeId && <span className="muted small">#{activeId}</span>}
              </div>
            }
          >
            {showSettings && (
              <div className="grid grid--2" style={{ marginBottom: "0.8rem" }}>
                <Field label="System prompt" hint="Sent with every request in this conversation.">
                  <textarea value={systemPrompt} onChange={(event) => setSystemPrompt(event.target.value)} />
                </Field>
                <Field label={`Temperature (${temperature})`}>
                  <input
                    type="number"
                    min={0}
                    max={2}
                    step={0.1}
                    value={temperature}
                    onChange={(event) => setTemperature(Number(event.target.value))}
                  />
                </Field>
              </div>
            )}

            <div className="chat-thread" ref={threadRef}>
              {turns.length === 0 ? (
                <EmptyState title={t("chat.placeholder")} hint="Your messages and the model replies are stored server-side." />
              ) : (
                turns.map((turn, index) => (
                  <div key={turn.id ?? index} className={`bubble bubble--${turn.role === "user" ? "user" : turn.errorCategory ? "error" : "assistant"}`}>
                    <div className="bubble__who">
                      <Icon name={turn.role === "user" ? "user" : "sparkles"} size={14} />
                      {turn.role === "user" ? (user?.display_name || t("label.email")) : (meta?.app_name || t("app.name"))}
                    </div>
                    {turn.role === "assistant" && turn.reasoning ? (
                      <details className="bubble__reasoning">
                        <summary>
                          <Icon name="sparkles" size={13} /> {t("chat.reasoning")}
                        </summary>
                        <pre>{turn.reasoning}</pre>
                      </details>
                    ) : null}
                    {turn.role === "assistant" ? (
                      turn.content ? (
                        <Markdown text={turn.content} />
                      ) : streaming ? (
                        <span className="typing" aria-label={t("chat.thinking")}>
                          <i />
                          <i />
                          <i />
                        </span>
                      ) : turn.errorMessage ? (
                        <p className="bubble__note">
                          <Icon name="alert" size={14} /> {turn.errorMessage}
                        </p>
                      ) : (
                        <p className="bubble__note">{t("chat.empty_answer")}</p>
                      )
                    ) : (
                      <p>{turn.content}</p>
                    )}
                    <div className="bubble__meta">
                      <span>{turn.role}</span>
                      {turn.created_at && <span>{formatDateTime(turn.created_at, locale)}</span>}
                      {turn.charged_micro ? <span>{formatCredits(turn.charged_micro)} credits</span> : null}
                      {turn.errorCategory && <Badge tone="danger">{turn.errorCategory}</Badge>}
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="composer" style={{ marginTop: "0.9rem" }}>
              <div className="composer__models">
                <label className="field" style={{ marginBottom: 0 }}>
                  <span className="field__label">{t("label.model")}</span>
                  <select value={modelId ?? ""} onChange={(event) => setModelId(event.target.value ? Number(event.target.value) : null)}>
                    <option value="">—</option>
                    {usableModels.map((model) => (
                      <option key={model.id} value={model.id}>
                        {model.display_name} · {model.provider}
                      </option>
                    ))}
                  </select>
                </label>
                <VariantPicker variants={modelVariants} value={variantId} onChange={setVariantId} />
                {activeVariant ? (
                  <p className="muted small composer__variant">
                    <Icon name="sparkles" size={13} />
                    {activeVariant.emoji ? `${activeVariant.emoji} ` : ""}
                    {activeVariant.name}
                    {activeVariant.has_system_prompt ? ` · ${t("variant.systemPrompt")}: ${activeVariant.system_prompt_chars}` : ""}
                  </p>
                ) : null}
              </div>
              <Field label={t("chat.placeholder")} hint={t("chat.thinking")}>
                <textarea
                  value={input}
                  onChange={(event) => setInput(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" && !event.shiftKey) {
                      event.preventDefault();
                      send(true);
                    }
                  }}
                />
              </Field>
              <div className="row row--between">
                <div className="row">
                <Button type="button" onClick={() => send(true)} loading={busy && streaming} disabled={!modelId || !input.trim()}>
                  <Icon name="bolt" size={16} />
                  {t("action.send")}
                </Button>
                <Button variant="subtle" type="button" onClick={() => send(false)} disabled={!modelId || !input.trim() || busy}>
                  Send without streaming
                </Button>
                {streaming && (
                  <Button variant="danger" type="button" onClick={stop}>
                    Stop
                  </Button>
                )}
                {activeId && (
                  <Button variant="ghost" type="button" onClick={regenerate} disabled={busy}>
                    <Icon name="refresh" size={15} />
                    {t("chat.regenerate")}
                  </Button>
                )}
                </div>
                <UsageLine usage={{ charged_micro: turns.reduce((sum, turn) => sum + (turn.charged_micro || 0), 0) }} />
              </div>
            </div>
          </Card>

          <Card title="Model price reference" subtitle="Live values from the pricing engine.">
            <div className="table-wrap table-wrap--stack">
              <table className="table table--stack">
                <thead>
                  <tr>
                    <th>{t("label.model")}</th>
                    <th>Input / 1M</th>
                    <th>Output / 1M</th>
                    <th>Per request</th>
                  </tr>
                </thead>
                <tbody>
                  {usableModels.slice(0, 10).map((model) => (
                    <tr key={model.id}>
                      <td data-label={t("label.model")}>
                        <Link to={`/app/models/${model.id}`}>{model.display_name}</Link>
                      </td>
                      <td className="mono" data-label="Input / 1M">{model.pricing?.input_credits_per_mtok ?? "—"}</td>
                      <td className="mono" data-label="Output / 1M">{model.pricing?.output_credits_per_mtok ?? "—"}</td>
                      <td className="mono" data-label="Per request">{model.pricing?.per_request_credits ?? "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
