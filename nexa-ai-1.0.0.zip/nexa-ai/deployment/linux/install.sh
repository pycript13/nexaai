#!/usr/bin/env bash
# Nexa AI — Ubuntu/Debian installer (native install, no Docker required).
#
# Usage:  sudo bash deployment/linux/install.sh [options]
#
# Options:
#   --access MODE       how people reach the app: public (public IP, no domain — default),
#                       domain (a domain name, with HTTPS when a certificate is available) or
#                       local (this machine only). Without this flag the installer asks in an
#                       interactive shell and uses "public" when it cannot ask.
#   --domain NAME       the domain that points at this server; implies --access domain
#   --acme-email A      e-mail for Let's Encrypt (needed only for automatic certificate issuance)
#   --public-port N     port for the Nginx site and the public URL (default 8080; 80 in domain mode)
#   --admin-email A     first Super Admin e-mail (asks interactively, else admin@example.com)
#   --admin-name N      display name of that administrator (default "Nexa Administrator")
#   --admin-password P  password for that administrator. Without it the installer asks (interactive
#                       shell) or generates a strong one and stores it in .env. It is never echoed
#                       and never written to the install log.
#   --generate-admin-password
#                       always generate the password (no prompt) — for unattended installs
#   --non-interactive   never ask anything (also implied when stdin is not a terminal)
#   --app-dir DIR       install directory (default /opt/nexa-ai)
#   --python PATH       interpreter for the virtualenv (default: best 3.11-3.13 found)
#   --reset-env         back up an existing .env and generate a fresh one (use when the
#                       file still carries placeholder or foreign values)
#   --reset-admin-password
#                       if the administrator cannot sign in (for example after the .env was
#                       replaced), reset that account to the password stored in .env; the
#                       change is audited and all its sessions are revoked
#   --no-packages       do not run apt-get (packages already installed)
#   --no-node           do not install Node.js / do not build the SPA
#   --no-nginx          skip the Nginx site (API keeps listening on 127.0.0.1)
#   --no-systemd        force the process launcher instead of systemd units
#   -h | --help         show this help
#
# What it does:
#   1. installs system packages (python3, venv, nginx, postgresql, redis, nodejs)
#   2. starts PostgreSQL / Redis and waits until they really accept connections
#   3. creates the nexa system user and the install directory
#   4. creates the PostgreSQL database + role
#   5. builds the frontend (when npm is available) and the virtualenv
#   6. runs migrations, bootstraps roles/settings and the first Super Admin
#   7. checks the configuration with app.cli doctor and refuses to continue if the
#      application would not start (placeholder secrets, SQLite in production, ...)
#   8. installs systemd units (API + worker) and an Nginx site — or, in a container
#      without systemd, starts the same processes through
#      deployment/linux/nexa-services.sh (PID files, nohup, logs in logs/)
#   9. verifies the result itself: /readyz plus a real administrator sign-in, then
#      prints the URL, the credentials file and the HTTP-on-public-IP warning
set -Eeuo pipefail

# /usr/sbin and /sbin are frequently missing from a minimal PATH (cron, docker exec,
# `sudo env`); nginx, ufw and the PostgreSQL tools live there.
export PATH="/usr/sbin:/sbin:${PATH}"

APP_USER="${APP_USER:-nexa}"
APP_DIR="${APP_DIR:-/opt/nexa-ai}"
DB_NAME="${DB_NAME:-nexa}"
DB_USER="${DB_USER:-nexa}"
DB_PASSWORD="${DB_PASSWORD:-$(openssl rand -hex 16)}"
PUBLIC_PORT="${PUBLIC_PORT:-8080}"
API_PORT=8000   # the port uvicorn binds (the systemd unit and the launcher both use it)
PYTHON_REQUESTED="${PYTHON_BIN:-}"
ADMIN_EMAIL="${ADMIN_EMAIL:-}"
ADMIN_NAME="${NEXA_ADMIN_NAME:-Nexa Administrator}"
ADMIN_PASSWORD_INPUT="${NEXA_ADMIN_PASSWORD:-}"
ACCESS_MODE="${ACCESS_MODE:-}"
ACCESS_EXPLICIT=0
DOMAIN="${DOMAIN:-}"
ACME_EMAIL="${ACME_EMAIL:-}"
GENERATE_ADMIN_PASSWORD=0
INTERACTIVE="auto"
PUBLIC_PORT_EXPLICIT=0
INSTALL_PACKAGES=1
BUILD_FRONTEND=1
SETUP_NGINX=1
USE_SYSTEMD="auto"
RESET_ENV=0
RESET_ADMIN_PASSWORD=0
CHECK_PUBLIC=1

usage() {
  cat <<'USAGE'
Nexa AI — Ubuntu/Debian installer (native install, no Docker required).

Usage:  sudo bash deployment/linux/install.sh [options]

Options:
  --access MODE       public | domain | local   (default: ask; "public" when it cannot ask)
  --domain NAME       domain pointing at this server (implies --access domain)
  --acme-email A      e-mail for Let's Encrypt certificate issuance
  --public-port N     port for the Nginx site and the public URL (default 8080; 80 in domain mode)
  --admin-email A     first Super Admin e-mail (default: ask, else admin@example.com)
  --admin-name N      display name of that administrator
  --admin-password P  password for that administrator (omit to be asked, or to have one generated)
  --generate-admin-password
                      generate the administrator password instead of asking
  --non-interactive   never prompt (also automatic when stdin is not a terminal)
  --app-dir DIR       install directory (default /opt/nexa-ai)
  --python PATH       interpreter for the virtualenv (default: best 3.11-3.13 found)
  --reset-env         back up an existing .env and generate a fresh one (use when the
                      file still carries placeholder or foreign values)
  --reset-admin-password
                      if the administrator cannot sign in (for example after the .env was
                      replaced), reset that account to the password stored in .env; the
                      change is audited and all its sessions are revoked
  --no-public-check   skip the "can a browser outside this machine reach the URL" check
  --no-packages       do not run apt-get (packages already installed)
  --no-node           do not install Node.js / do not build the SPA
  --no-nginx          skip the Nginx site (API keeps listening on 127.0.0.1)
  --no-systemd        force the process launcher instead of systemd units
  -h | --help         show this help

Environment:
  NEXA_PUBLIC_IP      pin the public address the installer prints and checks. Set it when the
                      outbound address (api.ipify.org) is not the address a browser uses —
                      double NAT, CGNAT, or a proxy in front of the host.
  NEXA_ADMIN_PASSWORD the administrator password, for automation that must not put it in argv
                      (it stays out of the process list and out of the install log).

What it does:
  1. installs system packages (python3, venv, nginx, postgresql, redis, nodejs)
  2. starts PostgreSQL / Redis and waits until they really accept connections
  3. creates the nexa system user and the install directory
  4. creates the PostgreSQL database + role
  5. builds the frontend (when npm is available) and the virtualenv
  6. runs migrations, bootstraps roles/settings and the first Super Admin
  7. checks the configuration with app.cli doctor and refuses to continue if the
     application would not start (placeholder secrets, SQLite in production, ...)
  8. installs systemd units (API + worker) and an Nginx site — or, in a container
     without systemd, starts the same processes through
     deployment/linux/nexa-services.sh (PID files, nohup, logs in logs/)
  9. verifies the result itself: /readyz, a real administrator sign-in, and whether a
     browser on another machine can reach the printed URL (NAT/firewall report)
USAGE
  exit 0
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --access)        ACCESS_MODE="$2"; ACCESS_EXPLICIT=1; shift 2 ;;
    --domain)        DOMAIN="$2"; ACCESS_MODE="domain"; ACCESS_EXPLICIT=1; shift 2 ;;
    --acme-email)    ACME_EMAIL="$2"; shift 2 ;;
    --public-port)   PUBLIC_PORT="$2"; PUBLIC_PORT_EXPLICIT=1; shift 2 ;;
    --admin-email)   ADMIN_EMAIL="$2"; shift 2 ;;
    --admin-name)    ADMIN_NAME="$2"; shift 2 ;;
    --admin-password) ADMIN_PASSWORD_INPUT="$2"; shift 2 ;;
    --generate-admin-password) GENERATE_ADMIN_PASSWORD=1; shift ;;
    --interactive)   INTERACTIVE=1; shift ;;
    --non-interactive) INTERACTIVE=0; shift ;;
    --app-dir)       APP_DIR="$2"; shift 2 ;;
    --db-name)       DB_NAME="$2"; shift 2 ;;
    --db-user)       DB_USER="$2"; shift 2 ;;
    --db-password)   DB_PASSWORD="$2"; shift 2 ;;
    --python)        PYTHON_REQUESTED="$2"; shift 2 ;;
    --reset-env)     RESET_ENV=1; shift ;;
    --reset-admin-password) RESET_ADMIN_PASSWORD=1; shift ;;
    --no-public-check) CHECK_PUBLIC=0; shift ;;
    --no-packages)   INSTALL_PACKAGES=0; shift ;;
    --no-node)       BUILD_FRONTEND=0; shift ;;
    --no-nginx)      SETUP_NGINX=0; shift ;;
    --no-systemd)    USE_SYSTEMD=0; shift ;;
    --systemd)       USE_SYSTEMD=1; shift ;;
    -h|--help)       usage ;;
    *) printf '[error] unknown option: %s (try --help)\n' "$1" >&2; exit 2 ;;
  esac
done

log()  { printf '\033[1;34m[install]\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32m[ok]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[warning]\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[error]\033[0m %s\n' "$*" >&2; exit 1; }

have() { command -v "$1" >/dev/null 2>&1; }

# The pinned dependency set (pydantic 2.10.x / pydantic-core 2.27) ships prebuilt wheels for
# CPython 3.9-3.13 only. On 3.14 pip would try to compile pydantic-core from source and fail
# with a Rust/PyO3 error, so the installer insists on a supported interpreter.
SUPPORTED_PYTHON="3.11-3.13"

python_version_of() { # $1 = interpreter -> prints "3.13" or nothing
  "$1" -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null || true
}

python_supported() { # $1 = interpreter
  case "$(python_version_of "$1")" in
    3.11|3.12|3.13) return 0 ;;
    *) return 1 ;;
  esac
}

# Where a uv-managed interpreter lives (set system-wide so the service user can execute it).
NEXA_PYTHON_DIR="${UV_PYTHON_INSTALL_DIR:-/opt/nexa-python}"

uv_python_binaries() {
  local dir
  for dir in "${NEXA_PYTHON_DIR}"/*/bin; do
    [[ -d "${dir}" ]] || continue
    for candidate in python3.13 python3.12 python3.11 python3; do
      [[ -x "${dir}/${candidate}" ]] && printf '%s\n' "${dir}/${candidate}"
    done
  done
}

select_python() {
  local candidate resolved
  for candidate in \
      ${PYTHON_REQUESTED:-} \
      $(uv_python_binaries) \
      python3.13 python3.12 python3.11 /usr/bin/python3 python3 /usr/local/bin/python3; do
    [[ -n "${candidate}" ]] || continue
    resolved="${candidate}"
    if [[ "${candidate}" != */* ]]; then
      resolved="$(command -v "${candidate}" 2>/dev/null || true)"
    fi
    [[ -n "${resolved}" ]] || continue
    if python_supported "${resolved}"; then
      printf '%s\n' "${resolved}"
      return 0
    fi
  done
  return 1
}

# ------------------------------------------------------------------ getting a Python 3.11-3.13 --
# A distribution that ships *only* Python 3.14 (Ubuntu 26.04 and friends) cannot build the pinned
# pydantic-core wheels without a Rust toolchain, so a `apt-get install python3` there changes
# nothing. This chain really produces a supported interpreter:
#   1. the distribution's versioned packages (python3.13 / 3.12 / 3.11)
#   2. deadsnakes (Ubuntu) when add-apt-repository is available
#   3. uv, which downloads a standalone CPython (python-build-standalone) into ${NEXA_PYTHON_DIR}
#      — works on any distribution, needs no PPA and no Rust, and is readable by the service user.
try_distro_python_packages() {
  local package
  for package in python3.13 python3.12 python3.11; do
    apt-get install -y --no-install-recommends "${package}" "${package}-venv" >/dev/null 2>&1 || true
    PYTHON_PATH="$(select_python || true)"
    [[ -n "${PYTHON_PATH:-}" ]] && return 0
  done
  return 1
}

try_deadsnakes() {
  have add-apt-repository || return 1
  have apt-get || return 1
  grep -q "deadsnakes" /etc/apt/sources.list /etc/apt/sources.list.d/* 2>/dev/null && return 1
  log "adding the deadsnakes PPA to obtain Python 3.13"
  DEBIAN_FRONTEND=noninteractive add-apt-repository -y ppa:deadsnakes/ppa >/dev/null 2>&1 || return 1
  apt-get update -qq >/dev/null 2>&1 || true
  try_distro_python_packages
}

try_uv_python() {
  local uv_bin="" candidate found
  if [[ -n "${UV_BIN:-}" && -x "${UV_BIN}" ]]; then
    uv_bin="${UV_BIN}"
  elif have uv; then
    uv_bin="$(command -v uv)"
  else
    for candidate in /usr/local/bin/uv /root/.local/bin/uv /opt/uv/uv; do
      [[ -x "${candidate}" ]] && uv_bin="${candidate}" && break
    done
  fi
  if [[ -z "${uv_bin}" ]]; then
    log "downloading uv (a single static binary) to obtain a supported Python"
    if curl -fsSL --max-time 180 https://astral.sh/uv/install.sh -o /tmp/nexa-uv-install.sh 2>/dev/null; then
      sh /tmp/nexa-uv-install.sh >/dev/null 2>&1 || true
    fi
    for candidate in /root/.local/bin/uv "${HOME}/.local/bin/uv" /usr/local/bin/uv; do
      [[ -x "${candidate}" ]] && uv_bin="${candidate}" && break
    done
  fi
  [[ -n "${uv_bin}" ]] || return 1
  log "installing a standalone Python 3.13 with uv (no compiler, no Rust, no PPA)"
  mkdir -p "${NEXA_PYTHON_DIR}"
  UV_PYTHON_INSTALL_DIR="${NEXA_PYTHON_DIR}" "${uv_bin}" python install 3.13 >/dev/null 2>&1 || return 1
  chmod -R a+rX "${NEXA_PYTHON_DIR}" 2>/dev/null || true
  found="$(UV_PYTHON_INSTALL_DIR="${NEXA_PYTHON_DIR}" "${uv_bin}" python find 3.13 2>/dev/null || true)"
  if [[ -z "${found}" || ! -x "${found}" ]]; then
    found="$(select_python || true)"
  fi
  [[ -n "${found}" ]] || return 1
  PYTHON_PATH="${found}"
}

# systemd is only usable when it really is PID 1 and the bus answers.
systemd_usable() {
  [[ "${USE_SYSTEMD}" == "0" ]] && return 1
  [[ "${USE_SYSTEMD}" == "1" ]] && return 0
  have systemctl || return 1
  # only PID 1 systemd can manage services; "degraded" is normal in containers
  [[ "$(ps -p 1 -o comm= 2>/dev/null | tr -d ' ')" == "systemd" ]] || return 1
  local state
  state="$(systemctl is-system-running 2>/dev/null || true)"
  case "${state}" in
    "" | offline | unknown) return 1 ;;
    *) return 0 ;;
  esac
}

[[ "$(id -u)" -eq 0 ]] || die "run this installer as root (sudo bash $0)"

# ---------------------------------------------------------------------------
# Input validation and the interactive wizard.
#
# Why this exists: the installer used to decide for the operator. Everybody got the same
# "admin@example.com" account with a generated password, and everybody got public-IP mode on
# port 8080 — including people who own a domain and want HTTPS, or who only want the app on their
# own machine. The mode and the credentials can now be chosen here (or passed as flags, or set
# through NEXA_ADMIN_PASSWORD for automation) and every value is validated *before* anything is
# installed, so a typo cannot surface half an hour later. An existing installation is never
# overwritten silently: the questions default to what is already configured and the password is
# only changed when asked for.
# ---------------------------------------------------------------------------
is_valid_email() {
  [[ "$1" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]
}

is_valid_domain() {
  [[ "$1" =~ ^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$ ]]
}

is_weak_password() { # shorter than the application's own minimum (10) or an obvious placeholder
  local value="$1"
  [[ ${#value} -lt 10 ]] && return 0
  printf '%s' "${value}" | grep -qiE 'change[_-]?me|your-?password|password123|placeholder|^(password|admin|nexa|qwerty|1234567890)+$' && return 0
  return 1
}

# Minimal .env reader for the wizard (the full helper further down is defined later in the run).
peek_env() { grep -E "^$2=" "$1" 2>/dev/null | tail -1 | cut -d= -f2- || true; }

ask() { # ask <prompt> <default> -> the answer (default when the line is empty)
  local prompt="$1" default="$2" answer=""
  if [[ -n "${default}" ]]; then
    printf '%s [%s]: ' "${prompt}" "${default}" >&2
  else
    printf '%s: ' "${prompt}" >&2
  fi
  read -r answer || answer=""
  answer="${answer:-${default}}"
  # strip surrounding quotes: people copy values like "Nexa AI" out of an .env file
  answer="${answer%\"}"; answer="${answer#\"}"
  answer="${answer%\'}"; answer="${answer#\'}"
  printf '%s' "${answer}"
}

ask_secret() { # ask_secret <prompt> -> what was typed, never echoed
  local prompt="$1" answer=""
  printf '%s' "${prompt}" >&2
  read -r -s answer || answer=""
  printf '\n' >&2
  printf '%s' "${answer}"
}

ask_yes_no() { # ask_yes_no <prompt> <default y|n> -> 0 for yes
  local prompt="$1" default="$2" answer=""
  printf '%s [%s]: ' "${prompt}" "${default}" >&2
  read -r answer || answer=""
  answer="${answer:-${default}}"
  case "$(printf '%s' "${answer}" | tr '[:upper:]' '[:lower:]')" in
    y|yes|1|true|بله) return 0 ;;
    *) return 1 ;;
  esac
}

wizard_enabled() {
  [[ "${INTERACTIVE}" == "1" ]] && return 0
  [[ "${INTERACTIVE}" == "0" ]] && return 1
  [[ -t 0 && -t 1 ]] || return 1
  return 0
}

ENV_FILE="${APP_DIR}/.env"
ENV_EXISTS=0
[[ -f "${ENV_FILE}" ]] && ENV_EXISTS=1

if [[ -z "${ADMIN_EMAIL}" ]]; then
  ADMIN_EMAIL="admin@example.com"   # only used when there is nothing to ask and nothing stored
fi

if wizard_enabled; then
  printf '\n'
  log "a few questions — Enter accepts the value shown in brackets"
  printf '\n'

  CURRENT_MODE="public"
  if [[ "${ENV_EXISTS}" -eq 1 ]]; then
    case "$(peek_env "${ENV_FILE}" NEXA_DEPLOYMENT_MODE)" in
      local) CURRENT_MODE="local" ;;
      domain_https) CURRENT_MODE="domain" ;;
      public_ip) CURRENT_MODE="public" ;;
    esac
    STORED_BASE_URL="$(peek_env "${ENV_FILE}" NEXA_PUBLIC_BASE_URL)"
    if [[ "${CURRENT_MODE}" == "public" && "${STORED_BASE_URL}" == https://* ]]; then
      CURRENT_MODE="domain"
    fi
    [[ -n "${DOMAIN}" ]] || DOMAIN="$(printf '%s' "${STORED_BASE_URL}" | sed -E 's#^https?://##; s#:[0-9]+$##; s#/.*$##')"
    [[ "${DOMAIN}" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && DOMAIN=""
    ADMIN_EMAIL="$(peek_env "${ENV_FILE}" NEXA_BOOTSTRAP_ADMIN_EMAIL)"
    ADMIN_EMAIL="${ADMIN_EMAIL:-admin@example.com}"
    STORED_NAME="$(peek_env "${ENV_FILE}" NEXA_BOOTSTRAP_ADMIN_NAME)"
    [[ -n "${STORED_NAME}" ]] && ADMIN_NAME="${STORED_NAME}"
    log "an installation already exists in ${APP_DIR} — the defaults below keep it as it is"
  fi
  [[ -n "${ACCESS_MODE}" ]] || ACCESS_MODE="${CURRENT_MODE}"
  case "${ACCESS_MODE}" in
    public) MODE_DEFAULT=1 ;;
    domain) MODE_DEFAULT=2 ;;
    local)  MODE_DEFAULT=3 ;;
    *)      MODE_DEFAULT=1 ;;
  esac

  cat <<'CHOICE' >&2
How should people reach this application?
  1) Public IP, no domain      — open http://<server-ip>:<port>: works immediately, plain HTTP
                                 (the UI shows a security warning: traffic is not encrypted)
  2) A domain (with HTTPS)     — you type a name such as ai.example.com; Nginx is configured for
                                 it and a Let's Encrypt certificate is issued when possible
  3) This machine only         — nothing is exposed; browse http://127.0.0.1:<port>
CHOICE
  MODE_ANSWER="$(ask "Choose 1, 2 or 3" "${MODE_DEFAULT}")"
  case "${MODE_ANSWER}" in
    1|public|public_ip|ip) ACCESS_MODE="public" ;;
    2|domain|https|domain_https) ACCESS_MODE="domain" ;;
    3|local|localhost|private) ACCESS_MODE="local" ;;
    *) warn "unrecognised answer '${MODE_ANSWER}' — using public IP mode"; ACCESS_MODE="public" ;;
  esac
  ACCESS_EXPLICIT=1

  if [[ "${ACCESS_MODE}" == "domain" ]]; then
    while true; do
      DOMAIN="$(ask "Domain that points at this server (A record)" "${DOMAIN}")"
      is_valid_domain "${DOMAIN}" && break
      warn "'${DOMAIN}' does not look like a domain name — try again (example: ai.example.com)"
    done
    ACME_EMAIL="$(ask "E-mail for the certificate (Let's Encrypt)" "${ACME_EMAIL:-${ADMIN_EMAIL}}")"
  elif [[ "${ACCESS_MODE}" == "public" && "${PUBLIC_PORT_EXPLICIT}" -eq 0 ]]; then
    PUBLIC_PORT="$(ask "Port other people will open" "${PUBLIC_PORT}")"
  fi

  ADMIN_EMAIL="$(ask "Administrator e-mail (the sign-in name)" "${ADMIN_EMAIL}")"
  ADMIN_NAME="$(ask "Administrator display name" "${ADMIN_NAME}")"

  SET_NEW_PASSWORD=0
  if [[ "${GENERATE_ADMIN_PASSWORD}" -eq 1 ]]; then
    SET_NEW_PASSWORD=-1   # means: generate one below, never a chosen value
  elif [[ -n "${ADMIN_PASSWORD_INPUT}" ]]; then
    SET_NEW_PASSWORD=1    # the flag already provided it; nothing to ask
  elif [[ "${ENV_EXISTS}" -eq 0 ]]; then
    SET_NEW_PASSWORD=1
    log "choose the password for ${ADMIN_EMAIL} (or press Enter to have a strong one generated)"
  elif ask_yes_no "Change the existing administrator password?" "n"; then
    SET_NEW_PASSWORD=1
  fi

  if [[ "${SET_NEW_PASSWORD}" -eq 1 && -z "${ADMIN_PASSWORD_INPUT}" ]]; then
    while true; do
      printf '\n%s\n' "Password: at least 10 characters, typing is hidden — press Enter alone to generate one" >&2
      TRY1="$(ask_secret "  password: ")"
      if [[ -z "${TRY1}" ]]; then
        GENERATE_ADMIN_PASSWORD=1
        break
      fi
      if is_weak_password "${TRY1}"; then
        warn "too short or too predictable — try again (or press Enter to generate one)"
        continue
      fi
      TRY2="$(ask_secret "  repeat:   ")"
      if [[ "${TRY1}" != "${TRY2}" ]]; then
        warn "the two entries did not match — try again"
        continue
      fi
      ADMIN_PASSWORD_INPUT="${TRY1}"
      break
    done
  fi
  printf '\n'
else
  # Non-interactive: an explicit flag/environment value wins, otherwise an existing installation
  # keeps its stored credentials and a fresh one gets a generated password (the previous behaviour).
  if [[ "${ENV_EXISTS}" -eq 1 && -z "${ADMIN_EMAIL}" ]]; then
    ADMIN_EMAIL="$(peek_env "${ENV_FILE}" NEXA_BOOTSTRAP_ADMIN_EMAIL)"
    ADMIN_EMAIL="${ADMIN_EMAIL:-admin@example.com}"
  fi
  [[ -n "${ACCESS_MODE}" ]] || ACCESS_MODE="public"
  [[ "${ACCESS_MODE}" == "domain" ]] || true
fi

# Every input is validated here — flags and environment included, because a typo must fail now
# and not after the packages, the database and the virtualenv are in place.
is_valid_email "${ADMIN_EMAIL}" || die "'${ADMIN_EMAIL}' is not a valid e-mail address (use --admin-email or answer the question again)"
if [[ -n "${ADMIN_PASSWORD_INPUT}" ]] && is_weak_password "${ADMIN_PASSWORD_INPUT}"; then
  die "the administrator password must be at least 10 characters and not a placeholder word (use --generate-admin-password to have one generated)"
fi
case "${ACCESS_MODE:-public}" in
  ""|public|public_ip) ACCESS_MODE="public" ;;
  domain|domain_https)
    ACCESS_MODE="domain"
    [[ -n "${DOMAIN}" ]] || die "--access domain needs --domain <name> (or answer the question interactively)"
    is_valid_domain "${DOMAIN}" || die "'${DOMAIN}' is not a valid domain name (example: ai.example.com)"
    DOMAIN="$(printf '%s' "${DOMAIN}" | tr '[:upper:]' '[:lower:]')"
    ;;
  local|localhost) ACCESS_MODE="local" ;;
  *) die "--access ${ACCESS_MODE} is not recognised (use public, domain or local)" ;;
esac
if [[ -n "${ACME_EMAIL}" ]] && ! is_valid_email "${ACME_EMAIL}"; then
  die "'${ACME_EMAIL}' is not a valid e-mail address (--acme-email)"
fi
if [[ "${ACCESS_MODE}" == "domain" && "${PUBLIC_PORT_EXPLICIT}" -eq 0 ]]; then
  PUBLIC_PORT=80          # a domain is published on the standard ports
fi
if [[ "${ACCESS_MODE}" == "local" ]]; then
  SETUP_NGINX=0
fi
if [[ "${ACCESS_MODE}" == "domain" && "${SETUP_NGINX}" -eq 0 ]]; then
  die "--no-nginx cannot be combined with a domain deployment (there would be nothing to serve ${DOMAIN:-the domain})"
fi

# fail fast on an explicitly requested interpreter we cannot support
if [[ -n "${PYTHON_REQUESTED}" ]] && ! python_supported "${PYTHON_REQUESTED}"; then
  die "--python ${PYTHON_REQUESTED} is Python $(python_version_of "${PYTHON_REQUESTED}" || echo unknown); this release supports ${SUPPORTED_PYTHON} (the pinned pydantic/pydantic-core wheels stop at 3.13)"
fi

if [[ "${INSTALL_PACKAGES}" -eq 1 ]]; then
  log "installing system packages"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -y
  apt-get install -y python3 python3-venv python3-dev build-essential libpq-dev \
    postgresql postgresql-contrib redis-server nginx curl git unzip openssl sqlite3 rsync ca-certificates
  if [[ "${BUILD_FRONTEND}" -eq 1 ]] && ! have npm; then
    apt-get install -y nodejs npm \
      || warn "could not install nodejs/npm from the distribution — install Node.js 20 from https://nodejs.org or NodeSource"
  fi
else
  log "skipping system package installation (--no-packages)"
fi

# ---------------------------------------------------------------------------
# PostgreSQL: start it (any way we can) and wait until it accepts connections.
# ---------------------------------------------------------------------------
pg_is_up() { have pg_isready && pg_isready -q -h /var/run/postgresql 2>/dev/null; }

pg_clusters() {
  have pg_lsclusters || return 0
  pg_lsclusters -h 2>/dev/null | awk 'NF>=2 {print $1" "$2}'
}

start_postgres_raw() {
  local version bindir datadir cfg logfile socketdir
  version="$(ls -1 /usr/lib/postgresql/*/ -d 2>/dev/null | sort -V | tail -1 | cut -d/ -f5)"
  [[ -n "${version}" ]] || return 1
  bindir="/usr/lib/postgresql/${version}/bin"
  datadir="/var/lib/postgresql/${version}/main"
  cfg="/etc/postgresql/${version}/main/postgresql.conf"
  [[ -x "${bindir}/pg_ctl" && -d "${datadir}" ]] || return 1
  socketdir="/var/run/postgresql"
  mkdir -p "${socketdir}" && chown postgres:postgres "${socketdir}"
  logfile="/var/log/postgresql/postgresql-${version}-main.log"
  mkdir -p "$(dirname "${logfile}")" && chown postgres:postgres "$(dirname "${logfile}")"
  su postgres -c "${bindir}/pg_ctl -D '${datadir}' -o '-c config_file=${cfg}' -l '${logfile}' -w start" >/dev/null
}

start_postgres() {
  pg_is_up && return 0

  if systemd_usable; then
    systemctl start postgresql >/dev/null 2>&1 || true
    pg_is_up && return 0
  fi

  if have service; then
    service postgresql start >/dev/null 2>&1 || true
    pg_is_up && return 0
  fi

  local cluster version name
  while read -r version name; do
    [[ -n "${version:-}" ]] || continue
    pg_ctlcluster "${version}" "${name}" start >/dev/null 2>&1 || true
    pg_is_up && return 0
  done < <(pg_clusters)

  start_postgres_raw >/dev/null 2>&1 || true
  pg_is_up
}

wait_for_postgres() {
  local tries="${1:-30}" i
  for ((i = 1; i <= tries; i++)); do
    pg_is_up && return 0
    sleep 1
  done
  return 1
}

log "starting PostgreSQL"
if ! start_postgres; then
  warn "PostgreSQL did not answer yet — waiting up to 30s more"
fi
if ! wait_for_postgres 30; then
  cat >&2 <<'PGFAIL'
[error] PostgreSQL is installed but not accepting connections.

This usually means the service was never started. Every environment is different:

  systemd host          sudo systemctl start postgresql
  OpenVZ / no systemd   sudo service postgresql start
  Debian/Ubuntu wrapper sudo pg_ctlcluster 17 main start
  container, manual     sudo -u postgres /usr/lib/postgresql/17/bin/pg_ctl \
                          -D /var/lib/postgresql/17/main \
                          -o "-c config_file=/etc/postgresql/17/main/postgresql.conf" \
                          -l /var/log/postgresql/postgresql-17-main.log start

(adjust "17" to the version printed by: ls /usr/lib/postgresql/)

Then confirm with:  pg_isready          # must print "accepting connections"

Alternatives if PostgreSQL cannot run in this environment:
  * use the Docker route instead:      docker compose up -d --build
  * run a development instance on SQLite:
        NEXA_DATABASE_URL=sqlite:////opt/nexa-ai/data/nexa.db
    (development only — never for production; see docs/KNOWN_LIMITATIONS.md)

After PostgreSQL is up, simply re-run:  sudo bash deployment/linux/install.sh
PGFAIL
  exit 1
fi
ok "PostgreSQL is accepting connections"

# ---------------------------------------------------------------------------
# Redis is optional: the application falls back to in-process rate limiting.
# ---------------------------------------------------------------------------
start_redis() {
  have redis-cli && redis-cli ping 2>/dev/null | grep -q PONG && return 0
  if systemd_usable; then
    systemctl start redis-server >/dev/null 2>&1 || systemctl start redis >/dev/null 2>&1 || true
    have redis-cli && redis-cli ping 2>/dev/null | grep -q PONG && return 0
  fi
  if have service; then
    service redis-server start >/dev/null 2>&1 || service redis start >/dev/null 2>&1 || true
    have redis-cli && redis-cli ping 2>/dev/null | grep -q PONG && return 0
  fi
  if have redis-server; then
    mkdir -p /var/lib/redis /var/log/redis
    chown -R redis:redis /var/lib/redis /var/log/redis 2>/dev/null || true
    redis-server --daemonize yes --dir /var/lib/redis --logfile /var/log/redis/redis-server.log >/dev/null 2>&1 || true
    sleep 1
    have redis-cli && redis-cli ping 2>/dev/null | grep -q PONG && return 0
  fi
  return 1
}

log "starting Redis"
if start_redis; then
  ok "Redis is responding"
else
  warn "Redis is not reachable — the API will use in-process rate limiting (single-process mode)."
  warn "Set NEXA_REDIS_URL= (empty) or start Redis before running several API processes."
fi

log "creating the ${APP_USER} system user"
if ! id -u "${APP_USER}" >/dev/null 2>&1; then
  useradd --system --create-home --home-dir "${APP_DIR}" --shell /usr/sbin/nologin "${APP_USER}"
fi
mkdir -p "${APP_DIR}"/{backend,frontend,uploads,backups,data,logs,run}
chown "${APP_USER}:${APP_USER}" "${APP_DIR}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"

log "copying the project into ${APP_DIR}"
# `.env`, the virtualenv and every runtime directory are preserved on purpose:
# re-running the installer is an upgrade, and it must never destroy data or secrets.
RSYNC_EXCLUDES=(
  --exclude '/.git/' --exclude '/node_modules/' --exclude '/frontend/node_modules/'
  --exclude '/frontend/dist/' --exclude '/.env' --exclude '/venv/' --exclude '/.venv/'
  --exclude '/data/' --exclude '/uploads/' --exclude '/backups/' --exclude '/logs/'
  --exclude '/run/' --exclude '/__pycache__/' --exclude '*.pyc'
)
TAR_EXCLUDES=(
  --exclude './.git' --exclude './node_modules' --exclude './frontend/node_modules'
  --exclude './frontend/dist' --exclude './.env' --exclude './venv' --exclude './.venv'
  --exclude './data' --exclude './uploads' --exclude './backups' --exclude './logs'
  --exclude './run' --exclude './__pycache__' --exclude '*.pyc'
)
if have rsync; then
  rsync -a --delete "${RSYNC_EXCLUDES[@]}" "${PROJECT_ROOT}/" "${APP_DIR}/"
else
  ( cd "${PROJECT_ROOT}" && tar cf - "${TAR_EXCLUDES[@]}" . ) | ( cd "${APP_DIR}" && tar xf - )
fi

log "configuring PostgreSQL role and database"
# A re-run is an upgrade: reuse the credentials the existing installation already uses,
# otherwise a freshly generated password would lock the running application out of its database.
if [[ -f "${APP_DIR}/.env" ]]; then
  EXISTING_URL="$(grep -E '^NEXA_DATABASE_URL=' "${APP_DIR}/.env" | tail -1 | cut -d= -f2- || true)"
  if [[ "${EXISTING_URL}" =~ ://([^:@/]+):([^@/]+)@ ]]; then
    DB_USER="${BASH_REMATCH[1]}"
    REUSED_PASSWORD="${BASH_REMATCH[2]}"
    if [[ "${REUSED_PASSWORD}" == *CHANGE_ME* || "${REUSED_PASSWORD}" == *changeme* || ${#REUSED_PASSWORD} -lt 8 ]]; then
      warn "the password inside ${APP_DIR}/.env is still a template placeholder — a new one is generated"
    else
      DB_PASSWORD="${REUSED_PASSWORD}"
      ok "reusing credentials from the existing ${APP_DIR}/.env (user ${DB_USER})"
    fi
  fi
fi
if ! sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='${DB_USER}'" 2>/dev/null | grep -q 1; then
  sudo -u postgres psql -c "CREATE ROLE ${DB_USER} LOGIN PASSWORD '${DB_PASSWORD//\'/\'\'}';" >/dev/null
  ok "created role ${DB_USER}"
fi
if ! sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'" 2>/dev/null | grep -q 1; then
  sudo -u postgres createdb -O "${DB_USER}" "${DB_NAME}"
  ok "created database ${DB_NAME}"
fi
# keep the stored password in sync with the one the application will use (idempotent)
sudo -u postgres psql -c "ALTER ROLE ${DB_USER} WITH LOGIN PASSWORD '${DB_PASSWORD//\'/\'\'}';" >/dev/null
# prove the credentials work over TCP before continuing
if ! PGPASSWORD="${DB_PASSWORD}" psql -h 127.0.0.1 -U "${DB_USER}" -d "${DB_NAME}" -tAc "SELECT 1" >/dev/null 2>&1; then
  die "the application role cannot connect to PostgreSQL over 127.0.0.1 — check pg_hba.conf (scram-sha-256) and listen_addresses"
fi
ok "database ${DB_NAME} is reachable with role ${DB_USER}"

SERVER_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
SERVER_IP="${SERVER_IP:-127.0.0.1}"
# every address this host answers on, plus loopback: a wildcard here is refused by the API
TRUSTED_HOSTS="$(hostname -I 2>/dev/null | tr ' ' '\n' | grep -v '^$' | paste -sd, -)"
TRUSTED_HOSTS="${TRUSTED_HOSTS:-${SERVER_IP}},localhost,127.0.0.1"

# ---------------------------------------------------------------------------
# Which address will a browser use?
# Not every host owns a public IPv4: cloud instances, containers, CGNAT and home connections
# answer on a private address and reach the Internet through NAT. Printing such an address as
# "the URL" hands the user a link that never opens, so the public address is detected here, the
# printed URL is built from it, and the check at the end of the install reports honestly whether
# it actually answers.
# ---------------------------------------------------------------------------
is_private_ipv4() { # 10/8, 172.16/12, 192.168/16, 100.64/10 (CGNAT), 169.254/16, 127/8
  local ip="$1"
  [[ "${ip}" =~ ^10\. ]] && return 0
  [[ "${ip}" =~ ^192\.168\. ]] && return 0
  [[ "${ip}" =~ ^172\.(1[6-9]|2[0-9]|3[01])\. ]] && return 0
  [[ "${ip}" =~ ^100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\. ]] && return 0
  [[ "${ip}" =~ ^169\.254\. ]] && return 0
  [[ "${ip}" =~ ^127\. ]] && return 0
  return 1
}

PUBLIC_IP="${NEXA_PUBLIC_IP:-}"
PUBLIC_IP_SOURCE="NEXA_PUBLIC_IP"
if [[ -z "${PUBLIC_IP}" ]] && have curl; then
  PUBLIC_IP_SOURCE="detected"
  for _service in https://api.ipify.org https://ifconfig.me/ip https://icanhazip.com; do
    PUBLIC_IP="$(curl -4 -fsS --max-time 6 "${_service}" 2>/dev/null | tr -d '[:space:]' || true)"
    if [[ "${PUBLIC_IP}" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
      break
    fi
    PUBLIC_IP=""
  done
fi

# Does this host answer on the address the Internet sees? If not it sits behind NAT and the
# port has to be forwarded/mapped by whoever runs that NAT before anyone else can connect.
HOST_IS_NAT=0
if [[ -n "${PUBLIC_IP}" ]]; then
  HOST_IS_NAT=1
  while IFS= read -r _ip; do
    if [[ -n "${_ip}" && "${_ip}" == "${PUBLIC_IP}" ]]; then
      HOST_IS_NAT=0
    fi
  done < <(hostname -I 2>/dev/null | tr ' ' '\n' | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' || true)
fi

# The address the user must type into a browser.
PUBLIC_HOST="${SERVER_IP}"
if [[ -n "${PUBLIC_IP}" ]]; then
  PUBLIC_HOST="${PUBLIC_IP}"
fi

if [[ "${ACCESS_MODE}" == "local" ]]; then
  : # nothing is published in local mode: a public address is neither needed nor checked
elif [[ -z "${PUBLIC_IP}" ]]; then
  warn "the public address of this host could not be determined (offline?); the installer will print the local address ${SERVER_IP} and say so"
elif [[ "${HOST_IS_NAT}" -eq 1 ]]; then
  warn "this host answers locally on ${SERVER_IP} (private) and reaches the Internet as ${PUBLIC_IP} — it sits behind NAT"
  warn "the printed URL uses ${PUBLIC_IP}; it only opens from another machine once inbound TCP ${PUBLIC_PORT} is forwarded/1:1-mapped to this host by whoever runs that NAT"
fi

# A request that arrives through a port-forward carries Host: <public address>, so the public
# address has to be trusted too — otherwise the API answers 400 "Invalid host header".
if [[ -n "${PUBLIC_IP}" && ",${TRUSTED_HOSTS}," != *",${PUBLIC_IP},"* ]]; then
  TRUSTED_HOSTS="${TRUSTED_HOSTS},${PUBLIC_IP}"
fi

# ---------------------------------------------------------------------------
# What the chosen access mode means for the application.
# One place decides the public URL, the deployment mode, the cookie/HSTS flags, the CORS origins
# and the trusted hosts, so the .env file, the Nginx site, the reachability check and the final
# summary can never disagree with each other.
#
# ACCESS_HTTPS is set later: after Nginx is configured the installer looks for a certificate (or
# has certbot issue one) and only then flips this to 1 — an install must never claim HTTPS that
# does not exist yet.
# ---------------------------------------------------------------------------
ACCESS_HTTPS=0

compute_access_values() {
  case "${ACCESS_MODE}" in
    local)
      # No Nginx in this mode, so the application answers on the API port itself — printing
      # ${PUBLIC_PORT} here would hand the operator a link that never opens.
      ACCESS_DEPLOYMENT_MODE="local"
      ACCESS_BASE_URL="http://127.0.0.1:${API_PORT}"
      ACCESS_COOKIE_SECURE="false"
      ACCESS_HSTS="false"
      ACCESS_ORIGINS="http://127.0.0.1:${API_PORT},http://localhost:${API_PORT}"
      ACCESS_URL="http://127.0.0.1:${API_PORT}"
      ACCESS_URL_LABEL="this machine only"
      ;;
    domain)
      if [[ "${ACCESS_HTTPS}" -eq 1 ]]; then
        ACCESS_DEPLOYMENT_MODE="domain_https"
        ACCESS_BASE_URL="https://${DOMAIN}"
        ACCESS_COOKIE_SECURE="true"
        ACCESS_HSTS="true"
        ACCESS_ORIGINS="https://${DOMAIN},http://${DOMAIN}"
        ACCESS_URL="https://${DOMAIN}"
        ACCESS_URL_LABEL="https, certificate in place"
      else
        # No certificate (yet). Say so honestly instead of pretending: the app runs in public_ip
        # mode, over plain HTTP on the domain, and the UI keeps showing its security warning.
        ACCESS_DEPLOYMENT_MODE="public_ip"
        ACCESS_BASE_URL="http://${DOMAIN}"
        ACCESS_COOKIE_SECURE="false"
        ACCESS_HSTS="false"
        ACCESS_ORIGINS="http://${DOMAIN},http://${PUBLIC_HOST}:${PUBLIC_PORT}"
        ACCESS_URL="http://${DOMAIN}"
        ACCESS_URL_LABEL="no certificate yet — plain HTTP on the domain"
      fi
      ;;
    *)
      ACCESS_DEPLOYMENT_MODE="public_ip"
      ACCESS_BASE_URL="http://${PUBLIC_HOST}:${PUBLIC_PORT}"
      ACCESS_COOKIE_SECURE="false"
      ACCESS_HSTS="false"
      if [[ "${PUBLIC_HOST}" == "${SERVER_IP}" ]]; then
        ACCESS_ORIGINS="http://${SERVER_IP}:${PUBLIC_PORT}"
      else
        ACCESS_ORIGINS="http://${PUBLIC_HOST}:${PUBLIC_PORT},http://${SERVER_IP}:${PUBLIC_PORT}"
      fi
      ACCESS_URL="http://${PUBLIC_HOST}:${PUBLIC_PORT}"
      ACCESS_URL_LABEL="public ip"
      ;;
  esac

  ACCESS_TRUSTED="${TRUSTED_HOSTS}"
  for _extra in "${PUBLIC_IP:-}" "${DOMAIN:-}" "${PUBLIC_HOST:-}"; do
    [[ -n "${_extra}" ]] || continue
    [[ ",${ACCESS_TRUSTED}," == *",${_extra},"* ]] || ACCESS_TRUSTED="${ACCESS_TRUSTED},${_extra}"
  done
}

# A certificate may already exist (certbot ran before, or the operator installed one): detect it
# here so the very first write of .env already carries the HTTPS settings — otherwise the mode
# would flip after Nginx is configured and the services would restart twice.
if [[ "${ACCESS_MODE}" == "domain" && -f "/etc/letsencrypt/live/${DOMAIN}/fullchain.pem" && \
      -f "/etc/letsencrypt/live/${DOMAIN}/privkey.pem" ]]; then
  SSL_CERT="/etc/letsencrypt/live/${DOMAIN}/fullchain.pem"
  SSL_KEY="/etc/letsencrypt/live/${DOMAIN}/privkey.pem"
  ACCESS_HTTPS=1
fi

compute_access_values

env_value() { # $1 file, $2 key -> prints the last value, empty when unset
  grep -E "^$2=" "$1" 2>/dev/null | tail -1 | cut -d= -f2- || true
}

env_backup() { # $1 file -> keeps one timestamped copy before the first change
  local file="$1"
  if [[ -z "${ENV_BACKUP_DONE:-}" ]]; then
    ENV_BACKUP="${file}.bak.$(date -u +%Y%m%dT%H%M%SZ)"
    cp -a "${file}" "${ENV_BACKUP}"
    ENV_BACKUP_DONE=1
  fi
}

set_env_value() { # $1 file, $2 key, $3 value (single line, no quoting needed)
  local file="$1" key="$2" value="$3" tmp
  tmp="$(mktemp)"
  if grep -qE "^${key}=" "${file}"; then
    awk -v k="${key}" -v v="${value}" 'BEGIN { FS = OFS = "=" } $1 == k { print k"="v; next } { print }' \
      "${file}" > "${tmp}"
  else
    cat "${file}" > "${tmp}"
    printf '%s=%s\n' "${key}" "${value}" >> "${tmp}"
  fi
  cat "${tmp}" > "${file}"
  rm -f "${tmp}"
}

# The API refuses to start when a secret is empty, a known placeholder or shorter than 16
# characters (see app/core/config.py: PLACEHOLDER_MARKERS); mirror that rule here.
secret_needs_replacement() { # $1 = value
  local value="$1"
  [[ -n "${value}" ]] || return 0
  [[ "${#value}" -lt 16 ]] && return 0
  printf '%s' "${value}" | grep -qiE 'change[_-]?me|your-secret|example\.com|placeholder|insecure' && return 0
  return 1
}

strip_inline_comments() { # $1 file — python-dotenv does NOT strip "# comment" after a value,
  # which makes pydantic fail with "unable to interpret input" errors at startup.
  local file="$1" tmp
  tmp="$(mktemp)"
  awk '
    {
      line = $0
      if (line ~ /^[A-Za-z_][A-Za-z0-9_]*=[^ \t]+[ \t]+#/) {
        sub(/[ \t]+#.*$/, "", line)
        print line
        next
      }
      print
    }' "${file}" > "${tmp}"
  if ! cmp -s "${file}" "${tmp}"; then
    env_backup "${file}"
    cat "${tmp}" > "${file}"
    INLINE_COMMENTS_STRIPPED=1
    warn "removed trailing '# comment' texts from value lines in ${file} (the API reads them literally and refuses to start)"
  fi
  rm -f "${tmp}"
}

repair_env() { # bring values written by other versions/templates up to our requirements
  local file="${APP_DIR}/.env"
  [[ -f "${file}" ]] || return 0
  local changed=0 value
  strip_inline_comments "${file}"
  [[ "${INLINE_COMMENTS_STRIPPED:-0}" -eq 1 ]] && changed=1

  if grep -qE '^NEXA_TRUSTED_HOSTS=\*[[:space:]]*$' "${file}"; then
    env_backup "${file}"
    set_env_value "${file}" NEXA_TRUSTED_HOSTS "${TRUSTED_HOSTS}"
    changed=1
    warn "replaced the wildcard NEXA_TRUSTED_HOSTS with ${TRUSTED_HOSTS} (a wildcard is refused in production)"
  fi

  value="$(env_value "${file}" NEXA_SECRET_KEY)"
  if secret_needs_replacement "${value}"; then
    env_backup "${file}"
    set_env_value "${file}" NEXA_SECRET_KEY "$(openssl rand -base64 48 | tr -d '\n')"
    changed=1
    warn "NEXA_SECRET_KEY was missing/placeholder — generated a real one (existing sessions are invalidated)"
  fi

  value="$(env_value "${file}" NEXA_ENCRYPTION_KEY)"
  if secret_needs_replacement "${value}"; then
    env_backup "${file}"
    set_env_value "${file}" NEXA_ENCRYPTION_KEY "$(openssl rand -base64 32 | tr '+/' '-_' | tr -d '\n')"
    changed=1
    warn "NEXA_ENCRYPTION_KEY was missing/placeholder — generated a real one"
    warn "provider credentials stored with the old key can no longer be decrypted; re-enter them in Admin → Providers"
  fi

  value="$(env_value "${file}" NEXA_DATABASE_URL)"
  if [[ "${value}" == *CHANGE_ME* || "${value}" == *"@db:5432/"* || "${value}" == *"@db/"* ]]; then
    env_backup "${file}"
    set_env_value "${file}" NEXA_DATABASE_URL \
      "postgresql+psycopg2://${DB_USER}:${DB_PASSWORD}@127.0.0.1:5432/${DB_NAME}"
    changed=1
    warn "NEXA_DATABASE_URL was a template value (placeholder password or the Docker host 'db') — set to the local PostgreSQL"
  fi

  # Both the address a browser outside uses and the local one are accepted, so the app works
  # whether it is opened through the public address, the LAN address or 127.0.0.1.
  if [[ "${PUBLIC_HOST}" == "${SERVER_IP}" ]]; then
    ORIGINS="${ACCESS_ORIGINS}"
  else
    ORIGINS="${ACCESS_ORIGINS}"
  fi

  value="$(env_value "${file}" NEXA_PUBLIC_BASE_URL)"
  if [[ "${value}" == *CHANGE_ME* || "${value}" == *example.com* || -z "${value}" ]] \
     || { [[ "${HOST_IS_NAT}" -eq 1 ]] && [[ "${value}" == "http://${SERVER_IP}:${PUBLIC_PORT}" ]]; }; then
    env_backup "${file}"
    set_env_value "${file}" NEXA_PUBLIC_BASE_URL "http://${PUBLIC_HOST}:${PUBLIC_PORT}"
    changed=1
    warn "NEXA_PUBLIC_BASE_URL was a template or local-only value — set to http://${PUBLIC_HOST}:${PUBLIC_PORT}"
  fi

  value="$(env_value "${file}" NEXA_CORS_ORIGINS)"
  if [[ "${value}" == *CHANGE_ME* || -z "${value}" ]] \
     || { [[ "${HOST_IS_NAT}" -eq 1 ]] && [[ "${value}" == "http://${SERVER_IP}:${PUBLIC_PORT}" ]]; }; then
    env_backup "${file}"
    set_env_value "${file}" NEXA_CORS_ORIGINS "${ORIGINS}"
    changed=1
    warn "NEXA_CORS_ORIGINS was a template or local-only value — set to ${ORIGINS}"
  fi

  # The public address belongs in TRUSTED_HOSTS as well: a browser that reaches the app through
  # a port-forward sends Host: <public address>, and the API refuses unknown hosts.
  value="$(env_value "${file}" NEXA_TRUSTED_HOSTS)"
  if [[ -n "${PUBLIC_IP}" && "${value}" != "*" && ",${value}," != *",${PUBLIC_IP},"* ]]; then
    env_backup "${file}"
    set_env_value "${file}" NEXA_TRUSTED_HOSTS "${value},${PUBLIC_IP}"
    changed=1
    warn "NEXA_TRUSTED_HOSTS did not contain the public address ${PUBLIC_IP} — added it (a request through a port-forward sends Host: ${PUBLIC_IP})"
  fi

  # Deployment metadata: the address a browser outside this machine has to use. Pinned by hand
  # when the outbound address is not the reachable one (double NAT, CGNAT, a proxy).
  if [[ -n "${PUBLIC_IP}" && -z "$(env_value "${file}" NEXA_PUBLIC_IP)" ]]; then
    env_backup "${file}"
    set_env_value "${file}" NEXA_PUBLIC_IP "${PUBLIC_IP}"
    changed=1
  fi

  value="$(env_value "${file}" NEXA_PUBLIC_PORT)"
  if [[ -z "${value}" || ! "${value}" =~ ^[0-9]+$ ]]; then
    env_backup "${file}"
    set_env_value "${file}" NEXA_PUBLIC_PORT "${PUBLIC_PORT}"
    changed=1
  fi

  # ---- values that only make sense inside the Docker network -------------------
  # A .env copied from deployment/.env.production.example points at /app and the
  # service names "db"/"redis". On a native install that breaks file storage and
  # Redis access, so those paths are re-pointed at this installation.
  value="$(env_value "${file}" NEXA_UPLOAD_DIR)"
  if [[ -z "${value}" || "${value}" == /app/* || "${value}" == /app ]]; then
    env_backup "${file}"
    set_env_value "${file}" NEXA_UPLOAD_DIR "${APP_DIR}/uploads"
    changed=1
    warn "NEXA_UPLOAD_DIR was a container path ('${value:-unset}') — set to ${APP_DIR}/uploads"
  fi

  value="$(env_value "${file}" NEXA_FRONTEND_DIST_DIR)"
  if [[ -z "${value}" || "${value}" == /app/* ]]; then
    env_backup "${file}"
    set_env_value "${file}" NEXA_FRONTEND_DIST_DIR "${APP_DIR}/frontend/dist"
    changed=1
    warn "NEXA_FRONTEND_DIST_DIR was a container path — set to ${APP_DIR}/frontend/dist"
  fi

  value="$(env_value "${file}" NEXA_SERVE_FRONTEND)"
  if [[ -z "${value}" ]]; then
    env_backup "${file}"
    set_env_value "${file}" NEXA_SERVE_FRONTEND true
    changed=1
  fi

  # A template password (CHANGE_ME...) is a known credential: on a public IP that is an open
  # door, so it is replaced and the account is re-pointed at the new value further down.
  value="$(env_value "${file}" NEXA_BOOTSTRAP_ADMIN_PASSWORD)"
  if [[ -z "${value}" ]] || printf '%s' "${value}" | grep -qiE 'change[_-]?me|your-password|password123|placeholder'; then
    env_backup "${file}"
    set_env_value "${file}" NEXA_BOOTSTRAP_ADMIN_PASSWORD "$(openssl rand -base64 18 | tr -d '\n' | tr -d '/+=' )Aa1"
    changed=1
    ADMIN_PASSWORD_ROTATED=1
    warn "NEXA_BOOTSTRAP_ADMIN_PASSWORD was a template placeholder — a strong password was generated"
    warn "the administrator account will be reset to it after the services restart (audit-logged)"
  fi

  value="$(env_value "${file}" NEXA_REDIS_URL)"
  if [[ "${value}" == redis://redis:* || "${value}" == *"//redis:6379"* ]]; then
    env_backup "${file}"
    set_env_value "${file}" NEXA_REDIS_URL "redis://127.0.0.1:6379/0"
    changed=1
    warn "NEXA_REDIS_URL pointed at the Docker service name 'redis' — set to 127.0.0.1"
  fi

  value="$(env_value "${file}" NEXA_ENVIRONMENT)"
  if [[ -z "${value}" ]]; then
    env_backup "${file}"
    set_env_value "${file}" NEXA_ENVIRONMENT production
    changed=1
    warn "NEXA_ENVIRONMENT was unset — set it to production"
  fi

  if [[ "${changed}" -eq 1 ]]; then
    chmod 600 "${file}"
    ok "existing ${file} updated for this version (previous file kept as ${ENV_BACKUP})"
  fi
  return 0
}

# ---------------------------------------------------------------------------
# sync_access_env — write the operator's access choices into an existing .env.
#
# Two call sites: (1) directly after the answers are known, so a re-run with --access/--domain
# switches an existing installation instead of being silently ignored; (2) once the certificate
# question is settled, because HTTPS changes the deployment mode, the cookie flags and HSTS.
# Everything is backed up first and only the keys this installer owns are touched.
# ---------------------------------------------------------------------------
sync_access_env() { # sync_access_env <file> [force]
  local file="$1" force="${2:-0}" changed=0
  local -a keys values
  keys=(NEXA_DEPLOYMENT_MODE NEXA_PUBLIC_BASE_URL NEXA_PUBLIC_PORT NEXA_PUBLIC_IP NEXA_COOKIE_SECURE
        NEXA_HSTS_ENABLED NEXA_CORS_ORIGINS NEXA_TRUSTED_HOSTS)
  values=("${ACCESS_DEPLOYMENT_MODE}" "${ACCESS_BASE_URL}" "${PUBLIC_PORT}" "${PUBLIC_IP}"
          "${ACCESS_COOKIE_SECURE}" "${ACCESS_HSTS}" "${ACCESS_ORIGINS}" "${ACCESS_TRUSTED}")

  local i key value current
  for i in "${!keys[@]}"; do
    key="${keys[$i]}"; value="${values[$i]}"
    [[ -n "${value}" ]] || continue
    current="$(env_value "${file}" "${key}")"
    if [[ "${current}" == "${value}" ]]; then
      continue
    fi
    # force=1 is used when the operator asked for a mode (or HTTPS became available); otherwise a
    # hand-edited value is preserved and only a missing/placeholder one is filled in.
    if [[ "${force}" -eq 1 ]] || [[ -z "${current}" ]] || printf '%s' "${current}" | grep -qE 'CHANGE_ME|localhost:8080|placeholder'; then
      env_backup "${file}"
      set_env_value "${file}" "${key}" "${value}"
      changed=1
      [[ "${force}" -eq 1 && -n "${current}" ]] && warn "${key}: ${current} -> ${value}"
    fi
  done

  # Administrator credentials: only when the operator supplied or chose them.
  if [[ -n "${ADMIN_PASSWORD_INPUT}" ]]; then
    current="$(env_value "${file}" NEXA_BOOTSTRAP_ADMIN_PASSWORD)"
    if [[ "${current}" != "${ADMIN_PASSWORD_INPUT}" ]]; then
      env_backup "${file}"
      set_env_value "${file}" NEXA_BOOTSTRAP_ADMIN_PASSWORD "${ADMIN_PASSWORD_INPUT}"
      changed=1
      ADMIN_PASSWORD_ROTATED=1
      ok "the administrator password has been set to the one you chose (audit-logged reset below)"
    fi
  fi
  local requested_email="${ADMIN_EMAIL_REQUESTED:-${ADMIN_EMAIL}}"
  if [[ -n "${requested_email}" ]]; then
    current="$(env_value "${file}" NEXA_BOOTSTRAP_ADMIN_EMAIL)"
    if [[ -n "${current}" && "${current}" != "${requested_email}" ]]; then
      # sync_access_env runs twice (before and after the certificate question): say it once.
      if [[ "${ADMIN_EMAIL_WARNED:-0}" -eq 0 ]]; then
        warn "this installation's administrator is ${current}; ${requested_email} was NOT applied"
        warn "  (create another administrator from the admin panel, or start from a fresh database)"
        ADMIN_EMAIL_WARNED=1
      fi
      ADMIN_EMAIL="${current}"
    elif [[ -z "${current}" ]]; then
      env_backup "${file}"
      set_env_value "${file}" NEXA_BOOTSTRAP_ADMIN_EMAIL "${requested_email}"
      changed=1
    fi
  fi
  if [[ -n "${ADMIN_NAME}" ]]; then
    current="$(env_value "${file}" NEXA_BOOTSTRAP_ADMIN_NAME)"
    if [[ -z "${current}" ]]; then
      env_backup "${file}"
      set_env_value "${file}" NEXA_BOOTSTRAP_ADMIN_NAME "${ADMIN_NAME}"
      changed=1
    fi
  fi

  if [[ "${changed}" -eq 1 ]]; then
    chmod 600 "${file}"
    chown "${APP_USER}:${APP_USER}" "${file}" 2>/dev/null || true
    ok "access settings updated in ${file} (previous file kept as ${ENV_BACKUP:-a .env.bak.<stamp> file})"
    return 0
  fi
  return 1
}

if [[ "${RESET_ENV}" -eq 1 && -f "${APP_DIR}/.env" ]]; then
  RESET_BACKUP="${APP_DIR}/.env.bak.$(date -u +%Y%m%dT%H%M%SZ)"
  cp -a "${APP_DIR}/.env" "${RESET_BACKUP}"
  rm -f "${APP_DIR}/.env"
  warn "--reset-env: previous .env kept as ${RESET_BACKUP}; a fresh one will be generated"
fi

if [[ ! -f "${APP_DIR}/.env" ]]; then
  log "creating ${APP_DIR}/.env"
  SECRET_KEY="$(openssl rand -base64 48 | tr -d '\n')"
  ENCRYPTION_KEY="$(openssl rand -base64 32 | tr '+/' '-_' | tr -d '\n')"
  ADMIN_PASSWORD="${ADMIN_PASSWORD_INPUT:-$(openssl rand -base64 18 | tr -d '\n' | tr -d '/+=' )Aa1}"
  ADMIN_PASSWORD_WAS_CHOSEN=0
  [[ -n "${ADMIN_PASSWORD_INPUT}" ]] && ADMIN_PASSWORD_WAS_CHOSEN=1
  cat > "${APP_DIR}/.env" <<ENVEOF
NEXA_APP_NAME="Nexa AI"
NEXA_ENVIRONMENT=production
NEXA_DEPLOYMENT_MODE=${ACCESS_DEPLOYMENT_MODE}
NEXA_PUBLIC_BASE_URL=${ACCESS_BASE_URL}
NEXA_PUBLIC_PORT=${PUBLIC_PORT}
NEXA_PUBLIC_IP=${PUBLIC_IP}
NEXA_LOG_LEVEL=INFO
NEXA_LOG_JSON=true
NEXA_SECRET_KEY=${SECRET_KEY}
NEXA_ENCRYPTION_KEY=${ENCRYPTION_KEY}
NEXA_DATABASE_URL=postgresql+psycopg2://${DB_USER}:${DB_PASSWORD}@127.0.0.1:5432/${DB_NAME}
NEXA_REDIS_URL=redis://127.0.0.1:6379/0
NEXA_USE_REDIS_RATE_LIMIT=true
NEXA_CORS_ORIGINS=${ACCESS_ORIGINS:-http://${SERVER_IP}:${PUBLIC_PORT}}
NEXA_COOKIE_SECURE=${ACCESS_COOKIE_SECURE}
NEXA_HSTS_ENABLED=${ACCESS_HSTS}
NEXA_TRUSTED_HOSTS=${ACCESS_TRUSTED}
NEXA_BOOTSTRAP_ADMIN_EMAIL=${ADMIN_EMAIL}
NEXA_BOOTSTRAP_ADMIN_NAME=${ADMIN_NAME}
NEXA_BOOTSTRAP_ADMIN_PASSWORD=${ADMIN_PASSWORD}
NEXA_UPLOAD_DIR=${APP_DIR}/uploads
NEXA_SERVE_FRONTEND=true
NEXA_FRONTEND_DIST_DIR=${APP_DIR}/frontend/dist
NEXA_INLINE_WORKER=false
NEXA_MANUAL_PAYMENTS_ENABLED=true
NEXA_EMAIL_ENABLED=false
ENVEOF
  chmod 600 "${APP_DIR}/.env"
  if [[ "${ADMIN_PASSWORD_WAS_CHOSEN}" -eq 1 ]]; then
    ok "administrator account: ${ADMIN_EMAIL} (with the password you chose — nothing else to change)"
  else
    ok "administrator account: ${ADMIN_EMAIL} (a strong password was generated; it is stored in ${APP_DIR}/.env)"
  fi
else
  warn "${APP_DIR}/.env already exists — keeping your settings (data, secrets and services are preserved)"
  repair_env
  # The operator's answers still win: an explicitly requested access mode, a new password or a
  # different administrator e-mail are applied to the existing file (with a backup) further down,
  # once the certificate question is settled, by sync_access_env.
fi

# From here on the .env file is the source of truth for the administrator credentials — but the
# operator's own request must not be forgotten silently: keep it, so sync_access_env can tell them
# when it cannot be honoured (an existing installation keeps its administrator).
ENV_ADMIN_EMAIL="$(env_value "${APP_DIR}/.env" NEXA_BOOTSTRAP_ADMIN_EMAIL)"
ADMIN_EMAIL_REQUESTED=""
if [[ -n "${ADMIN_EMAIL}" && -n "${ENV_ADMIN_EMAIL}" && "${ADMIN_EMAIL}" != "${ENV_ADMIN_EMAIL}" ]]; then
  ADMIN_EMAIL_REQUESTED="${ADMIN_EMAIL}"
fi
ADMIN_EMAIL="${ENV_ADMIN_EMAIL:-${ADMIN_EMAIL}}"
ADMIN_PASSWORD="$(env_value "${APP_DIR}/.env" NEXA_BOOTSTRAP_ADMIN_PASSWORD)"
if [[ -z "${ADMIN_PASSWORD}" ]]; then
  warn "${APP_DIR}/.env has no NEXA_BOOTSTRAP_ADMIN_PASSWORD — the sign-in self-check will be skipped"
fi

log "preparing the Python environment"
if [[ -n "${PYTHON_REQUESTED:-}" ]] && ! python_supported "${PYTHON_REQUESTED}"; then
  die "--python ${PYTHON_REQUESTED} is Python $(python_version_of "${PYTHON_REQUESTED}" || echo unknown); this release supports ${SUPPORTED_PYTHON} (the pinned pydantic/pydantic-core wheels stop at 3.13)"
fi
PYTHON_PATH="$(select_python)" || true
if [[ -z "${PYTHON_PATH:-}" ]]; then
  warn "no supported Python (${SUPPORTED_PYTHON}) found — looking for one to install"
  apt-get install -y python3 python3-venv >/dev/null 2>&1 || true   # older distributions
  PYTHON_PATH="$(select_python || true)"
fi
if [[ -z "${PYTHON_PATH:-}" ]]; then
  try_distro_python_packages || warn "the distribution has no ${SUPPORTED_PYTHON} package"
  PYTHON_PATH="$(select_python || true)"
fi
if [[ -z "${PYTHON_PATH:-}" ]]; then
  try_deadsnakes || warn "the deadsnakes PPA is not usable here"
  PYTHON_PATH="$(select_python || true)"
fi
if [[ -z "${PYTHON_PATH:-}" ]]; then
  try_uv_python || warn "uv could not provide a Python ${SUPPORTED_PYTHON} either"
fi
if [[ -z "${PYTHON_PATH:-}" ]]; then
  cat >&2 <<PYERR
[error] no supported Python interpreter found (need ${SUPPORTED_PYTHON}).

  "python3" in your PATH is : $(command -v python3 || echo none) ($(python_version_of "$(command -v python3)" || echo unknown))
  Distribution python      : /usr/bin/python3 ($(python_version_of /usr/bin/python3 || echo absent))

Newer runtimes (3.14+) cannot build the pinned pydantic-core wheels without a Rust
toolchain, so this release targets ${SUPPORTED_PYTHON}. This machine has none, and the automatic
routes above did not find one either (no versioned package, no deadsnakes, uv unavailable — usually
a missing network path). Fix it with whichever line fits:

  sudo apt-get install -y python3.13 python3.13-venv           # Debian 13, Ubuntu 25.10+
  sudo add-apt-repository -y ppa:deadsnakes/ppa && sudo apt-get install -y python3.13 python3.13-venv
  curl -LsSf https://astral.sh/uv/install.sh | sudo sh && \
    sudo env UV_PYTHON_INSTALL_DIR=/opt/nexa-python /root/.local/bin/uv python install 3.13 && \
    sudo bash deployment/linux/install.sh --python /opt/nexa-python/cpython-3.13-linux-x86_64-gnu/bin/python3.13

If you must stay on 3.14, use the Docker route instead (docker compose up -d --build),
which pins Python inside the image.
PYERR
  exit 1
fi
PYTHON_VER="$(python_version_of "${PYTHON_PATH}")"
log "using Python ${PYTHON_VER} (${PYTHON_PATH})"

chown -R "${APP_USER}:${APP_USER}" "${APP_DIR}"
if [[ -x "${APP_DIR}/venv/bin/python" ]]; then
  VENV_VER="$(python_version_of "${APP_DIR}/venv/bin/python" || true)"
  if [[ "${VENV_VER}" != "${PYTHON_VER}" ]]; then
    warn "the existing virtualenv uses Python ${VENV_VER:-unknown} — recreating it with ${PYTHON_VER}"
    rm -rf "${APP_DIR}/venv"
  fi
fi
if [[ ! -x "${APP_DIR}/venv/bin/python" ]]; then
  sudo -u "${APP_USER}" "${PYTHON_PATH}" -m venv "${APP_DIR}/venv"
fi
sudo -u "${APP_USER}" "${APP_DIR}/venv/bin/pip" install --upgrade pip wheel >/dev/null
sudo -u "${APP_USER}" "${APP_DIR}/venv/bin/pip" install -r "${APP_DIR}/backend/requirements.txt"
ok "python dependencies installed"

if [[ "${BUILD_FRONTEND}" -eq 1 ]]; then
  log "building the frontend"
  if command -v npm >/dev/null 2>&1; then
    ( cd "${APP_DIR}/frontend" && npm install --no-audit --no-fund && npm run build )
    ok "SPA built into ${APP_DIR}/frontend/dist"
  else
    warn "npm is not installed: the API cannot serve the web interface yet."
    warn "Install Node.js 20 (https://nodejs.org) and run:"
    warn "  cd ${APP_DIR}/frontend && npm install && npm run build"
  fi
fi

# The interface is part of the deliverable: a deployment whose SPA shell is missing answers 500
# on every page. Refuse to finish instead of leaving a site nobody can use (this is what a
# `--no-node` re-run hit on a machine whose frontend/dist had been removed).
if [[ ! -f "${APP_DIR}/frontend/dist/index.html" ]]; then
  die "the front-end bundle is missing: ${APP_DIR}/frontend/dist/index.html
  fix:   cd ${APP_DIR}/frontend && npm install && npm run build
  or:    re-run this installer without --no-node (it installs Node.js 20 and builds the SPA)
  The database, .env and uploads are untouched."
fi
ok "front-end bundle present (${APP_DIR}/frontend/dist/index.html)"

log "checking the configuration (pre-flight)"
DOCTOR_JSON="$( cd "${APP_DIR}/backend" && sudo -u "${APP_USER}" -E "${APP_DIR}/venv/bin/python" -m app.cli doctor 2>/dev/null || true )"
PROBLEMS="$( printf '%s' "${DOCTOR_JSON}" | "${APP_DIR}/venv/bin/python" -c \
  'import json,sys
try:
    data = json.load(sys.stdin)
except Exception:
    sys.exit(0)
for problem in data.get("production_problems") or []:
    print("  - " + problem)' 2>/dev/null || true )"
if [[ -n "${PROBLEMS}" ]]; then
  printf '[error] this configuration would make the API refuse to start:\n%s\n' "${PROBLEMS}" >&2
  cat >&2 <<REMEDY
[error] Most of these come from an .env that was copied from a template or written by another
        version. Choose one:

  * let this installer repair it (recommended, keeps your database and the rest of the file):
        sudo bash deployment/linux/install.sh          # repairs placeholders automatically

  * generate a completely fresh .env (the old file is backed up next to it):
        sudo bash deployment/linux/install.sh --reset-env

  * inspect the file yourself:
        sudo nano ${APP_DIR}/.env

        The API rejects: empty secrets, values containing CHANGE_ME/changeme/your-secret/
        example.com, values shorter than 16 characters, SQLite in production mode and a
        wildcard NEXA_TRUSTED_HOSTS. See docs/PRODUCTION_DEPLOYMENT.md.
REMEDY
  exit 1
fi
ok "configuration accepted by the application"

# An explicitly requested access mode (flags or the wizard) is applied to an existing .env before
# the services start, so the running configuration matches what was just answered.
if [[ "${ACCESS_EXPLICIT}" -eq 1 && -f "${APP_DIR}/.env" ]]; then
  sync_access_env "${APP_DIR}/.env" 1 || true
  ADMIN_PASSWORD="$(env_value "${APP_DIR}/.env" NEXA_BOOTSTRAP_ADMIN_PASSWORD)"
fi

log "running database migrations and bootstrap"
# The application reads ${APP_DIR}/.env itself (pydantic-settings env_file).
# Sourcing a hand-edited .env from bash is fragile, so the installer never does it.
( cd "${APP_DIR}/backend" && sudo -u "${APP_USER}" -E "${APP_DIR}/venv/bin/python" -m alembic upgrade head )
BOOTSTRAP_JSON="$( cd "${APP_DIR}/backend" && sudo -u "${APP_USER}" -E "${APP_DIR}/venv/bin/python" -m app.cli bootstrap )"
# The CLI logs to stdout as well as printing the JSON report, and the log line contains a Python
# dict — so the report is found by scanning for a JSON object that carries `super_admin`
# (deployment/linux/bootstrap_report.py, unit-tested in tests/deployment/test_bootstrap_report.py).
BOOTSTRAP_REPORT_PY="${PROJECT_ROOT}/deployment/linux/bootstrap_report.py"
ADMIN_CREATED="$( printf '%s' "${BOOTSTRAP_JSON}" | "${APP_DIR}/venv/bin/python" "${BOOTSTRAP_REPORT_PY}" created 2>/dev/null || echo unparsed )"

# A rejected administrator (an address the sign-in endpoint would refuse, e.g. a reserved
# `…@something.test` domain, or a password that fails the policy) must stop the install right here:
# continuing would leave a deployment nobody can sign in to.
BOOTSTRAP_REASON="$( printf '%s' "${BOOTSTRAP_JSON}" | "${APP_DIR}/venv/bin/python" "${BOOTSTRAP_REPORT_PY}" reason 2>/dev/null || echo "" )"
case "${BOOTSTRAP_REASON}" in
  *"e-mail rejected"*|*"password rejected"*)
    die "${BOOTSTRAP_REASON} Re-run with --admin-email you@your-domain.com --admin-password '…'" ;;
esac

SERVICE_MODE="systemd"
if systemd_usable; then
  log "installing systemd units"
  sed "s|__APP_DIR__|${APP_DIR}|g; s|__APP_USER__|${APP_USER}|g" \
    "${PROJECT_ROOT}/deployment/linux/nexa-api.service" > /etc/systemd/system/nexa-api.service
  sed "s|__APP_DIR__|${APP_DIR}|g; s|__APP_USER__|${APP_USER}|g" \
    "${PROJECT_ROOT}/deployment/linux/nexa-worker.service" > /etc/systemd/system/nexa-worker.service
  systemctl daemon-reload
  systemctl enable --now nexa-api.service nexa-worker.service
  ok "nexa-api and nexa-worker are running under systemd"
else
  SERVICE_MODE="launcher"
  warn "systemd is not available in this environment (container?) — starting the services with"
  warn "deployment/linux/nexa-services.sh instead (PID files in ${APP_DIR}/run, logs in ${APP_DIR}/logs)."
  bash "${APP_DIR}/deployment/linux/nexa-services.sh" restart || die "could not start the API/worker"
  ok "nexa-api and nexa-worker are running in the background"
  # systemd gives us Restart=always; without it a process that dies would stay dead and the site
  # would be down until somebody logged in. A one-line cron entry restores that guarantee.
  if ! have crontab; then
    # cron is a few hundred kilobytes and is what restores Restart=always on a systemd-less host.
    log "installing cron (needed to restart the services automatically)"
    DEBIAN_FRONTEND=noninteractive apt-get install -y cron >/dev/null 2>&1 || true
    ( service cron start >/dev/null 2>&1 || /etc/init.d/cron start >/dev/null 2>&1 || true )
  fi
  if have crontab; then
    KEEPALIVE_LINE="@reboot ${APP_DIR}/deployment/linux/nexa-services.sh start # nexa-keepalive-boot"
    KEEPALIVE_MINUTE="*/2 * * * * ${APP_DIR}/deployment/linux/nexa-services.sh keepalive >/dev/null 2>&1 # nexa-keepalive"
    ( crontab -l 2>/dev/null | grep -v "nexa-keepalive" || true; echo "${KEEPALIVE_MINUTE}"; echo "${KEEPALIVE_LINE}" ) | crontab - \
      && ok "auto-restart scheduled (cron: nexa-services.sh keepalive every 2 minutes)" \
      || warn "could not add the auto-restart cron entry — run 'crontab -e' and add: ${KEEPALIVE_MINUTE}"
  else
    warn "cron is not installed, so a crashed service will NOT restart by itself."
    warn "Install cron (apt-get install cron) or run: ${APP_DIR}/deployment/linux/nexa-services.sh keepalive"
  fi
fi

chown -R "${APP_USER}:${APP_USER}" "${APP_DIR}" || true

# ---------------------------------------------------------------------------
# Nginx site + the certificate question.
#
# Three shapes, all rendered from a template in deployment/nginx/:
#   local  : no Nginx at all — the API stays on 127.0.0.1:8000
#   public : nexa-host.conf          (this host's IP on __PUBLIC_PORT__)
#   domain : nexa-domain-http.conf   (the domain on port 80, ACME path ready)
#            nexa-domain-https.conf  (the same domain on 443, after a certificate exists)
# ---------------------------------------------------------------------------
SSL_CERT=""
SSL_KEY=""
DNS_IP=""
nginx_reload() {
  if nginx -t >/dev/null 2>&1; then
    if systemd_usable; then
      systemctl enable nginx >/dev/null 2>&1 || true
      systemctl restart nginx || systemctl reload nginx || nginx
    else
      (service nginx start || nginx) >/dev/null 2>&1 || true
    fi
    return 0
  fi
  nginx -t || true
  return 1
}

nginx_supports_http2_directive() { # `http2 on;` exists only on nginx >= 1.25.1
  local version
  version="$(nginx -v 2>&1 | sed -n 's|.*nginx/\([0-9][0-9.]*\).*|\1|p')"
  [[ -n "${version}" ]] || return 1
  local major minor patch
  IFS=. read -r major minor patch <<<"${version}."
  patch="${patch:-0}"
  [[ "${major}" -gt 1 ]] && return 0
  [[ "${major}" -eq 1 && "${minor}" -gt 25 ]] && return 0
  [[ "${major}" -eq 1 && "${minor}" -eq 25 && "${patch:-0}" -ge 1 ]] && return 0
  return 1
}

install_nginx_site() { # renders the vhost for the current access mode
  local template="$1"
  sed -e "s|__APP_DIR__|${APP_DIR}|g" \
      -e "s|__PUBLIC_PORT__|${PUBLIC_PORT}|g" \
      -e "s|__DOMAIN__|${DOMAIN:-_}|g" \
      -e "s|__SSL_CERT__|${SSL_CERT}|g" \
      -e "s|__SSL_KEY__|${SSL_KEY}|g" \
      "${PROJECT_ROOT}/deployment/nginx/${template}" > /etc/nginx/sites-available/nexa-ai
  if grep -q "listen 443 ssl http2;" /etc/nginx/sites-available/nexa-ai; then
    if nginx_supports_http2_directive; then
      # modern nginx: the two-line form, so nothing is logged as deprecated
      sed -i \
        -e "s|^    listen 443 ssl http2;|    listen 443 ssl;\n    http2 on;|" \
        -e "s|^    listen \[::\]:443 ssl http2;|    listen [::]:443 ssl;|" \
        /etc/nginx/sites-available/nexa-ai
    fi
    # older nginx (1.24 on Ubuntu 24.04): the template's `listen … http2` is already correct
  fi
  ln -sf /etc/nginx/sites-available/nexa-ai /etc/nginx/sites-enabled/nexa-ai
  rm -f /etc/nginx/sites-enabled/default
}

if [[ "${SETUP_NGINX}" -eq 1 ]]; then
  log "installing the Nginx site (${ACCESS_MODE} mode)"

  if [[ "${ACCESS_MODE}" == "domain" ]]; then
    # A certificate may already be present (certbot ran before, or the operator installed one).
    if [[ -f "/etc/letsencrypt/live/${DOMAIN}/fullchain.pem" && -f "/etc/letsencrypt/live/${DOMAIN}/privkey.pem" ]]; then
      SSL_CERT="/etc/letsencrypt/live/${DOMAIN}/fullchain.pem"
      SSL_KEY="/etc/letsencrypt/live/${DOMAIN}/privkey.pem"
      ACCESS_HTTPS=1
    fi

    install_nginx_site "nexa-domain-http.conf"
    if nginx_reload; then
      ok "Nginx is serving ${DOMAIN} on port ${PUBLIC_PORT}"
    else
      warn "the Nginx configuration test failed — the API is still reachable on 127.0.0.1:8000"
    fi

    if [[ "${ACCESS_HTTPS}" -eq 0 ]]; then
      DNS_IP="$(getent hosts "${DOMAIN}" 2>/dev/null | awk '{print $1}' | head -1 || true)"
      if [[ -n "${DNS_IP}" ]]; then
        ok "${DOMAIN} resolves to ${DNS_IP}"
      else
        warn "${DOMAIN} does not resolve yet — add an A record pointing at this server (${PUBLIC_IP:-${SERVER_IP}})"
      fi

      if [[ -n "${ACME_EMAIL}" ]] && ! have certbot && [[ "${INSTALL_PACKAGES}" -eq 1 ]]; then
        log "installing certbot"
        DEBIAN_FRONTEND=noninteractive apt-get install -y certbot python3-certbot-nginx >/dev/null 2>&1 \
          || warn "certbot could not be installed from the distribution — install it manually, see docs/INSTALL_UBUNTU.md"
      fi

      if [[ -n "${ACME_EMAIL}" ]] && have certbot; then
        log "requesting a Let's Encrypt certificate for ${DOMAIN}"
        if certbot --nginx --non-interactive --agree-tos --no-eff-email -m "${ACME_EMAIL}" \
             -d "${DOMAIN}" --redirect >/tmp/nexa-certbot.log 2>&1; then
          ok "certificate issued for ${DOMAIN}"
          SSL_CERT="/etc/letsencrypt/live/${DOMAIN}/fullchain.pem"
          SSL_KEY="/etc/letsencrypt/live/${DOMAIN}/privkey.pem"
          ACCESS_HTTPS=1
        else
          warn "certbot could not issue the certificate (the log is /tmp/nexa-certbot.log):"
          tail -n 3 /tmp/nexa-certbot.log | sed 's/^/    /' || true
          warn "the site keeps working over HTTP on ${DOMAIN}; fix the reason (DNS, port 80, rate limit)"
          warn "and re-run:  sudo certbot --nginx -d ${DOMAIN} -m ${ACME_EMAIL} --agree-tos --redirect"
          warn "             then:  sudo bash ${PROJECT_ROOT}/deployment/linux/install.sh --access domain --domain ${DOMAIN}"
        fi
      elif [[ -n "${ACME_EMAIL}" ]]; then
        warn "certbot is not installed — install it and issue the certificate:"
        warn "  sudo apt-get install -y certbot python3-certbot-nginx"
        warn "  sudo certbot --nginx -d ${DOMAIN} -m ${ACME_EMAIL} --agree-tos --redirect"
        warn "then re-run this installer with --access domain --domain ${DOMAIN} to switch to HTTPS"
      else
        warn "no certificate e-mail was given (--acme-email), so no certificate was requested"
        warn "the site serves plain HTTP on ${DOMAIN}; to switch to HTTPS later either re-run this"
        warn "installer with --acme-email you@example.com, or run certbot directly (see"
        warn "docs/INSTALL_UBUNTU.md, section \"Domain and HTTPS\")"
      fi

      if [[ "${ACCESS_HTTPS}" -eq 1 ]]; then
        install_nginx_site "nexa-domain-https.conf"
        nginx_reload && ok "HTTPS is active for ${DOMAIN} (HTTP redirects to it)"
      fi
    else
      install_nginx_site "nexa-domain-https.conf"
      nginx_reload && ok "HTTPS is active for ${DOMAIN} (HTTP redirects to it)"
      if have certbot; then
        # Renewals are what break silently; make them someone's job.
        ( crontab -l 2>/dev/null | grep -q "certbot renew" ) || {
          ( crontab -l 2>/dev/null; echo "17 3 * * * certbot renew --quiet --deploy-hook 'systemctl reload nginx'" ) | crontab - \
            && ok "daily certificate-renewal job installed (certbot renew)"
        }
      fi
    fi
  else
    install_nginx_site "nexa-host.conf"
    if nginx_reload; then
      ok "Nginx is serving port ${PUBLIC_PORT} (${ACCESS_MODE} mode)"
    else
      warn "the Nginx configuration test failed — the API is still reachable on 127.0.0.1:8000"
    fi
  fi

  have ufw && ufw allow "${PUBLIC_PORT}/tcp" >/dev/null 2>&1 || true
  if [[ "${ACCESS_MODE}" == "domain" && "${ACCESS_HTTPS}" -eq 1 ]]; then
    have ufw && ufw allow 443/tcp >/dev/null 2>&1 || true
  fi
else
  warn "skipping Nginx (local mode): the API listens on 127.0.0.1:8000 and is reachable on this machine only"
fi

# HTTPS changes the deployment mode, the cookie flags, HSTS and the CORS origins — recompute and
# push them into .env now, then restart the services so the running configuration matches reality.
compute_access_values
ACCESS_ENV_CHANGED=0
if [[ -f "${APP_DIR}/.env" ]]; then
  if [[ "${ACCESS_EXPLICIT}" -eq 1 ]]; then
    sync_access_env "${APP_DIR}/.env" 1 && ACCESS_ENV_CHANGED=1 || true
  else
    sync_access_env "${APP_DIR}/.env" 0 && ACCESS_ENV_CHANGED=1 || true
  fi
fi
if [[ "${ACCESS_ENV_CHANGED}" -eq 1 ]]; then
  log "restarting the services so they use the new access settings"
  if [[ "${SERVICE_MODE}" == "systemd" ]]; then
    systemctl restart nexa-api nexa-worker || warn "could not restart the systemd units"
  else
    bash "${APP_DIR}/deployment/linux/nexa-services.sh" restart || warn "could not restart the services"
  fi
  # give the API a moment: the health check below must not race the restart
  for _ in $(seq 1 20); do
    curl -fsS --max-time 3 "http://127.0.0.1:8000/readyz" >/dev/null 2>&1 && break
    sleep 1
  done
fi

# ---------------------------------------------------------------------------
# Health check: never finish with an install that does not answer.
# ---------------------------------------------------------------------------
admin_login_ok() { # asks the running API whether the .env administrator credentials work
  # Always the API itself on loopback + its own port: it is the process whose credentials are
  # being verified. Going through Nginx broke in domain+HTTPS mode (port 80 answers 301, and the
  # redirect target — the domain — does not resolve from inside the host), which produced a
  # misleading "the password is probably outdated" warning on a perfectly good install.
  local base="http://127.0.0.1:${API_PORT}" answer
  answer="$("${APP_DIR}/venv/bin/python" - "${base}" "${ADMIN_EMAIL}" "${ADMIN_PASSWORD}" <<'LOGINCHECK'
import json, sys, urllib.error, urllib.request

base, email, password = sys.argv[1], sys.argv[2], sys.argv[3]
payload = json.dumps({"email": email, "password": password}).encode()
request = urllib.request.Request(base.rstrip("/") + "/api/v1/auth/login", data=payload,
                                 headers={"Content-Type": "application/json"}, method="POST")
try:
    with urllib.request.urlopen(request, timeout=15) as response:
        # the response has to be a real signed-in session, not just an HTTP 200
        body = json.loads(response.read() or b"{}")
        ok = response.status == 200 and bool(body.get("user") or body.get("csrf_token") or body.get("session_id"))
except urllib.error.HTTPError:
    ok = False
except Exception:
    ok = False
print("true" if ok else "false")
sys.exit(0 if ok else 1)
LOGINCHECK
)"
  [[ "${answer}" == "true" ]]
}

log "checking the deployment"
# -k and -L on purpose: this is a liveness probe over loopback. In domain+HTTPS mode port 80
# answers with a redirect to https://<domain>, and the certificate belongs to the domain, not to
# 127.0.0.1 — the probe must still confirm that the chain nginx → API works. The reachability
# check below (check_public_access.sh) is the one that validates TLS properly.
HEALTH_URL="http://127.0.0.1:8000/readyz"
[[ "${SETUP_NGINX}" -eq 1 ]] && HEALTH_URL="http://127.0.0.1:${PUBLIC_PORT}/readyz"
HEALTHY=0
for _ in $(seq 1 30); do
  if curl -fsSLk "${HEALTH_URL}" >/dev/null 2>&1; then HEALTHY=1; break; fi
  sleep 1
done
if [[ "${HEALTHY}" -eq 1 ]]; then
  ok "health check passed (${HEALTH_URL})"
  if [[ -n "${ADMIN_PASSWORD}" ]]; then
    if admin_login_ok; then
      ok "administrator sign-in verified (${ADMIN_EMAIL})"
    elif [[ "${ADMIN_PASSWORD_ROTATED:-0}" -eq 1 && "${RESET_ADMIN_PASSWORD}" -eq 0 ]]; then
      warn "the placeholder administrator password was replaced — updating the existing account"
      if ( cd "${APP_DIR}/backend" && sudo -u "${APP_USER}" -E "${APP_DIR}/venv/bin/python" -m app.cli reset-password \
             --email "${ADMIN_EMAIL}" --password "${ADMIN_PASSWORD}" ) >/dev/null; then
        if admin_login_ok; then
          ok "administrator password rotated and verified (see ${APP_DIR}/.env)"
        else
          die "the password was rotated but the sign-in check still fails — inspect the API logs"
        fi
      else
        die "could not update the administrator account — run: sudo bash deployment/linux/install.sh --reset-admin-password"
      fi
    elif [[ "${RESET_ADMIN_PASSWORD}" -eq 1 ]]; then
      warn "sign-in failed for ${ADMIN_EMAIL} — resetting the account to the password stored in ${APP_DIR}/.env"
      if ( cd "${APP_DIR}/backend" && sudo -u "${APP_USER}" -E "${APP_DIR}/venv/bin/python" -m app.cli reset-password \
             --email "${ADMIN_EMAIL}" --password "${ADMIN_PASSWORD}" ) >/dev/null; then
        if admin_login_ok; then
          ok "administrator sign-in verified after the password reset (all previous sessions were revoked)"
        else
          die "the password was reset but the sign-in check still fails — inspect ${APP_DIR}/logs or journalctl -u nexa-api"
        fi
      else
        die "could not reset the administrator password — see the log above"
      fi
    elif [[ "${ADMIN_CREATED}" == "yes" ]]; then
      die "the administrator account was created but cannot sign in — check ${APP_DIR}/.env and the API logs"
    else
      warn "sign-in check failed for ${ADMIN_EMAIL}: the account existed before this run, so the"
      warn "password stored in ${APP_DIR}/.env is probably outdated. Fix it with either:"
      warn "  sudo bash deployment/linux/install.sh --reset-admin-password   # reset to the .env password (audited)"
      warn "  cd ${APP_DIR}/backend && sudo -u ${APP_USER} ../venv/bin/python -m app.cli reset-password --email ${ADMIN_EMAIL} --generate"
    fi
  fi
else
  warn "the health endpoint did not answer yet (${HEALTH_URL})"
  if [[ "${SERVICE_MODE}" == "systemd" ]]; then
    warn "last API log lines:"
    journalctl -u nexa-api -n 15 --no-pager 2>/dev/null | sed 's/^/  /' || true
  else
    tail -n 15 "${APP_DIR}/logs/api.log" 2>/dev/null | sed 's/^/  /' || true
  fi
  warn "full logs:  journalctl -u nexa-api -f   |   ${APP_DIR}/deployment/linux/nexa-services.sh status"
fi

# ---------------------------------------------------------------------------
# Two last truths, before the summary is printed.
# 1. Rotating NEXA_ENCRYPTION_KEY makes every already-stored provider credential unreadable —
#    say so now instead of letting the operator find out when a provider starts failing.
# 2. Run from the outside: does the address that is about to be printed actually answer?
# ---------------------------------------------------------------------------
SECRETS_ERR="$(mktemp)"
SECRETS_OUT="$( cd "${APP_DIR}/backend" && sudo -u "${APP_USER}" -E "${APP_DIR}/venv/bin/python" -m app.cli check-secrets 2>"${SECRETS_ERR}" || true )"
if [[ -z "${SECRETS_OUT}" ]]; then
  # never let this fail silently: if the command breaks, the operator has to see why
  warn "the provider-credential audit did not run (app.cli check-secrets produced no output):"
  tail -n 3 "${SECRETS_ERR}" | sed 's/^/  /' || true
else
  UNREADABLE="$(printf '%s' "${SECRETS_OUT}" | tr -d '\n ' | sed -n 's/.*"unreadable":\([0-9]*\).*/\1/p')"
  if [[ -n "${UNREADABLE}" && "${UNREADABLE}" != "0" ]]; then
    warn "${UNREADABLE} provider credential(s) already stored in the database can no longer be decrypted with NEXA_ENCRYPTION_KEY"
    printf '%s' "${SECRETS_OUT}" | sed -n 's/.*"provider": "\(.*\)",/  - \1/p' | sed 's/^/  /' || true
    warn "re-enter each of them under Admin -> AI Infrastructure -> Providers (the provider keeps failing until then; it never silently falls back)"
  fi
fi
rm -f "${SECRETS_ERR}"

# TLS is verified separately from "can a browser reach the port": a certificate that does not
# match the name, or an expiry that has passed, must never pass silently.
TLS_RC=""
CERT_SELF_SIGNED=0
if [[ "${ACCESS_HTTPS}" -eq 1 && -n "${SSL_CERT}" && -f "${SSL_CERT}" ]]; then
  _issuer="$(openssl x509 -in "${SSL_CERT}" -noout -issuer 2>/dev/null || true)"
  _subject="$(openssl x509 -in "${SSL_CERT}" -noout -subject 2>/dev/null || true)"
  if [[ -n "${_issuer}" && "${_issuer#issuer=}" == "${_subject#subject=}" ]]; then
    CERT_SELF_SIGNED=1
    warn "the certificate for ${DOMAIN} is SELF-SIGNED: browsers will show a warning and the strict"
    warn "  TLS verification below cannot pass. That is fine for a rehearsal; before sharing the URL"
    warn "  with other people, issue a real certificate:  sudo certbot --nginx -d ${DOMAIN} --agree-tos -m ${ACME_EMAIL:-you@example.com} --redirect"
  fi
fi
if [[ "${ACCESS_HTTPS}" -eq 1 ]]; then
  log "verifying the TLS endpoint for ${DOMAIN}"
  set +e
  curl -sS --max-time 15 --resolve "${DOMAIN}:443:127.0.0.1" -o /dev/null \
      -w "  https://${DOMAIN}/readyz  verify=%{ssl_verify_result}  HTTP %{http_code}  (%{time_total}s)\n" \
      "https://${DOMAIN}/readyz" 
  TLS_RC="$?"
  set -e
  if [[ "${TLS_RC}" -eq 0 ]]; then
    ok "HTTPS answered for ${DOMAIN} with a valid certificate chain"
    CERT_END="$(openssl x509 -in "/etc/letsencrypt/live/${DOMAIN}/fullchain.pem" -noout -enddate 2>/dev/null | cut -d= -f2 || true)"
    [[ -n "${CERT_END}" ]] && ok "certificate valid until ${CERT_END} (renewal runs daily via cron)"
  elif [[ "${CERT_SELF_SIGNED}" -eq 1 ]]; then
    # Expected: curl refuses a self-signed chain. Prove the TLS path itself works, and say plainly
    # what still has to change (a real certificate) — a silently "failed" check would be worse.
    if curl -sSk --max-time 15 --resolve "${DOMAIN}:443:127.0.0.1" -o /dev/null \
         -w "  (self-signed) https://${DOMAIN}/readyz  HTTP %{http_code}  tls=%{time_appconnect}s\n" \
         "https://${DOMAIN}/readyz"; then
      ok "the HTTPS endpoint works (self-signed certificate) — the chain will fail for visitors until a real one is installed"
    else
      warn "the TLS endpoint did not answer for ${DOMAIN} even without verification — check 'nginx -t'"
    fi
  else
    warn "the TLS endpoint did not answer for ${DOMAIN} (curl exit ${TLS_RC}) — check 'nginx -t' and the certificate paths"
  fi
fi

PUBLIC_CHECK_RC=""
if [[ "${CHECK_PUBLIC}" -eq 1 && "${SETUP_NGINX}" -eq 1 ]]; then
  if [[ "${ACCESS_MODE}" == "domain" && "${ACCESS_HTTPS}" -eq 1 ]]; then
    log "checking whether a browser outside this machine can open https://${DOMAIN}"
    PUBLIC_CHECK_LOG="$(mktemp)"
    set +e
    CHECK_INSECURE=()
    [[ "${CERT_SELF_SIGNED}" -eq 1 ]] && CHECK_INSECURE+=(--insecure)
    NEXA_PUBLIC_IP="${PUBLIC_IP}" bash "${APP_DIR}/deployment/linux/check_public_access.sh" \
        --scheme https --port 443 --host-header "${DOMAIN}" "${CHECK_INSECURE[@]+"${CHECK_INSECURE[@]}"}" \
        --wait 10 >"${PUBLIC_CHECK_LOG}" 2>&1
    PUBLIC_CHECK_RC="$?"
    set -e
    # --host-header targets 127.0.0.1 while sending "Host: <domain>"; the outside test is the
    # public IPv4 probe the script performs on its own, so a non-zero code still means "check the
    # firewall / DNS", never "the install failed".
    sed 's/^/  /' "${PUBLIC_CHECK_LOG}"
    rm -f "${PUBLIC_CHECK_LOG}"
  elif [[ "${ACCESS_MODE}" == "domain" ]]; then
    log "checking whether a browser outside this machine can open http://${DOMAIN}"
    PUBLIC_CHECK_LOG="$(mktemp)"
    set +e
    NEXA_PUBLIC_IP="${PUBLIC_IP}" bash "${APP_DIR}/deployment/linux/check_public_access.sh" \
        --port "${PUBLIC_PORT}" --host-header "${DOMAIN}" --wait 10 >"${PUBLIC_CHECK_LOG}" 2>&1
    PUBLIC_CHECK_RC="$?"
    set -e
    sed 's/^/  /' "${PUBLIC_CHECK_LOG}"
    rm -f "${PUBLIC_CHECK_LOG}"
  else
    log "checking whether a browser outside this machine can open http://${PUBLIC_HOST}:${PUBLIC_PORT}"
    PUBLIC_CHECK_LOG="$(mktemp)"
    set +e
    NEXA_PUBLIC_IP="${PUBLIC_IP}" bash "${APP_DIR}/deployment/linux/check_public_access.sh" \
        --port "${PUBLIC_PORT}" --wait 10 >"${PUBLIC_CHECK_LOG}" 2>&1
    PUBLIC_CHECK_RC="$?"
    set -e
    sed 's/^/  /' "${PUBLIC_CHECK_LOG}"
    rm -f "${PUBLIC_CHECK_LOG}"
  fi
elif [[ "${CHECK_PUBLIC}" -eq 1 ]]; then
  log "local mode: nothing is published, so there is nothing outside to check"
fi

# record how this tree was installed (used by support and by the repository tests)
cat > "${APP_DIR}/.install-info" <<INFOEOF
installed_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)
installer=deployment/linux/install.sh
service_mode=${SERVICE_MODE}
access_mode=${ACCESS_MODE}
deployment_mode=${ACCESS_DEPLOYMENT_MODE}
https=${ACCESS_HTTPS}
domain=${DOMAIN}
public_url=${ACCESS_URL}
admin_email=${ADMIN_EMAIL}
public_port=${PUBLIC_PORT}
app_dir=${APP_DIR}
app_user=${APP_USER}
database=${DB_NAME}
python=${PYTHON_PATH} (${PYTHON_VER})
INFOEOF
chown "${APP_USER}:${APP_USER}" "${APP_DIR}/.install-info" 2>/dev/null || true

SERVER_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
SERVER_IP="${SERVER_IP:-127.0.0.1}"

if [[ "${SERVICE_MODE}" == "systemd" ]]; then
  SERVICE_HELP="manage:   systemctl status|restart nexa-api nexa-worker"
  LOG_HELP="logs:     journalctl -u nexa-api -f"
else
  SERVICE_HELP="manage:   ${APP_DIR}/deployment/linux/nexa-services.sh {start|stop|restart|status|keepalive}"
  LOG_HELP="logs:     tail -f ${APP_DIR}/logs/api.log"
fi

# What to print — and what to tell the operator to do next — depends on the mode they chose.
# (Built with printf, not heredocs: a heredoc marked with quotes would print ${...} literally,
# and one without quotes would re-expand the URLs that were just computed.)
if [[ "${ACCESS_MODE}" == "local" ]]; then
  URL_LINE="${ACCESS_URL}   [this machine only — nobody else can reach it]"
  SHARE_BLOCK="$(printf '%s\n' \
    " HOW TO LET OTHERS IN (when you want to)" \
    "  Re-run this installer and pick option 1 (public IP) or 2 (domain+HTTPS):" \
    "      sudo bash deployment/linux/install.sh --access public" \
    "      sudo bash deployment/linux/install.sh --access domain --domain ai.example.com --acme-email you@example.com" \
    "  The database, the uploads and every setting are kept; only the access configuration changes.")"
elif [[ "${ACCESS_MODE}" == "domain" ]]; then
  if [[ "${ACCESS_HTTPS}" -eq 1 ]]; then
    URL_LINE="${ACCESS_URL}          [HTTPS, certificate in place]"
  else
    URL_LINE="${ACCESS_URL}          [plain HTTP — no certificate yet]"
  fi
  SHARE_BLOCK="$(printf '%s\n' \
    " SHARE IT WITH OTHERS" \
    "  Anyone can now open:   ${ACCESS_URL}" \
    "  Two things are on you, not on the installer:" \
    "    * an A record for ${DOMAIN} pointing at ${PUBLIC_IP:-${SERVER_IP}}${DNS_IP:+   (currently resolves to ${DNS_IP})}" \
    "    * inbound TCP ${PUBLIC_PORT}$( [[ "${ACCESS_HTTPS}" -eq 1 ]] && echo " and 443" ) open in the firewall / cloud security group")"
  if [[ "${ACCESS_HTTPS}" -eq 1 ]]; then
    SHARE_BLOCK="${SHARE_BLOCK}
  HTTPS is active: HTTP redirects to it, HSTS is on, session cookies are Secure, and renewal
  runs daily through certbot's cron entry."
  else
    SHARE_BLOCK="${SHARE_BLOCK}
  HTTPS is NOT active yet — the domain serves plain HTTP.
    once DNS points here:  sudo certbot --nginx -d ${DOMAIN} -m ${ACME_EMAIL:-you@example.com} --agree-tos --redirect
    then re-run:           sudo bash deployment/linux/install.sh --access domain --domain ${DOMAIN} --acme-email ${ACME_EMAIL:-you@example.com}
    (that switches the deployment to HTTPS mode, Secure cookies and HSTS automatically)"
  fi
else
  if [[ "${PUBLIC_CHECK_RC}" == "0" ]]; then
    URL_LINE="${ACCESS_URL}          [verified: answers from another machine]"
  elif [[ -n "${PUBLIC_CHECK_RC}" ]]; then
    URL_LINE="${ACCESS_URL}          [NOT reachable from another machine yet]"
  else
    URL_LINE="${ACCESS_URL}          [not checked]"
  fi
  SHARE_BLOCK="$(printf '%s\n' \
    " SHARE IT WITH OTHERS" \
    "  Send them the URL above. If it does not open for them, one of these three is missing —" \
    "  the application itself is running (the checks above proved that):" \
    "    1. a firewall rule on this host:   sudo ufw allow ${PUBLIC_PORT}/tcp" \
    "       (or firewall-cmd --add-port=${PUBLIC_PORT}/tcp --permanent / iptables / nftables)" \
    "    2. a cloud security-group rule (AWS, GCP, Azure, Oracle, Hetzner, OVH, ...) for TCP ${PUBLIC_PORT}" \
    "    3. behind a home router, NAT or CGNAT: forward inbound TCP ${PUBLIC_PORT} from the public" \
    "       address ${PUBLIC_IP:-of this host} to ${SERVER_IP} (this machine)" \
    "  Re-check any time:  sudo bash deployment/linux/check_public_access.sh --port ${PUBLIC_PORT}")"
fi

LOCAL_LINE="http://127.0.0.1:${PUBLIC_PORT} on this machine"
if [[ "${ACCESS_MODE}" == "local" ]]; then
  LOCAL_LINE="http://127.0.0.1:${API_PORT} on this machine (no Nginx in this mode)"
elif [[ "${ACCESS_MODE}" == "public" ]]; then
  LOCAL_LINE="http://${SERVER_IP}:${PUBLIC_PORT} in your own network, ${LOCAL_LINE}"
elif [[ "${ACCESS_MODE}" == "domain" ]]; then
  LOCAL_LINE="http://${SERVER_IP}:${PUBLIC_PORT} on the IP (bypassed by the API's host check), ${LOCAL_LINE}"
fi

if [[ -n "${ADMIN_PASSWORD_INPUT}" ]]; then
  ADMIN_LINE="the one you chose"
elif [[ "${ENV_EXISTS}" -eq 1 && -z "${ADMIN_PASSWORD_ROTATED:-}" ]]; then
  ADMIN_LINE="unchanged — the one already stored in ${APP_DIR}/.env"
else
  ADMIN_LINE="generated: read NEXA_BOOTSTRAP_ADMIN_PASSWORD in ${APP_DIR}/.env (root only, chmod 600)"
fi

if [[ -n "${ADMIN_PASSWORD_INPUT}" ]]; then
  ADMIN_LINE="the password you chose — keep it in your password manager"
elif [[ "${ENV_EXISTS}" -eq 1 && -z "${ADMIN_PASSWORD_ROTATED:-}" ]]; then
  ADMIN_LINE="unchanged (the one already in ${APP_DIR}/.env)"
else
  ADMIN_LINE="a generated one: read NEXA_BOOTSTRAP_ADMIN_PASSWORD in ${APP_DIR}/.env (root only, chmod 600)"
fi

cat <<SUMMARY

=====================================================================
 Nexa AI is installed.

  Access mode:    ${ACCESS_MODE} (${ACCESS_URL_LABEL})
  URL:            ${URL_LINE}
  ${LOCAL_LINE}
  Admin email:    ${ADMIN_EMAIL}
  Admin password: ${ADMIN_LINE}
  ${SERVICE_HELP}
  ${LOG_HELP}
  Health check:   ${APP_DIR}/scripts/health_check.sh $( [[ "${SETUP_NGINX}" -eq 1 ]] && echo "http://127.0.0.1:${PUBLIC_PORT}" || echo "http://127.0.0.1:8000" )
  Access check:   ${APP_DIR}/deployment/linux/check_public_access.sh --port ${PUBLIC_PORT}$( [[ "${ACCESS_HTTPS}" -eq 1 ]] && echo " --scheme https" )
  Install record: ${APP_DIR}/.install-info
$( [[ "${ACCESS_MODE}" == "public" ]] && cat <<'WARNBLOCK'

 SECURITY WARNING — plain HTTP on a public IP
  This mode is intentionally supported for testing and demonstration. Anyone on
  the network path can read or modify traffic, including session cookies and
  administrator actions. Use it only for short-lived testing and prefer the
  domain + HTTPS path (--access domain --domain your.name --acme-email you@example.com)
  before real use.
WARNBLOCK
)
${SHARE_BLOCK}

 NEXT STEPS
  1. Open the URL above and sign in as ${ADMIN_EMAIL}.
  2. Admin -> AI Infrastructure -> Providers: add a provider (base URL + API key), test it,
     then sync models. Nothing is charged until a model is priced and published.
  3. Set your balance/pricing under Admin -> Finance if you want users to pay per request.
$( [[ "${ACCESS_MODE}" == "domain" && "${ACCESS_HTTPS}" -eq 0 ]] && cat <<'HTTPSNEXT'
  4. Finish HTTPS: point the A record here, run certbot, then re-run this installer with
     --access domain --domain <your domain> --acme-email you@example.com
HTTPSNEXT
)
=====================================================================
SUMMARY
