# Browser checks (headless Chromium via `puppeteer-core`)

Optional, developer-facing checks that drive the **running** application in a real browser. They are
not part of the pytest suites (they need a browser binary and a live server); they exist because two
rounds of operator-reported bugs — a dialog with two close buttons and no save, and an admin screen
that crashed — were invisible to API tests and only reproducible in a browser.

```bash
# a live server (SQLite preview stack, or your own deployment)
npm install puppeteer-core                 # in this folder, or anywhere on NODE_PATH
BASE=http://127.0.0.1:8080 \
EMAIL=admin@example.com PASSWORD='…' \
CHROME=/usr/bin/chromium \
node check-admin-pages.cjs                # every admin + workspace route, phone + desktop
BASE=… EMAIL=… PASSWORD=… node check-model-dialog.cjs   # the model dialog, end to end
```

What `check-admin-pages.cjs` asserts: no console errors, no failed `/api/v1/*` calls, no horizontal
overflow at 390×844 and 1440×900, and that the role-permission editor really renders its checkboxes.

What `check-model-dialog.cjs` asserts: the model-edit dialog contains exactly **one** dismiss control
and exactly **one** save button, that typing a change and pressing Save persists it (re-read from the
server after a reload), and that the platform owner is never shown the “credits needed” message in the
catalogue. Screenshots and a `report.json` land in `SHOT_DIR` (default `/tmp/nexa-browser-shots`).
