/**
 * Admin-surface sweep for the Round-11 fixes, run against the live preview on :8081.
 *
 * Walks every admin page (and the roles permission editor in particular, which could not render a
 * single checkbox before this round), at a phone and a desktop viewport, and records:
 *   - console errors / failed API calls,
 *   - horizontal page overflow,
 *   - the number of rendered permission checkboxes on Admin → Roles.
 *
 * Usage: BASE=… EMAIL=… PASSWORD=… node check-admin-pages.cjs
 */
const fs = require("fs");
const path = require("path");
const puppeteer = require("puppeteer-core");

const BASE = process.env.BASE || "http://127.0.0.1:8081";
const EMAIL = process.env.EMAIL || "admin@example.com";
const PASSWORD = process.env.PASSWORD || "Nexa-Preview-Admin-2026!";
const OUT = process.env.SHOT_DIR || "/tmp/nexa-browser-shots";
const CHROME = process.env.CHROME || "/usr/bin/chromium";

const PAGES = [
  ["dashboard", "/app/admin"],
  ["users", "/app/admin/users"],
  ["roles", "/app/admin/roles"],
  ["providers", "/app/admin/providers"],
  ["models", "/app/admin/models"],
  ["pricing", "/app/admin/pricing"],
  ["payments", "/app/admin/payments"],
  ["plans", "/app/admin/plans"],
  ["settings", "/app/admin/settings"],
  ["audit", "/app/admin/audit"],
  ["security", "/app/admin/security"],
  ["errors", "/app/admin/errors"],
  ["jobs", "/app/admin/jobs"],
  ["system", "/app/admin/system"],
  ["backups", "/app/admin/backups"],
  // The workspace the user actually tests after signing in.
  ["user-dashboard", "/app"],
  ["user-chat", "/app/chat"],
  ["user-coding", "/app/coding"],
  ["user-images", "/app/images"],
  ["user-documents", "/app/documents"],
  ["user-data", "/app/data"],
  ["user-translation", "/app/translation"],
  ["user-audio", "/app/audio"],
  ["user-video", "/app/video"],
  ["user-models", "/app/models"],
  ["user-files", "/app/files"],
  ["user-jobs", "/app/jobs"],
  ["user-billing", "/app/billing"],
  ["user-payments", "/app/payments"],
  ["user-subscriptions", "/app/subscriptions"],
  ["user-usage", "/app/usage"],
  ["user-profile", "/app/profile"],
  ["user-security", "/app/security"],
  ["user-activity", "/app/activity"],
];

fs.mkdirSync(OUT, { recursive: true });
const problems = [];
let signedIn = false;

function note(message) {
  problems.push(message);
  console.log("  ! " + message);
}

async function login(page) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
  await page.waitForSelector('input[type="email"]', { timeout: 20000 });
  await page.type('input[type="email"]', EMAIL);
  await page.type('input[type="password"]', PASSWORD);
  await Promise.all([
    page.waitForNavigation({ waitUntil: "networkidle2", timeout: 30000 }).catch(() => {}),
    page.click('button[type="submit"]'),
  ]);
  await page.waitForFunction(() => !location.pathname.startsWith("/login"), { timeout: 30000 });
  signedIn = true;
}

async function visit(page, name, route, viewport) {
  const errors = [];
  const onConsole = (message) => {
    if (message.type() !== "error") return;
    if (!signedIn && /401|Unauthorized/i.test(message.text())) return;
    errors.push(`console: ${message.text().slice(0, 160)}`);
  };
  const onResponse = (response) => {
    if (response.status() >= 400 && response.url().includes("/api/v1/") && signedIn && !response.url().includes("/auth/me")) {
      errors.push(`HTTP ${response.status()} ${response.request().method()} ${response.url().replace(BASE, "")}`);
    }
  };
  page.on("console", onConsole);
  page.on("response", onResponse);
  await page.goto(`${BASE}${route}`, { waitUntil: "networkidle2" });
  await new Promise((resolve) => setTimeout(resolve, 900));
  const layout = await page.evaluate(() => ({
    scrollWidth: document.documentElement.scrollWidth,
    viewport: window.innerWidth,
    bodyText: document.body.innerText.slice(0, 80).replace(/\s+/g, " "),
  }));
  page.off("console", onConsole);
  page.off("response", onResponse);
  const label = `${name}@${viewport.name}`;
  if (layout.scrollWidth > layout.viewport + 2) {
    note(`${label}: horizontal overflow (${layout.scrollWidth} > ${layout.viewport})`);
  }
  for (const error of errors) note(`${label}: ${error}`);
  console.log(`${label.padEnd(22)} ok  (${layout.bodyText}…)`);
  if (viewport.name === "phone") {
    await page.screenshot({ path: path.join(OUT, `admin-${name}-phone.png`), fullPage: false });
  }
  return layout;
}

(async () => {
  const browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage"],
  });
  const viewports = [
    { name: "phone", width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 },
    { name: "desktop", width: 1440, height: 900, isMobile: false, hasTouch: false, deviceScaleFactor: 1 },
  ];
  try {
    for (const viewport of viewports) {
      const page = await browser.newPage();
      await page.setViewport(viewport);
      await page.evaluateOnNewDocument(() => localStorage.setItem("nexa.locale", "fa"));
      await login(page);
      for (const [name, route] of PAGES) {
        await visit(page, name, route, viewport);
      }
      if (viewport.name === "phone") {
        // The roles permission editor specifically: does it render the catalogue now?
        await page.goto(`${BASE}/app/admin/roles`, { waitUntil: "networkidle2" });
        await new Promise((resolve) => setTimeout(resolve, 800));
        const opened = await page.evaluate(() => {
          const button = Array.from(document.querySelectorAll("button")).find((b) =>
            /مجوز|permission/i.test(b.textContent || ""),
          );
          if (button) {
            button.click();
            return true;
          }
          return false;
        });
        if (!opened) note("roles: the permission editor button was not found");
        await new Promise((resolve) => setTimeout(resolve, 1200));
        const checkboxes = await page.$$eval('input[type="checkbox"]', (boxes) => boxes.length);
        console.log(`roles permission editor: ${checkboxes} checkboxes rendered`);
        if (checkboxes < 5) note(`roles: only ${checkboxes} permission checkboxes rendered`);
        await page.screenshot({ path: path.join(OUT, "admin-roles-permissions-phone.png"), fullPage: false });
      }
      await page.close();
    }
    fs.writeFileSync(path.join(OUT, "admin-sweep-report.json"), JSON.stringify({ base: BASE, problems }, null, 2));
    console.log(problems.length ? `PROBLEMS: ${problems.length}` : "PROBLEMS: 0");
    process.exitCode = problems.length ? 1 : 0;
  } catch (error) {
    console.error("sweep failed:", error.message);
    process.exitCode = 2;
  } finally {
    await browser.close();
  }
})();
