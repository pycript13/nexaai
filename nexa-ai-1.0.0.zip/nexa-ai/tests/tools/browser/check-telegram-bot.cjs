#!/usr/bin/env node
/**
 * The Telegram bot's *decision* engine, exercised live against the real bot token.
 *
 * Telegram only delivers a chat to a bot after that chat has started the bot, so a sandbox cannot
 * invent a chat id and receive replies. What can be verified — and is exactly what the operator asked
 * for — is the gate and the recognition:
 *
 *   * a Telegram id that is **not** registered on the site gets nothing but the instructions;
 *   * an id registered in the profile is recognised, greeted with the user's own data and served the
 *     menu/usage screens;
 *   * the one-time code path proves control of both accounts and links them.
 *
 * Updates are injected through the platform's own `/api/v1/telegram/webhook` endpoint, which is the
 * very handler the long-polling loop calls (`telegram_service.handle_update`), so the decisions below
 * are the ones a real chat receives — delivery itself needs the real chat (see the note at the end).
 *
 * Usage: node check-telegram-bot.cjs [baseUrl] <adminEmail> <adminPassword>
 */
const BASE = (process.argv[2] || "http://127.0.0.1:8081").replace(/\/$/, "");
const EMAIL = process.argv[3] || "admin@example.com";
const PASSWORD = process.argv[4] || "Nexa-Preview-Admin-2026!";

const problems = [];
const ok = (message) => console.log(`  ✓ ${message}`);
const fail = (message) => {
  problems.push(message);
  console.log(`  ✗ ${message}`);
};

const makeSession = () => {
  const session = { cookie: "", csrf: "" };
  const request = async (path, { method = "GET", body = null } = {}) => {
    const headers = {};
    if (body) headers["content-type"] = "application/json";
    if (session.cookie) headers.cookie = session.cookie;
    if (method !== "GET" && session.csrf) headers["x-csrf-token"] = session.csrf;
    const response = await fetch(`${BASE}${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined });
    const setCookie = response.headers.getSetCookie?.() || [];
    if (setCookie.length) {
      session.cookie = setCookie.map((entry) => entry.split(";")[0]).join("; ");
      const csrf = setCookie.find((entry) => entry.startsWith("nexa_csrf="));
      if (csrf) session.csrf = csrf.split("=")[1].split(";")[0];
    }
    let payload = null;
    try {
      payload = await response.json();
    } catch {
      payload = null;
    }
    return { status: response.status, body: payload };
  };
  return { request, session };
};

const update = (telegramUserId, text, chatId = telegramUserId) => ({
  update_id: Math.floor(Math.random() * 1e9),
  message: {
    message_id: Math.floor(Math.random() * 1e6),
    date: Math.floor(Date.now() / 1000),
    chat: { id: chatId, type: "private" },
    from: { id: telegramUserId, is_bot: false, first_name: "Tester", username: "tester" },
    text,
  },
});

(async () => {
  const admin = makeSession();
  const login = await admin.request("/api/v1/auth/login", { method: "POST", body: { email: EMAIL, password: PASSWORD } });
  if (login.status !== 200) {
    console.error(`admin sign-in failed: ${login.status}`);
    process.exit(2);
  }
  ok("admin signed in");

  const status = await admin.request("/api/v1/admin/telegram/status");
  if (status.body?.configured) ok(`the bot is configured (source: ${status.body.token?.source}, bot: @${status.body.bot_username})`);
  else fail("the bot is not configured — enter the token in Admin → Settings → Telegram first");

  // Telegram calls the webhook with the secret header and **no** session cookie, so the test does the
  // same: an endpoint that only works with an admin cookie would not be Telegram's endpoint.
  const secret = `e2e-webhook-secret-${Date.now().toString().slice(-6)}`;
  const secretSave = await admin.request("/api/v1/admin/telegram/webhook-secret", { method: "PUT", body: { secret } });
  if (secretSave.status === 200) ok(`the panel stored a webhook secret (masked as ${secretSave.body?.webhook_secret?.hint})`);
  else fail(`could not store a webhook secret (HTTP ${secretSave.status})`);
  const deliver = async (payload) => {
    const response = await fetch(`${BASE}/api/v1/telegram/webhook`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-telegram-bot-api-secret-token": secret },
      body: JSON.stringify(payload),
    });
    let body = null;
    try {
      body = await response.json();
    } catch {
      body = null;
    }
    return { status: response.status, body };
  };

  const anonymous = await fetch(`${BASE}/api/v1/telegram/webhook`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(update(900000001, "/whoami")),
  });
  if (anonymous.status === 401 || anonymous.status === 403 || anonymous.status === 422) {
    ok(`an update without the secret is refused (HTTP ${anonymous.status}) — the endpoint fails closed`);
  } else {
    fail(`an unauthenticated update was answered with HTTP ${anonymous.status}`);
  }

  // ------------------------------------------------- 1. a stranger gets nothing but instructions
  console.log("\n== a Telegram id that is not registered on the site");
  const stranger = 900000000 + Math.floor(Math.random() * 100000);
  for (const [command, expected] of [
    ["/whoami", "whoami_unlinked"],
    ["/start", "unlinked"],
    ["/models", "unlinked"],
    ["hello there", "unlinked"],
    ["/status", "unlinked"],
  ]) {
    const result = await deliver(update(stranger, command));
    if (result.status === 200 && result.body?.handled === expected) ok(`“${command}” → ${expected} (no account opened)`);
    else fail(`“${command}” → HTTP ${result.status} / ${result.body?.handled}, expected ${expected}`);
  }
  const tap = await deliver({
    update_id: Math.floor(Math.random() * 1e9),
    callback_query: {
      id: String(Math.floor(Math.random() * 1e9)),
      from: { id: stranger, is_bot: false, first_name: "Tester" },
      message: { message_id: 1, chat: { id: stranger, type: "private" }, date: Math.floor(Date.now() / 1000) },
      data: "menu:home",
    },
  });
  if (tap.status === 200) ok(`a button tap from a stranger is refused (${tap.body?.handled})`);
  else fail(`a stranger's button tap answered HTTP ${tap.status}`);

  // ------------------------------------------------- 2. a registered id is recognised and greeted
  console.log("\n== a Telegram id registered in the profile");
  const stamp = Date.now().toString().slice(-6);
  const email = `telegram-e2e-${stamp}@example.org`;
  const password = "Telegram-E2E-Pass-2026";
  const created = await admin.request("/api/v1/admin/users", {
    method: "POST",
    body: {
      email,
      display_name: "Telegram End To End",
      password,
      roles: ["user"],
      status: "active",
      initial_credit_micro: 5_000_000,
      confirm: true,
    },
  });
  if (created.status !== 201) {
    fail(`could not create the test account (HTTP ${created.status}: ${JSON.stringify(created.body).slice(0, 200)})`);
    process.exit(1);
  }
  ok(`test account created: ${email} with 5.00 credits (roles: user)`);

  const member = makeSession();
  const memberLogin = await member.request("/api/v1/auth/login", { method: "POST", body: { email, password } });
  if (memberLogin.status !== 200) fail(`the new account could not sign in (HTTP ${memberLogin.status})`);

  const registeredId = 700000000 + Math.floor(Math.random() * 999999);
  const declared = await member.request("/api/v1/telegram/numeric-id", {
    method: "POST",
    body: { telegram_user_id: registeredId },
  });
  if (declared.status === 200) ok(`the user registered their numeric id ${registeredId} in the profile`);
  else fail(`registering the numeric id failed (HTTP ${declared.status}: ${JSON.stringify(declared.body).slice(0, 160)})`);
  const claimed = await member.request("/api/v1/telegram/numeric-id", {
    method: "POST",
    body: { telegram_user_id: registeredId + 1 },
  });
  if (claimed.status === 200) ok("moving a declared id to another number is allowed (nothing was proven yet)");
  else fail(`re-declaring a new id failed (HTTP ${claimed.status})`);
  const back = await member.request("/api/v1/telegram/numeric-id", {
    method: "POST",
    body: { telegram_user_id: registeredId },
  });
  if (back.status === 200) ok("the id was set back for the rest of the run");

  const beforeDeclared = await deliver(update(registeredId, "/whoami"));
  if (beforeDeclared.body?.handled === "whoami") ok("the bot recognises the profile-declared id (“/whoami” answered)");
  else fail(`“/whoami” for the declared id → ${beforeDeclared.body?.handled}`);

  const start = await deliver(update(registeredId, "/start"));
  if (start.body?.handled === "welcome") ok("“/start” → welcome (the bot read the account and greeted the user)");
  else fail(`“/start” for the declared id → ${start.body?.handled}`);

  for (const [command, expected] of [
    ["/help", "help"],
    ["/status", "status"],
    ["/balance", "balance"],
    ["/usage", "usage"],
    ["/models", "models"],
    ["/menu", "menu"],
  ]) {
    const result = await deliver(update(registeredId, command));
    if (result.body?.handled === expected) ok(`“${command}” → ${expected}`);
    else fail(`“${command}” → ${result.body?.handled}, expected ${expected}`);
  }
  const menuviaButton = await deliver({
    update_id: Math.floor(Math.random() * 1e9),
    callback_query: {
      id: String(Math.floor(Math.random() * 1e9)),
      from: { id: registeredId, is_bot: false, first_name: "Tester" },
      message: { message_id: 2, chat: { id: registeredId, type: "private" }, date: Math.floor(Date.now() / 1000) },
      data: "menu:models",
    },
  });
  ok(`a button tap from the registered user → ${menuviaButton.body?.handled}`);

  // ------------------------------------------------- 2b. sessions and the fixed bottom bar
  console.log("\n== per-model sessions and the persistent bottom buttons");
  const pick = await deliver(update(registeredId, "/use 1"));
  if (pick.body?.handled === "model_selected") {
    ok("“/use 1” → model_selected (a published model is reachable for this account)");

    const steps = [
      ["/new", "session_created"],
      ["سلام ربات، یک جمله بگو", "answer"],
      ["/retry", "answer"],
      ["/sessions", "sessions"],
      ["/new پروژه دوم", "session_created"],
      ["/switch 1", "session_switched"],
      ["/rename نام پایدار", "session_renamed"],
      ["/stats", "stats"],
      ["/export", "export"],
      ["/settings", "settings"],
      ["/close", "session_closed"],
    ];
    for (const [text, expected] of steps) {
      const result = await deliver(update(registeredId, text));
      if (result.body?.handled === expected) ok(`“${text}” → ${expected}`);
      else fail(`“${text}” → ${result.body?.handled}, expected ${expected}`);
    }
  } else {
    fail(`“/use 1” → ${pick.body?.handled}: the runtime has no published model for a plain user, so the session flow cannot run`);
  }

  // The reply keyboard is a *persistent* bottom bar: Telegram delivers a tap as the button's exact
  // label text, so the label→action map is the whole mechanism. Sending the labels verbatim proves it.
  for (const [label, expected] of [
    ["💬 گفتگو", "menu"],
    ["🧠 مدل‌ها", "models"],
    ["🗂 سشن‌ها", "sessions"],
    ["💳 حساب من", "account"],
    ["⚙️ تنظیمات", "settings"],
    ["💰 نمایش هزینه", "settings"],
    ["❓ راهنما", "help"],
    ["🔙 بازگشت", "menu"],
  ]) {
    const result = await deliver(update(registeredId, label));
    if (result.body?.handled === expected) ok(`bottom-bar button “${label}” → ${expected}`);
    else fail(`bottom-bar button “${label}” → ${result.body?.handled}, expected ${expected}`);
  }

  // ------------------------------------------------- 3. the one-time code path
  console.log("\n== linking with a one-time code (proves control of both accounts)");
  const code = await member.request("/api/v1/telegram/link-code", { method: "POST", body: {} });
  if (code.status === 201 && code.body?.code) {
    ok(`the panel issued a one-time code and a deep link (${code.body.deep_link ? "t.me/…?start=…" : "no username set yet"})`);
    const secondTelegramId = 800000000 + Math.floor(Math.random() * 999999);
    const linked = await deliver(update(secondTelegramId, `/start ${code.body.code}`));
    if (linked.body?.handled === "linked") ok("“/start <code>” → linked (the bot stored the id Telegram reported)");
    else fail(`“/start <code>” → ${linked.body?.handled}`);
    const reused = await deliver(update(stranger, `/start ${code.body.code}`));
    if (reused.body?.handled === "bad_link_code") ok("the same code cannot be used twice");
    else fail(`re-using a spent code → ${reused.body?.handled}`);
    const greeting = await deliver(update(secondTelegramId, "/start"));
    if (greeting.body?.handled === "welcome") ok("the code-linked id is greeted too");
    else fail(`the code-linked id was not greeted (${greeting.body?.handled})`);
  } else {
    fail(`creating a link code failed (HTTP ${code.status}: ${JSON.stringify(code.body).slice(0, 160)})`);
  }

  const after = await admin.request("/api/v1/admin/telegram/status");
  console.log(`\n  registered Telegram accounts: ${after.body?.linked_accounts} (proven with a code: ${after.body?.verified_links}, declared in profile: ${after.body?.declared_links})`);
  console.log(`  messages handled: ${after.body?.messages_handled}`);

  console.log(`\nPROBLEMS: ${problems.length}`);
  console.log(
    "NOTE: a bot may only write to a chat that has started it, so the message bodies were refused by\n" +
      "      Telegram for these synthetic chats (logged, never fatal). Send /whoami to the bot from your\n" +
      "      own Telegram to see the real welcome, then save that number under Profile → Telegram.",
  );
  process.exit(problems.length ? 1 : 0);
})().catch((error) => {
  console.error(error);
  process.exit(2);
});
