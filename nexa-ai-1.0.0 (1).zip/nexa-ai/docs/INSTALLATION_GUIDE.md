# Nexa AI — Installation, Operation, Usage & Testing Guide

> The complete operational manual: from a bare server to a configured provider, activated users,
> credit payments, backups and proof that every path actually works.
> Persian version of this guide: [`RAHNAMA.md`](RAHNAMA.md)

---

## Table of contents

1. [Who this guide is for](#1-who-this-guide-is-for)
2. [Components at a glance](#2-components-at-a-glance)
3. [Prerequisites](#3-prerequisites)
4. [Quick install (three paths)](#4-quick-install-three-paths)
5. [Path A — Docker on any server (recommended)](#5-path-a--docker-on-any-server-recommended)
6. [Path B — Native Ubuntu/Debian install](#6-path-b--native-ubuntudebian-install)
7. [Path C — Windows](#7-path-c--windows)
8. [Path D — Developer setup (SQLite)](#8-path-d--developer-setup-sqlite)
9. [Configuring `.env`](#9-configuring-env)
10. [First-run platform setup (administrator)](#10-first-run-platform-setup-administrator)
11. [Day-to-day usage](#11-day-to-day-usage)
12. [Publishing on a public IP without a domain (supported, insecure)](#12-publishing-on-a-public-ip-without-a-domain-supported-insecure)
13. [HTTPS with a domain](#13-https-with-a-domain)
14. [Testing — proving the installation works](#14-testing--proving-the-installation-works)
15. [Backup and restore](#15-backup-and-restore)
16. [Maintenance and upgrades](#16-maintenance-and-upgrades)
17. [Troubleshooting](#17-troubleshooting)
18. [Security checklist](#18-security-checklist)
19. [Appendix — commands, roles, API errors](#19-appendix--commands-roles-api-errors)

---

## 1. Who this guide is for

| You are… | Start here |
| --- | --- |
| Deploying to a fresh VPS | [Quick install](#4-quick-install-three-paths) → [Path A](#5-path-a--docker-on-any-server-recommended) |
| Running Ubuntu without Docker | [Path B](#6-path-b--native-ubuntudebian-install) |
| On Windows | [Path C](#7-path-c--windows) |
| Developing locally | [Path D](#8-path-d--developer-setup-sqlite) |
| The administrator adding models | [First-run setup](#10-first-run-platform-setup-administrator) |
| Sharing the app with testers | [Public IP](#12-publishing-on-a-public-ip-without-a-domain-supported-insecure) → [Testing](#14-testing--proving-the-installation-works) |
| Fixing something | [Troubleshooting](#17-troubleshooting) |

---

## 2. Components at a glance

```
browser
   │  HTTP/HTTPS
   ▼
┌───────────────────────────────┐
│ Nginx (8080, or 80/443)       │  serves the SPA, proxies /api
└──────────────┬────────────────┘
               ▼
      ┌────────────────────┐        ┌─────────────────────┐
      │ API (FastAPI)      │───────▶│ PostgreSQL          │
      │ app.main:app       │        └─────────────────────┘
      └───────┬────────────┘        ┌─────────────────────┐
              │                     │ Redis (optional)    │
              ▼                     └─────────────────────┘
      ┌────────────────────┐        ┌─────────────────────┐
      │ Worker (job queue) │───────▶│ file storage        │
      └───────┬────────────┘        └─────────────────────┘
              ▼
      ┌───────────────────────────────────────────────────┐
      │ AI providers (OpenAI / Anthropic / Google / …)    │
      └───────────────────────────────────────────────────┘
```

| Component | Technology | Role | Required |
| --- | --- | --- | --- |
| `frontend/` | React 18 + TypeScript + Vite | SPA, RTL layout, 4 languages, 3 themes | yes |
| `backend/` | Python 3.11–3.13, FastAPI, SQLAlchemy 2, Alembic | API, auth, billing, provider/model management, model testing | yes |
| PostgreSQL | 15/16 | production database | yes in production |
| Redis | 7 | rate limiting + worker coordination | optional |
| Worker | `python -m app.workers.worker` | image/audio/video/document jobs | yes for async work |
| Nginx | 1.24+ | static hosting, proxy, unbuffered streaming | yes |
| Docker Compose | v2 | runs everything together | optional |

**No fake behaviour:** until a real provider is configured the API answers `503 not_configured`.
A freshly synced model stays hidden and `untested` until an administrator prices it, verifies it with a
test and publishes it deliberately.

---

## 3. Prerequisites

| Tier | CPU | RAM | Disk | Suitable for |
| --- | --- | --- | --- | --- |
| Test/demo | 1 core | 1 GB | 10 GB | a few users, no Docker |
| Small | 2 cores | 2 GB | 20 GB | up to ~50 users |
| Medium | 4 cores | 8 GB | 50 GB | up to ~300 users |
| Large | 8+ cores | 16+ GB | 200 GB | dedicated DB/Redis hosts |

Software: **Python 3.11–3.13** (developed and tested on 3.13; the installer selects a supported
interpreter automatically — 3.14+ would force a Rust build of the pinned `pydantic-core`, use the
Docker path in that case) · Node.js 20 LTS (build only) · PostgreSQL 15+ ·
Redis 7 (optional) · Docker 24 + Compose v2 (Path A) · Nginx 1.24 (Paths B/C).

Default ports: **8080** user entry (Nginx), **8000** API (loopback in native installs),
**5432** PostgreSQL and **6379** Redis (never expose these), **5173** Vite dev server.

---

## 4. Quick install (three paths)

```bash
# A — Docker, recommended
git clone <repo-url> nexa-ai && cd nexa-ai
cp deployment/.env.production.example .env      # fill in secrets (see §9)
docker compose up -d --build
docker compose exec api python -m app.cli doctor
# → http://SERVER-IP:8080

# B — Ubuntu/Debian without Docker
git clone <repo-url> nexa-ai && cd nexa-ai
sudo bash deployment/linux/install.sh

# C — Windows
deployment\windows\install.bat
deployment\windows\start_public.bat     # or start.bat for localhost only

# D — Developer
python3 -m venv .venv && source .venv/bin/activate
pip install -r backend/requirements-dev.txt
cd backend && python -m alembic upgrade head && python -m app.cli bootstrap
python -m uvicorn app.main:app --reload --port 8000
cd ../frontend && npm install && npm run dev
```

---

## 5. Path A — Docker on any server (recommended)

### 5.1 Prepare the host

```bash
sudo apt update && sudo apt -y upgrade
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker "$USER" && newgrp docker
sudo apt -y install git unzip curl
```

### 5.2 Create `.env`

```bash
git clone <repo-url> nexa-ai && cd nexa-ai
cp deployment/.env.production.example .env
python3 -c "import secrets;print('NEXA_SECRET_KEY=' + secrets.token_urlsafe(48))"
python3 -c "from cryptography.fernet import Fernet;print('NEXA_ENCRYPTION_KEY=' + Fernet.generate_key().decode())"
python3 -c "import secrets;print('POSTGRES_PASSWORD=' + secrets.token_urlsafe(24))"
```

Mandatory edits: `POSTGRES_PASSWORD`, `NEXA_SECRET_KEY`, `NEXA_ENCRYPTION_KEY`,
`NEXA_BOOTSTRAP_ADMIN_EMAIL`, `NEXA_BOOTSTRAP_ADMIN_PASSWORD`,
`NEXA_PUBLIC_BASE_URL` (e.g. `http://203.0.113.10:8080`), `NEXA_PUBLIC_PORT`.

### 5.3 Start

```bash
docker compose up -d --build
docker compose ps                       # db, redis, api, worker, web
docker compose logs -f api
docker compose exec api python -m app.cli doctor
```

Only the `web` service publishes a port. PostgreSQL and Redis stay on the internal network.
The `api` container runs `alembic upgrade head` and `bootstrap` on start.

### 5.4 Health

```bash
curl -s http://127.0.0.1:8080/healthz
curl -s http://127.0.0.1:8080/readyz
curl -s http://127.0.0.1:8080/api/v1/health/deep | python3 -m json.tool
```

### 5.5 Operations

```bash
docker compose exec api python -m alembic upgrade head
docker compose exec api python -m app.cli create-admin --email me@example.com --password '...' --name "Ops"
git pull && docker compose build --pull && docker compose up -d      # upgrade
docker compose down                                                  # stop (volumes kept)
docker compose down -v                                               # ⚠️ destroys data
```

---

## 6. Path B — Native Ubuntu/Debian install

```bash
sudo apt update && sudo apt -y install git curl
git clone <repo-url> nexa-ai && cd nexa-ai
sudo bash deployment/linux/install.sh          # --help lists all options
```

The script installs the packages, **starts PostgreSQL/Redis and waits for them**, creates the `nexa`
user and `/opt/nexa-ai`, provisions the database, writes `.env` with fresh secrets, builds the
virtualenv and the SPA, runs the pre-flight check plus migrations and bootstrap, installs the systemd
units (or starts the processes with `nexa-services.sh` when systemd is missing), installs the Nginx
site, then verifies `/readyz` **and** an actual administrator login. The last lines look like this:

```
[ok] health check passed (http://127.0.0.1:8080/readyz)
[ok] administrator sign-in verified (admin@example.com)
```

| Situation | Command |
| --- | --- |
| `.env` was copied from a template / an older install (`CHANGE_ME…`, `@db:5432`, `/app/uploads`, `KEY=value # comment`) | just re-run the installer: it repairs the file, keeps a `.env.bak.<UTC>` copy and prints every change. `--reset-env` regenerates it from scratch |
| The administrator cannot sign in (password in `.env` is outdated) | `sudo bash deployment/linux/install.sh --reset-admin-password` (audited; revokes the account's sessions) or `… -m app.cli reset-password --email <you> --generate` |
| `python3` in PATH is 3.14+ (`Failed building wheel for pydantic-core`, Rust/PyO3 error) | the installer now picks a supported interpreter automatically; force one with `sudo bash deployment/linux/install.sh --python /usr/bin/python3` (needs Python 3.11–3.13) |
| PostgreSQL not started (containers) | `sudo pg_ctlcluster 17 main start` (or `service postgresql start`) then re-run the installer |
| No systemd | `sudo bash deployment/linux/install.sh --no-systemd`; manage with `deployment/linux/nexa-services.sh {start,stop,restart,status,logs}` |
| Re-run / upgrade | the installer keeps `.env`, the database password, `data/`, `uploads/` and `backups/` |
| Only the frontend is missing | `cd /opt/nexa-ai/frontend && npm install && npm run build` |
| Stop everything | `systemctl stop nexa-api nexa-worker nginx` or `nexa-services.sh stop` |

Post-install checks (must all succeed):

```bash
systemctl status nexa-api nexa-worker nginx postgresql     # or: nexa-services.sh status
/opt/nexa-ai/scripts/health_check.sh http://127.0.0.1:8080
cd /opt/nexa-ai/backend && sudo -u nexa ../venv/bin/python -m app.cli doctor
```

`doctor` must report `production_problems: []`, `encryption_key_set: true` and
`ledger.inconsistent: 0`. The administrator password lives in `/opt/nexa-ai/.env`
(`NEXA_BOOTSTRAP_ADMIN_PASSWORD`); change it after the first sign-in.

## 7. Path C — Windows

Prerequisites: Python 3.11+ (tick “Add Python to PATH”), Node.js 20 LTS, optionally PostgreSQL 16.

```bat
cd C:\path\to\nexa-ai
deployment\windows\install.bat
```

`install.bat` creates `.venv`, installs dependencies, writes `.env` with fresh secrets and a random
admin password, builds the frontend, runs migrations + bootstrap, adds a firewall rule for TCP 8000
and creates desktop shortcuts.

| Script | Purpose |
| --- | --- |
| `start.bat` | API + worker windows, opens `http://127.0.0.1:8000` |
| `start_public.bat` | API on `0.0.0.0:8000` with the security warning and your LAN IP |
| `start_worker.bat` | worker only |
| `backup.bat` | SQLite copy (or `pg_dump`) + `uploads` archive |
| `diagnose.bat` | `app.cli doctor` + health probe |
| `install_service.bat` | Windows service via NSSM, else Task Scheduler entry |
| `uninstall_service.bat` | removes the service/task and the firewall rule |

Production on Windows: install PostgreSQL, create the role/database, then set
`NEXA_DATABASE_URL=postgresql+psycopg2://nexa:PASSWORD@127.0.0.1:5432/nexa`, `NEXA_ENVIRONMENT=production`
and re-run `alembic upgrade head` + `app.cli bootstrap`.

---

## 8. Path D — Developer setup (SQLite)

SQLite is for development only; the app refuses it in `production` unless
`NEXA_ALLOW_SQLITE_IN_PRODUCTION=true` (not recommended).

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r backend/requirements-dev.txt
cp .env.example .env        # set NEXA_SECRET_KEY, NEXA_ENCRYPTION_KEY, sqlite URL
cd backend
python -m alembic upgrade head
python -m app.cli bootstrap
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# second terminal
cd frontend && npm install && npm run dev     # http://localhost:5173, /api proxied
```

Single-port mode (same as production): `cd frontend && npm run build`, then start the API with
`NEXA_SERVE_FRONTEND=true` — the SPA is served by FastAPI at `http://localhost:8000`.

---

## 9. Configuring `.env`

Templates: `.env.example` (all keys, development), `deployment/.env.production.example`
(PostgreSQL + Redis), `deployment/windows/nexa.env.example` (Windows paths).

### 9.1 Mandatory keys

| Key | Purpose |
| --- | --- |
| `NEXA_DATABASE_URL` | e.g. `postgresql+psycopg2://nexa:pw@db:5432/nexa` |
| `NEXA_SECRET_KEY` | session/token signing (`secrets.token_urlsafe(48)`) |
| `NEXA_ENCRYPTION_KEY` | Fernet key encrypting provider credentials (required in production) |
| `NEXA_BOOTSTRAP_ADMIN_EMAIL` / `_PASSWORD` | first administrator created by bootstrap |
| `NEXA_PUBLIC_BASE_URL` | the URL users see (drives links and warnings) |
| `NEXA_DEPLOYMENT_MODE` | `local` \| `public_ip` \| `domain_https` (drives the banner) |

### 9.2 Frequently used keys

| Key | Default | Purpose |
| --- | --- | --- |
| `NEXA_ENVIRONMENT` | `development` | `production` enforces strict mode (no SQLite, secure cookies) |
| `NEXA_PUBLIC_PORT` | `8080` | entry port |
| `NEXA_REGISTRATION_MODE` | `open` | `open` / `invite_only` / `closed` |
| `NEXA_COOKIE_SECURE` / `NEXA_HSTS_ENABLED` | `false` | enable only behind HTTPS |
| `NEXA_SESSION_TTL_HOURS` | `720` | session lifetime |
| `NEXA_AUTH_RATE_LIMIT_PER_MINUTE` / `NEXA_API_RATE_LIMIT_PER_MINUTE` | `10` / `240` | rate limits |
| `NEXA_MAX_UPLOAD_MB` / `NEXA_USER_STORAGE_QUOTA_MB` | `50` / `2048` | upload and storage limits |
| `NEXA_MANUAL_PAYMENTS_ENABLED` + `NEXA_BANK_TRANSFER_INSTRUCTIONS` | `true` | bank-transfer payments and the instructions shown to users |
| `NEXA_CRYPTO_PAYMENTS_ENABLED` + `NEXA_CRYPTO_WALLETS` | `false` | crypto payments (real wallets required) |
| `NEXA_CREDIT_USD_RATE` / `NEXA_DEFAULT_MARKUP_PERCENT` / `NEXA_MINIMUM_CHARGE_MICRO` | `1.0` / `30` / `1000` | credit economics |
| `NEXA_EMAIL_ENABLED`, SMTP keys | `false` | transactional email |
| `NEXA_INLINE_WORKER` | `true` | set `false` and run a worker service in production |
| `NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS` | `false` | allow private/loopback provider URLs (local testing only) |
| `NEXA_PROVIDER_ALLOWED_HOSTS` | empty | provider host allowlist |
| `NEXA_SERVE_FRONTEND` / `NEXA_FRONTEND_DIST_DIR` | `true` / `../frontend/dist` | serve the SPA from the API |

> Never commit a real `.env`; the repository `.gitignore` already excludes it.

---

## 10. First-run platform setup (administrator)

1. **Sign in** with the bootstrap administrator and change the password immediately
   (Account → Security).
2. **Create a provider** (Admin → AI Infrastructure → Providers): choose the type
   (`openai`, `openai_compatible`, `anthropic`, `azure_openai`, `google`, `groq`, `mistral`,
   `together`, `deepseek`, `openrouter`, `ollama`, `stability`, `elevenlabs`, `deepgram`,
   `replicate`, `custom`), set the base URL and API key. Keys are encrypted at rest and only ever
   returned masked (`sk-********1234`).
3. **Run the connection test** — a green result proves the endpoint and credential work and reports
   how many models the provider exposes.
4. **Sync models** — new models are created `visibility=hidden`, `published=false`,
   `availability=untested`. Nothing is published automatically.
5. **Set prices** — selling prices are in *credits* (`selling_input_per_mtok` in credits per million
   tokens, `selling_per_image`/`per_request`/`per_audio_minute` as full credit amounts); provider costs
   are in *USD* (`provider_cost_*`). Leave selling prices empty to derive them from provider cost plus
   markup (the response then carries the `derived_from_provider_cost` warning). With neither set the
   model is `unpriced`: charges are recorded as 0 and a warning is returned.
6. **Verify the model** (Admin → Models → Test) using an operation that the model actually declares
   (`chat`, `streaming`, `completion`, `embeddings`, `image_generation`, `image_understanding`,
   `audio_transcription`, `speech_generation`, `video_generation`, `rerank`, `tools`, `json_mode`,
   `reasoning`, `document_qa`). The test:
   * works on hidden/internal models without publishing them,
   * is recorded in `admin_model_tests` and audited with `billed_to_user: false` (platform cost),
   * moves `availability` from `untested` to `available` on success,
   * never enables or publishes anything,
   * is bounded by `NEXA_ADMIN_TEST_DAILY_LIMIT_MICRO`.
7. **Publish deliberately** — combine `visibility=public`, `published=true` and the right
   `access_tier` (`free` | `credit` | `subscription` | `restricted` | `internal`). Restricted models
   need a grant (user or role) with optional daily/monthly caps and an expiry.
8. **Configure money** — manual payments need `NEXA_MANUAL_PAYMENTS_ENABLED` and the bank
   instructions. A user's payment request is **never credited automatically**: the administrator
   approves it once (idempotency key `payment:{reference}`; a second approval returns 422). Refunds
   are compensating ledger entries. Card/gateway adapters (Stripe, Zarinpal) are implemented but
   require real credentials plus a webhook endpoint; a `success` redirect alone never credits.
9. **Users and roles** — roles: `super_admin`, `admin`, `finance_manager`, `model_manager`,
   `support_agent`, `user`. Permissions are editable per role in Admin → Roles and every change is
   audited. Registration is governed by `NEXA_REGISTRATION_MODE`.

---

## 11. Day-to-day usage

**User workspace:** dashboard · chat (SSE streaming, conversations, regenerate, markdown export) ·
coding assist (generated code is never executed server-side) · image generation/analysis ·
documents (summarise, ask, extract, translate, index) · data analysis (statistics computed on the
server; the model only writes the narrative) · translation (batch, glossary, tone) · audio
(transcription, speech) · video · files (validated uploads, private downloads, quotas) · jobs ·
billing (balance, ledger with balance-after, payments, subscriptions, usage) · profile & security
(password, sessions, revoke-all) · activity. Languages: Persian (default, RTL), English, Arabic,
Kurdish Sorani. Themes: light, dark, system (+ glass when enabled).

**Admin panel:** dashboard · users (create, suspend/reactivate, roles, credit grants via ledger,
password reset, revoke sessions, per-user ledger) · roles & permissions · providers (create, edit,
test, sync, rotate/clear key, delete) · models (filters, pricing, capabilities, bulk
publish/unpublish/enable/disable, test history, grants) · pricing rules with versions and scopes ·
payments (review, approve, reject, refund, crypto verification) · plans & subscriptions · jobs ·
settings · audit · security events · system status · errors · backups.

**Credit integrity:** balances are projections of an append-only ledger; every change carries a
unique idempotency key; the database rejects duplicates. `python -m app.cli doctor` reconciles the
ledger against cached balances and reports drift.

---

## 12. Publishing on a public IP without a domain (supported, insecure)

```ini
NEXA_DEPLOYMENT_MODE=public_ip
NEXA_PUBLIC_BASE_URL=http://203.0.113.10:8080
NEXA_PUBLIC_PORT=8080
NEXA_COOKIE_SECURE=false          # must stay false on plain HTTP
NEXA_HSTS_ENABLED=false
NEXA_REGISTRATION_MODE=invite_only
```

Docker: `docker compose up -d` and allow the port (`sudo ufw allow 8080/tcp`, plus the cloud
security group). Native: Nginx listens on 8080 and proxies `/api` to `127.0.0.1:8000`; the API itself
stays on loopback. Windows: `deployment\windows\start_public.bat`.

**The platform warns everywhere:** a yellow banner appears in every page and
`GET /api/v1/meta/config` returns `security_warning` for this mode. Traffic — including passwords and
session cookies — is unencrypted and can be intercepted or modified. Use it for short-lived testing
with throw-away accounts only.

Pre-share checklist: admin password changed · `registration_mode` limited · firewall limits the
public port · test accounts used · service stopped or moved to HTTPS after the demo.

---

## 13. HTTPS with a domain

```bash
sudo apt -y install certbot python3-certbot-nginx
sudo certbot --nginx -d app.example.com --agree-tos -m admin@example.com --redirect
sudo cp deployment/nginx/nexa-https.conf.example /etc/nginx/sites-available/nexa-ai-https
sudo sed -i 's/YOUR.DOMAIN.TLD/app.example.com/g' /etc/nginx/sites-available/nexa-ai-https
sudo ln -sf /etc/nginx/sites-available/nexa-ai-https /etc/nginx/sites-enabled/nexa-ai-https
sudo nginx -t && sudo systemctl reload nginx
```

```ini
NEXA_DEPLOYMENT_MODE=domain_https
NEXA_PUBLIC_BASE_URL=https://app.example.com
NEXA_COOKIE_SECURE=true
NEXA_HSTS_ENABLED=true
NEXA_CORS_ORIGINS=https://app.example.com
```

Restart the services, then `curl -sI https://app.example.com/healthz` and
`python -m app.cli doctor` (the HTTP warning must disappear). Turning on `NEXA_COOKIE_SECURE`
before HTTPS breaks sign-in — do it in this order.

---

## 14. Testing — proving the installation works

### 14.1 Backend suite (this repository: **154 passed**)

```bash
cd backend
python -m pytest tests/ -q
python -m pytest tests/test_billing.py -q          # financial invariants
python -m pytest tests/ -q -m "not db"             # tests that need no database
```

Coverage: auth, authorization/RBAC, providers and adapters, billing/ledger, files, chat and
streaming, jobs, the public model catalogue, money conversion units, and module persistence
(image/audio/coding/translation/data).

### 14.2 Frontend build

```bash
cd frontend && npm install && npm run build && npm run preview
```

### 14.3 Live server checks

```bash
scripts/health_check.sh http://127.0.0.1:8080
docker compose exec api python -m app.cli doctor        # or: cd backend && python -m app.cli doctor
```

### 14.4 End-to-end live-stack test (no paid credentials needed)

`tests/tools/mock_openai_upstream.py` is a real HTTP OpenAI-compatible upstream (correct paths, SSE
framing, 401 on a wrong key) used as a test double; it counts every request it serves.

```bash
# terminal 1
python3 tests/tools/mock_openai_upstream.py --port 9099 --api-key sk-mock-key
# terminal 2
export NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=true     # local testing only
cd backend && python3 -m uvicorn app.main:app --port 8000 --host 0.0.0.0
# terminal 3
python3 tests/integration/test_live_stack.py \
  --base-url http://127.0.0.1:8000 --upstream http://127.0.0.1:9099 \
  --admin-email admin@example.com --admin-password '<admin password>'
```

Last run: **37 of 37 steps passed** — health/readiness and the deployment warning, provider creation
with masked credentials, connection test, model sync staying hidden, deliberate pricing and
publishing, an audited hidden-model admin test (platform cost, no publish), a normal user getting 403
on admin routes, manual payment (no credit before approval, exact credit after, duplicate approval
refused), non-streaming and streaming chat with exact balance debits, image generation with a stored,
downloadable file, and proof that the upstream actually served the platform's requests.

### 14.5 Ten-minute manual smoke test

```
[ ] register → sign in → switch language (fa/ar/ckb/en) → switch theme
[ ] without credits: send a chat → clear 402 insufficient-balance message
[ ] submit a manual payment → admin approves → ledger shows the credit
[ ] run chat, coding, image, document, data, audio, translation
[ ] download an output file; check Usage and Jobs pages
[ ] as a normal user open /app/admin → Forbidden page
[ ] run a backup and restore it into a scratch database
```

---

## 15. Backup and restore

```bash
scripts/backup.sh --keep 14                  # database (+ uploads archive), prunes older than 14 days
scripts/backup.sh --no-uploads --output-dir /mnt/backups
scripts/verify_backup.sh backups/<file>      # pg_restore --list or SQLite integrity_check
sudo systemctl stop nexa-api nexa-worker     # restore requires the app to be stopped
scripts/restore.sh backups/<file> --yes [--uploads backups/nexa-uploads-<stamp>.tar.gz]
sudo systemctl start nexa-api nexa-worker && scripts/health_check.sh http://127.0.0.1:8080
cd backend && python -m app.cli doctor       # verify ledger reconciliation after restore
```

Windows: `deployment\windows\backup.bat`. Docker:
`docker compose exec db pg_dump -U nexa -Fc nexa > backups/nexa-$(date +%F).dump`.
Automation: install `deployment/linux/nexa-backup.cron` in crontab (nightly backup + weekly
verification). Practice a restore monthly on a scratch host.

---

## 16. Maintenance and upgrades

| Task | Command |
| --- | --- |
| Service status / logs | `systemctl status nexa-api nexa-worker` · `journalctl -u nexa-api -f` |
| Housekeeping (expire files, lapse subscriptions) | `cd backend && python -m app.cli maintenance` |
| Drain queued jobs once | `python -m app.cli run-jobs --once` |
| Grant credits | `python -m app.cli grant-credits --email u@example.com --credits 10 --reason "goodwill"` |
| Add an administrator | `python -m app.cli create-admin --email me@example.com --password '...' --name "Ops"` |
| Health report / ledger reconciliation | `python -m app.cli doctor` |
| Upgrade | `git pull` → `docker compose up -d --build` or `sudo bash deployment/linux/install.sh` |
| Migrations | `cd backend && python -m alembic upgrade head` (`current`, `history --verbose`) |
| Rotate a provider key | Admin → Providers → Edit (or send `clear_api_key`) |

Changing `NEXA_ENCRYPTION_KEY` makes stored provider secrets undecryptable — re-enter them afterwards.

---

## 17. Troubleshooting

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| Blank page / 404 at `/` | frontend not built or `NEXA_SERVE_FRONTEND=false` | `cd frontend && npm run build`, set `NEXA_FRONTEND_DIST_DIR` |
| `503 not_configured` on chat | no provider/model, or model still `untested` | enable a provider, run the verification test, publish the model |
| `model_not_verified` | admin test never ran | Admin → Models → Test (operation must be one of the model's capabilities) |
| `402 insufficient_balance` | empty balance | have the user submit a payment and approve it, or grant credits |
| `403 model_not_accessible` | `internal`/`restricted`/`subscription` tier | change tier, add a grant, or activate a subscription |
| `429` limits | per-user/plan caps | raise caps, edit the user, or wait for the window |
| `413 payload_too_large` | upload too big | align `NEXA_MAX_UPLOAD_MB` with Nginx `client_max_body_size` |
| `502` `authentication` | wrong/expired API key | update the provider credential |
| `502` `rate_limit` | upstream throttling | lower `requests_per_minute` / `max_concurrency`, retry later |
| `502` `timeout` | short `read_timeout` | raise it (120 s+ for image/video) |
| `502` `unsupported_operation` | adapter lacks that operation | pick a suitable provider/model type |
| CORS/CSRF errors on sign-in | origin not allowed | add the exact browser origin to `NEXA_CORS_ORIGINS` / `NEXA_PUBLIC_BASE_URL` |
| Sign-in fails after enabling HTTPS flags | `NEXA_COOKIE_SECURE=true` without HTTPS | finish HTTPS or set it back to false |
| “Redis configured but unavailable” | Redis missing | harmless in dev; install Redis or clear `NEXA_REDIS_URL` |
| App refuses to start with SQLite in production | anti-SQLite policy | use PostgreSQL |
| “NEXA_ENCRYPTION_KEY is not set” | placeholder/empty key | generate a Fernet key into `.env` |
| Model visible to admins but not in the catalogue | by design | `visibility=public` + `published=true` + `available` + a suitable tier |
| Jobs never progress | worker not running and `NEXA_INLINE_WORKER=false` | start `nexa-worker` / `docker compose up -d worker` |
| Upload rejected | disallowed extension or signature mismatch | check `NEXA_ALLOWED_UPLOAD_EXTENSIONS`, send a real file of that type |
| Migration errors | stale database revision | `cd backend && python -m alembic upgrade head` |

---

## 18. Security checklist

```
[ ] random, unique NEXA_SECRET_KEY and NEXA_ENCRYPTION_KEY
[ ] default admin password changed
[ ] .env is mode 600 and never committed
[ ] PostgreSQL and Redis are never published to the internet
[ ] registration limited (invite_only/closed) when exposed
[ ] NEXA_TRUSTED_HOSTS restricted when a domain is used
[ ] NEXA_COOKIE_SECURE / NEXA_HSTS_ENABLED enabled only behind HTTPS
[ ] login rate limiting tuned
[ ] SSRF policy: private provider endpoints disabled, allowlist used when needed
[ ] per-user spend caps and the admin test budget configured
[ ] audit/security events reviewed periodically
[ ] scheduled backups plus a monthly restore drill
[ ] OS and dependencies kept up to date
```

---

## 19. Appendix — commands, roles, API errors

### 19.1 Project layout

```
nexa-ai/
├─ backend/            API, models, services, adapters, tests, alembic
├─ frontend/           React + TS + Vite
├─ database/           postgres_init.sql, schema.md, create_tables.sql
├─ deployment/         docker/, nginx/, linux/, windows/, .env.production.example
├─ scripts/            backup.sh, restore.sh, verify_backup.sh, health_check.sh, run_worker.sh, create_admin.py, seed_demo.py
├─ tests/              tools/mock_openai_upstream.py, integration/test_live_stack.py
├─ docs/               all documentation
├─ docker-compose.yml, docker-compose.dev.yml, .env.example
└─ uploads/            private/, generated/, tmp/
```

### 19.2 Command cheat-sheet

```bash
docker compose up -d --build          # start
sudo bash deployment/linux/install.sh # native install
cd backend && python -m alembic upgrade head
python -m app.cli bootstrap|doctor|maintenance|run-jobs --once
python -m app.cli create-admin --email a@b.com --password '...' --name "Admin"
python -m app.cli grant-credits --email u@b.com --credits 10 --reason "test"
cd backend && python -m pytest tests/ -q
cd frontend && npm run build
scripts/backup.sh --keep 14 && scripts/verify_backup.sh backups/<file>
scripts/restore.sh backups/<file> --yes && scripts/health_check.sh http://127.0.0.1:8080
```

### 19.3 API documentation

Interactive docs at `/api/docs` (Swagger) and `/api/redoc`; machine-readable at `/api/openapi.json`;
health at `/healthz`, `/readyz`, `/api/v1/health`, `/api/v1/health/deep`, `/api/v1/health/worker`.

### 19.4 Roles and permissions

| Group | Permissions |
| --- | --- |
| Users | `users.read`, `users.create`, `users.update`, `users.suspend`, `users.impersonate` |
| Roles | `roles.manage` |
| Providers | `providers.read`, `providers.manage`, `providers.credentials`, `providers.test`, `providers.sync` |
| Models | `models.read`, `models.manage`, `models.test`, `models.publish`, `models.grants.manage` |
| Finance | `pricing.manage`, `subscriptions.manage`, `payments.read`, `payments.manage`, `payments.approve`, `refunds.manage`, `credits.manage`, `usage.read`, `reports.read` |
| System | `settings.manage`, `audit.read`, `backups.manage`, `jobs.manage`, `security.read` |

### 19.5 API error codes

| Code | Meaning |
| --- | --- |
| `402 insufficient_balance` | user has no credit |
| `403 model_not_accessible` | tier not satisfied (`model_not_allowed`, `subscription_required`, `grant_required`) |
| `413 payload_too_large` | request/file too large |
| `422 validation_error` | invalid data (`details.fields`) |
| `429 rate_limited` | rate or spend cap reached |
| `502 provider_error` | upstream failure with a category (`authentication`, `rate_limit`, `timeout`, `unsupported_operation`, `malformed_response`, …) |
| `503 not_configured` | missing configuration (`unconfigured`, `model_not_verified`, gateway without keys) |

---

### Final notes

1. **Nothing fakes success** — a missing provider produces an explicit error, which means the system
   is behaving correctly.
2. **A synced model is hidden by design** — the healthy path is test → price → publish.
3. **Manual payments are never auto-credited**, and a gateway redirect is never proof of payment.
4. **Credits only move through the ledger**; no code path edits a balance directly.
5. **Back up before every change** — `scripts/backup.sh` is fast and cheap.
6. **No paid provider needed to test** — use `tests/tools/mock_openai_upstream.py`.
