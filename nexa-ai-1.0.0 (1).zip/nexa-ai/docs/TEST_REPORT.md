# Test report

Honest account of what was **executed** in this environment, what was **implemented but not
executed**, what **requires credentials** and what **requires infrastructure** (a VPS/Windows/Docker
host). Nothing below is claimed on the basis of "it should work".

Environment used for the executed results:

| Item | Value |
| --- | --- |
| OS | Linux (container), 2 vCPU, ~1.9 GB RAM, 21 GB disk |
| Python | 3.13.16 |
| Node.js / npm | 20.20.2 / 10.8.2 |
| Database (tests + dev) | SQLite (temporary files) |
| Docker | **not available** (no daemon) |
| Redis | **not available** (in-process fallback used, warning logged once) |
| Date of the runs below | 2026-10-12 and 2026-10-13 (the UI round) |

---

## 1. Executed and passing

| # | Test | Command | Result |
| --- | --- | --- | --- |
| 1 | Backend suite (auth, RBAC, providers, billing/ledger, files, chat, jobs, catalogue, money units, module persistence, operational CLI, HTTP hardening, UI contracts, provider transport errors + streaming retry, **model variants**, **Telegram bot + polling resilience**, **inline worker**, **strict request validation** and the **pricing-unit regressions**) | `cd backend && python -m pytest -p no:randomly` (do not add a second `-q`) | **230 passed / 0 failed** in 48 s (2026-10-14, after the real-provider round; `test_variants.py` 9, `test_telegram.py` 10, `test_inline_worker.py` 5, `test_pricing_units.py` 14, `test_schema_strictness.py` 8, `test_billing.py` 19, `test_ui_contracts.py` 6, `test_logging_config.py` 3, `test_providers.py` 25, `test_provider_transport.py` 12, `test_authorization.py` 22, `test_reasoning_tags.py` 13, `test_cli.py` 17) |
| 2 | Repository invariant suite (money column types, no committed secrets, sources compile, locale key parity, guarded admin routes, relative API URLs, no raw-HTML injection, documented error codes) | `python -m pytest tests/unit -q` | **passed** |
| 3 | Deployment asset suite (required deliverable files, Compose topology, Dockerfiles, shell syntax + exec bits, installer references, Nginx streaming/upload settings + **the nginx-1.24 `http2` guard**, systemd loopback binding, launcher **keepalive** scheduling, env templates carry no real secrets, docs complete, README links resolve, single Alembic head, **Windows batch statics** — CRLF, `%PY%` discipline, `start /d` launchers, pause guards, **SQL table references in every ops script**, **safe `.env` parsing**, the **restore-drill contract** and **the shipped scripts actually executing**) | `python -m pytest tests/deployment -q` | **159 passed / 11 skipped** (2026-10-14, +6 `test_shipped_scripts_execute.py`, +15 `test_daytona_preview.py`, +8 `test_bootstrap_report.py`) |
| 4 | Served-app end-to-end smoke (SPA shell, built assets downloadable, client routes, security headers, health/readiness/deep health, four languages + RTL, deployment warning present, Swagger/OpenAPI, anonymous catalogue leaks nothing, admin API requires auth, error shape) | `python -m pytest tests/e2e -q` | **10 passed** |
| 5 | Live-stack integration against a running API and a real HTTP upstream double | `python3 tests/integration/test_live_stack.py` | **37 / 37 steps passed** |
| 6 | Frontend production build (TypeScript + Vite) | `cd frontend && npm run build` | **success**, `tsc -b` clean, 95 modules: CSS 42.79 kB, JS 387.85 kB (110.5 kB gzip) |
| 7 | Database migrations and bootstrap | `cd backend && python -m alembic upgrade head && python -m app.cli bootstrap` | applied; bootstrap idempotent on re-run |
| 8 | Operational CLI | `python -m app.cli doctor` | reports environment, dialect, `encryption_key_set: true`, counts and ledger reconciliation (`inconsistent: 0`) |
| 9 | Health endpoints on the running instance | `curl /healthz`, `/readyz`, `/api/v1/health/deep` | 200 with component detail (database ok, redis not configured, gateways unconfigured) |
| 10 | Static API surface check | route enumeration of the running app | 131 API routes registered, all reachable modules included |
| 11 | **Archive re-verification** — extract the delivered ZIP into an empty directory, migrate, bootstrap, start and re-run the live stack | `unzip nexa-ai-1.0.0.zip`, then the commands in §5 | 80 repository tests passed, migrations applied, bootstrap created the Super Admin, the API answered `/healthz` and `/readyz`, and the live stack passed **37 / 37** again against the extracted copy |
| 12 | **Native Ubuntu/Debian installer, end to end** on a clean Debian 13 host (no project files, no database) | `sudo bash deployment/linux/install.sh --public-port 8080` | exit 0: packages installed, PostgreSQL and Redis started by the installer, role+database created, `.env` generated with fresh secrets, virtualenv + SPA built, pre-flight accepted, migrations + bootstrap applied, systemd units running, Nginx site live, `health check passed (http://127.0.0.1:8080/readyz)` and `administrator sign-in verified` |
| 13 | **Installed production stack exercised end to end (PostgreSQL, Nginx, systemd)** | live-stack suite against `http://127.0.0.1:8080` with the installer-created administrator | **37 / 37 passed** — same coverage as §1.1, but on the real deployment: PostgreSQL 17, two Uvicorn workers behind Nginx, production environment |
| 14 | **Backend suite on PostgreSQL** (not SQLite) | `NEXA_DATABASE_URL=postgresql+psycopg2://nexa@127.0.0.1/nexa_pgtest python -m pytest tests/ -q` | **137 passed / 0 failed** — the PostgreSQL dialect paths (migrations, JSON columns, transactions, unique constraints) are exercised |
| 15 | **Process-launcher mode** (`--no-systemd`, for containers) | `deployment/linux/nexa-services.sh start|status|stop|restart` | API and worker start with PID files, `status` reports both running plus `health ok`, health endpoint answers, restart and stop work |
| 16 | **Installed instance served-app smoke** | `NEXA_TEST_BASE_URL=http://127.0.0.1:8080 python -m pytest tests/e2e -q` | **10 passed** on the installed stack (SPA + assets + headers + languages + API auth boundaries) |
| 17 | **Full install from the delivered archive** — unzip `nexa-ai-1.0.0.zip` into an empty directory and run *its* installer | `unzip nexa-ai-1.0.0.zip && cd nexa-ai && sudo bash deployment/linux/install.sh --public-port 8080` | 80 repository tests passed before installing; install exit 0 with `health check passed` and `administrator sign-in verified`; then live stack **37 / 37** and served-app smoke **10 passed** against the freshly installed instance |
| 18 | **Reachability check — NATed host, closed port** (the reported defect: the installer printed `http://172.20.0.45:8080`, which no outside browser can open) | `tests/deployment/test_deployment_assets.py::test_public_access_checker_tells_the_truth_about_a_natted_host` — stubbed `curl`/`hostname`: `hostname -I` = `172.20.0.45`, public address `203.0.113.9`, only the local address answers | exit **3**, `http://203.0.113.9:8080 did NOT answer`, the working local address is still reported, the private-address/port-forward explanation and `ufw allow 8080/tcp` are printed, and the words *reachable from outside* never appear |
| 19 | **Reachability check — host that answers** | `…::test_public_access_checker_confirms_a_reachable_host` (same stub, public address answers 200) | exit **0** with `a browser outside this machine can open …` |
| 20 | **Installer publishes only a verified URL** | `…::test_installer_verifies_the_url_it_prints` (static checks + `install.sh --help`) | the installer calls the checker, keys its summary line on the result (`[verified: …]` / `[NOT reachable from another machine yet]`), explains what that means, adds the public address to `NEXA_TRUSTED_HOSTS` (a port-forwarded request arrives with `Host: <public ip>` and would otherwise be a 400 *Invalid host header*), points `NEXA_PUBLIC_BASE_URL` at the public address, and documents `--no-public-check` / `NEXA_PUBLIC_IP` in `--help` |
| 21 | **Credential audit after a key rotation** | `backend/tests/test_cli.py::test_check_secrets_reports_credentials_encrypted_with_another_key` and `…::test_check_secrets_exit_code_matches_its_own_report` | `python -m app.cli check-secrets` names providers whose stored credentials no longer decrypt (exit 3) instead of letting them fail silently later; the installer prints that warning during installation |
| 22 | **Installer credential audit, on the installed server** — a provider whose ciphertext cannot be decrypted was injected into the installed PostgreSQL database, then the installer was re-run | `psql`/SQLAlchemy insert of one `providers` row with a bogus `api_key_encrypted`, then `sudo bash deployment/linux/install.sh --public-port 8080` | `[warning] 1 provider credential(s) already stored in the database can no longer be decrypted with NEXA_ENCRYPTION_KEY` followed by `- Stale provider (key rotated)` and the remedy (`re-enter each of them under Admin -> AI Infrastructure -> Providers`). The row was removed afterwards and `app.cli check-secrets` returned `unreadable: 0`, exit 0 |
| 23 | **Re-run / upgrade path with the new checks** (nothing is destroyed, the summary stays honest) | `sudo bash deployment/linux/install.sh --public-port 8080` over an existing installation | exit 0, `.env` kept and repaired (previous file kept as `.env.bak.<UTC>`), services restarted, `health check passed`, `administrator sign-in verified`, then the credential audit and the reachability report — no data, uploads or backups touched |
| 24 | **The printed URL is verified on a NATed host** (this sandbox is shaped like the reported servers: `hostname -I` = `169.254.0.21`, egress `136.66.72.192`, no inbound path) | `install.sh` end of run, then `curl -H 'Host: 136.66.72.192:8080' http://127.0.0.1:8080/readyz` | summary: `URL: http://136.66.72.192:8080 [NOT reachable from another machine yet]` with the local fallbacks and the NAT explanation; the API answers **200** for `Host: 136.66.72.192:8080`, `Host: 169.254.0.21:8080` and `127.0.0.1` (before the fix the public `Host` header was a 400 *Invalid host header*), `.env` carries `NEXA_PUBLIC_BASE_URL=http://136.66.72.192:8080`, `NEXA_PUBLIC_IP=136.66.72.192`, `NEXA_TRUSTED_HOSTS=169.254.0.21,localhost,127.0.0.1,136.66.72.192` |

| 25 | **Browser sweep of the whole interface** — Chromium 154 driven by `tests/tools/ui_smoke/verify-ui.cjs` against a running instance (SQLite, API serving the built SPA) | `node tests/tools/ui_smoke/verify-ui.cjs` with `NEXA_UI_BASE_URL=http://127.0.0.1:8081` | 24 screenshots: sign-in, dashboard, chat, catalogue, billing, payments, usage, security, nine admin screens, light/dark/glass themes, English LTR, phone 390 px and the mobile drawer. Every screen rendered; the console stayed clean apart from the expected pre-sign-in `401` session probe; no screen leaked `[object Object]`, `undefined` or `NaN` |
| 26 | **Responsiveness measured, not assumed** — the same browser at 390 / 430 / 820 / 1024 / 1280 / 1440 px | `node` script reading `documentElement.scrollWidth` and every element rectangle | `scrollWidth == viewport width` at every width (no horizontal page scroll); the only elements outside the viewport are the parked mobile drawer; the drawer button appears ≤ 960 px and opens the drawer at 390 px |
| 27 | **Theme switching in a real browser** | clicking the light / dark / glass / system control and reloading | the applied `data-theme` and the stored preference follow the click, and the choice survives a reload (before the fix the account's stored theme overrode it, so dark mode reverted on refresh) |
| 28 | **UI contract tests** — the three response shapes the SPA depends on (payment methods keyed by slug, admin settings as a flat categorised list, per-locale `operation_labels`), plus roles-as-objects and the CSRF cookie the chat stream reads | `cd backend && python -m pytest tests/test_ui_contracts.py -q` | **5 passed** |
| 29 | **HTTP hardening tests** — default `X-Frame-Options: DENY`, `NEXA_FRAME_ANCESTORS` replacing it with `frame-ancestors`, never sending both, the deployment warning, and the always-present `nosniff` / `Referrer-Policy` / `X-Request-ID` headers | `cd backend && python -m pytest tests/test_http_hardening.py -q` | **4 passed** |
| 30 | **Repository suites** (unit invariants, deployment assets, served-app e2e) | `NEXA_TEST_BASE_URL=http://127.0.0.1:8081 python -m pytest tests/unit tests/deployment tests/e2e` (**point it at a running deployment** — without one the 10 e2e checks skip themselves and the suite reports 172 passed / 21 skipped instead of 206 / 11) | **206 passed / 11 skipped** (13.3 s) — unit 23, deployment 183 (+11 skipped: Docker/Windows/live-credential cases), e2e 10; an earlier run of this suite caught a rewritten `scripts/backup.sh` losing its executable bit (fix: `chmod +x`) |
| 31 | **Signed-out state and error resilience** | browser sweep plus a deliberate render failure | a signed-out browser on `/app` is redirected to `/login`; a failing screen now shows an error card with the technical message and a *Try again* action instead of a blank page (a new top-level error boundary covers every route) |
| 32 | **Telegram bot, live, end to end** — a throwaway stack (scratch SQLite, migrations, bootstrap, uvicorn, a local Bot API double on `:9021`, a mock OpenAI upstream, provider + published model + credits) driven by `backend/tests/tools/telegram_demo_stack.py` | `cd backend && python3 tests/tools/telegram_demo_stack.py` (exit **0**) | an unlinked Telegram id gets **only** the link-required message; after `/start <code>` the platform verifies the id against the account (`account linked: True`) and sends the welcome + usage guide; `/help`, `/status` (`balance 5.0`, 2 messages, `super_admin`), `/models` (`1 of 1` with page footer), and a free-text message answered by a **real upstream call** (`mock-answer: …`) |
| 33 | **The bot's answer is charged and ledgered** — the demo priced the model at 0.10 credits/MTok before this round | SQLite inspection of the demo stack's database after the run | usage row `chat_stream / module=telegram / succeeded / charged_micro=1000 / billed_to_user=1 / pricing_rule_id=1`; immutable ledger entry `usage_charge -1000` with idempotency key `usage:telegram:1` and `balance_after_micro=4999000`; account balance `5.000000 -> 4.999000` credits. **Before the pricing fix this row was `charged_micro=0` with no ledger entry at all** (see §1.4) |
| 34 | **Model variants (sub-models) through the running stack** — 12 steps against the live preview API | `python3 tests/tools/variant_e2e.py` | login, parent model, create sub-model, list, chat **through the sub-model** (`charged_micro=1000`), the upstream received the variant's system prompt and `temperature=0.1`, switching it off refuses the request (`422 validation_error`), admin monitoring counts the usage, admin toggle, delete, and the Telegram status endpoint — **ALL VARIANT STEPS PASSED**. `preview-tools/variant-stream-check.cjs` additionally shows the streamed answer in the real UI with `system prompt applied -> true` |
| 35 | **Responsiveness re-measured after the UI/price-editor change** — Chromium at iPhone SE / iPhone 14 / Pixel 7 / iPad mini / laptop widths, every reachable page | `node preview-tools/mobile-audit.cjs` | **0 measured problems** across five viewports (overflow, off-viewport elements, tap targets < 40 px, text < 11 px, tables without a scroll container). The single `navigation-error` entry was re-checked with `preview-tools/page-recheck.cjs` at 412 × 915 on the billing page: **0 problems** — a Puppeteer screenshot hiccup, not a layout defect |
| 36 | **Full install from the *rebuilt* archive, then a money round-trip on that installation** | `unzip nexa-ai-1.0.0.zip && cd nexa-ai && sudo bash deployment/linux/install.sh --no-nginx --public-port 8099` → then the pricing check inside the installed venv | install **exit 0** (`health check passed`, `administrator sign-in verified`, HTTP-on-public-IP warning printed); the installed API answers `/readyz` 200, serves the SPA (200), signs the administrator in (200), and reports `dialect: postgresql`, `pending_migrations_checked: true`; a model priced **0.28 credits/MTok** stored in PostgreSQL round-trips as `280000` micro-credits/MTok and charges `50000` micro-credits = **0.05 credits** for 100 000 in / 20 000 out tokens (exact, not the minimum) |
| 37 | **Live-stack suite re-run after the pricing change** against the running preview stack (mock upstream on `:9099`) | `python3 tests/integration/test_live_stack.py --base-url http://127.0.0.1:8081 …` | **38 / 38 steps passed**, including *chat response reports a real charge — charged_micro=1000* and *the charge is debited from the balance — delta=1000 charged=1000*, plus the streaming, image-generation and upstream-request-count assertions |

| 38 | **PostgreSQL backup → verify → restore drill, automated** (previously only the SQLite path had been executed) | `sudo bash scripts/backup.sh --keep 5` then `sudo bash scripts/restore_drill.sh` on the installed Debian 13 / PostgreSQL 17 deployment | dump 150 360 B, `[verify] pg_restore could read the archive (396 objects)`; drill: scratch DB created **owned by the application role**, restore performed as that role, `restored: tables=33 users=1 credit_ledger_rows=1`, throw-away API `/readyz` answered, `administrator sign-in against the restored data: 200`, `dialect: postgresql`, `accounts_checked: 1`, **`inconsistent: 0`** → PASS |
| 39 | **Redis-backed rate limiting** (previously listed as unverified) | 16 sign-in attempts with distinct `X-Forwarded-For` against the installed API, then Redis stopped and the API restarted | exactly **10 × HTTP 401 then 6 × HTTP 429** (`{"code":"rate_limited"}`), keys visible in Redis (`nexa:rl:login:admin@example.com:<ip>:<window>`); with Redis stopped the API logs `Redis configured but unavailable … falling back to in-process rate limiting`, still answers `/readyz` 200 and keeps returning 401 for bad credentials; the account was additionally **locked** after the failed burst (`Account temporarily locked after repeated failed sign-ins. Try again after 20:21 UTC`) and unlocked again by `reset-password` |
| 40 | **HTTPS/TLS rehearsal through the shipped Nginx template** (real TLS handshake; a public CA certificate still needs a domain, see §4) | nginx 1.26.3 + `deployment/nginx/nexa-https.conf.example` rendered for `localhost` with a self-signed SAN certificate, in front of the installed API | `https://127.0.0.1/` → **200** (SPA, `<html lang="fa" dir="rtl">`), headers actually sent: `strict-transport-security: max-age=31536000; includeSubDomains`, `x-content-type-options: nosniff`, `x-frame-options: SAMEORIGIN`, `referrer-policy`, `content-security-policy`; `/api/v1/health` and `/readyz` **200 through the proxy**; `http://` → **301 → https://**; TLS 1.2 → 200, TLS 1.1 → connection refused (matches `ssl_protocols TLSv1.2 TLSv1.3`); with `NEXA_DEPLOYMENT_MODE=domain_https` the session cookie is issued **Secure + HttpOnly** and `/admin/dashboard` reports `security_warning: None`; switching back to `public_ip` restores the plain-HTTP warning (the banner is mode-driven, not decorative) |
| 41 | **Telegram bot, full chain** (unlinked visitor refused → link → welcome + usage guide → menus → charged model answer), with a port pre-flight that refuses to reuse a stale process | `python3 backend/tests/tools/telegram_demo_stack.py` | exit 0: `=== unlinked visitor ===` answered with the *link-required* text only, `=== welcome message ===`, `/help`, `/status` (balance, model, message count, roles), `/models` with pagination footer, then a free-text message answered by the mock model and **charged** (`usage for module=telegram: 1 row(s), total charged 1000 micro`) |
| 42 | **Model variants / sub-models end to end against a running API** | `python3 tests/tools/variant_e2e.py` | **ALL VARIANT STEPS PASSED** (12 steps): create sub-model under a parent, list, chat through the variant (`charged_micro=1000`, upstream received the variant's system prompt and `temperature=0.1`), switch off → **422** for users, admin monitoring shows the row, admin can switch off, delete, and the Telegram status endpoint stays consistent |
| 43 | **Operator failure-path hardening (live)** | unreadable `.env` on the installed deployment | the API now refuses to start with an actionable message in the journal (`Nexa AI cannot read its configuration file: ../.env (permission denied). sudo chown <service-user>:<service-user> '../.env' … then restart the service`), and heals immediately once ownership is corrected (`/readyz` 200) |

Note on reading pytest output: this project's `pytest.ini` already sets `-q`. Adding another `-q` on the
command line makes it `-qq`, which in pytest 9 hides the final `N passed` line (the exit code and the
results are unaffected). Run `python -m pytest -p no:randomly` — without the extra `-q` — to see the counts.

| 44 | **Installer access-mode matrix, executed on the live Debian 13 installation** (the operator picks; nothing is decided for them) | four consecutive `deployment/linux/install.sh` runs: `--access local`, then `--access public --public-port 8099`, then `--access domain --domain nexa.demo.test`, then the same domain run with a certificate present | **local**: Nginx skipped, `NEXA_DEPLOYMENT_MODE=local`, URL `http://127.0.0.1:8000` and **that URL answers 200** (the API's own port — the previously printed 8080 would not have). **public**: `.env` rewritten in place (`local -> public_ip`, base URL, port 8099, CORS, trusted hosts) with a `.env.bak` backup, Nginx host site live, summary printed the SHARE block naming firewall, cloud security-group and NAT/port-forward, and the reachability check reported the truth for this NATed sandbox. **domain**: `nexa-domain-http.conf` installed, `Host: nexa.demo.test` → **200** (SPA), ACME path in place, honest warnings for "does not resolve yet" and "certbot is not installed", `.env` = `public_ip` + `http://nexa.demo.test`. **domain + certificate**: the installer detected it, wrote `domain_https` + `https://nexa.demo.test` + `Secure` cookies + HSTS in one pass, installed `nexa-domain-https.conf`, verified TLS with `curl --resolve` (HTTP 200, negotiated once), HTTP → **301** → HTTPS, TLS 1.2 → 200 / TLS 1.1 → refused, login over the domain returned **200** with `Secure; HttpOnly` session cookies, and `/admin/dashboard` reported `mode: domain_https`, `security_warning: None` |
| 45 | **Administrator credentials chosen by the operator** (e-mail, display name, password) | `--admin-email local-admin@example.com --admin-name "Local Admin" --generate-admin-password` on a fresh database; then a re-run with a *different* `--admin-email` | the account was created with the chosen identity and the installer signed in with it (`administrator sign-in verified`); `NEXA_BOOTSTRAP_ADMIN_NAME` stored; the re-run with `someone-else@example.com` **kept the existing administrator and said so** (`this installation's administrator is local-admin@example.com; yet-another@example.com was NOT applied`), instead of silently ignoring the flag |
| 46 | **`create-admin --generate` / `NEXA_ADMIN_PASSWORD`** (what `set_admin.bat` uses on Windows) | `backend/tests/test_cli.py` (2 new tests) + the CLI on the installed host | a generated password satisfies the application's policy, is printed exactly once and is never echoed for an explicitly supplied password; the environment variable keeps the value out of the process list |
| 47 | **Self-signed certificate handling** (no domain available here) | the domain run above with a self-signed SAN certificate in `/etc/letsencrypt/live/<domain>/` | the installer detected it, refused to call the chain valid (`SSL certificate problem: self-signed certificate`), proved the endpoint works anyway (`(self-signed) https://nexa.demo.test/readyz HTTP 200 tls=0.004s`) and told the operator to run certbot before sharing — the reachability check ran with `--insecure` only in that case |
| 48 | **Five defects found and fixed by this round's runs** | see §1.4 rows below |: (1) the printed URL in local mode pointed at a port nothing listened on; (2) `check_public_access.sh` probed `http://` against port 443 (nginx answers 400 "plain HTTP sent to HTTPS port") so an HTTPS installation was reported unreachable; (3) the admin-login self-check went through Nginx and therefore failed in HTTPS mode with a misleading "password probably outdated"; (4) a requested `--admin-email` on an existing installation was silently dropped; (5) the access-mode switch was applied *after* the services started, producing two restarts (and a momentary wrong mode) — the certificate is now detected before the first write of `.env` |
| 49 | **Review round: a shipped script that could never run** (`scripts/seed_demo.py`) | executing it against a throw-away SQLite database (`tests/deployment/test_shipped_scripts_execute.py`, 6 tests, runs the real script) | it crashed twice: `AttributeError: 'User' object has no attribute 'set_password'` (the model has `password_hash`, `email_verified`, `email_verified_at`; there is no such method) and, after that, `Provider type 'openai_compatible' requires an API key` for the *disabled* placeholder the script exists to create. Fixed by writing the real columns and by allowing a credential-less provider **only while it is disabled** (`enabled=false`); enabling one without credentials is refused with a hint, and `clear_api_key` + `enabled=true` in one request is refused too (3 new tests in `test_providers.py`) |
| 50 | **Review round: a misleading empty state** (found by driving the preview with a real browser) | Chromium sweep as a normal user (`demo.user@example.com`, zero balance) | the chat screen said “No model is available … an administrator must configure a provider and publish a model” while three models were in fact published and visible — the account simply had no credits and the API said so (`insufficient_balance`). The screen now shows the **API's own reason** (“موجودی اعتباری حساب شما صفر است…”) with buttons to Billing and the catalogue |
| 51 | **Review round: an English sentence inside a Persian interface** | same browser sweep in `fa` | the access reason reached the user as English prose. The catalogue API now returns `access_code` (stable) beside `access_reason` (English fallback), and the client translates 11 codes × 4 languages (`access.<code>` short label + `access.<code>.hint` sentence) on the catalogue, dashboard, model detail, chat and the model picker; unknown codes still fall back to the server text |
| 52 | **Review round: the banner blamed the wrong thing** | preview run with `NEXA_DEPLOYMENT_MODE=public_ip` behind an HTTPS proxy | the testing notice was rendered under the heading *“insecure deployment — HTTP”*, although the API sent no security warning. The heading now follows the warning text it actually prints; warning and testing notice are shown together when both exist (pinned by `tests/unit/test_repo_invariants.py::test_deployment_banner_title_matches_the_message_it_prints`) |
| 53 | **Review round: a supervisor that could not supervise** | `preview-data/run-preview.sh` on this sandbox, after restarting the API once | the working functions used `exec`, so the `while true` supervisor loop was replaced by the child and **no respawn was possible** — the log just stopped while the URL went dead. Fixed (no `exec` in the supervised functions) and proved: `kill -9` on the API → `api exited (status 0); restarting in 3s` → `/readyz` **200** again in ~8 s. The same class of guarantee was missing on systemd-less *customer* hosts, so `deployment/linux/nexa-services.sh` gained `keepalive` and `install.sh` now schedules it in cron (installing and starting `cron` itself when absent; `@reboot` entry too) |
| 54 | **Review round: final browser sweep** | `node preview-tools/verify-preview.cjs` (28 screenshots: light/dark/glass, phone width, drawer, sign-in) and `preview-tools/user-flow-check.cjs` (normal user: chat, catalogue, payments, 390 px phone) | **0 problems** in both (previously: chat had no usable model, 401 probe noise). The normal-user sweep additionally proves a manual top-up credits nothing until an administrator approves it, and that nothing overflows horizontally at 390 px |
| 55 | **Real, paid provider end to end** (`https://inference.dahl.global/v1`, 3 models) | `NEXA_REAL_BASE_URL=… NEXA_REAL_API_KEY=… python3 tests/tools/real_provider_check.py` against the live preview | **18 / 18**: connection test (245 ms, "3 models visible"), sync (`created=0 updated=3`), a priced model, an administrative verification test that returned a real completion (`MiniMaxAI/MiniMax-M2.7`, `<think>` output, 45/102 tokens, costed to the platform), a streaming admin test, publish, a new user registered, a manual bank-transfer request that credited **nothing** until an admin approved it, a real non-streaming completion, a real SSE stream through `/api/v1/chat/stream`, usage rows and a running ledger balance. The upstream really is the paid service — the same key answers `curl` outside the platform |
| 56 | **A dead end in the provider flow (found by the run above)** | first real sync: every model came back `capabilities: []`, and the admin test refused to run — "Update the model capabilities after verifying them with a supported operation" — while *verifying* was exactly what had just been refused | an administrative test may now **probe** an operation the model has not declared (that is what verification means), clearly labelled (`capability_warning`, `capability_verified`, `suggested_capabilities`) and stored in the test history. It still writes nothing: the admin declares the capability after the test (`services/access.py` keeps enforcing the list for users, and a chat request to a declared embedding-only model is still refused). 2 regression tests |
| 57 | **Transient throttles are retried** (real provider answered `429`, "at concurrency capacity, paid accounts are admitted first") | live run + `backend/tests/test_provider_transport.py` | HTTP 429 was classified as retryable **only** when the body mentioned a quota; a bare throttle was returned to the caller immediately. Now a bare 429 is retried with backoff honouring `Retry-After`, while an exhausted-quota/billing 429 is still never retried (3 new tests pin both directions, plus a 500-retried / 400-not pair) |
| 58 | **Telegram bot with the real Bot API** | `POST /api/v1/admin/telegram/test` through the platform, the polling worker's own logs, and a browser check of the new admin card | the platform's real `getMe` returned `@Signal_RRPlusbot` (id 8441353245); the polling worker holds the update stream — a second `getUpdates` from outside gets Telegram's `409 Conflict: terminated by other getUpdates request`. `getUpdates` was empty (the user has not messaged the bot yet), so no forged conversation was invented. The new **Admin → Settings → Telegram** card (status, transports, linked accounts, messages handled, per-account rows) was driven in Chromium and its test button showed the real bot name |
| 59 | **Telegram status was unreachable for everybody (found while wiring the card)** | `GET /api/v1/admin/telegram/status` → **403** for the super admin, the only account that exists | the endpoint required `settings.read`, a permission that is defined **nowhere** in `PERMISSION_GROUPS` — not even the `*` wildcard covers an unknown slug, so no role could ever hold it and the screen was dead for every operator. Changed to `settings.manage` and pinned by a new invariant test that scans every `require_permission(...)` in the server code and compares it with the catalogue |
| 60 | **Missing Telegram documentation** | `deployment/windows/install.bat` and `nexa.env.example` both tell the reader to "see docs/TELEGRAM.md" — and no such file shipped | wrote `docs/TELEGRAM.md` (BotFather walkthrough, the exact env block, polling vs webhook, the linking security model, billing, commands, troubleshooting), added the Telegram block to `.env.example` and indexed the document in `README.md` |
| 61 | **Workspace/release hygiene** | the release builder must not pick up runtime state, and the working directory was cleaned of previous rounds' artefacts | `bash build-nexa-archive.sh` → **770 158 B → 295 entries** with the secret scan reporting `ok: 252 files scanned, no secrets or runtime state found`, and a **fresh extract** re-ran both suites green (see §1 rows 1 and 3) |
| 62 | **Reasoning models printed their scaffolding** — the live model returned `<think>The user asks …</think>42` and the chat screen showed the tags as the answer; when the budget ran out *inside* the thinking block the reply was empty with `finish_reason=length` and the user saw a blank bubble | the real Dahl endpoint (`MiniMaxAI/MiniMax-M2.7`) driven from the browser harness `preview-tools/check-chat-reasoning.cjs` and the API check `python3 tests/tools/real_provider_check.py` | a reasoning splitter (`backend/app/providers/reasoning.py`) now separates inline `<think>/<thinking>/<reasoning>` blocks — and a dedicated `reasoning_content`/`reasoning` field — from the visible answer, for the non-streaming path *and* for streams whose chunks cut a tag in half (`"<thi"` + `"nk>…"`, which is what really arrives on the wire). The chain of thought is stored on the message (`content_parts`) and rendered in its own collapsible panel (**"Model reasoning"**, 4 locales). 13 tests: `backend/tests/test_reasoning_tags.py` |
| 63 | **An answer with no visible text explained nothing** — the same run: the model spent its whole output budget thinking, the platform charged for the tokens (a real provider cost) and returned an empty string, so the bubble stayed blank with no hint | live run above (24-token budget → `content=""`, `completion_tokens=64`) | the server annotates the turn (`status=incomplete`, `error_category=empty_answer`, a human explanation: raise the output limit under *Admin → Models* or ask something shorter), the SSE `done` event carries the same note, and the chat screen prints it with an alert icon instead of an empty bubble. Two unit tests plus a live end-to-end check |
| 64 | **The reasoning panel vanished on the first turn** (found by the same browser harness: the panel appeared on turn 2 and after a reload, but not on turn 1) | `check-chat-reasoning.cjs` comparing the live DOM with the reloaded DOM | the streaming `delta` handler replaced the message object instead of spreading it, so the reasoning that streams *before* the first visible token was wiped by the first content chunk. Fixed in both the delta and the error handlers; the harness now passes with the panel present on the first turn, no raw tags, and both panels surviving a reload |
| 65 | **The live banner described the prototype, not the deployment** — the operator-facing notice still said answers were "synthetic test output" while three real paid models were published | the browser run above | the notice is a normal, editable platform setting; it was rewritten through the product's own admin API (`PATCH /api/v1/admin/settings/site.testing_notice`, confirmation required and given) and both `/api/v1/meta/config` and the banner now describe the real providers |
| 66 | **The Daytona installer never produced a link** — the operator ran it on a real sandbox, got `<get the preview link for port 8080; see below>` and no way to share the deployment, although `docs/RAHNAMA-DAYTONA.md` already promised the script would "guess from the environment and print the link" | the operator's own run log (install → configure → verify all green, no URL), reproduced here by running the same script in a container | `deployment/daytona/preview_link.sh` (new): detects the sandbox id, builds `https://<port>-<id>.proxy.daytona.<work|works>`, **probes `/readyz`** on each candidate and classifies the answer — `2xx` = public, the link works for anyone (and it is then used as the public base URL); `401/403` = URL right, sandbox private; no answer = reported, never disguised. The installer sources it, resolves in the order `--public-url` → `daytona preview-url` CLI → probe → candidate, and never writes an unproven URL into `.env`. A container hostname such as `e2b.local` is rejected as an id. 15 tests execute the script against real local HTTP servers (`tests/deployment/test_daytona_preview.py`) |
| 67 | **A deployment finished with an administrator who could never sign in** — `--admin-email admin@nexa.test` was accepted, bootstrap created the account, and the sign-in endpoint answered **422** ("special-use or reserved name that cannot be used with email"), so the only administrator was unusable. The installer still reported "installed and verified" | found by the drill for row 66 (the login self-check failed); reproduced twice with a fresh database | the operational CLI, `bootstrap` and the API now share one validator (`app/core/crypto.py::email_policy_errors`, backed by the same `pydantic.EmailStr` the request schemas use), the installer **aborts** with the reason instead of continuing, and the Daytona script prints the API's own message when a sign-in fails. 5 new tests (`test_cli.py`, incl. that `admin@example.com` — the shipped default — stays acceptable) |
| 68 | **The installer read the bootstrap report with a slice that could never work** — `raw.find("{") … raw.rfind("}")` picked up the *log line's* Python dict (`bootstrap complete: {'permissions_created': 0, …}`), so `json.loads` always failed, `ADMIN_CREATED` became `unknown` and the check for row 67 silently never ran | the drill for row 67 stayed quiet; running the same snippet by hand showed it printing an empty line | the parsing moved into `deployment/linux/bootstrap_report.py`, which scans for the first JSON object carrying `super_admin` (the report, whatever is printed around it) and answers `yes`/`no`/`unparsed` honestly. 8 tests feed it the real shapes, including a log line first and a bare Python repr |
| 69 | **Plain-HTTP public installs tried to open a sandbox IP** — the summary printed `http://172.20.0.63:8080` as the share address, which no outsider can ever reach | both drills: the exit summary and the operator's log | the link block now always states the truth: the sandbox/container IP is not reachable from outside, the proxy port is the way in (with the internal API port named for clarity), and the exact `daytona list` / `daytona preview-url` commands plus the public-sandbox switch are printed with the security note about the preview token being usable on **every** port of the sandbox (22222 included) |

### 1.0b Provider resilience against a flapping upstream (executed)

`tests/tools/flaky_upstream.py` (an OpenAI-compatible double whose `/v1/models` always answers but
whose **first streaming chat request is answered with a TCP reset**) plus
`tests/integration/test_provider_resilience.py`:

```
1) connection test against the flaky provider: GREEN  — 1 model visible at the provider
2) synchronized 1 model (hidden, unpublished, untested, as always)
2b) administrator verification test: success
3) streamed chat through the flapping provider: events=['meta','delta','delta','done']  => RECOVERED
4) unreachable provider -> provider_connectivity with endpoint + ConnectError + hints
```

Executed against the installed deployment (PostgreSQL + Nginx + systemd on port 8080), exit 0.
The flaky upstream log shows the two attempts: `resetting the first streaming request (attempt 1)` →
`serving the retried streaming request (attempt 2)`.

### 1.1 What the live-stack test proves (all 37 steps green)

* liveness/readiness answer and `meta/config` carries the deployment warning
* an administrator can sign in and holds the expected permission set (30 permissions)
* a provider is created and its credential is **masked** in the API response
* the provider connection test really contacts the upstream and reports the model count
* model sync imports the upstream catalogue and every imported model stays **hidden, unpublished,
  untested**
* pricing a model and publishing it works; publishing a hidden model is refused
* an administrator can **test a hidden/internal model**, gets a real answer, the test is costed to the
  platform (`billed_to_user: false`), the model stays hidden/unpublished, and the test appears in the
  model test history
* a successful admin test moves `availability` from `untested` to `available`
* a normal user can register and sign in, is **refused (403)** on admin endpoints, and sees the
  published model in the catalogue
* submitting a manual payment credits **nothing**; approving it posts exactly one ledger entry keyed
  to the payment reference; approving it twice returns **422**
* the balance increases by exactly the approved amount (25 000 000 micro) and the ledger row shows the
  running `balance_after_micro`
* non-streaming chat and streaming chat both succeed through the configured provider; the charge is
  reported, the balance is debited by exactly that amount, and usage history records both operations
* image generation returns a stored file whose download returns **200** with real bytes
* the upstream double records that the platform really made its requests (its HTTP request counter increases throughout the run — nothing is simulated inside the application)

**Note on running the live-stack script against an installed (HTTPS-shaped) deployment.** When
`NEXA_COOKIE_SECURE=true` the session cookies are marked `Secure`, so the script cannot authenticate
over a loopback `http://` URL — correct behaviour of a browser and of `httpx`. The script detects this
and re-sends the cookies for its own client only, printing a line saying so; the server is untouched.
Provider endpoints on private addresses (the loopback mock) additionally need
`NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=true` and `NEXA_PROVIDER_ALLOW_INSECURE_HTTP=true` in the
deployment's `.env` for the duration of the test — see `docs/REMOTE_TESTING.md` §6, which gives the
exact three steps and how to undo them.

### 1.2 Installer verification (Debian 13, clean host)

Because the first published installer stopped with

```
psql: error: connection to server on socket "/var/run/postgresql/.s.PGSQL.5432" failed
```

on a host where `apt` had installed PostgreSQL without starting it, the installer was rewritten and
then **executed repeatedly on a clean Debian 13 machine** (same family as Ubuntu, no Docker). What the
runs proved:

* services are started by the installer itself (`systemctl` → `service` → `pg_ctlcluster` → raw
  `pg_ctl`, then a `pg_isready` wait with a 30 s timeout) and a helpful diagnosis is printed if none
  works;
* the generated `.env` passes the application's own production check (`NEXA_TRUSTED_HOSTS` no longer
  uses `*`), and the installer runs that check as a pre-flight step;
* re-running the installer preserves `.env`, the database password, `data/`, `uploads/` and
  `backups/` — verified by re-running it twice on the same host;
* the installer verifies the result itself: `/readyz` **and** an administrator login;
* `deployment/linux/nexa-services.sh` starts/stops/restarts/statuses the API and worker on hosts
  without systemd (containers, OpenVZ, WSL without systemd), writing PID files and logs.

#### The one-command sandbox installer (`deployment/daytona/install-daytona.sh`)

The Daytona/sandbox installer was written to be run by a single command inside a fresh sandbox and was
then **executed repeatedly on a clean Debian 13 machine** (2 vCPU / 2 GB, PostgreSQL and Nginx, **with**
systemd — the opposite of the no-systemd case above, so both supervisors are covered). What the runs
proved:

* a clean host, no manual editing: `sudo bash deployment/daytona/install-daytona.sh
  --public-url https://8080-<sandbox-id>.proxy.daytona.work` finished with **exit 0** in ~30 s and
  printed `Nexa AI is installed and verified inside this sandbox`;
* the deployment switches itself to the proxied-HTTPS shape (`NEXA_DEPLOYMENT_MODE=domain_https`,
  `NEXA_COOKIE_SECURE=true`, HSTS deliberately **off** on a shared proxy domain), trusts
  `*.proxy.daytona.work`, `*.proxy.daytona.works`, `*.daytona.work`, `*.daytona.io` plus the exact
  host, and sets CORS and the advertised public URL to the preview link — so a *refreshed* signed
  link keeps working;
* it verifies the result through the reverse proxy itself, with the preview `Host:` header:
  `/readyz`, the built SPA (full body, not a truncated prefix), a referenced `/assets/*.js`, `/api/v1/meta/config`
  and an administrator sign-in — all five green on the clean run;
* an unknown `Host:` is still refused (`400`) while any `*.proxy.daytona.*` host is accepted;
* re-running it (with or without `--skip-install`) is safe and idempotent: `0 setting(s) written`, then
  the same five checks green;
* **the full live-stack suite was then executed against that installed deployment** (PostgreSQL +
  Nginx + systemd on port 8080, not the development server): `PASSED 37 / 37`.

Additional scenarios executed on the clean host:

* **Python detection** — with a fake `python3` reporting 3.14 first in `PATH`, the installer selected
  `/usr/local/bin/python3.13` and completed successfully (`using Python 3.13`); the live stack then
  passed 37/37 against that installation.
* **Stale virtualenv** — a virtualenv whose interpreter reported 3.14 was detected and rebuilt
  (`the existing virtualenv uses Python 3.14 — recreating it with 3.13`) with no manual cleanup.
* **Legacy `.env` upgrade** — an `.env` containing `NEXA_TRUSTED_HOSTS=*` was repaired automatically
  (`replaced the wildcard NEXA_TRUSTED_HOSTS with 169.254.0.21,localhost,127.0.0.1`) and the run ended
  green.
* **Unsupported interpreter requested** — `--python <3.14 interpreter>` stops immediately with
  `this release supports 3.11-3.13 ...` instead of failing deep inside pip.
* **Re-install/upgrade** — re-running the installer keeps the database password, `.env`, uploads and
  backups, and ends with `health check passed` + `administrator sign-in verified`.
* **Leftover template `.env` (the reported failure)** — `deployment/.env.production.example` copied to
  `/opt/nexa-ai/.env` (with an inline comment added by hand): the installer repaired inline comments,
  placeholders, the wildcard host list, the Docker database host, `/app` paths, the Redis service name
  and the template admin password; services started, `/readyz` answered, the administrator account was
  rotated and verified (`login -> 200` with the password from `.env`, audit row
  `user.password_reset`), the live stack passed **37 / 37** and the served-app smoke **10 passed**.
* **Honesty of the self-check** — with a genuinely mismatched password the installer prints the
  `--reset-admin-password` remedies instead of claiming success.

Fixes found by these runs (all shipped):

| Defect | Impact | Fix |
| --- | --- | --- |
| Shipped env templates contained `KEY=value   # comment` lines | pydantic-settings reads the whole text as the value: the API died at startup with `4 validation errors for Settings … unable to interpret input`. Using `deployment/.env.production.example` as-is was guaranteed to fail | the 20 offending lines in the three templates were rewritten (comment on its own line); the installer also strips inline comments from an existing `.env` (with a backup); a repository test loads all three templates through the real application (`app.cli doctor`) and fails if any value cannot be interpreted |
| A `.env` copied from the Docker template on a native install | `NEXA_UPLOAD_DIR=/app/uploads` made every generation fail with `PermissionError: [Errno 13] Permission denied: '/app'`; `NEXA_TRUSTED_HOSTS=*`, `@db:5432` and `redis://redis:6379` were equally wrong for a native host | the installer re-points container paths/service names at the local installation (`<app dir>/uploads`, `<app dir>/frontend/dist`, `127.0.0.1:5432`, `127.0.0.1:6379`) and reports each change |
| Install finished and the printed URL does not open (reported from a real Debian 13 host whose only address is `172.20.0.45`) | the summary printed `http://172.20.0.45:8080` — a private address no browser outside that network can reach — and nothing tested the claim, so "installed" looked like "broken" | the installer now detects the public address (`api.ipify.org`, pinnable with `NEXA_PUBLIC_IP`), prints the address a browser must actually use, and verifies it with `deployment/linux/check_public_access.sh`: the summary reads `[verified: answers from another machine]` or `[NOT reachable from another machine yet]` followed by the layer that is closed (host port / host firewall / NAT port-forward) and the commands that open it. A closed port never fails the installation — it is a network problem, not an install failure |
| Credential audit that ran nowhere (found during the rehearsal of this very fix) | the installer called `app.cli check-secrets` from the install root and sent stderr to `/dev/null`; `app` only lives in `<app dir>/backend`, so the command failed on every install and the audit silently did nothing | fixed: the command runs in `${APP_DIR}/backend` like the other CLI calls, its stderr is captured and printed when it fails (`the provider-credential audit did not run …`), and a test pins both the working directory and the honesty of the failure |
| A placeholder administrator password (`CHANGE_ME_STRONG_ADMIN_PASSWORD`) survived the install | on a public-IP deployment the administrator account had a *known* password | the installer now generates a strong password, updates the existing account to it (audited `user.password_reset`, sessions revoked) and verifies the login again |
| The installer's own sign-in self-check could report success while the API answered `401` | a broken administrator account would have been reported as verified — the worst kind of false positive | the check now uses the process exit status **and** requires a real session in the response body; the deployment test asserts both |
| Existing accounts could not be recovered from the CLI | an operator locked out after an `.env` change had no supported command (`create-admin` refuses duplicates) | new `app.cli reset-password` (`--generate`, `--must-change`), with a policy check, session revocation and an audit event; 7 new backend tests |
| The installer used whatever `python3` was first in `PATH` | on a host whose `python3` is 3.14 the virtualenv build died with `Failed building wheel for pydantic-core` (PyO3: "the configured Python interpreter version (3.14) is newer than PyO3's maximum supported version (3.13)") and the installation stopped | interpreter selection restricted to 3.11–3.13 with candidates `python3.13 → 3.12 → 3.11 → /usr/bin/python3 → python3`, an `apt` fallback, a `--python PATH` override that refuses unsupported versions with a clear message, automatic rebuild of a virtualenv whose interpreter is unsupported, and the chosen version recorded in `.install-info` |
| An `.env` written by an earlier version blocked the upgrade | a wildcard `NEXA_TRUSTED_HOSTS=*` from the first release made the pre-flight check refuse to continue | `repair_env`: the wildcard is replaced with the host's real addresses, missing `NEXA_SECRET_KEY`/`NEXA_ENCRYPTION_KEY` are generated, and the change is reported |
| Nginx/ufw/`pg_ctl*` were not found when `PATH` lacked `/usr/sbin` | after `sudo env PATH=…` the installer reported a failed Nginx test although the configuration was valid | the installer prepends `/usr/sbin:/sbin` to `PATH` |
| Installer assumed a running PostgreSQL | installation aborted with a raw `psql` socket error on any host whose services are not auto-started | start PostgreSQL through four fallbacks + readiness wait + actionable error text |
| Generated `.env` used `NEXA_TRUSTED_HOSTS=*` in `public_ip` mode | the API refused to start in production — the installer produced a service that could never boot | concrete host list (`hostname -I` + `localhost`/`127.0.0.1`) and a pre-flight `doctor` gate |
| Nginx health locations proxied without `proxy_set_header Host` | nginx sent the upstream name as `Host`, so `/healthz` and `/readyz` returned `400 Invalid host header` while `/api/` worked — monitoring and the installer's own health check were broken | explicit `Host` header added in all three templates (host, generic, HTTPS) |
| The project copy carried the developer's `.env` and could delete `data/`/`uploads/` on re-install | an upgrade could pin the install to a template `.env` (placeholder secrets) or destroy runtime data | rsync/tar exclude lists that protect `.env`, `venv/`, `data/`, `uploads/`, `backups/`, `logs/` |
| `source .env` in bash during the install | a hand-edited `.env` aborted the install with `syntax error near unexpected token` | the installer no longer sources `.env`; the application loads it itself (pydantic-settings) |
| The database password was regenerated on every run | a re-run locked the application out of its own database | the password is read back from an existing `.env` and re-applied with `ALTER ROLE` |
| `apt-get install nodejs npm` on a NodeSource host | abort-worthy conflict (`E: Unable to correct problems`) on servers that already have Node | Node is only installed when `npm` is missing; otherwise the existing toolchain is used |
| Reinstall created a root-owned tree | `python -m venv` failed with `Permission denied` for the `nexa` user | ownership fixed before the virtualenv is created |

### 1.3 Archive verification (self-sufficiency)

The delivered archive was extracted to an empty directory (`/tmp/verify`), its migrations were applied to
a fresh SQLite database, the Super Admin was bootstrapped from `.env` values, the API was started and the
whole suite was re-run from that copy:

```
unzip nexa-ai-1.0.0.zip → 272 entries (219 files), no node_modules, dist, caches, .env or database files
python -m pytest tests/unit tests/deployment -q   → 65 passed
python -m alembic upgrade head && python -m app.cli bootstrap   → schema created, admin created
GET /healthz → {"status":"ok"}        GET /readyz → {"status":"ready","database":"ok"}
python3 tests/integration/test_live_stack.py      → PASSED 37 / 37
```

The archive is rebuilt after every change; the numbers in this section describe the run
reported above, while the current archive contains the UI round of 2026-10-13 (the browser sweep
in §1, rows 25–31, was executed against that code).

This proves the archive is complete and self-sufficient: it installs, migrates, boots and passes its own
end-to-end test without any file that lives only in the development workspace. The strongest form of
this check was also executed: the archive was extracted into an empty directory, **installed with its
own `deployment/linux/install.sh` onto a clean Debian 13 host**, and the live stack then passed 37/37
against that installation (§1, row 17).

#### Latest archive (with the one-command sandbox installer) — extracted and installed from the archive itself

The archive that ships `deployment/daytona/install-daytona.sh` was verified the same way, from the
archive file itself:

```
unzip nexa-ai-1.0.0.zip → 284 entries (242 files), no node_modules, dist, caches, real .env, database,
                          upload or log files — only the .env.example templates
shipped scripts executable (install.sh, install-daytona.sh, nexa-services.sh, backup/restore/health,
verifier and the Windows .bat set) and all *.sh pass bash -n; backend/app + tests + scripts compile
sudo bash deployment/daytona/install-daytona.sh --public-url https://8080-<sandbox-id>.proxy.daytona.work
     → exit 0 on a clean Debian 13 host; /readyz, the SPA (full body), /assets/*.js,
       /api/v1/meta/config and a real administrator sign-in all green
python3 tests/integration/test_live_stack.py --base-url http://127.0.0.1:8080
     → PASSED 37 / 37 against the deployment installed from the archive
```

#### The archive of 2026-10-13 (variants, Telegram, strict schemas, pricing units)

`bash /home/user/build-nexa-archive.sh` builds the deliverable reproducibly: it checks 27 key files
first, restores the executable bits that the workspace snapshot does not preserve, copies with an
explicit exclude list, **refuses to package** if a secret, a database, a log or a build artefact is
found (242 files scanned) and prints the entry count plus the SHA-256. The archive that is shipped with
this report:

```
entries: 285        size: ~701 KB        executable scripts: install.sh, install-daytona.sh,
                                          nexa-services.sh, backup/restore/verify, check_public_access.sh,
                                          the Windows .bat set
```

The checksum of the file you received is written next to it in `nexa-ai-1.0.0.zip.sha256`
(`sha256sum -c nexa-ai-1.0.0.zip.sha256`). This document ships **inside** the archive, so a hash printed
here could only describe the build *before* this file was last edited; the authoritative number is the
one in the `.sha256` file, and `bash build-nexa-archive.sh` reproduces and prints it from scratch
(27 key files checked, 242 files scanned for secrets/state, nothing packaged if anything is found).

Two packaging defects were caught by this verification and fixed (they are defence in depth: the archive
still installed and tested green *without* the missing file):

| Packaging defect | Impact | Fix |
| --- | --- | --- |
| the exclude list dropped `.gitignore` (a `--exclude '.git*'` pattern matched it) | the shipped project no longer documented which files must never be committed (`.env`, databases, uploads, keys) | the pattern now excludes the `.git` directory only; `tests/unit/test_repo_invariants.py` and `tests/deployment/test_deployment_assets.py` run against the **extracted archive** and fail if `.gitignore` is missing again |
| an earlier build did not restore executable bits before zipping | `install.sh` and the service scripts arrived non-executable on a fresh host | the builder `chmod +x`es every `*.sh`/`*.bat` first and the archive is inspected afterwards (61 executable entries in the current build) |

It was verified the same way as every previous one — extracted into an empty directory and **installed
with its own installer** (`sudo bash deployment/linux/install.sh --no-nginx --public-port 8099`, exit
**0**, `health check passed`, `administrator sign-in verified`), the installed instance then answering
`/readyz` **200**, serving the SPA **200**, signing the administrator in **200**, reporting
`dialect: postgresql` with `pending_migrations_checked: true`, and — inside the installed virtualenv,
against PostgreSQL — storing a **0.28 credits/MTok** model, resolving it to `280000` micro-credits per
MTok and charging exactly `50000` micro-credits (0.05 credits) for 100 000 input + 20 000 output
tokens (§1, row 36).

No file had to be copied in from the development workspace, and no manual `.env` editing was needed.

### 1.4 Defects found and fixed by these tests

| Defect | Impact | Fix |
| --- | --- | --- |
| Six module endpoints (`coding/assist`, `translation/translate`, `data/analyze`, `image/generate`, `image/analyze`, `audio/speak`) returned `200` without committing | the reported charge and the generated file were rolled back: users were not charged and files were orphaned on disk | explicit `db.commit()` before responding + regression tests in `backend/tests/test_modules_persistence.py` |
| Flat prices (`selling_per_image`, `selling_per_request`, `selling_per_audio_minute`) were truncated to integers | `0.25` credits per image became `0` — images were effectively free whenever the default pricing rule existed | `_flat_credits_to_micro()` (full credit amount) and half-up rounding for per-MTok values + unit tests in `backend/tests/test_pricing_units.py` |
| Catalogue listing crashed with `TypeError` for unpriced models (`micro_to_credits(None * 1e6)`) | a single unpriced model broke the whole model list (HTTP 500) for every user | `_per_mtok_credits()` helper returning `None` for unpriced models + regression test |
| Frontend referenced permission slugs the backend does not define (`admin.access`, `system.read`, `errors.read`, `refunds.approve`, wildcard group gate) | administrative navigation and a refund button could be hidden from users who legitimately hold the real permission | slugs aligned with `backend/app/models/enums.py`; the invariant test now cross-checks every `hasPermission()` slug against the backend catalogue |
| `response.headers.pop("X-Frame-Options")` in the security-header middleware (`MutableHeaders` has no `pop`) | **every** request returned `500` whenever `NEXA_FRAME_ANCESTORS` was set — the embedding feature could never work | `del response.headers[...]` guarded by a membership check; `backend/tests/test_http_hardening.py` pins the whole contract (deny by default, allow-list replaces it, never both) |
| Catalogue, payments and admin-settings screens crashed to a white page in the browser (React error #31 and two `TypeError`s) | three commercial screens were unusable although the APIs were correct: the SPA read `operation_labels` (per-locale objects), `payment-methods.methods`/`gateways` (objects keyed by slug) and `admin/settings` (a flat categorised list) as arrays | responses are read as the API really sends them, per-locale labels go through a `localized()` helper, categories are grouped client-side; `backend/tests/test_ui_contracts.py` pins all three shapes so neither side can drift silently |
| No error boundary anywhere | a single failing screen blanked the entire application with no way back | a top-level error boundary renders the failure, the technical message and *Try again* / *Back to dashboard* actions |
| Chat streaming returned `403 csrf_failed` in a fresh tab | the primary feature of the product failed for a user who had simply reloaded the page: the page read a `<meta name="csrf">` tag that does not exist, and the in-memory token is lost on reload | the client reads the JavaScript-readable `nexa_csrf` cookie the backend already sets (with the in-memory copy first and a one-shot recovery when a token is genuinely stale); pinned by a contract test |
| `[object Object]` printed in the top bar and the sidebar, and the "system" theme button silently applied dark | roles arrive as `{slug, name}` objects, and the account's stored theme overrode the local choice on every reload so dark/glass mode appeared broken | roles are rendered through a `roleLabel()` helper (types updated to `RoleRef[] | string[]`), and a device preference now wins over the account copy (the pre-paint script, the switcher and `auth/me` agree) |
| A failed provider connection surfaced as `Provider connectivity failure:` — a label, a colon and nothing else | the operator (and the product owner) could not tell DNS from firewall from TLS from a wrong base URL; several `httpx` exceptions have an empty `str()` (measured: `ConnectTimeout`, `ReadTimeout`), so the message the UI printed carried no information at all | `classify_exception()` now always builds a substantive message: the endpoint actually called, the exception class, `errno`/underlying cause and a one-line explanation, plus `details.endpoint`/`details.exception` and hints that name the diagnostic command; the query string (which can hold a key) is stripped before anything is rendered |
| The streamed chat path never retried a transient transport failure, while the non-streamed path did (2 attempts by default) | the chat UI uses SSE, so a single flapping connection — RST from a firewall, a proxy hiccup, a provider restart — made every chat fail with `provider_connectivity` **while the administrator's connection test stayed green** (it calls `GET /models`, a different request). Reproduced on purpose with `tests/tools/flaky_upstream.py`, which resets the first streaming request: before the fix the chat failed 100 % of the time | `stream_lines()` now uses the same retry policy as `request()` — but only while **nothing has been streamed yet** (a retry after the first token could duplicate the answer); after partial output it fails honestly and marks `details.partial_stream=true`. The same flapping provider now answers: `events=['meta','delta','delta','done']` |
| Two supervisors fighting over the API port (a systemd unit **and** the process launcher) | on a host where systemd exists the installer creates `nexa-api.service`, but a launcher-started `uvicorn` can still own `127.0.0.1:8000`: the unit then crash-loops (`activating (auto-restart)`, `[Errno 98] Address already in use`) while the **stale** API answers, so the deployment looks installed but serves old settings — the fresh install ended with a misleading `admin sign-in 401` | the restart step is now supervisor-aware: it stops the launcher, stops the units, kills only processes of *this* installation (`pkill -f "$APP_DIR/venv/bin/uvicorn app.main:app"`), waits for port 8000 to be released, `reset-failed`, then starts exactly one supervisor (systemd, with the launcher as a fallback), waits up to 60 s for `/healthz` and counts the surviving API processes; the conflict was reproduced on purpose (launcher owning the port + crash-looping unit) and the installer repaired it to a single healthy service |
| The admin **pricing page read `items` while the endpoint answers `rules`** (the same class of defect the other three UI-contract tests cover) | the rules table rendered **empty with no error**: an administrator could not see or edit a single price, and the page also repeated the unit explanation and printed a nonsensical *"spend today: 524.64 of 0 credits"* | the page reads `rules` (with `items` as a fallback), shows the server's own `unit_note`, states "no daily platform limit configured" instead of *of 0 credits*, and `test_ui_contracts.py::test_admin_pricing_rules_keep_their_shape` pins the shape; verified in a real browser (`preview-tools/page-recheck.cjs --vp 1440x900 --page /app/admin/pricing` → 0 measured problems, rules visible) |
| **Per-token prices below one credit per million tokens rounded to zero** — `_as_micro()` converted *credits/MTok* to *micro-credits **per token***, an integer | the money bug of the whole delivery: 1 micro-credit per token is the smallest representable price, so `0.28`, `0.10`, `0.05` — i.e. **every real provider price** — became `0` and each request was billed as **free** while the API answered `200` and the usage row said `succeeded`. Observed live in the Telegram demo: `charged_micro=0`, no ledger entry, silently | per-token prices are now **micro-credits per 1 000 000 tokens** (the number the operator types, scaled by 1e6: `0.28 -> 280000`), charges are `tokens × rate / 1e6` rounded half-up per line item, and migration `c7d41b0f9a13` rescales existing rule prices by 1 000 000 so **no rule changes its effective price**. Regression guards: `test_pricing_units.py` (`0.10 → 100000`, `0.4 → 400000`, `0.281234 → 281234`), `test_billing.py` (balance delta + ledger entry for a cheap model), and the live Telegram charge above |
| The same unit collision inflated **provider cost** by 1e6 — `usd_to_micro()` returns micro-credits *per million tokens*, but it was multiplied by the token count directly | a $0.20/MTok provider cost was recorded (and charged) as $0.20 **per token**; any price the platform *derived* from provider cost + markup was inflated the same way, turning a 0.13 credits/MTok model into ~130 000 credits/MTok | per-token costs and prices share one unit and one code path (`_tokens_charge()`); pinned by `test_provider_per_token_cost_is_a_per_mtok_rate_not_a_per_token_rate` and `test_derived_per_token_price_stays_in_the_credits_per_mtok_range` |
| **Write payloads silently ignored unknown fields** — Pydantic's default `extra` behaviour dropped them | a typo'd price (`selling_per_mtok_input` instead of `selling_input_per_mtok`) returned **200** and left the model **unpriced**; the only trace was a warning deep in the server log, so an administrator believed the model was priced while every request of it was free | every write payload derives from `StrictModel` (`extra="forbid"`, ~45 schemas); an unknown key is a `422 validation_error` naming the offending field. `test_schema_strictness.py` pins the behaviour *and* that the correct field names still work; the Telegram demo stack (which had the typo) was fixed and now proves a non-zero charge |
| The Telegram polling thread died on the first transient network error — `telegram._sleep` did `await threading.Event.wait()`, which returns a **bool** | `object bool can't be used in 'await' expression` killed the polling thread the moment Telegram hiccuped: the bot went permanently deaf while the platform looked healthy — in production this is a silent outage of the whole Telegram feature | `_sleep` handles `threading.Event` (blocking wait in an executor), `asyncio.Event` and `None`; both entry points (`services/inline_worker.py`, `workers/worker.py`) now supervise the loop with exponential backoff (5 s × attempt, capped at 60 s) and log start/stop; `test_telegram.py` pins both the sleep contract and survival across a deliberately failed `getUpdates` |
| `preview.env`-style env files with unquoted spaced values | `NEXA_APP_NAME=Nexa AI` executes `AI` as a command when the file is sourced by a shell | values containing spaces are quoted in the file; the application reads `.env` with its own parser, so production installs are unaffected |

| **Every ops script died on the `.env` file the installer writes** — `backup.sh`, `restore.sh` and `health_check.sh` loaded it with `set -a; source .env`, and the generated first line is `NEXA_APP_NAME=Nexa AI` | sourcing that line makes the shell try to execute `AI`; under `set -e` the script **exits 127 before doing anything** — no backup, no restore, no health check, on every installation the installer produced, with no error message | `.env` is now *parsed*, never executed (`scripts/lib_env.sh`: `nexa_env_value`/`nexa_env_load`, quoted values, `export` prefix, CRLF, comments), the installer quotes the value it writes, and two guards pin it (`test_ops_scripts_never_source_the_env_file`, plus a functional parser test with the installer's own shapes) |
| `pg_dump`/`pg_restore` received the **SQLAlchemy** URL (`postgresql+psycopg2://…`), which libpq does not understand | libpq silently fell back to the local socket and the operating-system user: `FATAL: role "root" does not exist` — **every PostgreSQL backup failed on a correctly installed server** (the app connects fine, so nothing else hinted at a problem); the failed dump also left a **0-byte `.dump`** that looks exactly like a finished backup and would survive retention pruning | `libpq_url()` strips the `+driver` suffix before handing the URL over, `--no-password` prevents a scheduled job from hanging on a prompt, and dumps/backups are written to a `.partial` file and renamed only on success (`trap` removes the leftovers) — pinned by `test_backup_writes_atomically_and_never_leaves_empty_archives` |
| The documented manual restore drill could produce a **restored-but-unusable** database | on PostgreSQL 15+ `public` belongs to the database owner: a drill run as `postgres` (`createdb nexa_drill`, `pg_restore --no-owner`) creates every table for that role, and an API started against it then dies with `SQLAlchemy ProgrammingError: permission denied for table permissions` — the drill looked successful and the restore was worthless | `scripts/restore_drill.sh` does the whole drill in one command *correctly*: scratch database created **owned by the application role**, restored **as that role**, table/user/`credit_ledger` counts printed, throw-away API booted against the restored data (`/readyz`), administrator sign-in verified, `app.cli doctor` required to report `inconsistent: 0`, credentials redacted, scratch database dropped unless `--keep`; a static test pins those properties |
| `reset-password` (the documented operator unlock path) assigned `user.failed_login_attempts`, **an attribute that does not exist** on the model (it is `failed_login_count`) | SQLAlchemy accepts unknown attribute assignments silently, so the failed-sign-in counter was never cleared while the command reported success — the account unlocked but kept its "repeated failures" state, and the stale write made the unlock look like it worked | the attribute is fixed and locked by two tests: a functional one that asserts `locked_until is None` **and** `failed_login_count == 0` after the CLI runs, and an AST scan (`test_no_app_code_assigns_unknown_user_attributes`) that rejects any assignment to an unmapped attribute on a `User` row anywhere in `app/` |
| An `.env` the service user cannot read (the normal result of `sudo mv`/`sudo cp` over it) produced a bare `PermissionError` traceback | systemd keeps reporting the unit as **active** while every worker dies, so the operator sees a healthy service that answers nothing and no explanation | `get_settings()` converts it into an actionable `SystemExit` naming the file and the exact `chown`/`chmod` fix; executed live on the installed deployment (journal shows the message, `/readyz` 200 immediately after the ownership fix) |
| `configure_logging()` bailed out after its first call, and its handler captured `sys.stdout` at construction time | a later call could not change the target stream (the CLI asks for `stderr` to keep its JSON report machine-readable) or the level, handlers could stack and duplicate every line, and a handler pinned to a capture buffer swallowed output after that buffer was closed — the visible symptom was a test run that printed `[100%]` and then **no `N passed` line at all** | the handler resolves `sys.stdout`/`sys.stderr` on every emit and previously installed handlers are tagged and replaced (`test_logging_config.py`, 3 tests) |
| The Telegram demo tooling talked to a **stale process** left on `:8031` by an aborted run | the run failed with `! the bot did not answer an unlinked user` and no hint about the squatter — a confusing false alarm that cost real debugging time | the demo stack refuses to start when its ports are occupied and prints the `ss` command to find the owner (`_require_free_ports`) |

| The installer's printed URL in **local mode** pointed at `${PUBLIC_PORT}` (8080) while no Nginx is installed in that mode, so the app actually answers on 8000 | the operator is handed a link that never opens and concludes the install failed | local mode now uses the API's own port for the base URL, the CORS origins, the printed URL and the "on this machine" line — and the run above proves the printed URL answers 200 |
| `check_public_access.sh` probed **`http://`** for the second of two target loops even when `--scheme https` was requested | an HTTP request against port 443 makes nginx answer **400 "The plain HTTP request was sent to HTTPS port"**; the check printed that as the result and then declared an HTTPS installation unreachable — the exact opposite of the truth | every probe (including the two loopback readiness waits) follows `--scheme`; a static test rejects any remaining `probe "http://` |
| The administrator sign-in self-check talked to `http://127.0.0.1:${PUBLIC_PORT}` — through the proxy | in domain+HTTPS mode port 80 answers **301 to the domain**, which does not resolve from inside the host, so the check failed on a perfectly good installation and printed *"the password stored in .env is probably outdated"*, sending the operator to reset a password that was fine | the check now targets the API itself on `http://127.0.0.1:8000` (the process whose credentials are being verified); Nginx and TLS are verified separately |
| `--admin-email you@example.com` on an **existing** installation was silently ignored: `.env` becomes the source of truth before the comparison, so the requested value had already been overwritten | the operator asks for something, gets nothing, and is told nothing — they would only find out when the e-mail they expect does not work | the requested value is remembered separately, the installer keeps the existing administrator **and says so loudly** (once), with the way forward in the same message |
| The access-mode switch (and the HTTPS flip) was applied *after* the services started, and the certificate was only looked for in the Nginx step | mode churn: a re-run wrote HTTP values, started the services, then wrote HTTPS values and restarted them again — two restarts and a window in which the running configuration did not match `.env` | an existing certificate is detected *before* the first write of `.env`, so the HTTPS configuration is written once; re-running now performs exactly one restart (measured: zero `-> http` downgrades and one service restart in the domain run) |
| Windows installer had no way to choose anything: always `admin@example.com`, a generated password, `NEXA_DEPLOYMENT_MODE=local` | the Windows path could not expose the app to other machines at all, and the owner could not set their own administrator | `install.bat` asks mode + e-mail + name + password (hidden prompt, Enter to generate), writes a coherent `.env` (deployment mode, base URL, port, trusted hosts, CORS), adds the firewall rule for the chosen port, and `start.bat` binds `0.0.0.0` on that port in public mode; `deployment\windows\set_admin.bat` changes the administrator later, and `create-admin --generate` / `NEXA_ADMIN_PASSWORD` keep the password out of the process list |

## 2. Implemented but **not executed** here (and why)

| Area | Reason not executed | Evidence that it is implemented |
| --- | --- | --- |
| Docker build/run of `Dockerfile.backend`, `.worker`, `.frontend` and `docker-compose.yml` | no Docker daemon in the environment | the Compose file is parsed and asserted by `tests/deployment` (services, no published DB/Redis, health checks, correct env); the Dockerfiles contain the exact commands (`alembic upgrade head`, `app.cli bootstrap`, `npm run build`) and are never run as root |
| `deployment\windows\install.bat`, `start*.bat`, service installation | no Windows host | asset test verifies every referenced file, the venv interpreter usage and the called modules; manual procedure documented in `docs/INSTALL_WINDOWS.md` |
| Multi-worker (multi-replica) rate-limit *sharing* | a single API process was tested; the Redis keys are shared, but two replicas under load were not | `app/core/ratelimit.py` keeps the window in Redis (`nexa:rl:<key>:<window>`), so limits are shared by construction; single-process behaviour is executed (see §1 row 39) |
| Malware scanning | no scanner installed | `NEXA_MALWARE_SCAN_ENABLED` + command; status is reported as `disabled`, never as a fake "clean" |
| Transactional email (verification, password reset) | no SMTP server | `app/services/email.py` queues into `email_outbox`; the endpoints exist and are tested for their API contract |
| Backup → restore drill on **SQLite** | the PostgreSQL drill is now executed (see §1 row 38); the SQLite path is covered by the same scripts | SQLite branch of `scripts/backup.sh`/`restore.sh` + `tests/deployment` statics |

### 2.1 Executed backup/restore evidence (SQLite path)

```
scripts/backup.sh            → nexa-sqlite-<stamp>.db + nexa-uploads-<stamp>.tar.gz
scripts/verify_backup.sh ... → integrity_check ok, table/user/ledger counts reported
scripts/restore.sh ... --yes → refuses without --yes; refuses while the API runs;
                               keeps a *.pre-restore.<stamp> copy; restores the file
scripts/health_check.sh      → liveness/readiness/api/deep all 200 after restart
app.cli doctor               → ledger inconsistency count 0 after the restore
```

The PostgreSQL variant of the same scripts **is** exercised — see §1 row 38 (`scripts/restore_drill.sh`).

## 3. Requires real credentials (cannot be verified without them)

Note: the Ubuntu/Debian installer, PostgreSQL operation, Nginx proxying and the launcher mode are
**no longer** in this list — they were executed on a clean Debian 13 host (§1.2).

| Integration | Needed | What to check after configuring |
| --- | --- | --- |
| OpenAI / Azure OpenAI | API key (+ endpoint, api version) | provider test → model sync → admin model test → chat + image |
| Anthropic | API key | provider test → admin chat test (Messages API) |
| Google Gemini | API key | provider test → admin chat/vision test |
| OpenRouter / Groq / Mistral / Together / DeepSeek | API key | provider test → model sync → admin test |
| Stability / Replicate | API key | image (and video for Replicate) admin test |
| ElevenLabs / Deepgram | API key | speech / transcription admin test |
| Ollama or any self-hosted OpenAI-compatible server | reachable URL | set `NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=true`, then test/sync/test-model |
| Stripe / Zarinpal | secret key + webhook secret + public webhook URL | a completed payment that only credits after webhook signature verification |
| Crypto payments | real wallet addresses | `NEXA_CRYPTO_WALLETS`, submit a payment, verify on-chain, approve |
| SMTP | host/user/password | registration → verification email → password reset |

The suite substitutes a **real HTTP** OpenAI-compatible upstream double
(`tests/tools/mock_openai_upstream.py`) for the network round-trip, which is why the request/usage/
billing path is verified end-to-end even without a paid account. Live vendor traffic remains untested.

## 4. Requires infrastructure you must provide

| Test | Needs |
| --- | --- |
| Compose stack up/down/upgrade, volume persistence | a Docker host |
| Ubuntu installer on a *pristine cloud image* beyond Debian 13 | another distribution/version (Ubuntu 22.04/24.04, RHEL family) — the script targets Debian/Ubuntu |
| Windows installer + service mode | a Windows machine |
| Public-IP reachability from outside the sandbox | a VPS with a public IPv4 address and firewall control |
| HTTPS + certbot + HSTS verification | a domain pointing at that VPS |
| Load/concurrency behaviour | a load driver (locust/k6) and a provider quota that tolerates it |
| Browser interaction tests (click-through UI) | a headless browser (Playwright) — the delivered `tests/e2e` covers the served app, assets, headers and API instead |

## 5. How to reproduce everything that was executed

```bash
# 1. repository-level
python -m pytest tests/unit tests/deployment -q

# 2. backend
cd backend && rm -rf /tmp/nexa-tests-* && python -m pytest tests/ -q && cd ..

# 3. build the SPA
cd frontend && npm install && npm run build && cd ..

# 4. run the stack (development database is fine for this)
export NEXA_ENVIRONMENT=development NEXA_DEPLOYMENT_MODE=public_ip
export NEXA_SECRET_KEY=$(python3 -c "import secrets;print(secrets.token_urlsafe(48))")
export NEXA_ENCRYPTION_KEY=$(python3 -c "from cryptography.fernet import Fernet;print(Fernet.generate_key().decode())")
export NEXA_BOOTSTRAP_ADMIN_EMAIL=admin@example.com NEXA_BOOTSTRAP_ADMIN_PASSWORD='Nexa-Admin-Passw0rd-2026!'
export NEXA_ALLOW_PRIVATE_PROVIDER_ENDPOINTS=true          # allows the local upstream double
cd backend && python -m alembic upgrade head && python -m app.cli bootstrap
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 &

# 5. upstream double + integration test
cd ..
python3 tests/tools/mock_openai_upstream.py --port 9099 --api-key sk-mock-key &
python3 tests/integration/test_live_stack.py \
  --base-url http://127.0.0.1:8000 --upstream http://127.0.0.1:9099 \
  --admin-email admin@example.com --admin-password 'Nexa-Admin-Passw0rd-2026!'

# 6. served-app smoke
python -m pytest tests/e2e -q
```

## 6. Coverage summary (what is actually asserted)

| Layer | Covered |
| --- | --- |
| Authentication | registration, login, logout, password change/reset, session listing and revocation, lockout, verification |
| Authorization | 6 roles, 30 permissions, per-endpoint enforcement, admin surface blocked for normal users, cross-user object access denied |
| Providers | adapter registry, credential encryption/masking, connection test, sync, disable semantics, error taxonomy (401/429/5xx/timeout/unsupported) |
| Catalogue | visibility/availability/tier combinations, unpriced models, payable-model visibility, subscription gating, anonymous exposure limits |
| Billing | ledger invariants, idempotent approval, refunds as compensating entries, parallel debits without overdraw, spend caps, failed-call zero charge, subscription credits |
| Modules | chat (streaming and non-streaming), coding, translation, documents, data analysis, image generation/analysis, speech, transcription — including post-response persistence |
| Files | extension/signature validation, size and quota limits, traversal attempts, download authorization, storage summary |
| Jobs | enqueue, claim/lease, retry loop to terminal state, cancellation |
| Operations | health endpoints, `doctor` report, migration and bootstrap idempotency, deployment assets, docs/README consistency, SPA smoke |

## 7. Verdict

* **Executed and green:** backend suite (**230 passed / 0 failed**), repository suites
  (**206 passed / 11 skipped**: unit 23, deployment 183, served-app e2e 10), real-provider check **18/18**, live-stack integration
  (**38/38**), model-variant e2e against a running API (**12/12**), the full Telegram chain
  (unlinked refusal → link → welcome + guide → menus → **charged** model answer), browser
  responsiveness (**0 measured problems** across five viewports), frontend production build,
  migrations + bootstrap on SQLite **and** PostgreSQL, CLI diagnostics, SQLite *and* **PostgreSQL**
  backup → verify → restore (automated drill: API booted on restored data, sign-in 200, ledger
  reconciled), **Redis-backed rate limiting with the fallback path**, an **HTTPS/TLS rehearsal**
  through the shipped Nginx template (TLS 1.2-only, HSTS, secure cookies, HTTP→HTTPS redirect), and
  a full install from the delivered archive (exit 0) followed by a money round-trip on that
  installation.
* **Implemented, unexecuted here:** Docker stack (no daemon in this environment), the Windows
  installer on real Windows hardware, malware scanning, SMTP delivery, gateway round-trips, video
  generation, a two-replica rate-limit load test, a **public CA** certificate (needs a domain; the
  TLS path itself was rehearsed with a self-signed certificate — the installer detects and reports
  that case honestly), the Windows installer on real Windows hardware (its questions, mode-dependent
  `.env`, firewall rule and `start.bat` binding are pinned by tests, not executed on Windows), and
  browser-level interaction tests beyond the screenshots/headless checks recorded in §1.
* **Credential-dependent:** all real vendor provider calls and payment gateways (documented in
  `docs/PROVIDER_CONFIGURATION.md` and `docs/BILLING.md`).
* **Infrastructure-dependent:** public-IP and HTTPS verification, load testing, Windows/Docker hosts.

Twenty-two defects were found by the executed tests and fixed (the complete table is §1.4; the most
consequential are the per-token pricing unit that made every realistic model price free, the 1e6
inflation of provider cost, the silently-dropped request fields that left a model unpriced, and the
Telegram polling thread that died on the first network error). No feature in this delivery
is represented only by a mock, a placeholder or a fabricated success message: where an integration is
untested, this report says so and the implementation fails loudly (`503 not_configured`) rather than
pretending.
