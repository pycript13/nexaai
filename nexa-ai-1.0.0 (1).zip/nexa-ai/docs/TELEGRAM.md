# Telegram bot

Nexa AI ships an optional Telegram bot: a verified user of the platform can talk to the same
models from Telegram, and every message is billed to that platform account through the normal
credit ledger. Nothing is free and nothing is anonymous — the bot only answers a Telegram id that
has been **linked to a registered platform account**.

This document is the operator's guide. It was written while the integration was exercised against
the live Telegram Bot API (see `docs/TEST_REPORT.md`, row "Telegram bot, real token").

---

## 1. Do I need it?

No. The bot is off unless a token is configured (`NEXA_TELEGRAM_ENABLED=false` by default), and
the platform works fully without it. Turn it on when you want a second delivery channel.

## 2. Create the bot and get the token

1. Open Telegram, start a chat with [@BotFather](https://t.me/BotFather).
2. Send `/newbot`, choose a name (display name) and a username ending in `bot`
   (e.g. `MyNexaAssistantBot`).
3. BotFather answers with the **token**, e.g. `123456789:AAE…`. Treat it as a password:
   anyone holding it controls the bot.
4. Optional but recommended: `/setdescription`, `/setuserpic`, and `/setcommands` with

   ```
   start - link this chat to your Nexa AI account
   help - what this bot can do
   status - your credits and linked account
   models - list the models available to you
   reset - clear the current conversation context
   ```

## 3. Configure the server

Add these lines to the deployment's `.env` (`/opt/nexa-ai/.env` on the Linux installer,
`<install dir>\.env` on Windows) and restart the services:

```ini
NEXA_TELEGRAM_ENABLED=true
NEXA_TELEGRAM_BOT_TOKEN=123456789:AAE…            # the token from BotFather
NEXA_TELEGRAM_BOT_USERNAME=MyNexaAssistantBot     # without the @; used for t.me deep links
NEXA_TELEGRAM_MODE=polling                        # polling | webhook
# Only for webhook mode (see §5): the value Telegram must send back in the secret header
NEXA_TELEGRAM_WEBHOOK_SECRET=
# Optional: a chat id that receives a short "bot is up" notice at start-up
NEXA_TELEGRAM_ADMIN_CHAT_ID=
```

Then make sure **something is doing the polling**:

| Deployment | What runs the bot |
| --- | --- |
| Linux, systemd | the `nexa-worker` service already polls (`deployment/linux/nexa-worker.service`) |
| Linux, no systemd (containers) | `nexa-services.sh` starts the same worker process |
| Windows | `NEXA_INLINE_WORKER=true` in `.env` lets the API process poll — nothing else to start |
| Docker Compose | the `worker` service polls |

Restart and verify:

```bash
# Linux
sudo systemctl restart nexa-api nexa-worker            # or: nexa-services.sh restart
journalctl -u nexa-worker -n 30 | grep -i telegram      # expect: "telegram polling starting"
# any deployment, through the API:
curl -s -X POST http://127.0.0.1:8000/api/v1/admin/telegram/test \
     -H "Cookie: …" -H "X-CSRF-Token: …"                # or use Admin → Settings → Telegram → Test
```

`Admin → Settings → Telegram → Test` (and the endpoint above) performs a real `getMe` call: only a
successful answer proves the token works. The reply states the bot's `@username`, so a wrong token
in a shared `.env` is obvious immediately.

## 4. Linking a Telegram account (the security model)

A Telegram id **cannot use the bot** until it is linked to a platform account:

1. The user signs in at the site and opens **Profile → Telegram**.
2. Presses **Create link code** — a short-lived, one-time code is issued (`/api/v1/telegram/link-code`).
3. The user sends `/start <code>` (or just the code) to the bot.
4. The platform consumes the code, stores the link (`telegram_links`) and replies with a welcome
   message plus a short usage guide.
5. From then on, every message from that chat id is answered **as that platform user**: access
   rules, credit balance, model availability and pricing are exactly the same as on the website.

Unlinked visitors get an explanation and the linking instructions — never a model answer. A user
can unlink at any time from the same screen (`DELETE /api/v1/telegram/link`).

## 5. Transports: polling vs webhook

| | Polling (default) | Webhook |
| --- | --- | --- |
| Needs a public HTTPS URL | no — works behind NAT, containers, a home server | yes |
| How it works | the worker calls `getUpdates` in a loop | Telegram POSTs each update to `/api/v1/telegram/webhook` |
| Configure | `NEXA_TELEGRAM_MODE=polling` | `NEXA_TELEGRAM_MODE=webhook` + `NEXA_TELEGRAM_WEBHOOK_SECRET`, then register the URL (Admin → Settings → Telegram, or `POST /api/v1/admin/telegram/webhook`) |
| Only one consumer | required: two pollers cause `409 Conflict` (Telegram kills the older call) | — |

Polling is the right choice for almost every self-hosted installation, and it is what the shipped
services run. Use a webhook only if you have a public HTTPS endpoint and want the lowest latency.

## 6. Billing

* Every model answer is charged to the linked platform account exactly like a website request, with
  an immutable ledger entry (`usage:` key) and a usage row (`module=telegram`).
* No balance → no answer: the bot replies with the same "add credits" explanation the API returns.
* Administrative tests and the bot are separate: bot traffic is user traffic.
* `/status` shows the balance the user's own account has; there is no hidden free allowance.

## 7. Commands the bot answers

| Command | What happens |
| --- | --- |
| `/start` | welcome + linking instructions (or confirmation when the code is valid) |
| `/help` | usage guide |
| `/status` | linked account, credit balance, message count |
| `/models` | the models **this account** may use (paginated) |
| `/reset` | clears the conversation context for the bot chat |
| any other text | sent to the account's selected model, streamed back as a normal Telegram message |

The conversation with the bot is stored server-side on the platform like any other conversation,
so it appears in the workspace history and is auditable.

## 8. Troubleshooting

| Symptom | Cause and fix |
| --- | --- |
| `Admin → Settings → Telegram → Test` says "not configured" | `NEXA_TELEGRAM_ENABLED` is not `true`, or the token is missing/empty in the `.env` the service reads |
| Log shows `Conflict: terminated by other getUpdates request` | two pollers with the same token: stop the other one (an old deployment, a local script, or the same bot configured twice) |
| Bot is silent although the token is valid | nothing is polling: check that the worker (or `NEXA_INLINE_WORKER=true`) is running and that the log contains `telegram polling starting` |
| Unlinked users get no model answers | intended: linking is the gate. Create a code in Profile → Telegram |
| Answers never arrive but `/status` works | the account has no credits, or the selected model is not accessible — the bot repeats the API's own reason |
| Webhook mode: updates are not delivered | the URL must be public HTTPS; a self-signed certificate or a private address will not work — use polling |

## 9. Reference

* Endpoints: `GET/POST /api/v1/telegram/*` (user), `GET /api/v1/admin/telegram/status`,
  `POST /api/v1/admin/telegram/test`, `POST /api/v1/admin/telegram/webhook`.
* Server code: `backend/app/services/telegram.py` (transport, commands, billing) and
  `backend/app/workers/worker.py` / `backend/app/services/inline_worker.py` (the polling loop).
* Demo/verification harness: `backend/tests/tools/telegram_demo_stack.py` (runs the whole flow
  against a local Bot API stub, no real token needed).
* Environment variables: `.env.example` (Telegram section) and `deployment/windows/nexa.env.example`.
