#!/usr/bin/env bash
# Nexa AI — database + uploads backup.
#
# Usage:  scripts/backup.sh [--output-dir DIR] [--keep DAYS] [--uploads]
# Works with PostgreSQL (pg_dump) and with SQLite (file copy). Read-only on the app.
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUTPUT_DIR="${ROOT_DIR}/backups"
KEEP_DAYS=14
INCLUDE_UPLOADS=1

while [[ $# -gt 0 ]]; do
  case "$1" in
    --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
    --keep) KEEP_DAYS="$2"; shift 2 ;;
    --no-uploads) INCLUDE_UPLOADS=0; shift ;;
    -h|--help) sed -n '1,12p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
done

# Load environment (NEXA_DATABASE_URL, NEXA_UPLOAD_DIR, ...). Parsed, never sourced: the file is
# user-editable and contains values with spaces (`NEXA_APP_NAME=Nexa AI`), which `source` would
# try to execute (the script then died with exit 127 before writing a single backup).
# shellcheck source=lib_env.sh
. "${ROOT_DIR}/scripts/lib_env.sh"
nexa_env_load "${ROOT_DIR}/.env" NEXA_DATABASE_URL NEXA_UPLOAD_DIR NEXA_ENVIRONMENT

# libpq (pg_dump/pg_restore) does not understand SQLAlchemy dialect suffixes such as
# `postgresql+psycopg2://`. Passing the raw URL made libpq fall back to the local socket and the
# operating-system user ("FATAL: role \"root\" does not exist") — a PostgreSQL backup that failed
# although the application connects perfectly. Strip the driver part before handing it over.
libpq_url() {
  printf '%s' "${1}" | sed -E 's#^(postgres(ql)?)\+[A-Za-z0-9_]+://#\1://#'
}


DATABASE_URL="${NEXA_DATABASE_URL:-sqlite:///${ROOT_DIR}/data/nexa.db}"
UPLOAD_DIR="${NEXA_UPLOAD_DIR:-${ROOT_DIR}/uploads}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "${OUTPUT_DIR}"

log() { printf '%s [backup] %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*"; }

if [[ "${DATABASE_URL}" == postgres* ]]; then
  command -v pg_dump >/dev/null 2>&1 || { echo "pg_dump is required for PostgreSQL backups" >&2; exit 1; }
  TARGET="${OUTPUT_DIR}/nexa-pg-${STAMP}.dump"
  PARTIAL="${TARGET}.partial"
  log "dumping PostgreSQL database (custom format)"
  # Write to a partial file first: a failed dump used to leave a zero-byte .dump behind, which
  # looks exactly like a finished backup on disk (and would be picked up by a retention glob).
  rm -f "${PARTIAL}"
  trap 'rm -f "${PARTIAL}"' EXIT
  # --no-password: fail immediately and visibly instead of waiting for an interactive prompt
  # (a scheduled backup must never hang).
  pg_dump --format=custom --no-owner --no-privileges --no-password \
    --file="${PARTIAL}" "$(libpq_url "${DATABASE_URL}")"
  mv -f "${PARTIAL}" "${TARGET}"
  trap - EXIT
else
  DB_PATH="${DATABASE_URL#sqlite:///}"
  DB_PATH="${DB_PATH#sqlite://}"
  [[ -f "${DB_PATH}" ]] || { echo "SQLite database not found: ${DB_PATH}" >&2; exit 1; }
  TARGET="${OUTPUT_DIR}/nexa-sqlite-${STAMP}.db"
  log "copying SQLite database ${DB_PATH}"
  # Use the SQLite online backup API so the copy is consistent while the app is running.
  # Same partial-file discipline as the PostgreSQL branch.
  PARTIAL="${TARGET}.partial"
  rm -f "${PARTIAL}"
  trap 'rm -f "${PARTIAL}"' EXIT
  if command -v sqlite3 >/dev/null 2>&1; then
    sqlite3 "${DB_PATH}" ".backup '${PARTIAL}'"
  else
    cp "${DB_PATH}" "${PARTIAL}"
  fi
  mv -f "${PARTIAL}" "${TARGET}"
  trap - EXIT
fi

# Integrity/verification: the backup must be readable before we keep it.
"${ROOT_DIR}/scripts/verify_backup.sh" "${TARGET}"

if [[ "${INCLUDE_UPLOADS}" -eq 1 && -d "${UPLOAD_DIR}" ]]; then
  ARCHIVE="${OUTPUT_DIR}/nexa-uploads-${STAMP}.tar.gz"
  log "archiving uploads from ${UPLOAD_DIR}"
  tar -czf "${ARCHIVE}" -C "$(dirname "${UPLOAD_DIR}")" "$(basename "${UPLOAD_DIR}")"
  log "uploads archive: ${ARCHIVE} ($(du -h "${ARCHIVE}" | cut -f1))"
fi

if [[ "${KEEP_DAYS}" -gt 0 ]]; then
  log "removing backups older than ${KEEP_DAYS} days"
  find "${OUTPUT_DIR}" -maxdepth 1 -type f \( -name 'nexa-pg-*' -o -name 'nexa-sqlite-*' -o -name 'nexa-uploads-*' \) -mtime "+${KEEP_DAYS}" -print -delete || true
fi

log "backup complete: ${TARGET}"
