#!/usr/bin/env bash
# Nexa AI — one-command install for Daytona sandboxes (and any container host behind a
# TLS reverse proxy, i.e. a NATed machine that is published through a proxy URL).
#
# It wraps deployment/linux/install.sh — the same installer that runs on a real Ubuntu/Debian
# server — and then re-points the deployment at the HTTPS address a browser will actually use
# (the Daytona preview link), restarts the services and verifies the whole path itself.
#
# Usage:
#   sudo bash deployment/daytona/install-daytona.sh --public-url https://8080-<sandbox-id>.proxy.daytona.work
#
# Options:
#   --public-url URL   the HTTPS address the browser will open (a Daytona preview link).
#                      Recommended: pass it explicitly. Without it the script still installs,
#                      trusts every *.proxy.daytona.* host and prints how to obtain the link.
#   --port N           port inside the sandbox that the preview link points at (default 8080)
#   --app-dir DIR      install directory (default /opt/nexa-ai)
#   --admin-email A    first Super Admin e-mail (default admin@example.com)
#   --http             keep the deployment in plain-HTTP mode (secure cookies off). Use this
#                      only when you reach the sandbox over HTTP — e.g. an SSH tunnel — and
#                      never for a preview link (those are HTTPS).
#   --allow-embedding  add the preview host to NEXA_FRAME_ANCESTORS so the page may be loaded
#                      inside an <iframe> of the Daytona dashboard. Off by default: framing
#                      protection is what stops clickjacking.
#   --skip-install     only re-apply the Daytona settings and re-run the self-test (fast)
#   --admin-password P   pass through: the first Super Admin's password (non-interactive runs)
#   --no-packages      pass through to the installer (packages already installed)
#   --no-node          pass through to the installer (do not build the SPA)
#   --reset-admin-password
#                      pass through: reset the administrator to the password stored in .env
#   -h | --help        this help
#
# What it does:
#   1. installs the application (PostgreSQL, Redis, virtualenv, built SPA, migrations,
#      bootstrap, Nginx on --port) through deployment/linux/install.sh
#   2. rewrites .env for a proxied HTTPS deployment: deployment mode, public URL, secure
#      cookies, trusted hosts (*.proxy.daytona.*), CORS origins
#   3. restarts the API/worker under exactly one supervisor (systemd, else the process
#      launcher), repairing any leftover process that still holds port 8000, and reloads Nginx
#   4. verifies: /readyz, the SPA, /api/v1/meta/config and a real administrator sign-in —
#      all with the preview URL's Host header, so a "Invalid host header" cannot slip through
#   5. prints the URL to open, how to refresh an expired preview link, and the credentials
set -Eeuo pipefail

# nginx / ufw / pg_ctl* live in /usr/sbin and /sbin, often missing from a minimal PATH.
export PATH="/usr/sbin:/sbin:${PATH}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
INSTALLER="${PROJECT_DIR}/deployment/linux/install.sh"
SERVICES="${PROJECT_DIR}/deployment/linux/nexa-services.sh"
PREVIEW_HELPER="${SCRIPT_DIR}/preview_link.sh"
# shellcheck source=deployment/daytona/preview_link.sh
. "${PREVIEW_HELPER}"    # candidate URLs, reachability probe, sandbox-id detection

PUBLIC_URL="${NEXA_PUBLIC_URL:-}"
PUBLIC_PORT="${NEXA_PUBLIC_PORT:-8080}"
APP_DIR=""
ADMIN_EMAIL=""
HTTP_MODE=0
ALLOW_EMBEDDING=0
SKIP_INSTALL=0
PASSTHROUGH=()

log()  { printf '\033[1;36m[daytona]\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32m[daytona]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[daytona][warn]\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[daytona][error]\033[0m %s\n' "$*" >&2; exit 1; }

usage() {
  sed -n '2,50p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --public-url) PUBLIC_URL="${2:-}"; shift 2 ;;
    --public-url=*) PUBLIC_URL="${1#*=}"; shift ;;
    --port) PUBLIC_PORT="${2:-}"; shift 2 ;;
    --port=*) PUBLIC_PORT="${1#*=}"; shift ;;
    --app-dir) APP_DIR="${2:-}"; shift 2 ;;
    --app-dir=*) APP_DIR="${1#*=}"; shift ;;
    --admin-email) ADMIN_EMAIL="${2:-}"; shift 2 ;;
    --admin-email=*) ADMIN_EMAIL="${1#*=}"; shift ;;
    --http) HTTP_MODE=1; shift ;;
    --allow-embedding) ALLOW_EMBEDDING=1; shift ;;
    --skip-install) SKIP_INSTALL=1; shift ;;
    --no-packages|--no-node) PASSTHROUGH+=("$1"); shift ;;
    --admin-password)   PASSTHROUGH+=("--admin-password" "${2:-}"); shift 2 ;;
    --admin-password=*) PASSTHROUGH+=("$1"); shift ;;
    --generate-admin-password) PASSTHROUGH+=("$1"); shift ;;
    --reset-admin-password) PASSTHROUGH+=("$1"); shift ;;
    -h|--help) usage; exit 0 ;;
    *) die "unknown option '$1' (try --help)" ;;
  esac
done

[[ -n "${APP_DIR}" ]] || APP_DIR="/opt/nexa-ai"

# ---------------------------------------------------------------- root ---------
if [[ "$(id -u)" -ne 0 ]]; then
  command -v sudo >/dev/null 2>&1 || die "run this script as root (or install sudo)"
  log "re-running with sudo (the installer needs root)"
  exec sudo -E bash "${BASH_SOURCE[0]}" "$@"
fi

[[ -f "${INSTALLER}" ]] || die "cannot find ${INSTALLER} — run the script from inside the project directory"
[[ -f "${PROJECT_DIR}/backend/requirements.txt" ]] || die "${PROJECT_DIR} does not look like a Nexa AI project directory"

# ---------------------------------------------------------------- the installer --
if [[ "${SKIP_INSTALL}" -eq 0 ]]; then
  log "installing the application into ${APP_DIR} (this takes a few minutes)"
  log "the public-address probe is skipped on purpose: at Daytona the reachable address is the preview link, not the sandbox IP"
  INSTALL_ARGS=(--public-port "${PUBLIC_PORT}" --app-dir "${APP_DIR}" --no-public-check)
  [[ -n "${ADMIN_EMAIL}" ]] && INSTALL_ARGS+=(--admin-email "${ADMIN_EMAIL}")
  if [[ ${#PASSTHROUGH[@]} -gt 0 ]]; then INSTALL_ARGS+=("${PASSTHROUGH[@]}"); fi
  if ! bash "${INSTALLER}" "${INSTALL_ARGS[@]}"; then
    die "the base installer failed — fix the error above and re-run this script (it is safe to re-run)"
  fi
else
  log "--skip-install: keeping the existing installation in ${APP_DIR}"
fi

ENV_FILE="${APP_DIR}/.env"
[[ -f "${ENV_FILE}" ]] || die "expected ${ENV_FILE} to exist after the install"

# ---------------------------------------------------------------- preview URL ---
# The browser link is the only way into a sandbox: the sandbox IP is never reachable from outside,
# and the proxy answers 401 until the sandbox is public or the link is signed. So the link is
# resolved here, in order of trustworthiness:
#   1. --public-url (the operator knows it)           → source: given
#   2. `daytona preview-url` inside the sandbox       → source: cli (signed, expiring)
#   3. probing https://<port>-<sandbox-id>.<proxy>    → source: probed (answers /readyz 2xx now)
#   4. assuming the URL from the detected sandbox id  → source: assumed (dashboard-verify)
PREVIEW_SOURCE=""
SANDBOX_ID="$(nexa_preview_sandbox_id)"
# A container hostname such as `e2b.local` is *not* a sandbox id: never build a link out of it.
nexa_preview_plausible_id "${SANDBOX_ID}" || SANDBOX_ID=""
PREVIEW_ASSUMED=""
PREVIEW_ASSUMED_STATUS="000"
if [[ -n "${PUBLIC_URL}" ]]; then
  PREVIEW_SOURCE="given"
elif [[ "${HTTP_MODE}" -eq 0 ]]; then
  if command -v daytona >/dev/null 2>&1 && [[ -n "${SANDBOX_ID}" ]]; then
    if cli_url="$(timeout 30 daytona preview-url "${SANDBOX_ID}" --port "${PUBLIC_PORT}" --expires 86400 2>/dev/null | grep -oE 'https://[^[:space:]]+' | head -1)" && [[ -n "${cli_url}" ]]; then
      PUBLIC_URL="${cli_url}"
      PREVIEW_SOURCE="cli"
      log "daytona preview-url returned a signed link for port ${PUBLIC_PORT}"
    fi
  fi
  if [[ -z "${PUBLIC_URL}" && -n "${SANDBOX_ID}" ]]; then
    if probed_url="$(nexa_preview_resolve "${SANDBOX_ID}" "${PUBLIC_PORT}")" && [[ -n "${probed_url}" ]]; then
      PUBLIC_URL="${probed_url}"
      PREVIEW_SOURCE="probed"
      log "the preview proxy answered /readyz on ${PUBLIC_URL}: this sandbox is public, the link works for anyone"
    fi
  fi
  if [[ -z "${PUBLIC_URL}" && -n "${SANDBOX_ID}" ]]; then
    # Nothing proved this link, so it is *not* written into .env as the public base URL — it is a
    # candidate to check, and its answer is reported.
    PREVIEW_ASSUMED="$(nexa_preview_candidate_urls "${SANDBOX_ID}" "${PUBLIC_PORT}" | head -1)"
    PREVIEW_ASSUMED_STATUS="$(nexa_preview_probe "${PREVIEW_ASSUMED}")"
    warn "no link could be proven from inside the sandbox; the likely address is ${PREVIEW_ASSUMED} (HTTP ${PREVIEW_ASSUMED_STATUS})"
  fi
fi
if [[ -n "${PUBLIC_URL}" ]]; then
  PUBLIC_URL="${PUBLIC_URL%/}"
  if [[ "${PUBLIC_URL}" != https://* && "${HTTP_MODE}" -eq 0 ]]; then
    warn "the preview URL is not HTTPS ('${PUBLIC_URL}') — falling back to HTTP mode for cookies"
    HTTP_MODE=1
  fi
  PUBLIC_HOST="${PUBLIC_URL#*://}"
  PUBLIC_HOST="${PUBLIC_HOST%%/*}"
else
  PUBLIC_HOST=""
fi

# ---------------------------------------------------------------- .env rewrite ---
log "configuring the deployment for a proxied HTTPS preview"
python3 - "${ENV_FILE}" "${PUBLIC_URL}" "${PUBLIC_HOST}" "${PUBLIC_PORT}" "${HTTP_MODE}" "${ALLOW_EMBEDDING}" <<'PY'
import sys

path, public_url, public_host, port, http_mode, allow_embedding = sys.argv[1:7]
http_mode = http_mode == "1"
allow_embedding = allow_embedding == "1"

lines = open(path, encoding="utf-8").read().splitlines()
values: dict[str, str] = {}
for line in lines:
    if "=" in line and not line.lstrip().startswith("#"):
        key, _, value = line.partition("=")
        values[key.strip()] = value.strip()

# Hosts that must be accepted. A signed preview link contains a token in its hostname
# (https://8080-<token>.proxy.daytona.work), and those are regenerated with a new token,
# so the wildcard is what keeps a refreshed link working without editing .env again.
trusted = [h.strip() for h in values.get("NEXA_TRUSTED_HOSTS", "").split(",") if h.strip()]
for host in ("*.proxy.daytona.work", "*.proxy.daytona.works", "*.daytona.work", "*.daytona.io"):
    if host not in trusted:
        trusted.append(host)
if public_host and public_host not in trusted:
    trusted.append(public_host)
for host in ("localhost", "127.0.0.1"):
    if host not in trusted:
        trusted.append(host)

origins = [o.strip() for o in values.get("NEXA_CORS_ORIGINS", "").split(",") if o.strip()]
for origin in (public_url, f"http://localhost:{port}", f"http://127.0.0.1:{port}"):
    if origin and origin not in origins:
        origins.append(origin)

updates = {
    "NEXA_DEPLOYMENT_MODE": "public_ip" if http_mode else "domain_https",
    "NEXA_PUBLIC_PORT": port,
    "NEXA_COOKIE_SECURE": "false" if http_mode else "true",
    # HSTS on someone else's proxy domain would pin every other sandbox the operator visits.
    "NEXA_HSTS_ENABLED": "false",
    "NEXA_TRUSTED_HOSTS": ",".join(trusted),
    "NEXA_CORS_ORIGINS": ",".join(origins),
}
if public_url:
    updates["NEXA_PUBLIC_BASE_URL"] = public_url
if allow_embedding and public_host:
    frame_ancestors = values.get("NEXA_FRAME_ANCESTORS", "").strip()
    entries = [e for e in frame_ancestors.split() if e]
    for entry in (f"https://{public_host}", "https://*.proxy.daytona.work"):
        if entry not in entries:
            entries.append(entry)
    updates["NEXA_FRAME_ANCESTORS"] = " ".join(entries)

changed, added = [], []
for key, value in updates.items():
    if key in values:
        if values[key] != value:
            changed.append((key, values[key], value))
            for index, line in enumerate(lines):
                if line.startswith(f"{key}="):
                    lines[index] = f"{key}={value}"
    else:
        added.append((key, value))
        lines.append(f"{key}={value}")

with open(path, "w", encoding="utf-8") as handle:
    handle.write("\n".join(lines).rstrip("\n") + "\n")

print(f"  .env: {len(changed) + len(added)} setting(s) written")
for key, before, after in changed:
    print(f"    ~ {key}: {before or '(empty)'} -> {after}")
for key, value in added:
    print(f"    + {key}={value}")
PY
chmod 600 "${ENV_FILE}"

# ---------------------------------------------------------------- restart -------
# The base installer starts the services itself, with the .env it had at that moment, so a
# plain "restart" is not enough: on hosts without systemd the pid files do not always match
# the running processes, and the old API would keep answering with the old settings (a preview
# host that is not trusted yet -> "400 Invalid host header"). Stop through the launcher, make
# sure nothing of this installation survives, then start again and wait for it.
# Exactly one supervisor must own the API. An installation can end up with both a systemd
# unit and launcher processes (for example after the host gained systemd, or after a manual
# restart): the second copy then cannot bind port 8000, crash-loops and the `status` output
# lies. So: stop everything through both mechanisms, remove the stale pid files, and only
# then start one of them.
kill_leftovers() {
  # Anchored on this installation's own interpreter path, so an unrelated process on the host
  # (a second deployment, a dev server) can never be killed by accident.
  pkill -f "${APP_DIR}/venv/bin/uvicorn app.main:app" 2>/dev/null || true
  pkill -f "${APP_DIR}/venv/bin/python -m app.workers.worker" 2>/dev/null || true
  pkill -f "${APP_DIR}/venv/bin/python3.13 -m app.workers.worker" 2>/dev/null || true
}

api_is_listening() { ss -ltn 2>/dev/null | grep -qE '(:8000[[:space:]])'; }

wait_for_api() {
  for _ in $(seq 1 60); do
    [[ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:8000/healthz || true)" == "200" ]] && return 0
    sleep 1
  done
  return 1
}

log "restarting the API and the worker so they pick up the new settings"
APP_DIR="${APP_DIR}" bash "${SERVICES}" stop >/dev/null 2>&1 || true
if command -v systemctl >/dev/null 2>&1; then
  systemctl stop nexa-api nexa-worker 2>/dev/null || true
fi
kill_leftovers
rm -f "${APP_DIR}/run/api.pid" "${APP_DIR}/run/worker.pid"
for _ in $(seq 1 40); do api_is_listening || break; sleep 0.5; done
if api_is_listening; then
  warn "something is still listening on 127.0.0.1:8000 after stopping every Nexa AI process:"
  ss -ltnp 2>/dev/null | grep -E ':8000[[:space:]]' | sed 's/^/      /'
  warn "the API cannot start while that port is taken. Stop that process (kill <pid>) and re-run this script."
  exit 1
fi

USE_SYSTEMD=0
if [[ -f /etc/systemd/system/nexa-api.service ]] && command -v systemctl >/dev/null 2>&1; then
  systemctl reset-failed nexa-api nexa-worker >/dev/null 2>&1 || true
  if systemctl start nexa-api nexa-worker >/dev/null 2>&1 && wait_for_api; then
    USE_SYSTEMD=1
    ok "services started through systemd (nexa-api.service, nexa-worker.service)"
  else
    warn "the systemd units did not bring the API up — falling back to the process launcher"
  fi
fi
if [[ "${USE_SYSTEMD}" -eq 0 ]]; then
  kill_leftovers
  APP_DIR="${APP_DIR}" bash "${SERVICES}" start >/dev/null || warn "the launcher reported a problem starting the services"
  wait_for_api || warn "the API did not answer on 127.0.0.1:8000 within 60 s"
fi

if ! wait_for_api; then
  printf '    port 8000 is held by:\n'
  ss -ltnp 2>/dev/null | grep -E ':8000[[:space:]]' | sed 's/^/      /' || echo "      (nothing is listening)"
  printf '    last lines of %s:\n' "${APP_DIR}/logs/api.log"
  tail -n 12 "${APP_DIR}/logs/api.log" 2>/dev/null | sed 's/^/      /' || true
  systemctl status nexa-api --no-pager -n 6 2>/dev/null | sed 's/^/      /' || true
fi

# How many API processes are alive? More than one means the two supervisors are fighting again.
# `pgrep -f` also matches the `sudo -u nexa ...` wrapper the launcher uses, so only the
# interpreter processes themselves are counted. Two of *those* would mean two supervisors.
API_PROCS="$(pgrep -af "${APP_DIR}/venv/bin/uvicorn app.main:app" 2>/dev/null | grep -v '^[0-9]* sudo ' || true)"
API_PROC_COUNT="$(printf '%s' "${API_PROCS}" | grep -c 'app.main:app' || true)"
if [[ "${API_PROC_COUNT}" -gt 1 ]]; then
  warn "${API_PROC_COUNT} API processes are running — only one can serve port 8000"
  printf '%s\n' "${API_PROCS}" | sed 's/^/      /'
fi
if [[ "${USE_SYSTEMD}" -eq 1 ]]; then
  printf '    supervisor: systemd (systemctl status nexa-api)\n'
  systemctl is-active nexa-api nexa-worker 2>/dev/null | paste -sd' ' - | sed 's/^/    units: /' || true
else
  printf '    supervisor: process launcher (deployment/linux/nexa-services.sh)\n'
  APP_DIR="${APP_DIR}" bash "${SERVICES}" status 2>/dev/null | sed 's/^/    /' || true
fi

# ---------------------------------------------------------------- self-test -----
log "verifying the deployment"
HOST_HEADER="${PUBLIC_HOST:-127.0.0.1:${PUBLIC_PORT}}"
BASE="http://127.0.0.1:${PUBLIC_PORT}"
PROBLEMS=()

http_code() { # $1 = path
  curl -s -o /dev/null -w '%{http_code}' --max-time 20 -H "Host: ${HOST_HEADER}" "${BASE}$1" || echo "000"
}

ready="$(http_code /readyz)"
if [[ "${ready}" == "200" ]]; then ok "readiness check passed (/readyz)"; else PROBLEMS+=("/readyz returned ${ready}"); fi

spa="$(curl -s --max-time 20 -H "Host: ${HOST_HEADER}" "${BASE}/" || true)"
if grep -qi '<!doctype html' <<<"${spa}" && grep -q 'id="root"' <<<"${spa}"; then
  ok "the built single-page app is served"
else
  PROBLEMS+=("the SPA is not served at / (is NEXA_FRONTEND_DIST_DIR correct?)")
fi
# The assets next to index.html must be reachable too, otherwise the browser shows a blank page.
ASSET="$(grep -oE '/assets/[A-Za-z0-9._-]+\.(js|css)' <<<"${spa}" | head -n 1 || true)"
if [[ -n "${ASSET}" ]]; then
  asset_code="$(http_code "${ASSET}")"
  if [[ "${asset_code}" == "200" ]]; then ok "the built assets are reachable (${ASSET})"; else PROBLEMS+=("${ASSET} returned ${asset_code}"); fi
else
  PROBLEMS+=("index.html does not reference a built asset — the SPA was not built (run without --no-node)")
fi

meta="$(curl -s --max-time 20 -H "Host: ${HOST_HEADER}" "${BASE}/api/v1/meta/config" || true)"
if grep -q '"app_name"' <<<"${meta}"; then ok "the API answers /api/v1/meta/config"; else PROBLEMS+=("/api/v1/meta/config did not answer"); fi
if [[ -n "${PUBLIC_URL}" ]] && ! grep -q "${PUBLIC_HOST}" <<<"${meta}"; then
  warn "meta/config does not advertise ${PUBLIC_HOST} as the public base URL — check NEXA_PUBLIC_BASE_URL"
fi

ADMIN_PASSWORD="$(python3 - "${ENV_FILE}" <<'PY'
import sys
for line in open(sys.argv[1], encoding="utf-8"):
    if line.startswith("NEXA_BOOTSTRAP_ADMIN_PASSWORD="):
        print(line.split("=", 1)[1].strip())
        break
PY
)"
ADMIN_LOGIN_EMAIL="$(python3 - "${ENV_FILE}" "${ADMIN_EMAIL}" <<'PY'
import sys
for line in open(sys.argv[1], encoding="utf-8"):
    if line.startswith("NEXA_BOOTSTRAP_ADMIN_EMAIL="):
        print(line.split("=", 1)[1].strip())
        break
else:
    print(sys.argv[2] or "admin@example.com")
PY
)"
LOGIN_CODE="$(curl -s -o /tmp/nexa-daytona-login.json -w '%{http_code}' --max-time 20 \
  -H "Host: ${HOST_HEADER}" -H 'Content-Type: application/json' \
  -d "{\"email\":\"${ADMIN_LOGIN_EMAIL}\",\"password\":\"${ADMIN_PASSWORD}\"}" \
  "${BASE}/api/v1/auth/login" || echo "000")"
if [[ "${LOGIN_CODE}" == "200" ]]; then
  ok "administrator sign-in verified (${ADMIN_LOGIN_EMAIL})"
else
  # Surface what the API actually said: a 422 is usually the address itself (reserved domain), and
  # "reset the password" would not help then.
  LOGIN_DETAIL="$(sed -n 's/.*"message"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' /tmp/nexa-daytona-login.json 2>/dev/null | head -1)"
  LOGIN_FIELD="$(sed -n 's/.*"fields"[[:space:]]*:[[:space:]]*{"\([^"]*\)".*/\1/p' /tmp/nexa-daytona-login.json 2>/dev/null | head -1)"
  if [[ -n "${LOGIN_DETAIL}" && "${LOGIN_CODE}" == "422" ]]; then
    PROBLEMS+=("administrator sign-in returned 422 for ${ADMIN_LOGIN_EMAIL} (${LOGIN_FIELD:-field} rejected: ${LOGIN_DETAIL}) — the sign-in endpoint refuses this address; recreate the administrator with a real mailbox: sudo bash ${APP_DIR}/deployment/linux/install.sh --admin-email you@your-domain.com")
  else
    PROBLEMS+=("administrator sign-in returned ${LOGIN_CODE}${LOGIN_DETAIL:+ (${LOGIN_DETAIL})} — recover with: cd ${APP_DIR} && sudo bash deployment/linux/install.sh --reset-admin-password")
  fi
fi

# ---------------------------------------------------------------- summary -------
if [[ ${#PROBLEMS[@]} -gt 0 ]]; then
  warn "diagnostics"
  if [[ -f "${APP_DIR}/logs/api.log" ]]; then
    printf '    last lines of %s:\n' "${APP_DIR}/logs/api.log"
    tail -n 12 "${APP_DIR}/logs/api.log" | sed 's/^/      /'
  fi
  printf '    trusted hosts in effect: %s\n' "$(grep -E '^NEXA_TRUSTED_HOSTS=' "${ENV_FILE}" | cut -d= -f2-)"
  printf '    a 400 "Invalid host header" from /readyz means the preview host is not trusted;\n'
  printf '    a 502 means the reverse proxy is up but the API is not listening.\n'
fi

echo
if [[ ${#PROBLEMS[@]} -eq 0 ]]; then
  ok "=============================================================="
  ok " Nexa AI is installed and verified inside this sandbox"
  ok "=============================================================="
else
  warn "the installation finished with ${#PROBLEMS[@]} problem(s):"
  for problem in "${PROBLEMS[@]}"; do printf '       - %s\n' "${problem}"; done
fi
# Build the "Open in a browser" block: the resolved link when there is one, otherwise the full
# diagnosis (candidate URLs, the status each answers, and which command to run on the operator's
# machine) — a bare placeholder is exactly what used to leave the operator without a link.
PREVIEW_BLOCK=""
if [[ -n "${PUBLIC_URL}" ]]; then
  PREVIEW_BLOCK="    ${PUBLIC_URL}"
  case "${PREVIEW_SOURCE}" in
    probed)  PREVIEW_BLOCK+=$'\n    (proven from inside the sandbox: /readyz answered on this address just now, so it needs no token)'
             PREVIEW_BLOCK+=$'\n    share it as is — this link does not expire' ;;
    cli)     PREVIEW_BLOCK+=$'\n    (a signed Daytona link: it works in any browser but expires — refresh it with the command below)' ;;
    given)   PREVIEW_BLOCK+=$'\n    (the address you passed with --public-url)' ;;
  esac
elif [[ -n "${PREVIEW_ASSUMED}" ]]; then
  PREVIEW_BLOCK="    ${PREVIEW_ASSUMED}   (candidate — nothing proved it yet: HTTP ${PREVIEW_ASSUMED_STATUS})"
  if [[ "$(nexa_preview_classify "${PREVIEW_ASSUMED_STATUS}")" == "private" ]]; then
    PREVIEW_BLOCK+=$'\n    the proxy answered, but this sandbox is private: nobody can open that link until you'
    PREVIEW_BLOCK+=$'\n    share a signed one (daytona preview-url) or make the sandbox public — both are printed below'
  else
    PREVIEW_BLOCK+=$'\n    no answer from inside the sandbox — check the sandbox name, then see the block below'
  fi
else
  # No link at all: print the diagnosis instead of leaving the operator to guess.
  PREVIEW_BLOCK="$(bash "${PREVIEW_HELPER}" --port "${PUBLIC_PORT}" \
      $([[ -n "${SANDBOX_ID}" ]] && printf -- '--sandbox-name %s' "${SANDBOX_ID}") 2>&1 | sed 's/^/    /; s/[[:space:]]*$//')" || true
  PREVIEW_BLOCK+=$'\n    (the sandbox IP itself is never reachable from outside — the preview link is the only way in)'
fi

cat <<SUMMARY

  Open in a browser
${PREVIEW_BLOCK}

  Sign in
    e-mail   : ${ADMIN_LOGIN_EMAIL}
    password : stored in ${ENV_FILE} (NEXA_BOOTSTRAP_ADMIN_PASSWORD)
    command  : sudo grep NEXA_BOOTSTRAP_ADMIN_PASSWORD ${ENV_FILE}

  Preview link — how to refresh it (the command runs on YOUR machine, not here)
    daytona list                                            # find the sandbox name
    daytona preview-url <sandbox-name> --port ${PUBLIC_PORT} --expires 86400
  or in the dashboard: Sandbox -> Ports -> ${PUBLIC_PORT} -> Preview.
  A signed link carries its own token and expires; the sandbox must be public (daytona create
  --public / sandbox.set_public(true)) if you want a link that needs no token at all.
  Any *.proxy.daytona.* host is accepted by this deployment, so a refreshed link keeps working.
  Diagnose any link from inside the sandbox:  bash ${PROJECT_DIR}/deployment/daytona/preview_link.sh --port ${PUBLIC_PORT}

  Prove it end to end without paid provider keys (mock upstream, 37 steps)
    see docs/REMOTE_TESTING.md section 6 "Proving the whole platform end to end"

  Useful on this machine
    supervisor: $(if [[ "${USE_SYSTEMD:-0}" -eq 1 ]]; then echo "systemd"; else echo "process launcher (no systemd here)"; fi)
    restart : $(if [[ "${USE_SYSTEMD:-0}" -eq 1 ]]; then echo "sudo systemctl restart nexa-api nexa-worker"; else echo "cd ${APP_DIR} && sudo bash deployment/linux/nexa-services.sh restart"; fi)
    status  : $(if [[ "${USE_SYSTEMD:-0}" -eq 1 ]]; then echo "systemctl status nexa-api"; else echo "cd ${APP_DIR} && sudo bash deployment/linux/nexa-services.sh status"; fi)
    logs    : $(if [[ "${USE_SYSTEMD:-0}" -eq 1 ]]; then echo "sudo journalctl -u nexa-api -f"; else echo "tail -f ${APP_DIR}/logs/api.log"; fi)
    cd ${APP_DIR}/backend && sudo -u nexa venv/bin/python -m app.cli doctor
    tail -f ${APP_DIR}/logs/api.log
    ${NGINX_OK:+nginx -t   # reverse proxy in front of the app on port ${PUBLIC_PORT}}

  Security
    This deployment now accepts HTTPS preview hosts and uses secure cookies. Keep the link
    private: whoever has it can reach the sign-in page. Framing protection stays ON
$(if [[ "${ALLOW_EMBEDDING}" -eq 1 ]]; then echo "    (disabled for the preview host because --allow-embedding was used)."; else echo "    (X-Frame-Options: DENY — re-run with --allow-embedding only if the dashboard embeds the page)."; fi)

SUMMARY

[[ ${#PROBLEMS[@]} -eq 0 ]] || exit 1
