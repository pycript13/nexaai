"""Public metadata: branding, languages, pricing plans, deployment warnings."""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter
from sqlalchemy import select

from app.api.deps import CurrentUser, DbDep, OptionalUser
from app.core.config import settings
from app.core.errors import NotFound
from app.models.billing import SubscriptionPlan
from app.providers.capabilities import ALL_OPERATIONS, MODULES, OPERATION_LABELS
from app.providers.registry import describe_adapters
from app.services import access as access_service
from app.services import payments as payments_service
from app.services.settings_store import public_settings

router = APIRouter(prefix="/meta", tags=["meta"])

LANGUAGES = [
    {"code": "fa", "name": "فارسی", "english": "Persian", "dir": "rtl", "default": True},
    {"code": "en", "name": "English", "english": "English", "dir": "ltr", "default": False},
    {"code": "ar", "name": "العربية", "english": "Arabic", "dir": "rtl", "default": False},
    {"code": "ckb", "name": "کوردیی ناوەندی", "english": "Kurdish Sorani", "dir": "rtl", "default": False},
]


@router.get("/config")
def public_config(db: DbDep, user: OptionalUser) -> dict[str, Any]:
    store = public_settings(db)
    return {
        "app_name": store.get("site.name", settings.app_name),
        "tagline": store.get("site.tagline", ""),
        "version": settings.version,
        "environment": settings.environment,
        "deployment_mode": settings.deployment_mode,
        "public_base_url": settings.public_base_url,
        "public_ip": settings.public_ip or None,
        "public_port": settings.public_port,
        "security_warning": settings.plain_http_warning,
        "testing_notice": store.get("site.testing_notice", ""),
        "languages": LANGUAGES,
        "default_language": "fa",
        "themes": ["light", "dark", "system"],
        "enhanced_theme_available": True,
        "registration_mode": store.get("registration.mode", settings.registration_mode),
        "features": {
            "email_delivery": settings.email_enabled and bool(settings.smtp_host),
            "manual_payments": settings.manual_payments_enabled,
            "crypto_payments": settings.crypto_payments_enabled,
            "streaming": True,
        },
        "payment_methods": payments_service.available_methods().to_dict(),
        "credit_display_name": store.get("billing.credit_display_name", settings.credit_display_name),
        "credit_usd_rate": float(store.get("billing.credit_usd_rate", settings.credit_usd_rate)),
        "max_upload_mb": int(store.get("files.max_upload_mb", settings.max_upload_mb)),
        "user_storage_quota_mb": int(store.get("files.user_quota_mb", settings.user_storage_quota_mb)),
        "supported_upload_types": sorted(settings.allowed_extension_set),
        "modules": [{"key": key, **value} for key, value in MODULES.items()],
        "operations": list(ALL_OPERATIONS),
        "operation_labels": OPERATION_LABELS,
        "support_email": store.get("site.support_email", ""),
        "privacy_version": store.get("registration.privacy_version", "2026-01"),
        "terms_version": store.get("registration.require_terms_version", "2026-01"),
        "authenticated": user is not None,
    }


@router.get("/provider-presets")
def provider_presets(user: CurrentUser) -> dict[str, Any]:
    """Adapter catalog + base-URL presets for the admin provider form."""
    access_service.require_permission(user, "providers.read")
    return {"adapters": describe_adapters()}


@router.get("/pricing-plans")
def pricing_plans(db: DbDep) -> dict[str, Any]:
    plans = db.scalars(
        select(SubscriptionPlan).where(SubscriptionPlan.is_public.is_(True), SubscriptionPlan.is_active.is_(True))
        .order_by(SubscriptionPlan.sort_order)
    ).all()
    return {
        "items": [
            {
                "id": plan.id,
                "slug": plan.slug,
                "name": plan.name,
                "name_fa": plan.name_fa,
                "description": plan.description,
                "price_micro_monthly": plan.price_micro_monthly,
                "included_credit_micro": plan.included_credit_micro,
                "daily_request_limit": plan.daily_request_limit,
                "monthly_token_limit": plan.monthly_token_limit,
                "features": plan.features or {},
            }
            for plan in plans
        ],
        "credit_usd_rate": settings.credit_usd_rate,
        "currency": settings.default_currency,
    }


@router.get("/policy/{kind}")
def policy(kind: str, db: DbDep) -> dict[str, Any]:
    if kind not in ("terms", "privacy"):
        raise NotFound("Unknown policy document.")
    from app.services.settings_store import get_value

    store_key = "registration.require_terms_version" if kind == "terms" else "registration.privacy_version"
    version = get_value(db, store_key, "2026-01")
    return {
        "kind": kind,
        "version": version,
        "title": f"{'Terms of Service' if kind == 'terms' else 'Privacy Policy'} (v{version})",
        "body": POLICY_TEXTS[kind],
        "editable_note": "Replace this text with your organisation's reviewed policy before a commercial launch.",
    }


POLICY_TEXTS: dict[str, str] = {
    "terms": (
        "1. Scope\nThese terms govern the use of the Nexa AI platform.\n\n"
        "2. Accounts\nYou are responsible for keeping your credentials confidential and for all activity performed "
        "with your account.\n\n"
        "3. Acceptable use\nYou must not use the platform for unlawful content, to attack the provider APIs, to "
        "circumvent usage limits, or to process data you are not authorised to process.\n\n"
        "4. AI output\nOutputs are generated by third-party models. They may be inaccurate. You are responsible for "
        "reviewing outputs before using them.\n\n"
        "5. Credits and billing\nPaid usage is deducted from your credit balance according to the published pricing. "
        "Purchased credit is non-transferable. Refunds are handled by the operator according to the applicable "
        "consumer protection rules.\n\n"
        "6. Availability\nThis deployment may be an evaluation build. The operator may suspend accounts to protect "
        "the platform and may reset test data with reasonable notice.\n"
    ),
    "privacy": (
        "1. Data we process\nAccount data (email, display name, settings), usage metadata (model, tokens, cost), "
        "conversations you create, and files you upload.\n\n"
        "2. Why\nThe data is processed to operate your account, to bill usage, to protect the platform from abuse, "
        "and to provide the AI features you request.\n\n"
        "3. Third parties\nPrompts and attachments are transmitted to the AI provider you select in order to produce "
        "the requested output. Review each provider's own data-retention policy before sending sensitive content.\n\n"
        "4. Retention\nConversations, files and financial ledgers are retained according to the operator's retention "
        "policy. Financial ledger entries are immutable and retained for accounting integrity.\n\n"
        "5. Your rights\nYou can export or delete conversations and files from the workspace. Account deletion "
        "requests are handled by the operator; financial records are retained where legally required.\n\n"
        "6. Security\nPasswords are stored with Argon2id. Sessions are server-side revocable. Provider credentials "
        "are encrypted at rest with a key held outside the database.\n"
    ),
}
