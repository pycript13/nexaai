"""Administrative user & access management (spec §6, §15)."""
from __future__ import annotations

import datetime as dt
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import func, or_, select

from app.api.deps import Client, DbDep, PageDep, User, paginated, require_permission
from app.core.config import settings
from app.core.crypto import hash_password, password_policy_errors, random_token
from app.core.errors import Conflict, NotFound, ValidationError
from app.core.logging import get_logger
from app.models.billing import CreditAccount, Payment, Subscription
from app.models.enums import PERMISSION_GROUPS, ROLE_DEFINITIONS
from app.models.user import Permission, Role, User as UserModel, UserSession
from app.services import access as access_service
from app.services import audit as audit_service
from app.services import ledger as ledger_service
from app.services import payments as payments_service
from app.services import pricing as pricing_service
from app.services.settings_store import get_value
from app.schemas.common import StrictModel

log = get_logger(__name__)
router = APIRouter(prefix="/admin/users", tags=["admin:users"])


class UserCreateRequest(StrictModel):
    email: EmailStr
    display_name: str = Field(min_length=1, max_length=120)
    password: str | None = None
    roles: list[str] = Field(default_factory=lambda: ["user"])
    status: str = "active"
    is_test_account: bool = False
    expires_in_days: int | None = None
    quota_requests_per_day: int | None = None
    quota_spend_micro_per_day: int | None = None
    initial_credit_micro: int = 0
    notes: str | None = None


class UserUpdateRequest(StrictModel):
    display_name: str | None = None
    status: str | None = None
    locale: str | None = None
    theme: str | None = None
    is_test_account: bool | None = None
    expires_in_days: int | None = None
    clear_expiry: bool = False
    quota_requests_per_day: int | None = None
    quota_spend_micro_per_day: int | None = None
    daily_spend_limit_micro: int | None = None
    monthly_spend_limit_micro: int | None = None
    notes: str | None = None
    account_frozen: bool | None = None


class RolesUpdateRequest(StrictModel):
    roles: list[str]


class CreditAdjustRequest(StrictModel):
    amount_micro: int
    reason: str = Field(min_length=3, max_length=300)
    entry_type: str = "adjustment"


class SuspendRequest(StrictModel):
    reason: str = Field(min_length=3, max_length=300)


def _user_admin_payload(db, user: UserModel) -> dict[str, Any]:  # noqa: ANN001
    account = db.scalars(select(CreditAccount).where(CreditAccount.user_id == user.id)).first()
    return {
        "id": user.id,
        "email": user.email,
        "display_name": user.display_name,
        "status": user.status,
        "email_verified": user.email_verified,
        "locale": user.locale,
        "theme": user.theme,
        "roles": [{"slug": r.slug, "name": r.name} for r in user.roles],
        "permissions": sorted(access_service.user_permissions(user)),
        "is_test_account": user.is_test_account,
        "expires_at": user.expires_at,
        "quota_requests_per_day": user.quota_requests_per_day,
        "quota_spend_micro_per_day": user.quota_spend_micro_per_day,
        "balance_micro": account.balance_micro if account else 0,
        "lifetime_spent_micro": account.lifetime_spent_micro if account else 0,
        "daily_spend_limit_micro": account.daily_spend_limit_micro if account else None,
        "monthly_spend_limit_micro": account.monthly_spend_limit_micro if account else None,
        "account_frozen": account.is_frozen if account else False,
        "storage_used_bytes": user.storage_used_bytes,
        "last_login_at": user.last_login_at,
        "created_at": user.created_at,
        "notes": user.notes,
    }


@router.get("")
def list_users(
    db: DbDep,
    page: PageDep,
    actor: Annotated[UserModel, Depends(require_permission("users.read"))],
    search: str | None = None,
    status: str | None = None,
    role: str | None = None,
    is_test_account: bool | None = None,
    sort: str = Query("created_at", pattern="^(created_at|last_login_at|email|display_name|status)$"),
    direction: str = Query("desc", pattern="^(asc|desc)$"),
) -> dict[str, Any]:
    stmt = select(UserModel)
    if search:
        term = f"%{search.lower()}%"
        stmt = stmt.where(or_(func.lower(UserModel.email).like(term), func.lower(UserModel.display_name).like(term)))
    if status:
        stmt = stmt.where(UserModel.status == status)
    if is_test_account is not None:
        stmt = stmt.where(UserModel.is_test_account.is_(is_test_account))
    if role:
        stmt = stmt.join(UserModel.roles).where(Role.slug == role)
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    column = getattr(UserModel, sort)
    stmt = stmt.order_by(column.desc() if direction == "desc" else column.asc()).offset(page.offset).limit(page.limit)
    users = db.scalars(stmt).unique().all()
    return paginated([_user_admin_payload(db, u) for u in users], int(total), page)


@router.post("", status_code=201)
def create_user(
    payload: UserCreateRequest,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("users.create"))],
    client: Client,
) -> dict[str, Any]:
    email = payload.email.lower().strip()
    if db.scalars(select(UserModel).where(UserModel.email == email)).first() is not None:
        raise Conflict("A user with this email already exists.")
    generated_password: str | None = None
    password = payload.password
    if not password:
        generated_password = f"Nx-{random_token(12)}"
        password = generated_password
    errors = password_policy_errors(password, email=email, name=payload.display_name)
    if errors:
        raise ValidationError(" ".join(errors), details={"fields": {"password": errors}})
    roles = db.scalars(select(Role).where(Role.slug.in_(payload.roles))).all()
    unknown = set(payload.roles) - {r.slug for r in roles}
    if unknown:
        raise ValidationError(f"Unknown role(s): {', '.join(sorted(unknown))}.")
    if payload.status not in ("active", "pending", "suspended", "deactivated"):
        raise ValidationError("Invalid status for a new user.")
    user = UserModel(
        email=email,
        display_name=payload.display_name.strip(),
        password_hash=hash_password(password),
        status=payload.status,
        email_verified=True,
        email_verified_at=dt.datetime.now(dt.timezone.utc),
        is_test_account=payload.is_test_account,
        expires_at=dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=payload.expires_in_days) if payload.expires_in_days else None,
        quota_requests_per_day=payload.quota_requests_per_day,
        quota_spend_micro_per_day=payload.quota_spend_micro_per_day,
        notes=payload.notes,
        must_change_password=bool(generated_password),
        password_changed_at=dt.datetime.now(dt.timezone.utc),
    )
    db.add(user)
    db.flush()
    user.roles.extend(roles)
    ledger_service.get_account(db, user.id)
    if payload.initial_credit_micro:
        ledger_service.credit(
            db, user_id=user.id, amount_micro=payload.initial_credit_micro, entry_type="admin_grant",
            idempotency_key=f"admin-create-grant:{user.id}", description="Initial credit granted by administrator",
            created_by_id=actor.id, reference_type="admin_grant",
        )
    audit_service.record_audit(
        db, action="user.created", summary=f"User {email} created by {actor.email}.", actor=actor, entity_type="user",
        entity_id=user.id, after={"roles": payload.roles, "status": payload.status, "is_test_account": payload.is_test_account},
        ip_address=client.ip,
    )
    db.commit()
    return {
        "user": _user_admin_payload(db, user),
        "generated_password": generated_password,
        "note": "Share the generated password over a secure channel; the user must change it after first sign-in."
        if generated_password
        else None,
    }


@router.get("/{user_id}")
def get_user(user_id: int, db: DbDep, actor: Annotated[UserModel, Depends(require_permission("users.read"))]) -> dict[str, Any]:
    user = db.get(UserModel, user_id)
    if user is None:
        raise NotFound("User not found.")
    sessions = db.scalars(select(UserSession).where(UserSession.user_id == user.id).order_by(UserSession.created_at.desc()).limit(20)).all()
    payments = db.scalars(select(Payment).where(Payment.user_id == user.id).order_by(Payment.created_at.desc()).limit(20)).all()
    subscriptions = db.scalars(select(Subscription).where(Subscription.user_id == user.id)).all()
    return {
        "user": _user_admin_payload(db, user),
        "sessions": [
            {"id": s.id, "ip_address": s.ip_address, "user_agent": s.user_agent, "created_at": s.created_at,
             "last_seen_at": s.last_seen_at, "active": s.is_valid()}
            for s in sessions
        ],
        "payments": [
            {"id": p.id, "reference": p.reference, "status": p.status, "method": p.method, "amount_micro": p.amount_micro,
             "created_at": p.created_at}
            for p in payments
        ],
        "subscriptions": [
            {"id": s.id, "plan": s.plan.name if s.plan else None, "status": s.status,
             "current_period_end": s.current_period_end}
            for s in subscriptions
        ],
    }


@router.patch("/{user_id}")
def update_user(
    user_id: int,
    payload: UserUpdateRequest,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("users.update"))],
    client: Client,
) -> dict[str, Any]:
    user = db.get(UserModel, user_id)
    if user is None:
        raise NotFound("User not found.")
    if user.id == actor.id and payload.status and payload.status != "active":
        raise ValidationError("You cannot change your own account status.")
    before = _user_admin_payload(db, user)
    if payload.display_name is not None:
        user.display_name = payload.display_name.strip()[:120]
    if payload.status is not None:
        if payload.status not in ("active", "pending", "suspended", "deactivated"):
            raise ValidationError("Invalid status.")
        if payload.status == "suspended":
            access_service.require_permission(actor, "users.suspend")
        user.status = payload.status
        if payload.status in ("suspended", "deactivated"):
            _revoke_sessions(db, user, reason="account_status_changed")
    if payload.locale in {"fa", "en", "ar", "ckb"}:
        user.locale = payload.locale
    if payload.theme in {"light", "dark", "system"}:
        user.theme = payload.theme
    if payload.is_test_account is not None:
        user.is_test_account = payload.is_test_account
    if payload.expires_in_days:
        user.expires_at = dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=payload.expires_in_days)
    if payload.clear_expiry:
        user.expires_at = None
    if payload.quota_requests_per_day is not None:
        user.quota_requests_per_day = payload.quota_requests_per_day or None
    if payload.quota_spend_micro_per_day is not None:
        user.quota_spend_micro_per_day = payload.quota_spend_micro_per_day or None
    if payload.notes is not None:
        user.notes = payload.notes
    account = ledger_service.get_account(db, user.id)
    if account is not None:
        if payload.daily_spend_limit_micro is not None:
            account.daily_spend_limit_micro = payload.daily_spend_limit_micro or None
        if payload.monthly_spend_limit_micro is not None:
            account.monthly_spend_limit_micro = payload.monthly_spend_limit_micro or None
        if payload.account_frozen is not None:
            access_service.require_permission(actor, "credits.manage")
            account.is_frozen = payload.account_frozen
    after = _user_admin_payload(db, user)
    audit_service.record_audit(
        db, action="user.updated", summary=f"User {user.email} updated by {actor.email}.", actor=actor,
        entity_type="user", entity_id=user.id, before=before, after=after, ip_address=client.ip,
    )
    db.commit()
    return {"user": after}


def _revoke_sessions(db, user: UserModel, *, reason: str) -> int:  # noqa: ANN001
    count = 0
    for session in db.scalars(select(UserSession).where(UserSession.user_id == user.id, UserSession.revoked_at.is_(None))).all():
        session.revoked_at = dt.datetime.now(dt.timezone.utc)
        session.revoked_reason = reason
        count += 1
    return count


@router.post("/{user_id}/suspend")
def suspend_user(
    user_id: int,
    payload: SuspendRequest,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("users.suspend"))],
    client: Client,
) -> dict[str, Any]:
    user = db.get(UserModel, user_id)
    if user is None:
        raise NotFound("User not found.")
    if user.id == actor.id:
        raise ValidationError("You cannot suspend your own account.")
    if access_service.is_super_admin(user) and not access_service.is_super_admin(actor):
        raise ValidationError("Only a Super Admin can suspend another Super Admin.")
    user.status = "suspended"
    revoked = _revoke_sessions(db, user, reason="suspended")
    audit_service.record_audit(
        db, action="user.suspended", summary=f"User {user.email} suspended: {payload.reason[:200]}", actor=actor,
        entity_type="user", entity_id=user.id, after={"reason": payload.reason, "sessions_revoked": revoked},
        severity="warning", ip_address=client.ip,
    )
    db.commit()
    return {"user_id": user.id, "status": user.status, "sessions_revoked": revoked}


@router.post("/{user_id}/reactivate")
def reactivate_user(
    user_id: int,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("users.suspend"))],
) -> dict[str, Any]:
    user = db.get(UserModel, user_id)
    if user is None:
        raise NotFound("User not found.")
    user.status = "active"
    audit_service.record_audit(db, action="user.reactivated", summary=f"User {user.email} reactivated.", actor=actor,
                               entity_type="user", entity_id=user.id)
    db.commit()
    return {"user_id": user.id, "status": user.status}


@router.put("/{user_id}/roles")
def set_roles(
    user_id: int,
    payload: RolesUpdateRequest,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("roles.manage"))],
    client: Client,
) -> dict[str, Any]:
    user = db.get(UserModel, user_id)
    if user is None:
        raise NotFound("User not found.")
    roles = db.scalars(select(Role).where(Role.slug.in_(payload.roles))).all()
    unknown = set(payload.roles) - {r.slug for r in roles}
    if unknown:
        raise ValidationError(f"Unknown role(s): {', '.join(sorted(unknown))}.")
    if "super_admin" in payload.roles and not access_service.is_super_admin(actor):
        raise ValidationError("Only a Super Admin can grant the Super Admin role.")
    before = sorted(r.slug for r in user.roles)
    if user.id == actor.id and "super_admin" in before and "super_admin" not in payload.roles:
        raise ValidationError("You cannot remove your own Super Admin role.")
    user.roles = list(roles)
    db.flush()
    audit_service.record_audit(
        db, action="user.roles_changed", summary=f"Roles for {user.email}: {before} → {payload.roles}", actor=actor,
        entity_type="user", entity_id=user.id, before={"roles": before}, after={"roles": payload.roles},
        severity="warning", ip_address=client.ip,
    )
    db.commit()
    return {"user_id": user.id, "roles": payload.roles}


@router.post("/{user_id}/credits")
def adjust_credits(
    user_id: int,
    payload: CreditAdjustRequest,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("credits.manage"))],
    client: Client,
) -> dict[str, Any]:
    user = db.get(UserModel, user_id)
    if user is None:
        raise NotFound("User not found.")
    if payload.entry_type not in ("adjustment", "admin_grant", "promotional", "refund", "expiry"):
        raise ValidationError("Unsupported ledger entry type for manual adjustment.")
    if payload.amount_micro == 0:
        raise ValidationError("Amount must not be zero.")
    import uuid

    key = f"admin-adjust:{user.id}:{payload.entry_type}:{uuid.uuid4().hex}"
    if payload.amount_micro > 0:
        result = ledger_service.credit(
            db, user_id=user.id, amount_micro=payload.amount_micro, entry_type=payload.entry_type,
            idempotency_key=key, description=f"{payload.reason} (by {actor.email})", created_by_id=actor.id,
            reference_type="admin_grant",
        )
    else:
        result = ledger_service.adjust(
            db, user_id=user.id, amount_micro=payload.amount_micro, reason=f"{payload.reason} (by {actor.email})",
            admin_id=actor.id, idempotency_key=key, entry_type=payload.entry_type,
        )
    audit_service.record_audit(
        db, action="user.credits_adjusted",
        summary=f"{actor.email} adjusted {user.email} by {pricing_service.micro_to_display(payload.amount_micro)} credits: {payload.reason}",
        actor=actor, entity_type="user", entity_id=user.id,
        after={"amount_micro": payload.amount_micro, "entry_type": payload.entry_type,
               "balance_after_micro": result.balance_after_micro},
        severity="warning", ip_address=client.ip,
    )
    db.commit()
    return {
        "user_id": user.id,
        "balance_after_micro": result.balance_after_micro,
        "entry_id": result.entry.id if result.entry else None,
        "created": result.created,
    }


@router.post("/{user_id}/reset-password")
def admin_reset_password(
    user_id: int,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("users.update"))],
) -> dict[str, Any]:
    user = db.get(UserModel, user_id)
    if user is None:
        raise NotFound("User not found.")
    password = f"Nx-{random_token(12)}"
    user.password_hash = hash_password(password)
    user.password_changed_at = dt.datetime.now(dt.timezone.utc)
    user.must_change_password = True
    revoked = _revoke_sessions(db, user, reason="admin_password_reset")
    audit_service.record_audit(
        db, action="auth.password_reset_completed", summary=f"Administrator reset the password for {user.email}.",
        actor=actor, entity_type="user", entity_id=user.id, severity="warning",
        after={"sessions_revoked": revoked},
    )
    db.commit()
    return {
        "user_id": user.id,
        "temporary_password": password,
        "sessions_revoked": revoked,
        "note": "The user must set a new password after signing in.",
    }


@router.delete("/{user_id}")
def delete_user(
    user_id: int,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("users.update"))],
    hard: bool = False,
    confirm_email: str | None = None,
) -> dict[str, Any]:
    user = db.get(UserModel, user_id)
    if user is None:
        raise NotFound("User not found.")
    if user.id == actor.id:
        raise ValidationError("You cannot delete your own account from the admin console.")
    if access_service.is_super_admin(user) and not access_service.is_super_admin(actor):
        raise ValidationError("Only a Super Admin can delete another Super Admin.")
    if confirm_email and confirm_email.lower().strip() != user.email.lower():
        raise ValidationError("Confirmation email does not match the account being deleted.")
    if hard:
        from app.models.billing import LedgerEntry, UsageRecord
        from app.models.chat import Conversation

        if db.scalars(select(UsageRecord).where(UsageRecord.user_id == user.id).limit(1)).first() is not None:
            raise ValidationError(
                "This account has usage history; a hard delete would break financial records. "
                "Deactivate the account instead (recommended)."
            )
        ledger_entries = db.scalars(select(LedgerEntry).where(LedgerEntry.user_id == user.id).limit(1)).first()
        if ledger_entries is not None:
            raise ValidationError("This account has ledger history and cannot be hard-deleted.")
        for conversation in db.scalars(select(Conversation).where(Conversation.user_id == user.id)).all():
            db.delete(conversation)
        audit_service.record_audit(
            db, action="user.deleted", summary=f"User {user.email} hard-deleted by {actor.email}.", actor=actor,
            entity_type="user", entity_id=user.id, severity="critical",
        )
        db.delete(user)
        db.commit()
        return {"deleted": True, "mode": "hard"}
    user.status = "deactivated"
    user.deleted_at = dt.datetime.now(dt.timezone.utc)
    user.email = f"deleted+{user.id}@{user.email.split('@')[-1]}" if "@" in user.email else f"deleted+{user.id}"
    revoked = _revoke_sessions(db, user, reason="account_deactivated")
    audit_service.record_audit(
        db, action="user.deleted", summary=f"User deactivated (soft delete) by {actor.email}.", actor=actor,
        entity_type="user", entity_id=user.id, severity="critical", after={"sessions_revoked": revoked},
    )
    db.commit()
    return {"deleted": True, "mode": "soft", "sessions_revoked": revoked}


@router.post("/{user_id}/sessions/revoke")
def revoke_user_sessions(
    user_id: int,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("users.update"))],
) -> dict[str, Any]:
    user = db.get(UserModel, user_id)
    if user is None:
        raise NotFound("User not found.")
    revoked = _revoke_sessions(db, user, reason="admin_revoked")
    audit_service.record_audit(db, action="auth.session_revoked", summary=f"{revoked} session(s) revoked for {user.email}.",
                               actor=actor, entity_type="user", entity_id=user.id)
    db.commit()
    return {"sessions_revoked": revoked}


@router.get("/{user_id}/ledger")
def user_ledger(
    user_id: int,
    db: DbDep,
    page: PageDep,
    actor: Annotated[UserModel, Depends(require_permission("usage.read"))],
) -> dict[str, Any]:
    from app.models.billing import LedgerEntry

    user = db.get(UserModel, user_id)
    if user is None:
        raise NotFound("User not found.")
    total = db.scalar(select(func.count(LedgerEntry.id)).where(LedgerEntry.user_id == user.id)) or 0
    rows = db.scalars(
        select(LedgerEntry).where(LedgerEntry.user_id == user.id)
        .order_by(LedgerEntry.created_at.desc()).offset(page.offset).limit(page.limit)
    ).all()
    return paginated(
        [
            {
                "id": r.id, "type": r.entry_type, "amount_micro": r.amount_micro, "balance_after_micro": r.balance_after_micro,
                "description": r.description, "reference_type": r.reference_type, "reference_id": r.reference_id,
                "created_at": r.created_at,
            }
            for r in rows
        ],
        int(total),
        page,
    )


# ------------------------------------------------------------------- roles ----
roles_router = APIRouter(prefix="/admin/roles", tags=["admin:roles"])


@roles_router.get("")
def list_roles(db: DbDep, actor: Annotated[UserModel, Depends(require_permission("users.read"))]) -> dict[str, Any]:
    roles = db.scalars(select(Role).order_by(Role.slug)).all()
    counts = dict(db.execute(select(Role.slug, func.count(UserModel.id)).join(UserModel.roles).group_by(Role.slug)).all())
    return {
        "items": [
            {
                "id": role.id,
                "slug": role.slug,
                "name": role.name,
                "description": role.description,
                "is_system": role.is_system,
                "permissions": sorted(p.slug for p in role.permissions),
                "user_count": int(counts.get(role.slug, 0)),
            }
            for role in roles
        ],
        "permission_groups": PERMISSION_GROUPS,
        "role_definitions": ROLE_DEFINITIONS,
    }


roles_router_alt = roles_router


@roles_router.post("")
def create_role(
    payload: dict,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("roles.manage"))],
) -> dict[str, Any]:
    slug = str(payload.get("slug") or "").strip().lower()
    name = str(payload.get("name") or "").strip()
    if not slug or not name:
        raise ValidationError("Both 'slug' and 'name' are required.")
    if db.scalars(select(Role).where(Role.slug == slug)).first() is not None:
        raise Conflict("A role with this slug already exists.")
    role = Role(slug=slug, name=name, description=str(payload.get("description") or ""), is_system=False)
    db.add(role)
    db.flush()
    slug_list = [p for p in (payload.get("permissions") or []) if p in {perm.slug for perm in db.scalars(select(Permission)).all()}]
    role.permissions = list(db.scalars(select(Permission).where(Permission.slug.in_(slug_list))).all())
    audit_service.record_audit(db, action="roles.manage", summary=f"Role '{slug}' created.", actor=actor,
                               entity_type="role", entity_id=role.id, after={"permissions": slug_list},
                               category="users", severity="warning")
    db.commit()
    return {"id": role.id, "slug": role.slug, "permissions": slug_list}


@roles_router.put("/{role_id}/permissions")
def set_role_permissions(
    role_id: int,
    payload: dict,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("roles.manage"))],
) -> dict[str, Any]:
    role = db.get(Role, role_id)
    if role is None:
        raise NotFound("Role not found.")
    if role.slug == "super_admin":
        raise ValidationError(
            "The Super Admin role always holds every permission and cannot be narrowed. Create a custom role instead."
        )
    wanted = [p for p in (payload.get("permissions") or [])]
    perms = db.scalars(select(Permission).where(Permission.slug.in_(wanted))).all()
    unknown = set(wanted) - {p.slug for p in perms}
    if unknown:
        raise ValidationError(f"Unknown permission(s): {', '.join(sorted(unknown))}.")
    before = sorted(p.slug for p in role.permissions)
    role.permissions = list(perms)
    audit_service.record_audit(db, action="roles.manage", summary=f"Permissions for role '{role.slug}' updated.",
                               actor=actor, entity_type="role", entity_id=role.id, before={"permissions": before},
                               after={"permissions": sorted(p.slug for p in perms)}, category="users", severity="warning")
    db.commit()
    return {"role": role.slug, "permissions": sorted(p.slug for p in perms)}


@roles_router.get("/permissions")
def list_permissions(db: DbDep, actor: Annotated[UserModel, Depends(require_permission("users.read"))]) -> dict[str, Any]:
    return {"groups": PERMISSION_GROUPS}
