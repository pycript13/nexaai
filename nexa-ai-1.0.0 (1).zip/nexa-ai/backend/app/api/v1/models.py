"""Model catalog: user discovery + administrative model management (spec §8, §9)."""
from __future__ import annotations

import datetime as dt
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.api.deps import Client, CurrentUser, DbDep, OptionalUser, PageDep, User, paginated, require_permission
from app.core.errors import NotFound, ValidationError
from app.core.logging import get_logger
from app.models.provider import (
    AccessTier,
    Model,
    ModelVariant,
    ModelAvailability,
    ModelCategory,
    ModelGrant,
    ModelTag,
    ModelVisibility,
    Provider,
)
from app.models.user import Role, User as UserModel
from app.providers.capabilities import ALL_OPERATIONS, OPERATION_LABELS
from app.services import access as access_service
from app.services import ai as ai_service
from app.services import audit as audit_service
from app.services import pricing as pricing_service
from app.services import variants as variant_service
from app.schemas.common import StrictModel

log = get_logger(__name__)
router = APIRouter(prefix="/models", tags=["models"])
admin_router = APIRouter(prefix="/admin/models", tags=["admin:models"])
admin_variants_router = APIRouter(prefix="/admin/model-variants", tags=["admin:model-variants"])


class ModelCreate(StrictModel):
    provider_id: int
    provider_model_id: str = Field(min_length=1, max_length=200)
    display_name: str = Field(min_length=1, max_length=200)
    description: str = ""
    model_family: str | None = None
    capabilities: list[str] = Field(default_factory=list)
    input_modalities: list[str] = Field(default_factory=lambda: ["text"])
    output_modalities: list[str] = Field(default_factory=lambda: ["text"])
    context_window: int | None = None
    max_output_tokens: int | None = None
    supports_streaming: bool = True
    supports_tools: bool = False
    supports_vision: bool = False
    supports_embeddings: bool = False
    supports_json_mode: bool = False
    supports_reasoning: bool = False
    supports_audio_input: bool = False
    supports_audio_output: bool = False
    supports_video: bool = False
    provider_cost_input_per_mtok: float | None = None
    provider_cost_output_per_mtok: float | None = None
    provider_cost_per_request: float | None = None
    provider_cost_per_image: float | None = None
    provider_cost_per_audio_minute: float | None = None
    pricing_uncertain: bool = True
    selling_input_per_mtok: float | None = None
    selling_output_per_mtok: float | None = None
    selling_per_request: float | None = None
    selling_per_image: float | None = None
    selling_per_audio_minute: float | None = None
    visibility: str = ModelVisibility.HIDDEN
    availability: str = ModelAvailability.UNTESTED
    access_tier: str = AccessTier.CREDIT
    enabled: bool = True
    published: bool = False
    is_default: bool = False
    subscription_plan_id: int | None = None
    category_ids: list[int] = Field(default_factory=list)
    tag_slugs: list[str] = Field(default_factory=list)
    sort_order: int = 100


class ModelUpdate(StrictModel):
    display_name: str | None = None
    description: str | None = None
    model_family: str | None = None
    capabilities: list[str] | None = None
    input_modalities: list[str] | None = None
    output_modalities: list[str] | None = None
    context_window: int | None = None
    max_output_tokens: int | None = None
    supports_streaming: bool | None = None
    supports_tools: bool | None = None
    supports_vision: bool | None = None
    supports_embeddings: bool | None = None
    supports_json_mode: bool | None = None
    supports_reasoning: bool | None = None
    supports_audio_input: bool | None = None
    supports_audio_output: bool | None = None
    supports_video: bool | None = None
    provider_cost_input_per_mtok: float | None = None
    provider_cost_output_per_mtok: float | None = None
    provider_cost_per_request: float | None = None
    provider_cost_per_image: float | None = None
    provider_cost_per_audio_minute: float | None = None
    pricing_uncertain: bool | None = None
    selling_input_per_mtok: float | None = None
    selling_output_per_mtok: float | None = None
    selling_per_request: float | None = None
    selling_per_image: float | None = None
    selling_per_audio_minute: float | None = None
    visibility: str | None = None
    availability: str | None = None
    access_tier: str | None = None
    enabled: bool | None = None
    published: bool | None = None
    is_default: bool | None = None
    subscription_plan_id: int | None = None
    category_ids: list[int] | None = None
    tag_slugs: list[str] | None = None
    sort_order: int | None = None
    deprecation_note: str | None = None


class BulkUpdate(StrictModel):
    model_ids: list[int]
    action: str = Field(description="publish | unpublish | enable | disable | set_tier | set_visibility | add_categories")
    access_tier: str | None = None
    visibility: str | None = None
    category_ids: list[int] | None = None
    confirm: bool = False


class ModelTestRequest(StrictModel):
    operation: str = "chat"
    input: str | None = None
    prompt: str | None = None
    messages: list[dict[str, Any]] | None = None
    system: str | None = None
    temperature: float | None = None
    max_tokens: int | None = None
    top_p: float | None = None
    json_mode: bool = False
    n: int | None = None
    size: str | None = None
    quality: str | None = None
    voice: str | None = None
    file_id: int | None = None


class GrantRequest(StrictModel):
    subject_type: str = Field(default="user", pattern="^(user|role)$")
    subject_id: int
    daily_spend_limit_micro: int | None = None
    monthly_spend_limit_micro: int | None = None
    expires_in_days: int | None = None
    note: str | None = None


def _model_admin_payload(db, model: Model) -> dict[str, Any]:  # noqa: ANN001
    grants = db.scalars(select(ModelGrant).where(ModelGrant.model_id == model.id)).all()
    return {
        "id": model.id,
        "provider_id": model.provider_id,
        "provider_name": model.provider.name if model.provider else None,
        "provider_enabled": model.provider.enabled if model.provider else None,
        "provider_model_id": model.provider_model_id,
        "display_name": model.display_name,
        "description": model.description,
        "model_family": model.model_family,
        "capabilities": model.capabilities or [],
        "input_modalities": model.input_modalities or [],
        "output_modalities": model.output_modalities or [],
        "context_window": model.context_window,
        "max_output_tokens": model.max_output_tokens,
        "supports_streaming": model.supports_streaming,
        "supports_tools": model.supports_tools,
        "supports_vision": model.supports_vision,
        "supports_embeddings": model.supports_embeddings,
        "supports_json_mode": model.supports_json_mode,
        "supports_reasoning": model.supports_reasoning,
        "supports_audio_input": model.supports_audio_input,
        "supports_audio_output": model.supports_audio_output,
        "supports_video": model.supports_video,
        "provider_cost_input_per_mtok": float(model.provider_cost_input_per_mtok) if model.provider_cost_input_per_mtok is not None else None,
        "provider_cost_output_per_mtok": float(model.provider_cost_output_per_mtok) if model.provider_cost_output_per_mtok is not None else None,
        "provider_cost_per_request": float(model.provider_cost_per_request) if model.provider_cost_per_request is not None else None,
        "provider_cost_per_image": float(model.provider_cost_per_image) if model.provider_cost_per_image is not None else None,
        "provider_cost_per_audio_minute": float(model.provider_cost_per_audio_minute) if model.provider_cost_per_audio_minute is not None else None,
        "pricing_uncertain": model.pricing_uncertain,
        "selling_input_per_mtok": float(model.selling_input_per_mtok) if model.selling_input_per_mtok is not None else None,
        "selling_output_per_mtok": float(model.selling_output_per_mtok) if model.selling_output_per_mtok is not None else None,
        "selling_per_request": float(model.selling_per_request) if model.selling_per_request is not None else None,
        "selling_per_image": float(model.selling_per_image) if model.selling_per_image is not None else None,
        "selling_per_audio_minute": float(model.selling_per_audio_minute) if model.selling_per_audio_minute is not None else None,
        "visibility": model.visibility,
        "availability": model.availability,
        "access_tier": model.access_tier,
        "enabled": model.enabled,
        "published": model.published,
        "is_default": model.is_default,
        "is_user_visible": model.is_user_visible(),
        "subscription_plan_id": model.subscription_plan_id,
        "categories": [{"id": c.id, "slug": c.slug, "name": c.name} for c in model.categories],
        "tags": [],
        "sort_order": model.sort_order,
        "deprecation_note": model.deprecation_note,
        "last_tested_at": model.last_tested_at,
        "last_test_status": model.last_test_status,
        "last_test_latency_ms": model.last_test_latency_ms,
        "last_test_error_category": model.last_test_error_category,
        "last_test_message": model.last_test_message,
        "discovered_by_sync": model.discovered_by_sync,
        "grants": [
            {
                "id": g.id,
                "subject_type": g.subject_type,
                "subject_id": g.subject_id,
                "daily_spend_limit_micro": g.daily_spend_limit_micro,
                "monthly_spend_limit_micro": g.monthly_spend_limit_micro,
                "expires_at": g.expires_at,
                "note": g.note,
            }
            for g in grants
        ],
        "created_at": model.created_at,
        "updated_at": model.updated_at,
    }


def _per_mtok_credits(micro_per_mtok: int | None) -> float | None:
    """Display helper: micro-credits per 1M tokens -> credits per 1M tokens.

    Customer-facing prices are expressed in **credits per million tokens**
    (``0.28``) while they are stored in micro-credits per million tokens
    (``280000``); ``None`` (unpriced model) stays ``None``.
    """
    return pricing_service.micro_to_per_mtok_credits(micro_per_mtok)


# ------------------------------------------------------------- user catalog --
@router.get("")
def list_models(
    db: DbDep,
    user: OptionalUser,
    page: PageDep,
    search: str | None = None,
    capability: str | None = None,
    category: str | None = None,
    provider: str | None = None,
    tier: str | None = None,
    favorites_only: bool = False,
    include_unavailable: bool = False,
) -> dict[str, Any]:
    """Models a signed-in user is allowed to use (server-enforced filtering)."""
    stmt = access_service.visible_models_query(user, include_unpublished=include_unavailable)
    if search:
        term = f"%{search.lower()}%"
        stmt = stmt.where(or_(func.lower(Model.display_name).like(term), func.lower(Model.provider_model_id).like(term),
                              func.lower(Model.description).like(term)))
    if capability:
        # JSON array containment differs per engine; filter in Python for portability
        pass
    if category:
        stmt = stmt.join(Model.categories).where(ModelCategory.slug == category)
    if provider:
        stmt = stmt.where(Provider.slug == provider)
    if tier:
        stmt = stmt.where(Model.access_tier == tier)
    all_models = db.scalars(stmt.order_by(Model.sort_order, Model.display_name)).unique().all()
    if capability:
        all_models = [m for m in all_models if capability in (m.capabilities or [])]
    if favorites_only:
        all_models = [m for m in all_models if m.is_favorite_hint]
    allowed = access_service.filter_models_for_user(db, user, all_models)
    total = len(allowed)
    start = page.offset
    window = allowed[start:start + page.limit]
    items = []
    for model in window:
        decision = access_service.evaluate_model_access(db, user, model, operation=(model.capabilities or ["chat"])[0])
        quote = pricing_service.resolve_price(db, model, user=user)
        data = model.public_dict()
        data.update(
            {
                "pricing": {
                    "currency": quote.currency,
                    # A "per 1M token" price in credits equals the micro-credit price per token
                    # (1 credit = 1e6 micro, 1M tokens = 1e6 tokens), so no conversion is applied here.
                    "input_credits_per_mtok": _per_mtok_credits(quote.input_per_mtok_micro),
                    "output_credits_per_mtok": _per_mtok_credits(quote.output_per_mtok_micro),
                    "per_request_credits": pricing_service.micro_to_credits(quote.per_request_micro),
                    "per_image_credits": pricing_service.micro_to_credits(quote.per_image_micro),
                    "per_audio_minute_credits": pricing_service.micro_to_credits(quote.per_audio_minute_micro),
                    "minimum_charge_credits": pricing_service.micro_to_credits(quote.minimum_charge_micro),
                    "pricing_model": quote.scope,
                    "notes": quote.warnings,
                },
                "accessible": decision.allowed,
                "access_reason": decision.reason,
                # Machine-readable counterpart of `access_reason`: the client localises it, so a
                # Persian/Arabic/Kurdish user is never shown an English sentence (see docs/TEST_REPORT.md).
                "access_code": decision.code,
                "requires_payment": decision.requires_payment,
                "categories": [{"slug": c.slug, "name": c.name} for c in model.categories],
                "categories_i18n": [{"slug": c.slug, "name": c.name, "name_fa": c.name_fa} for c in model.categories],
            }
        )
        items.append(data)
    return {
        **paginated(items, total, page),
        "capabilities": list(ALL_OPERATIONS),
        "operation_labels": OPERATION_LABELS,
        "tiers": list(AccessTier.ALL),
    }


@router.get("/categories")
def list_categories(db: DbDep, user: OptionalUser) -> dict[str, Any]:
    categories = db.scalars(select(ModelCategory).order_by(ModelCategory.sort_order)).all()
    counts: dict[int, int] = {}
    if user is not None:
        visible = access_service.filter_models_for_user(db, user, list(db.scalars(access_service.visible_models_query(user)).all()))
        for model in visible:
            for category in model.categories:
                counts[category.id] = counts.get(category.id, 0) + 1
    return {
        "items": [
            {
                "id": c.id, "slug": c.slug, "name": c.name, "name_fa": c.name_fa, "description": c.description,
                "icon": c.icon, "model_count": counts.get(c.id, 0) if user else None,
            }
            for c in categories
        ]
    }


@router.get("/{model_id}")
def model_detail(model_id: int, db: DbDep, user: OptionalUser) -> dict[str, Any]:
    model = db.get(Model, model_id)
    if model is None:
        raise NotFound("Model not found.")
    decision = access_service.evaluate_model_access(db, user, model, operation="chat")
    if not model.is_user_visible() and not (user and access_service.has_permission(user, "models.read")):
        raise NotFound("Model not found.")
    quote = pricing_service.resolve_price(db, model, user=user)
    return {
        "model": model.public_dict(),
        "access": {
            "allowed": decision.allowed,
            "code": decision.code,
            "reason": decision.reason,
            "requires_payment": decision.requires_payment,
        },
        "pricing": {
            "currency": quote.currency,
            "pricing_model": quote.scope,
            "input_credits_per_mtok": _per_mtok_credits(quote.input_per_mtok_micro),
            "output_credits_per_mtok": _per_mtok_credits(quote.output_per_mtok_micro),
            "per_request_credits": pricing_service.micro_to_credits(quote.per_request_micro),
            "per_image_credits": pricing_service.micro_to_credits(quote.per_image_micro),
            "per_audio_minute_credits": pricing_service.micro_to_credits(quote.per_audio_minute_micro),
            "minimum_charge_credits": pricing_service.micro_to_credits(quote.minimum_charge_micro),
            "notes": quote.warnings,
        },
    }


# ------------------------------------------------------------ admin: models --
@admin_router.get("")
def admin_list_models(
    db: DbDep,
    page: PageDep,
    actor: Annotated[User, Depends(require_permission("models.read"))],
    search: str | None = None,
    provider_id: int | None = None,
    visibility: str | None = None,
    availability: str | None = None,
    access_tier: str | None = None,
    enabled: bool | None = None,
    published: bool | None = None,
    only_problems: bool = False,
    sort: str = Query("updated_at", pattern="^(updated_at|created_at|display_name|last_tested_at|sort_order)$"),
    direction: str = Query("desc", pattern="^(asc|desc)$"),
) -> dict[str, Any]:
    stmt = select(Model)
    if search:
        term = f"%{search.lower()}%"
        stmt = stmt.where(or_(func.lower(Model.display_name).like(term), func.lower(Model.provider_model_id).like(term)))
    if provider_id:
        stmt = stmt.where(Model.provider_id == provider_id)
    if visibility:
        stmt = stmt.where(Model.visibility == visibility)
    if availability:
        stmt = stmt.where(Model.availability == availability)
    if access_tier:
        stmt = stmt.where(Model.access_tier == access_tier)
    if enabled is not None:
        stmt = stmt.where(Model.enabled.is_(enabled))
    if published is not None:
        stmt = stmt.where(Model.published.is_(published))
    if only_problems:
        stmt = stmt.where(or_(Model.availability == ModelAvailability.DEGRADED, Model.last_test_status == "error",
                              Model.last_test_error_category.is_not(None)))
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    column = getattr(Model, sort)
    rows = db.scalars(stmt.order_by(column.desc() if direction == "desc" else column.asc()).offset(page.offset).limit(page.limit)).all()
    counts = {
        "total": db.scalar(select(func.count(Model.id))) or 0,
        "public_published": db.scalar(
            select(func.count(Model.id)).where(Model.visibility == "public", Model.published.is_(True))
        ) or 0,
        "hidden": db.scalar(select(func.count(Model.id)).where(Model.visibility == "hidden")) or 0,
        "disabled": db.scalar(select(func.count(Model.id)).where(Model.enabled.is_(False))) or 0,
        "untested": db.scalar(select(func.count(Model.id)).where(Model.availability == "untested")) or 0,
    }
    return {**paginated([_model_admin_payload(db, m) for m in rows], int(total), page), "counts": counts}


@admin_router.post("", status_code=201)
def admin_create_model(
    payload: ModelCreate,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("models.manage"))],
    client: Client,
) -> dict[str, Any]:
    provider = db.get(Provider, payload.provider_id)
    if provider is None:
        raise NotFound("Provider not found.")
    if db.scalars(
        select(Model).where(Model.provider_id == provider.id, Model.provider_model_id == payload.provider_model_id)
    ).first() is not None:
        raise ValidationError("This provider model id is already registered.")
    unknown_caps = set(payload.capabilities) - set(ALL_OPERATIONS)
    if unknown_caps:
        raise ValidationError(f"Unknown capability value(s): {', '.join(sorted(unknown_caps))}.")
    if payload.visibility not in ModelVisibility.ALL:
        raise ValidationError("Invalid visibility value.")
    if payload.access_tier not in AccessTier.ALL:
        raise ValidationError("Invalid access tier.")
    if payload.published and payload.visibility != ModelVisibility.PUBLIC:
        raise ValidationError("Only models with 'public' visibility can be published for users.")
    data = payload.model_dump(exclude={"category_ids", "tag_slugs"})
    model = Model(**{k: v for k, v in data.items() if k not in ("category_ids", "tag_slugs")})
    db.add(model)
    db.flush()
    if payload.category_ids:
        model.categories = list(db.scalars(select(ModelCategory).where(ModelCategory.id.in_(payload.category_ids))).all())
    audit_service.record_audit(
        db, action="model.created", summary=f"Model '{model.display_name}' created (visibility={model.visibility}, published={model.published}).",
        actor=actor, entity_type="model", entity_id=model.id,
        after={"provider_id": provider.id, "provider_model_id": model.provider_model_id, "visibility": model.visibility,
               "access_tier": model.access_tier, "published": model.published},
        ip_address=client.ip,
    )
    db.commit()
    return {"model": _model_admin_payload(db, model)}


@admin_router.get("/{model_id}")
def admin_get_model(
    model_id: int,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("models.read"))],
) -> dict[str, Any]:
    model = db.get(Model, model_id)
    if model is None:
        raise NotFound("Model not found.")
    quote = pricing_service.resolve_price(db, model)
    recent_tests = db.scalars(
        select(__import__("app.models.admin", fromlist=["AdminModelTest"]).AdminModelTest)
        .where(__import__("app.models.admin", fromlist=["AdminModelTest"]).AdminModelTest.model_id == model.id)
        .order_by(__import__("app.models.admin", fromlist=["AdminModelTest"]).AdminModelTest.created_at.desc())
        .limit(10)
    ).all()
    from app.models.billing import UsageRecord

    usage_count = db.scalar(select(func.count(UsageRecord.id)).where(UsageRecord.model_id == model.id)) or 0
    error_rows = db.scalars(
        select(UsageRecord).where(UsageRecord.model_id == model.id, UsageRecord.error_category.is_not(None))
        .order_by(UsageRecord.created_at.desc()).limit(10)
    ).all()
    return {
        "model": _model_admin_payload(db, model),
        "pricing_quote": quote.to_dict(),
        "supported_operations": list(ALL_OPERATIONS),
        "recent_tests": [
            {
                "id": t.id, "operation": t.operation, "success": t.success, "latency_ms": t.latency_ms,
                "error_category": t.error_category, "error_message": t.error_message, "created_at": t.created_at,
                "admin_user_id": t.admin_user_id, "provider_cost_micro": t.provider_cost_micro,
                "usage_source": t.usage_source,
            }
            for t in recent_tests
        ],
        "usage": {
            "total_records": int(usage_count),
            "recent_errors": [
                {"id": u.id, "operation": u.operation, "error_category": u.error_category, "created_at": u.created_at}
                for u in error_rows
            ],
        },
    }


@admin_router.patch("/{model_id}")
def admin_update_model(
    model_id: int,
    payload: ModelUpdate,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("models.manage"))],
    client: Client,
) -> dict[str, Any]:
    model = db.get(Model, model_id)
    if model is None:
        raise NotFound("Model not found.")
    before = _model_admin_payload(db, model)
    data = payload.model_dump(exclude_unset=True)
    if "capabilities" in data and data["capabilities"] is not None:
        unknown = set(data["capabilities"]) - set(ALL_OPERATIONS)
        if unknown:
            raise ValidationError(f"Unknown capability value(s): {', '.join(sorted(unknown))}.")
    if data.get("visibility") and data["visibility"] not in ModelVisibility.ALL:
        raise ValidationError("Invalid visibility value.")
    if data.get("access_tier") and data["access_tier"] not in AccessTier.ALL:
        raise ValidationError("Invalid access tier.")
    if data.get("availability") and data["availability"] not in ModelAvailability.ALL:
        raise ValidationError("Invalid availability value.")
    if data.get("published") and (data.get("visibility") or model.visibility) != ModelVisibility.PUBLIC:
        raise ValidationError("Publishing requires 'public' visibility — a hidden model cannot be published.")
    if data.get("published"):
        access_service.require_permission(actor, "models.publish")

    category_ids = data.pop("category_ids", None)
    for key, value in data.items():
        if value is not None or key in ("description", "model_family", "deprecation_note", "subscription_plan_id"):
            setattr(model, key, value)
    if category_ids is not None:
        model.categories = list(db.scalars(select(ModelCategory).where(ModelCategory.id.in_(category_ids))).all())
    db.flush()
    after = _model_admin_payload(db, model)
    action = "model.updated"
    if "published" in data:
        action = "model.published" if data["published"] else "model.unpublished"
    elif "enabled" in data:
        action = "model.enabled" if data["enabled"] else "model.disabled"
    audit_service.record_audit(
        db, action=action, summary=f"Model '{model.display_name}' updated by {actor.email}.", actor=actor,
        entity_type="model", entity_id=model.id, before=before, after=after, ip_address=client.ip,
    )
    db.commit()
    return {"model": after}


@admin_router.post("/bulk")
def bulk_update(
    payload: BulkUpdate,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("models.manage"))],
    client: Client,
) -> dict[str, Any]:
    if not payload.confirm:
        raise ValidationError("Bulk operations require explicit confirmation (confirm=true).")
    if payload.action not in ("publish", "unpublish", "enable", "disable", "set_tier", "set_visibility", "add_categories"):
        raise ValidationError("Unsupported bulk action.")
    if payload.action in ("publish", "unpublish"):
        access_service.require_permission(actor, "models.publish")
    models = db.scalars(select(Model).where(Model.id.in_(payload.model_ids))).all()
    if not models:
        raise NotFound("No models matched the supplied ids.")
    changed: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []
    for model in models:
        before = {"visibility": model.visibility, "published": model.published, "enabled": model.enabled,
                  "access_tier": model.access_tier}
        if payload.action == "publish":
            if model.visibility != ModelVisibility.PUBLIC:
                errors.append({"model_id": model.id, "reason": "Model is not public; change visibility first."})
                continue
            if not (model.capabilities or []):
                errors.append({"model_id": model.id, "reason": "Model has no verified capabilities; test it before publishing."})
                continue
            model.published = True
        elif payload.action == "unpublish":
            model.published = False
        elif payload.action == "enable":
            model.enabled = True
        elif payload.action == "disable":
            model.enabled = False
        elif payload.action == "set_tier":
            if payload.access_tier not in AccessTier.ALL:
                raise ValidationError("Invalid access tier.")
            model.access_tier = payload.access_tier
            if payload.access_tier == AccessTier.INTERNAL and model.published:
                model.published = False
        elif payload.action == "set_visibility":
            if payload.visibility not in ModelVisibility.ALL:
                raise ValidationError("Invalid visibility.")
            model.visibility = payload.visibility
            if payload.visibility != ModelVisibility.PUBLIC:
                model.published = False  # never leave a non-public model published
        elif payload.action == "add_categories" and payload.category_ids:
            existing = {c.id for c in model.categories}
            for category in db.scalars(select(ModelCategory).where(ModelCategory.id.in_(payload.category_ids))).all():
                if category.id not in existing:
                    model.categories.append(category)
        changed.append({"model_id": model.id, "before": before,
                        "after": {"visibility": model.visibility, "published": model.published, "enabled": model.enabled,
                                  "access_tier": model.access_tier}})
    db.flush()
    audit_service.record_audit(
        db, action="model.bulk_updated", summary=f"Bulk {payload.action} applied to {len(changed)} model(s) by {actor.email}.",
        actor=actor, entity_type="model", entity_id=",".join(str(c['model_id']) for c in changed[:50]),
        after={"action": payload.action, "changed": changed, "errors": errors}, severity="warning", ip_address=client.ip,
    )
    db.commit()
    return {"action": payload.action, "updated": len(changed), "skipped": len(errors), "errors": errors, "changes": changed}


@admin_router.delete("/{model_id}")
def admin_delete_model(
    model_id: int,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("models.manage"))],
    archive_only: bool = True,
) -> dict[str, Any]:
    model = db.get(Model, model_id)
    if model is None:
        raise NotFound("Model not found.")
    if archive_only:
        model.enabled = False
        model.published = False
        model.visibility = ModelVisibility.ARCHIVED
        audit_service.record_audit(
            db, action="model.deleted", summary=f"Model '{model.display_name}' archived (soft delete).", actor=actor,
            entity_type="model", entity_id=model.id, severity="warning",
        )
        db.commit()
        return {"archived": True, "model_id": model.id}
    from app.models.billing import UsageRecord

    if db.scalars(select(UsageRecord).where(UsageRecord.model_id == model.id).limit(1)).first() is not None:
        raise ValidationError(
            "This model has usage history; deleting it would orphan billing records. Archive it instead."
        )
    name = model.display_name
    db.delete(model)
    audit_service.record_audit(db, action="model.deleted", summary=f"Model '{name}' hard-deleted by {actor.email}.",
                               actor=actor, entity_type="model", entity_id=f"{model_id}", severity="critical")
    db.commit()
    return {"deleted": True, "model_id": model_id}


@admin_router.post("/{model_id}/test")
async def admin_test_model(
    model_id: int,
    payload: ModelTestRequest,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("models.test"))],
    client: Client,
) -> dict[str, Any]:
    """Administrative model test (spec §9) — works for hidden/restricted models."""
    model = db.get(Model, model_id)
    if model is None:
        raise NotFound("Model not found.")
    result = await ai_service.admin_test_model(db, admin=actor, model=model, operation=payload.operation,
                                               payload=payload.model_dump(exclude_none=True))
    audit_service.record_audit(
        db, action="model.tested",
        summary=f"Admin test of '{model.display_name}' ({payload.operation}): {'success' if result['success'] else result['error_category']}",
        actor=actor, entity_type="model", entity_id=model.id,
        after={"operation": payload.operation, "success": result["success"], "latency_ms": result["latency_ms"],
               "visibility": model.visibility, "billed_to_user": False},
        ip_address=client.ip,
    )
    db.commit()
    return result


@admin_router.get("/{model_id}/tests")
def admin_model_tests(
    model_id: int,
    db: DbDep,
    page: PageDep,
    actor: Annotated[User, Depends(require_permission("models.test"))],
) -> dict[str, Any]:
    from app.models.admin import AdminModelTest

    total = db.scalar(select(func.count(AdminModelTest.id)).where(AdminModelTest.model_id == model_id)) or 0
    rows = db.scalars(
        select(AdminModelTest).where(AdminModelTest.model_id == model_id)
        .order_by(AdminModelTest.created_at.desc()).offset(page.offset).limit(page.limit)
    ).all()
    return paginated(
        [
            {
                "id": t.id, "operation": t.operation, "success": t.success, "latency_ms": t.latency_ms,
                "prompt_tokens": t.prompt_tokens, "completion_tokens": t.completion_tokens,
                "usage_source": t.usage_source, "provider_cost_micro": t.provider_cost_micro,
                "cost_uncertain": t.cost_uncertain, "error_category": t.error_category,
                "error_message": t.error_message, "response_preview": (t.response_text or "")[:400],
                "admin_user_id": t.admin_user_id, "created_at": t.created_at,
                "bypassed_user_restrictions": t.bypassed_user_restrictions,
            }
            for t in rows
        ],
        int(total),
        page,
    )


@admin_router.post("/{model_id}/grants")
def create_grant(
    model_id: int,
    payload: GrantRequest,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("models.grants.manage"))],
    client: Client,
) -> dict[str, Any]:
    model = db.get(Model, model_id)
    if model is None:
        raise NotFound("Model not found.")
    if payload.subject_type == "user" and db.get(UserModel, payload.subject_id) is None:
        raise NotFound("Target user not found.")
    if payload.subject_type == "role" and db.get(Role, payload.subject_id) is None:
        raise NotFound("Target role not found.")
    existing = db.scalars(
        select(ModelGrant).where(ModelGrant.model_id == model.id, ModelGrant.subject_type == payload.subject_type,
                                 ModelGrant.subject_id == payload.subject_id)
    ).first()
    expires_at = dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=payload.expires_in_days) if payload.expires_in_days else None
    if existing:
        existing.daily_spend_limit_micro = payload.daily_spend_limit_micro
        existing.monthly_spend_limit_micro = payload.monthly_spend_limit_micro
        existing.expires_at = expires_at
        existing.note = payload.note
        grant = existing
    else:
        grant = ModelGrant(
            model_id=model.id, subject_type=payload.subject_type, subject_id=payload.subject_id,
            granted_by_id=actor.id, daily_spend_limit_micro=payload.daily_spend_limit_micro,
            monthly_spend_limit_micro=payload.monthly_spend_limit_micro, expires_at=expires_at, note=payload.note,
        )
        db.add(grant)
    db.flush()
    audit_service.record_audit(
        db, action="model.grant_created",
        summary=f"Grant on '{model.display_name}' for {payload.subject_type} #{payload.subject_id}.",
        actor=actor, entity_type="model", entity_id=model.id,
        after={"subject_type": payload.subject_type, "subject_id": payload.subject_id,
               "daily_spend_limit_micro": payload.daily_spend_limit_micro},
        ip_address=client.ip,
    )
    db.commit()
    return {"grant_id": grant.id, "model_id": model.id, "subject_type": grant.subject_type, "subject_id": grant.subject_id}


@admin_router.delete("/{model_id}/grants/{grant_id}")
def revoke_grant(
    model_id: int,
    grant_id: int,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("models.grants.manage"))],
) -> dict[str, Any]:
    grant = db.get(ModelGrant, grant_id)
    if grant is None or grant.model_id != model_id:
        raise NotFound("Grant not found.")
    db.delete(grant)
    audit_service.record_audit(db, action="model.grant_revoked", summary=f"Grant #{grant_id} revoked.", actor=actor,
                               entity_type="model", entity_id=model_id)
    db.commit()
    return {"revoked": True, "grant_id": grant_id}


@admin_router.get("/{model_id}/usage")
def model_usage(
    model_id: int,
    db: DbDep,
    actor: Annotated[User, Depends(require_permission("usage.read"))],
) -> dict[str, Any]:
    from app.models.billing import UsageRecord

    total = db.scalar(select(func.count(UsageRecord.id)).where(UsageRecord.model_id == model_id)) or 0
    user_usage = db.scalar(
        select(func.count(UsageRecord.id)).where(UsageRecord.model_id == model_id, UsageRecord.is_admin_test.is_(False))
    ) or 0
    admin_usage = int(total) - int(user_usage)
    tokens = db.scalar(select(func.coalesce(func.sum(UsageRecord.total_tokens), 0)).where(UsageRecord.model_id == model_id)) or 0
    charged = db.scalar(select(func.coalesce(func.sum(UsageRecord.charged_micro), 0)).where(UsageRecord.model_id == model_id)) or 0
    cost = db.scalar(select(func.coalesce(func.sum(UsageRecord.provider_cost_micro), 0)).where(UsageRecord.model_id == model_id)) or 0
    errors = db.execute(
        select(UsageRecord.error_category, func.count(UsageRecord.id))
        .where(UsageRecord.model_id == model_id, UsageRecord.error_category.is_not(None))
        .group_by(UsageRecord.error_category)
    ).all()
    return {
        "model_id": model_id,
        "requests_total": int(total),
        "requests_user": int(user_usage),
        "requests_admin_test": int(admin_usage),
        "tokens_total": int(tokens),
        "charged_micro": int(charged),
        "provider_cost_micro": int(cost),
        "error_categories": {category: int(count) for category, count in errors},
        "note": "Admin test usage is reported separately and is never billed to user balances.",
    }

# ---------------------------------------------------------------- variants -----
class VariantPayload(StrictModel):
    name: str | None = None
    description: str | None = None
    emoji: str | None = None
    system_prompt: str | None = None
    default_temperature: float | None = Field(default=None, ge=0, le=2)
    default_top_p: float | None = Field(default=None, ge=0, le=1)
    default_max_tokens: int | None = Field(default=None, ge=1, le=200_000)
    enabled: bool | None = None
    is_default: bool | None = None
    scope: str | None = None
    sort_order: int | None = None


def _model_or_404(db: Session, model_id: int) -> Model:
    model = db.get(Model, model_id)
    if model is None:
        raise NotFound("Model not found.")
    return model


def _can_see_model(db: Session, user: UserModel, model: Model) -> bool:
    visible = access_service.filter_models_for_user(db, user, [model])
    return bool(visible)


@router.get("/{model_id}/variants")
def list_model_variants(model_id: int, db: DbDep, user: CurrentUser) -> dict[str, Any]:
    """Variants of a model that *this* user may use (system ones + their own)."""
    model = _model_or_404(db, model_id)
    if not _can_see_model(db, user, model):
        raise NotFound("Model not found.")
    variants = variant_service.list_variants(db, model_id=model.id, actor=user)
    return {
        "items": [variant_service.serialize(v, model=model, prompts_visible=True) for v in variants],
        "model": {"id": model.id, "display_name": model.display_name},
    }


@router.post("/{model_id}/variants", status_code=201)
def create_variant(model_id: int, payload: VariantPayload, db: DbDep, user: CurrentUser, client: Client) -> dict[str, Any]:
    """Create a variant. Any user may create a *personal* one; only administrators a system one."""
    model = _model_or_404(db, model_id)
    if not _can_see_model(db, user, model):
        raise NotFound("Model not found.")
    is_admin = access_service.has_permission(user, "models.manage") or access_service.has_permission(user, "models.test")
    if not is_admin and payload.scope == "system":
        raise ValidationError("Only an administrator can create a variant for everyone. Use scope='personal'.")
    data = payload.model_dump(exclude_none=True)
    if is_admin and "scope" not in data:
        data["scope"] = "system"
    variant = variant_service.create_variant(db, actor=user, model=model, data=data, allow_system_scope=is_admin)
    return {"variant": variant_service.serialize(variant, model=model)}


@router.patch("/variants/{variant_id}")
def update_variant(variant_id: int, payload: VariantPayload, db: DbDep, user: CurrentUser, client: Client) -> dict[str, Any]:
    variant = variant_service.get_variant(db, variant_id)
    is_admin = access_service.has_permission(user, "models.manage") or access_service.has_permission(user, "models.test")
    updated = variant_service.update_variant(
        db, actor=user, variant=variant, data=payload.model_dump(exclude_none=True), allow_system_scope=is_admin
    )
    return {"variant": variant_service.serialize(updated)}


@router.delete("/variants/{variant_id}")
def delete_variant(variant_id: int, db: DbDep, user: CurrentUser, client: Client) -> dict[str, Any]:
    variant = variant_service.get_variant(db, variant_id)
    is_admin = access_service.has_permission(user, "models.manage") or access_service.has_permission(user, "models.test")
    name = variant.name
    variant_service.delete_variant(db, actor=user, variant=variant, allow_system_scope=is_admin)
    return {"deleted": True, "name": name}


@router.post("/variants/{variant_id}/toggle")
def toggle_variant(variant_id: int, db: DbDep, user: CurrentUser, client: Client) -> dict[str, Any]:
    """One-click switch: immediately on or off, audited."""
    variant = variant_service.get_variant(db, variant_id)
    is_admin = access_service.has_permission(user, "models.manage") or access_service.has_permission(user, "models.test")
    updated = variant_service.update_variant(
        db, actor=user, variant=variant, data={"enabled": not variant.enabled}, allow_system_scope=is_admin
    )
    return {"variant": variant_service.serialize(updated), "enabled": updated.enabled}


# ---------------------------------------------------------------- admin --------
@admin_variants_router.get("")
def admin_list_variants(
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("models.read"))],
    model_id: int | None = None,
    include_disabled: bool = True,
) -> dict[str, Any]:
    """Every variant, including disabled ones and other people's personal variants."""
    variants = variant_service.list_variants(
        db, model_id=model_id, actor=actor, include_disabled=include_disabled, include_personal_of_others=True
    )
    models = {m.id: m for m in db.scalars(select(Model).where(Model.id.in_([v.model_id for v in variants] or [0]))).all()}
    items = []
    for variant in variants:
        owner = db.get(UserModel, variant.owner_user_id) if variant.owner_user_id else None
        data = variant_service.serialize(variant, model=models.get(variant.model_id))
        data["owner_email"] = owner.email if owner else None
        items.append(data)
    return {"items": items, "total": len(items)}


@admin_variants_router.post("/models/{model_id}", status_code=201)
def admin_create_variant(
    model_id: int,
    payload: VariantPayload,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("models.manage"))],
) -> dict[str, Any]:
    model = _model_or_404(db, model_id)
    data = payload.model_dump(exclude_none=True)
    data.setdefault("scope", "system")
    variant = variant_service.create_variant(db, actor=actor, model=model, data=data, allow_system_scope=True)
    return {"variant": variant_service.serialize(variant, model=model)}


@admin_variants_router.patch("/{variant_id}")
def admin_update_variant(
    variant_id: int,
    payload: VariantPayload,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("models.manage"))],
) -> dict[str, Any]:
    variant = variant_service.get_variant(db, variant_id)
    updated = variant_service.update_variant(
        db, actor=actor, variant=variant, data=payload.model_dump(exclude_none=True), allow_system_scope=True
    )
    return {"variant": variant_service.serialize(updated)}


@admin_variants_router.delete("/{variant_id}")
def admin_delete_variant(
    variant_id: int,
    db: DbDep,
    actor: Annotated[UserModel, Depends(require_permission("models.manage"))],
) -> dict[str, Any]:
    variant = variant_service.get_variant(db, variant_id)
    variant_service.delete_variant(db, actor=actor, variant=variant, allow_system_scope=True)
    return {"deleted": True}
