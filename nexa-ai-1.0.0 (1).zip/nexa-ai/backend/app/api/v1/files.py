"""File upload/download with strict authorization (spec §12)."""
from __future__ import annotations

import datetime as dt
from typing import Annotated, Any

from fastapi import APIRouter, Depends, File, Query, UploadFile
from fastapi.responses import Response
from sqlalchemy import func, select

from app.api.deps import CurrentUser, DbDep, PageDep, paginated
from app.core.config import settings
from app.core.errors import NotFound, ValidationError
from app.core.logging import get_logger
from app.models.files import FileKind, StoredFile
from app.models.user import User as UserModel
from app.services import audit as audit_service
from app.services import files as file_service
from app.services.settings_store import get_value

log = get_logger(__name__)
router = APIRouter(prefix="/files", tags=["files"])


@router.get("")
def list_files(
    db: DbDep,
    page: PageDep,
    user: CurrentUser,
    kind: str | None = None,
    search: str | None = None,
    include_deleted: bool = False,
) -> dict[str, Any]:
    stmt = select(StoredFile).where(StoredFile.user_id == user.id)
    if not include_deleted:
        stmt = stmt.where(StoredFile.deleted_at.is_(None))
    if kind:
        stmt = stmt.where(StoredFile.kind == kind)
    if search:
        stmt = stmt.where(func.lower(StoredFile.original_name).like(f"%{search.lower()}%"))
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.scalars(stmt.order_by(StoredFile.created_at.desc()).offset(page.offset).limit(page.limit)).all()
    used = file_service.user_storage_used(db, user.id)
    return {
        **paginated([_file_payload(f, include_text=False) for f in rows], int(total), page),
        "storage": {
            "used_bytes": used,
            "quota_bytes": int(get_value(db, "files.user_quota_mb", settings.user_storage_quota_mb)) * 1024 * 1024,
        },
    }


def _file_payload(record: StoredFile, *, include_text: bool = False) -> dict[str, Any]:
    return {
        "id": record.id,
        "uuid": record.uuid,
        "kind": record.kind,
        "name": record.original_name,
        "mime_type": record.mime_type,
        "extension": record.extension,
        "size_bytes": record.size_bytes,
        "size_mb": record.size_mb,
        "checksum_sha256": record.checksum_sha256,
        "content_validated": record.content_validated,
        "malware_scan_status": record.malware_scan_status,
        "has_extracted_text": bool(record.extracted_text),
        "metadata": record.metadata_json or {},
        "expires_at": record.expires_at,
        "created_at": record.created_at,
        "extracted_text": record.extracted_text[:5000] if include_text and record.extracted_text else None,
    }


@router.post("", status_code=201)
async def upload_file(
    db: DbDep,
    user: CurrentUser,
    file: UploadFile = File(...),
    kind: str = Query("upload", pattern="^(upload|attachment|receipt)$"),
    extract: bool = Query(False, description="Extract text immediately (PDF/XLSX/DOCX/CSV/TXT)."),
) -> dict[str, Any]:
    declared_limit = int(get_value(db, "files.max_upload_mb", settings.max_upload_mb)) * 1024 * 1024
    data = await file.read()
    if len(data) > declared_limit:
        from app.core.errors import PayloadTooLarge

        raise PayloadTooLarge(
            f"File exceeds the {declared_limit // 1048576} MB limit.",
            details={"max_upload_mb": declared_limit // 1048576, "size_bytes": len(data)},
        )
    record = file_service.store_upload(
        db,
        user=user,
        filename=file.filename or "unnamed",
        data=data,
        kind=kind if kind != "upload" else FileKind.UPLOAD,
        mime_type=file.content_type,
    )
    extracted: str | None = None
    if extract:
        try:
            extracted = file_service.extract_text(record)
            record.extracted_text = extracted
        except ValidationError as exc:
            extracted = None
            record.metadata_json = {**(record.metadata_json or {}), "extraction_error": exc.detail}
    audit_service.record_audit(db, action="file.uploaded", summary=f"File '{record.original_name}' uploaded ({record.size_bytes} bytes).",
                               actor=user, entity_type="file", entity_id=record.id,
                               after={"kind": record.kind, "extension": record.extension, "size_bytes": record.size_bytes})
    db.commit()
    payload = _file_payload(record, include_text=True)
    payload["extracted_text"] = extracted[:5000] if extracted else None
    return {"file": payload, "limits": {"max_upload_mb": declared_limit // 1048576,
                                        "allowed_extensions": sorted(settings.allowed_extension_set)}}


@router.get("/{file_id}")
def file_metadata(
    file_id: int,
    db: DbDep,
    user: CurrentUser,
) -> dict[str, Any]:
    record = db.get(StoredFile, file_id)
    if record is None:
        raise NotFound("File not found.")
    file_service.authorize_download(db, record=record, user=user)
    return {"file": _file_payload(record, include_text=True)}


@router.get("/{file_id}/download")
def download_file(
    file_id: int,
    db: DbDep,
    user: CurrentUser,
) -> Response:
    record = db.get(StoredFile, file_id)
    if record is None:
        raise NotFound("File not found.")
    file_service.authorize_download(db, record=record, user=user)
    data = file_service.read_bytes(record)
    safe_name = record.original_name.replace('"', "").replace("\n", " ")[:150]
    return Response(
        content=data,
        media_type=record.mime_type,
        headers={
            "Content-Disposition": f'attachment; filename="{safe_name}"',
            "X-Content-Type-Options": "nosniff",
            "Cache-Control": "private, no-store",
        },
    )


@router.post("/{file_id}/extract")
def extract_text(
    file_id: int,
    db: DbDep,
    user: CurrentUser,
    max_chars: int = Query(20000, ge=100, le=200000),
) -> dict[str, Any]:
    record = db.get(StoredFile, file_id)
    if record is None:
        raise NotFound("File not found.")
    file_service.authorize_download(db, record=record, user=user)
    text = file_service.extract_text(record, max_chars=max_chars)
    record.extracted_text = text
    db.commit()
    return {
        "file_id": record.id,
        "name": record.original_name,
        "characters": len(text),
        "text": text,
    }


@router.delete("/{file_id}")
def delete_file(
    file_id: int,
    db: DbDep,
    user: CurrentUser,
    hard: bool = False,
) -> dict[str, Any]:
    record = db.get(StoredFile, file_id)
    if record is None or (record.user_id != user.id and not user.is_admin()):
        raise NotFound("File not found.")
    file_service.delete_file(db, record, hard=hard)
    audit_service.record_audit(db, action="file.deleted", summary=f"File '{record.original_name}' deleted.", actor=user,
                               entity_type="file", entity_id=record.id)
    db.commit()
    return {"deleted": True, "file_id": file_id, "mode": "hard" if hard else "soft"}


@router.get("/storage/summary")
def storage_summary(
    db: DbDep,
    user: CurrentUser,
) -> dict[str, Any]:
    rows = db.execute(
        select(StoredFile.kind, func.count(StoredFile.id), func.coalesce(func.sum(StoredFile.size_bytes), 0))
        .where(StoredFile.user_id == user.id, StoredFile.deleted_at.is_(None))
        .group_by(StoredFile.kind)
    ).all()
    quota = int(get_value(db, "files.user_quota_mb", settings.user_storage_quota_mb)) * 1024 * 1024
    return {
        "by_kind": [
            {"kind": kind, "count": int(count), "bytes": int(total)} for kind, count, total in rows
        ],
        "used_bytes": file_service.user_storage_used(db, user.id),
        "quota_bytes": quota,
        "retention_days": settings.file_retention_days,
        "malware_scanning": {
            "enabled": settings.malware_scan_enabled,
            "configured": bool(settings.malware_scan_command),
        },
    }
