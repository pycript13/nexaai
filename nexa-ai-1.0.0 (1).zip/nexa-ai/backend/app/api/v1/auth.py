"""Authentication & account self-service endpoints."""
from __future__ import annotations

import datetime as dt
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Request, Response, status
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import select

from app.api.deps import Client, CurrentUser, DbDep, OptionalUser, rate_limit_key
from app.core.config import settings
from app.core.crypto import (
    hash_password,
    mask_secret,
    needs_rehash,
    password_policy_errors,
    verify_password,
)
from app.core.errors import AuthError, Conflict, NotFound, RateLimited, ValidationError
from app.core.logging import get_logger
from app.core.ratelimit import limiter
from app.core.security import (
    CSRF_COOKIE,
    SESSION_COOKIE,
    create_action_token,
    decode_action_token,
    generate_csrf_token,
    generate_otp,
    generate_session_token,
    hash_session_token,
)
from app.models.admin import AppSetting
from app.models.user import AccountStatus, Role, User, UserSession
from app.schemas.common import MessageResponse, StrictModel
from app.services import access as access_service
from app.services import audit as audit_service
from app.services import email as email_service
from app.services import ledger as ledger_service
from app.services import settings_store

log = get_logger(__name__)
router = APIRouter(prefix="/auth", tags=["auth"])


class RegisterRequest(StrictModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=256)
    display_name: str = Field(min_length=1, max_length=120)
    accept_terms: bool
    accept_privacy: bool
    invitation_token: str | None = None
    locale: str | None = None
    company: str | None = None


class LoginRequest(StrictModel):
    email: EmailStr
    password: str
    remember: bool = True


class PasswordChangeRequest(StrictModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=256)


class PasswordResetRequest(StrictModel):
    email: EmailStr


class PasswordResetConfirm(StrictModel):
    token: str
    new_password: str = Field(min_length=8, max_length=256)


class ProfileUpdateRequest(StrictModel):
    display_name: str | None = Field(default=None, max_length=120)
    phone: str | None = Field(default=None, max_length=32)
    company: str | None = Field(default=None, max_length=160)
    locale: str | None = None
    theme: str | None = None
    enhanced_theme: bool | None = None
    timezone: str | None = None


def _user_payload(user: User) -> dict[str, Any]:
    return {
        "id": user.id,
        "email": user.email,
        "display_name": user.display_name,
        "status": user.status,
        "locale": user.locale,
        "theme": user.theme,
        "enhanced_theme": user.enhanced_theme,
        "timezone": user.timezone,
        "email_verified": user.email_verified,
        "is_test_account": user.is_test_account,
        "expires_at": user.expires_at,
        "must_change_password": user.must_change_password,
        "roles": [{"slug": r.slug, "name": r.name} for r in user.roles],
        "permissions": sorted(access_service.user_permissions(user)),
        "created_at": user.created_at,
        "last_login_at": user.last_login_at,
    }


def set_session_cookies(response: Response, *, token: str, csrf: str, max_age: int) -> None:
    response.set_cookie(
        SESSION_COOKIE,
        token,
        max_age=max_age,
        httponly=True,
        secure=settings.cookie_secure,
        samesite=settings.cookie_samesite,
        path="/",
        domain=settings.cookie_domain or None,
    )
    response.set_cookie(
        CSRF_COOKIE,
        csrf,
        max_age=max_age,
        httponly=False,  # readable by the SPA so it can echo it in the header
        secure=settings.cookie_secure,
        samesite=settings.cookie_samesite,
        path="/",
        domain=settings.cookie_domain or None,
    )


def clear_session_cookies(response: Response) -> None:
    response.delete_cookie(SESSION_COOKIE, path="/")
    response.delete_cookie(CSRF_COOKIE, path="/")


def get_setting(db, key: str, default: Any = None) -> Any:  # noqa: ANN001
    return settings_store.get_value(db, key, default)


@router.get("/config")
def auth_config(db: DbDep) -> dict[str, Any]:
    """Public configuration the sign-in/sign-up screens need (no secrets)."""
    registration_mode = get_setting(db, "registration.mode", settings.registration_mode)
    return {
        "registration_mode": registration_mode,
        "registration_enabled": registration_mode != "closed",
        "password_min_length": int(get_setting(db, "security.password_min_length", settings.password_min_length)),
        "email_verification_required": bool(settings.email_enabled and settings.require_email_verification),
        "email_delivery_configured": email_service.is_configured(),
        "terms_version": get_setting(db, "registration.require_terms_version", "2026-01"),
        "privacy_version": get_setting(db, "registration.privacy_version", "2026-01"),
        "deployment_mode": settings.deployment_mode,
    }


@router.post("/register", status_code=status.HTTP_201_CREATED)
def register(payload: RegisterRequest, request: Request, response: Response, db: DbDep, client: Client) -> dict[str, Any]:
    limiter.check(rate_limit_key(request, "register"), settings.auth_rate_limit_per_minute, 60)
    if not payload.accept_terms or not payload.accept_privacy:
        raise ValidationError(
            "You must accept the Terms of Service and the Privacy Policy to create an account.",
            details={"fields": {"accept_terms": not payload.accept_terms, "accept_privacy": not payload.accept_privacy}},
        )
    mode = get_setting(db, "registration.mode", settings.registration_mode)
    if mode == "closed":
        raise ValidationError("Registration is currently closed on this platform.")
    invitation = None
    if mode == "invite_only":
        if not payload.invitation_token:
            raise ValidationError("This platform is invitation-only: an invitation token is required.")
        invitation = _consume_invitation(db, payload.invitation_token)

    email = payload.email.lower().strip()
    if db.scalars(select(User).where(User.email == email)).first() is not None:
        raise Conflict("An account with this email address already exists.")
    errors = password_policy_errors(payload.password, email=email, name=payload.display_name)
    if errors:
        raise ValidationError(" ".join(errors), details={"fields": {"password": errors}})

    email_configured = email_service.is_configured()
    requires_verification = bool(email_configured and settings.require_email_verification)
    user = User(
        email=email,
        display_name=payload.display_name.strip()[:120],
        password_hash=hash_password(payload.password),
        status=AccountStatus.PENDING if requires_verification else AccountStatus.ACTIVE,
        email_verified=not requires_verification,
        email_verified_at=None if requires_verification else dt.datetime.now(dt.timezone.utc),
        locale=(payload.locale or "fa")[:12],
        company=payload.company,
        accepted_terms_version=str(get_setting(db, "registration.require_terms_version", "2026-01")),
        accepted_terms_at=dt.datetime.now(dt.timezone.utc),
        accepted_privacy_version=str(get_setting(db, "registration.privacy_version", "2026-01")),
        accepted_privacy_at=dt.datetime.now(dt.timezone.utc),
        password_changed_at=dt.datetime.now(dt.timezone.utc),
    )
    db.add(user)
    db.flush()
    user_role = db.scalars(select(Role).where(Role.slug == "user")).first()
    if user_role is not None:
        user.roles.append(user_role)
    ledger_service.get_account(db, user.id)

    trial = int(get_setting(db, "registration.free_trial_credit_micro", settings.free_trial_credit_micro) or 0)
    if trial > 0:
        ledger_service.credit(
            db,
            user_id=user.id,
            amount_micro=trial,
            entry_type="promotional",
            idempotency_key=f"signup-trial:{user.id}",
            description="Welcome credit granted at registration",
            reference_type="promotion",
        )
    audit_service.record_audit(
        db, action="auth.register", summary=f"Account registered for {email}.", actor=user, entity_type="user",
        entity_id=user.id, ip_address=client.ip, user_agent=client.user_agent,
    )
    audit_service.record_activity(db, user=user, event="register", description="Account created",
                                  ip_address=client.ip, user_agent=client.user_agent)
    if invitation:
        audit_service.record_audit(
            db, action="user.created", summary=f"Invitation token used by {email}.", actor=user, entity_type="user",
            entity_id=user.id,
        )
    db.commit()

    verification_sent = False
    if requires_verification:
        verification_sent = email_service.send_verification_email(db, user=user)
    return {
        "message": (
            "Account created. Check your email to verify your address before signing in."
            if requires_verification
            else "Account created successfully."
        ),
        "user": _user_payload(user),
        "verification_email_sent": verification_sent,
        "verification_required": requires_verification,
        "email_delivery_configured": email_configured,
    }


def _consume_invitation(db, token: str) -> bool:  # noqa: ANN001
    from app.models.admin import AuditEvent

    fingerprint = hash_session_token(token)[:32]
    event = db.scalars(
        select(AuditEvent).where(AuditEvent.action == "user.created", AuditEvent.entity_type == "invitation",
                                 AuditEvent.entity_id == fingerprint)
    ).first()
    if event is None:
        raise ValidationError("This invitation token is not valid.")
    if event.created_at and event.created_at < dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=14):
        raise ValidationError("This invitation token has expired.")
    event.summary = f"{event.summary} [USED]"
    db.flush()
    return True


@router.post("/login")
def login(payload: LoginRequest, request: Request, response: Response, db: DbDep, client: Client) -> dict[str, Any]:
    ip_key = f"login:{payload.email.lower()}:{client.ip}"
    limiter.check(rate_limit_key(request, "login", payload.email.lower()), settings.auth_rate_limit_per_minute, 60)
    limiter.check(ip_key, settings.auth_rate_limit_per_minute * 3, 60)

    user = db.scalars(select(User).where(User.email == payload.email.lower().strip())).first()
    now = dt.datetime.now(dt.timezone.utc)
    generic_error = AuthError("Incorrect email or password.")
    if user is None:
        audit_service.record_audit(db, action="auth.login_failed", summary=f"Login attempt for unknown email {payload.email}.",
                                   entity_type="user", ip_address=client.ip, user_agent=client.user_agent, commit=True)
        raise generic_error
    if user.locked_until and user.locked_until > now:
        raise AuthError(
            f"Account temporarily locked after repeated failed sign-ins. Try again after {user.locked_until:%H:%M} UTC.",
            details={"locked_until": user.locked_until.isoformat()},
        )
    if not verify_password(payload.password, user.password_hash):
        user.failed_login_count = (user.failed_login_count or 0) + 1
        if user.failed_login_count >= settings.lockout_threshold:
            user.locked_until = now + dt.timedelta(minutes=settings.lockout_minutes)
            user.failed_login_count = 0
        audit_service.record_audit(
            db, action="auth.login_failed", summary=f"Failed sign-in for {user.email} (attempt {user.failed_login_count}).",
            entity_type="user", entity_id=user.id, ip_address=client.ip, user_agent=client.user_agent,
        )
        db.commit()
        raise generic_error
    if user.status == AccountStatus.SUSPENDED:
        raise AuthError("This account is suspended. Contact platform support.", details={"status": "suspended"})
    if user.status == AccountStatus.PENDING:
        raise AuthError(
            "Your email address is not verified yet.",
            details={"status": "pending_verification", "hint": "Resend the verification email from the sign-in screen."},
        )
    if user.status in (AccountStatus.DEACTIVATED, AccountStatus.DELETED) or user.deleted_at is not None:
        raise AuthError("This account is not active.")
    if user.expires_at and user.expires_at < now:
        raise AuthError("This test account has expired.", details={"expires_at": user.expires_at.isoformat()})

    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(payload.password)
    user.failed_login_count = 0
    user.locked_until = None
    user.last_login_at = now
    user.last_login_ip = client.ip

    session_token = generate_session_token()
    csrf = generate_csrf_token()
    ttl = dt.timedelta(hours=settings.session_ttl_hours if payload.remember else 12)
    session = UserSession(
        user_id=user.id,
        token_hash=hash_session_token(session_token),
        csrf_token=csrf,
        user_agent=(client.user_agent or "")[:400],
        ip_address=client.ip,
        expires_at=now + ttl,
    )
    db.add(session)
    audit_service.record_audit(
        db, action="auth.login", summary=f"{user.email} signed in.", actor=user, entity_type="session",
        ip_address=client.ip, user_agent=client.user_agent,
    )
    audit_service.record_activity(db, user=user, event="login", description="Signed in", ip_address=client.ip,
                                  user_agent=client.user_agent)
    db.commit()

    set_session_cookies(response, token=session_token, csrf=csrf, max_age=int(ttl.total_seconds()))
    return {
        "user": _user_payload(user),
        "session": {"id": session.id, "expires_at": session.expires_at},
        "csrf_token": csrf,
        "must_change_password": user.must_change_password,
    }


@router.post("/logout", response_model=MessageResponse)
def logout(request: Request, response: Response, db: DbDep, user: OptionalUser) -> MessageResponse:
    token = request.cookies.get(SESSION_COOKIE)
    if token:
        session = db.scalars(select(UserSession).where(UserSession.token_hash == hash_session_token(token))).first()
        if session is not None:
            session.revoked_at = dt.datetime.now(dt.timezone.utc)
            session.revoked_reason = "user_logout"
    if user is not None:
        audit_service.record_audit(db, action="auth.logout", summary=f"{user.email} signed out.", actor=user, entity_type="session")
    db.commit()
    clear_session_cookies(response)
    return MessageResponse(message="Signed out.")


@router.get("/me")
def me(user: CurrentUser, db: DbDep) -> dict[str, Any]:
    account = ledger_service.get_account(db, user.id)
    subscription = access_service.active_subscription(db, user)
    return {
        "user": _user_payload(user),
        "account": {
            "balance_micro": account.balance_micro if account else 0,
            "currency": account.currency if account else settings.default_currency,
            "daily_spend_limit_micro": account.daily_spend_limit_micro if account else None,
            "monthly_spend_limit_micro": account.monthly_spend_limit_micro if account else None,
            "is_frozen": account.is_frozen if account else False,
        },
        "subscription": (
            {
                "id": subscription.id,
                "plan": subscription.plan.name,
                "plan_slug": subscription.plan.slug,
                "status": subscription.status,
                "current_period_end": subscription.current_period_end,
            }
            if subscription
            else None
        ),
        "permissions": sorted(access_service.user_permissions(user)),
        "theme": user.theme,
        "locale": user.locale,
    }


@router.patch("/me")
def update_me(payload: ProfileUpdateRequest, db: DbDep, user: CurrentUser) -> dict[str, Any]:
    before = {"display_name": user.display_name, "locale": user.locale, "theme": user.theme, "enhanced_theme": user.enhanced_theme}
    if payload.display_name is not None:
        user.display_name = payload.display_name.strip()[:120]
    if payload.phone is not None:
        user.phone = payload.phone[:32]
    if payload.company is not None:
        user.company = payload.company[:160]
    if payload.locale in {"fa", "en", "ar", "ckb"}:
        user.locale = payload.locale
    if payload.theme in {"light", "dark", "system"}:
        user.theme = payload.theme
    if payload.enhanced_theme is not None:
        user.enhanced_theme = payload.enhanced_theme
    if payload.timezone:
        user.timezone = payload.timezone[:64]
    db.commit()
    audit_service.record_activity(db, user=user, event="profile_updated", description="Profile updated")
    db.commit()
    return {"user": _user_payload(user), "changed": before}


@router.post("/password")
def change_password(payload: PasswordChangeRequest, request: Request, db: DbDep, user: CurrentUser, client: Client) -> dict[str, Any]:
    if not verify_password(payload.current_password, user.password_hash):
        raise AuthError("The current password is incorrect.")
    errors = password_policy_errors(payload.new_password, email=user.email, name=user.display_name)
    if errors:
        raise ValidationError(" ".join(errors), details={"fields": {"new_password": errors}})
    if verify_password(payload.new_password, user.password_hash):
        raise ValidationError("The new password must differ from the current password.")
    user.password_hash = hash_password(payload.new_password)
    user.password_changed_at = dt.datetime.now(dt.timezone.utc)
    user.must_change_password = False
    # revoke every other session after a password change; only the session that
    # made this request survives (identified by its cookie token hash).
    current_hash = hash_session_token(request.cookies.get(SESSION_COOKIE) or "")
    kept_session: UserSession | None = None
    revoked_count = 0
    for session in db.scalars(select(UserSession).where(UserSession.user_id == user.id, UserSession.revoked_at.is_(None))).all():
        if current_hash and session.token_hash == current_hash:
            kept_session = session
            continue
        session.revoked_at = dt.datetime.now(dt.timezone.utc)
        session.revoked_reason = "password_changed"
        revoked_count += 1
    audit_service.record_audit(db, action="auth.password_reset_completed", summary="Password changed by the user.",
                               actor=user, entity_type="user", entity_id=user.id, severity="warning")
    audit_service.record_activity(db, user=user, event="password_changed", description="Password changed", ip_address=client.ip)
    db.commit()
    return {
        "message": f"Password updated. {revoked_count} other session(s) were signed out.",
        "sessions_revoked": revoked_count,
        "kept_session_id": kept_session.id if kept_session else None,
    }


@router.post("/password/reset-request", response_model=MessageResponse)
def request_password_reset(payload: PasswordResetRequest, request: Request, db: DbDep, client: Client) -> MessageResponse:
    limiter.check(rate_limit_key(request, "reset", payload.email.lower()), max(3, settings.auth_rate_limit_per_minute // 2), 60)
    user = db.scalars(select(User).where(User.email == payload.email.lower().strip())).first()
    if user is not None:
        token = create_action_token(str(user.id), "password_reset", ttl_minutes=30)
        sent = email_service.send_password_reset_email(db, user=user, token=token)
        audit_service.record_audit(db, action="auth.password_reset_requested", summary=f"Password reset requested for {user.email}.",
                                   entity_type="user", entity_id=user.id, ip_address=client.ip, commit=True)
        return MessageResponse(
            message=(
                "If that email exists, a reset link has been sent."
                if sent
                else "Email delivery is not configured on this platform, so no reset email could be sent. "
                     "Ask an administrator to reset your password from the admin console."
            )
        )
    return MessageResponse(message="If that email exists, a reset link has been sent.")


@router.post("/password/reset", response_model=MessageResponse)
def confirm_password_reset(payload: PasswordResetConfirm, db: DbDep, client: Client) -> MessageResponse:
    import jwt

    try:
        data = decode_action_token(payload.token, "password_reset")
    except jwt.ExpiredSignatureError as exc:
        raise ValidationError("This password reset link has expired. Request a new one.") from exc
    except jwt.InvalidTokenError as exc:
        raise ValidationError("This password reset link is not valid.") from exc
    user = db.get(User, int(data["sub"]))
    if user is None or user.deleted_at is not None:
        raise NotFound("Account not found.")
    errors = password_policy_errors(payload.new_password, email=user.email, name=user.display_name)
    if errors:
        raise ValidationError(" ".join(errors), details={"fields": {"new_password": errors}})
    user.password_hash = hash_password(payload.new_password)
    user.password_changed_at = dt.datetime.now(dt.timezone.utc)
    user.failed_login_count = 0
    user.locked_until = None
    if user.status == AccountStatus.PENDING:
        user.status = AccountStatus.ACTIVE
        user.email_verified = True
        user.email_verified_at = dt.datetime.now(dt.timezone.utc)
    for session in db.scalars(select(UserSession).where(UserSession.user_id == user.id, UserSession.revoked_at.is_(None))).all():
        session.revoked_at = dt.datetime.now(dt.timezone.utc)
        session.revoked_reason = "password_reset"
    audit_service.record_audit(db, action="auth.password_reset_completed", summary="Password reset completed via email token.",
                               actor=user, entity_type="user", entity_id=user.id, severity="warning", ip_address=client.ip)
    db.commit()
    return MessageResponse(message="Password updated. All sessions were signed out.")


@router.post("/email/verify-request", response_model=MessageResponse)
def request_email_verification(db: DbDep, user: CurrentUser) -> MessageResponse:
    if user.email_verified:
        return MessageResponse(message="Your email address is already verified.")
    if not email_service.is_configured():
        raise ValidationError(
            "Email delivery is not configured on this platform, so verification emails cannot be sent. "
            "Ask an administrator to verify your account."
        )
    sent = email_service.send_verification_email(db, user=user)
    return MessageResponse(message="Verification email sent." if sent else "The verification email could not be sent; check the mail configuration.")


@router.post("/email/verify", response_model=MessageResponse)
def verify_email(token: str, db: DbDep) -> MessageResponse:
    import jwt

    try:
        data = decode_action_token(token, "email_verify")
    except jwt.InvalidTokenError as exc:
        raise ValidationError("This verification link is not valid or has expired.") from exc
    user = db.get(User, int(data["sub"]))
    if user is None:
        raise NotFound("Account not found.")
    user.email_verified = True
    user.email_verified_at = dt.datetime.now(dt.timezone.utc)
    if user.status == AccountStatus.PENDING:
        user.status = AccountStatus.ACTIVE
    audit_service.record_audit(db, action="auth.email_verified", summary=f"Email verified for {user.email}.", actor=user,
                               entity_type="user", entity_id=user.id)
    db.commit()
    return MessageResponse(message="Email address verified. You can sign in now.")


@router.get("/sessions")
def list_sessions(request: Request, db: DbDep, user: CurrentUser) -> dict[str, Any]:
    token = request.cookies.get(SESSION_COOKIE)
    current_hash = hash_session_token(token) if token else ""
    sessions = db.scalars(
        select(UserSession).where(UserSession.user_id == user.id).order_by(UserSession.created_at.desc()).limit(100)
    ).all()
    return {
        "items": [
            {
                "id": s.id,
                "current": s.token_hash == current_hash,
                "user_agent": s.user_agent,
                "ip_address": s.ip_address,
                "created_at": s.created_at,
                "last_seen_at": s.last_seen_at,
                "expires_at": s.expires_at,
                "revoked_at": s.revoked_at,
                "revoked_reason": s.revoked_reason,
                "active": s.is_valid(),
            }
            for s in sessions
        ]
    }


@router.delete("/sessions/{session_id}", response_model=MessageResponse)
def revoke_session(session_id: int, request: Request, db: DbDep, user: CurrentUser) -> MessageResponse:
    session = db.get(UserSession, session_id)
    if session is None or session.user_id != user.id:
        raise NotFound("Session not found.")
    session.revoked_at = dt.datetime.now(dt.timezone.utc)
    session.revoked_reason = "revoked_by_user"
    audit_service.record_audit(db, action="auth.session_revoked", summary=f"Session {session_id} revoked.", actor=user,
                               entity_type="session", entity_id=session_id)
    db.commit()
    return MessageResponse(message="Session revoked.")


@router.delete("/sessions", response_model=MessageResponse)
def revoke_all_sessions(request: Request, db: DbDep, user: CurrentUser) -> MessageResponse:
    token = request.cookies.get(SESSION_COOKIE)
    current_hash = hash_session_token(token) if token else ""
    revoked = 0
    for session in db.scalars(select(UserSession).where(UserSession.user_id == user.id, UserSession.revoked_at.is_(None))).all():
        if session.token_hash == current_hash:
            continue
        session.revoked_at = dt.datetime.now(dt.timezone.utc)
        session.revoked_reason = "revoked_all"
        revoked += 1
    audit_service.record_audit(db, action="auth.session_revoked", summary=f"{revoked} session(s) revoked (all but current).",
                               actor=user, entity_type="user", entity_id=user.id)
    db.commit()
    return MessageResponse(message=f"{revoked} other session(s) revoked.")


@router.get("/activity")
def my_activity(db: DbDep, user: CurrentUser, limit: int = 50) -> dict[str, Any]:
    from app.models.user import UserActivity

    rows = db.scalars(
        select(UserActivity).where(UserActivity.user_id == user.id).order_by(UserActivity.created_at.desc()).limit(min(limit, 200))
    ).all()
    return {
        "items": [
            {"id": r.id, "event": r.event, "description": r.description, "ip_address": r.ip_address, "created_at": r.created_at}
            for r in rows
        ]
    }
