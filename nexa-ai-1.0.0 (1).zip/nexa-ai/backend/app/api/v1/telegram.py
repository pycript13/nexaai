"""Telegram endpoints: account linking (user), bot status (admin) and the webhook."""
from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Depends, Header, Request
from sqlalchemy.orm import Session

from app.api.deps import CurrentUser, DbDep, User, require_permission
from app.core.config import settings
from app.core.errors import AuthError, PermissionDenied, ValidationError
from app.core.logging import get_logger
from app.services import telegram as telegram_service

log = get_logger(__name__)
router = APIRouter(prefix="/telegram", tags=["telegram"])
admin_router = APIRouter(prefix="/admin/telegram", tags=["admin:telegram"])


# ------------------------------------------------------------------ user side -----
@router.get("/status")
def link_status(db: DbDep, user: CurrentUser) -> dict[str, Any]:
    """Is this account linked to a Telegram chat, and is the bot configured at all?"""
    return telegram_service.link_status(db, user=user)


@router.post("/link-code", status_code=201)
def create_link_code(db: DbDep, user: CurrentUser) -> dict[str, Any]:
    """Create a single-use, short-lived code and the t.me deep link that carries it."""
    if not telegram_service.is_configured():
        raise ValidationError(
            "The Telegram bot is not configured on this server yet. An administrator must set "
            "NEXA_TELEGRAM_ENABLED=true and NEXA_TELEGRAM_BOT_TOKEN, then restart the services.",
            details={"reason": "telegram_not_configured"},
        )
    return telegram_service.create_link_code(db, user=user)


@router.delete("/link")
def unlink(db: DbDep, user: CurrentUser) -> dict[str, Any]:
    """Disconnect this account from Telegram (the bot immediately stops acting for it)."""
    return telegram_service.unlink(db, user=user)


# ------------------------------------------------------------------ admin side ----
@admin_router.get("/status")
def admin_status(
    db: DbDep,
    # `settings.manage` — the permission that actually exists in the catalogue. This endpoint used
    # to require `settings.read`, which is defined nowhere, so `has_permission` was false for every
    # account including the super admin: the Telegram status screen could never load for anyone.
    actor: Annotated[User, Depends(require_permission("settings.manage"))],
) -> dict[str, Any]:
    from sqlalchemy import func, select

    from app.models.telegram import TelegramLink
    from app.models.user import User as UserModel

    total = db.scalar(select(func.count(TelegramLink.id))) or 0
    active = db.scalar(select(func.count(TelegramLink.id)).where(TelegramLink.enabled.is_(True))) or 0
    messages = db.scalar(select(func.coalesce(func.sum(TelegramLink.message_count), 0))) or 0
    recent = db.scalars(select(TelegramLink).order_by(TelegramLink.id.desc()).limit(10)).all()
    return {
        "enabled": settings.telegram_enabled,
        "configured": telegram_service.is_configured(),
        "mode": settings.telegram_mode,
        "bot_username": settings.telegram_bot_username or None,
        "api_base": telegram_service.api_base(),
        "webhook_secret_set": bool(settings.telegram_webhook_secret),
        "linked_accounts": int(total),
        "enabled_links": int(active),
        "messages_handled": int(messages),
        "recent": [
            {
                "user_id": link.user_id,
                "email": (db.get(UserModel, link.user_id).email if db.get(UserModel, link.user_id) else None),
                "telegram_username": link.telegram_username,
                "enabled": link.enabled,
                "message_count": link.message_count,
                "linked_at": link.linked_at,
                "last_message_at": link.last_message_at,
            }
            for link in recent
        ],
    }


@admin_router.post("/test")
async def admin_test(
    actor: Annotated[User, Depends(require_permission("settings.manage"))],
) -> dict[str, Any]:
    """Call getMe — the only honest way to say "the token works"."""
    if not telegram_service.is_configured():
        raise ValidationError(
            "The bot is not configured: set NEXA_TELEGRAM_ENABLED=true and NEXA_TELEGRAM_BOT_TOKEN.",
            details={"reason": "telegram_not_configured"},
        )
    me = await telegram_service.get_me()
    username = me.get("username") or ""
    result: dict[str, Any] = {
        "ok": True,
        "bot": {
            "id": me.get("id"),
            "username": me.get("username"),
            "first_name": me.get("first_name"),
            "can_join_groups": me.get("can_join_groups"),
            "can_read_all_group_messages": me.get("can_read_all_group_messages"),
        },
        "note": "If can_read_all_group_messages is false the bot answers direct messages only — that is the "
                "intended privacy-friendly default.",
    }
    if username and not settings.telegram_bot_username:
        # The token resolves the username every time, so the operator can be told the exact value to
        # put in .env instead of leaving deep links (t.me/…) unbuildable without saying why.
        result["configuration_hint"] = (
            f"Set NEXA_TELEGRAM_BOT_USERNAME={username} in the environment file and restart so the "
            "platform can build t.me deep links and show the bot name in the admin panel."
        )
    return result


@admin_router.post("/webhook")
async def admin_set_webhook(
    payload: dict[str, Any],
    actor: Annotated[User, Depends(require_permission("settings.manage"))],
) -> dict[str, Any]:
    """Register the production webhook (https://<your-domain>/api/v1/telegram/webhook)."""
    url = str(payload.get("url") or "").strip()
    if not url.startswith("https://"):
        raise ValidationError("Telegram requires an HTTPS webhook URL.")
    result = await telegram_service.set_webhook(url)
    return {"ok": True, "result": result}


# ------------------------------------------------------------------ webhook ------
@router.post("/webhook")
async def webhook(
    request: Request,
    db: DbDep,
    x_telegram_bot_api_secret_token: Annotated[str | None, Header()] = None,
) -> dict[str, Any]:
    """Receive updates from Telegram when the deployment uses webhook mode.

    Telegram sends the secret it was registered with in the
    ``X-Telegram-Bot-Api-Secret-Token`` header; without it anyone could post fake updates.
    """
    if not telegram_service.is_configured():
        raise ValidationError("The Telegram bot is not configured.", details={"reason": "telegram_not_configured"})
    if settings.telegram_webhook_secret:
        if x_telegram_bot_api_secret_token != settings.telegram_webhook_secret:
            raise AuthError("Invalid Telegram webhook secret.")
    try:
        update = await request.json()
    except Exception as exc:  # noqa: BLE001
        raise ValidationError("The webhook body is not valid JSON.") from exc
    if not isinstance(update, dict):
        raise PermissionDenied("Malformed update.")
    result = await telegram_service.handle_update(db, update)
    return {"ok": True, "handled": result}
