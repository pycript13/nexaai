"""Cryptographic helpers: password hashing + provider-secret encryption.

* Passwords: Argon2id (via argon2-cffi). Parameters are read from the library
  defaults which follow the OWASP guidance for interactive logins.
* Provider secrets: symmetric Fernet (AES-128-CBC + HMAC-SHA256) with a key
  that lives *outside* the database (NEXA_ENCRYPTION_KEY). Only masked
  representations are ever sent back to the UI.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
from functools import lru_cache

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerifyMismatchError
from argon2.low_level import Type, hash_secret_raw
from cryptography.fernet import Fernet, InvalidToken

from app.core.config import settings

_hasher = PasswordHasher(time_cost=3, memory_cost=64 * 1024, parallelism=2, hash_len=32, salt_len=16)

MIN_PASSWORD_LENGTH = settings.password_min_length
COMMON_PASSWORDS = {
    "password", "password1", "12345678", "123456789", "1234567890", "qwerty123", "letmein",
    "admin123", "administrator", "welcome1", "iloveyou", "changeme", "nexa1234", "passw0rd",
    "qwertyuiop", "1q2w3e4r", "abc12345", "password123",
}


# --- passwords --------------------------------------------------------------
def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(password: str, hashed: str) -> bool:
    try:
        return _hasher.verify(hashed, password)
    except (VerifyMismatchError, InvalidHashError, Exception):
        return False


def needs_rehash(hashed: str) -> bool:
    try:
        return _hasher.check_needs_rehash(hashed)
    except Exception:
        return False


# Reserved/special-use names that e-mail validation rejects (RFC 2606/6761 + the pydantic rule the
# API already applies through `EmailStr`). The operational CLI used to accept them, so an operator
# could bootstrap an administrator whose address the *sign-in endpoint* refuses (live case:
# `admin@nexa.test` → HTTP 422 "special-use or reserved name"), leaving a login nobody could use.
_RESERVED_DOMAINS = (
    ".test", ".invalid", ".local", ".localhost", ".example", ".internal", ".home.arpa",
)
_RESERVED_NAMES = {"example.com", "example.net", "example.org", "localhost", "test", "invalid"}


def email_policy_errors(email: str | None) -> list[str]:
    """Return human-readable reason(s) an address cannot be used for sign-in ([] == acceptable).

    Uses the same validator the API's request schemas use (`pydantic.EmailStr`), so the CLI and the
    HTTP layer can never disagree about which addresses are usable.
    """
    value = (email or "").strip()
    if not value:
        return ["An e-mail address is required."]
    try:
        from pydantic import EmailStr, TypeAdapter

        TypeAdapter(EmailStr).validate_python(value)
    except Exception as exc:  # noqa: BLE001 - the message is what matters here
        reason = str(exc).splitlines()
        detail = reason[-1] if reason else "the address is not acceptable"
        lowered = value.lower()
        domain = lowered.rsplit("@", 1)[-1]
        if domain in _RESERVED_NAMES or lowered.endswith(_RESERVED_DOMAINS):
            detail = "reserved example/placeholder domains cannot be used for sign-in"
        return [f"'{value}' is not a valid e-mail address for sign-in: {detail}.",
                "Use a real mailbox (e.g. you@your-domain.com) — the sign-in endpoint applies the "
                "same rule, so an account created with a reserved domain could never log in."]
    return []


def password_policy_errors(password: str, *, email: str | None = None, name: str | None = None) -> list[str]:
    """Return human-readable policy violations (empty list == acceptable)."""
    errors: list[str] = []
    if len(password) < MIN_PASSWORD_LENGTH:
        errors.append(f"Password must be at least {MIN_PASSWORD_LENGTH} characters long.")
    if len(password) > 256:
        errors.append("Password must be at most 256 characters long.")
    if password.lower() in COMMON_PASSWORDS:
        errors.append("This password is too common; choose something less predictable.")
    if password.isdigit() or password.isalpha():
        errors.append("Password must mix letters, digits or symbols (not only one character class).")
    if email and password.lower() == email.lower():
        errors.append("Password must not be the same as the email address.")
    if name and password.lower() == name.lower():
        errors.append("Password must not be the same as your display name.")
    return errors


# --- provider secret encryption --------------------------------------------
def generate_encryption_key() -> str:
    return Fernet.generate_key().decode()


def _derive_key_from_secret(secret: str) -> bytes:
    digest = hashlib.sha256(f"nexa-provider-secrets::{secret}".encode()).digest()
    return base64.urlsafe_b64encode(digest)


def is_placeholder_key(value: str | None) -> bool:
    if not value:
        return True
    return "CHANGE_ME" in value.upper() or len(value.strip()) != 44


@lru_cache
def _fernet() -> Fernet:
    key = settings.encryption_key.strip()
    if is_placeholder_key(key):
        if settings.is_production:
            raise RuntimeError(
                "NEXA_ENCRYPTION_KEY is not set (or is still the template placeholder). Provider "
                "credentials cannot be stored safely. Generate one with: python -c \"from cryptography.fernet "
                "import Fernet;print(Fernet.generate_key().decode())\" then set NEXA_ENCRYPTION_KEY in .env."
            )
        # Development-only derivation so that local runs work without setup.
        key = _derive_key_from_secret(settings.secret_key).decode()
    try:
        return Fernet(key.encode())
    except Exception as exc:  # pragma: no cover - operator error
        raise RuntimeError("NEXA_ENCRYPTION_KEY is not a valid Fernet key (44 char urlsafe base64).") from exc


def encrypt_secret(plaintext: str) -> str:
    if plaintext is None:
        plaintext = ""
    return _fernet().encrypt(plaintext.encode()).decode()


def decrypt_secret(ciphertext: str | None) -> str:
    if not ciphertext:
        return ""
    try:
        return _fernet().decrypt(ciphertext.encode()).decode()
    except InvalidToken as exc:
        raise RuntimeError(
            "Stored provider secret could not be decrypted — NEXA_ENCRYPTION_KEY changed. "
            "Re-save the provider credential under Admin → AI Infrastructure → Providers."
        ) from exc


def mask_secret(plaintext: str | None, *, visible_tail: int = 4) -> str:
    """Return a display-safe mask, e.g. ``sk-…f3a9``. Never returns the full key."""
    if not plaintext:
        return ""
    tail = plaintext[-visible_tail:] if len(plaintext) > visible_tail else ""
    head = plaintext[:3]
    return f"{head}{'*' * 8}{tail}"


# --- misc -------------------------------------------------------------------
def token_fingerprint(token: str) -> str:
    return hmac.new(settings.secret_key.encode(), token.encode(), hashlib.sha256).hexdigest()


def compare_digest(a: str, b: str) -> bool:
    return hmac.compare_digest(a or "", b or "")


def random_token(nbytes: int = 32) -> str:
    return base64.urlsafe_b64encode(os.urandom(nbytes)).decode().rstrip("=")


def idempotency_hash(*parts: str) -> str:
    return hashlib.sha256("|".join(parts).encode()).hexdigest()
