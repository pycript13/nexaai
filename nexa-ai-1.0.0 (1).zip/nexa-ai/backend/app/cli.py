"""Operational CLI: bootstrap, create admin, grant credits, run jobs, diagnostics.

Usage (inside the backend container or a venv):
    python -m app.cli bootstrap
    python -m app.cli create-admin --email a@b.c --password '...' --name 'Admin'
    python -m app.cli reset-password --email a@b.c --password '...'   # recovery (revokes sessions)
    python -m app.cli grant-credits --email a@b.c --credits 25 --reason "tester top-up"
    python -m app.cli run-jobs --once
    python -m app.cli doctor
    python -m app.cli check-secrets    # can the stored provider credentials still be decrypted?
    python -m app.cli provider-check --provider <slug> [--model <provider-model-id>]
                                       # DNS -> TCP -> TLS -> /models -> chat -> stream, with the
                                       # provider's own error body. Use it when the connection test
                                       # is green but a model call fails.
"""
from __future__ import annotations

import argparse
import json
import os
import secrets
import string
import sys
from typing import Any

from app.core.config import settings
from app.core.crypto import password_policy_errors
from app.core.logging import configure_logging, get_logger
from app.db.session import SessionLocal, check_database
from app.services import jobs as job_service
from app.services import ledger as ledger_service
from app.services import pricing as pricing_service
from app.services.bootstrap import ensure_super_admin, run_bootstrap
from app.services.payments import expire_lapsed_subscriptions
from app.services.files import cleanup_expired
from sqlalchemy import select

log = get_logger("nexa.cli")


def _with_db():
    from contextlib import contextmanager

    @contextmanager
    def ctx():
        db = SessionLocal()
        try:
            yield db
        finally:
            db.close()

    return ctx()


def cmd_bootstrap(args: argparse.Namespace) -> int:
    with _with_db() as db:
        report = run_bootstrap(
            db, create_admin=not args.skip_admin,
            admin_email=args.admin_email or settings.bootstrap_admin_email,
            admin_password=args.admin_password or settings.bootstrap_admin_password,
            admin_name=args.admin_name or settings.bootstrap_admin_name,
        )
    print(json.dumps(report, indent=2, default=str))
    return 0


def cmd_create_admin(args: argparse.Namespace) -> int:
    # The password can arrive three ways, all with the same policy:
    #   --password VALUE            explicit (visible in the process list — fine for a local shell)
    #   NEXA_ADMIN_PASSWORD=VALUE   environment (used by deployment/windows/set_admin.bat: a
    #                               password on a command line is readable by every process owner)
    #   --generate                  no value at all: a strong one is created and printed once
    if not args.password and not getattr(args, "generate", False):
        env_password = os.getenv("NEXA_ADMIN_PASSWORD", "")
        if env_password:
            args.password = env_password
    generated = False
    if getattr(args, "generate", False) or not args.password:
        alphabet = string.ascii_letters + string.digits + "!@#%^&*-_"
        args.password = "".join(secrets.choice(alphabet) for _ in range(20)) + "Aa1"
        generated = True
    errors = password_policy_errors(args.password, email=args.email, name=args.name)
    if errors:
        print("Password rejected: " + "; ".join(errors), file=sys.stderr)
        return 2
    from sqlalchemy import select as _select

    from app.models.user import Role, User
    from app.core.crypto import hash_password
    import datetime as dt

    with _with_db() as db:
        existing = db.scalars(_select(User).where(User.email == args.email.lower())).first()
        if existing is not None:
            print(f"User {args.email} already exists (id={existing.id}).", file=sys.stderr)
            return 1
        user = User(
            email=args.email.lower(), display_name=args.name, password_hash=hash_password(args.password),
            status="active", email_verified=True, email_verified_at=dt.datetime.now(dt.timezone.utc),
            must_change_password=False, password_changed_at=dt.datetime.now(dt.timezone.utc),
        )
        db.add(user)
        db.flush()
        role = db.scalars(_select(Role).where(Role.slug == args.role)).first()
        if role is None:
            print(f"Role '{args.role}' not found — run `python -m app.cli bootstrap` first.", file=sys.stderr)
            return 1
        user.roles.append(role)
        ledger_service.get_account(db, user.id)
        db.commit()
        report = {"created": True, "user_id": user.id, "email": user.email, "role": role.slug}
        if generated:
            # printed exactly once: it is not stored anywhere in clear text
            report["generated_password"] = args.password
        print(json.dumps(report))
    return 0


def cmd_grant_credits(args: argparse.Namespace) -> int:
    from sqlalchemy import select as _select

    from app.models.user import User

    with _with_db() as db:
        user = db.scalars(_select(User).where(User.email == args.email.lower())).first()
        if user is None:
            print(f"User {args.email} not found.", file=sys.stderr)
            return 1
        amount = int(round(args.credits * 1_000_000))
        result = ledger_service.credit(
            db, user_id=user.id, amount_micro=amount, entry_type="admin_grant",
            idempotency_key=f"cli-grant:{user.id}:{amount}:{args.reason}", description=args.reason,
            reference_type="admin_grant",
        )
        db.commit()
        print(json.dumps({"user": user.email, "credited_micro": amount,
                          "balance_after": pricing_service.micro_to_display(result.balance_after_micro),
                          "created": result.created}))
    return 0


def cmd_reset_password(args: argparse.Namespace) -> int:
    """Set a new password for an existing account (recovery).

    Used by the installer when an .env was replaced, and by operators locked out of an
    account. The change is audited and every session of that user is revoked.
    """
    import datetime as dt
    import secrets
    import string

    from sqlalchemy import select as _select

    from app.core.crypto import hash_password
    from app.models.user import User, UserSession
    from app.services import audit as audit_service

    password = args.password
    generated = False
    if not password:
        alphabet = string.ascii_letters + string.digits
        password = "".join(secrets.choice(alphabet) for _ in range(20)) + "Aa1!"
        generated = True

    email = args.email.strip().lower()
    errors = password_policy_errors(password, email=email, name=email)
    if errors:
        print("Password rejected: " + "; ".join(errors), file=sys.stderr)
        return 2

    with _with_db() as db:
        user = db.scalars(_select(User).where(User.email == email)).first()
        if user is None:
            print(f"User {email} not found.", file=sys.stderr)
            return 1
        user.password_hash = hash_password(password)
        user.password_changed_at = dt.datetime.now(dt.timezone.utc)
        user.must_change_password = bool(args.must_change)
        user.failed_login_count = 0
        user.locked_until = None
        revoked = 0
        for session in db.scalars(
            _select(UserSession).where(UserSession.user_id == user.id, UserSession.revoked_at.is_(None))
        ).all():
            session.revoked_at = dt.datetime.now(dt.timezone.utc)
            session.revoked_reason = "password_reset"
            revoked += 1
        audit_service.record_audit(
            db,
            action="user.password_reset",
            summary=f"Password for {user.email} reset from the operational CLI.",
            entity_type="user",
            entity_id=user.id,
            severity="warning",
            after={"sessions_revoked": revoked, "must_change_password": bool(args.must_change)},
        )
        db.commit()
        payload = {
            "email": user.email,
            "user_id": user.id,
            "sessions_revoked": revoked,
            "must_change_password": bool(args.must_change),
        }
        if generated:
            payload["generated_password"] = password
        print(json.dumps(payload, indent=2))
    return 0


def cmd_run_jobs(args: argparse.Namespace) -> int:
    processed = 0
    while True:
        with _with_db() as db:
            job = job_service.run_once(db)
        if job is None:
            break
        processed += 1
        if args.once:
            break
    print(json.dumps({"processed": processed}))
    return 0


def cmd_maintenance(args: argparse.Namespace) -> int:
    with _with_db() as db:
        files = cleanup_expired(db)
        subs = expire_lapsed_subscriptions(db)
    print(json.dumps({**files, "subscriptions_expired": subs}))
    return 0


def cmd_doctor(args: argparse.Namespace) -> int:
    ok, detail = check_database()
    report: dict = {
        "environment": settings.environment,
        "deployment_mode": settings.deployment_mode,
        "database": {"ok": ok, "dialect": detail, "is_sqlite": settings.is_sqlite},
        "production_problems": settings.assert_production_ready(),
        "warnings": settings.deployment_warnings(),
        "encryption_key_set": bool(settings.encryption_key and "CHANGE_ME" not in settings.encryption_key),
        "email_configured": settings.email_enabled and bool(settings.smtp_host),
    }
    if ok:
        from sqlalchemy import func

        from app.models.provider import Model, Provider
        from app.models.user import User

        with _with_db() as db:
            report["counts"] = {
                "users": db.scalar(select(func.count(User.id))) or 0,
                "providers": db.scalar(select(func.count(Provider.id))) or 0,
                "models": db.scalar(select(func.count(Model.id))) or 0,
            }
            report["ledger"] = ledger_service.ledger_consistency_report(db, limit=200)
    print(json.dumps(report, indent=2, default=str))
    return 0 if ok and not settings.assert_production_ready() else (0 if ok else 1)


def cmd_check_secrets(args: argparse.Namespace) -> int:
    """Report whether stored provider credentials can still be decrypted.

    Rotating NEXA_ENCRYPTION_KEY (for example because the previous value was a placeholder)
    makes every existing ciphertext unreadable. The installer calls this so it can say so out
    loud instead of letting the operator discover it when a provider starts failing.
    """
    from app.core.crypto import decrypt_secret
    from app.models.provider import Provider

    report: dict = {"providers": 0, "credentials": 0, "readable": 0, "unreadable": 0, "details": []}
    with _with_db() as db:
        for provider in db.scalars(select(Provider).order_by(Provider.id)).all():
            report["providers"] += 1
            for label, ciphertext in (("api key", provider.api_key_encrypted), ("extra headers", provider.extra_headers_encrypted)):
                if not ciphertext:
                    continue
                report["credentials"] += 1
                try:
                    decrypt_secret(ciphertext)
                except Exception:
                    report["unreadable"] += 1
                    report["details"].append({"provider": provider.name, "slug": provider.slug, "field": label})
                else:
                    report["readable"] += 1
    print(json.dumps(report, indent=2))
    return 3 if report["unreadable"] else 0


def cmd_provider_check(args: argparse.Namespace) -> int:
    """Diagnose one provider step by step, with real network calls.

    Layer by layer so the failure can be located exactly: DNS resolution, TCP connect,
    the TLS handshake and certificate, the model list endpoint, a one-token chat call and
    the same call as a stream. Nothing is guessed and nothing is simulated: every step
    talks to the provider with the credentials stored in the database.

    The chat probes are made directly through the adapter, so they are *not* billed to any
    user and are *not* written to usage history. They do cost whatever the provider charges
    for a single one-token request.
    """
    import asyncio
    import socket
    import ssl as ssl_module
    import time
    from urllib.parse import urlsplit

    from app.core.errors import ProviderError
    from app.core.net import validate_outbound_url
    from app.models.provider import Model, Provider
    from app.providers.base import ChatMessage, ChatRequest
    from app.providers.registry import adapter_for_provider

    steps: list[dict] = []
    verdict = "unknown"

    def step(name: str, ok: bool, detail: str, **extra: Any) -> None:
        entry: dict[str, Any] = {"step": name, "ok": ok, "detail": detail}
        entry.update(extra)
        steps.append(entry)

    with _with_db() as db:
        query = select(Provider)
        if args.provider:
            query = query.where((Provider.slug == args.provider) | (Provider.id == _as_int(args.provider)))
        provider = db.scalars(query.order_by(Provider.id)).first()
        if provider is None:
            known = [row.slug for row in db.scalars(select(Provider).order_by(Provider.id)).all()]
            print(json.dumps({"error": f"provider '{args.provider}' not found", "providers": known}, indent=2))
            return 6

        info = {
            "id": provider.id,
            "slug": provider.slug,
            "name": provider.name,
            "type": provider.provider_type,
            "base_url": provider.base_url,
            "enabled": bool(provider.enabled),
            "api_key_hint": provider.api_key_hint,
            "has_credentials": bool(provider.api_key_encrypted),
            "connect_timeout": provider.connect_timeout,
            "read_timeout": provider.read_timeout,
            "max_retries": provider.max_retries,
            "proxy_url": provider.proxy_url,
            "last_test_status": provider.last_test_status,
            "last_test_message": provider.last_test_message,
            "last_sync_status": provider.last_sync_status,
            "last_sync_message": provider.last_sync_message,
            "last_error_category": provider.last_error_category,
        }

        # Provider model id for the chat probes: explicit flag, else the first synced model.
        model_rows = db.scalars(select(Model).where(Model.provider_id == provider.id).order_by(Model.id)).all()
        model_id = args.model or (model_rows[0].provider_model_id if model_rows else None)
        model_note = "from --model" if args.model else ("first synchronized model" if model_rows else "")

        # ---- outbound-policy check (no network) -----------------------------
        policy = validate_outbound_url(provider.base_url, purpose="provider base URL")
        step("policy", policy.ok, policy.reason or "allowed by the outbound policy")

        # ---- DNS / TCP / TLS --------------------------------------------------
        parts = urlsplit(provider.base_url)
        host = parts.hostname or ""
        scheme = parts.scheme or "https"
        port = parts.port or (443 if scheme == "https" else 80)

        async def network_layers() -> dict:
            loop = asyncio.get_running_loop()
            started = time.perf_counter()
            try:
                infos = await loop.getaddrinfo(host, port, type=socket.SOCK_STREAM)
                addresses = sorted({item[4][0] for item in infos})
            except Exception as exc:  # noqa: BLE001
                return {"dns_ok": False, "detail": f"{type(exc).__name__}: {exc}", "elapsed_ms": int((time.perf_counter() - started) * 1000)}
            dns_ms = int((time.perf_counter() - started) * 1000)

            started = time.perf_counter()
            context = ssl_module.create_default_context() if scheme == "https" else None
            try:
                reader, writer = await asyncio.wait_for(
                    asyncio.open_connection(host, port, ssl=context, server_hostname=host if context else None),
                    timeout=max(5.0, float(provider.connect_timeout or 10)),
                )
            except Exception as exc:  # noqa: BLE001
                return {
                    "dns_ok": True,
                    "addresses": addresses,
                    "dns_ms": dns_ms,
                    "tcp_ok": False,
                    "detail": f"{type(exc).__name__}: {exc}",
                    "elapsed_ms": int((time.perf_counter() - started) * 1000),
                }
            tcp_ms = int((time.perf_counter() - started) * 1000)
            tls_info = "plain HTTP"
            ssl_object = writer.get_extra_info("ssl_object")
            if ssl_object is not None:
                try:
                    cert = ssl_object.getpeercert() or {}
                    subject = dict(x[0] for x in cert.get("subject", ())).get("commonName", "?")
                    issuer = dict(x[0] for x in cert.get("issuer", ())).get("commonName", "?")
                    tls_info = f"{ssl_object.version()} {ssl_object.cipher()[0]} | cert CN={subject} issuer={issuer} valid until {cert.get('notAfter', '?')}"
                except Exception as exc:  # noqa: BLE001
                    tls_info = f"handshake ok, certificate details unavailable ({type(exc).__name__})"
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:  # noqa: BLE001
                pass
            return {
                "dns_ok": True,
                "addresses": addresses,
                "dns_ms": dns_ms,
                "tcp_ok": True,
                "tcp_ms": tcp_ms,
                "tls": tls_info,
                "elapsed_ms": int((time.perf_counter() - started) * 1000),
            }

        layers = asyncio.run(network_layers()) if host else {"dns_ok": False, "detail": "base URL has no host"}
        if not layers.get("dns_ok"):
            step("dns", False, layers.get("detail", "resolution failed"), elapsed_ms=layers.get("elapsed_ms"))
            verdict = "DNS: this server cannot resolve the provider host. Check the base URL and the server's DNS."
            print(json.dumps({"provider": info, "steps": steps, "verdict": verdict}, indent=2, default=str))
            return 2
        step("dns", True, f"{host} -> {', '.join(layers['addresses'])}", elapsed_ms=layers.get("dns_ms"))
        if not layers.get("tcp_ok"):
            step("tcp", False, layers.get("detail", "connect failed"), elapsed_ms=layers.get("elapsed_ms"))
            verdict = (
                "TCP/TLS: the provider host resolved but the connection could not be established. "
                "Typical causes: a firewall/security group on this server or at the provider, a proxy that is "
                "required but not configured, or TLS interception. The connection test and the chat call use the "
                "same transport, so check both again after fixing the network path."
            )
            print(json.dumps({"provider": info, "steps": steps, "verdict": verdict}, indent=2, default=str))
            return 2
        step("tcp", True, f"connected to {host}:{port}", elapsed_ms=layers.get("tcp_ms"))
        step("tls", True, layers.get("tls", ""), )

        # ---- model list ------------------------------------------------------
        if not provider.enabled:
            step("models", False, "provider is disabled — enable it to run the model probes")
            verdict = "The provider is disabled. Enable it in Admin -> Providers and run this again."
            print(json.dumps({"provider": info, "steps": steps, "verdict": verdict}, indent=2, default=str))
            return 4

        async def probes() -> list[dict]:
            results: list[dict] = []
            try:
                adapter = adapter_for_provider(provider, require_key=True)
            except Exception as exc:  # noqa: BLE001
                results.append({"step": "adapter", "ok": False, "detail": f"{type(exc).__name__}: {exc}"})
                return results

            started = time.perf_counter()
            try:
                models = await adapter.list_models()
            except ProviderError as error:
                results.append({
                    "step": "models", "ok": False, "detail": error.detail, "category": error.category,
                    "details": error.details, "elapsed_ms": int((time.perf_counter() - started) * 1000),
                })
            except Exception as exc:  # noqa: BLE001
                results.append({"step": "models", "ok": False, "detail": f"{type(exc).__name__}: {exc}",
                                "elapsed_ms": int((time.perf_counter() - started) * 1000)})
            else:
                results.append({
                    "step": "models", "ok": True,
                    "detail": f"{len(models)} models visible at the provider",
                    "sample": [m.get("provider_model_id") for m in models[:5]],
                    "elapsed_ms": int((time.perf_counter() - started) * 1000),
                })

            if not model_id:
                results.append({
                    "step": "chat", "ok": False,
                    "detail": "no synchronized model to call — run 'Synchronize models' or pass --model <provider-model-id>",
                })
                return results

            request = ChatRequest(
                model=model_id,
                messages=[ChatMessage(role="user", content="Reply with the single word: pong")],
                max_tokens=8,
                temperature=0.0,
            )

            started = time.perf_counter()
            try:
                response = await adapter.chat(request)
            except ProviderError as error:
                results.append({
                    "step": "chat", "ok": False, "detail": error.detail, "category": error.category,
                    "details": error.details, "model": model_id,
                    "elapsed_ms": int((time.perf_counter() - started) * 1000),
                })
            except Exception as exc:  # noqa: BLE001
                results.append({"step": "chat", "ok": False, "detail": f"{type(exc).__name__}: {exc}", "model": model_id,
                                "elapsed_ms": int((time.perf_counter() - started) * 1000)})
            else:
                text = (response.text or "").strip()
                results.append({
                    "step": "chat", "ok": True, "model": model_id,
                    "detail": f"answered in {int((time.perf_counter() - started) * 1000)} ms: {text[:120]!r}",
                    "usage": {
                        "prompt_tokens": response.prompt_tokens,
                        "completion_tokens": response.completion_tokens,
                        "usage_source": response.usage_source,
                        "provider_request_id": response.provider_request_id,
                    },
                    "elapsed_ms": int((time.perf_counter() - started) * 1000),
                })

            started = time.perf_counter()
            chunks = 0
            text_parts: list[str] = []
            try:
                async for chunk in adapter.stream_chat(request):
                    chunks += 1
                    if chunk.delta:
                        text_parts.append(chunk.delta)
                    if chunks >= 200:  # safety stop
                        break
            except ProviderError as error:
                results.append({
                    "step": "chat_stream", "ok": False, "detail": error.detail, "category": error.category,
                    "details": error.details, "model": model_id, "chunks_received": chunks,
                    "elapsed_ms": int((time.perf_counter() - started) * 1000),
                })
            except Exception as exc:  # noqa: BLE001
                results.append({"step": "chat_stream", "ok": False, "detail": f"{type(exc).__name__}: {exc}",
                                "model": model_id, "chunks_received": chunks,
                                "elapsed_ms": int((time.perf_counter() - started) * 1000)})
            else:
                results.append({
                    "step": "chat_stream", "ok": True, "model": model_id,
                    "detail": f"{chunks} chunks, text={'yes' if text_parts else 'no'}: {''.join(text_parts)[:120]!r}",
                    "elapsed_ms": int((time.perf_counter() - started) * 1000),
                })
            return results

        if getattr(args, "skip_chat", False):
            step("probes", True, "skipped (--skip-chat)")
        else:
            for entry in asyncio.run(probes()):
                step(entry.pop("step"), entry.pop("ok"), entry.pop("detail"), **entry)

    failed = [entry for entry in steps if not entry["ok"]]
    if not failed:
        verdict = "Everything answered: DNS, TCP, TLS, the model list, a real chat call and a streamed chat call."
        code = 0
    else:
        first = failed[0]
        category = first.get("category")
        if category in ("authentication", "authorization"):
            verdict = "The provider rejected the credentials or the key lacks access. Check the API key in Admin -> Providers."
            code = 3
        elif category in ("model_not_found", "unsupported_operation", "invalid_request", "content_filtered"):
            verdict = "The provider rejected the request itself (model id/operation/parameters). Re-run 'Synchronize models' and pick the current model id."
            code = 4
        elif category in ("provider_connectivity", "provider_timeout", "upstream_server_error", "rate_limit", "quota_exhausted"):
            verdict = "The provider could not be reached or refused to answer. The message above carries the endpoint, the exception and the provider's own body."
            code = 5
        else:
            verdict = "See the failed step above."
            code = 5
    print(json.dumps({"provider": info, "steps": steps, "verdict": verdict}, indent=2, default=str))
    return code


def _as_int(value: Any) -> int:
    try:
        return int(str(value))
    except (TypeError, ValueError):
        return -1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python -m app.cli", description="Nexa AI operational CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("bootstrap", help="seed roles/permissions/settings and the initial Super Admin")
    p.add_argument("--skip-admin", action="store_true")
    p.add_argument("--admin-email")
    p.add_argument("--admin-password")
    p.add_argument("--admin-name")
    p.set_defaults(func=cmd_bootstrap)

    p = sub.add_parser("create-admin", help="create an additional administrator account")
    p.add_argument("--email", required=True)
    p.add_argument("--password", default="", help="password; omit to use NEXA_ADMIN_PASSWORD, or with --generate")
    p.add_argument("--generate", action="store_true", help="generate a strong password and print it once")
    p.add_argument("--name", required=True)
    p.add_argument("--role", default="admin")
    p.set_defaults(func=cmd_create_admin)

    p = sub.add_parser("reset-password", help="set a new password for an existing account (recovery)")
    p.add_argument("--email", required=True)
    p.add_argument("--password", default="", help="new password; omit with --generate")
    p.add_argument("--generate", action="store_true", help="generate a random password and print it")
    p.add_argument("--must-change", action="store_true", help="force a password change at next sign-in")
    p.set_defaults(func=cmd_reset_password)

    p = sub.add_parser("grant-credits", help="grant credits to an account (ledger-recorded)")
    p.add_argument("--email", required=True)
    p.add_argument("--credits", type=float, required=True)
    p.add_argument("--reason", default="Operational credit grant")
    p.set_defaults(func=cmd_grant_credits)

    p = sub.add_parser("run-jobs", help="process queued jobs in this process")
    p.add_argument("--once", action="store_true")
    p.set_defaults(func=cmd_run_jobs)

    p = sub.add_parser("maintenance", help="expire old files and lapsed subscriptions")
    p.set_defaults(func=cmd_maintenance)

    p = sub.add_parser("doctor", help="print a configuration and integrity report")
    p.set_defaults(func=cmd_doctor)

    p = sub.add_parser("check-secrets", help="check that stored provider credentials still decrypt (exit 3 when not)")
    p.set_defaults(func=cmd_check_secrets)

    p = sub.add_parser(
        "provider-check",
        help="diagnose one provider layer by layer (DNS, TCP, TLS, models, chat, stream) with real calls",
    )
    p.add_argument("--provider", help="provider slug or id (omit when exactly one provider exists)")
    p.add_argument("--model", help="provider model id to call (default: the first synchronized model)")
    p.add_argument("--skip-chat", action="store_true", help="stop after the model list (no billable call)")
    p.set_defaults(func=cmd_provider_check)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    # Commands that print a JSON report on stdout send their log lines to stderr, so the
    # output can be piped straight into `jq` / `python -m json.tool`.
    json_report_commands = {"doctor", "check-secrets", "provider-check"}
    argv_list = list(sys.argv[1:] if argv is None else argv)
    command = next((token for token in argv_list if not token.startswith("-")), "")
    configure_logging(settings.log_level, json_output=False, stream="stderr" if command in json_report_commands else "stdout")
    args = parser.parse_args(argv_list)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
