"""Nexa AI — FastAPI application entry point.

Security middleware stack (outermost first):
  request-id/correlation → structured logging → security headers → CORS →
  trusted hosts → body-size guard → routes.
"""
from __future__ import annotations

import time
import uuid
from collections.abc import Awaitable, Callable
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware

from app.api.v1 import (
    admin,
    auth,
    billing,
    chat,
    files,
    health,
    meta,
    models,
    modules,
    providers,
    telegram,
    users,
)
from app.core.config import settings
from app.core.errors import NexaError, RateLimited
from app.core.logging import REQUEST_ID, configure_logging, get_logger
from app.db.session import check_database, get_engine
from app.services.bootstrap import run_bootstrap

configure_logging(settings.log_level, json_output=settings.log_json)
log = get_logger("nexa.main")


@asynccontextmanager
async def lifespan(app: FastAPI):  # noqa: ANN201
    problems = settings.assert_production_ready()
    for warning in settings.deployment_warnings():
        log.warning("deployment warning: %s", warning)
    if problems and settings.is_production:
        for problem in problems:
            log.error("FATAL configuration problem: %s", problem)
        raise RuntimeError(
            "Refusing to start with an unsafe production configuration:\n- " + "\n- ".join(problems)
        )
    ok, dialect = check_database()
    if not ok:
        log.error("database unavailable at startup: %s", dialect)
    else:
        log.info("database connection ok (%s)", dialect)
        from app.db.session import SessionLocal

        with SessionLocal() as db:
            report = run_bootstrap(db)
            log.info("bootstrap report: %s", report)
    log.info(
        "%s v%s starting — env=%s mode=%s public_url=%s",
        settings.app_name, settings.version, settings.environment, settings.deployment_mode, settings.public_base_url,
    )
    if settings.plain_http_warning:
        log.warning(settings.plain_http_warning)
    # NEXA_INLINE_WORKER=true means the API process owns the job queue (and Telegram
    # long-polling). Health endpoints advertise this mode, so it has to be real.
    from app.services import inline_worker

    if inline_worker.should_start():
        worker = inline_worker.start()
        log.info("inline worker enabled (id=%s)", worker.worker_id if worker else "-")
    else:
        log.info("inline worker disabled (NEXA_INLINE_WORKER=%s, env=%s)",
                 settings.inline_worker, settings.environment)
    yield
    log.info("shutting down; disposing database connections")
    inline_worker.stop()
    get_engine().dispose()


app = FastAPI(
    title="Nexa AI API",
    version=settings.version,
    description=(
        "Nexa AI — multi-provider AI workspace. All endpoints are versioned under /api/v1. "
        "Authentication uses an HttpOnly session cookie (with CSRF double-submit) or a Bearer access token."
    ),
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
    lifespan=lifespan,
)


@app.middleware("http")
async def request_context(request: Request, call_next: Callable[[Request], Awaitable[Response]]) -> Response:
    request_id = request.headers.get("x-request-id") or uuid.uuid4().hex[:16]
    REQUEST_ID.set(request_id)
    started = time.perf_counter()
    try:
        response = await call_next(request)
    except Exception:  # noqa: BLE001 - logged by the global handler
        raise
    latency_ms = int((time.perf_counter() - started) * 1000)
    response.headers["X-Request-ID"] = request_id
    response.headers["X-Response-Time-ms"] = str(latency_ms)
    if request.url.path.startswith("/api") and request.method != "OPTIONS":
        log.info(
            "request %s %s -> %s (%sms)", request.method, request.url.path, response.status_code, latency_ms,
            extra={"path": request.url.path, "method": request.method, "status": response.status_code, "latency_ms": latency_ms},
        )
    return response


@app.middleware("http")
async def body_size_guard(request: Request, call_next: Callable[[Request], Awaitable[Response]]) -> Response:
    limit = settings.max_request_body_mb * 1024 * 1024
    content_length = request.headers.get("content-length")
    if content_length and content_length.isdigit() and int(content_length) > limit:
        return JSONResponse(
            status_code=413,
            content={"error": {"code": "payload_too_large", "message": f"Request body exceeds {settings.max_request_body_mb} MB."}},
        )
    return await call_next(request)


@app.middleware("http")
async def security_headers(request: Request, call_next: Callable[[Request], Awaitable[Response]]) -> Response:
    response = await call_next(request)
    if not settings.security_headers:
        return response
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    if settings.frame_ancestors:
        # Explicit embedding allow-list: CSP frame-ancestors, and no conflicting X-Frame-Options
        # (a browser that sees X-Frame-Options ignores frame-ancestors).
        response.headers["Content-Security-Policy"] = f"frame-ancestors {settings.frame_ancestors};"
        if "x-frame-options" in response.headers:
            del response.headers["x-frame-options"]
    else:
        response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(self), geolocation=()")
    response.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
    if hsts := settings.hsts_enabled:
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    if request.url.path.startswith("/api"):
        response.headers.setdefault("Cache-Control", "no-store")
    return response


app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-CSRF-Token", "X-Request-ID", "Accept-Language"],
    expose_headers=["X-Request-ID", "X-Response-Time-ms"],
    max_age=600,
)
if "*" not in settings.trusted_host_list:
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=settings.trusted_host_list)


# ----------------------------------------------------------------- handlers --
@app.exception_handler(NexaError)
async def nexa_error_handler(request: Request, exc: NexaError) -> JSONResponse:
    headers = {}
    if isinstance(exc, RateLimited):
        headers["Retry-After"] = str(exc.retry_after)
    payload = exc.to_payload()
    payload["error"]["request_id"] = REQUEST_ID.get()
    level = log.warning if exc.status_code < 500 else log.error
    level("api error %s %s -> %s: %s", request.method, request.url.path, exc.status_code, exc.detail)
    return JSONResponse(status_code=exc.status_code, content=payload, headers=headers)


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    fields: dict[str, str] = {}
    for error in exc.errors():
        location = ".".join(str(part) for part in error["loc"] if part not in ("body", "query", "path"))
        fields[location or "body"] = error["msg"]
    return JSONResponse(
        status_code=422,
        content={
            "error": {
                "code": "validation_error",
                "message": "The submitted data is invalid.",
                "category": "invalid_request",
                "details": {"fields": fields},
                "request_id": REQUEST_ID.get(),
            }
        },
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    log.exception("unhandled error on %s %s: %s", request.method, request.url.path, exc)
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "code": "internal_error",
                "message": "An unexpected error occurred. Reference the request id when contacting support.",
                "category": "internal_error",
                "details": {},
                "request_id": REQUEST_ID.get(),
            }
        },
    )


# ------------------------------------------------------------------ routers --
API = "/api/v1"
app.include_router(health.router, tags=["health"])
app.include_router(meta.router, prefix=API, tags=["meta"])
app.include_router(auth.router, prefix=API)
app.include_router(users.router, prefix=API)
app.include_router(users.roles_router, prefix=API)
app.include_router(providers.router, prefix=API)
app.include_router(models.router, prefix=API)
app.include_router(models.admin_router, prefix=API)
app.include_router(models.admin_variants_router, prefix=API)
app.include_router(chat.router, prefix=API)
app.include_router(files.router, prefix=API)
app.include_router(modules.router, prefix=API)
app.include_router(modules.jobs_router, prefix=API)
app.include_router(billing.router, prefix=API)
app.include_router(billing.admin_router, prefix=API)
app.include_router(admin.router, prefix=API)
app.include_router(telegram.router, prefix=API)
app.include_router(telegram.admin_router, prefix=API)


# ------------------------------------------------------------ static SPA ------
FRONTEND_DIST = (Path(__file__).resolve().parent.parent / settings.frontend_dist_dir).resolve()
if settings.serve_frontend and FRONTEND_DIST.exists():
    assets_dir = FRONTEND_DIST / "assets"
    if assets_dir.exists():
        app.mount("/assets", StaticFiles(directory=str(assets_dir)), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def spa(full_path: str) -> Response:
        if full_path.startswith(("api/", "docs", "redoc", "openapi")):
            return JSONResponse(status_code=404, content={"error": {"code": "not_found", "message": "Not found"}})
        candidate = (FRONTEND_DIST / full_path).resolve()
        if full_path and FRONTEND_DIST in candidate.parents and candidate.is_file():
            return FileResponse(candidate)
        index = FRONTEND_DIST / "index.html"
        if index.exists():
            return FileResponse(index, headers={"Cache-Control": "no-cache"})
        return JSONResponse(status_code=404, content={"error": {"code": "not_found", "message": "Frontend build not found"}})
else:
    @app.get("/", include_in_schema=False)
    async def root() -> dict:
        return {
            "name": settings.app_name,
            "version": settings.version,
            "api": "/api/v1",
            "docs": "/api/docs",
            "frontend": "not built into this image — run `npm run build` in frontend/ or use the Vite dev server",
        }
