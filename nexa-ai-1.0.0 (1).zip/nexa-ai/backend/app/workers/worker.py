"""Standalone job worker process (docker compose service ``worker``).

Graceful shutdown: SIGTERM/SIGINT finish the current job, then exit. Jobs whose
worker dies are recovered by the lease mechanism in ``services.jobs``.
"""
from __future__ import annotations

import asyncio
import signal
import sys
import threading
import time

from app.core.config import settings
from app.core.logging import configure_logging, get_logger
from app.db.session import SessionLocal, check_database, get_engine
from app.services import jobs as job_service
from app.services.bootstrap import run_bootstrap

configure_logging(settings.log_level, json_output=settings.log_json)
log = get_logger("nexa.worker")

RUNNING = True
_STOP_EVENT: threading.Event | None = None


def _stop(signum, _frame):  # noqa: ANN001
    global RUNNING
    log.info("received signal %s — finishing current job then exiting", signum)
    RUNNING = False
    if _STOP_EVENT is not None:
        _STOP_EVENT.set()


def _telegram_polling_decision() -> tuple[bool, str]:
    """Decide whether *this* process should long-poll Telegram, with the reason.

    Telegram delivers an update to a single ``getUpdates`` consumer, so exactly one
    process may poll: the API process when ``NEXA_INLINE_WORKER=true``, otherwise the
    dedicated worker service.
    """
    if not (settings.telegram_enabled and settings.telegram_mode == "polling" and settings.telegram_bot_token):
        return False, f"not configured (enabled={settings.telegram_enabled}, mode={settings.telegram_mode})"
    if settings.inline_worker:
        return False, "owned by the API process (NEXA_INLINE_WORKER=true)"
    return True, "started in the worker process"


def _telegram_thread(stop_event: threading.Event) -> None:
    """Long-poll Telegram in this process, restarting after a crash."""
    from app.services import telegram as telegram_service

    attempt = 0
    while not stop_event.is_set():
        attempt += 1
        log.info("telegram polling starting (bot=@%s, attempt %s)", settings.telegram_bot_username or "unset", attempt)
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(telegram_service.run_polling(stop_event))
            if not stop_event.is_set():
                log.warning("telegram polling returned unexpectedly; restarting")
        except Exception as exc:  # noqa: BLE001
            log.exception("telegram polling crashed: %s", exc)
        finally:
            loop.close()
        if stop_event.is_set():
            break
        attempt = min(attempt, 20)
        stop_event.wait(min(5 * attempt, 60))
    log.info("telegram polling stopped")


def main() -> int:
    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)
    ok, detail = check_database()
    if not ok:
        log.error("database not reachable: %s", detail)
        return 1
    with SessionLocal() as db:
        run_bootstrap(db, create_admin=False)
    worker_id = job_service.new_worker_id()
    log.info("worker %s started (poll=%ss, concurrency=%s)", worker_id, settings.job_poll_seconds, settings.worker_concurrency)
    global _STOP_EVENT
    start_telegram, reason = _telegram_polling_decision()
    if start_telegram:
        _STOP_EVENT = threading.Event()
        threading.Thread(target=_telegram_thread, args=(_STOP_EVENT,), name="telegram-poll", daemon=True).start()
        log.info("telegram polling %s", reason)
    else:
        log.info("telegram polling not started here: %s", reason)
    idle_rounds = 0
    while RUNNING:
        with SessionLocal() as db:
            job = job_service.run_once(db, worker_id)
        if job is None:
            idle_rounds += 1
            time.sleep(min(settings.job_poll_seconds * (1 + idle_rounds // 30), 15))
        else:
            idle_rounds = 0
            log.info("processed job %s (%s) -> %s", job.id, job.job_type, job.status)
    log.info("worker %s stopped", worker_id)
    get_engine().dispose()
    return 0


if __name__ == "__main__":
    sys.exit(main())
