"""Telegram link model."""
from __future__ import annotations

import datetime as dt

from sqlalchemy import JSON, BigInteger, Boolean, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import UTCDateTime, Base, created_at_col, pk, updated_at_col


class TelegramLink(Base):
    """A Telegram account bound to a platform account.

    The platform never receives a Telegram password and Telegram never receives a platform
    password: the binding is proven once by a short-lived code the signed-in user asks the
    site for, then every bot message is executed *as* that platform user.
    """

    __tablename__ = "telegram_links"

    id: Mapped[int] = pk()
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    telegram_user_id: Mapped[int] = mapped_column(BigInteger, nullable=False, unique=True, index=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    telegram_username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    telegram_first_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    linked_at: Mapped[dt.datetime] = created_at_col()
    last_message_at: Mapped[dt.datetime | None] = mapped_column(UTCDateTime, nullable=True)
    message_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    state: Mapped[dict | None] = mapped_column(JSON, nullable=True)   # selected model / variant / conversation

    created_at: Mapped[dt.datetime] = created_at_col()
    updated_at: Mapped[dt.datetime] = updated_at_col()

    user = relationship("User", backref="telegram_link")
