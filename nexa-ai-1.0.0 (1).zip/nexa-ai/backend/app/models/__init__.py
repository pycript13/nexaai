"""SQLAlchemy models. Import order matters for mapper configuration."""
from app.models.user import (  # noqa: F401
    AccountStatus,
    Permission,
    Role,
    RolePermission,
    User,
    UserActivity,
    UserRole,
    UserSession,
)
from app.models.provider import (  # noqa: F401
    AccessTier,
    Model,
    ModelAvailability,
    ModelCategory,
    ModelGrant,
    ModelVariant,
    ModelVisibility,
    Provider,
    ProviderHealthSample,
    ProviderType,
    model_categories,
    model_tags,
)
from app.models.chat import Conversation, Message, MessageRole  # noqa: F401
from app.models.files import FileKind, StoredFile  # noqa: F401
from app.models.jobs import Job, JobStatus, JobType  # noqa: F401
from app.models.billing import (  # noqa: F401
    CreditAccount,
    LedgerEntry,
    LedgerEntryType,
    Payment,
    PaymentMethod,
    PaymentStatus,
    PricingRule,
    Subscription,
    SubscriptionPlan,
    SubscriptionStatus,
    UsageRecord,
    UsageStatus,
    usage_admin_test_scope,
)
from app.models.telegram import TelegramLink  # noqa: F401
from app.models.admin import AdminModelTest, AppSetting, AuditEvent  # noqa: F401
from app.models.enums import ACCOUNT_STATUSES, ROLE_SLUGS  # noqa: F401

__all__ = [
    "User", "Role", "Permission", "RolePermission", "UserRole", "UserSession", "UserActivity", "AccountStatus",
    "Provider", "ProviderType", "ProviderHealthSample", "Model", "ModelVariant", "ModelCategory", "ModelGrant",
    "ModelVisibility", "ModelAvailability", "AccessTier", "model_categories", "model_tags",
    "Conversation", "Message", "MessageRole",
    "StoredFile", "FileKind",
    "Job", "JobStatus", "JobType",
    "CreditAccount", "LedgerEntry", "LedgerEntryType", "Payment", "PaymentStatus", "PaymentMethod",
    "PricingRule", "Subscription", "SubscriptionPlan", "SubscriptionStatus", "UsageRecord", "UsageStatus",
    "AdminModelTest", "AuditEvent", "AppSetting", "TelegramLink",
    "ROLE_SLUGS", "ACCOUNT_STATUSES",
]
