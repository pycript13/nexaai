from __future__ import annotations

import datetime as dt

from sqlalchemy import JSON, BigInteger, Boolean, DateTime, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, created_at_col, pk


class AdminModelTest(Base):
    """Record of an administrative model test (spec §9).

    Kept separate from user usage: ``cost_micro`` here is the *platform's*
    provider cost, never charged to a user's credit balance.
    """

    __tablename__ = "admin_model_tests"
    __table_args__ = (
        Index("ix_admin_tests_provider_created", "provider_id", "created_at"),
        Index("ix_admin_tests_model_created", "model_id", "created_at"),
        Index("ix_admin_tests_admin_created", "admin_user_id", "created_at"),
    )

    id: Mapped[int] = pk()
    admin_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    provider_id: Mapped[int | None] = mapped_column(ForeignKey("providers.id", ondelete="SET NULL"), nullable=True)
    model_id: Mapped[int | None] = mapped_column(ForeignKey("models.id", ondelete="SET NULL"), nullable=True)
    provider_model_id: Mapped[str | None] = mapped_column(String(200), nullable=True)
    operation: Mapped[str] = mapped_column(String(32), nullable=False, default="chat")
    used_model_visibility: Mapped[str | None] = mapped_column(String(24), nullable=True)
    bypassed_user_restrictions: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    request_summary: Mapped[str | None] = mapped_column(Text, nullable=True)   # truncated, secret-free preview
    request_params: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    success: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    response_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    response_meta: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    latency_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    provider_request_id: Mapped[str | None] = mapped_column(String(160), nullable=True)
    prompt_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    completion_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    usage_source: Mapped[str] = mapped_column(String(24), nullable=False, default="unavailable")
    provider_cost_micro: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    cost_uncertain: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    error_category: Mapped[str | None] = mapped_column(String(48), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    diagnostics: Mapped[list | None] = mapped_column(JSON, nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()

    admin_user: Mapped["User"] = relationship()  # noqa: F821
    model: Mapped["Model"] = relationship()  # noqa: F821


class AuditEvent(Base):
    """Append-only administrative/security audit trail."""

    __tablename__ = "audit_events"
    __table_args__ = (
        Index("ix_audit_created", "created_at"),
        Index("ix_audit_action_created", "action", "created_at"),
        Index("ix_audit_actor_created", "actor_user_id", "created_at"),
        Index("ix_audit_entity", "entity_type", "entity_id"),
    )

    id: Mapped[int] = pk()
    action: Mapped[str] = mapped_column(String(96), nullable=False, index=True)
    category: Mapped[str] = mapped_column(String(32), nullable=False, default="general", index=True)
    severity: Mapped[str] = mapped_column(String(16), nullable=False, default="info")  # info|notice|warning|critical
    actor_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    actor_email: Mapped[str | None] = mapped_column(String(320), nullable=True)
    actor_role: Mapped[str | None] = mapped_column(String(48), nullable=True)
    entity_type: Mapped[str | None] = mapped_column(String(48), nullable=True)
    entity_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    summary: Mapped[str] = mapped_column(String(400), nullable=False, default="")
    before_state: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    after_state: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    ip_address: Mapped[str | None] = mapped_column(String(64), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(400), nullable=True)
    request_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    created_at: Mapped[dt.datetime] = created_at_col()


class AppSetting(Base):
    """Operator-editable settings that are safe to change at runtime.

    Secrets are never stored here (they belong in the environment / encrypted
    provider credentials).
    """

    __tablename__ = "app_settings"

    id: Mapped[int] = pk()
    key: Mapped[str] = mapped_column(String(96), unique=True, nullable=False, index=True)
    value_json: Mapped[dict | None] = mapped_column("value", JSON, nullable=True)
    value_type: Mapped[str] = mapped_column(String(16), nullable=False, default="json")
    category: Mapped[str] = mapped_column(String(32), nullable=False, default="general")
    label: Mapped[str] = mapped_column(String(160), nullable=False, default="")
    description: Mapped[str] = mapped_column(String(400), nullable=False, default="")
    is_public: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    updated_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at: Mapped[dt.datetime] = created_at_col()
    updated_at: Mapped[dt.datetime] = created_at_col()
