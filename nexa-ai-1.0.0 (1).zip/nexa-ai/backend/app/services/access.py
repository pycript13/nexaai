"""Authorization: RBAC permissions + model access policy + quota enforcement.

Everything here is enforced **server side**. The UI mirrors these rules only to
avoid dead ends; it is never the security boundary.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.errors import InsufficientBalance, PermissionDenied, RateLimited
from app.models.billing import Subscription, SubscriptionStatus
from app.models.provider import AccessTier, Model, ModelAvailability, ModelGrant, ModelVisibility, Provider
from app.models.user import User
from app.services import ledger as ledger_service
from app.services import pricing as pricing_service
from app.services import usage as usage_service

# --------------------------------------------------------------------- RBAC --
def user_permissions(user: User | None) -> set[str]:
    if user is None:
        return set()
    slugs: set[str] = set()
    for role in user.roles or []:
        for perm in role.permissions or []:
            slugs.add(perm.slug)
    return slugs


def has_permission(user: User | None, permission: str) -> bool:
    if user is None:
        return False
    if "*" in user_permissions(user):
        return True
    return permission in user_permissions(user)


def has_any_permission(user: User | None, permissions: list[str]) -> bool:
    return any(has_permission(user, p) for p in permissions)


def is_super_admin(user: User | None) -> bool:
    if user is None:
        return False
    return any(role.slug == "super_admin" for role in user.roles or [])


def require_permission(user: User | None, permission: str) -> None:
    if not has_permission(user, permission):
        raise PermissionDenied(
            f"Missing required permission: {permission}",
            details={"required_permission": permission},
        )


def role_slugs(user: User | None) -> list[str]:
    return sorted(role.slug for role in (user.roles or []))


# -------------------------------------------------------- model access rules --
@dataclass
class AccessDecision:
    allowed: bool
    code: str = "ok"
    reason: str = ""
    access_tier: str = AccessTier.CREDIT
    requires_payment: bool = False
    is_admin_override: bool = False
    details: dict = field(default_factory=dict)


def _grants_for(db: Session, model: Model, user: User) -> list[ModelGrant]:
    role_ids = [role.id for role in (user.roles or [])]
    conditions = [ModelGrant.subject_type == "user", ModelGrant.subject_id == user.id]
    if role_ids:
        conditions.append((ModelGrant.subject_type == "role") & ModelGrant.subject_id.in_(role_ids))
    return list(db.scalars(select(ModelGrant).where(ModelGrant.model_id == model.id, or_(*conditions))).all())


def _grant_is_live(grant: ModelGrant, now: dt.datetime) -> bool:
    if grant.expires_at and grant.expires_at < now:
        return False
    return True


def active_subscription(db: Session, user: User) -> Subscription | None:
    subs = db.scalars(
        select(Subscription).where(
            Subscription.user_id == user.id,
            Subscription.status.in_([SubscriptionStatus.ACTIVE, SubscriptionStatus.TRIALING]),
        )
    ).all()
    for sub in subs:
        if sub.is_currently_active():
            return sub
    return None


def evaluate_model_access(
    db: Session,
    user: User | None,
    model: Model,
    *,
    operation: str = "chat",
    is_admin_test: bool = False,
    admin_user: User | None = None,
) -> AccessDecision:
    """Decide whether `user` may run `operation` on `model`.

    ``is_admin_test`` switches into the administrative workflow: an authorized
    administrator may exercise hidden/restricted/internal models, but a
    *disabled* provider or a *disabled* model stays disabled (no silent
    re-enabling), and the operation must still be supported by the model.
    """
    provider: Provider | None = model.provider
    if provider is None:
        return AccessDecision(False, "provider_missing", "The model has no provider attached.")
    if not provider.enabled:
        return AccessDecision(
            False, "provider_disabled",
            f"Provider '{provider.name}' is disabled. Enable it under Admin → AI Infrastructure → Providers.",
            details={"provider_id": provider.id, "provider_enabled": False},
        )
    if not model.enabled:
        return AccessDecision(
            False, "model_disabled",
            f"Model '{model.display_name}' is disabled by an administrator.",
            details={"model_id": model.id, "model_enabled": False},
        )
    if model.availability == ModelAvailability.DISABLED:
        return AccessDecision(False, "model_offline", f"Model '{model.display_name}' is marked as unavailable.")

    capabilities = set(model.capabilities or [])
    if operation not in capabilities:
        return AccessDecision(
            False, "operation_unsupported",
            f"Model '{model.display_name}' does not advertise the '{operation}' capability.",
            details={"operation": operation, "capabilities": sorted(capabilities)},
        )

    if is_admin_test:
        if admin_user is None or not has_permission(admin_user, "models.test"):
            return AccessDecision(False, "permission_denied", "You do not have permission to run administrative model tests.")
        return AccessDecision(
            True,
            "admin_test",
            "Administrative test: user-level commercial restrictions bypassed; provider credentials and model state still enforced.",
            access_tier=model.access_tier,
            is_admin_override=True,
            details={"visibility": model.visibility, "access_tier": model.access_tier},
        )

    if user is None:
        return AccessDecision(False, "unauthenticated", "Sign in to use AI models.")

    if model.visibility != ModelVisibility.PUBLIC or not model.published:
        return AccessDecision(
            False, "model_not_available",
            f"Model '{model.display_name}' is not published for user access.",
            details={"visibility": model.visibility, "published": model.published},
        )

    tier = model.access_tier
    if tier == AccessTier.INTERNAL:
        return AccessDecision(False, "internal_only", "This model is reserved for internal platform operations.")
    if tier == AccessTier.RESTRICTED:
        grants = [g for g in _grants_for(db, model, user) if _grant_is_live(g, dt.datetime.now(dt.timezone.utc))]
        if not grants:
            return AccessDecision(
                False, "model_restricted",
                "Access to this model is restricted. Request a grant from an administrator.",
                access_tier=tier,
            )
        limits = {
            "daily_spend_limit_micro": min([g.daily_spend_limit_micro for g in grants if g.daily_spend_limit_micro] or [None], default=None)
            if any(g.daily_spend_limit_micro for g in grants) else None,
        }
        return AccessDecision(True, "restricted_grant", "Access granted.", access_tier=tier, details=limits)
    if tier == AccessTier.SUBSCRIPTION:
        sub = active_subscription(db, user)
        if sub is None:
            return AccessDecision(
                False, "subscription_required",
                "An active subscription is required for this model.",
                access_tier=tier,
                requires_payment=True,
                details={"pricing_url": "/account/subscriptions"},
            )
        if model.subscription_plan_id and sub.plan_id != model.subscription_plan_id:
            return AccessDecision(
                False, "plan_upgrade_required",
                f"Model requires the '{sub.plan.name}' successor plan or higher.",
                access_tier=tier,
                requires_payment=True,
            )
        return AccessDecision(True, "subscription_active", "Subscription covers this model.", access_tier=tier)
    if tier == AccessTier.FREE:
        return AccessDecision(True, "free", "Model is free to use.", access_tier=tier)

    # credit tier: needs a positive balance
    balance = ledger_service.balance_of(db, user.id)
    if balance <= 0:
        return AccessDecision(
            False, "insufficient_balance",
            "Your credit balance is empty. Add credits under Account → Billing to use paid models.",
            access_tier=tier,
            requires_payment=True,
            details={"balance_micro": balance},
        )
    return AccessDecision(True, "credit", "Paid per use from your credit balance.", access_tier=tier)


# ---------------------------------------------------------------- quotas ----
def estimate_max_charge_micro(db: Session, model: Model, user: User | None, *, prompt_tokens_estimate: int = 0, max_output_tokens: int = 0) -> int:
    quote = pricing_service.resolve_price(db, model, user=user)
    breakdown = pricing_service.compute_charge(
        quote,
        prompt_tokens=prompt_tokens_estimate or None,
        completion_tokens=max_output_tokens or None,
        requests=1,
        access_tier=model.access_tier,
    )
    return breakdown.charged_micro


def enforce_quotas(
    db: Session,
    user: User | None,
    model: Model | None,
    *,
    estimated_charge_micro: int | None = None,
    is_admin_test: bool = False,
) -> None:
    """Raise when a user-level or platform-level spending/rate limit is hit."""
    if is_admin_test:
        return
    if settings.global_daily_spend_limit_micro:
        spent = usage_service.platform_spend_today_micro(db)
        if spent >= settings.global_daily_spend_limit_micro:
            raise RateLimited(
                "The platform-wide daily provider spend limit has been reached. Try again after the limit resets.",
                retry_after=3600,
                details={"scope": "global", "spent_micro": spent, "limit_micro": settings.global_daily_spend_limit_micro},
            )
    if user is None:
        return

    # daily request quota (test accounts etc.)
    if user.quota_requests_per_day:
        start = dt.datetime.now(dt.timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        from app.models.billing import UsageRecord

        count = db.scalar(
            select(func.count(UsageRecord.id)).where(
                UsageRecord.user_id == user.id, UsageRecord.created_at >= start
            )
        ) or 0
        if int(count) >= user.quota_requests_per_day:
            raise RateLimited(
                f"Daily request quota reached ({user.quota_requests_per_day} requests/day for this account).",
                retry_after=3600,
                details={"scope": "user_daily_requests", "limit": user.quota_requests_per_day},
            )

    account = ledger_service.get_account(db, user.id)
    if account is None:
        return
    spent_today = usage_service.user_spend_today_micro(db, user.id)
    spent_month = usage_service.user_spend_month_micro(db, user.id)
    projected = estimated_charge_micro or 0

    limits = [
        ("user_daily_spend", user.quota_spend_micro_per_day, spent_today),
        ("account_daily_spend", account.daily_spend_limit_micro, spent_today),
        ("account_monthly_spend", account.monthly_spend_limit_micro, spent_month),
    ]
    for scope, limit, spent in limits:
        if limit and spent + projected > limit:
            raise RateLimited(
                f"Spending limit reached for {scope.replace('_', ' ')} "
                f"({pricing_service.micro_to_display(limit)} credits). Contact an administrator to raise it.",
                retry_after=3600,
                details={"scope": scope, "limit_micro": limit, "spent_micro": spent, "projected_micro": projected},
            )
    if model is not None:
        grants = _grants_for(db, model, user)
        for grant in grants:
            if grant.daily_spend_limit_micro and spent_today + projected > grant.daily_spend_limit_micro:
                raise RateLimited(
                    "Daily spend limit for this granted model has been reached.",
                    retry_after=3600,
                    details={"scope": "grant_daily_spend", "limit_micro": grant.daily_spend_limit_micro},
                )
            if grant.monthly_spend_limit_micro and spent_month + projected > grant.monthly_spend_limit_micro:
                raise RateLimited(
                    "Monthly spend limit for this granted model has been reached.",
                    retry_after=3600,
                    details={"scope": "grant_monthly_spend", "limit_micro": grant.monthly_spend_limit_micro},
                )


def ensure_balance_for_request(db: Session, user: User, model: Model, *, estimated_charge_micro: int) -> None:
    if model.access_tier == AccessTier.FREE or estimated_charge_micro <= 0:
        return
    account = ledger_service.get_account(db, user.id)
    if account is None or account.balance_micro < estimated_charge_micro:
        raise InsufficientBalance(
            "Insufficient credit balance to start this request.",
            details={
                "balance_micro": account.balance_micro if account else 0,
                "required_micro": estimated_charge_micro,
            },
        )


# ------------------------------------------------------- discoverable models --
def visible_models_query(user: User | None, *, include_unpublished: bool = False):
    """Base SELECT for models a normal user may see."""
    stmt = select(Model).join(Provider, Provider.id == Model.provider_id).where(
        Model.enabled.is_(True),
        Provider.enabled.is_(True),
    )
    if not include_unpublished:
        stmt = stmt.where(
            Model.visibility == ModelVisibility.PUBLIC,
            Model.published.is_(True),
            Model.availability != ModelAvailability.DISABLED,
            Model.access_tier != AccessTier.INTERNAL,
        )
    else:
        stmt = stmt.where(Model.visibility != ModelVisibility.ARCHIVED)
    return stmt


def filter_models_for_user(db: Session, user: User | None, models: list[Model], *, operation: str | None = None) -> list[Model]:
    """Models a signed-in user may *see* in the catalog.

    Visibility is not access: a model the user cannot use yet because it is paid
    (``requires_payment``) stays visible so the UI can explain how to unlock it,
    while restricted/internal/hidden models are filtered out entirely.
    """
    out: list[Model] = []
    for model in models:
        decision = evaluate_model_access(db, user, model, operation=operation or (model.capabilities or ["chat"])[0])
        if decision.allowed or decision.requires_payment:
            out.append(model)
    return out
