"""Usage recording + charging orchestration.

The rule that keeps the books honest:
* A usage record is written for *every* provider operation that reached the
  provider — including failures — but a **failure is never charged** unless the
  provider-specific policy explicitly says otherwise (``charge_on_failure``).
* A charge is only written together with a successful provider response, inside
  one transaction, keyed by an idempotency key derived from the request.
* Admin test usage is stored with ``is_admin_test=true`` and is never billed to a
  user balance.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.errors import ProviderError
from app.core.logging import get_logger
from app.models.billing import LedgerEntryType, PricingRule, UsageRecord, UsageStatus
from app.models.provider import AccessTier, Model, Provider
from app.models.user import User
from app.services import ledger as ledger_service
from app.services import pricing as pricing_service

log = get_logger(__name__)


@dataclass
class UsageOutcome:
    usage: UsageRecord
    charge: ledger_service.LedgerResult | None = None
    insufficient_balance: bool = False
    notes: list[str] = field(default_factory=list)


def record_usage(
    db: Session,
    *,
    user: User | None,
    model: Model | None,
    provider: Provider | None,
    operation: str,
    status: str = UsageStatus.SUCCEEDED,
    module: str | None = None,
    idempotency_key: str,
    prompt_tokens: int | None = None,
    completion_tokens: int | None = None,
    usage_source: str = "provider_reported",
    images: int = 0,
    audio_seconds: float | None = None,
    video_seconds: float | None = None,
    latency_ms: int | None = None,
    provider_request_id: str | None = None,
    error_category: str | None = None,
    conversation_id: int | None = None,
    variant_id: int | None = None,
    job_id: int | None = None,
    is_admin_test: bool = False,
    admin_test_id: int | None = None,
    charge: bool = True,
    charge_on_failure: bool = False,
    metadata: dict | None = None,
) -> UsageOutcome:
    existing = db.scalars(select(UsageRecord).where(UsageRecord.idempotency_key == idempotency_key)).first()
    if existing is not None:
        return UsageOutcome(usage=existing, notes=["duplicate idempotency key — no new charge"])

    total_tokens = None
    if prompt_tokens is not None or completion_tokens is not None:
        total_tokens = (prompt_tokens or 0) + (completion_tokens or 0)

    record = UsageRecord(
        user_id=user.id if user else None,
        provider_id=provider.id if provider else None,
        model_id=model.id if model else None,
        provider_model_id=model.provider_model_id if model else None,
        operation=operation,
        module=module,
        conversation_id=conversation_id,
        variant_id=variant_id,
        job_id=job_id,
        status=status,
        error_category=error_category,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        total_tokens=total_tokens,
        images_generated=images or None,
        audio_seconds=Decimal(str(audio_seconds)) if audio_seconds is not None else None,
        video_seconds=Decimal(str(video_seconds)) if video_seconds is not None else None,
        usage_source=usage_source,
        latency_ms=latency_ms,
        provider_request_id=provider_request_id,
        idempotency_key=idempotency_key,
        is_admin_test=is_admin_test,
        admin_test_id=admin_test_id,
        metadata_json=metadata,
    )

    outcome = UsageOutcome(usage=record)
    chargeable = (
        charge
        and user is not None
        and model is not None
        and (status == UsageStatus.SUCCEEDED or charge_on_failure)
    )
    if chargeable:
        quote = pricing_service.resolve_price(db, model, user=user, operation=operation)
        breakdown = pricing_service.compute_charge(
            quote,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            requests=1,
            images=images,
            audio_seconds=audio_seconds,
            access_tier=model.access_tier,
        )
        record.charged_micro = breakdown.charged_micro
        record.provider_cost_micro = breakdown.provider_cost_micro
        record.pricing_rule_id = quote.rule_id
        record.pricing_rule_version = quote.rule_version
        record.pricing_uncertain = bool(breakdown and (breakdown.warnings or quote.provider_cost_uncertain))
        if model.access_tier == AccessTier.FREE:
            record.billed_to_user = False
        elif breakdown.charged_micro > 0:
            record.billed_to_user = True
        outcome.notes.extend(breakdown.warnings)

    db.add(record)
    db.flush()

    if record.billed_to_user and record.charged_micro > 0 and not is_admin_test:
        try:
            charge_result = ledger_service.debit(
                db,
                user_id=user.id,  # type: ignore[union-attr]
                amount_micro=record.charged_micro,
                entry_type=LedgerEntryType.USAGE_CHARGE,
                idempotency_key=f"usage:{idempotency_key}",
                description=f"{operation} on {model.display_name if model else 'model'}",
                reference_type="usage",
                reference_id=record.id,
            )
            outcome.charge = charge_result
        except Exception as exc:  # InsufficientBalance is handled by the caller AFTER the provider call
            outcome.insufficient_balance = True
            outcome.notes.append(str(exc))
            raise
    return outcome


def user_spend_today_micro(db: Session, user_id: int) -> int:
    start = dt.datetime.now(dt.timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    total = db.scalar(
        select(func.coalesce(func.sum(UsageRecord.charged_micro), 0)).where(
            UsageRecord.user_id == user_id, UsageRecord.created_at >= start, UsageRecord.billed_to_user.is_(True)
        )
    )
    return int(total or 0)


def user_spend_month_micro(db: Session, user_id: int) -> int:
    now = dt.datetime.now(dt.timezone.utc)
    start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    total = db.scalar(
        select(func.coalesce(func.sum(UsageRecord.charged_micro), 0)).where(
            UsageRecord.user_id == user_id, UsageRecord.created_at >= start, UsageRecord.billed_to_user.is_(True)
        )
    )
    return int(total or 0)


def platform_spend_today_micro(db: Session) -> int:
    start = dt.datetime.now(dt.timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    total = db.scalar(
        select(func.coalesce(func.sum(UsageRecord.provider_cost_micro), 0)).where(UsageRecord.created_at >= start)
    )
    return int(total or 0)


def admin_test_spend_today_micro(db: Session, admin_id: int | None = None) -> int:
    start = dt.datetime.now(dt.timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    query = select(func.coalesce(func.sum(UsageRecord.provider_cost_micro), 0)).where(
        UsageRecord.is_admin_test.is_(True), UsageRecord.created_at >= start
    )
    if admin_id is not None:
        query = query.where(UsageRecord.user_id == admin_id)
    return int(db.scalar(query) or 0)
