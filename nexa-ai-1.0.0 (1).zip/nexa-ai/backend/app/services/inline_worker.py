"""The in-process worker: job queue consumer + Telegram long-polling.

Why this exists
---------------
``NEXA_INLINE_WORKER=true`` is the default for local installs (Windows ``start.bat``,
the Docker dev stack, ``.env.example``) and both ``/api/v1/health`` and
``/api/v1/health/deep`` already reported it as active. Nothing actually consumed the
queue in that mode, though: an installation without a separate worker service left every
job — image generation, transcription, exports, scheduled cleanup — sitting in ``pending``
for ever, and the Telegram bot never polled. That is a "described but not implemented"
feature, so this module implements it for real.

Design
------
* One daemon thread per process. It claims jobs through the ordinary
  ``job_service.run_once`` path, so leases, retries and audit records behave exactly like
  the standalone worker service.
* Telegram polling runs in the same thread (long-polling is I/O-bound and light) when
  ``NEXA_TELEGRAM_ENABLED`` and ``NEXA_TELEGRAM_MODE=polling``.
* It is never started when ``NEXA_ENVIRONMENT=test``: tests must not spawn background
  loops. The tests call :meth:`InlineWorker.tick` directly to exercise the same code.
* It is not started when ``NEXA_INLINE_WORKER=false`` — that is the "dedicated worker
  service" deployment, where ``app.workers.worker`` owns the queue.
"""
from __future__ import annotations

import asyncio
import threading
import time
from typing import Any

from app.core.config import settings
from app.core.logging import get_logger
from app.db.session import SessionLocal
from app.services import jobs as job_service

log = get_logger(__name__)


class InlineWorker:
    """A restartable, inspectable in-process worker loop."""

    def __init__(self, *, poll_seconds: float | None = None) -> None:
        self.poll_seconds = float(poll_seconds if poll_seconds is not None else settings.job_poll_seconds)
        self.worker_id = job_service.new_worker_id()
        self.stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._telegram_thread: threading.Thread | None = None
        self.processed = 0
        self.errors = 0
        self.started_at: float | None = None
        self.last_activity: float | None = None

    # ---------------------------------------------------------------- state -----
    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def status(self) -> dict[str, Any]:
        return {
            "running": self.running,
            "worker_id": self.worker_id,
            "processed": self.processed,
            "errors": self.errors,
            "poll_seconds": self.poll_seconds,
            "telegram_polling": bool(self._telegram_thread and self._telegram_thread.is_alive()),
            "started_at": self.started_at,
            "last_activity": self.last_activity,
        }

    # ----------------------------------------------------------------- ticks -----
    def tick(self) -> bool:
        """Process at most one job. Returns True when a job was handled.

        Kept separate from the loop so it can be tested without threads or sleeping.
        """
        db = SessionLocal()
        try:
            job = job_service.run_once(db, self.worker_id)
        except Exception as exc:  # noqa: BLE001 - a broken job must not kill the loop
            db.rollback()
            self.errors += 1
            log.exception("inline worker: job execution failed (%s)", exc)
            return False
        finally:
            db.close()
        if job is None:
            return False
        self.processed += 1
        self.last_activity = time.time()
        log.info("inline worker processed job %s (%s) -> %s", job.id, job.job_type, job.status)
        return True

    # ---------------------------------------------------------------- loops ------
    def _loop(self) -> None:
        idle_rounds = 0
        log.info("inline worker %s started (poll=%ss)", self.worker_id, self.poll_seconds)
        while not self.stop_event.is_set():
            handled = False
            try:
                handled = self.tick()
            except Exception as exc:  # noqa: BLE001 - the loop must survive anything
                self.errors += 1
                log.exception("inline worker loop error: %s", exc)
            if handled:
                idle_rounds = 0
                continue
            idle_rounds += 1
            # Back off gently: short delay while work is flowing, longer when idle.
            delay = min(self.poll_seconds * (1 + idle_rounds // 30), 15)
            self.stop_event.wait(max(0.2, delay))
        log.info("inline worker %s stopped", self.worker_id)

    def _telegram_loop(self) -> None:
        """Long-poll Telegram, restarting the loop if it ever falls over.

        A bot that silently stops answering is worse than one that logs an error, so a
        crash is retried with backoff until the worker is asked to stop.
        """
        from app.services import telegram as telegram_service

        attempt = 0
        while not self.stop_event.is_set():
            attempt += 1
            log.info("inline worker: telegram polling starting (bot=@%s, attempt %s)",
                     settings.telegram_bot_username or "unset", attempt)
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                loop.run_until_complete(telegram_service.run_polling(self.stop_event))
                if not self.stop_event.is_set():
                    log.warning("inline worker: telegram polling returned unexpectedly; restarting")
            except Exception as exc:  # noqa: BLE001
                log.exception("inline worker: telegram polling crashed: %s", exc)
            finally:
                loop.close()
            if self.stop_event.is_set():
                break
            attempt = min(attempt, 20)
            self.stop_event.wait(min(5 * attempt, 60))  # backoff, capped at a minute
        log.info("inline worker: telegram polling stopped")

    # ------------------------------------------------------------- lifecycle -----
    def start(self) -> None:
        if self.running:
            return
        self.stop_event.clear()
        self.started_at = time.time()
        self._thread = threading.Thread(target=self._loop, name="nexa-inline-worker", daemon=True)
        self._thread.start()
        if settings.telegram_enabled and settings.telegram_mode == "polling" and settings.telegram_bot_token:
            self._telegram_thread = threading.Thread(
                target=self._telegram_loop, name="nexa-telegram-poll", daemon=True
            )
            self._telegram_thread.start()
        else:
            log.info(
                "inline worker: telegram polling not started (enabled=%s, mode=%s)",
                settings.telegram_enabled, settings.telegram_mode,
            )

    def stop(self, timeout: float = 5.0) -> None:
        self.stop_event.set()
        for thread in (self._thread, self._telegram_thread):
            if thread and thread.is_alive():
                thread.join(timeout=timeout)


# The instance started by the application lifespan. Kept module-level so health
# endpoints and tests can inspect it without reaching into the FastAPI state.
_instance: InlineWorker | None = None


def should_start() -> bool:
    """Start only when the mode asks for it and we are not in a test run."""
    return bool(settings.inline_worker) and settings.environment != "test"


def start() -> InlineWorker | None:
    global _instance
    if not should_start():
        return None
    if _instance is None or not _instance.running:
        _instance = InlineWorker()
        _instance.start()
    return _instance


def stop() -> None:
    global _instance
    if _instance is not None:
        _instance.stop()
        _instance = None


def current() -> InlineWorker | None:
    return _instance
