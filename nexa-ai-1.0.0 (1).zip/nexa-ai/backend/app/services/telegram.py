"""Telegram bot: linking, welcome, guided commands and real model interaction.

How linking works (and why nothing secret ever travels through Telegram):

1. A signed-in user opens **Account → Telegram** and asks the site for a one-time link code.
   The site stores a short-lived, single-use code bound to that account.
2. The user opens the bot (``/start <code>`` deep link). The bot posts the code back to the
   platform, which validates it and stores the Telegram user id on the account — that is the
   "this Telegram id is registered on the site" check the product requires.
3. From then on every message from that Telegram id is resolved through ``telegram_links``
   to the platform account, so the bot acts *as that user*: same permissions, same credit
   balance, same rate limits, same model access rules, same usage history.

Nothing is bypassed: a Telegram message runs through ``ai_service.stream_chat`` exactly like a
web request, so it is charged to the same ledger, refused when the balance is empty and recorded
in the same usage table (module ``telegram``). A Telegram id that is not linked is told how to
link; it can never use somebody else's account.

Transports: long polling (default — works behind NAT, no public URL needed) and webhook (for
production domains). Both call the same handler.
"""
from __future__ import annotations

import datetime as dt
import html
import math
import json
import secrets
from typing import Any

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.errors import NexaError, ValidationError
from app.core.logging import get_logger
from app.db.session import SessionLocal
from app.models.chat import Conversation, Message, MessageRole
from app.models.provider import Model
from app.models.telegram import TelegramLink
from app.models.billing import CreditAccount
from app.models.user import User
from app.services import access as access_service
from app.services import ai as ai_service
from app.services import variants as variant_service

log = get_logger(__name__)

LINK_CODE_TTL_MINUTES = 15
MAX_TELEGRAM_MESSAGE = 4000          # Telegram's own limit is 4096
HELP_TEXT = (
    "🤖 <b>Nexa AI</b>\n\n"
    "دستورها / Commands:\n"
    "/help — همین راهنما / this guide\n"
    "/models — فهرست مدل‌های در دسترس / available models\n"
    "/use &lt;شماره&gt; — انتخاب مدل / select a model\n"
    "/variants — نسخه‌های یک مدل (پرامپت سیستمی) / model variants\n"
    "/usev &lt;شماره&gt; — انتخاب نسخه / select a variant\n"
    "/new — گفتگوی تازه / start a new conversation\n"
    "/balance — اعتبار / credit balance\n"
    "/usage — آخرین مصرف‌ها / recent usage\n"
    "/status — وضعیت حساب / account status\n\n"
    "هر پیام متنی دیگر مستقیماً به مدل انتخاب‌شده فرستاده می‌شود و از اعتبار حساب شما کسر می‌شود.\n"
    "Any other text message is sent to the selected model and charged to your balance."
)
WELCOME_TEXT = (
    "👋 خوش آمدید {name}!\n\n"
    "حساب شما به ربات وصل شد. مدل پیش‌فرض: <b>{model}</b>\n"
    "اعتبار فعلی: <b>{balance}</b>\n\n"
    + HELP_TEXT
)
MODELS_PER_PAGE = 20

LINK_REQUIRED_TEXT = (
    "🔗 این شناسه تلگرام به هیچ حسابی روی سایت وصل نیست.\n"
    "برای اتصال: وارد سایت شوید → «حساب من / پروفایل» → بخش <b>تلگرام</b> → ساخت کد اتصال → "
    "سپس دستور <code>/start &lt;کد&gt;</code> را همین‌جا بفرستید.\n\n"
    "This Telegram account is not linked yet. Sign in on the site → Profile → Telegram → create a "
    "link code → send <code>/start &lt;code&gt;</code> here."
)


# ---------------------------------------------------------------- API transport --
def api_base() -> str:
    return (settings.telegram_api_base or "https://api.telegram.org").rstrip("/")


def bot_token() -> str:
    return settings.telegram_bot_token or ""


def is_configured() -> bool:
    return bool(settings.telegram_enabled and bot_token())


async def call_api(method: str, payload: dict[str, Any], *, timeout: float = 40.0) -> dict[str, Any]:
    """Call one Telegram Bot API method. Raises ValidationError with the real reason."""
    if not bot_token():
        raise ValidationError("The Telegram bot token is not configured (NEXA_TELEGRAM_BOT_TOKEN).")
    url = f"{api_base()}/bot{bot_token()}/{method}"
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(url, json=payload)
    except Exception as exc:  # noqa: BLE001
        raise ValidationError(f"Telegram is unreachable: {type(exc).__name__}: {exc}") from exc
    try:
        data = response.json()
    except Exception:  # noqa: BLE001
        raise ValidationError(f"Telegram answered HTTP {response.status_code} with a non-JSON body.") from None
    if not data.get("ok"):
        raise ValidationError(f"Telegram refused {method}: {data.get('description') or data}")
    return data.get("result") or {}


async def send_message(chat_id: int | str, text: str, *, markdown: bool = True, reply_to: int | None = None) -> None:
    payload: dict[str, Any] = {
        "chat_id": chat_id,
        "text": text[:MAX_TELEGRAM_MESSAGE],
        "disable_web_page_preview": True,
    }
    if markdown:
        payload["parse_mode"] = "HTML"
    if reply_to:
        payload["reply_parameters"] = json.dumps({"message_id": reply_to})
    await call_api("sendMessage", payload)


async def send_typing(chat_id: int | str) -> None:
    try:
        await call_api("sendChatAction", {"chat_id": chat_id, "action": "typing"}, timeout=10)
    except NexaError:
        pass


async def get_me() -> dict[str, Any]:
    return await call_api("getMe", {})


async def delete_webhook() -> dict[str, Any]:
    return await call_api("deleteWebhook", {"drop_pending_updates": False})


# ---------------------------------------------------------------- linking -------
def create_link_code(db: Session, *, user: User) -> dict[str, Any]:
    """One-time, short-lived code the user pastes after /start."""
    code = secrets.token_urlsafe(9).replace("-", "").replace("_", "")[:12].upper()
    expires = dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=LINK_CODE_TTL_MINUTES)
    user.telegram_link_code = code
    user.telegram_link_code_expires_at = expires
    db.commit()
    bot_username = (settings.telegram_bot_username or "").lstrip("@")
    deep_link = f"https://t.me/{bot_username}?start={code}" if bot_username else ""
    return {
        "code": code,
        "expires_at": expires,
        "expires_in_minutes": LINK_CODE_TTL_MINUTES,
        "bot_username": bot_username or None,
        "deep_link": deep_link or None,
    }


def link_status(db: Session, *, user: User) -> dict[str, Any]:
    link = db.scalars(select(TelegramLink).where(TelegramLink.user_id == user.id)).first()
    return {
        "linked": bool(link and link.enabled),
        "telegram_user_id": link.telegram_user_id if link else None,
        "telegram_username": link.telegram_username if link else None,
        "linked_at": link.linked_at if link else None,
        "last_message_at": link.last_message_at if link else None,
        "message_count": link.message_count if link else 0,
        "bot_configured": is_configured(),
        "bot_username": settings.telegram_bot_username or None,
        "transport": settings.telegram_mode,
        "pending_code": bool(
            user.telegram_link_code
            and user.telegram_link_code_expires_at
            and user.telegram_link_code_expires_at > dt.datetime.now(dt.timezone.utc)
        ),
    }


def unlink(db: Session, *, user: User) -> dict[str, Any]:
    link = db.scalars(select(TelegramLink).where(TelegramLink.user_id == user.id)).first()
    if link is not None:
        db.delete(link)
        db.commit()
    user.telegram_link_code = None
    user.telegram_link_code_expires_at = None
    db.commit()
    return {"linked": False}


def consume_link_code(db: Session, *, code: str, telegram_user_id: int, chat_id: int,
                      username: str | None, first_name: str | None) -> User | None:
    """Bind a Telegram id to the account that owns the code. Returns the user or None."""
    cleaned = (code or "").strip().upper()
    if not cleaned:
        return None
    user = db.scalars(select(User).where(User.telegram_link_code == cleaned)).first()
    if user is None:
        return None
    if not user.telegram_link_code_expires_at or user.telegram_link_code_expires_at < dt.datetime.now(dt.timezone.utc):
        user.telegram_link_code = None
        user.telegram_link_code_expires_at = None
        db.commit()
        return None

    existing = db.scalars(select(TelegramLink).where(TelegramLink.telegram_user_id == telegram_user_id)).first()
    if existing is not None and existing.user_id != user.id:
        # the Telegram account moves to the account that just proved ownership with a fresh code
        db.delete(existing)
        db.flush()
    link = db.scalars(select(TelegramLink).where(TelegramLink.user_id == user.id)).first()
    if link is None:
        link = TelegramLink(user_id=user.id, telegram_user_id=telegram_user_id, chat_id=chat_id)
        db.add(link)
    link.telegram_user_id = telegram_user_id
    link.chat_id = chat_id
    link.telegram_username = username
    link.telegram_first_name = first_name
    link.enabled = True
    link.linked_at = dt.datetime.now(dt.timezone.utc)
    user.telegram_link_code = None
    user.telegram_link_code_expires_at = None
    db.commit()

    from app.services import audit as audit_service

    audit_service.record_audit(
        db,
        action="telegram.linked",
        summary=f"Telegram user {telegram_user_id} linked to {user.email}.",
        actor=user,
        entity_type="user",
        entity_id=user.id,
        after={"telegram_user_id": telegram_user_id, "username": username},
    )
    db.commit()
    return user


def resolve_user(db: Session, telegram_user_id: int) -> tuple[User | None, TelegramLink | None]:
    link = db.scalars(
        select(TelegramLink).where(TelegramLink.telegram_user_id == telegram_user_id, TelegramLink.enabled.is_(True))
    ).first()
    if link is None:
        return None, None
    user = db.get(User, link.user_id)
    if user is None or getattr(user, "status", "active") != "active":
        return None, link
    return user, link


# ---------------------------------------------------------------- chat state -----
def _state(link: TelegramLink) -> dict[str, Any]:
    return dict(link.state or {})


def _save_state(db: Session, link: TelegramLink, state: dict[str, Any]) -> None:
    link.state = state
    db.commit()


def _accessible_models(db: Session, user: User, limit: int | None = None) -> list[Model]:
    """Every model this user may use, in a stable order.

    This used to stop after 12 entries with nothing telling the user that a cap existed:
    a catalogue larger than that simply could not be reached from the bot. The full list
    is returned now and ``/models`` paginates it, always printing the real total.
    """
    rows = db.scalars(access_service.visible_models_query(user).order_by(Model.sort_order, Model.id)).all()
    models = access_service.filter_models_for_user(db, user, list(rows))
    return models[:limit] if limit is not None else models


def _balance_text(db: Session, user: User) -> str:
    from app.services.pricing import micro_to_credits

    account = db.scalars(select(CreditAccount).where(CreditAccount.user_id == user.id)).first()
    if account is None:
        return "0"
    return f"{micro_to_credits(account.balance_micro):,}"


def _conversation_for(db: Session, user: User, model: Model, link: TelegramLink) -> Conversation:
    state = _state(link)
    conversation_id = state.get("conversation_id")
    conversation = db.get(Conversation, conversation_id) if conversation_id else None
    if conversation is None or conversation.user_id != user.id or conversation.model_id != model.id:
        conversation = Conversation(
            user_id=user.id,
            title=f"Telegram · {model.display_name}"[:60],
            module="telegram",
            model_id=model.id,
        )
        db.add(conversation)
        db.flush()
        state["conversation_id"] = conversation.id
        _save_state(db, link, state)
        db.commit()
    return conversation


def _history(db: Session, conversation: Conversation, limit: int = 12) -> list[ai_service.ChatMessage]:
    rows = db.scalars(
        select(Message).where(Message.conversation_id == conversation.id).order_by(Message.id.desc()).limit(limit)
    ).all()
    history: list[ai_service.ChatMessage] = []
    for row in reversed(list(rows)):
        if row.role in (MessageRole.USER, MessageRole.ASSISTANT) and row.content:
            history.append(ai_service.ChatMessage(role=row.role, content=row.content))
    return history


# ---------------------------------------------------------------- the handler -----
async def handle_update(db: Session, update: dict[str, Any]) -> str:
    """Process one Telegram update. Returns a short label for logs/tests."""
    message = update.get("message") or update.get("edited_message") or {}
    chat = message.get("chat") or {}
    sender = message.get("from") or {}
    chat_id = chat.get("id")
    telegram_user_id = sender.get("id")
    text = (message.get("text") or "").strip()
    if not chat_id or not telegram_user_id or not text:
        return "ignored"

    if not is_configured():
        log.warning("telegram update received while the bot is not configured")
        return "not_configured"

    command, _, argument = text.partition(" ")
    command = command.split("@")[0].lower()

    # --- /start with a link code ------------------------------------------------
    if command == "/start":
        argument = argument.strip()
        if argument:
            user = consume_link_code(
                db,
                code=argument,
                telegram_user_id=int(telegram_user_id),
                chat_id=int(chat_id),
                username=sender.get("username"),
                first_name=sender.get("first_name"),
            )
            if user is None:
                await send_message(chat_id, "❌ کد اتصال نامعتبر یا منقضی شده است. کد تازه بسازید.\n"
                                            "Invalid or expired link code — create a new one on the site.")
                return "bad_link_code"
            link = db.scalars(select(TelegramLink).where(TelegramLink.user_id == user.id)).first()
            models = _accessible_models(db, user)
            model_name = models[0].display_name if models else "—"
            if link is not None and models:
                state = _state(link)
                state["model_id"] = models[0].id
                _save_state(db, link, state)
            await send_message(
                chat_id,
                WELCOME_TEXT.format(name=html.escape(user.display_name or user.email), model=html.escape(model_name),
                                    balance=_balance_text(db, user)),
            )
            return "linked"

    user, link = resolve_user(db, int(telegram_user_id))
    if user is None or link is None:
        await send_message(chat_id, LINK_REQUIRED_TEXT)
        return "unlinked"

    link.last_message_at = dt.datetime.now(dt.timezone.utc)
    link.message_count = (link.message_count or 0) + 1
    db.commit()

    if command in ("/help", "/commands"):
        await send_message(chat_id, HELP_TEXT)
        return "help"

    if command in ("/whoami", "/status"):
        models = _accessible_models(db, user)
        state = _state(link)
        current = next((m for m in models if m.id == state.get("model_id")), models[0] if models else None)
        await send_message(
            chat_id,
            "👤 <b>{email}</b>\n"
            "🎚 مدل فعلی / current model: <b>{model}</b>\n"
            "💳 اعتبار / balance: <b>{balance}</b>\n"
            "🔢 پیام‌ها / messages: {count}\n"
            "🛡 نقش‌ها / roles: {roles}".format(
                email=html.escape(user.email),
                model=html.escape(current.display_name if current else "—"),
                balance=_balance_text(db, user),
                count=link.message_count or 0,
                roles=html.escape(", ".join(r.slug for r in (user.roles or [])) or "user"),
            ),
        )
        return "status"

    if command == "/balance":
        await send_message(chat_id, f"💳 اعتبار شما / your balance: <b>{_balance_text(db, user)}</b> credits")
        return "balance"

    if command == "/usage":
        from app.models.billing import UsageRecord
        from app.services.pricing import micro_to_credits

        rows = db.scalars(
            select(UsageRecord).where(UsageRecord.user_id == user.id).order_by(UsageRecord.id.desc()).limit(8)
        ).all()
        if not rows:
            await send_message(chat_id, "هنوز مصرفی ثبت نشده / no usage recorded yet.")
            return "usage"
        lines = [
            f"• <code>{row.operation}</code> — {html.escape(row.provider_model_id or '')} — "
            f"{micro_to_credits(row.charged_micro or 0)} credits — {row.created_at:%Y-%m-%d %H:%M}"
            for row in rows
        ]
        await send_message(chat_id, "📊 آخرین مصرف‌ها / recent usage:\n" + "\n".join(lines))
        return "usage"

    if command in ("/models", "/model"):
        models = _accessible_models(db, user)
        if not models:
            await send_message(chat_id, "هیچ مدلی برای حساب شما منتشر نشده است / no model is available for your account.")
            return "models"
        pages = max(1, math.ceil(len(models) / MODELS_PER_PAGE))
        try:
            page = int(argument.strip()) if argument.strip() else 1
        except ValueError:
            page = 1
        page = min(max(page, 1), pages)
        start = (page - 1) * MODELS_PER_PAGE
        state = _state(link)
        lines = []
        for number, model in enumerate(models[start:start + MODELS_PER_PAGE], start=start + 1):
            mark = "✅" if model.id == state.get("model_id") else "▫️"
            lines.append(f"{mark} {number}. <b>{html.escape(model.display_name)}</b> ({html.escape(model.provider_model_id)})")
        footer = [f"📄 صفحه {page} از {pages} — مجموع {len(models)} مدل / page {page} of {pages}, {len(models)} models"]
        if page < pages:
            footer.append(f"صفحهٔ بعد / next page: /models {page + 1}")
        if page > 1:
            footer.append(f"صفحهٔ قبل / previous page: /models {page - 1}")
        footer.append("با /use &lt;شماره&gt; انتخاب کنید / pick one with /use &lt;number&gt;.")
        await send_message(chat_id, "🧠 مدل‌های در دسترس / available models:\n" + "\n".join(lines) + "\n\n" + "\n".join(footer))
        return "models"

    if command == "/use":
        models = _accessible_models(db, user)
        try:
            index = int(argument.strip())
        except ValueError:
            await send_message(chat_id, "شمارهٔ مدل را بفرستید، مثلاً /use 2\nSend the number, e.g. /use 2")
            return "use_bad"
        if not 1 <= index <= len(models):
            await send_message(
                chat_id,
                f"شمارهٔ نامعتبر — بین ۱ تا {len(models)} (همان شماره‌ای که /models نشان می‌دهد).\n"
                f"Invalid number — pick 1…{len(models)}, exactly as numbered by /models.",
            )
            return "use_bad"
        model = models[index - 1]
        state = _state(link)
        state["model_id"] = model.id
        state.pop("conversation_id", None)
        state.pop("variant_id", None)
        _save_state(db, link, state)
        variants = variant_service.list_variants(db, model_id=model.id, actor=user)
        extra = ""
        if variants:
            names = ", ".join(f"{v.name}" for v in variants[:8])
            extra = f"\n🎛 نسخه‌ها / variants: {html.escape(names)}\nبا /variants و /usev <شماره> انتخاب کنید."
        await send_message(chat_id, f"✅ مدل انتخاب شد / model selected: <b>{html.escape(model.display_name)}</b>{extra}")
        return "use"

    if command == "/variants":
        state = _state(link)
        models = _accessible_models(db, user)
        model = next((m for m in models if m.id == state.get("model_id")), models[0] if models else None)
        if model is None:
            await send_message(chat_id, "ابتدا یک مدل انتخاب کنید / select a model first (/models).")
            return "variants"
        variants = variant_service.list_variants(db, model_id=model.id, actor=user)
        if not variants:
            await send_message(chat_id, f"برای «{html.escape(model.display_name)}» نسخه‌ای تعریف نشده است.\n"
                                        "No variant is defined for this model.")
            return "variants"
        lines = ["▫️ 0. مدل خام (بدون پرامپت سیستمی) / raw model"]
        for index, variant in enumerate(variants, start=1):
            mark = "✅" if variant.id == state.get("variant_id") else "▫️"
            emoji = f"{variant.emoji} " if variant.emoji else ""
            lines.append(f"{mark} {index}. {emoji}<b>{html.escape(variant.name)}</b> — "
                         f"{html.escape((variant.description or '')[:60])}")
        await send_message(chat_id, "🎛 نسخه‌های این مدل / variants:\n" + "\n".join(lines) + "\n\n/usev &lt;شماره&gt;")
        return "variants"

    if command == "/usev":
        state = _state(link)
        models = _accessible_models(db, user)
        model = next((m for m in models if m.id == state.get("model_id")), models[0] if models else None)
        if model is None:
            await send_message(chat_id, "ابتدا یک مدل انتخاب کنید / select a model first.")
            return "usev"
        variants = variant_service.list_variants(db, model_id=model.id, actor=user)
        try:
            index = int(argument.strip())
        except ValueError:
            await send_message(chat_id, "شمارهٔ نسخه را بفرستید، مثلاً /usev 1")
            return "usev_bad"
        if index == 0:
            state.pop("variant_id", None)
            state.pop("conversation_id", None)
            _save_state(db, link, state)
            await send_message(chat_id, "✅ حالت خام مدل فعال شد / raw model selected.")
            return "usev"
        if not 1 <= index <= len(variants):
            await send_message(chat_id, f"شمارهٔ نامعتبر. بین ۱ تا {len(variants)}.")
            return "usev_bad"
        variant = variants[index - 1]
        state["variant_id"] = variant.id
        state.pop("conversation_id", None)
        _save_state(db, link, state)
        await send_message(
            chat_id,
            f"✅ نسخه انتخاب شد / variant selected: <b>{html.escape(variant.name)}</b>\n"
            f"🧩 پرامپت سیستمی / system prompt: {len(variant.system_prompt or '')} کاراکتر",
        )
        return "usev"

    if command == "/new":
        state = _state(link)
        state.pop("conversation_id", None)
        _save_state(db, link, state)
        await send_message(chat_id, "🆕 گفتگوی تازه آماده است. پیام بعدی شما شروع می‌کند.\nNew conversation ready.")
        return "new"

    if command.startswith("/"):
        await send_message(chat_id, "دستور ناشناخته. /help را بفرستید.\nUnknown command — send /help.")
        return "unknown_command"

    # --- free text: a real model call, charged to the same account -----------
    models = _accessible_models(db, user)
    if not models:
        await send_message(chat_id, "⚠️ برای حساب شما مدلی منتشر نشده است. با مدیر تماس بگیرید.\n"
                                    "No model is published for your account — contact the administrator.")
        return "no_model"
    state = _state(link)
    model = next((m for m in models if m.id == state.get("model_id")), models[0])
    variant = None
    if state.get("variant_id"):
        try:
            variant = variant_service.resolve_for_request(db, model=model, user=user, variant_id=state["variant_id"])
        except ValidationError as exc:
            state.pop("variant_id", None)
            _save_state(db, link, state)
            await send_message(chat_id, f"⚠️ {html.escape(exc.detail)}")
    conversation = _conversation_for(db, user, model, link)
    if variant is not None:
        conversation.variant_id = variant.id
        db.commit()

    await send_typing(chat_id)
    try:
        ref = ai_service.resolve_model(db, user=user, model_id=model.id, operation="chat")
    except NexaError as exc:
        await send_message(chat_id, f"⛔️ {html.escape(exc.detail)}")
        return "not_allowed"

    user_message = Message(
        conversation_id=conversation.id,
        user_id=user.id,
        role=MessageRole.USER,
        content=text,
        model_id=model.id,
    )
    db.add(user_message)
    db.flush()

    answer_parts: list[str] = []
    charge_note = ""
    error_note = ""
    async for event in ai_service.stream_chat(
        db,
        user=user,
        model_ref=ref,
        messages=_history(db, conversation) or [ai_service.ChatMessage(role="user", content=text)],
        system=variant_service.system_prompt_for(variant),
        temperature=float(variant.default_temperature) if variant and variant.default_temperature is not None else None,
        max_tokens=variant.default_max_tokens if variant else None,
        module="telegram",
        conversation_id=conversation.id,
        variant_id=variant.id if variant else None,
        idempotency_key=f"telegram:{user_message.id}",
    ):
        if event.type == "delta":
            answer_parts.append(event.data.get("text", ""))
        elif event.type == "done":
            from app.services.pricing import micro_to_credits

            charged = event.data.get("charged_micro") or 0
            charge_note = f"\n\n— {micro_to_credits(charged)} credits" if charged else ""
        elif event.type == "error":
            error_note = event.data.get("message") or "provider failure"
            category = event.data.get("category")

    answer = "".join(answer_parts).strip()
    assistant = Message(
        conversation_id=conversation.id,
        user_id=user.id,
        role=MessageRole.ASSISTANT,
        content=answer,
        model_id=model.id,
        error_category=None if answer else error_note or "unknown",
    )
    db.add(assistant)
    conversation.message_count = (conversation.message_count or 0) + 1
    db.commit()

    if not answer:
        await send_message(chat_id, f"⚠️ پاسخ سرویس‌دهنده دریافت نشد / no answer from the provider:\n{html.escape(error_note)}")
        return "provider_error"
    await send_message(chat_id, html.escape(answer) + charge_note)
    return "chat"


# ---------------------------------------------------------------- transports -----
async def process_updates(offset: int | None = None, *, limit: int = 20, timeout: int = 30) -> tuple[int, int]:
    """One getUpdates round. Returns (next_offset, handled_count)."""
    payload: dict[str, Any] = {"timeout": timeout, "limit": limit, "allowed_updates": ["message", "edited_message"]}
    if offset is not None:
        payload["offset"] = offset
    updates = await call_api("getUpdates", payload, timeout=timeout + 15)
    handled = 0
    next_offset = offset or 0
    for update in updates:
        next_offset = max(next_offset, int(update.get("update_id", 0)) + 1)
        db = SessionLocal()
        try:
            result = await handle_update(db, update)
            handled += 1
            log.info("telegram update %s -> %s", update.get("update_id"), result)
        except Exception as exc:  # noqa: BLE001
            db.rollback()
            log.exception("telegram update failed: %s", exc)
        finally:
            db.close()
    return next_offset, handled


async def run_polling(stop_event) -> None:  # noqa: ANN001
    """Long-polling loop (used by the worker when NEXA_TELEGRAM_MODE=polling)."""
    offset: int | None = None
    try:
        await delete_webhook()
    except NexaError as exc:
        log.warning("could not clear an existing Telegram webhook: %s", exc)
    while not stop_event.is_set():
        try:
            offset, handled = await process_updates(offset)
            if handled:
                log.info("telegram: handled %s update(s)", handled)
        except NexaError as exc:
            log.warning("telegram polling: %s", exc)
            await _sleep(stop_event, 5)
        except Exception as exc:  # noqa: BLE001
            log.exception("telegram polling crashed: %s", exc)
            await _sleep(stop_event, 5)


async def _sleep(stop_event, seconds: float) -> None:  # noqa: ANN001
    """Sleep for `seconds`, waking early when the stop signal fires.

    The stop signal arrives as a `threading.Event` from both entry points (the worker
    process and the API's inline worker), and as an `asyncio.Event` from async callers.
    `threading.Event.wait()` returns a *bool* and cannot be awaited: awaiting it raised
    "object bool can't be used in 'await' expression", which killed the polling loop at
    the first transient network error. Both kinds are handled here.
    """
    import asyncio
    import inspect
    import threading

    if stop_event is None:
        await asyncio.sleep(seconds)
        return

    waiter = getattr(stop_event, "wait", None)
    if waiter is None:
        await asyncio.sleep(seconds)
        return

    if isinstance(stop_event, threading.Event):
        # Never call the blocking wait on the loop thread.
        await asyncio.get_running_loop().run_in_executor(None, waiter, seconds)
        return

    try:
        outcome = waiter(seconds)
    except TypeError:
        # asyncio.Event.wait() takes no timeout and returns a coroutine.
        outcome = waiter()

    if inspect.isawaitable(outcome):
        try:
            await asyncio.wait_for(outcome, timeout=seconds)
        except asyncio.TimeoutError:
            pass
        return


async def set_webhook(url: str) -> dict[str, Any]:
    payload: dict[str, Any] = {"url": url, "allowed_updates": ["message", "edited_message"]}
    if settings.telegram_webhook_secret:
        payload["secret_token"] = settings.telegram_webhook_secret
    return await call_api("setWebhook", payload)
