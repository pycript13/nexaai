"""Runtime-editable settings (stored in ``app_settings``).

Values are stored as ``{"value": ...}`` JSON. Only non-secret operational
settings belong here — credentials stay in the environment or encrypted
provider records.
"""
from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.admin import AppSetting
from app.services import audit as audit_service


def get_value(db: Session, key: str, default: Any = None) -> Any:
    row = db.scalars(select(AppSetting).where(AppSetting.key == key)).first()
    if row is None or row.value_json is None:
        return default
    if isinstance(row.value_json, dict) and "value" in row.value_json:
        return row.value_json["value"]
    return row.value_json


def set_value(db: Session, key: str, value: Any, *, actor=None, commit: bool = True) -> AppSetting:  # noqa: ANN001
    row = db.scalars(select(AppSetting).where(AppSetting.key == key)).first()
    before = get_value(db, key)
    if row is None:
        row = AppSetting(key=key, value_json={"value": value}, category="general", label=key)
        db.add(row)
    else:
        row.value_json = {"value": value}
    row.updated_by_id = actor.id if actor else None
    row.updated_at = __import__("datetime").datetime.now(__import__("datetime").timezone.utc)
    db.flush()
    audit_service.record_audit(
        db, action="settings.updated", summary=f"Setting '{key}' updated.",
        actor=actor, entity_type="setting", entity_id=key, before={"value": _safe(before)}, after={"value": _safe(value)},
    )
    if commit:
        db.commit()
    return row


def _safe(value: Any) -> Any:
    text = str(value)
    if any(marker in text.lower() for marker in ("password", "secret", "key=", "token")):
        return "***redacted***"
    return value[:200] if isinstance(text, str) else value


def all_settings(db: Session, *, public_only: bool = False) -> list[dict[str, Any]]:
    stmt = select(AppSetting).order_by(AppSetting.category, AppSetting.key)
    if public_only:
        stmt = stmt.where(AppSetting.is_public.is_(True))
    return [
        {
            "key": row.key,
            "value": get_value(db, row.key),
            "category": row.category,
            "label": row.label,
            "description": row.description,
            "is_public": row.is_public,
            "updated_at": row.updated_at,
        }
        for row in db.scalars(stmt).all()
    ]


def public_settings(db: Session) -> dict[str, Any]:
    return {item["key"]: item["value"] for item in all_settings(db, public_only=True)}
