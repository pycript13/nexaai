"""Operational CLI: password recovery, credential audit and diagnostics.

The installer relies on `create-admin` and `reset-password` when an `.env` was replaced or an
operator is locked out, and on `check-secrets` to tell the operator that stored provider
credentials became unreadable — so these commands are part of the supported surface, not a
developer aid.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import uuid

import pytest
from sqlalchemy import select

from app.core.crypto import hash_password, password_policy_errors, verify_password
from app.core.security import hash_session_token
from app.models.admin import AuditEvent
from app.models.user import Role, User, UserSession


def _run(capsys, *argv: str) -> tuple[int, str, str]:
    """Invoke the CLI in-process; argparse itself raises SystemExit for --help."""
    from app.cli import main

    try:
        code = main(list(argv))
    except SystemExit as exc:  # --help / bad usage
        code = int(exc.code or 0)
    captured = capsys.readouterr()
    return code, captured.out, captured.err


@pytest.fixture()
def admin_user(db):
    """An account that acts as the operator's own administrator (unique per test)."""
    email = f"owner-{uuid.uuid4().hex[:8]}@example.com"
    user = User(
        email=email,
        display_name="Owner",
        password_hash=hash_password("Old-Owner-Passw0rd!"),
        status="active",
        email_verified=True,
        must_change_password=False,
    )
    role = db.scalars(select(Role).where(Role.slug == "super_admin")).first()
    if role is not None:
        user.roles.append(role)
    db.add(user)
    db.commit()
    return user


def test_cli_help_lists_the_operational_commands(capsys):
    code, out, _ = _run(capsys, "--help")
    assert code == 0
    for command in ("bootstrap", "create-admin", "reset-password", "grant-credits", "doctor", "check-secrets"):
        assert command in out


def test_reset_password_changes_the_hash_and_revokes_sessions(capsys, db, admin_user):
    db.add(
        UserSession(
            user_id=admin_user.id,
            token_hash=hash_session_token("live-token"),
            expires_at=dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=1),
        )
    )
    db.commit()

    code, out, err = _run(
        capsys, "reset-password", "--email", admin_user.email, "--password", "New-Owner-Passw0rd-2026!"
    )
    assert code == 0, err
    payload = json.loads(out)
    assert payload["email"] == admin_user.email
    assert payload["sessions_revoked"] >= 1
    assert "generated_password" not in payload

    db.expire_all()
    stored = db.scalars(select(User).where(User.email == admin_user.email)).first()
    assert verify_password("New-Owner-Passw0rd-2026!", stored.password_hash)
    assert not verify_password("Old-Owner-Passw0rd!", stored.password_hash)
    assert stored.must_change_password is False

    sessions = db.scalars(select(UserSession).where(UserSession.user_id == admin_user.id)).all()
    assert sessions and all(session.revoked_at is not None for session in sessions)
    assert {session.revoked_reason for session in sessions} == {"password_reset"}

    audit = db.scalars(select(AuditEvent).where(AuditEvent.action == "user.password_reset")).all()
    assert audit, "the reset must be audited"


def test_reset_password_can_generate_and_force_change(capsys, db, admin_user):
    code, out, err = _run(capsys, "reset-password", "--email", admin_user.email, "--generate", "--must-change")
    assert code == 0, err
    payload = json.loads(out)
    generated = payload["generated_password"]
    assert len(generated) >= 16

    db.expire_all()
    stored = db.scalars(select(User).where(User.email == admin_user.email)).first()
    assert verify_password(generated, stored.password_hash)
    assert stored.must_change_password is True


def test_reset_password_rejects_weak_input(capsys, db, admin_user):
    code, _, err = _run(capsys, "reset-password", "--email", admin_user.email, "--password", "short")
    assert code == 2
    assert "Password rejected" in err


def test_check_secrets_reports_credentials_encrypted_with_another_key(capsys, db):
    """A rotated NEXA_ENCRYPTION_KEY makes old ciphertexts unreadable — the CLI must say so."""
    from app.core.crypto import encrypt_secret
    from app.models.provider import Provider

    healthy = Provider(slug=f"ok-{uuid.uuid4().hex[:6]}", name="Readable provider",
                       api_key_encrypted=encrypt_secret("sk-live-readable"), enabled=False)
    broken = Provider(slug=f"stale-{uuid.uuid4().hex[:6]}", name="Stale provider",
                      api_key_encrypted="gAAAAABm-not-a-real-fernet-token", enabled=False)
    db.add_all([healthy, broken])
    db.commit()

    code, out, _ = _run(capsys, "check-secrets")
    report = json.loads(out)
    assert code == 3, "an unreadable credential must make the command fail loudly"
    assert report["unreadable"] >= 1
    assert report["readable"] >= 1, "the readable provider must not be blamed"
    assert "Stale provider" in [detail["provider"] for detail in report["details"]]


def test_check_secrets_exit_code_matches_its_own_report(capsys, db):
    """The installer reads this JSON and the exit code, so they must never disagree."""
    from app.core.crypto import encrypt_secret
    from app.models.provider import Provider

    db.add(Provider(slug=f"fine-{uuid.uuid4().hex[:6]}", name="Fine provider",
                    api_key_encrypted=encrypt_secret("sk-live-fine"), enabled=False))
    db.commit()

    code, out, _ = _run(capsys, "check-secrets")
    report = json.loads(out)
    assert report["credentials"] >= 1
    assert report["credentials"] == report["readable"] + report["unreadable"]
    assert code == (3 if report["unreadable"] else 0)


def test_reset_password_unknown_account_fails(capsys, db):
    code, _, err = _run(capsys, "reset-password", "--email", "nobody@example.com", "--password", "Some-Str0ng-Pass-2026!")
    assert code == 1
    assert "not found" in err


def test_create_admin_refuses_duplicates(capsys, db, admin_user):
    code, _, err = _run(
        capsys, "create-admin", "--email", admin_user.email, "--password", "Another-Str0ng-Pass-1!", "--name", "Copy"
    )
    assert code == 1
    assert "already exists" in err


def test_create_admin_creates_a_usable_account(capsys, db):
    email = f"second-{uuid.uuid4().hex[:8]}@example.com"
    code, out, err = _run(capsys, "create-admin", "--email", email, "--password", "Second-Str0ng-Pass-1!", "--name", "Second")
    assert code == 0, err
    payload = json.loads(out)
    assert payload["created"] is True and payload["email"] == email

    db.expire_all()
    created = db.scalars(select(User).where(User.email == email)).first()
    assert created is not None and verify_password("Second-Str0ng-Pass-1!", created.password_hash)
    assert any(role.slug == "admin" for role in created.roles)


def test_reset_password_clears_the_lockout_and_the_failure_counter(capsys, db, admin_user):
    """The operator's unlock path must clear *both* signs of a locked account.

    ``reset-password`` used to assign ``user.failed_login_attempts``, which is not a mapped
    attribute: SQLAlchemy accepts the assignment silently (it becomes a plain instance attribute),
    so the counter was never cleared and nobody noticed. The lockout check reads
    ``locked_until``, and the counter feeds the sign-in audit trail — clear both.
    """
    admin_user.failed_login_count = 3
    admin_user.locked_until = dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=15)
    db.commit()

    code, out, err = _run(
        capsys, "reset-password", "--email", admin_user.email, "--password", "Unlocked-Owner-2026!"
    )
    assert code == 0, err
    assert json.loads(out)["email"] == admin_user.email

    db.expire_all()
    stored = db.scalars(select(User).where(User.email == admin_user.email)).first()
    assert stored.locked_until is None, "the lockout survived reset-password"
    assert stored.failed_login_count == 0, "the failed-sign-in counter survived reset-password"


def test_no_app_code_assigns_unknown_user_attributes():
    """Guard against the class of bug above: a silently ignored attribute assignment.

    Every ``<something>.<name> = ...`` in ``app/`` where the target is a *user row* is scanned
    against the mapped attributes of the ORM class. Only assignments that mention ``user`` (the
    conventional variable name for a ``User`` row in this code base) are checked, so the scan stays
    precise instead of guessing types.
    """
    import ast
    from pathlib import Path as _Path

    from app.models.user import User

    mapped = {attr.key for attr in User.__mapper__.attrs}
    app_dir = _Path(__file__).resolve().parent.parent / "app"
    offenders: list[str] = []
    for path in sorted(app_dir.rglob("*.py")):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if not isinstance(node, ast.Assign):
                continue
            for target in node.targets:
                if (
                    isinstance(target, ast.Attribute)
                    and isinstance(target.value, ast.Name)
                    and target.value.id in {"user", "fresh_user"}
                    and target.attr not in mapped
                    and not target.attr.startswith("_")
                ):
                    offenders.append(f"{path.name}:{node.lineno} {target.value.id}.{target.attr}")
    assert not offenders, (
        "these assignments look like User rows but the attribute is not mapped (SQLAlchemy would "
        "silently ignore them): " + ", ".join(offenders)
    )


def test_unreadable_env_file_refuses_to_start_with_a_fixable_message(tmp_path, monkeypatch):
    """An operator must never be left with a bare PermissionError traceback.

    Replacing `.env` as root (`sudo mv`, `sudo cp`) leaves the file unreadable for the service
    user. The app must say which file and which chown/chmod fixes it — systemd keeps reporting the
    unit as active while every worker dies, so a silent failure is not acceptable.
    """
    # Point the settings loader at a directory whose .env exists but cannot be read
    env_dir = tmp_path / "app-dir"
    env_dir.mkdir()
    env_file = env_dir / ".env"
    env_file.write_text("NEXA_ENVIRONMENT=production\n", encoding="utf-8")
    env_file.chmod(0o000)
    if os.access(env_file, os.R_OK):  # running as root: permissions are not enforced
        pytest.skip("cannot simulate an unreadable file as root")

    monkeypatch.chdir(env_dir)
    from app.core import config as config_module

    config_module.reset_settings_cache()
    with pytest.raises(SystemExit) as excinfo:
        config_module.get_settings()
    message = str(excinfo.value)
    assert ".env" in message and ("chown" in message or "chmod" in message), message


def test_create_admin_generates_a_password_when_asked_and_prints_it_once(capsys, db):
    """`create-admin --generate` is what set_admin.bat uses on Windows.

    The password must never require a flag value (a command line is readable by other processes),
    it must satisfy the application's own policy, and it must be printed exactly once so the
    operator can save it.
    """
    email = f"generated-{uuid.uuid4().hex[:8]}@example.com"
    code, out, err = _run(capsys, "create-admin", "--email", email, "--name", "Generated Admin", "--generate")
    assert code == 0, err
    payload = json.loads(out)
    password = payload.get("generated_password")
    assert password and len(password) >= 10, "no generated password was reported"
    assert not password_policy_errors(password, email=email, name="Generated Admin")

    db.expire_all()
    stored = db.scalars(select(User).where(User.email == email)).first()
    assert stored is not None and verify_password(password, stored.password_hash)
    assert "generated_password" not in json.dumps(_run(capsys, "create-admin", "--email", email, "--name", "x")[1] or "")


def test_create_admin_takes_the_password_from_the_environment(monkeypatch, capsys, db):
    """`NEXA_ADMIN_PASSWORD` keeps the value out of the process list (used by the Windows helper)."""
    email = f"envadmin-{uuid.uuid4().hex[:8]}@example.com"
    monkeypatch.setenv("NEXA_ADMIN_PASSWORD", "Env-Supplied-Passw0rd-2026!")
    code, out, err = _run(capsys, "create-admin", "--email", email, "--name", "Env Admin")
    assert code == 0, err
    assert "generated_password" not in out, "an explicitly supplied password must not be echoed"
    db.expire_all()
    stored = db.scalars(select(User).where(User.email == email)).first()
    assert stored is not None and verify_password("Env-Supplied-Passw0rd-2026!", stored.password_hash)
