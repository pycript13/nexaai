"""Shared pytest fixtures.

The suite runs against a temporary SQLite database with an isolated upload
directory. Provider HTTP calls are served by an ``httpx.MockTransport`` so that
adapter behaviour (including error categorisation and streaming) is exercised
deterministically without network access or credentials.
"""
from __future__ import annotations

import json
import os
import shutil
import socket
import tempfile
from collections.abc import Iterator
from pathlib import Path
from typing import Any, Callable

import pytest

# --- environment must be configured before importing the app -------------------
TMP_ROOT = Path(tempfile.mkdtemp(prefix="nexa-tests-"))
os.environ.update(
    {
        "NEXA_ENVIRONMENT": "test",
        "NEXA_DATABASE_URL": f"sqlite:///{TMP_ROOT / 'test.db'}",
        "NEXA_UPLOAD_DIR": str(TMP_ROOT / "uploads"),
        "NEXA_SECRET_KEY": "test-secret-key-that-is-long-enough-for-tests-0123456789",
        "NEXA_ENCRYPTION_KEY": "",
        "NEXA_REDIS_URL": "",
        "NEXA_RATE_LIMIT_ENABLED": "true",
        "NEXA_AUTH_RATE_LIMIT_PER_MINUTE": "1000",
        "NEXA_API_RATE_LIMIT_PER_MINUTE": "1000",
        "NEXA_DEPLOYMENT_MODE": "local",
        "NEXA_PUBLIC_BASE_URL": "http://testserver",
        "NEXA_TRUSTED_HOSTS": "*",
        "NEXA_CORS_ORIGINS": "http://testserver",
        "NEXA_BOOTSTRAP_ADMIN_EMAIL": "admin@nexatest.io",
        "NEXA_BOOTSTRAP_ADMIN_PASSWORD": "Admin-Test-Password-1",
        "NEXA_BOOTSTRAP_ADMIN_NAME": "Test Administrator",
        "NEXA_INLINE_WORKER": "true",
        "NEXA_EMAIL_ENABLED": "false",
        "NEXA_MANUAL_PAYMENTS_ENABLED": "true",
        "NEXA_MINIMUM_CHARGE_MICRO": "1000",
        "NEXA_LOG_LEVEL": "WARNING",
    }
)

from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy.orm import Session  # noqa: E402

from app.core.config import reset_settings_cache  # noqa: E402
from app.db.base import Base  # noqa: E402
from app.db.session import SessionLocal, get_engine, reset_engine  # noqa: E402
from app.main import app  # noqa: E402
from app.services.bootstrap import run_bootstrap  # noqa: E402

reset_settings_cache()
reset_engine()


@pytest.fixture(scope="session", autouse=True)
def _hermetic_dns() -> Iterator[None]:
    """Resolve any hostname to a public IP so SSRF checks never depend on real DNS.

    SSRF tests that need a *private* resolution re-patch ``socket.getaddrinfo``
    locally, and literal private IPs are blocked before DNS is consulted at all.
    """
    original = socket.getaddrinfo

    def fake_getaddrinfo(host, port, *args, **kwargs):  # noqa: ANN001, ANN202
        if host in ("localhost", "localhost.localdomain"):
            return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("127.0.0.1", port or 0))]
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", port or 0))]

    socket.getaddrinfo = fake_getaddrinfo  # type: ignore[assignment]
    yield
    socket.getaddrinfo = original  # type: ignore[assignment]


@pytest.fixture(scope="session", autouse=True)
def _prepare_database() -> Iterator[None]:
    engine = get_engine()
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        run_bootstrap(db, admin_email="admin@nexatest.io", admin_password="Admin-Test-Password-1", admin_name="Test Administrator")
    yield
    engine.dispose()


@pytest.fixture(scope="session")
def client() -> Iterator[TestClient]:
    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture(autouse=True)
def _fresh_cookies(client: TestClient) -> Iterator[None]:
    """Each test starts without inherited browser cookies (cookie auth + CSRF)."""
    client.cookies.clear()
    yield
    client.cookies.clear()


@pytest.fixture()
def db() -> Iterator[Session]:
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


# ---------------------------------------------------------------- auth helpers --
class AuthSession:
    """An independent browser-like session.

    Each AuthSession keeps its *own* cookie jar so that tests which act as two
    different users (admin + regular user) never leak cookies into each other.
    """

    def __init__(self, client: TestClient, email: str, password: str) -> None:
        self.client = client
        self.email = email
        self.password = password
        self.headers: dict[str, str] = {}
        self.cookies: dict[str, str] = {}

    def login(self) -> dict[str, Any]:
        response = self.client.post("/api/v1/auth/login", json={"email": self.email, "password": self.password})
        assert response.status_code == 200, response.text
        data = response.json()
        self.headers = {"x-csrf-token": data["csrf_token"]}
        self.cookies = dict(response.cookies)
        self.client.cookies.clear()  # never leak this session into the shared jar
        return data

    def request(self, method: str, url: str, **kwargs: Any):  # noqa: ANN201
        headers = {**self.headers, **kwargs.pop("headers", {})}
        cookies = kwargs.pop("cookies", self.cookies)
        return self.client.request(method, url, headers=headers, cookies=cookies, **kwargs)

    def get(self, url: str, **kwargs: Any):  # noqa: ANN201
        return self.request("GET", url, **kwargs)

    def stream(self, method: str, url: str, **kwargs: Any):  # noqa: ANN201
        """Streaming requests (SSE) keep this session's cookies and CSRF header."""
        headers = {**self.headers, **kwargs.pop("headers", {})}
        cookies = kwargs.pop("cookies", self.cookies)
        return self.client.stream(method, url, headers=headers, cookies=cookies, **kwargs)

    def post(self, url: str, **kwargs: Any):  # noqa: ANN201
        return self.request("POST", url, **kwargs)

    def patch(self, url: str, **kwargs: Any):  # noqa: ANN201
        return self.request("PATCH", url, **kwargs)

    def delete(self, url: str, **kwargs: Any):  # noqa: ANN201
        return self.request("DELETE", url, **kwargs)


def _register(client: TestClient, email: str, password: str = "Tester-Password-99", name: str = "Tester") -> AuthSession:
    response = client.post(
        "/api/v1/auth/register",
        json={
            "email": email,
            "password": password,
            "display_name": name,
            "accept_terms": True,
            "accept_privacy": True,
        },
    )
    assert response.status_code in (201, 409), response.text
    return AuthSession(client, email, password)


@pytest.fixture()
def admin_client(client: TestClient) -> AuthSession:
    session = AuthSession(client, "admin@nexatest.io", "Admin-Test-Password-1")
    session.login()
    return session


@pytest.fixture()
def user_client(client: TestClient) -> AuthSession:
    session = _register(client, f"user{socket.gethostname()[:3]}{os.urandom(4).hex()}@nexatest.io")
    session.login()
    return session


@pytest.fixture()
def second_user_client(client: TestClient) -> AuthSession:
    session = _register(client, f"other{os.urandom(4).hex()}@nexatest.io")
    session.login()
    return session


# ------------------------------------------------------------- provider mocks --
@pytest.fixture()
def mock_provider_transport() -> Iterator[Callable[[Callable], None]]:
    """Install an httpx.MockTransport handler for outbound provider calls."""
    import app.providers.http as http_module
    import httpx

    handlers: list[Callable[[httpx.Request], httpx.Response]] = []

    def install(handler: Callable[[httpx.Request], httpx.Response]) -> None:
        handlers.append(handler)

        def dispatch(request: httpx.Request) -> httpx.Response:
            return handler(request)

        http_module.TRANSPORT_FACTORY = lambda: httpx.MockTransport(dispatch)

    yield install
    http_module.TRANSPORT_FACTORY = None


def create_provider_and_model(
    db: Session,
    *,
    provider_type: str = "openai_compatible",
    base_url: str = "https://provider.example.com/v1",
    api_key: str = "sk-test-key-1234567890",
    capabilities: list[str] | None = None,
    visibility: str = "public",
    published: bool = True,
    access_tier: str = "credit",
    enabled: bool = True,
    provider_enabled: bool = True,
    model_id_str: str = "test-model-1",
    display_name: str = "Test Model 1",
    name_suffix: str = "",
    input_price: float | None = 3.0,
    output_price: float | None = 15.0,
):  # noqa: ANN201
    from app.core.crypto import encrypt_secret
    from app.models.provider import Model, Provider

    slug = f"{provider_type}-{os.urandom(3).hex()}{('-' + name_suffix) if name_suffix else ''}"
    provider = Provider(
        slug=slug,
        name=f"Test {provider_type} {slug[-4:]}",
        provider_type=provider_type,
        base_url=base_url,
        api_key_encrypted=encrypt_secret(api_key),
        api_key_hint="sk-********7890",
        enabled=provider_enabled,
        connect_timeout=5,
        read_timeout=10,
        max_retries=1,
    )
    db.add(provider)
    db.flush()
    model = Model(
        provider_id=provider.id,
        provider_model_id=model_id_str,
        display_name=display_name,
        capabilities=capabilities if capabilities is not None else ["chat", "streaming"],
        input_modalities=["text"],
        output_modalities=["text"],
        supports_streaming=True,
        supports_vision=False,
        visibility=visibility,
        availability="available",
        access_tier=access_tier,
        enabled=enabled,
        published=published,
        selling_input_per_mtok=input_price,
        selling_output_per_mtok=output_price,
        provider_cost_input_per_mtok=0.5,
        provider_cost_output_per_mtok=1.5,
        pricing_uncertain=False,
    )
    db.add(model)
    db.commit()
    return provider, model


def grant_credits(db: Session, email: str, credits: float, *, key: str | None = None) -> int:
    from sqlalchemy import select

    from app.models.user import User
    from app.services import ledger as ledger_service

    user = db.scalars(select(User).where(User.email == email)).first()
    assert user is not None, f"user {email} not found"
    result = ledger_service.credit(
        db, user_id=user.id, amount_micro=int(credits * 1_000_000), entry_type="admin_grant",
        idempotency_key=key or f"test-grant:{user.id}:{credits}:{os.urandom(4).hex()}",
        description="test grant",
    )
    db.commit()
    return result.balance_after_micro


@pytest.fixture()
def anyio_backend() -> str:
    return "asyncio"


def pytest_sessionfinish(session, exitstatus) -> None:  # noqa: ANN001
    shutil.rmtree(TMP_ROOT, ignore_errors=True)
