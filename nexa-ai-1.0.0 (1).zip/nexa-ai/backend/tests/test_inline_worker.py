"""The in-process worker (`NEXA_INLINE_WORKER=true`) has to be real, not decorative.

Background: `/api/v1/health` and `/api/v1/health/deep` advertised the inline mode while
nothing in the API process consumed the queue, so a local install (Windows `start.bat`,
the Docker dev stack, the bare `.env.example`) accumulated `pending` jobs for ever and the
Telegram bot never polled. These tests pin the behaviour down:

* a queued job is claimed and executed by the in-process worker,
* a job that raises does not kill the loop and is counted as an error,
* testing never starts the background thread implicitly,
* a deployment that runs a dedicated worker does not also poll Telegram in the API.
"""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.jobs import Job
from app.models.jobs import JobType
from app.services import inline_worker as inline_worker_service
from app.services import jobs as job_service


def _enqueue_cleanup(db: Session) -> Job:
    """A real registered job type with no external dependency."""
    job = job_service.enqueue(db, job_type=JobType.CLEANUP, payload={"reason": "inline-worker-test"})
    db.commit()
    return job


def test_a_queued_job_is_executed_by_the_inline_worker(db: Session) -> None:
    job = _enqueue_cleanup(db)
    worker = inline_worker_service.InlineWorker(poll_seconds=0.05)

    assert worker.tick() is True, "the worker must claim the queued job"

    db.expire_all()
    stored = db.get(Job, job.id)
    assert stored is not None
    assert stored.status in {"succeeded", "success", "completed"}, stored.status
    assert worker.processed == 1
    assert worker.errors == 0
    assert worker.status()["processed"] == 1


def test_the_loop_survives_a_failing_job(db: Session, monkeypatch) -> None:
    worker = inline_worker_service.InlineWorker(poll_seconds=0.05)

    def boom(db_: Session, worker_id: str | None = None):  # noqa: ANN001, ANN202
        raise RuntimeError("handler exploded")

    monkeypatch.setattr(job_service, "run_once", boom)
    assert worker.tick() is False, "a crash must be reported, not raised"
    assert worker.errors == 1


def test_an_empty_queue_is_a_no_op(db: Session) -> None:
    worker = inline_worker_service.InlineWorker(poll_seconds=0.05)
    assert worker.tick() is False
    assert worker.processed == 0 and worker.errors == 0


def test_the_worker_is_not_started_inside_test_runs() -> None:
    # conftest sets NEXA_ENVIRONMENT=test; the guard must refuse to spawn threads.
    assert settings.environment == "test"
    assert inline_worker_service.should_start() is False
    assert inline_worker_service.start() is None
    assert inline_worker_service.current() is None


def test_exactly_one_process_is_chosen_for_telegram_polling(monkeypatch) -> None:
    """Telegram gives an update to a single getUpdates caller: the decision must be unique."""
    from app.workers import worker as worker_module

    monkeypatch.setattr(settings, "telegram_enabled", True)
    monkeypatch.setattr(settings, "telegram_mode", "polling")
    monkeypatch.setattr(settings, "telegram_bot_token", "123:TOKEN")

    # Inline mode: the API process polls, the worker service must stand down.
    monkeypatch.setattr(settings, "inline_worker", True)
    start, reason = worker_module._telegram_polling_decision()
    assert start is False
    assert "API process" in reason

    # Dedicated worker deployment: the worker service polls.
    monkeypatch.setattr(settings, "inline_worker", False)
    start, _reason = worker_module._telegram_polling_decision()
    assert start is True

    # Not configured at all: nobody polls.
    monkeypatch.setattr(settings, "telegram_enabled", False)
    start, _reason = worker_module._telegram_polling_decision()
    assert start is False
