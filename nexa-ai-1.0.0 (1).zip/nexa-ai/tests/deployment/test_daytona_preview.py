#!/usr/bin/env python3
"""The preview link is the only way into a Daytona sandbox — prove we resolve it.

The operator ran `install-daytona.sh` on a real sandbox and got no link: the summary printed
`<get the preview link for port 8080; see below>` because the script only built a URL when the
`DAYTONA_SANDBOX_ID` environment variable happened to be set (the docs already promised it would
"guess from the environment and print the link"). Inside a sandbox the machine's own IP
(`172.20.0.63` here) is unreachable from the outside, so a placeholder in that spot means the
sandbox cannot be shared at all.

`deployment/daytona/preview_link.sh` now detects the sandbox id, builds the candidate proxy URLs,
**probes them** and classifies the answer:

* HTTP 2xx → the sandbox is public, the link works for anyone (and it is used as the public URL),
* HTTP 401/403 → the URL is right but access needs a signed link or the public flag,
* no answer → report it instead of pretending.

These tests drive the real script against local HTTP servers, so the classification is executed,
not grepped.
"""
from __future__ import annotations

import http.server
import os
import socket
import subprocess
import threading
from pathlib import Path

import pytest

DAYTONA = Path(__file__).resolve().parents[2] / "deployment" / "daytona"
ROOT = Path(__file__).resolve().parents[2]
HELPER = ROOT / "deployment" / "daytona" / "preview_link.sh"
INSTALLER = ROOT / "deployment" / "daytona" / "install-daytona.sh"


class _Handler(http.server.BaseHTTPRequestHandler):
    status = 200

    def do_GET(self) -> None:  # noqa: N802 - stdlib naming
        self.send_response(type(self).status)
        self.send_header("content-type", "text/plain")
        self.end_headers()
        self.wfile.write(b'{"status":"ok"}')

    def log_message(self, *args: object) -> None:  # keep the test output clean
        return


def _serve(status: int) -> tuple[str, http.server.ThreadingHTTPServer]:
    handler = type(f"Handler{status}", (_Handler,), {"status": status})
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return f"http://127.0.0.1:{server.server_port}", server


def _free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def _helper(*args: str, env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    base = dict(os.environ)
    base.setdefault("DAYTONA_SANDBOX_ID", "sandbox-under-test")
    # no Daytona domain is reachable from CI; the tests inject their own local URL instead
    base["NEXA_PREVIEW_DOMAINS"] = ""
    base["NEXA_PREVIEW_PROBE_TIMEOUT"] = "5"
    if env:
        base.update(env)
    return subprocess.run(
        ["bash", str(HELPER), *args], capture_output=True, text=True, env=base, timeout=90
    )


# ------------------------------------------------------------------ static wiring --
def test_the_installer_sources_the_resolver_and_no_longer_prints_a_placeholder() -> None:
    text = INSTALLER.read_text(encoding="utf-8")
    assert ". \"${PREVIEW_HELPER}\"" in text, "install-daytona.sh must source preview_link.sh"
    assert "nexa_preview_resolve" in text, "the installer must probe for a working preview URL"
    assert "nexa_preview_sandbox_id" in text, "the installer must detect the sandbox id"
    assert "<get the preview link for port" not in text, (
        "the placeholder that left the operator without a link must not come back"
    )
    assert "PREVIEW_BLOCK" in text, "the summary must print a resolved link (or a full diagnosis)"


def test_the_helper_is_executable_and_parses() -> None:
    assert os.access(HELPER, os.X_OK), "preview_link.sh must ship with the executable bit"
    subprocess.run(["bash", "-n", str(HELPER)], check=True, timeout=30)


# ------------------------------------------------------------------ candidate URLs --
def test_candidate_urls_follow_the_daytona_proxy_scheme() -> None:
    result = subprocess.run(
        ["bash", "-c", f'. "{HELPER}"; NEXA_PREVIEW_EXTRA_URLS= nexa_preview_candidate_urls abc123 8080'],
        capture_output=True, text=True, timeout=30,
    )
    assert result.returncode == 0
    assert result.stdout.strip().splitlines() == [
        "https://8080-abc123.proxy.daytona.work",
        "https://8080-abc123.proxy.daytona.works",
    ], "the <port>-<sandbox-id>.<proxy-domain> shape is what the Daytona proxy answers on"


def test_the_sandbox_id_comes_from_the_environment_or_the_hostname() -> None:
    script = f'. "{HELPER}"; nexa_preview_sandbox_id'
    from_env = subprocess.run(
        ["bash", "-c", script], capture_output=True, text=True, timeout=30,
        env={**os.environ, "DAYTONA_SANDBOX_ID": "my-sandbox"},
    )
    assert from_env.stdout.strip() == "my-sandbox"
    fallback = subprocess.run(
        ["bash", "-c", script], capture_output=True, text=True, timeout=30,
        env={k: v for k, v in os.environ.items() if k != "DAYTONA_SANDBOX_ID"},
    )
    assert fallback.stdout.strip(), "without the variable the container hostname is used"


# ------------------------------------------------------------------ classification --
def test_a_public_sandbox_is_reported_as_shareable() -> None:
    url, server = _serve(200)
    try:
        result = _helper("--port", "8080", env={"NEXA_PREVIEW_EXTRA_URLS": url})
        assert result.returncode == 0, result.stdout + result.stderr
        assert "SHARE THIS LINK" in result.stdout
        assert url in result.stdout
        assert "works for anyone" in result.stdout
    finally:
        server.shutdown()


def test_a_private_sandbox_explains_the_two_ways_to_open_it() -> None:
    url, server = _serve(401)
    try:
        result = _helper("--port", "8080", env={"NEXA_PREVIEW_EXTRA_URLS": url})
        assert result.returncode == 3, result.stdout + result.stderr
        assert "private" in result.stdout
        assert "daytona preview-url" in result.stdout, "the operator must get the exact command"
        assert "set_public(True)" in result.stdout, "and the no-token alternative"
    finally:
        server.shutdown()


def test_an_unreachable_candidate_is_not_reported_as_a_link() -> None:
    result = _helper("--port", "8080", env={"NEXA_PREVIEW_EXTRA_URLS": f"http://127.0.0.1:{_free_port()}"})
    assert "SHARE THIS LINK" not in result.stdout
    assert "no answer from here" in result.stdout


def test_resolve_returns_only_a_url_that_answers() -> None:
    public_url, public = _serve(200)
    private_url, private = _serve(401)
    try:
        good = subprocess.run(
            ["bash", "-c", f'. "{HELPER}"; NEXA_PREVIEW_DOMAINS= nexa_preview_resolve "" 8080'],
            capture_output=True, text=True, timeout=60,
            env={**os.environ, "NEXA_PREVIEW_EXTRA_URLS": f"{private_url} {public_url}"},
        )
        assert good.stdout.strip() == public_url, "the first *answering* candidate wins"
    finally:
        public.shutdown()
        private.shutdown()
    nothing = subprocess.run(
        ["bash", "-c", f'. "{HELPER}"; NEXA_PREVIEW_DOMAINS= nexa_preview_resolve "" 8080'],
        capture_output=True, text=True, timeout=60,
        env={**os.environ, "NEXA_PREVIEW_EXTRA_URLS": f"http://127.0.0.1:{_free_port()}"},
    )
    assert nothing.returncode != 0 and nothing.stdout.strip() == "", (
        "an unreachable candidate must never be used as the public URL"
    )


# only a 2xx is proof that the link works for others: a redirect does not install any page
@pytest.mark.parametrize("status,expected", [(200, "public"), (204, "public"), (401, "private"),
                                            (403, "private"), (301, "unreachable"),
                                            (502, "unreachable"), (0, "unreachable")])
def test_status_classification(status: int, expected: str) -> None:
    result = subprocess.run(
        ["bash", "-c", f'. "{HELPER}"; nexa_preview_classify {status}'],
        capture_output=True, text=True, timeout=30,
    )
    assert result.stdout.strip() == expected

def test_installer_warns_that_secure_cookies_need_https() -> None:
    """A Secure cookie is dropped on a plain http:// page.

    Measured in a real sandbox: sign-in answered 200 and the next request was still anonymous,
    which reads as "the app is broken". The installer now says so and names the fix (--http).
    """
    text = (DAYTONA / "install-daytona.sh").read_text(encoding="utf-8")
    assert "COOKIE_NOTE" in text
    assert "DROPS a Secure cookie on a plain http:// URL" in text
    assert "--http" in text
    # and the summary actually prints the note
    assert "${COOKIE_NOTE}" in text

def test_service_restarts_do_not_leak_the_systemd_shim_warning() -> None:
    """On a container without systemd the `systemctl` shim prints to *stdout*.

    Unsuppressed, that warning landed in the middle of the installation summary and read like a
    failure ("systemd is not running in this container"), while the launcher had already done the
    right thing. Every restart call must silence stdout *and* stderr.
    """
    text = (DAYTONA / "install-daytona.sh").read_text(encoding="utf-8")
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped.startswith("systemctl ") or "is-system-running" in stripped:
            continue
        if "|" in stripped:
            continue  # stdout is consumed by a pipe, so a shim warning cannot reach the operator
        assert ">/dev/null 2>&1" in stripped or "&>/dev/null" in stripped, f"systemctl call leaks output: {stripped}"

