# Nexa AI — Multi-Provider AI Platform

**فارسی** · [English](#english)

پلتفرم واقعی و تجاری هوش مصنوعی: چند ارائه‌دهنده (OpenAI، Anthropic، Google، سرویس‌های سازگار،
استبیلیتی، ElevenLabs، Deepgram، Replicate و …)، فروشگاه مدل با کنترل دسترسی، صورتحساب اعتباری با
دفتر کل تغییرناپذیر، پنل مدیریت کامل، ۴ زبان (فارسی پیش‌فرض + انگلیسی + عربی + کردی سورانی) با
راست‌به‌چپ، و نصب روی لینوکس و ویندوز.

> **هیچ‌چیز ساختگی نیست.** تا وقتی ارائه‌دهنده‌ی واقعی پیکربندی نشود، API با خطای صریح
> `503 not_configured` پاسخ می‌دهد و هیچ پاسخ هوش مصنوعی جعلی تولید نمی‌شود. مدل تازه‌همگام‌شده
> «مخفی و تأییدنشده» است تا مدیر آن را تست، قیمت‌گذاری و آگاهانه منتشر کند.

## نصب سریع

```bash
# ۱) با Docker (پیشنهادی)
git clone <repo-url> nexa-ai && cd nexa-ai
cp deployment/.env.production.example .env     # کلیدها و رمزها را پر کنید
docker compose up -d --build                   # سپس: http://IP:8080

# ۲) اوبونتو/دبیان بدون Docker
sudo bash deployment/linux/install.sh

# ۳) ویندوز
deployment\windows\install.bat
deployment\windows\start.bat
```

**راهنمای کامل (نصب، استفاده، تست، پشتیبان، عیب‌یابی): [`docs/RAHNAMA.md`](docs/RAHNAMA.md)**

## چه چیزی ساخته شده است

| لایه | فناوری | وضعیت |
| --- | --- | --- |
| بک‌اند | Python + FastAPI + Pydantic + SQLAlchemy 2 + Alembic | ۱۳۱ مسیر API، ۳۰ جدول، ۱۳۷ تست موفق |
| فرانت‌اند | React 18 + TypeScript + Vite | ساخت production موفق (SPA ~۳۶۲KB) |
| دیتابیس | PostgreSQL (بهره‌برداری) / SQLite (فقط توسعه) | مهاجرت اولیه + بذر اولیه (۶ نقش، ۳۰ مجوز، ۹ دسته، ۲۰ تنظیم) |
| ارائه‌دهنده‌ها | ۱۶ آداپتور | متن/جریان/تصویر/صدا/ویدئو/embedding/rerank، خطاهای دسته‌بندی‌شده |
| مالی | دفتر کل تغییرناپذیر، میکرواعتبار صحیح، idempotency | پرداخت دستی + رمزارز + آداپتور درگاه، بدون اعتبار خودکار |
| استقرار | Docker Compose، Nginx، systemd، اسکریپت‌های ویندوز | فایل‌های واقعی، آزمون‌پذیر |
| تست | pytest (بک‌اند) + تست زنده‌ی سرتاسری + `doctor` + چک‌های استقرار | ۱۳۷ + ۳۷ مسیر موفق در آخرین اجرا |

## ساختار پروژه

```
backend/    API، مدل‌های داده، سرویس‌ها، آداپتورها، تست‌ها، alembic
frontend/   رابط کاربری React/TS (صفحات کاربر و ۱۵ صفحه‌ی مدیریت)
database/   اسکریپت ساخت PostgreSQL، نمای schema
deployment/ Docker، Nginx، systemd، نصب‌کننده‌های لینوکس و ویندوز
docs/       همه‌ی مستندات (شروع از docs/RAHNAMA.md)
scripts/    پشتیبان/بازیابی/بررسی سلامت/CLI
tests/      تست زنده‌ی سرتاسری، شبیه‌ساز ارائه‌دهنده، آزمون‌های استقرار و UI
```

## اولین گام‌ها پس از نصب

1. با مدیر ساخته‌شده در `NEXA_BOOTSTRAP_ADMIN_EMAIL` وارد شوید و رمز را عوض کنید.
2. در **مدیر → ارائه‌دهنده‌ها** یک ارائه‌دهنده بسازید، **تست اتصال** و **همگام‌سازی مدل** بزنید.
3. مدل را قیمت‌گذاری کنید (**مدل‌ها → ویرایش**): قیمت فروش به «اعتبار»، هزینه‌ی ارائه‌دهنده به «دلار».
4. **تست مدل** را روی یک قابلیت واقعی اجرا کنید (ثبت در audit، با هزینه‌ی پلتفرم).
5. مدل را منتشر کنید (`public` + `published` + `access_tier` مناسب).
6. پرداخت دستی: کاربر درخواست می‌دهد، مدیر **تأیید** می‌کند و اعتبار یک‌بار در دفتر کل ثبت می‌شود.

## تست

```bash
cd backend && python -m pytest tests/ -q                 # ۱۳۷ تست
python -m pytest ../tests/deployment -q                  # آزمون فایل‌های استقرار
python3 tests/tools/mock_openai_upstream.py --port 9099 &   # شبیه‌ساز ارائه‌دهنده
python3 tests/integration/test_live_stack.py             # ۳۷ مسیر سرتاسری
```

---

## English

A real, commercial multi-provider AI platform: OpenAI-compatible, Anthropic, Google, Stability,
ElevenLabs, Deepgram, Replicate and more; a model catalogue with visibility ≠ availability ≠ access;
an immutable credit ledger with idempotent money movements; a full administration panel; four
languages (Persian default with RTL, English, Arabic, Kurdish Sorani); Linux and Windows installers.

**Nothing is faked.** Without a configured provider the API answers `503 not_configured` — never a
generated mock answer. A freshly synced model stays hidden and unverified until an administrator
tests, prices and publishes it deliberately.

### Quick start

```bash
# Docker (recommended)
cp deployment/.env.production.example .env     # fill in secrets
docker compose up -d --build                   # → http://SERVER-IP:8080

# Ubuntu/Debian without Docker
sudo bash deployment/linux/install.sh

# Windows
deployment\windows\install.bat && deployment\windows\start.bat
```

Full manual — install, provider setup, users, billing, public-IP testing, backups, troubleshooting:
**[`docs/INSTALLATION_GUIDE.md`](docs/INSTALLATION_GUIDE.md)** (English) ·
**[`docs/RAHNAMA.md`](docs/RAHNAMA.md)** (فارسی)

### Verified in this repository

| Check | Result |
| --- | --- |
| Backend test suite | **154 passed** (`cd backend && python -m pytest tests -q`) |
| Frontend production build | **success** (`npm run build`, `tsc -b` clean) |
| Live end-to-end stack test | **37 / 37 steps passed** against a running API + mock upstream |
| Migrations + bootstrap | applied and idempotent (`alembic upgrade head`, `app.cli bootstrap`) |
| Deployment assets | validated by `tests/deployment` (compose YAML, no published DB/Redis, installers, Nginx, systemd) |
| Served-app end-to-end smoke | **10 passed** (`python -m pytest tests/e2e -q` against a running instance) |
| Repository invariants | **80 passed** (`python -m pytest tests/unit tests/deployment -q`: money types, no committed secrets, locale parity, guarded admin routes, installer/NAT truthfulness) |
| Archive self-check | the delivered ZIP was extracted to an empty directory and re-verified: 80 tests, migrations, bootstrap, `/healthz`, live stack **37 / 37** |
| Native installer on a clean Debian 13 host | `sudo bash deployment/linux/install.sh` → all steps green, PostgreSQL/Redis started automatically, Nginx live, `health check passed`, `administrator sign-in verified` |
| Installed production stack (PostgreSQL + Nginx + systemd) | live stack **37 / 37** and served-app smoke **10 passed** against `http://127.0.0.1:8080` |
| Backend suite on PostgreSQL | **137 passed** (same suite, PostgreSQL 17 dialect; the four newest test files are dialect-independent) |
| Browser sweep of the whole UI | **24 screenshots, no console errors** (`tests/tools/ui_smoke/verify-ui.cjs`; sign-in, user + admin screens, light/dark/glass, 390 px drawer) |
| Responsive layout measured | no horizontal page scroll at 390 / 430 / 820 / 1024 / 1280 / 1440 px |

### Documentation set

| Document | Contents |
| --- | --- |
| [`docs/RAHNAMA.md`](docs/RAHNAMA.md) / [`docs/INSTALLATION_GUIDE.md`](docs/INSTALLATION_GUIDE.md) | the complete install → operate → test manual (fa / en) |
| [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) | components, request flow, data model, design decisions |
| [`docs/INSTALL_UBUNTU.md`](docs/INSTALL_UBUNTU.md) / [`docs/INSTALL_WINDOWS.md`](docs/INSTALL_WINDOWS.md) | platform-specific install notes |
| [`docs/PROVIDER_CONFIGURATION.md`](docs/PROVIDER_CONFIGURATION.md) | every adapter, credentials, base URLs, timeouts |
| [`docs/TELEGRAM.md`](docs/TELEGRAM.md) | the optional Telegram bot: BotFather token, polling vs webhook, linking, billing |
| [`docs/MODEL_MANAGEMENT.md`](docs/MODEL_MANAGEMENT.md) | sync, pricing, visibility/availability/tier, testing, grants |
| [`docs/BILLING.md`](docs/BILLING.md) | credits, ledger, payments, refunds, subscriptions, quotas |
| [`docs/SECURITY.md`](docs/SECURITY.md) | threat model and implemented controls |
| [`docs/BACKUP_RESTORE.md`](docs/BACKUP_RESTORE.md) | backup, verification and restore drills |
| [`docs/PRODUCTION_DEPLOYMENT.md`](docs/PRODUCTION_DEPLOYMENT.md) | public IP and domain/HTTPS deployment |
| [`docs/REMOTE_TESTING.md`](docs/REMOTE_TESTING.md) | sharing a public-IP instance with testers safely |
| [`docs/TROUBLESHOOTING.md`](docs/TROUBLESHOOTING.md) | symptom → cause → fix |
| [`docs/KNOWN_LIMITATIONS.md`](docs/KNOWN_LIMITATIONS.md) | honest list of what is not implemented/verified |
| [`docs/TEST_REPORT.md`](docs/TEST_REPORT.md) | what was executed, what was not, and why |

### Licence and third-party services

The application code ships with no AI provider credentials. You must configure your own provider keys
(`Admin → AI Infrastructure → Providers`) and comply with each provider's terms of service. Every
outbound call is made from your server with your credentials; the platform never proxies through a
third party of ours.
