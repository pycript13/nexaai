/** Shapes returned by the Nexa AI backend (only the fields the UI consumes). */
export interface Pagination {
  page: number;
  page_size: number;
  total: number;
  pages: number;
  has_next: boolean;
  has_prev: boolean;
}

export interface Paged<T> {
  items: T[];
  pagination?: Pagination;
}

/** `/models` adds catalog metadata next to the page of models. */
export interface CatalogResponse extends Paged<CatalogModel> {
  capabilities?: string[];
  operation_labels?: Record<string, string>;
  tiers?: string[];
}

export interface ApiErrorBody {
  code: string;
  message: string;
  category?: string;
  category_label?: string;
  details?: Record<string, unknown>;
  retryable?: boolean;
  provider?: string | null;
  model?: string | null;
  upstream_status?: number | null;
}

/** `/auth/login` and `/auth/me` return roles as objects, not slugs. */
export interface RoleRef {
  slug: string;
  name: string;
}

export interface CurrentUser {
  id: number;
  email: string;
  display_name: string;
  status: string;
  email_verified: boolean;
  locale: string;
  theme: string;
  roles: RoleRef[] | string[];
  permissions: string[];
  must_change_password?: boolean;
  created_at?: string;
  last_login_at?: string | null;
}

export interface MeResponse {
  user: CurrentUser;
  account: Record<string, unknown> | null;
  subscription: Record<string, unknown> | null;
  permissions: string[];
  theme?: string;
  locale?: string;
}

export interface Balance {
  balance_micro: number;
  balance_display: string;
  currency: string;
  credit_display_name: string;
  credit_usd_rate: number;
  lifetime_deposited_micro: number;
  lifetime_spent_micro: number;
  spent_today_micro: number;
  spent_month_micro: number;
  daily_spend_limit_micro: number | null;
  monthly_spend_limit_micro: number | null;
  is_frozen: boolean;
  subscription?: Record<string, unknown> | null;
}

export interface ModelPricing {
  currency: string;
  pricing_model: string;
  input_credits_per_mtok: number | null;
  output_credits_per_mtok: number | null;
  per_request_credits: number | null;
  per_image_credits: number | null;
  per_audio_minute_credits: number | null;
  minimum_charge_credits: number | null;
  notes?: string[];
}

export interface CatalogModel {
  id: number;
  display_name: string;
  provider_model_id: string;
  provider: string | null;
  provider_id: number;
  capabilities: string[];
  input_modalities: string[];
  output_modalities: string[];
  context_window: number | null;
  max_output_tokens: number | null;
  access_tier: string;
  availability: string;
  supports_streaming: boolean;
  supports_vision: boolean;
  supports_tools: boolean;
  description?: string | null;
  pricing?: ModelPricing;
  accessible: boolean;
  access_reason?: string;
  /** Machine-readable reason code (localised by the client); `access_reason` is the English fallback. */
  access_code?: string;
  requires_payment?: boolean;
  categories?: { slug: string; name: string }[];
}

export interface Conversation {
  id: number;
  title: string;
  model_id: number | null;
  pinned: boolean;
  archived: boolean;
  created_at: string;
  updated_at: string;
  message_count?: number;
  last_message_preview?: string | null;
}

export interface ChatMessageRecord {
  id: number;
  role: string;
  content: string;
  model_id?: number | null;
  prompt_tokens?: number | null;
  completion_tokens?: number | null;
  charged_micro?: number | null;
  created_at: string;
  error_category?: string | null;
  /** Set when the provider returned no visible text (e.g. a reasoning model that used its whole
   *  output budget thinking); the chat screen prints it instead of an empty bubble. */
  error_message?: string | null;
  status?: string | null;
  /** Reasoning emitted as its own part (seen live with MiniMax/GLM style models). */
  content_parts?: Array<{ type?: string; text?: string }> | null;
}

export interface Job {
  id: number;
  type: string;
  status: string;
  progress: number;
  attempts: number;
  max_attempts?: number;
  error_category?: string | null;
  error_message?: string | null;
  charged_micro?: number;
  created_at: string;
  started_at?: string | null;
  finished_at?: string | null;
  result?: Record<string, unknown> | null;
  user_id?: number | null;
}

export interface StoredFile {
  id: number;
  original_name: string;
  kind: string;
  extension: string;
  mime_type: string;
  size_bytes: number;
  is_private: boolean;
  created_at: string;
  extracted_text?: string | null;
  metadata?: Record<string, unknown> | null;
}

export interface LedgerEntry {
  id: number;
  type: string;
  amount_micro: number;
  balance_after_micro: number;
  description: string;
  created_at: string;
  reference_type?: string | null;
  reference_id?: string | null;
}

export interface Payment {
  id: number;
  reference: string;
  amount_micro: number;
  method: string;
  status: string;
  payer_name?: string | null;
  bank_reference?: string | null;
  tx_hash?: string | null;
  crypto_asset?: string | null;
  crypto_network?: string | null;
  receipt_file_id?: number | null;
  note?: string | null;
  review_note?: string | null;
  created_at: string;
  reviewed_at?: string | null;
  verified_by_platform?: boolean;
}

export interface ProviderRecord {
  id: number;
  slug: string;
  name: string;
  provider_type: string;
  base_url: string;
  enabled: boolean;
  priority: number;
  has_credentials: boolean;
  api_key_hint?: string | null;
  last_test_status?: string | null;
  last_test_at?: string | null;
  last_error_category?: string | null;
  model_count?: number;
  notes?: string | null;
}

export interface AdminModelRecord extends Record<string, unknown> {
  id: number;
  display_name: string;
  provider_model_id: string;
  provider_id: number;
  visibility: string;
  published: boolean;
  enabled: boolean;
  availability: string;
  access_tier: string;
  capabilities: string[];
  last_test_status?: string | null;
  last_test_at?: string | null;
}

export interface ModuleCapability {
  label: string;
  operations: string[];
  available: boolean;
  options: { model_id: number; model: string; provider: string; operation: string }[];
  message: string | null;
}

export interface MetaConfig {
  app_name: string;
  tagline: string;
  version: string;
  environment: string;
  deployment_mode: string;
  security_warning: string | null;
  testing_notice?: string | null;
  languages: { code: string; label: string; direction: string }[];
  default_language: string;
  themes: string[];
  enhanced_theme_available: boolean;
  registration_mode: string;
  registration_enabled?: boolean;
  terms_version?: string;
  privacy_version?: string;
  features: Record<string, boolean>;
  payment_methods: Record<string, unknown>;
  credit_display_name: string;
  max_upload_mb: number;
  user_storage_quota_mb: number;
  supported_upload_types: string[];
  /** Module catalogue reported by the backend (`/api/v1/meta/config`). */
  modules?: { key: string; label?: string; available?: boolean; options?: unknown[]; [key: string]: unknown }[];
  /** Public address metadata (deployment mode "public_ip"). */
  public_base_url?: string;
  public_ip?: string | null;
  public_port?: number;
  operations: string[];
  operation_labels: Record<string, string>;
  support_email?: string | null;
  authenticated: boolean;
}
