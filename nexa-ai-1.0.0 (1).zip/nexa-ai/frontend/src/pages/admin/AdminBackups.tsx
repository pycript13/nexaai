import { useState } from "react";
import { api } from "../../api/client";
import { Badge, Button, Card, ConfirmCheckbox, ErrorNotice, Field, Spinner, Stat, useApi } from "../../components/ui";
import { formatBytes, formatDateTime } from "../../utils/format";
import { useApp, useI18n } from "../../state/app";

interface BackupRecord {
  id: number;
  filename: string;
  size_bytes: number;
  status: string;
  created_at: string;
  verified?: boolean;
  notes?: string | null;
}

export function AdminBackups(): JSX.Element {
  const { t, locale } = useI18n();
  const { notify } = useApp();
  const backups = useApi<{ items: BackupRecord[]; directory: string; last_verified?: string | null; restore_note?: string }>(
    () => api.get("/api/v1/admin/backup/run"),
    [],
  );
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [result, setResult] = useState<any>(null);

  const runBackup = async () => {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const response = await api.post("/api/v1/admin/backup/run", { confirm: confirmed });
      setResult(response);
      notify("success", "Backup completed and recorded");
      backups.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (backups.loading && !backups.data) return <Spinner />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.backups")}</h1>
          <p>
            The API can trigger a database backup; full restore verification is performed with the scripts in
            <code> scripts/backup.sh</code> and <code>scripts/restore.sh</code> (see docs/BACKUP_RESTORE.md).
          </p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      {result && (
        <Card title="Backup result">
          <pre className="md__code">{JSON.stringify(result, null, 2)}</pre>
        </Card>
      )}

      <div className="grid grid--4">
        <Stat label="Backups" value={backups.data?.items?.length ?? 0} />
        <Stat label="Directory" value={backups.data?.directory || "—"} />
        <Stat label="Last verified" value={formatDateTime(backups.data?.last_verified, locale)} />
        <Stat
          label="Latest size"
          value={formatBytes(backups.data?.items?.[0]?.size_bytes)}
        />
      </div>

      <Card title="Run a backup now">
        <ConfirmCheckbox checked={confirmed} onChange={setConfirmed} label={t("admin.confirmSensitive")} />
        <div className="row" style={{ marginTop: "0.6rem" }}>
          <Button type="button" onClick={runBackup} loading={busy} disabled={!confirmed || busy}>
            Run backup
          </Button>
        </div>
        <p className="muted small">{backups.data?.restore_note}</p>
      </Card>

      <Card title="Backup history">
        {(backups.data?.items || []).length === 0 ? (
          <p className="muted">No backup has been recorded yet.</p>
        ) : (
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th>File</th>
                  <th>Size</th>
                  <th>Status</th>
                  <th>{t("label.created")}</th>
                  <th>Verified</th>
                </tr>
              </thead>
              <tbody>
                {(backups.data?.items || []).map((backup) => (
                  <tr key={backup.id}>
                    <td className="mono">{backup.filename}</td>
                    <td>{formatBytes(backup.size_bytes)}</td>
                    <td>
                      <Badge tone={backup.status === "completed" ? "success" : "warning"}>{backup.status}</Badge>
                    </td>
                    <td>{formatDateTime(backup.created_at, locale)}</td>
                    <td>{backup.verified ? t("common.yes") : t("common.no")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
