import React, { useState } from "react";
import { api } from "../../api/client";
import { Badge, Button, Card, ConfirmCheckbox, DataTable, ErrorNotice, Field, Spinner, StatusBadge, useApi } from "../../components/ui";
import { formatCredits, formatDateTime } from "../../utils/format";
import { useApp, useI18n } from "../../state/app";

interface PlanRecord {
  id: number;
  slug: string;
  name: string;
  description: string;
  price_micro_monthly: number;
  included_credit_micro: number;
  daily_request_limit: number | null;
  monthly_token_limit: number | null;
  markup_percent: number | null;
  is_active: boolean;
  is_public: boolean;
  subscriber_count: number;
}

export function AdminPlans(): JSX.Element {
  const { t, locale } = useI18n();
  const { notify } = useApp();
  const plans = useApi<{ items: PlanRecord[] }>(() => api.get("/api/v1/admin/billing/plans"), []);
  const [form, setForm] = useState({ name: "", description: "", price_credits: "20", included_credits: "20" });
  const [assign, setAssign] = useState({ user_id: "", plan_id: "", grant_credits: true });
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [created, setCreated] = useState<any>(null);

  const createPlan = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.post("/api/v1/admin/billing/plans", {
        name: form.name,
        description: form.description,
        price_micro_monthly: Math.round(Number(form.price_credits) * 1_000_000),
        included_credit_micro: Math.round(Number(form.included_credits) * 1_000_000),
      });
      notify("success", "Plan created");
      plans.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const assignPlan = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const response = await api.post("/api/v1/admin/billing/subscriptions", {
        user_id: Number(assign.user_id),
        plan_id: Number(assign.plan_id),
        grant_credits: assign.grant_credits,
      });
      setCreated(response);
      notify("success", "Subscription activated for the user");
      plans.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (plans.loading) return <Spinner />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.plans")}</h1>
          <p>Subscriptions gate premium models and add their own quotas. Activation is always an explicit admin action.</p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      {created && (
        <Card title="Subscription activated">
          <pre className="md__code">{JSON.stringify(created, null, 2)}</pre>
        </Card>
      )}

      <div className="grid grid--2">
        <Card title="Create a plan">
          <form onSubmit={createPlan}>
            <Field label="Name">
              <input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} required minLength={2} />
            </Field>
            <Field label="Description">
              <textarea value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} />
            </Field>
            <div className="grid grid--2">
              <Field label="Price (credits / month)">
                <input type="number" step="1" value={form.price_credits} onChange={(event) => setForm({ ...form, price_credits: event.target.value })} />
              </Field>
              <Field label="Included credit (credits)">
                <input type="number" step="1" value={form.included_credits} onChange={(event) => setForm({ ...form, included_credits: event.target.value })} />
              </Field>
            </div>
            <Button type="submit" loading={busy} disabled={busy}>
              {t("action.create")}
            </Button>
          </form>
        </Card>

        <Card title="Assign a subscription">
          <form onSubmit={assignPlan}>
            <ConfirmCheckbox checked={confirmed} onChange={setConfirmed} label={t("admin.confirmSensitive")} />
            <div className="grid grid--3" style={{ marginTop: "0.6rem" }}>
              <Field label="User id">
                <input value={assign.user_id} onChange={(event) => setAssign({ ...assign, user_id: event.target.value })} required />
              </Field>
              <Field label="Plan">
                <select value={assign.plan_id} onChange={(event) => setAssign({ ...assign, plan_id: event.target.value })} required>
                  <option value="">—</option>
                  {(plans.data?.items || []).filter((plan) => plan.is_active).map((plan) => (
                    <option key={plan.id} value={plan.id}>
                      {plan.name} ({formatCredits(plan.price_micro_monthly)} credits)
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Included credit">
                <select
                  value={assign.grant_credits ? "yes" : "no"}
                  onChange={(event) => setAssign({ ...assign, grant_credits: event.target.value === "yes" })}
                >
                  <option value="yes">post the plan's included credit</option>
                  <option value="no">activate without credit</option>
                </select>
              </Field>
            </div>
            <Button type="submit" loading={busy} disabled={busy || !confirmed}>
              Activate
            </Button>
          </form>
          <p className="muted small">
            Included credit is posted as a ledger entry keyed to the subscription, so reactivating the same period never
            double-credits.
          </p>
        </Card>
      </div>

      <Card title="Plans">
        <DataTable
          rows={plans.data?.items || []}
          columns={[
            { key: "name", header: "Plan", render: (row) => row.name },
            { key: "slug", header: "Slug", render: (row) => <span className="mono">{row.slug}</span> },
            { key: "price", header: "Price / month", render: (row) => formatCredits(row.price_micro_monthly) },
            { key: "credit", header: "Included credit", render: (row) => formatCredits(row.included_credit_micro) },
            { key: "daily", header: "Daily requests", render: (row) => row.daily_request_limit ?? "—" },
            { key: "tokens", header: "Monthly tokens", render: (row) => row.monthly_token_limit ?? "—" },
            { key: "subs", header: "Subscribers", render: (row) => row.subscriber_count },
            { key: "status", header: t("label.status"), render: (row) => <StatusBadge value={row.is_active ? "active" : "disabled"} /> },
          ]}
        />
      </Card>
    </div>
  );
}
