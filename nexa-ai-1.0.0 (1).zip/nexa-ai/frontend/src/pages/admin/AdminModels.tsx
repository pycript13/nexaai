import React, { useState } from "react";
import { api } from "../../api/client";
import type { AdminModelRecord, Pagination as PaginationMeta } from "../../api/types";
import { Badge, Button, Card, ConfirmCheckbox, DataTable, ErrorNotice, Field, Modal, Pagination, Spinner, StatusBadge, useApi } from "../../components/ui";
import { formatCredits, formatDateTime } from "../../utils/format";
import { useApp, useI18n } from "../../state/app";
import { AdminVariantBoard } from "../../components/variants";
import { useSearchParams } from "react-router-dom";

const OPERATIONS = [
  "chat",
  "streaming",
  "embeddings",
  "image_generation",
  "image_understanding",
  "audio_transcription",
  "speech_generation",
  "video_generation",
  "rerank",
  "document_understanding",
];

const VISIBILITIES = ["public", "paid", "subscription", "restricted", "internal", "hidden", "archived"];
const TIERS = ["free", "credit", "subscription", "restricted", "internal"];
const AVAILABILITY = ["untested", "available", "degraded", "disabled"];

export function AdminModels(): JSX.Element {
  const { t, locale } = useI18n();
  const { notify, hasPermission } = useApp();
  const [page, setPage] = useState(1);
  // Filters can arrive in the URL (e.g. the provider page links to ?published=false after a sync)
  const [searchParams] = useSearchParams();
  const [filters, setFilters] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {};
    for (const key of ["published", "visibility", "availability", "search", "provider_id"]) {
      const value = searchParams.get(key);
      if (value) initial[key] = value;
    }
    return initial;
  });
  const models = useApi<{ items: AdminModelRecord[]; pagination: PaginationMeta; counts?: Record<string, number> }>(
    () => api.get("/api/v1/admin/models", { page, page_size: 20, ...filters }),
    [page, JSON.stringify(filters)],
  );
  const providers = useApi<{ items: { id: number; name: string; enabled: boolean }[] }>(() => api.get("/api/v1/admin/providers"), []);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({
    provider_id: "",
    provider_model_id: "",
    display_name: "",
    capabilities: ["chat"] as string[],
    visibility: "hidden",
    access_tier: "credit",
    input_price: "3",
    output_price: "15",
  });
  const [selected, setSelected] = useState<AdminModelRecord | null>(null);
  const [testForm, setTestForm] = useState({ operation: "chat", input: "Reply with the single word: pong" });
  const [testResult, setTestResult] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [confirmed, setConfirmed] = useState(false);

  const createModel = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.post("/api/v1/admin/models", {
        provider_id: Number(form.provider_id),
        provider_model_id: form.provider_model_id,
        display_name: form.display_name,
        capabilities: form.capabilities,
        visibility: form.visibility,
        access_tier: form.access_tier,
        published: false,
        selling_input_per_mtok: form.input_price ? Number(form.input_price) : undefined,
        selling_output_per_mtok: form.output_price ? Number(form.output_price) : undefined,
      });
      notify("success", "Model created as unpublished and hidden. Run a test, then publish it deliberately.");
      setCreating(false);
      models.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const runTest = async () => {
    if (!selected) return;
    setBusy(true);
    setError(null);
    setTestResult(null);
    try {
      const result = await api.post(`/api/v1/admin/models/${selected.id}/test`, {
        operation: testForm.operation,
        input: testForm.input,
      });
      setTestResult(result);
      notify("success", "Administrative test finished — it is audited and billed separately from user balances.");
      models.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const patchModel = async (payload: Record<string, unknown>, successMessage: string) => {
    if (!selected) return;
    setBusy(true);
    setError(null);
    try {
      await api.patch(`/api/v1/admin/models/${selected.id}`, { ...payload, confirm: confirmed });
      notify("success", successMessage);
      models.reload();
      const refreshed = await api.get<{ model: AdminModelRecord }>(`/api/v1/admin/models/${selected.id}`);
      setSelected(refreshed.model);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (models.loading && !models.data) return <Spinner />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.models")}</h1>
          <p>
            Visibility, availability and access tier are independent. Administrative tests run against hidden or
            restricted models without publishing them, and never bypass provider authentication.
          </p>
        </div>
        <div className="row">
          <Button type="button" onClick={() => setCreating(true)}>
            Add model
          </Button>
          <Button variant="subtle" type="button" onClick={models.reload}>
            {t("action.refresh")}
          </Button>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}

      <Card title={t("action.filter")}>
        <div className="grid grid--4">
          <Field label={t("action.search")}>
            <input value={filters.search || ""} onChange={(event) => { setPage(1); setFilters({ ...filters, search: event.target.value }); }} />
          </Field>
          <Field label={t("label.visibility")}>
            <select value={filters.visibility || ""} onChange={(event) => { setPage(1); setFilters({ ...filters, visibility: event.target.value }); }}>
              <option value="">{t("common.all")}</option>
              {VISIBILITIES.map((value) => (
                <option key={value} value={value}>{value}</option>
              ))}
            </select>
          </Field>
          <Field label={t("label.availability")}>
            <select value={filters.availability || ""} onChange={(event) => { setPage(1); setFilters({ ...filters, availability: event.target.value }); }}>
              <option value="">{t("common.all")}</option>
              {AVAILABILITY.map((value) => (
                <option key={value} value={value}>{value}</option>
              ))}
            </select>
          </Field>
          <Field label={t("label.published")}>
            <select value={filters.published || ""} onChange={(event) => { setPage(1); setFilters({ ...filters, published: event.target.value }); }}>
              <option value="">{t("common.all")}</option>
              <option value="true">published</option>
              <option value="false">not published</option>
            </select>
          </Field>
        </div>
      </Card>

      <Card title={t("nav.admin.models")}>
        <DataTable
          rows={models.data?.items || []}
          columns={[
            { key: "name", header: t("label.model"), render: (row) => String(row.display_name) },
            { key: "id", header: t("label.providerModelId"), render: (row) => <span className="mono">{String(row.provider_model_id)}</span> },
            { key: "visibility", header: t("label.visibility"), render: (row) => <Badge tone={row.visibility === "public" ? "success" : "neutral"}>{String(row.visibility)}</Badge> },
            { key: "published", header: t("label.published"), render: (row) => <StatusBadge value={row.published ? "published" : "hidden"} /> },
            { key: "tier", header: t("label.tier"), render: (row) => <Badge tone="info">{String(row.access_tier)}</Badge> },
            { key: "availability", header: t("label.availability"), render: (row) => <StatusBadge value={row.availability} /> },
            { key: "test", header: t("label.lastTest"), render: (row) => <StatusBadge value={row.last_test_status || "untested"} /> },
            { key: "capabilities", header: t("label.capabilities"), render: (row) => (row.capabilities || []).slice(0, 3).join(", ") },
            {
              key: "actions",
              header: t("label.actions"),
              render: (row) => (
                <Button variant="ghost" type="button" onClick={() => { setSelected(row); setTestResult(null); setConfirmed(false); }}>
                  {t("action.edit")}
                </Button>
              ),
            },
          ]}
        />
        <Pagination meta={models.data?.pagination} onChange={setPage} />
      </Card>

      <Modal
        open={creating}
        wide
        title="Add a model to the catalog"
        onClose={() => setCreating(false)}
        footer={
          <Button type="submit" form="model-create" loading={busy} disabled={busy}>
            {t("action.create")}
          </Button>
        }
      >
        <form id="model-create" onSubmit={createModel}>
          <Field label={t("label.provider")}>
            <select value={form.provider_id} onChange={(event) => setForm({ ...form, provider_id: event.target.value })} required>
              <option value="">—</option>
              {(providers.data?.items || []).map((provider) => (
                <option key={provider.id} value={provider.id}>
                  {provider.name} {provider.enabled ? "" : "(disabled)"}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Provider model id" hint="The exact identifier sent to the provider, e.g. gpt-4o-mini.">
            <input value={form.provider_model_id} onChange={(event) => setForm({ ...form, provider_model_id: event.target.value })} dir="ltr" required />
          </Field>
          <Field label="Display name">
            <input value={form.display_name} onChange={(event) => setForm({ ...form, display_name: event.target.value })} required />
          </Field>
          <Field label={t("label.capabilities")} hint="Only declare what the provider really supports; the gateway enforces this list.">
            <div className="grid grid--3">
              {OPERATIONS.map((operation) => (
                <label key={operation} className="checkbox">
                  <input
                    type="checkbox"
                    checked={form.capabilities.includes(operation)}
                    onChange={(event) =>
                      setForm((current) => ({
                        ...current,
                        capabilities: event.target.checked
                          ? [...current.capabilities, operation]
                          : current.capabilities.filter((item) => item !== operation),
                      }))
                    }
                  />
                  <span className="mono">{operation}</span>
                </label>
              ))}
            </div>
          </Field>
          <div className="grid grid--3">
            <Field label={t("label.visibility")}>
              <select value={form.visibility} onChange={(event) => setForm({ ...form, visibility: event.target.value })}>
                {VISIBILITIES.map((value) => (
                  <option key={value} value={value}>{value}</option>
                ))}
              </select>
            </Field>
            <Field label={t("label.tier")}>
              <select value={form.access_tier} onChange={(event) => setForm({ ...form, access_tier: event.target.value })}>
                {TIERS.map((value) => (
                  <option key={value} value={value}>{value}</option>
                ))}
              </select>
            </Field>
            <Field label="Input credits / 1M tokens">
              <input type="number" step="0.01" value={form.input_price} onChange={(event) => setForm({ ...form, input_price: event.target.value })} />
            </Field>
          </div>
          <Field label="Output credits / 1M tokens">
            <input type="number" step="0.01" value={form.output_price} onChange={(event) => setForm({ ...form, output_price: event.target.value })} />
          </Field>
        </form>
      </Modal>

      <Modal
        open={Boolean(selected)}
        wide
        title={selected ? String(selected.display_name) : ""}
        onClose={() => setSelected(null)}
        footer={
          <Button variant="subtle" type="button" onClick={() => setSelected(null)}>
            {t("action.close")}
          </Button>
        }
      >
        {selected && (
          <div className="stack">
            <ConfirmCheckbox checked={confirmed} onChange={setConfirmed} label={t("admin.confirmSensitive")} />

            <div className="alert alert--success">
              <div>
                <strong>{t("admin.impersonation")}</strong>
                <p>{t("admin.impersonationNote")}</p>
              </div>
            </div>

            <Card title="Administrative test">
              <div className="grid grid--3">
                <Field label="Operation">
                  <select value={testForm.operation} onChange={(event) => setTestForm({ ...testForm, operation: event.target.value })}>
                    {OPERATIONS.map((operation) => (
                      <option key={operation} value={operation}>{operation}</option>
                    ))}
                  </select>
                </Field>
                <Field label="Input">
                  <textarea value={testForm.input} onChange={(event) => setTestForm({ ...testForm, input: event.target.value })} />
                </Field>
                <div style={{ alignSelf: "end" }}>
                  <Button type="button" onClick={runTest} loading={busy} disabled={!hasPermission("models.test")}>
                    {t("action.test")}
                  </Button>
                </div>
              </div>
              {testResult && (
                <div className="stack">
                  <div className="row">
                    <Badge tone={testResult.test?.status === "ok" ? "success" : "danger"}>{testResult.test?.status}</Badge>
                    <span className="muted small">
                      charged to platform: {formatCredits(testResult.test?.cost_micro ?? 0)} · billed_to_user:{" "}
                      {String(testResult.test?.billed_to_user ?? false)}
                    </span>
                  </div>
                  <pre className="md__code">{JSON.stringify(testResult, null, 2).slice(0, 6000)}</pre>
                </div>
              )}
            </Card>

            <Card title="Lifecycle">
              <div className="grid grid--3">
                <Field label={t("label.visibility")}>
                  <select
                    value={String(selected.visibility)}
                    onChange={(event) => patchModel({ visibility: event.target.value }, "Visibility updated")}
                    disabled={!confirmed || busy}
                  >
                    {VISIBILITIES.map((value) => (
                      <option key={value} value={value}>{value}</option>
                    ))}
                  </select>
                </Field>
                <Field label={t("label.tier")}>
                  <select
                    value={String(selected.access_tier)}
                    onChange={(event) => patchModel({ access_tier: event.target.value }, "Access tier updated")}
                    disabled={!confirmed || busy}
                  >
                    {TIERS.map((value) => (
                      <option key={value} value={value}>{value}</option>
                    ))}
                  </select>
                </Field>
                <Field label={t("label.availability")}>
                  <select
                    value={String(selected.availability)}
                    onChange={(event) => patchModel({ availability: event.target.value }, "Availability updated")}
                    disabled={!confirmed || busy}
                  >
                    {AVAILABILITY.map((value) => (
                      <option key={value} value={value}>{value}</option>
                    ))}
                  </select>
                </Field>
              </div>
              <div className="row">
                <Button
                  type="button"
                  onClick={() => patchModel({ published: true }, "Model published")}
                  disabled={!confirmed || busy || Boolean(selected.published)}
                >
                  Publish
                </Button>
                <Button
                  variant="subtle"
                  type="button"
                  onClick={() => patchModel({ published: false }, "Model unpublished")}
                  disabled={!confirmed || busy || !selected.published}
                >
                  Unpublish
                </Button>
                <Button
                  variant="subtle"
                  type="button"
                  onClick={() => patchModel({ enabled: !selected.enabled }, selected.enabled ? "Model disabled" : "Model enabled")}
                  disabled={!confirmed || busy}
                >
                  {selected.enabled ? "Disable" : "Enable"}
                </Button>
              </div>
            </Card>

            <Card title="Prices (customer-facing)">
              <p className="muted small">
                Enter prices in <strong>credits per 1,000,000 tokens</strong> — fractional values are supported
                (0.28 is a typical cheap-model price). Internally they are stored as integer micro-credits per
                1M tokens (1 credit = 1,000,000 micro), so billing never uses floating point. Provider cost is
                tracked separately and never shown to end users.
              </p>
              <div className="grid grid--3">
                <Field label="Input credits / 1M tokens">
                  <input
                    type="number"
                    step="0.01"
                    defaultValue={String(selected.selling_input_per_mtok ?? "")}
                    onBlur={(event) => patchModel({ selling_input_per_mtok: Number(event.target.value) }, "Input price updated")}
                    disabled={!confirmed}
                  />
                </Field>
                <Field label="Output credits / 1M tokens">
                  <input
                    type="number"
                    step="0.01"
                    defaultValue={String(selected.selling_output_per_mtok ?? "")}
                    onBlur={(event) => patchModel({ selling_output_per_mtok: Number(event.target.value) }, "Output price updated")}
                    disabled={!confirmed}
                  />
                </Field>
                <Field label="Per image credits">
                  <input
                    type="number"
                    step="0.01"
                    defaultValue={String(selected.selling_per_image ?? "")}
                    onBlur={(event) => patchModel({ selling_per_image: Number(event.target.value) }, "Image price updated")}
                    disabled={!confirmed}
                  />
                </Field>
              </div>
            </Card>

            <Card title="Model tests history" subtitle="Every administrative test is stored with its cost and result.">
              <ModelTests modelId={selected.id} />
            </Card>

            <Card title={t("label.detail")}>
              <div className="kv">
                <div>
                  <span>Updated</span>
                  <span>{formatDateTime(String(selected.updated_at || ""), locale)}</span>
                </div>
                <div>
                  <span>Published</span>
                  <span>{String(selected.published)}</span>
                </div>
                <div>
                  <span>Enabled</span>
                  <span>{String(selected.enabled)}</span>
                </div>
              </div>
            </Card>
          </div>
        )}
      </Modal>

      <AdminVariantBoard />
    </div>
  );
}

function ModelTests({ modelId }: { modelId: number }): JSX.Element {
  const { t, locale } = useI18n();
  const tests = useApi<{ items: any[] }>(() => api.get(`/api/v1/admin/models/${modelId}/tests`), [modelId]);
  if (tests.loading) return <Spinner />;
  return (
    <DataTable
      rows={tests.data?.items || []}
      empty={<p className="muted">No administrative test has been run for this model yet.</p>}
      columns={[
        { key: "created", header: t("label.when"), render: (row) => formatDateTime(row.created_at, locale) },
        { key: "operation", header: t("label.operation"), render: (row) => <span className="mono">{row.operation}</span> },
        { key: "status", header: t("label.status"), render: (row) => <StatusBadge value={row.status} /> },
        { key: "bypass", header: t("label.bypassedRules"), render: (row) => (row.bypassed_user_restrictions ? "yes" : "no") },
        { key: "cost", header: t("label.platformCost"), render: (row) => formatCredits(row.cost_micro || 0) },
        { key: "summary", header: t("label.summary"), render: (row) => row.response_summary || row.error_message || "—" },
      ]}
    />
  );
}
