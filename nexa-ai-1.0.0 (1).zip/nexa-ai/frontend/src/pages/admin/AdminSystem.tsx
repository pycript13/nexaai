import { api } from "../../api/client";
import { Badge, Button, Card, ErrorNotice, Spinner, Stat, useApi } from "../../components/ui";
import { formatBytes } from "../../utils/format";
import { useI18n } from "../../state/app";

export function AdminSystem(): JSX.Element {
  const { t } = useI18n();
  const system = useApi<any>(() => api.get("/api/v1/admin/system"), []);
  const health = useApi<any>(() => api.get("/api/v1/health/deep"), []);

  if (system.loading || health.loading) return <Spinner />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.system")}</h1>
          <p>Live component status. A component that is not configured is reported as such instead of pretending to be healthy.</p>
        </div>
        <Button
          variant="subtle"
          type="button"
          onClick={() => {
            system.reload();
            health.reload();
          }}
        >
          {t("action.refresh")}
        </Button>
      </div>

      {system.error ? <ErrorNotice error={system.error} onRetry={system.reload} /> : null}

      <div className="grid grid--4">
        <Stat label="Status" value={String(health.data?.status ?? "—")} tone={health.data?.status === "ok" ? "success" : "warning"} />
        <Stat label="Uptime" value={`${Math.round((health.data?.uptime_seconds || 0) / 60)} min`} />
        <Stat label="Disk free" value={formatBytes(health.data?.disk?.free_bytes)} hint={health.data?.disk?.path} />
        <Stat label="Deployment mode" value={String(system.data?.deployment?.mode ?? "—")} />
      </div>

      <Card title="Components">
        <div className="kv">
          {Object.entries(health.data?.components || {}).map(([key, value]: [string, any]) => (
            <div key={key}>
              <span>{key}</span>
              <span>
                {typeof value === "object" && value !== null ? (
                  <>
                    <Badge tone={value.status === "ok" ? "success" : value.status === "error" ? "danger" : "warning"}>{value.status}</Badge>{" "}
                    <span className="muted small">{value.message || value.detail || ""}</span>
                  </>
                ) : (
                  String(value)
                )}
              </span>
            </div>
          ))}
        </div>
      </Card>

      <div className="grid grid--2">
        <Card title="Runtime">
          <div className="kv">
            {Object.entries(system.data?.runtime || {}).map(([key, value]) => (
              <div key={key}>
                <span>{key}</span>
                <span className="mono">{String(value)}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card title="Database & storage">
          <div className="kv">
            {Object.entries(system.data?.database || {}).map(([key, value]) => (
              <div key={key}>
                <span>{key}</span>
                <span className="mono">{String(value)}</span>
              </div>
            ))}
            {Object.entries(system.data?.storage || {}).map(([key, value]) => (
              <div key={`storage-${key}`}>
                <span>{key}</span>
                <span className="mono">{String(value)}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card title="Payment providers">
        <div className="kv">
          {Object.entries(health.data?.payment_providers || {}).map(([key, value]: [string, any]) => (
            <div key={key}>
              <span>{key}</span>
              <span>
                <Badge tone={value.configured ? "success" : "warning"}>{value.configured ? "configured" : "not configured"}</Badge>
              </span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
