import { useState } from "react";
import { api } from "../../api/client";
import type { Pagination as PaginationMeta } from "../../api/types";
import { Badge, Button, Card, DataTable, ErrorNotice, Field, Pagination, Spinner, Stat, useApi } from "../../components/ui";
import { formatDateTime } from "../../utils/format";
import { useI18n } from "../../state/app";

interface SecurityEvent {
  id: number;
  event_type: string;
  severity: string;
  description: string;
  email?: string | null;
  ip_address?: string | null;
  user_agent?: string | null;
  created_at: string;
}

export function AdminSecurity(): JSX.Element {
  const { t, locale } = useI18n();
  const [page, setPage] = useState(1);
  const [severity, setSeverity] = useState("");
  const events = useApi<{ items: SecurityEvent[]; pagination: PaginationMeta; summary?: Record<string, number> }>(
    () => api.get("/api/v1/admin/security-events", { page, page_size: 25, severity: severity || undefined }),
    [page, severity],
  );

  if (events.loading && !events.data) return <Spinner />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.security")}</h1>
          <p>Failed sign-ins, permission denials, suspicious input and administrative actions are recorded here.</p>
        </div>
        <Button variant="subtle" type="button" onClick={events.reload}>
          {t("action.refresh")}
        </Button>
      </div>

      {events.error ? <ErrorNotice error={events.error} onRetry={events.reload} /> : null}

      <div className="grid grid--4">
        {Object.entries(events.data?.summary || {}).map(([key, value]) => (
          <Stat key={key} label={key} value={value} tone={key.includes("critical") ? "danger" : undefined} />
        ))}
      </div>

      <Card title={t("action.filter")}>
        <Field label="Severity">
          <select value={severity} onChange={(event) => { setPage(1); setSeverity(event.target.value); }}>
            <option value="">{t("common.all")}</option>
            <option value="info">info</option>
            <option value="warning">warning</option>
            <option value="critical">critical</option>
          </select>
        </Field>
      </Card>

      <Card title={t("nav.admin.security")}>
        <DataTable
          rows={events.data?.items || []}
          columns={[
            { key: "created", header: "When", render: (row) => formatDateTime(row.created_at, locale) },
            { key: "type", header: "Event", render: (row) => <span className="mono">{row.event_type}</span> },
            { key: "severity", header: "Severity", render: (row) => <Badge tone={row.severity === "critical" ? "danger" : row.severity === "warning" ? "warning" : "info"}>{row.severity}</Badge> },
            { key: "description", header: "Description", render: (row) => row.description },
            { key: "email", header: "Account", render: (row) => row.email || "—" },
            { key: "ip", header: "IP", render: (row) => <span className="mono">{row.ip_address || "—"}</span> },
          ]}
        />
        <Pagination meta={events.data?.pagination} onChange={setPage} />
      </Card>
    </div>
  );
}
