import React, { useState } from "react";
import { api } from "../../api/client";
import type { Pagination as PaginationMeta } from "../../api/types";
import { Badge, Button, Card, ConfirmCheckbox, DataTable, ErrorNotice, Field, Modal, Pagination, Spinner, StatusBadge, useApi } from "../../components/ui";
import { formatCredits, formatDateTime } from "../../utils/format";
import { useApp, useI18n } from "../../state/app";

interface AdminUser {
  id: number;
  email: string;
  display_name: string;
  status: string;
  email_verified: boolean;
  roles: string[];
  balance_micro: number;
  lifetime_spent_micro: number;
  last_login_at: string | null;
  created_at: string;
  account_frozen: boolean;
  quota_requests_per_day: number | null;
  notes?: string | null;
}

export function AdminUsers(): JSX.Element {
  const { t, locale } = useI18n();
  const { notify, hasPermission } = useApp();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const users = useApi<{ items: AdminUser[]; pagination: PaginationMeta }>(
    () => api.get("/api/v1/admin/users", { page, page_size: 20, search: search || undefined, status: status || undefined }),
    [page, search, status],
  );
  const roles = useApi<{ items: { slug: string; name: string }[] }>(() => api.get("/api/v1/admin/roles"), []);
  const [selected, setSelected] = useState<AdminUser | null>(null);
  const [credits, setCredits] = useState("10");
  const [reason, setReason] = useState("");
  const [roleSlugs, setRoleSlugs] = useState<string[]>([]);
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);

  const openUser = (user: AdminUser) => {
    setSelected(user);
    setRoleSlugs(user.roles || []);
    setCredits("10");
    setReason("");
    setConfirmed(false);
    setError(null);
  };

  const grantCredits = async () => {
    if (!selected) return;
    setBusy(true);
    try {
      await api.post(`/api/v1/admin/users/${selected.id}/credits`, {
        amount_micro: Math.round(Number(credits) * 1_000_000),
        reason: reason || "Administrator grant",
        confirm: confirmed,
      });
      notify("success", "Credits granted through the ledger");
      users.reload();
      setSelected(null);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const setRoles = async () => {
    if (!selected) return;
    setBusy(true);
    try {
      await api.put(`/api/v1/admin/users/${selected.id}/roles`, { roles: roleSlugs, confirm: confirmed });
      notify("success", "Roles updated");
      users.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const suspend = async (suspendUser: boolean) => {
    if (!selected) return;
    setBusy(true);
    try {
      await api.post(`/api/v1/admin/users/${selected.id}/${suspendUser ? "suspend" : "reactivate"}`, { confirm: confirmed, reason: reason || undefined });
      notify("success", suspendUser ? "Account suspended" : "Account reactivated");
      users.reload();
      setSelected(null);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const revokeSessions = async () => {
    if (!selected) return;
    setBusy(true);
    try {
      await api.post(`/api/v1/admin/users/${selected.id}/sessions/revoke`, {});
      notify("success", "Sessions revoked");
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (users.loading && !users.data) return <Spinner />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.users")}</h1>
          <p>Credits are granted as ledger entries; balances are never edited directly.</p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      {users.error ? <ErrorNotice error={users.error} onRetry={users.reload} /> : null}

      <Card title={t("action.filter")}>
        <div className="grid grid--3">
          <Field label={t("action.search")}>
            <input value={search} onChange={(event) => { setPage(1); setSearch(event.target.value); }} />
          </Field>
          <Field label={t("label.status")}>
            <select value={status} onChange={(event) => { setPage(1); setStatus(event.target.value); }}>
              <option value="">{t("common.all")}</option>
              <option value="active">active</option>
              <option value="suspended">suspended</option>
              <option value="pending_verification">pending_verification</option>
            </select>
          </Field>
        </div>
      </Card>

      <Card title={t("nav.admin.users")}>
        <DataTable
          loading={users.loading}
          rows={users.data?.items || []}
          columns={[
            { key: "email", header: t("label.email"), render: (row) => <span dir="ltr">{row.email}</span> },
            { key: "name", header: t("label.displayName"), render: (row) => row.display_name || "—" },
            { key: "status", header: t("label.status"), render: (row) => <StatusBadge value={row.status} /> },
            { key: "roles", header: t("label.role"), render: (row) => <span className="mono">{row.roles.join(", ")}</span> },
            { key: "balance", header: t("label.balance"), render: (row) => formatCredits(row.balance_micro) },
            { key: "spent", header: "Spent", render: (row) => formatCredits(row.lifetime_spent_micro) },
            { key: "last", header: "Last sign-in", render: (row) => formatDateTime(row.last_login_at, locale) },
            {
              key: "actions",
              header: t("label.actions"),
              render: (row) => (
                <Button variant="ghost" type="button" onClick={() => openUser(row)}>
                  {t("action.edit")}
                </Button>
              ),
            },
          ]}
        />
        <Pagination meta={users.data?.pagination} onChange={setPage} />
      </Card>

      <Modal
        open={Boolean(selected)}
        wide
        title={selected ? selected.email : ""}
        onClose={() => setSelected(null)}
        footer={
          <Button variant="subtle" type="button" onClick={() => setSelected(null)}>
            {t("action.close")}
          </Button>
        }
      >
        {selected && (
          <div className="stack">
            <ConfirmCheckbox checked={confirmed} onChange={setConfirmed} label={t("admin.confirmSensitive")} />

            {hasPermission("credits.manage") && (
              <Card title="Grant credits">
                <div className="grid grid--3">
                  <Field label="Amount (credits)">
                    <input type="number" step="0.5" value={credits} onChange={(event) => setCredits(event.target.value)} />
                  </Field>
                  <Field label={t("label.reason")}>
                    <input value={reason} onChange={(event) => setReason(event.target.value)} />
                  </Field>
                  <div style={{ alignSelf: "end" }}>
                    <Button type="button" onClick={grantCredits} loading={busy} disabled={!confirmed}>
                      Grant
                    </Button>
                  </div>
                </div>
                <p className="muted small">
                  A grant writes one idempotent ledger entry (`admin_grant`) and updates the account atomically.
                </p>
              </Card>
            )}

            {hasPermission("roles.manage") && (
              <Card title="Roles">
                <div className="pill-list">
                  {(roles.data?.items || []).map((role) => (
                    <label key={role.slug} className="checkbox">
                      <input
                        type="checkbox"
                        checked={roleSlugs.includes(role.slug)}
                        onChange={(event) =>
                          setRoleSlugs((current) =>
                            event.target.checked ? [...current, role.slug] : current.filter((slug) => slug !== role.slug),
                          )
                        }
                      />
                      <span>{role.name}</span>
                    </label>
                  ))}
                </div>
                <div className="row" style={{ marginTop: "0.6rem" }}>
                  <Button type="button" onClick={setRoles} loading={busy} disabled={!confirmed}>
                    {t("action.save")}
                  </Button>
                </div>
              </Card>
            )}

            <Card title={t("admin.dangerZone")} danger>
              <div className="row">
                <Button variant="danger" type="button" onClick={() => suspend(true)} disabled={!confirmed || busy}>
                  Suspend account
                </Button>
                <Button variant="subtle" type="button" onClick={() => suspend(false)} disabled={!confirmed || busy}>
                  Reactivate account
                </Button>
                <Button variant="ghost" type="button" onClick={revokeSessions} disabled={busy}>
                  Revoke all sessions
                </Button>
              </div>
              <p className="muted small">
                Suspension blocks sign-in and revokes sessions immediately; existing data is preserved.
              </p>
            </Card>
          </div>
        )}
      </Modal>
    </div>
  );
}
