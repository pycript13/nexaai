import { Link } from "react-router-dom";
import { api } from "../../api/client";
import { Badge, Card, ErrorNotice, Spinner, Stat, useApi } from "../../components/ui";
import { BarChart } from "../../components/charts";
import { formatCredits, formatDateTime, formatNumber } from "../../utils/format";
import { useI18n } from "../../state/app";

interface DashboardPayload {
  users: Record<string, number>;
  ai: Record<string, unknown>;
  usage: Record<string, number>;
  finance: Record<string, unknown>;
  recent_errors: { id: number; code: string; message: string; created_at: string; count?: number }[];
  recent_audit: { id: number; action: string; summary: string; actor: string | null; created_at: string }[];
  deployment: Record<string, unknown>;
}

export function AdminDashboard(): JSX.Element {
  const { t, locale } = useI18n();
  const dashboard = useApi<DashboardPayload>(() => api.get("/api/v1/admin/dashboard"), []);

  if (dashboard.loading) return <Spinner />;
  if (dashboard.error) return <ErrorNotice error={dashboard.error} onRetry={dashboard.reload} />;
  const data = dashboard.data!;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.dashboard")}</h1>
          <p>Operational overview: every value is computed from the database, no placeholder numbers.</p>
        </div>
      </div>

      <div className="grid grid--4">
        <Stat label="Users" value={formatNumber(data.users?.total ?? 0)} hint={`${data.users?.active ?? 0} active`} />
        <Stat label="Providers" value={formatNumber(Number(data.ai?.providers ?? 0))} hint={`${data.ai?.enabled_providers ?? 0} enabled`} />
        <Stat label="Models" value={formatNumber(Number(data.ai?.models ?? 0))} hint={`${data.ai?.published_models ?? 0} published`} />
        <Stat
          label="Requests (24h)"
          value={formatNumber(data.usage?.requests_24h ?? 0)}
          hint={`${data.usage?.failures_24h ?? 0} failures`}
        />
      </div>

      <div className="grid grid--2">
        <Card title="Finance" subtitle="Integer micro-credits; no floating point arithmetic.">
          <div className="kv">
            <div>
              <span>{t("label.balance")} in circulation</span>
              <span className="mono">{formatCredits(Number(data.finance?.credits_outstanding_micro ?? 0))}</span>
            </div>
            <div>
              <span>Charged (30 days)</span>
              <span className="mono">{formatCredits(Number(data.finance?.charged_30d_micro ?? 0))}</span>
            </div>
            <div>
              <span>Provider cost (30 days)</span>
              <span className="mono">{formatCredits(Number(data.finance?.provider_cost_30d_micro ?? 0))}</span>
            </div>
            <div>
              <span>Pending payments</span>
              <span>
                {formatNumber(Number(data.finance?.pending_payments ?? 0))}{" "}
                <Link to="/app/admin/payments">review</Link>
              </span>
            </div>
            <div>
              <span>Ledger consistency</span>
              <span>
                {Number(data.finance?.ledger_inconsistencies ?? 0) === 0 ? (
                  <Badge tone="success">consistent</Badge>
                ) : (
                  <Badge tone="danger">{String(data.finance?.ledger_inconsistencies)} inconsistent accounts</Badge>
                )}
              </span>
            </div>
          </div>
        </Card>

        <Card title="Deployment" subtitle="Live values from the running process.">
          <div className="kv">
            {Object.entries(data.deployment || {}).map(([key, value]) => (
              <div key={key}>
                <span>{key}</span>
                <span>{typeof value === "string" || typeof value === "number" ? String(value) : JSON.stringify(value)}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card title="Usage by module (30 days)">
        <BarChart
          data={Object.entries(data.usage || {})
            .filter(([key]) => key.startsWith("charged_by_module") || key.includes("by_module"))
            .map(([key, value]) => ({ label: key, value: Number(value) }))}
          format={(value) => formatCredits(value)}
        />
      </Card>

      <div className="grid grid--2">
        <Card
          title="Recent errors"
          actions={<Link to="/app/admin/errors">{t("common.all")}</Link>}
        >
          {data.recent_errors?.length ? (
            <ul className="stack" style={{ listStyle: "none", padding: 0, margin: 0 }}>
              {data.recent_errors.map((error) => (
                <li key={error.id}>
                  <Badge tone="danger">{error.code}</Badge> <span>{error.message}</span>{" "}
                  <span className="muted small">{formatDateTime(error.created_at, locale)}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="muted">No errors recorded.</p>
          )}
        </Card>
        <Card title="Recent administrative actions" actions={<Link to="/app/admin/audit">{t("common.all")}</Link>}>
          {data.recent_audit?.length ? (
            <ul className="stack" style={{ listStyle: "none", padding: 0, margin: 0 }}>
              {data.recent_audit.map((entry) => (
                <li key={entry.id}>
                  <Badge tone="info">{entry.action}</Badge> <span>{entry.summary}</span>{" "}
                  <span className="muted small">
                    {entry.actor || "system"} · {formatDateTime(entry.created_at, locale)}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="muted">No audit entries yet.</p>
          )}
        </Card>
      </div>
    </div>
  );
}
