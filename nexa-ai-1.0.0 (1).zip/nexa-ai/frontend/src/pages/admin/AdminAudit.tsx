import { useState } from "react";
import { api } from "../../api/client";
import type { Pagination as PaginationMeta } from "../../api/types";
import { Badge, Button, Card, DataTable, ErrorNotice, Field, Pagination, Spinner, useApi } from "../../components/ui";
import { formatDateTime } from "../../utils/format";
import { useI18n } from "../../state/app";

interface AuditRecord {
  id: number;
  action: string;
  category: string;
  severity: string;
  summary: string;
  actor_email: string | null;
  entity_type: string | null;
  entity_id: string | null;
  ip_address: string | null;
  created_at: string;
  details?: Record<string, unknown>;
}

export function AdminAudit(): JSX.Element {
  const { t, locale } = useI18n();
  const [page, setPage] = useState(1);
  const [filters, setFilters] = useState<Record<string, string>>({});
  const audit = useApi<{ items: AuditRecord[]; pagination: PaginationMeta; categories?: string[] }>(
    () => api.get("/api/v1/admin/audit", { page, page_size: 25, ...filters }),
    [page, JSON.stringify(filters)],
  );
  const [selected, setSelected] = useState<AuditRecord | null>(null);

  if (audit.loading && !audit.data) return <Spinner />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.audit")}</h1>
          <p>The audit trail is append-only: entries can be read and filtered, never edited or deleted.</p>
        </div>
        <Button variant="subtle" type="button" onClick={audit.reload}>
          {t("action.refresh")}
        </Button>
      </div>

      {audit.error ? <ErrorNotice error={audit.error} onRetry={audit.reload} /> : null}

      <Card title={t("action.filter")}>
        <div className="grid grid--3">
          <Field label={t("action.search")}>
            <input value={filters.search || ""} onChange={(event) => { setPage(1); setFilters({ ...filters, search: event.target.value }); }} />
          </Field>
          <Field label="Severity">
            <select value={filters.severity || ""} onChange={(event) => { setPage(1); setFilters({ ...filters, severity: event.target.value }); }}>
              <option value="">{t("common.all")}</option>
              <option value="info">info</option>
              <option value="warning">warning</option>
              <option value="critical">critical</option>
            </select>
          </Field>
          <Field label="Category">
            <input value={filters.category || ""} onChange={(event) => { setPage(1); setFilters({ ...filters, category: event.target.value }); }} />
          </Field>
        </div>
      </Card>

      <Card title={t("nav.admin.audit")}>
        <DataTable
          rows={audit.data?.items || []}
          columns={[
            { key: "created", header: "When", render: (row) => formatDateTime(row.created_at, locale) },
            { key: "action", header: "Action", render: (row) => <span className="mono">{row.action}</span> },
            { key: "severity", header: "Severity", render: (row) => <Badge tone={row.severity === "critical" ? "danger" : row.severity === "warning" ? "warning" : "info"}>{row.severity}</Badge> },
            { key: "summary", header: "Summary", render: (row) => row.summary },
            { key: "actor", header: "Actor", render: (row) => row.actor_email || "system" },
            { key: "entity", header: "Entity", render: (row) => (row.entity_type ? `${row.entity_type}#${row.entity_id ?? "—"}` : "—") },
            { key: "ip", header: "IP", render: (row) => <span className="mono">{row.ip_address || "—"}</span> },
            {
              key: "actions",
              header: "",
              render: (row) => (
                <Button variant="ghost" type="button" onClick={() => setSelected(row)}>
                  {t("label.detail")}
                </Button>
              ),
            },
          ]}
        />
        <Pagination meta={audit.data?.pagination} onChange={setPage} />
      </Card>

      {selected && (
        <Card title={`${selected.action} · ${formatDateTime(selected.created_at, locale)}`}>
          <p>{selected.summary}</p>
          <pre className="md__code">{JSON.stringify(selected.details || {}, null, 2)}</pre>
        </Card>
      )}
    </div>
  );
}
