import { useState } from "react";
import { api } from "../../api/client";
import { Badge, Button, Card, ConfirmCheckbox, ErrorNotice, Field, Spinner, useApi } from "../../components/ui";
import { useApp, useI18n } from "../../state/app";

interface RoleRecord {
  id: number;
  slug: string;
  name: string;
  description: string;
  is_system: boolean;
  permissions: string[];
  user_count: number;
}

export function AdminRoles(): JSX.Element {
  const { t } = useI18n();
  const { notify } = useApp();
  const roles = useApi<{ items: RoleRecord[]; permission_groups: { group: string; permissions: { slug: string; description: string }[] }[] }>(
    () => api.get("/api/v1/admin/roles"),
    [],
  );
  const [selected, setSelected] = useState<RoleRecord | null>(null);
  const [permissions, setPermissions] = useState<string[]>([]);
  const [newRole, setNewRole] = useState({ name: "", description: "" });
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);

  const open = (role: RoleRecord) => {
    setSelected(role);
    setPermissions(role.permissions);
    setConfirmed(false);
    setError(null);
  };

  const save = async () => {
    if (!selected) return;
    setBusy(true);
    try {
      await api.put(`/api/v1/admin/roles/${selected.id}/permissions`, { permissions, confirm: confirmed });
      notify("success", "Permissions updated");
      roles.reload();
      setSelected(null);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const create = async () => {
    setBusy(true);
    try {
      await api.post("/api/v1/admin/roles", { name: newRole.name, description: newRole.description });
      notify("success", "Role created");
      setNewRole({ name: "", description: "" });
      roles.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (roles.loading) return <Spinner />;
  if (roles.error) return <ErrorNotice error={roles.error} onRetry={roles.reload} />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.roles")}</h1>
          <p>Permissions are checked on every request server-side; this page edits the stored role definitions.</p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}

      <Card title="Create a custom role">
        <div className="grid grid--3">
          <Field label="Name">
            <input value={newRole.name} onChange={(event) => setNewRole({ ...newRole, name: event.target.value })} />
          </Field>
          <Field label="Description">
            <input value={newRole.description} onChange={(event) => setNewRole({ ...newRole, description: event.target.value })} />
          </Field>
          <div style={{ alignSelf: "end" }}>
            <Button type="button" onClick={create} loading={busy} disabled={newRole.name.length < 2}>
              {t("action.create")}
            </Button>
          </div>
        </div>
      </Card>

      <div className="grid grid--3">
        {(roles.data?.items || []).map((role) => (
          <Card
            key={role.id}
            title={role.name}
            subtitle={`${role.user_count} user(s)`}
            actions={role.is_system ? <Badge tone="info">system</Badge> : <Badge tone="neutral">custom</Badge>}
          >
            <p className="muted small">{role.description}</p>
            <div className="pill-list">
              {role.permissions.slice(0, 8).map((permission) => (
                <span key={permission} className="badge badge--neutral mono">
                  {permission}
                </span>
              ))}
              {role.permissions.length > 8 ? <Badge tone="neutral">+{role.permissions.length - 8}</Badge> : null}
            </div>
            <div className="row" style={{ marginTop: "0.6rem" }}>
              <Button variant="subtle" type="button" onClick={() => open(role)}>
                Edit permissions
              </Button>
            </div>
          </Card>
        ))}
      </div>

      {selected && (
        <Card
          title={`${selected.name} — ${t("label.permissions")}`}
          actions={
            <div className="row">
              <Button variant="ghost" type="button" onClick={() => setSelected(null)}>
                {t("action.cancel")}
              </Button>
              <Button type="button" onClick={save} loading={busy} disabled={!confirmed}>
                {t("action.save")}
              </Button>
            </div>
          }
        >
          <ConfirmCheckbox checked={confirmed} onChange={setConfirmed} label={t("admin.confirmSensitive")} />
          <div className="stack" style={{ marginTop: "0.6rem" }}>
            {(roles.data?.permission_groups || []).map((group) => (
              <div key={group.group}>
                <h3>{group.group}</h3>
                <div className="grid grid--3">
                  {group.permissions.map((permission) => (
                    <label key={permission.slug} className="checkbox" title={permission.description}>
                      <input
                        type="checkbox"
                        checked={permissions.includes(permission.slug)}
                        onChange={(event) =>
                          setPermissions((current) =>
                            event.target.checked
                              ? [...current, permission.slug]
                              : current.filter((slug) => slug !== permission.slug),
                          )
                        }
                      />
                      <span className="mono">{permission.slug}</span>
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
