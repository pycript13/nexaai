import { useState } from "react";
import { api } from "../../api/client";
import { Badge, Button, Card, ConfirmCheckbox, ErrorNotice, Field, Spinner, useApi } from "../../components/ui";
import { useApp, useI18n } from "../../state/app";

/** The API returns a flat list; the page groups it by `category` for display. */
interface SettingRow {
  key: string;
  value: unknown;
  category?: string | null;
  label?: string | null;
  description?: string | null;
  is_public?: boolean;
  updated_at?: string | null;
}

/** Telegram bot status and the only honest health check: a real `getMe` call. */
function TelegramCard(): JSX.Element {
  const { t } = useI18n();
  const { notify, hasPermission } = useApp();
  const status = useApi<{
    enabled: boolean;
    configured: boolean;
    mode: string;
    bot_username: string | null;
    api_base: string;
    webhook_secret_set: boolean;
    linked_accounts: number;
    enabled_links: number;
    messages_handled: number;
    recent: { email: string | null; telegram_username: string | null; enabled: boolean; message_count: number }[];
  }>(() => api.get("/api/v1/admin/telegram/status"), []);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<unknown>(null);
  if (status.loading) return <Spinner />;
  if (status.error) return <ErrorNotice error={status.error} onRetry={status.reload} />;
  const data = status.data;
  const permission = hasPermission("settings.manage");

  const runTest = async () => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const result = await api.post<{ bot: { username?: string; first_name?: string } }>("/api/v1/admin/telegram/test");
      setNotice(`${t("telegram.testOk")}: @${result.bot?.username || "?"} (${result.bot?.first_name || ""})`.trim());
      notify("success", t("telegram.testOk"));
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const registerWebhook = async () => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const result = await api.post<{ webhook?: string }>("/api/v1/admin/telegram/webhook", {});
      setNotice(`${t("telegram.webhookSet")}: ${result.webhook || ""}`);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card
      icon="mail"
      title={t("telegram.title")}
      subtitle={data?.configured ? t("telegram.hint") : t("telegram.notConfigured")}
    >
      {error ? <ErrorNotice error={error} /> : null}
      {notice ? (
        <div className="alert alert--success">
          <div>
            <strong>{notice}</strong>
          </div>
        </div>
      ) : null}
      <div className="kv">
        <div>
          <span>{t("telegram.statusEnabled")}</span>
          <span>{data?.enabled ? <Badge tone="success">true</Badge> : <Badge tone="neutral">false</Badge>}</span>
        </div>
        <div>
          <span>{t("telegram.statusMode")}</span>
          <span className="mono">{data?.mode}</span>
        </div>
        <div>
          <span>{t("telegram.statusBot")}</span>
          <span className="mono">{data?.bot_username ? `@${data.bot_username}` : "—"}</span>
        </div>
        <div>
          <span>{t("telegram.statusLinked")}</span>
          <span className="mono">
            {data?.enabled_links ?? 0} / {data?.linked_accounts ?? 0}
          </span>
        </div>
        <div>
          <span>{t("telegram.statusMessages")}</span>
          <span className="mono">{data?.messages_handled ?? 0}</span>
        </div>
      </div>
      <div className="row" style={{ marginTop: "0.75rem" }}>
        <Button type="button" onClick={runTest} loading={busy} disabled={!permission || !data?.configured}>
          {t("telegram.test")}
        </Button>
        {data?.mode === "webhook" && (
          <Button variant="subtle" type="button" onClick={registerWebhook} disabled={!permission || busy}>
            {t("telegram.webhookRegister")}
          </Button>
        )}
      </div>
      <p className="muted small">{t("telegram.adminNote")}</p>
      {(data?.recent || []).length > 0 && (
        <table className="table table--stack">
          <thead>
            <tr>
              <th>{t("label.email")}</th>
              <th>Telegram</th>
              <th>{t("telegram.statusMessages")}</th>
            </tr>
          </thead>
          <tbody>
            {(data?.recent || []).map((row, index) => (
              <tr key={index}>
                <td data-label={t("label.email")}>{row.email || "—"}</td>
                <td className="mono" data-label="Telegram">{row.telegram_username ? `@${row.telegram_username}` : "—"}</td>
                <td className="mono" data-label={t("telegram.statusMessages")}>{row.message_count}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </Card>
  );
}

export function AdminSettings(): JSX.Element {
  const { t } = useI18n();
  const { notify, hasPermission } = useApp();
  const settings = useApi<{ items: SettingRow[]; read_only_note: string; environment: Record<string, unknown> }>(
    () => api.get("/api/v1/admin/settings"),
    [],
  );
  const [edits, setEdits] = useState<Record<string, string>>({});
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const save = async (key: string) => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const raw = edits[key];
      let value: unknown = raw;
      if (raw === "true" || raw === "false") value = raw === "true";
      else if (raw !== "" && !Number.isNaN(Number(raw))) value = Number(raw);
      const response = await api.patch<{ message?: string; restart_required?: boolean }>(`/api/v1/admin/settings/${key}`, {
        value,
        confirm: confirmed,
      });
      setNotice(
        `${response.message || `${key} updated.`}${response.restart_required ? " A restart is required for the change to take effect." : ""}`,
      );
      notify("success", `${key} updated`);
      settings.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (settings.loading) return <Spinner />;
  if (settings.error) return <ErrorNotice error={settings.error} onRetry={settings.reload} />;

  const groups = Object.entries(
    (settings.data?.items || []).reduce<Record<string, SettingRow[]>>((accumulator, row) => {
      const key = row.category || "general";
      (accumulator[key] ||= []).push(row);
      return accumulator;
    }, {}),
  ).sort(([left], [right]) => left.localeCompare(right));

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.settings")}</h1>
          <p>Only non-secret operational settings are editable here. Secrets stay in the environment file.</p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      {notice && (
        <div className="alert alert--success">
          <div>
            <strong>{notice}</strong>
          </div>
        </div>
      )}
      <div className="alert alert--warning">
        <div>
          <strong>Read-only configuration</strong>
          <p>{settings.data?.read_only_note}</p>
        </div>
      </div>

      <ConfirmCheckbox checked={confirmed} onChange={setConfirmed} label={t("admin.confirmSensitive")} />

      {groups.length === 0 ? (
        <Card title={t("status.empty")}>
          <p className="muted">{t("status.empty")}</p>
        </Card>
      ) : (
        groups.map(([category, rows]) => (
          <Card key={category} icon="sliders" title={category} subtitle={`${rows.length} setting(s)`}>
            <div className="grid grid--2">
              {rows.map((item) => {
                const editable = hasPermission("settings.manage");
                const value = edits[item.key] ?? (typeof item.value === "object" ? JSON.stringify(item.value) : String(item.value ?? ""));
                return (
                  <div key={item.key} className="stack stack--tight">
                    <Field label={item.label || item.key} hint={item.description || undefined}>
                      <input
                        value={value}
                        onChange={(event) => setEdits({ ...edits, [item.key]: event.target.value })}
                        disabled={!editable}
                      />
                    </Field>
                    <div className="row row--between">
                      <span className="muted small mono">{item.key}</span>
                      <div className="row">
                        {item.is_public ? <Badge tone="info">public</Badge> : <Badge tone="neutral">admin only</Badge>}
                        <Button
                          variant="subtle"
                          type="button"
                          onClick={() => save(item.key)}
                          disabled={!confirmed || busy || !editable}
                        >
                          {t("action.save")}
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        ))
      )}

      <TelegramCard />

      <Card title="Environment (read-only)">
        <div className="kv">
          {Object.entries(settings.data?.environment || {}).map(([key, value]) => (
            <div key={key}>
              <span>{key}</span>
              <span className="mono">{String(value)}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
