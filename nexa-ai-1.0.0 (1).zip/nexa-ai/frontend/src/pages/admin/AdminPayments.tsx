import React, { useState } from "react";
import { api, downloadFile } from "../../api/client";
import type { Pagination as PaginationMeta, Payment } from "../../api/types";
import { Badge, Button, Card, ConfirmCheckbox, DataTable, ErrorNotice, Field, Modal, Pagination, Spinner, StatusBadge, useApi } from "../../components/ui";
import { formatCredits, formatDateTime } from "../../utils/format";
import { useApp, useI18n } from "../../state/app";

export function AdminPayments(): JSX.Element {
  const { t, locale } = useI18n();
  const { notify, hasPermission } = useApp();
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState("awaiting_review");
  const payments = useApi<{ items: Payment[]; pagination: PaginationMeta }>(
    () => api.get("/api/v1/admin/billing/payments", { page, page_size: 20, status: status || undefined }),
    [page, status],
  );
  const [selected, setSelected] = useState<Payment | null>(null);
  const [note, setNote] = useState("");
  const [refundAmount, setRefundAmount] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);

  const open = (payment: Payment) => {
    setSelected(payment);
    setNote("");
    setRefundAmount(formatCredits(payment.amount_micro));
    setConfirmed(false);
    setError(null);
  };

  const approve = async () => {
    if (!selected) return;
    setBusy(true);
    setError(null);
    try {
      const response = await api.post<{ credited_micro: number }>(`/api/v1/admin/billing/payments/${selected.id}/approve`, {
        note: note || "Verified against the bank statement",
        confirm: confirmed,
      });
      notify("success", `Credited ${formatCredits(response.credited_micro)} credits (single idempotent ledger entry).`);
      payments.reload();
      setSelected(null);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const reject = async () => {
    if (!selected) return;
    setBusy(true);
    setError(null);
    try {
      await api.post(`/api/v1/admin/billing/payments/${selected.id}/reject`, { reason: note || "Not matched against the bank statement" });
      notify("success", "Payment rejected — no credits were added.");
      payments.reload();
      setSelected(null);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const refund = async () => {
    if (!selected) return;
    setBusy(true);
    setError(null);
    try {
      const response = await api.post<{ refunded_micro: number; status: string }>(`/api/v1/admin/billing/payments/${selected.id}/refund`, {
        amount_micro: Math.round(Number(refundAmount) * 1_000_000),
        reason: note || "Refund approved by administrator",
        confirm: confirmed,
      });
      notify("success", `Refund recorded as a compensating ledger entry (${response.status}).`);
      payments.reload();
      setSelected(null);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const verifyCrypto = async () => {
    if (!selected) return;
    setBusy(true);
    setError(null);
    try {
      await api.post(`/api/v1/admin/billing/payments/${selected.id}/verify-crypto`, {
        tx_hash: selected.tx_hash || undefined,
        confirmations: 2,
      });
      notify("success", "Crypto payment verification recorded");
      payments.reload();
      setSelected(null);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (payments.loading && !payments.data) return <Spinner />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.payments")}</h1>
          <p>
            Approving a manual payment posts exactly one ledger entry keyed by the payment reference; repeating the
            action is refused. Refunds are compensating entries and never delete history.
          </p>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}

      <Card title={t("action.filter")}>
        <Field label={t("label.status")}>
          <select value={status} onChange={(event) => { setPage(1); setStatus(event.target.value); }}>
            <option value="awaiting_review">awaiting_review</option>
            <option value="approved">approved</option>
            <option value="rejected">rejected</option>
            <option value="refunded">refunded</option>
            <option value="partially_refunded">partially_refunded</option>
            <option value="">{t("common.all")}</option>
          </select>
        </Field>
      </Card>

      <Card title={t("nav.admin.payments")}>
        <DataTable
          rows={payments.data?.items || []}
          loading={payments.loading}
          columns={[
            { key: "ref", header: "Reference", render: (row) => <span className="mono">{row.reference}</span> },
            { key: "amount", header: t("label.amount"), render: (row) => formatCredits(row.amount_micro) },
            { key: "method", header: t("label.method"), render: (row) => <Badge tone="neutral">{row.method}</Badge> },
            { key: "payer", header: "Payer", render: (row) => row.payer_name || "—" },
            { key: "bank", header: "Bank ref", render: (row) => <span className="mono">{row.bank_reference || "—"}</span> },
            { key: "status", header: t("label.status"), render: (row) => <StatusBadge value={row.status} /> },
            { key: "created", header: t("label.created"), render: (row) => formatDateTime(row.created_at, locale) },
            {
              key: "actions",
              header: t("label.actions"),
              render: (row) => (
                <div className="row">
                  <Button variant="ghost" type="button" onClick={() => open(row)}>
                    Review
                  </Button>
                  {row.receipt_file_id && (
                    <Button variant="ghost" type="button" onClick={() => downloadFile(`/api/v1/files/${row.receipt_file_id}/download`, `receipt-${row.reference}`)}>
                      Receipt
                    </Button>
                  )}
                </div>
              ),
            },
          ]}
        />
        <Pagination meta={payments.data?.pagination} onChange={setPage} />
      </Card>

      <Modal
        open={Boolean(selected)}
        wide
        title={selected ? `Review ${selected.reference}` : ""}
        onClose={() => setSelected(null)}
        footer={
          <>
            <Button variant="danger" type="button" onClick={reject} disabled={!confirmed || busy}>
              {t("action.reject")}
            </Button>
            {selected?.method === "crypto" && (
              <Button variant="subtle" type="button" onClick={verifyCrypto} disabled={!confirmed || busy}>
                Verify on chain
              </Button>
            )}
            <Button variant="subtle" type="button" onClick={refund} disabled={!confirmed || busy || !hasPermission("refunds.manage")}>
              {t("action.refund")}
            </Button>
            <Button type="button" onClick={approve} loading={busy} disabled={!confirmed || busy || !hasPermission("payments.approve")}>
              {t("action.approve")}
            </Button>
          </>
        }
      >
        {selected && (
          <div className="stack">
            <ConfirmCheckbox checked={confirmed} onChange={setConfirmed} label={t("admin.confirmSensitive")} />

            <div className="kv">
              <div>
                <span>{t("label.amount")}</span>
                <span className="mono">{formatCredits(selected.amount_micro)} credits</span>
              </div>
              <div>
                <span>{t("label.method")}</span>
                <span>{selected.method}</span>
              </div>
              {selected.bank_reference && (
                <div>
                  <span>Bank reference</span>
                  <span className="mono">{selected.bank_reference}</span>
                </div>
              )}
              {selected.tx_hash && (
                <div>
                  <span>Transaction</span>
                  <span className="mono">{selected.tx_hash}</span>
                </div>
              )}
              {selected.crypto_asset && (
                <div>
                  <span>Asset</span>
                  <span>
                    {selected.crypto_asset} {selected.crypto_network ? `(${selected.crypto_network})` : ""}
                  </span>
                </div>
              )}
              <div>
                <span>Submitted</span>
                <span>{formatDateTime(selected.created_at, locale)}</span>
              </div>
            </div>

            <Field label={t("label.notes")} hint="Stored in the audit trail together with your account.">
              <textarea value={note} onChange={(event) => setNote(event.target.value)} />
            </Field>

            <Field label="Refund amount (credits)" hint="Refunds debit the balance; the entry is keyed as refund:{reference}:{total} so it cannot double-post.">
              <input type="number" step="0.5" value={refundAmount} onChange={(event) => setRefundAmount(event.target.value)} />
            </Field>
          </div>
        )}
      </Modal>
    </div>
  );
}
