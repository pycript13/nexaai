import { useState } from "react";
import { api } from "../../api/client";
import type { Pagination as PaginationMeta } from "../../api/types";
import { Badge, Button, Card, DataTable, ErrorNotice, Field, Pagination, Spinner, useApi } from "../../components/ui";
import { formatDateTime } from "../../utils/format";
import { useI18n } from "../../state/app";

interface ErrorRecord {
  id: number;
  code: string;
  category: string;
  message: string;
  path?: string | null;
  method?: string | null;
  user_id?: number | null;
  request_id?: string | null;
  created_at: string;
  details?: Record<string, unknown>;
}

export function AdminErrors(): JSX.Element {
  const { t, locale } = useI18n();
  const [page, setPage] = useState(1);
  const [category, setCategory] = useState("");
  const errors = useApi<{ items: ErrorRecord[]; pagination: PaginationMeta; categories?: string[]; by_category?: Record<string, number> }>(
    () => api.get("/api/v1/admin/errors", { page, page_size: 25, category: category || undefined }),
    [page, category],
  );
  const [selected, setSelected] = useState<ErrorRecord | null>(null);

  if (errors.loading && !errors.data) return <Spinner />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.errors")}</h1>
          <p>Errors are classified with the same taxonomy the adapters use, so an invalid key is never confused with a timeout.</p>
        </div>
        <Button variant="subtle" type="button" onClick={errors.reload}>
          {t("action.refresh")}
        </Button>
      </div>

      {errors.error ? <ErrorNotice error={errors.error} onRetry={errors.reload} /> : null}

      <Card title={t("action.filter")}>
        <Field label="Category">
          <select value={category} onChange={(event) => { setPage(1); setCategory(event.target.value); }}>
            <option value="">{t("common.all")}</option>
            {(errors.data?.categories || []).map((value) => (
              <option key={value} value={value}>
                {value}
              </option>
            ))}
          </select>
        </Field>
      </Card>

      <Card title="Recent errors">
        <DataTable
          rows={errors.data?.items || []}
          columns={[
            { key: "created", header: "When", render: (row) => formatDateTime(row.created_at, locale) },
            { key: "category", header: "Category", render: (row) => <Badge tone="warning">{row.category}</Badge> },
            { key: "code", header: "Code", render: (row) => <span className="mono">{row.code}</span> },
            { key: "message", header: "Message", render: (row) => row.message },
            { key: "path", header: "Endpoint", render: (row) => <span className="mono">{row.method} {row.path}</span> },
            { key: "request", header: "Request id", render: (row) => <span className="mono">{row.request_id || "—"}</span> },
            {
              key: "actions",
              header: "",
              render: (row) => (
                <Button variant="ghost" type="button" onClick={() => setSelected(row)}>
                  {t("label.detail")}
                </Button>
              ),
            },
          ]}
        />
        <Pagination meta={errors.data?.pagination} onChange={setPage} />
      </Card>

      {selected && (
        <Card title={`${selected.category} · ${selected.code}`}>
          <p>{selected.message}</p>
          <pre className="md__code">{JSON.stringify(selected.details || {}, null, 2)}</pre>
        </Card>
      )}
    </div>
  );
}
