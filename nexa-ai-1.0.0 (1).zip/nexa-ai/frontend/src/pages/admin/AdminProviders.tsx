import React, { useState } from "react";
import { api } from "../../api/client";
import type { ProviderRecord } from "../../api/types";
import { Badge, Button, Card, ConfirmCheckbox, DataTable, ErrorNotice, Field, Modal, Spinner, StatusBadge, useApi } from "../../components/ui";
import { formatDateTime } from "../../utils/format";
import { useApp, useI18n } from "../../state/app";
import { useNavigate } from "react-router-dom";

interface Preset {
  provider_type: string;
  label: string;
  base_url: string;
  needs_api_key: boolean;
  operations: string[];
}

export function AdminProviders(): JSX.Element {
  const { t, locale } = useI18n();
  const { notify, hasPermission } = useApp();
  const providers = useApi<{ items: ProviderRecord[] }>(() => api.get("/api/v1/admin/providers"), []);
  const presets = useApi<{ adapters: Preset[] }>(() => api.get("/api/v1/meta/provider-presets"), []);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ name: "", provider_type: "openai_compatible", base_url: "", api_key: "", priority: 100, notes: "" });
  const [editing, setEditing] = useState<ProviderRecord | null>(null);
  const [editForm, setEditForm] = useState({ name: "", base_url: "", api_key: "", enabled: true, priority: 100, clear_api_key: false });
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [testResult, setTestResult] = useState<any>(null);
  const [syncResult, setSyncResult] = useState<any>(null);
  const navigate = useNavigate();

  const createProvider = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.post("/api/v1/admin/providers", {
        name: form.name,
        provider_type: form.provider_type,
        base_url: form.base_url,
        api_key: form.api_key || undefined,
        priority: Number(form.priority),
        description: form.notes,
      });
      notify("success", "Provider created. API keys are encrypted at rest.");
      setCreating(false);
      setForm({ name: "", provider_type: "openai_compatible", base_url: "", api_key: "", priority: 100, notes: "" });
      providers.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const openEdit = (provider: ProviderRecord) => {
    setEditing(provider);
    setEditForm({
      name: provider.name,
      base_url: provider.base_url,
      api_key: "",
      enabled: provider.enabled,
      priority: provider.priority,
      clear_api_key: false,
    });
    setConfirmed(false);
    setTestResult(null);
    setSyncResult(null);
  };

  const saveEdit = async () => {
    if (!editing) return;
    setBusy(true);
    setError(null);
    try {
      await api.patch(`/api/v1/admin/providers/${editing.id}`, {
        name: editForm.name,
        base_url: editForm.base_url,
        api_key: editForm.api_key || undefined,
        clear_api_key: editForm.clear_api_key,
        enabled: editForm.enabled,
        priority: Number(editForm.priority),
        confirm: confirmed,
      });
      notify("success", "Provider updated");
      providers.reload();
      setEditing(null);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const testProvider = async (provider: ProviderRecord, withModelRequest: boolean) => {
    setBusy(true);
    setError(null);
    setTestResult(null);
    try {
      const result = await api.post(`/api/v1/admin/providers/${provider.id}/test`, { with_model_request: withModelRequest });
      setTestResult(result);
      notify(result?.success === false ? "error" : "success", `Test finished: ${result?.category || result?.status || "ok"}`);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const syncModels = async (provider: ProviderRecord) => {
    setBusy(true);
    setError(null);
    setSyncResult(null);
    try {
      const result = await api.post<any>(`/api/v1/admin/providers/${provider.id}/sync`, {});
      // the endpoint answers { sync: { … }, policy_note: "…" }; the card shows the sync body
      setSyncResult({ ...(result?.sync || result), policy_note: result?.policy_note });
      notify("success", "Model list synchronised — new models stay hidden and unpublished until you verify them.");
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  if (providers.loading) return <Spinner />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.admin.providers")}</h1>
          <p>
            API keys are encrypted with the platform key and only ever displayed masked. Disabled providers cannot be
            used by any request path.
          </p>
        </div>
        <div className="row">
          <Button type="button" onClick={() => setCreating(true)}>
            Add provider
          </Button>
          <Button variant="subtle" type="button" onClick={providers.reload}>
            {t("action.refresh")}
          </Button>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      {testResult && (
        <Card title="Connection test result">
          <pre className="md__code">{JSON.stringify(testResult, null, 2)}</pre>
        </Card>
      )}
      {syncResult && (
        <Card title="Model synchronisation">
          <div className="stack" style={{ gap: "0.6rem" }}>
            <div className="row" style={{ gap: "0.6rem", flexWrap: "wrap" }}>
              <Badge tone={syncResult.created ? "success" : "neutral"}>
                {syncResult.created ?? 0} imported
              </Badge>
              <Badge tone="neutral">{syncResult.updated ?? 0} refreshed</Badge>
              <Badge tone="neutral">{syncResult.total_remote ?? 0} at the provider</Badge>
              {syncResult.skipped ? <Badge tone="warning">{syncResult.skipped} unusable</Badge> : null}
            </div>
            {(syncResult.notes || []).map((note: string, index: number) => (
              <p key={index} style={{ margin: 0 }}>{note}</p>
            ))}
            {(syncResult.new_model_ids || []).length ? (
              <div>
                <div style={{ marginBottom: "0.3rem" }}>Imported model ids:</div>
                <pre className="md__code">{syncResult.new_model_ids.join("\n")}</pre>
              </div>
            ) : null}
            <div className="row" style={{ gap: "0.5rem", flexWrap: "wrap" }}>
              <Button type="button" onClick={() => navigate("/app/admin/models?published=false")}>
                Open the unpublished models
              </Button>
              <Button variant="subtle" type="button" onClick={() => setSyncResult(null)}>
                {t("action.close")}
              </Button>
            </div>
            <details>
              <summary style={{ cursor: "pointer" }}>Raw response</summary>
              <pre className="md__code">{JSON.stringify(syncResult, null, 2)}</pre>
            </details>
          </div>
        </Card>
      )}

      <Card title={t("label.provider")}>
        <DataTable
          rows={providers.data?.items || []}
          columns={[
            { key: "name", header: "Name", render: (row) => row.name },
            { key: "type", header: "Adapter", render: (row) => <span className="mono">{row.provider_type}</span> },
            { key: "url", header: "Base URL", render: (row) => <span className="mono" dir="ltr">{row.base_url || "—"}</span> },
            { key: "credentials", header: "Credentials", render: (row) => (row.has_credentials ? <Badge tone="success">{row.api_key_hint || "set"}</Badge> : <Badge tone="danger">missing</Badge>) },
            { key: "status", header: t("label.status"), render: (row) => <StatusBadge value={row.enabled ? "enabled" : "disabled"} /> },
            { key: "models", header: "Models", render: (row) => row.model_count ?? "—" },
            { key: "last", header: "Last test", render: (row) => `${row.last_test_status || "never"} · ${formatDateTime(row.last_test_at, locale)}` },
            {
              key: "actions",
              header: t("label.actions"),
              render: (row) => (
                <div className="row">
                  <Button variant="ghost" type="button" onClick={() => openEdit(row)}>
                    {t("action.edit")}
                  </Button>
                  <Button variant="subtle" type="button" disabled={busy} onClick={() => testProvider(row, false)}>
                    {t("action.test")}
                  </Button>
                  <Button variant="subtle" type="button" disabled={busy} onClick={() => syncModels(row)}>
                    {t("action.sync")}
                  </Button>
                </div>
              ),
            },
          ]}
        />
      </Card>

      <Modal
        open={creating}
        wide
        title="Add a provider"
        onClose={() => setCreating(false)}
        footer={
          <Button type="submit" form="provider-create" loading={busy} disabled={busy}>
            {t("action.create")}
          </Button>
        }
      >
        <form id="provider-create" onSubmit={createProvider}>
          <Field label="Display name">
            <input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} required minLength={2} />
          </Field>
          <Field label="Adapter type" hint="Each adapter speaks the real provider protocol.">
            <select value={form.provider_type} onChange={(event) => setForm({ ...form, provider_type: event.target.value })}>
              {(presets.data?.adapters || []).map((preset) => (
                <option key={preset.provider_type} value={preset.provider_type}>
                  {preset.label} — {preset.operations.join(", ")}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Base URL">
            <input value={form.base_url} onChange={(event) => setForm({ ...form, base_url: event.target.value })} dir="ltr" placeholder="https://api.example.com/v1" />
          </Field>
          <Field label="API key" hint="Stored encrypted. It is never returned by the API after saving.">
            <input type="password" value={form.api_key} onChange={(event) => setForm({ ...form, api_key: event.target.value })} dir="ltr" />
          </Field>
          <Field label="Priority" hint="Lower numbers are preferred when several providers offer the same model.">
            <input type="number" value={form.priority} onChange={(event) => setForm({ ...form, priority: Number(event.target.value) })} />
          </Field>
          <Field label={t("label.notes")}>
            <textarea value={form.notes} onChange={(event) => setForm({ ...form, notes: event.target.value })} />
          </Field>
        </form>
      </Modal>

      <Modal
        open={Boolean(editing)}
        wide
        title={editing?.name || ""}
        onClose={() => setEditing(null)}
        footer={
          <>
            <Button variant="subtle" type="button" onClick={() => editing && testProvider(editing, true)} disabled={busy}>
              Test with a real request
            </Button>
            <Button type="button" onClick={saveEdit} loading={busy} disabled={!confirmed}>
              {t("action.save")}
            </Button>
          </>
        }
      >
        {editing && (
          <div className="stack">
            <ConfirmCheckbox checked={confirmed} onChange={setConfirmed} label={t("admin.confirmSensitive")} />
            <Field label="Display name">
              <input value={editForm.name} onChange={(event) => setEditForm({ ...editForm, name: event.target.value })} />
            </Field>
            <Field label="Base URL">
              <input value={editForm.base_url} onChange={(event) => setEditForm({ ...editForm, base_url: event.target.value })} dir="ltr" />
            </Field>
            <Field label="Replace API key" hint={`Current: ${editing.api_key_hint || "not set"}`}>
              <input type="password" value={editForm.api_key} onChange={(event) => setEditForm({ ...editForm, api_key: event.target.value })} dir="ltr" />
            </Field>
            <label className="checkbox">
              <input type="checkbox" checked={editForm.clear_api_key} onChange={(event) => setEditForm({ ...editForm, clear_api_key: event.target.checked })} />
              <span>Remove the stored API key</span>
            </label>
            <label className="checkbox">
              <input type="checkbox" checked={editForm.enabled} onChange={(event) => setEditForm({ ...editForm, enabled: event.target.checked })} />
              <span>Provider enabled</span>
            </label>
            <Field label="Priority">
              <input type="number" value={editForm.priority} onChange={(event) => setEditForm({ ...editForm, priority: Number(event.target.value) })} />
            </Field>
            {hasPermission("providers.credentials") ? null : (
              <p className="muted small">You need the `providers.credentials` permission to rotate API keys.</p>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
