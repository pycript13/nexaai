import React, { useState } from "react";
import { api } from "../api/client";
import { Badge, Button, Card, CopyButton, ErrorNotice, Field, SuccessNotice, useApi } from "../components/ui";
import { formatDateTime } from "../utils/format";
import { useApp, useI18n } from "../state/app";

interface TelegramStatus {
  linked: boolean;
  telegram_user_id: number | null;
  telegram_username: string | null;
  linked_at: string | null;
  last_message_at: string | null;
  message_count: number;
  bot_configured: boolean;
  bot_username: string | null;
  transport: string;
  pending_code: boolean;
}

interface LinkCode {
  code: string;
  expires_at: string;
  expires_in_minutes: number;
  bot_username: string | null;
  deep_link: string | null;
}

/**
 * Telegram bot linking. The bot only answers Telegram ids that are verified against a
 * platform account — this card produces that one-time code and severs the link again.
 */
function TelegramCard(): JSX.Element {
  const { t } = useI18n();
  const status = useApi<TelegramStatus>(() => api.get<TelegramStatus>("/api/v1/telegram/status"), []);
  const [code, setCode] = useState<LinkCode | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const createCode = async () => {
    setBusy(true);
    setError(null);
    try {
      const response = await api.post<LinkCode>("/api/v1/telegram/link-code");
      setCode(response);
      setNotice(t("telegram.codeCreated"));
      status.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const unlink = async () => {
    setBusy(true);
    setError(null);
    try {
      await api.del("/api/v1/telegram/link");
      setCode(null);
      setNotice(t("telegram.unlinked"));
      status.reload();
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  const data = status.data;
  return (
    <Card
      icon="bolt"
      title={t("telegram.title")}
      subtitle={t("telegram.hint")}
      actions={
        <Badge tone={data?.linked ? "success" : "muted"}>
          {data?.linked ? t("telegram.linked") : t("telegram.notLinked")}
        </Badge>
      }
    >
      {error ? <ErrorNotice error={error} /> : null}
      {notice ? <SuccessNotice message={notice} /> : null}
      {status.loading ? <p className="muted small">{t("status.loading")}</p> : null}
      {data && !data.bot_configured ? <p className="alert alert--warning small">{t("telegram.notConfigured")}</p> : null}

      {data?.linked ? (
        <div className="kv">
          <div>
            <span>{t("telegram.chatId")}</span>
            <span className="mono">
              {data.telegram_user_id}
              {data.telegram_username ? ` (@${data.telegram_username})` : ""}
            </span>
          </div>
          <div>
            <span>{t("telegram.messages")}</span>
            <span className="mono">{data.message_count}</span>
          </div>
          <div>
            <span>{t("telegram.lastSeen")}</span>
            <span>{data.last_message_at ? formatDateTime(data.last_message_at) : "—"}</span>
          </div>
        </div>
      ) : null}

      {code ? (
        <div className="telegram-code">
          <p className="muted small">{t("telegram.codeHint")}</p>
          <div className="telegram-code__row">
            <code className="mono telegram-code__value">{code.code}</code>
            <CopyButton value={code.code} />
          </div>
          {code.deep_link ? (
            <a className="btn btn--subtle" href={code.deep_link} target="_blank" rel="noreferrer">
              {t("telegram.openBot")}
            </a>
          ) : null}
        </div>
      ) : null}

      <div className="row" style={{ marginTop: "0.6rem", flexWrap: "wrap" }}>
        <Button variant="primary" type="button" onClick={createCode} loading={busy} disabled={busy || !data?.bot_configured}>
          {t("telegram.createCode")}
        </Button>
        {data?.linked ? (
          <Button variant="danger" type="button" onClick={unlink} disabled={busy}>
            {t("telegram.unlink")}
          </Button>
        ) : null}
      </div>
    </Card>
  );
}

export function Profile(): JSX.Element {
  const { user, refreshMe, meta } = useApp();
  const { t, locale, setLocale, locales } = useI18n();
  const [displayName, setDisplayName] = useState(user?.display_name || "");
  const [errors, setErrors] = useState<unknown>(null);
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);

  const save = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setErrors(null);
    try {
      await api.patch("/api/v1/auth/me", { display_name: displayName, locale });
      await refreshMe();
      setSaved(true);
    } catch (caught) {
      setErrors(caught);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.profile")}</h1>
          <p>Account details are stored on the server; the interface language is remembered per account.</p>
        </div>
      </div>

      {errors ? <ErrorNotice error={errors} /> : null}
      {saved && <SuccessNotice message={t("common.saved")} />}

      <div className="grid grid--2">
        <Card title={t("nav.profile")}>
          <form onSubmit={save}>
            <Field label={t("label.email")}>
              <input value={user?.email || ""} disabled dir="ltr" />
            </Field>
            <Field label={t("label.displayName")}>
              <input value={displayName} onChange={(event) => setDisplayName(event.target.value)} />
            </Field>
            <Field label={t("language.label")}>
              <select value={locale} onChange={(event) => setLocale(event.target.value as typeof locale)}>
                {locales.map((entry) => (
                  <option key={entry.code} value={entry.code}>
                    {entry.nativeLabel}
                  </option>
                ))}
              </select>
            </Field>
            <Button type="submit" loading={busy} disabled={busy}>
              {t("action.save")}
            </Button>
          </form>
        </Card>

        <Card title="Account">
          <div className="kv">
            <div>
              <span>{t("label.status")}</span>
              <span>{user?.status}</span>
            </div>
            <div>
              <span>Email verified</span>
              <span>{user?.email_verified ? t("common.yes") : t("common.no")}</span>
            </div>
            <div>
              <span>{t("label.role")}</span>
              <span>{(user?.roles || []).map((role) => (typeof role === "string" ? role : role.name || role.slug)).join(", ") || "—"}</span>
            </div>
            <div>
              <span>{t("label.permissions")}</span>
              <span>{(user?.permissions || []).length}</span>
            </div>
            <div>
              <span>{t("label.created")}</span>
              <span>{formatDateTime(user?.created_at, locale)}</span>
            </div>
            <div>
              <span>Last sign-in</span>
              <span>{formatDateTime(user?.last_login_at, locale)}</span>
            </div>
            <div>
              <span>{t("label.credits")}</span>
              <span>{meta?.credit_display_name}</span>
            </div>
            <div>
              <span>Terms / privacy version</span>
              <span>
                {meta?.terms_version} / {meta?.privacy_version}
              </span>
            </div>
          </div>
        </Card>
      </div>

      <Card title={t("label.permissions")} subtitle="Effective permissions granted by your roles.">
        <div className="pill-list">
          {(user?.permissions || []).sort().map((permission) => (
            <span key={permission} className="badge badge--neutral mono">
              {permission}
            </span>
          ))}
        </div>
      </Card>

      <div className="grid grid--2">
        <TelegramCard />
      </div>
    </div>
  );
}
