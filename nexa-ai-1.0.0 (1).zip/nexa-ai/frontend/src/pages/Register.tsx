import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useApp, useI18n } from "../state/app";
import { Button, ErrorNotice, Field, SuccessNotice } from "../components/ui";
import { AuthShell } from "../components/auth";

export function Register(): JSX.Element {
  const { register, meta } = useApp();
  const { t, locale, setLocale, locales } = useI18n();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", display_name: "", password: "", confirm: "" });
  const [accepted, setAccepted] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);
    setNotice(null);
    if (form.password !== form.confirm) {
      setError(new Error("The two passwords do not match."));
      return;
    }
    setBusy(true);
    try {
      const result = await register({
        email: form.email,
        display_name: form.display_name,
        password: form.password,
        locale,
        accept_terms: accepted,
      });
      if (result.needsVerification) {
        setNotice("Your account was created. Check your inbox to verify the email address, then sign in.");
      } else {
        navigate("/app", { replace: true });
      }
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthShell title={t("register.title")} subtitle={t("register.subtitle")}>
      {meta?.registration_mode ? (
        <p className="muted small">
          Registration mode: <strong>{meta.registration_mode}</strong>
        </p>
      ) : null}
      {error ? <ErrorNotice error={error} /> : null}
      {notice ? <SuccessNotice message={notice} /> : null}

      <form onSubmit={submit}>
        <Field label={t("label.email")}>
          <input type="email" dir="ltr" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required placeholder="you@example.com" />
        </Field>
        <Field label={t("label.displayName")}>
          <input value={form.display_name} onChange={(e) => setForm({ ...form, display_name: e.target.value })} />
        </Field>
        <Field label={t("label.password")} hint="Minimum 10 characters.">
          <input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required autoComplete="new-password" />
        </Field>
        <Field label={`${t("label.password")} (repeat)`}>
          <input type="password" value={form.confirm} onChange={(e) => setForm({ ...form, confirm: e.target.value })} required autoComplete="new-password" />
        </Field>
        <Field label={t("language.label")}>
          <select value={locale} onChange={(e) => setLocale(e.target.value as typeof locale)}>
            {locales.map((entry) => (
              <option key={entry.code} value={entry.code}>
                {entry.nativeLabel}
              </option>
            ))}
          </select>
        </Field>
        <label className="checkbox" style={{ marginBottom: "0.9rem" }}>
          <input type="checkbox" checked={accepted} onChange={(e) => setAccepted(e.target.checked)} required />
          <span>
            I accept the terms (version {meta?.terms_version || "—"}) and the privacy policy (
            {meta?.privacy_version || "—"}).
          </span>
        </label>
        <Button type="submit" loading={busy} disabled={busy || !accepted} className="btn--block">
          {t("action.register")}
        </Button>
      </form>

      <div className="row row--between" style={{ marginTop: "0.95rem" }}>
        <Link to="/login">{t("action.login")}</Link>
        <Link to="/verify-email" className="muted small">
          Verify an email address
        </Link>
      </div>
    </AuthShell>
  );
}
