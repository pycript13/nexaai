import React, { useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api/client";
import type { CatalogModel, CatalogResponse } from "../api/types";
import { Badge, Card, ErrorNotice, Field, Pagination, Spinner, useApi } from "../components/ui";
import { formatCredits, localized } from "../utils/format";
import { useI18n } from "../state/app";
import { accessReason } from "./shared";

export function Models(): JSX.Element {
  const { t, locale } = useI18n();
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [page, setPage] = useState(1);
  const catalog = useApi<CatalogResponse>(
    () => api.get<CatalogResponse>("/api/v1/models", { page, page_size: 20, ...filters }),
    [page, JSON.stringify(filters)],
  );
  const categories = useApi<{ items: { slug: string; name: string; name_fa?: string; model_count?: number }[] }>(
    () => api.get("/api/v1/models/categories"),
    [],
  );

  if (catalog.loading) return <Spinner />;
  if (catalog.error) return <ErrorNotice error={catalog.error} onRetry={catalog.reload} />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t("nav.catalog")}</h1>
          <p>
            The catalog is filtered server-side: hidden, unpublished, internal and disabled models never appear here,
            and access tiers are enforced on every request.
          </p>
        </div>
      </div>

      <Card title={t("action.filter")}>
        <div className="grid grid--4">
          <Field label={t("action.search")}>
            <input
              value={filters.search || ""}
              onChange={(event) => {
                setPage(1);
                setFilters({ ...filters, search: event.target.value });
              }}
            />
          </Field>
          <Field label={t("label.capabilities")}>
            <select
              value={filters.capability || ""}
              onChange={(event) => {
                setPage(1);
                setFilters({ ...filters, capability: event.target.value });
              }}
            >
              <option value="">{t("common.all")}</option>
              {(catalog.data?.capabilities || []).map((capability: string) => (
                <option key={capability} value={capability}>
                  {localized(catalog.data?.operation_labels?.[capability], locale, capability)}
                </option>
              ))}
            </select>
          </Field>
          <Field label={t("label.tier")}>
            <select
              value={filters.tier || ""}
              onChange={(event) => {
                setPage(1);
                setFilters({ ...filters, tier: event.target.value });
              }}
            >
              <option value="">{t("common.all")}</option>
              {(catalog.data?.tiers || []).map((tier: string) => (
                <option key={tier} value={tier}>
                  {tier}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Category">
            <select
              value={filters.category || ""}
              onChange={(event) => {
                setPage(1);
                setFilters({ ...filters, category: event.target.value });
              }}
            >
              <option value="">{t("common.all")}</option>
              {(categories.data?.items || []).map((category) => (
                <option key={category.slug} value={category.slug}>
                  {category.name}
                </option>
              ))}
            </select>
          </Field>
        </div>
      </Card>

      {(catalog.data?.items || []).length === 0 ? (
        <Card title={t("status.empty")}>
          <p className="muted">
            No model matches these filters. If you expected models here, an administrator has not published one yet.
          </p>
        </Card>
      ) : (
        <div className="grid grid--2">
          {(catalog.data?.items || []).map((model) => (
            <Card
              key={model.id}
              title={
                <Link to={`/app/models/${model.id}`}>{model.display_name}</Link>
              }
              subtitle={`${model.provider} · ${model.provider_model_id}`}
              actions={model.accessible ? <Badge tone="success">{t("status.available")}</Badge> : <Badge tone="warning">{accessReason(t, model, "short")}</Badge>}
            >
              <p className="muted small">{model.description || "No description provided."}</p>
              <div className="pill-list" style={{ marginBottom: "0.6rem" }}>
                {(model.capabilities || []).map((capability) => (
                  <Badge key={capability} tone="info">
                    {capability}
                  </Badge>
                ))}
                <Badge tone="neutral">{model.access_tier}</Badge>
                <Badge tone={model.availability === "available" ? "success" : "warning"}>{model.availability}</Badge>
              </div>
              <div className="kv">
                <div>
                  <span>Input / 1M tokens</span>
                  <span className="mono">{formatCredits((model.pricing?.input_credits_per_mtok ?? 0) * 1_000_000)} credits</span>
                </div>
                <div>
                  <span>Output / 1M tokens</span>
                  <span className="mono">{formatCredits((model.pricing?.output_credits_per_mtok ?? 0) * 1_000_000)} credits</span>
                </div>
                {model.pricing?.per_image_credits ? (
                  <div>
                    <span>Per image</span>
                    <span className="mono">{model.pricing.per_image_credits}</span>
                  </div>
                ) : null}
                <div>
                  <span>{t("label.capabilities")}</span>
                  <span>{model.context_window ? `${model.context_window} tokens` : "—"}</span>
                </div>
              </div>
              {model.pricing?.notes?.length ? <p className="muted small">{model.pricing.notes.join(" ")}</p> : null}
              <div className="row" style={{ marginTop: "0.6rem" }}>
                <Link className="btn btn--subtle" to={`/app/chat?model=${model.id}`}>
                  {t("nav.chat")}
                </Link>
                <Link className="btn btn--ghost" to={`/app/models/${model.id}`}>
                  {t("label.detail")}
                </Link>
              </div>
            </Card>
          ))}
        </div>
      )}
      <Pagination meta={catalog.data?.pagination} onChange={setPage} />
    </div>
  );
}
