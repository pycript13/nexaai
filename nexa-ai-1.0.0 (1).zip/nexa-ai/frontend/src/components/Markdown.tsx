/**
 * Minimal, dependency-free Markdown renderer for model output.
 *
 * Security: the text is escaped by React (never `dangerouslySetInnerHTML`), links
 * are restricted to http/https/mailto, and only a small subset of Markdown is
 * supported (headings, lists, code fences, inline code, bold/italic, tables are
 * rendered as preformatted text). This keeps untrusted model output safe.
 */
import React from "react";

function inline(text: string, keyPrefix: string): React.ReactNode[] {
  const nodes: React.ReactNode[] = [];
  const pattern = /(`[^`]+`)|(\*\*[^*]+\*\*)|(\*[^*]+\*)|(\[[^\]]+\]\((https?:\/\/[^\s)]+|mailto:[^\s)]+)\))/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  let index = 0;
  while ((match = pattern.exec(text)) !== null) {
    if (match.index > lastIndex) nodes.push(text.slice(lastIndex, match.index));
    const token = match[0];
    const key = `${keyPrefix}-${index++}`;
    if (token.startsWith("`")) nodes.push(<code key={key}>{token.slice(1, -1)}</code>);
    else if (token.startsWith("**")) nodes.push(<strong key={key}>{token.slice(2, -2)}</strong>);
    else if (token.startsWith("*")) nodes.push(<em key={key}>{token.slice(1, -1)}</em>);
    else {
      const label = token.slice(1, token.indexOf("]"));
      const href = token.slice(token.indexOf("](") + 2, -1);
      nodes.push(
        <a key={key} href={href} target="_blank" rel="noreferrer noopener">
          {label}
        </a>,
      );
    }
    lastIndex = pattern.lastIndex;
  }
  if (lastIndex < text.length) nodes.push(text.slice(lastIndex));
  return nodes;
}

export function Markdown({ text }: { text: string }): JSX.Element {
  const lines = (text || "").split("\n");
  const blocks: React.ReactNode[] = [];
  let buffer: string[] = [];
  let mode: "paragraph" | "code" | "list" = "paragraph";
  let codeLang = "";
  let key = 0;

  const flush = () => {
    if (buffer.length === 0) return;
    if (mode === "code") {
      blocks.push(
        <pre key={`block-${key++}`} className="md__code" data-lang={codeLang}>
          <code>{buffer.join("\n")}</code>
        </pre>,
      );
    } else if (mode === "list") {
      blocks.push(
        <ul key={`block-${key++}`}>
          {buffer.map((item, index) => (
            <li key={index}>{inline(item.replace(/^\s*[-*]\s+/, ""), `li-${key}-${index}`)}</li>
          ))}
        </ul>,
      );
    } else {
      blocks.push(<p key={`block-${key++}`}>{inline(buffer.join(" "), `p-${key}`)}</p>);
    }
    buffer = [];
  };

  for (const line of lines) {
    if (line.trim().startsWith("```")) {
      if (mode === "code") {
        flush();
        mode = "paragraph";
      } else {
        flush();
        mode = "code";
        codeLang = line.trim().slice(3);
      }
      continue;
    }
    if (mode === "code") {
      buffer.push(line);
      continue;
    }
    const heading = /^(#{1,4})\s+(.*)$/.exec(line);
    if (heading) {
      flush();
      const level = heading[1].length;
      const content = inline(heading[2], `h-${key}`);
      blocks.push(
        level <= 2 ? (
          <h3 key={`block-${key++}`}>{content}</h3>
        ) : (
          <h4 key={`block-${key++}`}>{content}</h4>
        ),
      );
      continue;
    }
    if (/^\s*[-*]\s+/.test(line)) {
      if (mode !== "list") flush();
      mode = "list";
      buffer.push(line);
      continue;
    }
    if (line.trim() === "") {
      flush();
      mode = "paragraph";
      continue;
    }
    if (mode === "list") flush();
    mode = "paragraph";
    buffer.push(line);
  }
  flush();
  return <div className="md">{blocks}</div>;
}
