"""Idempotent database bootstrap.

Runs on every start (and from the installer):
* seeds roles + permissions from the central definition,
* seeds model categories, default pricing rule and public settings,
* creates the initial Super Admin **only** when no user with any admin role
  exists, using the password supplied by the installer (never a hard-coded one),
* never overwrites existing rows, so it is safe on an existing production DB.
"""
from __future__ import annotations

import datetime as dt
from typing import Any

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.crypto import email_policy_errors, hash_password, password_policy_errors
from app.core.logging import get_logger
from app.models.admin import AppSetting
from app.models.billing import LedgerEntryType, PricingRule
from app.models.enums import ALL_PERMISSIONS, PERMISSION_GROUPS, ROLE_DEFINITIONS
from app.models.provider import ModelCategory
from app.models.user import Permission, Role, User
from app.services import audit as audit_service
from app.services import ledger as ledger_service

log = get_logger(__name__)

DEFAULT_CATEGORIES = [
    ("general", "General purpose", "مدل‌های عمومی", "Balanced models for everyday tasks", "sparkles", 10),
    ("reasoning", "Reasoning", "استدلال", "Deep reasoning and analysis models", "brain", 20),
    ("coding", "Coding", "کدنویسی", "Code generation and review models", "code", 30),
    ("vision", "Vision", "بینایی", "Image understanding models", "eye", 40),
    ("image-generation", "Image generation", "تولید تصویر", "Text-to-image models", "image", 50),
    ("audio", "Audio", "صدا", "Speech recognition and synthesis", "microphone", 60),
    ("video", "Video", "ویدیو", "Video generation models", "video", 70),
    ("embeddings", "Embeddings", "برداری‌سازی", "Vector embedding models", "grid", 80),
    ("fast", "Fast & light", "سریع و سبک", "Low-latency models for high volume", "bolt", 90),
]

DEFAULT_SETTINGS: list[dict[str, Any]] = [
    {"key": "site.name", "value": "Nexa AI", "category": "general", "label": "Platform name", "is_public": True,
     "description": "Shown in the header, emails and browser title."},
    {"key": "site.tagline", "value": "One workspace for every AI model", "category": "general", "label": "Tagline",
     "is_public": True, "description": "Short marketing line shown on the login screen."},
    {"key": "site.support_email", "value": "", "category": "general", "label": "Support email", "is_public": True,
     "description": "Displayed to users who need help."},
    {"key": "site.testing_notice", "value": "", "category": "general", "label": "Test deployment notice", "is_public": True,
     "description": "Banner shown to testers on public test deployments (e.g. 'Evaluation build — data may be reset')."},
    {"key": "registration.mode", "value": settings.registration_mode, "category": "security", "label": "Registration mode",
     "is_public": True, "description": "open | invite_only | closed"},
    {"key": "registration.require_terms_version", "value": "2026-01", "category": "legal", "label": "Terms version",
     "is_public": True, "description": "Version string stored when a user accepts the terms of service."},
    {"key": "registration.privacy_version", "value": "2026-01", "category": "legal", "label": "Privacy version",
     "is_public": True, "description": "Version string stored when a user accepts the privacy policy."},
    {"key": "registration.free_trial_credit_micro", "value": settings.free_trial_credit_micro, "category": "billing",
     "label": "Signup trial credit (micro)", "is_public": False,
     "description": "Credit granted on first registration. 0 disables the grant."},
    {"key": "billing.credit_display_name", "value": settings.credit_display_name, "category": "billing",
     "label": "Credit unit name", "is_public": True, "description": "How credits are labelled in the UI."},
    {"key": "billing.credit_usd_rate", "value": settings.credit_usd_rate, "category": "billing", "label": "USD per credit",
     "is_public": False, "description": "Used to convert provider USD prices into credits."},
    {"key": "billing.manual_payments_enabled", "value": settings.manual_payments_enabled, "category": "billing",
     "label": "Manual bank transfers", "is_public": True, "description": "Allow users to submit manual payment requests."},
    {"key": "billing.bank_transfer_instructions", "value": settings.bank_transfer_instructions, "category": "billing",
     "label": "Bank transfer instructions", "is_public": True, "description": "Shown on the manual payment form."},
    {"key": "billing.crypto_payments_enabled", "value": settings.crypto_payments_enabled, "category": "billing",
     "label": "Crypto payments", "is_public": True, "description": "Enable cryptocurrency payment requests."},
    {"key": "usage.default_max_output_tokens", "value": 2048, "category": "usage", "label": "Default max output tokens",
     "is_public": False, "description": "Applied when a model does not specify its own limit."},
    {"key": "usage.max_prompt_chars", "value": 24000, "category": "usage", "label": "Maximum prompt size (characters)",
     "is_public": False, "description": "Hard cap protecting the platform from oversized prompts."},
    {"key": "files.max_upload_mb", "value": settings.max_upload_mb, "category": "storage", "label": "Max upload size (MB)",
     "is_public": True, "description": "Per-file upload limit."},
    {"key": "files.user_quota_mb", "value": settings.user_storage_quota_mb, "category": "storage",
     "label": "Per-user storage quota (MB)", "is_public": True, "description": "Total storage a user may consume."},
    {"key": "security.password_min_length", "value": settings.password_min_length, "category": "security",
     "label": "Minimum password length", "is_public": True, "description": "Enforced on registration and password change."},
    {"key": "security.session_idle_timeout_minutes", "value": settings.session_idle_timeout_minutes,
     "category": "security", "label": "Session idle timeout (minutes)", "is_public": False, "description": "Idle sessions are revoked."},
    {"key": "deployment.mode", "value": settings.deployment_mode, "category": "deployment", "label": "Deployment mode",
     "is_public": True, "description": "local | public_ip | domain_https"},
]


def sync_permissions(db: Session) -> dict[str, int]:
    created = 0
    for group, slugs in PERMISSION_GROUPS.items():
        for slug in slugs:
            if db.scalars(select(Permission).where(Permission.slug == slug)).first() is None:
                db.add(Permission(slug=slug, group=group, description=slug.replace(".", " ").replace("_", " ").title()))
                created += 1
    db.flush()
    return {"permissions_created": created}


def sync_roles(db: Session) -> dict[str, int]:
    perms = {p.slug: p for p in db.scalars(select(Permission)).all()}
    created = updated = 0
    for slug, definition in ROLE_DEFINITIONS.items():
        role = db.scalars(select(Role).where(Role.slug == slug)).first()
        if role is None:
            role = Role(slug=slug, name=definition["name"], description=definition["description"], is_system=True)
            db.add(role)
            db.flush()
            created += 1
        else:
            role.name = definition["name"]
            role.description = definition["description"]
            role.is_system = True
            updated += 1
        wanted = set(ALL_PERMISSIONS) if "*" in definition["permissions"] else set(definition["permissions"])
        current = {p.slug for p in role.permissions}
        for slug_ in wanted - current:
            if slug_ in perms:
                role.permissions.append(perms[slug_])
        for slug_ in current - wanted:
            if slug_ not in ALL_PERMISSIONS:
                continue
            # do not silently strip permissions an operator added by hand; only sync the definition set
            continue
    db.flush()
    return {"roles_created": created, "roles_synced": updated}


def sync_categories(db: Session) -> int:
    created = 0
    for slug, name, name_fa, description, icon, order in DEFAULT_CATEGORIES:
        if db.scalars(select(ModelCategory).where(ModelCategory.slug == slug)).first() is None:
            db.add(ModelCategory(slug=slug, name=name, name_fa=name_fa, description=description, icon=icon, sort_order=order))
            created += 1
    db.flush()
    return created


def sync_settings(db: Session) -> int:
    created = 0
    for item in DEFAULT_SETTINGS:
        existing = db.scalars(select(AppSetting).where(AppSetting.key == item["key"])).first()
        if existing is None:
            db.add(
                AppSetting(
                    key=item["key"],
                    value_json={"value": item["value"]},
                    category=item["category"],
                    label=item["label"],
                    description=item["description"],
                    is_public=item["is_public"],
                )
            )
            created += 1
    db.flush()
    return created


def sync_default_pricing(db: Session) -> int:
    if db.scalars(select(PricingRule).where(PricingRule.scope == "global")).first() is not None:
        return 0
    db.add(
        PricingRule(
            name="Default platform pricing",
            scope="global",
            version=1,
            active=True,
            minimum_charge_micro=settings.minimum_charge_micro,
            markup_percent=settings.default_markup_percent,
            currency=settings.default_currency,
            notes=(
                "Baseline rule. Models without their own selling prices inherit this rule's markup and minimum charge. "
                "Per-token prices are expressed in credits per 1,000,000 tokens (stored as micro-credits per 1,000,000 tokens, so 0.28 is a valid price)."
            ),
        )
    )
    db.flush()
    return 1


DEFAULT_PLANS = [
    {
        "slug": "starter-monthly",
        "name": "Starter (monthly)",
        "name_fa": "شروع (ماهانه)",
        "description": "Entry plan for individual users: monthly credit bundle and higher daily limits.",
        "price_credits": 20,
        "included_credit_credits": 20,
        "daily_request_limit": 500,
        "monthly_token_limit": 5_000_000,
        "features": {"support": "email", "concurrent_streams": 2},
        "sort_order": 10,
    },
    {
        "slug": "pro-monthly",
        "name": "Pro (monthly)",
        "name_fa": "حرفه‌ای (ماهانه)",
        "description": "For professionals: larger bundle, higher throughput and premium model access.",
        "price_credits": 60,
        "included_credit_credits": 70,
        "daily_request_limit": 5_000,
        "monthly_token_limit": 50_000_000,
        "features": {"support": "priority", "concurrent_streams": 8, "premium_models": True},
        "sort_order": 20,
    },
    {
        "slug": "team-monthly",
        "name": "Team (monthly)",
        "name_fa": "تیمی (ماهانه)",
        "description": "Shared quota for small teams; per-seat billing is handled by the administrator.",
        "price_credits": 200,
        "included_credit_credits": 260,
        "daily_request_limit": 20_000,
        "monthly_token_limit": 200_000_000,
        "features": {"support": "priority", "concurrent_streams": 20, "premium_models": True, "seats": 5},
        "sort_order": 30,
    },
]


def sync_subscription_plans(db: Session) -> int:
    """Create the default subscription plans (idempotent, never overwrites edits)."""
    from app.models.billing import SubscriptionPlan
    from app.services.pricing import credits_to_micro

    created = 0
    for spec in DEFAULT_PLANS:
        plan = db.scalars(select(SubscriptionPlan).where(SubscriptionPlan.slug == spec["slug"])).first()
        if plan is not None:
            continue
        plan = SubscriptionPlan(
            slug=spec["slug"],
            name=spec["name"],
            name_fa=spec["name_fa"],
            description=spec["description"],
            price_micro_monthly=credits_to_micro(spec["price_credits"]) or 0,
            included_credit_micro=credits_to_micro(spec["included_credit_credits"]) or 0,
            daily_request_limit=spec["daily_request_limit"],
            monthly_token_limit=spec["monthly_token_limit"],
            features=spec["features"],
            is_active=True,
            is_public=True,
            sort_order=spec["sort_order"],
        )
        db.add(plan)
        created += 1
    if created:
        db.commit()
        log.info("seeded %s subscription plan(s)", created)
    return created


def ensure_super_admin(db: Session, *, email: str | None = None, password: str | None = None, name: str | None = None) -> dict[str, Any]:
    """Create the initial Super Admin if no administrator exists yet.

    Returns a dict describing what happened. Never resets an existing password.
    """
    email = (email or settings.bootstrap_admin_email or "").strip().lower()
    password = password or settings.bootstrap_admin_password
    name = name or settings.bootstrap_admin_name or "Nexa Administrator"

    existing_admin = db.scalars(
        select(User).join(User.roles).where(Role.slug.in_(["super_admin", "admin"]))
    ).first()
    if existing_admin is not None:
        return {"created": False, "reason": "an administrator already exists", "email": existing_admin.email}
    if not email:
        return {"created": False, "reason": "no NEXA_BOOTSTRAP_ADMIN_EMAIL configured"}
    if not password:
        return {"created": False, "reason": "no NEXA_BOOTSTRAP_ADMIN_PASSWORD configured", "email": email}
    email_problems = email_policy_errors(email)
    if email_problems:
        # Refuse here rather than after the fact: the sign-in endpoint applies the same rule, so an
        # administrator created with a reserved domain could never log in.
        return {"created": False, "reason": "bootstrap e-mail rejected: " + " ".join(email_problems), "email": email}
    errors = password_policy_errors(password, email=email, name=name)
    if errors:
        return {"created": False, "reason": "bootstrap password rejected: " + "; ".join(errors), "email": email}

    user = User(
        email=email,
        display_name=name,
        password_hash=hash_password(password),
        status="active",
        email_verified=True,
        email_verified_at=dt.datetime.now(dt.timezone.utc),
        locale="fa",
        theme="system",
        password_changed_at=dt.datetime.now(dt.timezone.utc),
        must_change_password=True,
    )
    db.add(user)
    db.flush()
    super_role = db.scalars(select(Role).where(Role.slug == "super_admin")).first()
    if super_role is not None:
        user.roles.append(super_role)
    account = ledger_service.get_account(db, user.id)
    if account is None:  # pragma: no cover - defensive
        raise RuntimeError("credit account creation failed during bootstrap")
    db.flush()
    audit_service.record_audit(
        db,
        action="user.created",
        summary=f"Initial Super Admin '{email}' created during bootstrap.",
        actor=None,
        entity_type="user",
        entity_id=user.id,
    )
    log.warning("Created initial Super Admin %s — the installer password must be changed on first login.", email)
    return {"created": True, "email": email, "user_id": user.id, "must_change_password": True}


def grant_credits(db: Session, *, user_id: int, amount_micro: int, reason: str, idempotency_key: str) -> dict:
    result = ledger_service.credit(
        db,
        user_id=user_id,
        amount_micro=amount_micro,
        entry_type=LedgerEntryType.ADMIN_GRANT,
        idempotency_key=idempotency_key,
        description=reason,
        reference_type="admin_grant",
    )
    return {"entry_id": result.entry.id, "created": result.created, "balance_after_micro": result.balance_after_micro}


def run_bootstrap(db: Session, *, create_admin: bool = True, admin_email: str | None = None, admin_password: str | None = None,
                  admin_name: str | None = None) -> dict[str, Any]:
    report: dict[str, Any] = {}
    report.update(sync_permissions(db))
    report.update(sync_roles(db))
    report["categories_created"] = sync_categories(db)
    report["settings_created"] = sync_settings(db)
    report["pricing_rules_created"] = sync_default_pricing(db)
    report["subscription_plans_created"] = sync_subscription_plans(db)
    if create_admin:
        report["super_admin"] = ensure_super_admin(db, email=admin_email, password=admin_password, name=admin_name)
    db.commit()
    log.info("bootstrap complete: %s", report)
    return report


def database_is_initialized(db: Session) -> bool:
    try:
        return db.scalar(text("SELECT COUNT(*) FROM users")) is not None
    except Exception:
        return False
