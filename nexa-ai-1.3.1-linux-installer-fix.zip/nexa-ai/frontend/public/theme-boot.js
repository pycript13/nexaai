/* Nexa AI — pre-paint bootstrap.
 *
 * Runs synchronously from <head> *before* the app bundle and before first paint, so the
 * stored theme, language and text direction are applied without a flash of the wrong
 * colours or a left-to-right layout for Persian/Arabic/Kurdish users.
 *
 * It lives in its own file on purpose: the shipped Content-Security-Policy is
 * `script-src 'self'`, so an inline <script> in index.html would be *blocked* by the
 * browser (and every page load would log a CSP violation). Keeping it external means the
 * policy stays strict and no hash has to be recomputed when this code changes.
 */
(function () {
  try {
    var root = document.documentElement;
    var saved = localStorage.getItem("nexa.theme") || "system";
    var resolved = saved;
    if (saved === "system" || saved === "auto") {
      resolved = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    }
    if (resolved === "dark" || resolved === "light") {
      root.setAttribute("data-theme", resolved);
    }
    var locale = localStorage.getItem("nexa.locale");
    if (locale) {
      var rtl = { fa: 1, ar: 1, ckb: 1 };
      root.setAttribute("lang", locale);
      root.setAttribute("dir", rtl[locale] ? "rtl" : "ltr");
    }
  } catch (error) {
    /* storage unavailable (private mode / blocked cookies) — the app resolves it after mount */
  }
})();
