/**
 * Application shell: permission-aware nested navigation, theme/language switching,
 * the deployment-mode security banner and the toast host.
 *
 * Layout: floating glass sidebar (rail on desktop, drawer on tablet/phone) + a sticky
 * command bar with breadcrumbs, balance, theme control and the account menu.
 */
import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Link, NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { api } from "../api/client";
import type { Balance, CurrentUser } from "../api/types";
import { useApp, useI18n } from "../state/app";
import type { TranslationKey } from "../locales";
import { Badge } from "./ui";
import { Icon, LogoMark, type IconName } from "./icons";
import { CommandPalette, CommandTrigger } from "./command-palette";

interface NavItem {
  to: string;
  labelKey: TranslationKey;
  permissions?: string[];
  icon?: IconName;
}

/** A collapsible second level inside a group (used by the administration tree). */
interface NavSection {
  id: string;
  labelKey: TranslationKey;
  items: NavItem[];
}

interface NavGroup {
  id: string;
  labelKey: TranslationKey;
  items: NavItem[];
  /** Optional nested level; the sidebar renders it collapsible, the palette sees a flat list. */
  sections?: NavSection[];
  permissions?: string[];
}

/**
 * Any one of these permissions reveals the administration navigation group.
 * The individual entries are additionally gated per item below, and the API
 * enforces the same slugs server-side (see backend/app/models/enums.py).
 */
const ADMIN_ANY = ["users.read", "providers.read", "models.read", "pricing.manage", "payments.read", "reports.read", "audit.read", "backups.manage"];

/**
 * The navigation as an account sees it: groups without visible items disappear, and the whole
 * administration group stays hidden unless at least one admin permission is held.
 *
 * `items` is always the **flat** list of everything reachable inside the group (direct entries plus
 * every section's entries) so consumers like the command palette offer exactly the same destinations
 * as the sidebar — a palette that could list a page the account may not open would be a lie.
 * `sections` keeps the nested shape for the collapsible sidebar.
 */
export function navGroupsFor(hasPermission: (permission: string | string[]) => boolean): NavGroup[] {
  const isAdmin = ADMIN_ANY.some((permission) => hasPermission(permission));
  return NAV.map((group) => {
    const visible = (item: NavItem) => !item.permissions || hasPermission(item.permissions);
    const sections = (group.sections || [])
      .map((section) => ({ ...section, items: section.items.filter(visible) }))
      .filter((section) => section.items.length > 0);
    const items = [...group.items.filter(visible), ...sections.flatMap((section) => section.items)];
    return { ...group, items, sections };
  }).filter((group) => group.items.length > 0 && (group.id !== "admin" || isAdmin));
}

const NAV: NavGroup[] = [
  {
    id: "root",
    labelKey: "nav.dashboard",
    items: [{ to: "/app", labelKey: "nav.dashboard", icon: "dashboard" }],
  },
  {
    id: "workspace",
    labelKey: "nav.workspace",
    items: [
      { to: "/app/chat", labelKey: "nav.chat", icon: "chat" },
      { to: "/app/coding", labelKey: "nav.coding", icon: "code" },
      { to: "/app/images", labelKey: "nav.images", icon: "image" },
      { to: "/app/documents", labelKey: "nav.documents", icon: "document" },
      { to: "/app/data", labelKey: "nav.data", icon: "data" },
      { to: "/app/translation", labelKey: "nav.translation", icon: "translate" },
      { to: "/app/audio", labelKey: "nav.audio", icon: "audio" },
      { to: "/app/video", labelKey: "nav.video", icon: "video" },
    ],
  },
  {
    id: "catalog",
    labelKey: "nav.catalog",
    items: [
      { to: "/app/models", labelKey: "nav.catalog", icon: "brain" },
      { to: "/app/files", labelKey: "nav.files", icon: "folder" },
      { to: "/app/jobs", labelKey: "nav.jobs", icon: "list" },
    ],
  },
  {
    id: "account",
    labelKey: "nav.account",
    items: [
      { to: "/app/billing", labelKey: "nav.billing", icon: "wallet" },
      { to: "/app/payments", labelKey: "nav.payments", icon: "receipt" },
      { to: "/app/subscriptions", labelKey: "nav.subscriptions", icon: "layers" },
      { to: "/app/usage", labelKey: "nav.usage", icon: "chart-line" },
      { to: "/app/profile", labelKey: "nav.profile", icon: "user" },
      { to: "/app/security", labelKey: "nav.security", icon: "lock" },
      { to: "/app/activity", labelKey: "nav.activity", icon: "clock" },
    ],
  },
  {
    // The administration tree is deliberately **nested**: 15 flat entries made the sidebar a wall,
    // so it is one overview link plus four collapsible sections. Every entry keeps its own
    // permission gate, and the API enforces the same slugs server-side.
    id: "admin",
    labelKey: "nav.admin",
    permissions: ["*admin*"],
    items: [{ to: "/app/admin", labelKey: "nav.admin.dashboard", icon: "gauge", permissions: ADMIN_ANY }],
    sections: [
      {
        id: "access",
        labelKey: "nav.admin.group.access",
        items: [
          { to: "/app/admin/users", labelKey: "nav.admin.users", icon: "users", permissions: ["users.read"] },
          { to: "/app/admin/roles", labelKey: "nav.admin.roles", icon: "key", permissions: ["roles.manage"] },
          { to: "/app/admin/security", labelKey: "nav.admin.security", icon: "shield", permissions: ["security.read"] },
        ],
      },
      {
        id: "platform",
        labelKey: "nav.admin.group.platform",
        items: [
          { to: "/app/admin/providers", labelKey: "nav.admin.providers", icon: "server", permissions: ["providers.manage"] },
          { to: "/app/admin/models", labelKey: "nav.admin.models", icon: "brain", permissions: ["models.manage"] },
          { to: "/app/admin/pricing", labelKey: "nav.admin.pricing", icon: "tag", permissions: ["pricing.manage"] },
          { to: "/app/admin/plans", labelKey: "nav.admin.plans", icon: "layers", permissions: ["subscriptions.manage"] },
        ],
      },
      {
        id: "finance",
        labelKey: "nav.admin.group.finance",
        items: [
          { to: "/app/admin/payments", labelKey: "nav.admin.payments", icon: "receipt", permissions: ["payments.read"] },
        ],
      },
      {
        id: "operations",
        labelKey: "nav.admin.group.operations",
        items: [
          { to: "/app/admin/jobs", labelKey: "nav.admin.jobs", icon: "list", permissions: ["jobs.manage"] },
          { to: "/app/admin/settings", labelKey: "nav.admin.settings", icon: "sliders", permissions: ["settings.manage"] },
          { to: "/app/admin/system", labelKey: "nav.admin.system", icon: "monitor", permissions: ["settings.manage"] },
          { to: "/app/admin/audit", labelKey: "nav.admin.audit", icon: "scroll", permissions: ["audit.read"] },
          { to: "/app/admin/errors", labelKey: "nav.admin.errors", icon: "alert", permissions: ["audit.read"] },
          { to: "/app/admin/backups", labelKey: "nav.admin.backups", icon: "database", permissions: ["backups.manage"] },
        ],
      },
    ],
  },
];

const THEME_ICONS: { value: "system" | "light" | "dark" | "glass"; icon: IconName }[] = [
  { value: "system", icon: "contrast" },
  { value: "light", icon: "sun" },
  { value: "dark", icon: "moon" },
  { value: "glass", icon: "sparkles" },
];

/** Where the sidebar's manual expand/collapse choices are remembered. */
const NAV_OPEN_KEY = "nexa.nav.open.v1";

type BannerTone = "warning" | "info";

/**
 * A single banner primitive. Long operational notices (deployment mode, testing
 * environment, installer password) are useful but eat a phone screen, so on narrow
 * viewports the body collapses behind a "Details" toggle while the headline stays
 * visible. Everything is expanded by default on tablet and desktop.
 */
function Banner({
  tone,
  icon,
  title,
  children,
  onDismiss,
}: {
  tone: BannerTone;
  icon: IconName;
  title: string;
  children: React.ReactNode;
  onDismiss?: () => void;
}): JSX.Element {
  const { t } = useI18n();
  const [expanded, setExpanded] = useState(false);
  return (
    <div className={`banner banner--${tone}${expanded ? " banner--expanded" : ""}`} role="alert">
      <div className="alert__body">
        <Icon name={icon} size={18} />
        <div className="banner__text">
          <strong>{title}</strong>
          <p className="banner__body">{children}</p>
        </div>
      </div>
      <div className="banner__actions">
        <button
          className="banner__more"
          type="button"
          aria-expanded={expanded}
          onClick={() => setExpanded((value) => !value)}
        >
          {expanded ? t("action.less") : t("action.more")}
        </button>
        {onDismiss && (
          <button className="iconbtn iconbtn--ghost" type="button" onClick={onDismiss} aria-label={t("action.close")}>
            <Icon name="close" size={16} />
          </button>
        )}
      </div>
    </div>
  );
}

export function DeploymentBanner(): JSX.Element | null {
  const { meta } = useApp();
  const { t } = useI18n();
  const [dismissed, setDismissed] = useState(false);
  if (!meta || dismissed) return null;
  // The banner title must describe what is actually printed: an installation that returns no
  // security warning but does return a testing notice used to be shown under the "insecure
  // deployment" heading, which was simply the wrong explanation (seen in the live preview).
  const securityWarning = (meta.security_warning || "").trim();
  const testingNotice = (meta.testing_notice || "").trim();
  if (!securityWarning && !testingNotice) return null;
  const body = [securityWarning, testingNotice].filter(Boolean).join("\n\n");
  return (
    <Banner
      tone={securityWarning ? "warning" : "info"}
      icon={securityWarning ? "alert" : "info"}
      title={securityWarning ? t("warning.deploymentTitle") : t("warning.testingNotice")}
      onDismiss={() => setDismissed(true)}
    >
      {body}
    </Banner>
  );
}

const TOAST_ICON: Record<string, IconName> = {
  success: "check",
  error: "alert",
  warning: "alert",
  info: "info",
};

function ToastHost(): JSX.Element {
  const { toasts, dismissToast } = useApp();
  const { t } = useI18n();
  return (
    <div className="toasts" aria-live="polite">
      {toasts.map((toast) => (
        <div key={toast.id} className={`toast toast--${toast.kind}`}>
          <div className="alert__body">
            <span className="toast__icon" aria-hidden>
              <Icon name={TOAST_ICON[toast.kind] || "info"} size={16} />
            </span>
            <div>
              <p>{toast.message}</p>
              {toast.hint && <p className="toast__hint">{toast.hint}</p>}
            </div>
          </div>
          <button
            className="iconbtn iconbtn--ghost"
            type="button"
            onClick={() => dismissToast(toast.id)}
            aria-label={t("action.close")}
          >
            <Icon name="close" size={15} />
          </button>
        </div>
      ))}
    </div>
  );
}

/** Roles arrive as `{ slug, name }` from the API, but tolerate plain slugs too. */
function roleLabel(role: { slug: string; name: string } | string): string {
  if (typeof role === "string") return role;
  return role?.name || role?.slug || "";
}

function roleLabels(roles: CurrentUser["roles"] | undefined): string {
  return (roles || []).map((role) => roleLabel(role)).filter(Boolean).join(" · ");
}

export function AppLayout(): JSX.Element {
  const { user, logout, hasPermission, theme, setTheme, meta, mustChangePassword } = useApp();
  const { t, locale, setLocale, locales } = useI18n();
  const [balance, setBalance] = useState<Balance | null>(null);
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState<"user" | "lang" | null>(null);
  const shellRef = useRef<HTMLDivElement | null>(null);
  const navigate = useNavigate();
  const location = useLocation();

  const [paletteOpen, setPaletteOpen] = useState(false);
  const groups = useMemo(() => navGroupsFor(hasPermission), [hasPermission]);

  /** True when `path` is this entry itself or one of its sub-pages ("/app" never prefix-matches). */
  const matchesPath = (item: NavItem, path: string) =>
    item.to === path || (item.to !== "/app" && path.startsWith(`${item.to}/`));

  /** Breadcrumb: the active entry plus the group (and nested section) it belongs to. */
  const trail = useMemo(() => {
    const path = location.pathname.replace(/\/$/, "");
    for (const group of groups) {
      for (const section of group.sections || []) {
        for (const item of section.items) {
          if (matchesPath(item, path)) {
            return { group: group.labelKey, section: section.labelKey, item: item.labelKey };
          }
        }
      }
    }
    for (const group of groups) {
      for (const item of group.items) {
        if (matchesPath(item, path)) return { group: group.labelKey, item: item.labelKey };
      }
    }
    return null;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [groups, location.pathname]);

  /** Which group/section holds the current route — they open automatically on navigation. */
  const activeNav = useMemo(() => {
    const path = location.pathname.replace(/\/$/, "");
    for (const group of groups) {
      for (const section of group.sections || []) {
        if (section.items.some((item) => matchesPath(item, path))) {
          return { groupId: group.id, sectionId: `${group.id}.${section.id}` };
        }
      }
      if (group.items.some((item) => matchesPath(item, path))) return { groupId: group.id, sectionId: null };
    }
    return { groupId: null, sectionId: null };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [groups, location.pathname]);

  /**
   * Collapsible navigation state. Manual choices persist per browser; navigating into a collapsed
   * group or section re-opens it (a menu that hides the page you are on would be a trap), while the
   * rest stay closed so the sidebar reads as a short, tidy tree.
   */
  const [navOpen, setNavOpen] = useState<Record<string, boolean>>(() => {
    try {
      const raw = window.localStorage.getItem(NAV_OPEN_KEY);
      return raw ? (JSON.parse(raw) as Record<string, boolean>) : {};
    } catch {
      return {};
    }
  });
  const persistNav = (next: Record<string, boolean>) => {
    try {
      window.localStorage.setItem(NAV_OPEN_KEY, JSON.stringify(next));
    } catch {
      /* private mode — the tree still works, it just does not remember */
    }
  };
  useEffect(() => {
    const { groupId, sectionId } = activeNav;
    if (!groupId) return;
    setNavOpen((prev) => {
      if (prev[groupId] === true && (!sectionId || prev[sectionId] === true)) return prev;
      const next = { ...prev, [groupId]: true };
      if (sectionId) next[sectionId] = true;
      persistNav(next);
      return next;
    });
  }, [activeNav]);
  const toggleNav = (id: string) => {
    setNavOpen((prev) => {
      const next = { ...prev, [id]: prev[id] !== true };
      persistNav(next);
      return next;
    });
  };

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    api
      .get<Balance>("/api/v1/billing/balance")
      .then((data) => {
        if (!cancelled) setBalance(data);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [user, location.pathname]);

  useEffect(() => {
    setOpen(false);
    setMenu(null);
  }, [location.pathname]);

  // Ctrl/⌘ + K opens the palette from anywhere; "/" does too when no field has focus (a shortcut
  // people expect from commercial consoles). Escape is handled inside the palette itself.
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing = !!target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable);
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setPaletteOpen((value) => !value);
        return;
      }
      if (event.key === "/" && !typing && !event.ctrlKey && !event.metaKey && !event.altKey) {
        event.preventDefault();
        setPaletteOpen(true);
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  // Click-outside + Escape close the popovers.
  useEffect(() => {
    if (!menu) return;
    const onDown = (event: MouseEvent) => {
      if (shellRef.current && !shellRef.current.contains(event.target as Node)) setMenu(null);
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenu(null);
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [menu]);

  // Header popovers are placed in JS. The trigger cluster wraps to different physical sides
  // depending on width AND direction (right edge on phones, left edge on a wide RTL desktop), so
  // any pure-CSS anchor puts the card off-screen somewhere. The card is fixed, hung under its
  // trigger and clamped into the viewport — the contract commercial consoles ship.
  useLayoutEffect(() => {
    if (!menu) return undefined;
    const node = shellRef.current?.querySelector<HTMLElement>(".menu") || null;
    const trigger = shellRef.current?.querySelector<HTMLElement>(
      menu === "user" ? ".user-chip__button" : ".user-chip .iconbtn",
    );
    if (!node || !trigger) return undefined;
    const place = () => {
      const box = trigger.getBoundingClientRect();
      const width = node.offsetWidth;
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const left = Math.min(Math.max(12, box.right - width), Math.max(12, vw - width - 12));
      const top = Math.min(box.bottom + 8, Math.max(12, vh - 160));
      node.style.position = "fixed";
      node.style.right = "auto";
      node.style.left = `${left}px`;
      node.style.top = `${top}px`;
      node.style.maxHeight = `${Math.max(160, vh - top - 12)}px`;
      node.style.overflowY = "auto";
    };
    place();
    window.addEventListener("resize", place);
    return () => window.removeEventListener("resize", place);
  }, [menu]);

  useEffect(() => {
    if (open) {
      const onKey = (event: KeyboardEvent) => {
        if (event.key === "Escape") setOpen(false);
      };
      document.addEventListener("keydown", onKey);
      return () => document.removeEventListener("keydown", onKey);
    }
    return undefined;
  }, [open]);

  const themesAvailable = THEME_ICONS.filter((entry) => entry.value !== "glass" || meta?.enhanced_theme_available);

  return (
    <div className="shell" ref={shellRef}>
      <a className="skip-link" href="#main-content">
        {t("nav.dashboard")}
      </a>

      <button
        type="button"
        className={`sidebar-backdrop ${open ? "sidebar-backdrop--open" : ""}`}
        aria-label={t("action.close")}
        tabIndex={open ? 0 : -1}
        onClick={() => setOpen(false)}
      />

      <aside className={`sidebar ${open ? "sidebar--open" : ""}`} aria-label={t("nav.menu")}>
        <div className="sidebar__panel">
          <div className="sidebar__brand">
            <Link to="/app" className="brand">
              <LogoMark />
              <span className="brand__text">
                <strong>{meta?.app_name || t("app.name")}</strong>
                <small>{meta?.version ? `v${meta.version}` : t("app.tagline")}</small>
              </span>
            </Link>
            <button
              type="button"
              className="iconbtn iconbtn--ghost sidebar__close"
              onClick={() => setOpen(false)}
              aria-label={t("action.close")}
            >
              <Icon name="close" size={16} />
            </button>
          </div>

          <nav className="sidebar__nav">
            {groups.map((group) => {
              const renderLink = (item: NavItem) => (
                <li key={item.to}>
                  <NavLink
                    to={item.to}
                    // Overview routes are pages of their own, not prefixes of their children: without
                    // `end`, /app and /app/admin would light up on every deeper page (two "active"
                    // links at once — one page, one active entry).
                    end={item.to === "/app" || item.to === "/app/admin"}
                    className={({ isActive }) => `navlink ${isActive ? "navlink--active" : ""}`}
                  >
                    <span className="navlink__icon" aria-hidden>
                      {item.icon ? <Icon name={item.icon} size={17} /> : null}
                    </span>
                    <span className="navlink__text">{t(item.labelKey)}</span>
                  </NavLink>
                </li>
              );

              // The dashboard group holds a single entry — a toggle around one link is noise.
              const sections = group.sections || [];
              if (sections.length === 0 && group.items.length === 1 && group.id === "root") {
                return (
                  <div key={group.id} className="navgroup navgroup--single">
                    <ul>{group.items.map(renderLink)}</ul>
                  </div>
                );
              }

              const open = navOpen[group.id] === true;
              const sectionKeys = new Set(sections.flatMap((section) => section.items.map((item) => item.to)));
              const direct = group.items.filter((item) => !sectionKeys.has(item.to));
              return (
                <div key={group.id} className={`navgroup ${open ? "navgroup--open" : ""}`}>
                  <button
                    type="button"
                    className="navgroup__toggle"
                    aria-expanded={open}
                    onClick={() => toggleNav(group.id)}
                  >
                    <span className="navgroup__chevron" aria-hidden>
                      <Icon name="chevron-down" size={13} />
                    </span>
                    <span className="navgroup__label">{t(group.labelKey)}</span>
                    <span className="navgroup__count" aria-hidden>
                      {group.items.length}
                    </span>
                  </button>
                  <div className="navgroup__body">
                    <div className="navgroup__inner">
                      <ul>
                        {direct.map(renderLink)}
                        {sections.map((section) => {
                          const sectionKey = `${group.id}.${section.id}`;
                          const sectionOpen = navOpen[sectionKey] === true;
                          return (
                            <li key={section.id} className={`navsection ${sectionOpen ? "navsection--open" : ""}`}>
                              <button
                                type="button"
                                className="navsection__toggle"
                                aria-expanded={sectionOpen}
                                onClick={() => toggleNav(sectionKey)}
                              >
                                <span className="navgroup__chevron" aria-hidden>
                                  <Icon name="chevron-down" size={12} />
                                </span>
                                <span className="navsection__label">{t(section.labelKey)}</span>
                                <span className="navgroup__count" aria-hidden>
                                  {section.items.length}
                                </span>
                              </button>
                              <div className="navsection__body">
                                <div className="navsection__inner">
                                  <ul>{section.items.map(renderLink)}</ul>
                                </div>
                              </div>
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  </div>
                </div>
              );
            })}
          </nav>

          <div className="sidebar__foot">
            {balance && (
              <Link to="/app/billing" className="side-credit">
                <span className="side-credit__label">
                  <Icon name="wallet" size={14} />
                  {t("label.balance")}
                </span>
                <span className="side-credit__value">
                  {balance.balance_display} <small className="muted">{balance.credit_display_name}</small>
                </span>
              </Link>
            )}
            <div className="sidebar__meta">
              <span>{meta?.environment}</span>
              <Badge tone="info">{meta?.deployment_mode}</Badge>
            </div>
          </div>
        </div>
      </aside>

      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} />

      <div className="main">
        <header className="topbar">
          <button
            className="iconbtn topbar__menu"
            onClick={() => setOpen((value) => !value)}
            type="button"
            aria-label={t("nav.menu")}
            aria-expanded={open}
          >
            <Icon name={open ? "close" : "menu"} size={19} />
          </button>

          <nav className="crumbs" aria-label={t("nav.dashboard")}>
            {trail ? (
              <>
                <span>{t(trail.group)}</span>
                {trail.section ? (
                  <>
                    <span className="crumbs__sep" aria-hidden>
                      /
                    </span>
                    <span>{t(trail.section)}</span>
                  </>
                ) : null}
                <span className="crumbs__sep" aria-hidden>
                  /
                </span>
                <strong>{t(trail.item)}</strong>
              </>
            ) : (
              <strong>{meta?.app_name || t("app.name")}</strong>
            )}
          </nav>

          <div className="topbar__spacer" />

          <CommandTrigger onOpen={() => setPaletteOpen(true)} />

          {balance && (
            <Link to="/app/billing" className="topbar__balance" title={t("billing.balance")}>
              <span>{t("label.balance")}</span>
              <strong>
                {balance.balance_display} {balance.credit_display_name}
              </strong>
            </Link>
          )}

          <button
            className="iconbtn topbar__compact"
            type="button"
            onClick={() => {
              const index = themesAvailable.findIndex((entry) => entry.value === theme);
              const next = themesAvailable[(index + 1) % themesAvailable.length];
              setTheme(next.value);
            }}
            title={`${t("theme.label")}: ${t(`theme.${theme}` as TranslationKey)}`}
            aria-label={`${t("theme.label")}: ${t(`theme.${theme}` as TranslationKey)}`}
          >
            <Icon name={THEME_ICONS.find((entry) => entry.value === theme)?.icon || "contrast"} size={18} />
          </button>

          <div className="segmented" role="group" aria-label={t("theme.label")}>
            {themesAvailable.map((entry) => (
              <button
                key={entry.value}
                type="button"
                aria-pressed={theme === entry.value}
                onClick={() => setTheme(entry.value)}
                title={t(`theme.${entry.value}` as TranslationKey)}
                aria-label={t(`theme.${entry.value}` as TranslationKey)}
              >
                <Icon name={entry.icon} size={16} />
              </button>
            ))}
          </div>

          <div className="user-chip">
            <button
              type="button"
              className="iconbtn"
              onClick={() => setMenu(menu === "lang" ? null : "lang")}
              aria-label={t("language.label")}
              aria-expanded={menu === "lang"}
              title={t("language.label")}
            >
              <Icon name="languages" size={18} />
            </button>
            {menu === "lang" && (
              <div className="menu" role="menu">
                <div className="lang-row">
                  {locales.map((entry) => (
                    <button
                      key={entry.code}
                      type="button"
                      aria-pressed={locale === entry.code}
                      onClick={() => {
                        setLocale(entry.code);
                        setMenu(null);
                      }}
                    >
                      {entry.nativeLabel}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="user-chip">
            <button
              type="button"
              className="user-chip__button"
              onClick={() => setMenu(menu === "user" ? null : "user")}
              aria-expanded={menu === "user"}
              aria-haspopup="menu"
            >
              <span className="avatar" aria-hidden>
                {(user?.display_name || user?.email || "?")
                  .split(/[\s@._-]+/)
                  .filter(Boolean)
                  .slice(0, 2)
                  .map((part) => part[0]?.toUpperCase())
                  .join("")}
              </span>
              <span className="user-chip__text">
                <span className="topbar__name">{user?.display_name || user?.email}</span>
                <span className="topbar__roles">{roleLabels(user?.roles)}</span>
              </span>
              <Icon name="chevron-down" size={15} />
            </button>

            {menu === "user" && (
              <div className="menu" role="menu">
                <div className="menu__head">
                  <strong>{user?.display_name || user?.email}</strong>
                  <span className="muted small">{user?.email}</span>
                  {user?.roles?.length ? <span className="small muted">{roleLabels(user.roles)}</span> : null}
                </div>
                <Link className="menu__item" to="/app/profile" role="menuitem">
                  <Icon name="user" size={16} />
                  {t("nav.profile")}
                </Link>
                <Link className="menu__item" to="/app/security" role="menuitem">
                  <Icon name="lock" size={16} />
                  {t("nav.security")}
                </Link>
                <Link className="menu__item" to="/app/billing" role="menuitem">
                  <Icon name="wallet" size={16} />
                  {t("nav.billing")}
                </Link>
                <div className="menu__sep" />
                <div className="menu__quick">
                  <span className="menu__quick-label">
                    <Icon name="contrast" size={13} /> {t("theme.label")}
                  </span>
                  <div className="menu__quick-row">
                    {themesAvailable.map((entry) => (
                      <button
                        key={entry.value}
                        type="button"
                        aria-pressed={theme === entry.value}
                        onClick={() => setTheme(entry.value)}
                      >
                        {t(`theme.${entry.value}` as TranslationKey)}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="menu__quick">
                  <span className="menu__quick-label">
                    <Icon name="languages" size={13} /> {t("language.label")}
                  </span>
                  <div className="menu__quick-row">
                    {locales.map((entry) => (
                      <button
                        key={entry.code}
                        type="button"
                        aria-pressed={locale === entry.code}
                        onClick={() => setLocale(entry.code)}
                      >
                        {entry.nativeLabel}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="menu__sep" />
                <button
                  className="menu__item menu__item--danger"
                  type="button"
                  role="menuitem"
                  onClick={async () => {
                    await logout();
                    navigate("/login");
                  }}
                >
                  <Icon name="logout" size={16} />
                  {t("action.logout")}
                </button>
              </div>
            )}
          </div>
        </header>

        {mustChangePassword && (
          <Banner tone="warning" icon="lock" title={t("nav.security")}>
            This account still uses the password created by the installer. Change it now in{" "}
            <Link to="/app/security">{t("nav.security")}</Link>.
          </Banner>
        )}

        <DeploymentBanner />

        <main className="content" id="main-content">
          <Outlet />
        </main>
        <footer className="foot">
          <span>
            {meta?.app_name} · v{meta?.version} · {meta?.environment}
          </span>
          {meta?.support_email && <span>{meta.support_email}</span>}
        </footer>
      </div>
      <ToastHost />
    </div>
  );
}
