/**
 * Application state: session, permissions, theme, language and the deployment
 * banner. Everything is sourced from the real backend (`/auth/me`, `/meta/config`);
 * nothing is mocked.
 */
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { api, setCsrfToken, setUnauthorizedHandler, ApiError } from "../api/client";
import type { CurrentUser, MeResponse, MetaConfig } from "../api/types";
import { LOCALES, dictionaries, isLocale, type LocaleCode, type TranslationKey } from "../locales";

export type ThemeChoice = "light" | "dark" | "system" | "glass";

type Toast = { id: number; kind: "success" | "error" | "info" | "warning"; message: string; hint?: string };

interface AppState {
  ready: boolean;
  meta: MetaConfig | null;
  user: CurrentUser | null;
  permissions: Set<string>;
  theme: ThemeChoice;
  locale: LocaleCode;
  direction: "rtl" | "ltr";
  mustChangePassword: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (payload: Record<string, unknown>) => Promise<{ needsVerification: boolean }>;
  logout: () => Promise<void>;
  refreshMe: () => Promise<void>;
  hasPermission: (permission: string | string[]) => boolean;
  setTheme: (theme: ThemeChoice) => void;
  setLocale: (locale: LocaleCode) => void;
  t: (key: TranslationKey, fallback?: string) => string;
  toasts: Toast[];
  notify: (kind: Toast["kind"], message: string, hint?: string) => void;
  dismissToast: (id: number) => void;
}

const AppContext = createContext<AppState | null>(null);

function resolveTheme(choice: ThemeChoice): "light" | "dark" | "glass" {
  if (choice !== "system") return choice;
  if (typeof window !== "undefined" && window.matchMedia("(prefers-color-scheme: dark)").matches) return "dark";
  return "light";
}

function stored(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function readStored<T extends string>(key: string, allowed: readonly T[], fallback: T): T {
  try {
    const value = localStorage.getItem(key) as T | null;
    if (value && allowed.includes(value)) return value;
  } catch {
    /* storage may be disabled (private mode) — fall back silently */
  }
  return fallback;
}

export function AppProvider({ children }: { children: React.ReactNode }): JSX.Element {
  const [ready, setReady] = useState(false);
  const [meta, setMeta] = useState<MetaConfig | null>(null);
  const [user, setUser] = useState<CurrentUser | null>(null);
  const [permissions, setPermissions] = useState<Set<string>>(new Set());
  const [theme, setThemeState] = useState<ThemeChoice>(() =>
    readStored<ThemeChoice>("nexa.theme", ["light", "dark", "system", "glass"], "system"),
  );
  const [locale, setLocaleState] = useState<LocaleCode>(() => {
    const stored = (() => {
      try {
        return localStorage.getItem("nexa.locale");
      } catch {
        return null;
      }
    })();
    return isLocale(stored) ? stored : "fa";
  });
  const [mustChangePassword, setMustChangePassword] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);

  const notify = useCallback((kind: Toast["kind"], message: string, hint?: string) => {
    const id = Date.now() + Math.random();
    setToasts((current) => [...current, { id, kind, message, hint }]);
    window.setTimeout(() => setToasts((current) => current.filter((toast) => toast.id !== id)), 7000);
  }, []);

  const dismissToast = useCallback((id: number) => {
    setToasts((current) => current.filter((toast) => toast.id !== id));
  }, []);

  const refreshMe = useCallback(async () => {
    try {
      const data = await api.get<MeResponse>("/api/v1/auth/me");
      setUser(data.user);
      setPermissions(new Set([...(data.permissions || []), ...(data.user?.permissions || [])]));
      setMustChangePassword(Boolean(data.user?.must_change_password));
      // The account copy is the fallback for a device that has never chosen; an
      // explicit local choice always wins, otherwise the pre-paint script in
      // index.html and the switcher itself would be undone on every reload.
      const storedTheme = stored("nexa.theme");
      const storedLocale = stored("nexa.locale");
      if (isLocale(storedLocale) && storedLocale !== locale) setLocaleState(storedLocale);
      else if (!storedLocale && data.locale && isLocale(data.locale) && data.locale !== locale) setLocaleState(data.locale);
      if (storedTheme && ["light", "dark", "system", "glass"].includes(storedTheme)) {
        if (storedTheme !== theme) setThemeState(storedTheme as ThemeChoice);
      } else if (data.user?.theme && ["light", "dark", "system", "glass"].includes(data.user.theme)) {
        setThemeState(data.user.theme as ThemeChoice);
      }
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) {
        setUser(null);
        setPermissions(new Set());
        setCsrfToken(null);
        return;
      }
      throw error;
    }
  }, [locale, theme]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const config = await api.get<MetaConfig>("/api/v1/meta/config");
        if (!cancelled) setMeta(config);
      } catch {
        /* the banner falls back to "unknown" rather than blocking the app */
      }
      try {
        await refreshMe();
      } catch {
        /* not signed in yet */
      }
      if (!cancelled) setReady(true);
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    setUnauthorizedHandler(() => {
      setUser(null);
      setPermissions(new Set());
      setCsrfToken(null);
    });
    return () => setUnauthorizedHandler(null);
  }, []);

  const direction = useMemo(() => {
    const entry = LOCALES.find((item) => item.code === locale);
    return entry ? entry.direction : "rtl";
  }, [locale]);

  useEffect(() => {
    const resolved = resolveTheme(theme);
    document.documentElement.dataset.theme = resolved;
    document.documentElement.dataset.themeChoice = theme;
    document.documentElement.lang = locale;
    document.documentElement.dir = direction;
    try {
      localStorage.setItem("nexa.theme", theme);
      localStorage.setItem("nexa.locale", locale);
    } catch {
      /* ignore storage failures */
    }
  }, [theme, locale, direction]);

  const setTheme = useCallback(
    (next: ThemeChoice) => {
      setThemeState(next);
      if (user) {
        api.patch("/api/v1/auth/me", { theme: next }).catch(() => undefined);
      }
    },
    [user],
  );

  const setLocale = useCallback(
    (next: LocaleCode) => {
      setLocaleState(next);
      if (user) {
        api.patch("/api/v1/auth/me", { locale: next }).catch(() => undefined);
      }
    },
    [user],
  );

  const login = useCallback(
    async (email: string, password: string) => {
      const data = await api.post<{ user: CurrentUser; csrf_token?: string; must_change_password?: boolean }>(
        "/api/v1/auth/login",
        { email, password },
      );
      if (data.csrf_token) setCsrfToken(data.csrf_token);
      setUser(data.user);
      setMustChangePassword(Boolean(data.must_change_password ?? data.user?.must_change_password));
      setPermissions(new Set(data.user?.permissions || []));
      await refreshMe();
    },
    [refreshMe],
  );

  const register = useCallback(async (payload: Record<string, unknown>) => {
    const data = await api.post<{
      needs_email_verification?: boolean;
      verification_required?: boolean;
      csrf_token?: string;
      user?: CurrentUser;
    }>("/api/v1/auth/register", payload);
    if (data.csrf_token) setCsrfToken(data.csrf_token);
    // The API answers `verification_required`; the screen used to read a key that never existed, so a
    // pending account was sent into the app instead of being told to check its inbox.
    const needsVerification = Boolean(data.verification_required ?? data.needs_email_verification);
    // Registration signs the visitor in (unless the address must be verified first). Adopt the
    // session right here: the shipped build navigated to /app while the store still had `user = null`,
    // and the route guard bounced the brand-new account straight back to the sign-in screen.
    if (!needsVerification) {
      if (data.user) {
        setUser(data.user);
        setPermissions(new Set(data.user.permissions || []));
      }
      await refreshMe();
    }
    return { needsVerification };
  }, [refreshMe]);

  const logout = useCallback(async () => {
    try {
      await api.post("/api/v1/auth/logout", {});
    } finally {
      setUser(null);
      setPermissions(new Set());
      setCsrfToken(null);
    }
  }, []);

  const hasPermission = useCallback(
    (permission: string | string[]) => {
      if (!user) return false;
      const requested = Array.isArray(permission) ? permission : [permission];
      if (permissions.has("*")) return true;
      return requested.every((item) => permissions.has(item));
    },
    [permissions, user],
  );

  const t = useCallback(
    (key: TranslationKey, fallback?: string) => {
      const dictionary = dictionaries[locale] || dictionaries.en;
      return dictionary[key] || dictionaries.en[key] || fallback || String(key);
    },
    [locale],
  );

  const value: AppState = {
    ready,
    meta,
    user,
    permissions,
    theme,
    locale,
    direction,
    mustChangePassword,
    login,
    register,
    logout,
    refreshMe,
    hasPermission,
    setTheme,
    setLocale,
    t,
    toasts,
    notify,
    dismissToast,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppState {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used inside AppProvider");
  return context;
}

/** Convenience hook: `const { t, locale, direction } = useI18n();` */
export function useI18n() {
  const { t, locale, direction, setLocale } = useApp();
  return { t, locale, direction, setLocale, locales: LOCALES };
}
