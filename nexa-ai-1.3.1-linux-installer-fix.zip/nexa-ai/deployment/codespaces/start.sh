#!/usr/bin/env bash
# =============================================================================
# Nexa AI — start the app inside a cloud development workspace
#              (GitHub Codespaces, Gitpod, a dev container, any Linux box)
#
#   bash deployment/codespaces/start.sh            # one port: the API serves the built SPA (8080)
#   bash deployment/codespaces/start.sh --dev      # two ports: Vite dev server (5173) + API (8081)
#   bash deployment/codespaces/start.sh --daemon   # the same, detached, with logs in .run/
#   bash deployment/codespaces/start.sh --stop     # stop whatever this script started
#
# Always binds 0.0.0.0: a forwarded port inside a container never sees 127.0.0.1 from outside.
# =============================================================================
set -Eeuo pipefail

SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/$(basename "${BASH_SOURCE[0]}")"
ROOT="$(cd "$(dirname "${SELF}")/../.." && pwd)"
cd "${ROOT}"

CYAN=$'\033[36m'; GREEN=$'\033[32m'; YELLOW=$'\033[33m'; RED=$'\033[31m'; BOLD=$'\033[1m'; OFF=$'\033[0m'
step() { printf '%s==>%s %s\n' "${CYAN}${BOLD}" "${OFF}" "$*"; }
ok()   { printf '  %s✓%s %s\n' "${GREEN}" "${OFF}" "$*"; }
warn() { printf '  %s!%s %s\n' "${YELLOW}" "${OFF}" "$*"; }
die()  { printf '  %s✗%s %s\n' "${RED}" "${OFF}" "$*" >&2; exit 1; }

MODE="single"; DAEMON=0; ACTION="start"
for arg in "$@"; do
  case "${arg}" in
    --dev) MODE="dev" ;;
    --single) MODE="single" ;;
    --daemon) DAEMON=1 ;;
    --stop) ACTION="stop" ;;
    -h|--help) sed -n '3,12p' "${SELF}" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) die "unknown option ${arg} (see --help)" ;;
  esac
done

RUN_DIR="${ROOT}/.run"
mkdir -p "${RUN_DIR}"
API_PORT="${NEXA_PORT:-8080}"
DEV_API_PORT="${NEXA_DEV_API_PORT:-8081}"
WEB_PORT="${NEXA_WEB_PORT:-5173}"
VENV_PY="${ROOT}/.venv/bin/python"
ENV_FILE="${ROOT}/backend/.env"

port_in_use() { (exec 3<>"/dev/tcp/127.0.0.1/$1") 2>/dev/null && { exec 3<&- 3>&-; return 0; } || return 1; }

stop_all() {
  local stopped=0
  for name in api web; do
    local pidfile="${RUN_DIR}/${name}.pid"
    [[ -f "${pidfile}" ]] || continue
    local pid; pid="$(cat "${pidfile}" 2>/dev/null || true)"
    if [[ -n "${pid}" ]] && kill -0 "${pid}" 2>/dev/null; then
      # The pidfile holds the *server* process (start_api/start_web `exec` into it), so a plain kill
      # reaches the process that owns the port — no orphaned child left holding it.
      kill "${pid}" 2>/dev/null || true
      sleep 1
      if kill -0 "${pid}" 2>/dev/null; then kill -9 "${pid}" 2>/dev/null || true; sleep 1; fi
      ok "stopped ${name} (pid ${pid})"
      stopped=1
    fi
    rm -f "${pidfile}"
  done
  # Belt and braces: something started outside this script on the same port is reported, not guessed at.
  for name in api web; do
    local port; port="$( [[ "${name}" == "api" ]] && echo "${API_PORT}" || echo "${WEB_PORT}" )"
    if port_in_use "${port}" && ! pgrep -f "uvicorn app.main:app --host 0.0.0.0 --port ${port}" >/dev/null 2>&1; then
      warn "port ${port} is still in use by a process this script does not own"
    fi
  done
  [[ "${stopped}" -eq 1 ]] || warn "nothing of mine was running"
}
[[ "${ACTION}" == "stop" ]] && { stop_all; exit 0; }

[[ -f "${ENV_FILE}" ]] || die "${ENV_FILE} is missing — run: bash deployment/codespaces/setup.sh"
[[ -x "${VENV_PY}" ]] || die "${VENV_PY} is missing — run: bash deployment/codespaces/setup.sh"

# The forwarded URL of a workspace changes on every rebuild. If host checking is strict, every request
# — including sign-up — answers 400. Tell the truth here instead of letting the browser fail.
if ! grep -qE '^NEXA_ALLOW_DEV_HOSTS=(true|1|yes|on)$' "${ENV_FILE}"; then
  if [[ -n "${CODESPACES:-}${GITPOD_WORKSPACE_ID:-}${DAYTONA_SANDBOX_ID:-}" ]]; then
    printf '\nNEXA_ALLOW_DEV_HOSTS=true\n' >> "${ENV_FILE}"
    ok "added NEXA_ALLOW_DEV_HOSTS=true (this workspace's forwarded URL changes on every rebuild)"
  else
    warn "NEXA_ALLOW_DEV_HOSTS is not true — a forwarded URL that is not listed in"
    warn "  NEXA_TRUSTED_HOSTS will be refused with 400 host_not_allowed (registration included)."
  fi
fi

print_urls() {
  local port="$1"
  printf '\n%sReady.%s\n' "${GREEN}${BOLD}" "${OFF}"
  printf '  local:      http://127.0.0.1:%s\n' "${port}"
  if [[ -n "${CODESPACES:-}" && -n "${CODESPACE_NAME:-}" ]]; then
    printf '  forwarded:  https://%s-%s.%s\n' "${port}" "${CODESPACE_NAME}" \
      "${GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN:-app.github.dev}"
    printf '  share it:   the port must be public for other people to open that link:\n'
    printf '              gh codespace ports visibility %s:public -c %s\n' "${port}" "${CODESPACE_NAME}"
    printf '              (or Ports tab → right-click the port → Port Visibility → Public)\n'
  elif [[ -n "${GITPOD_WORKSPACE_URL:-}" ]]; then
    printf '  forwarded:  %s\n' "${GITPOD_WORKSPACE_URL/:\/\//:\/\/${port}-}"
  else
    printf '  other machines: open the firewall for port %s and use this host address\n' "${port}"
  fi
  printf '  admin:      see NEXA_BOOTSTRAP_ADMIN_EMAIL / _PASSWORD in backend/.env\n\n'
}

start_api() {
  local port="$1" log="${RUN_DIR}/api.log"
  step "API on 0.0.0.0:${port}"
  if port_in_use "${port}" && [[ -f "${RUN_DIR}/api.pid" ]]; then
    warn "port ${port} is held by my previous instance — stopping it"
    stop_all
    sleep 1
  fi
  if port_in_use "${port}"; then
    # Never report success for a port somebody else owns: the browser would talk to that process.
    warn "port ${port} is already in use by another program (this script did not start it)"
    if [[ "${MODE}" == "dev" ]]; then
      warn "  pick another port: NEXA_DEV_API_PORT=8090 bash deployment/codespaces/start.sh --dev"
    else
      warn "  pick another port: NEXA_PORT=8090 bash deployment/codespaces/start.sh"
    fi
    return 1
  fi
  # `exec` inside the subshell makes the recorded pid the uvicorn process itself, so --stop really
  # stops the server (a subshell pid would only kill the wrapper and orphan the server).
  (
    cd "${ROOT}/backend" || exit 1
    set -a
    # shellcheck disable=SC1090
    . "${ENV_FILE}"
    set +a
    export NEXA_PUBLIC_PORT="${port}"
    export NEXA_PUBLIC_BASE_URL="${NEXA_PUBLIC_BASE_URL:-http://127.0.0.1:${port}}"
    exec "${VENV_PY}" -m uvicorn app.main:app --host 0.0.0.0 --port "${port}"
  ) >"${log}" 2>&1 </dev/null &
  echo $! > "${RUN_DIR}/api.pid"
  local pid; pid="$(cat "${RUN_DIR}/api.pid" 2>/dev/null || true)"
  for _ in $(seq 1 60); do
    if curl -fsS -m 2 "http://127.0.0.1:${port}/readyz" >/dev/null 2>&1; then ok "API is answering on ${port}"; return 0; fi
    if [[ -n "${pid}" ]] && ! kill -0 "${pid}" 2>/dev/null; then
      warn "the API process exited before it could answer — last lines of ${log}:"
      tail -n 20 "${log}" | sed 's/^/    /'
      return 1
    fi
    sleep 1
  done
  warn "the API did not answer within 60 s — last lines of ${log}:"
  tail -n 20 "${log}" | sed 's/^/    /'
  return 1
}

start_web() {
  step "Vite dev server on 0.0.0.0:${WEB_PORT}"
  if port_in_use "${WEB_PORT}"; then
    warn "port ${WEB_PORT} is already in use — skipping the dev server (set NEXA_WEB_PORT to change it)"
    return 0
  fi
  # Vite directly (not `npm run dev`): the pid we record is the process that owns the port.
  (
    cd "${ROOT}/frontend" || exit 1
    export VITE_PROXY_TARGET="http://127.0.0.1:${DEV_API_PORT}"
    exec "${ROOT}/frontend/node_modules/.bin/vite" --host 0.0.0.0 --port "${WEB_PORT}"
  ) >"${RUN_DIR}/web.log" 2>&1 </dev/null &
  echo $! > "${RUN_DIR}/web.pid"
  for _ in $(seq 1 30); do
    if curl -fsS -m 2 "http://127.0.0.1:${WEB_PORT}/" >/dev/null 2>&1; then ok "the dev server is answering on ${WEB_PORT}"; return 0; fi
    sleep 1
  done
  warn "the dev server did not answer within 30 s — last lines of ${RUN_DIR}/web.log:"
  tail -n 20 "${RUN_DIR}/web.log" | sed 's/^/    /'
}

if [[ "${MODE}" == "dev" ]]; then
  start_api "${DEV_API_PORT}" || exit 1
  start_web
  print_urls "${WEB_PORT}"
else
  if [[ ! -f "${ROOT}/frontend/dist/index.html" ]]; then
    step "Frontend build (missing)"
    ( cd frontend && npm run build --silent ) || die "npm run build failed"
    ok "frontend/dist built"
  fi
  start_api "${API_PORT}" || exit 1
  print_urls "${API_PORT}"
fi

if [[ "${DAEMON}" -eq 1 ]]; then
  ok "running in the background; stop it with: bash deployment/codespaces/start.sh --stop"
else
  printf 'Logs: %s\n' "${RUN_DIR}"
  printf 'Stop: bash deployment/codespaces/start.sh --stop\n'
fi
