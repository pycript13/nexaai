/**
 * Chat Studio — a dedicated, mobile-first workspace for talking to models.
 *
 * The classic chat page carries every tool the platform grew (sessions rail,
 * settings, variants, pricing) and gets cramped on a phone. The studio is the
 * opposite: one big conversation, one big composer, and the user's file
 * workspace one tap away — the same conversations/messages APIs underneath, so
 * nothing here is a second-class citizen: files uploaded in the studio are the
 * workspace files every other module sees, and the storage meter reads the
 * same quota the admin sets (Admin → Settings → storage).
 */
import { useEffect, useRef, useState } from "react";

import { api, ApiError, downloadFile, getCsrfToken } from "../api/client";
import type { CatalogModel } from "../api/types";
import { Icon } from "../components/icons";
import { Markdown } from "../components/Markdown";
import { ModelHealthBadge, useModelHealth } from "../components/ModelHealth";
import { Button, ErrorNotice, Spinner } from "../components/ui";
import { FilesWorkspace, type StoredFileItem } from "../components/FilesCenter";
import { useI18n } from "../state/app";

type Turn = {
  role: "user" | "assistant";
  content: string;
  errorCategory?: string | null;
  errorMessage?: string | null;
};

export default function Studio(): JSX.Element {
  const { t } = useI18n();
  const [models, setModels] = useState<CatalogModel[]>([]);
  const [modelId, setModelId] = useState<number | null>(() => {
    const saved = Number(localStorage.getItem("nexa.studio.model") || 0);
    return saved || null;
  });
  const { health, probe, markFailed } = useModelHealth();
  const [turns, setTurns] = useState<Turn[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [conversationId, setConversationId] = useState<number | null>(null);
  const [filesOpen, setFilesOpen] = useState(false);
  const [attachments, setAttachments] = useState<{ id: number; name: string }[]>([]);
  const [uploading, setUploading] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    api.get<{ items: CatalogModel[] }>("/api/v1/models", { limit: 100 })
      .then((data) => {
        const usable = (data.items || []).filter((m) => m.accessible);
        setModels(usable);
        setModelId((current) => current && usable.some((m) => m.id === current) ? current : usable[0]?.id ?? null);
      })
      .catch(setError);
  }, []);

  useEffect(() => {
    if (modelId) {
      localStorage.setItem("nexa.studio.model", String(modelId));
      void probe(modelId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modelId]);

  useEffect(() => {
    const node = scrollRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [turns, busy]);

  const send = async () => {
    const message = input.trim();
    if ((!message && attachments.length === 0) || !modelId || busy) return;
    const attachmentIds = attachments.map((item) => item.id);
    const shown = attachmentIds.length
      ? `${message}${message ? "\n" : ""}${attachments.map((item) => `📎 ${item.name}`).join("\n")}`.trim()
      : message;
    setAttachments([]);
    setInput("");
    setError(null);
    setTurns((current) => [...current, { role: "user", content: shown }, { role: "assistant", content: "" }]);
    setBusy(true);
    const controller = new AbortController();
    abortRef.current = controller;
    let assistant = "";
    try {
      const response = await fetch("/api/v1/chat/stream", {
        method: "POST",
        credentials: "include",
        signal: controller.signal,
        headers: {
          "Content-Type": "application/json",
          Accept: "text/event-stream",
          "X-CSRF-Token": getCsrfToken() || "",
        },
        body: JSON.stringify({ model_id: modelId, message, attachment_ids: attachmentIds, conversation_id: conversationId ?? undefined }),
      });
      if (!response.ok || !response.body) {
        const payload = await response.json().catch(() => null);
        throw new ApiError(response.status, payload?.error || { code: "stream_failed", message: "The stream could not be opened." });
      }
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let event = "";
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        for (const line of lines) {
          if (line.startsWith("event:")) { event = line.slice(6).trim(); continue; }
          if (!line.startsWith("data:")) continue;
          const payload = JSON.parse(line.slice(5).trim() || "null");
          if (!payload) continue;
          if (event === "meta" && payload.conversation_id) setConversationId(payload.conversation_id);
          else if (event === "delta" && typeof payload.text === "string") {
            assistant += payload.text;
            setTurns((current) => {
              const copy = [...current];
              copy[copy.length - 1] = { role: "assistant", content: assistant };
              return copy;
            });
          } else if (event === "error") {
            setTurns((current) => {
              const copy = [...current];
              copy[copy.length - 1] = {
                role: "assistant", content: assistant,
                errorCategory: payload.category || "upstream_server_error",
                errorMessage: payload.message || null,
              };
              return copy;
            });
            // The real attempt is the truth: the badge must not keep claiming health.
            markFailed(modelId, payload.message || payload.category || "");
          }
        }
      }
    } catch (caught) {
      if ((caught as Error)?.name === "AbortError") {
        setTurns((current) => {
          const copy = [...current];
          const last = copy[copy.length - 1];
          if (last?.role === "assistant") copy[copy.length - 1] = { ...last, errorCategory: "stopped", errorMessage: t("studio.stopped") };
          return copy;
        });
      } else {
        setError(caught);
        setTurns((current) => current.slice(0, -1));
        markFailed(modelId, caught instanceof Error ? caught.message : String(caught));
      }
    } finally {
      abortRef.current = null;
      setBusy(false);
    }
  };

  const upload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    setUploading(true);
    setError(null);
    try {
      const form = new FormData();
      form.append("file", file);
      const saved = await api.upload<{ id: number; name: string }>("/api/v1/files", form);
      setAttachments((current) => [...current, { id: saved.id, name: saved.name || file.name }]);
    } catch (caught) {
      setError(caught);
    } finally {
      setUploading(false);
    }
  };

  const attachExisting = (file: StoredFileItem) => {
    setAttachments((current) =>
      current.some((item) => item.id === file.id) ? current : [...current, { id: file.id, name: file.name }],
    );
  };

  return (
    <div className="studio">
      <header className="studio__bar">
        <div className="studio__title">
          <strong>{t("studio.title")}</strong>
          <span className="muted small">{t("studio.subtitle")}</span>
        </div>
        <div className="studio__model">
          <select
            value={modelId ?? ""}
            onChange={(e) => { const next = Number(e.target.value) || null; setModelId(next); if (next) void probe(next, true); }}
            aria-label={t("label.model")}
          >
            {models.map((m) => <option key={m.id} value={m.id}>{m.display_name}</option>)}
          </select>
          {modelId ? <ModelHealthBadge state={health[modelId]} onRecheck={() => void probe(modelId, true)} /> : null}
        </div>
        <button type="button" className={`btn btn--ghost studio__files-btn ${filesOpen ? "chip--active" : ""}`} onClick={() => setFilesOpen((v) => !v)}>
          <Icon name="folder" size={16} /> {t("studio.files")}
        </button>
      </header>

      {error ? <ErrorNotice error={error} /> : null}

      <div className="studio__thread" ref={scrollRef}>
        {turns.length === 0 ? (
          <div className="studio__empty">
            <span className="landing__feature-icon"><Icon name="chat" size={26} /></span>
            <h2>{t("studio.emptyTitle")}</h2>
            <p className="muted">{t("studio.emptyText")}</p>
          </div>
        ) : (
          turns.map((turn, index) => (
            <article key={index} className={`studio__msg studio__msg--${turn.role}`}>
              <span className="studio__msg-role">{turn.role === "user" ? t("studio.you") : t("studio.assistant")}</span>
              {turn.content ? <Markdown text={turn.content} /> : busy && index === turns.length - 1 ? <Spinner /> : null}
              {turn.errorCategory ? (
                <div className="studio__error" role="alert">
                  <strong>⚠️ {turn.errorCategory}</strong>
                  {turn.errorMessage ? <span>{turn.errorMessage}</span> : null}
                  {modelId ? (
                    <button type="button" className="model-health__recheck" onClick={() => void probe(modelId, true)}>
                      {t("modelHealth.recheck")}
                    </button>
                  ) : null}
                </div>
              ) : null}
            </article>
          ))
        )}
      </div>

      {attachments.length > 0 ? (
        <div className="studio__attachments">
          {attachments.map((item) => (
            <span key={item.id} className="chip chip--active">
              <Icon name="attach" size={13} /> {item.name}
              <button
                type="button"
                className="chip__x"
                aria-label={t("action.delete")}
                onClick={() => setAttachments((current) => current.filter((entry) => entry.id !== item.id))}
              >
                ×
              </button>
            </span>
          ))}
        </div>
      ) : null}
      <div className="studio__composer">
        <label className="studio__attach" title={t("chat.attach")}>
          <Icon name="plus" size={18} />
          <input type="file" hidden onChange={upload} disabled={uploading} />
        </label>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void send(); } }}
          placeholder={t("studio.placeholder")}
          rows={2}
        />
        {busy ? (
          <Button type="button" variant="subtle" onClick={() => abortRef.current?.abort()}>{t("chat.stop")}</Button>
        ) : (
          <Button type="button" onClick={() => void send()} disabled={!modelId || (!input.trim() && attachments.length === 0)}>{t("studio.send")}</Button>
        )}
      </div>
      <p className="muted small studio__hint">{t("studio.hint")}</p>

      {filesOpen ? (
        <aside className="studio__drawer" aria-label={t("studio.files")}>
          <div className="studio__drawer-head">
            <strong>{t("studio.workspace")}</strong>
            <button type="button" className="iconbtn iconbtn--ghost" onClick={() => setFilesOpen(false)} aria-label={t("action.close")}>
              <Icon name="close" size={16} />
            </button>
          </div>
          <FilesWorkspace onAttach={attachExisting} attachedIds={attachments.map((item) => item.id)} />
        </aside>
      ) : null}
    </div>
  );
}
