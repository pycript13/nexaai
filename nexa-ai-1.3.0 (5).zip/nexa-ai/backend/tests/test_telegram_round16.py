"""Round 16 — the bot answers like the best Telegram AI bots do.

What is pinned here is exactly what a user sees: the answer grows inside ONE message with
a ▍ cursor while the model writes, the final edit removes the cursor and attaches the
glass action row; an answer too big for one message overflows into extra messages instead
of breaking Telegram's 4000-character limit; refusals and provider errors carry a retry
button that really replays the last prompt; the settings card owns a live-stream toggle;
and the account card reports today's spend — with a progress bar when a daily limit is set.
"""
import json

import httpx
import pytest
from sqlalchemy import select

from app.models.billing import CreditAccount
from app.models.telegram import TelegramLink
from app.services import telegram as telegram_service
from app.services import telegram_menus as menus
from app.services import telegram_sessions as session_service
from tests.conftest import create_provider_and_model, grant_credits
from tests.test_telegram_sessions import (  # fixtures + helpers live with the rest of the bot suite
    telegram,  # noqa: F401  (pytest fixture re-export)
    _idata,
    _linked_account,
    _say,
    _set_live_stream,
    _state,
    _tap_and_read,
)

CURSOR = telegram_service._STREAM_CURSOR


def _settings_card(server, sent: list[dict]) -> str:
    """The newest settings-card text, whether the router sent it fresh or edited it in place."""
    candidates = [m["text"] for m in sent if "پخش زنده" in m.get("text", "")]
    candidates += [e["text"] for e in server.edits if "پخش زنده" in e.get("text", "")]
    assert candidates, "the settings card must mention the live-stream row"
    return candidates[-1]


def _sse(chunks: list[str]) -> str:
    """Build an OpenAI-style SSE stream from plain text chunks (json.dumps keeps it safe)."""
    body = "".join(
        'data: {"choices":[{"delta":{"content":' + json.dumps(chunk, ensure_ascii=False)
        + '},"finish_reason":null}]}\n\n'
        for chunk in chunks
    )
    return body + "data: [DONE]\n\n"


def _answer_handler(chunks: list[str]):
    payload = _sse(chunks)

    def handler(request):  # noqa: ANN001
        return httpx.Response(200, content=payload, headers={"content-type": "text/event-stream"})

    return handler


# ------------------------------------------------------------------- streaming ----
def test_answer_grows_in_one_message_and_finalises_cleanly(
        user_client, db, telegram, mock_provider_transport) -> None:  # noqa: F811
    chunks = ["Nexa AI یک پلتفرم ", "یکپارچه برای ", "مدیریت مدل‌های هوش مصنوعی است. "] * 6
    mock_provider_transport(_answer_handler(chunks))
    create_provider_and_model(db, published=True, display_name="Stream Model")
    grant_credits(db, user_client.email, 20.0)
    tid = _linked_account(user_client, db, telegram)

    edits_before = len(telegram.edits)
    result, sent = _say(db, telegram, "خودت را معرفی کن", telegram_user_id=tid)
    assert result == "answer"

    # the generating placeholder appears immediately, carrying the ⏹ stop button; the
    # answer then grows inside that very message and finalises in place
    placeholder = [m for m in sent if "در حال تولید" in m["text"]]
    assert len(placeholder) == 1, "exactly one generating placeholder"
    assert "chat:stop" in _idata(placeholder[0]), "the generating message carries the ⏹ stop button"

    edits = telegram.edits[edits_before:]
    assert len(edits) == 1, "a fast stream is throttled into a single final edit"
    final = edits[0]
    assert final["message_id"] == placeholder[0]["message_id"], "the same message is edited, never re-sent"
    assert CURSOR.strip() not in final["text"], "the final edit removes the cursor"
    assert final["text"].startswith("".join(chunks).strip())
    assert "chat:retry" in _idata(final) and "menu:models" in _idata(final), \
        "the final answer carries the glass action row"


def test_huge_answer_overflows_into_extra_messages_without_breaking_the_limit(
        user_client, db, telegram, mock_provider_transport) -> None:  # noqa: F811
    body = "B" * 8_000 + " TAIL-MARKER-7Q"
    chunks = [body[i:i + 2_000] for i in range(0, len(body), 2_000)]
    mock_provider_transport(_answer_handler(chunks))
    create_provider_and_model(db, published=True, display_name="Huge Model")
    grant_credits(db, user_client.email, 20.0)
    tid = _linked_account(user_client, db, telegram)

    edits_before = len(telegram.edits)
    result, sent = _say(db, telegram, "یک متن خیلی بلند بگو", telegram_user_id=tid)
    assert result == "answer"

    answer_msgs = [m for m in sent if "B" in m["text"] or "TAIL-MARKER-7Q" in m["text"]]
    assert len(answer_msgs) >= 2, "an 8000-char answer must be spread over several messages"
    assert all(len(m["text"]) <= telegram_service.MAX_TELEGRAM_MESSAGE + 40 for m in answer_msgs), \
        "no single message may exceed Telegram's limit"
    edits = telegram.edits[edits_before:]
    final_by_id = {e["message_id"]: e["text"] for e in edits}
    cursor_msgs = [m for m in answer_msgs if CURSOR.strip() in m["text"]]
    assert cursor_msgs, "the live messages are sent with the cursor"
    for m in cursor_msgs:
        assert m["message_id"] in final_by_id, "every live message is finalised by an edit"
        assert CURSOR.strip() not in final_by_id[m["message_id"]], "finalising removes the cursor"
    final = edits[-1]
    assert "TAIL-MARKER-7Q" in final["text"], "the end of the answer must survive"


def test_live_stream_off_falls_back_to_one_shot_delivery(
        user_client, db, telegram, mock_provider_transport) -> None:  # noqa: F811
    chunks = ["پاسخ ", "کلاسیک ", "بدون پخش زنده. "] * 4
    mock_provider_transport(_answer_handler(chunks))
    create_provider_and_model(db, published=True, display_name="Classic Model")
    grant_credits(db, user_client.email, 20.0)
    tid = _linked_account(user_client, db, telegram)
    _set_live_stream(db, tid, False)

    edits_before = len(telegram.edits)
    result, sent = _say(db, telegram, "سلام", telegram_user_id=tid)
    assert result == "answer"
    answer = [m for m in sent if m["text"].startswith("پاسخ کلاسیک")]
    assert len(answer) == 1, "one-shot delivery sends the complete answer once"
    assert CURSOR.strip() not in answer[0]["text"], "no cursor without live streaming"
    assert "chat:retry" in _idata(answer[0])
    assert telegram.edits[edits_before:] == [], "nothing is edited in one-shot mode"


# ----------------------------------------------------------------------- retry -----
def test_refusal_carries_a_retry_button_that_replays_the_prompt(
        user_client, db, telegram, mock_provider_transport) -> None:  # noqa: F811
    mock_provider_transport(_answer_handler(["پاسخ بعد از شارژ آماده است."]))
    create_provider_and_model(db, published=True, display_name="Refuse Model")
    # deliberately NO credits: the very first prompt is refused
    tid = _linked_account(user_client, db, telegram)

    result, sent = _say(db, telegram, "یک سؤال مهم", telegram_user_id=tid)
    assert result == "not_allowed"
    refusal = [m for m in sent if m["text"].startswith("⛔️")][0]
    assert _idata(refusal) == ["chat:retry"], "the refusal must offer exactly one retry button"

    grant_credits(db, user_client.email, 20.0)
    result2, sent2 = _tap_and_read(db, telegram, "chat:retry", telegram_user_id=tid)
    assert result2 == "answer"
    delivered = [m["text"] for m in sent2] + [e["text"] for e in telegram.edits]
    assert any("پاسخ بعد از شارژ آماده است." in text for text in delivered), \
        "retry replays the refused prompt once the account can pay"
    state = _state(db, tid)
    assert state["last_prompt"] == "یک سؤال مهم", "the prompt is remembered BEFORE the refusal"


def test_provider_failure_midstream_warns_with_a_retry_button(
        user_client, db, telegram, mock_provider_transport) -> None:  # noqa: F811
    def handler(request):  # noqa: ANN001
        return httpx.Response(503, content=b'{"error":{"message":"upstream exploded"}}',
                              headers={"content-type": "application/json"})

    mock_provider_transport(handler)
    create_provider_and_model(db, published=True, display_name="Broken Model")
    grant_credits(db, user_client.email, 20.0)
    tid = _linked_account(user_client, db, telegram)

    result, sent = _say(db, telegram, "سؤال از سرویس خراب", telegram_user_id=tid)
    assert result == "provider_error"
    # the warning finalises the generating placeholder by edit — same visibility, one message
    warning = [m for m in sent if "⚠️" in m["text"]] + [e for e in telegram.edits if "⚠️" in e["text"]]
    assert warning, "the user must see a warning"
    assert _idata(warning[-1]) == ["chat:retry"]


# -------------------------------------------------------------------- settings -----
def test_settings_card_owns_the_live_stream_toggle(
        user_client, db, telegram, mock_provider_transport) -> None:  # noqa: F811
    mock_provider_transport(_answer_handler(["ok"]))
    create_provider_and_model(db, published=True, display_name="Toggle Model")
    grant_credits(db, user_client.email, 20.0)
    tid = _linked_account(user_client, db, telegram)

    result, sent = _say(db, telegram, "/settings", telegram_user_id=tid)
    assert result == "settings"
    card = [m for m in sent if "پخش زنده" in m["text"]][-1]
    assert "روشن" in card["text"], "live streaming is on by default and the card says so"
    assert "settings:stream:toggle" in _idata(card)
    toggle = [b for row in card["reply_markup"]["inline_keyboard"] for b in row
              if b["callback_data"] == "settings:stream:toggle"][0]
    assert toggle["text"].startswith("✅")

    result, sent2 = _tap_and_read(db, telegram, "settings:stream:toggle", telegram_user_id=tid)
    assert result == "settings"
    card2 = _settings_card(telegram, sent2)
    assert "خاموش" in card2, "tapping flips the card to off"
    assert session_service.settings_of(_state(db, tid))["live_stream"] is False, "and persists"

    result, sent3 = _tap_and_read(db, telegram, "settings:stream:toggle", telegram_user_id=tid)
    assert result == "settings"
    assert "روشن" in _settings_card(telegram, sent3)
    assert session_service.settings_of(_state(db, tid))["live_stream"] is True


# ----------------------------------------------------------------------- status -----
def test_status_card_reports_today_spend_and_the_daily_limit_bar(
        user_client, db, telegram, mock_provider_transport) -> None:  # noqa: F811
    mock_provider_transport(_answer_handler(["پاسخ کوچک برای ساختن رکورد مصرف."]))
    create_provider_and_model(db, published=True, display_name="Status Model")
    grant_credits(db, user_client.email, 20.0)
    tid = _linked_account(user_client, db, telegram)
    assert _say(db, telegram, "یک پیام", telegram_user_id=tid)[0] == "answer"

    account = db.scalars(select(CreditAccount).where(
        CreditAccount.user_id == select(TelegramLink.user_id).where(
            TelegramLink.telegram_user_id == tid).scalar_subquery())).first()
    assert account is not None
    account.daily_spend_limit_micro = 2_000           # tiny on purpose: one paid turn fills half of it
    db.commit()

    result, sent = _say(db, telegram, "/status", telegram_user_id=tid)
    card = [m for m in sent if "👤" in m["text"]][-1]["text"]
    assert "مصرف امروز" in card, "today's spend is part of the account card"
    assert "سقف روزانه" in card and "%" in card, \
        "with a daily limit set, the card shows a progress bar"
    assert "▰" in card or "▱" in card, "the bar is drawn from ▰/▱ blocks"


# ------------------------------------------------------------------------ menus -----
def test_section_breadcrumbs_and_progress_bar() -> None:
    assert menus.section_intro("settings", "fa").startswith("🧭 منو › ")
    assert menus.section_intro("models", "en").startswith("🧭 menu › ")
    assert not menus.section_intro("main", "fa").startswith("🧭 منو › "), "home needs no breadcrumb"
    assert not menus.section_intro("chat", "en").startswith("🧭 menu › ")
    assert menus.progress_bar(30, 100) == "▰▰▰▱▱▱▱▱▱▱ 30%"
    assert menus.progress_bar(150, 100) == "▰▰▰▰▰▰▰▰▰▰ 100%"
    assert menus.progress_bar(5, 0) == "", "no limit → no bar"
