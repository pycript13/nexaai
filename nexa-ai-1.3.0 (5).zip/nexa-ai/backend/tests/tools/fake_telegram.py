"""A fake Telegram Bot API server, faithful enough to test the bot end to end.

It implements the methods the platform uses (``getMe``, ``getUpdates``, ``sendMessage``,
``sendChatAction``, ``setWebhook``, ``deleteWebhook``) over real HTTP on a loopback port, keeps
a queue of updates that the test pushes in, and records every message the bot sends so a test
can assert on what a user would have seen. No platform code is patched.

Used by ``tests/telegram/`` (pytest) and by ``tests/tools/telegram_demo.py`` (a live demo
against a real running deployment).
"""
from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any


class _State:
    def __init__(self) -> None:
        self.updates: list[dict[str, Any]] = []
        self.sent: list[dict[str, Any]] = []
        self.actions: list[dict[str, Any]] = []
        self.edits: list[dict[str, Any]] = []
        self.documents: list[dict[str, Any]] = []
        self.deletes: list[dict[str, Any]] = []
        self.callbacks: list[dict[str, Any]] = []
        self.commands: list[dict[str, Any]] = []
        self.webhook: str | None = None
        # Real Telegram update ids are unique for the bot's whole lifetime. Seeding
        # each fake server from the clock keeps that promise across tests that share
        # one database (the exactly-once claim table would otherwise collide).
        import random as _random
        import time as _time

        self._update_id = int(_time.time() * 1000) % 10**12 + _random.randint(0, 10**6)
        self._message_id = 1
        self.lock = threading.Lock()

    def next_update_id(self) -> int:
        with self.lock:
            self._update_id += 1
            return self._update_id

    def next_message_id(self) -> int:
        with self.lock:
            self._message_id += 1
            return self._message_id


class FakeTelegramServer:
    """Loopback HTTP server speaking the subset of the Bot API the platform uses."""

    def __init__(self) -> None:
        self.state = _State()
        self._httpd: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None
        self.port: int | None = None
        # Confirmed update offset, exactly like the real Bot API: updates below it are
        # not delivered again. A polling client must advance it or it replays updates.
        self.offset: int | None = None

    # -- lifecycle ---------------------------------------------------------
    def start(self, port: int = 0) -> int:
        """Start the double. `port=0` picks a free one (tests); a fixed port is used
        by the live demo, where the platform is configured before the server starts."""
        state = self.state

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *args, **kwargs) -> None:  # noqa: ANN002, ANN003
                return  # keep the test output clean

            def _reply(self, payload: dict[str, Any], status: int = 200) -> None:
                body = json.dumps(payload).encode()
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_POST(self) -> None:  # noqa: N802
                length = int(self.headers.get("content-length") or 0)
                raw = self.rfile.read(length) if length else b"{}"
                if "multipart/form-data" in (self.headers.get("content-type") or ""):
                    # sendDocument arrives as multipart: pull the fields the tests assert on.
                    text = raw.decode("utf-8", "ignore")
                    def field(name: str) -> str:
                        marker = f'name="{name}"'
                        at = text.find(marker)
                        if at < 0:
                            return ""
                        start = text.find("\r\n\r\n", at)
                        end = text.find("\r\n--", start)
                        return text[start + 4:end].strip() if start >= 0 and end > start else ""
                    filename = ""
                    at = text.find('name="document"')
                    if at >= 0:
                        fstart = text.find('filename="', at)
                        fend = text.find('"', fstart + 10) if fstart >= 0 else -1
                        filename = text[fstart + 10:fend] if fstart >= 0 and fend > fstart else ""
                    message_id = state.next_message_id()
                    with state.lock:
                        state.documents.append({"chat_id": field("chat_id"), "filename": filename,
                                                "caption": field("caption"), "message_id": message_id})
                    return self._reply({"ok": True, "result": {
                        "message_id": message_id, "chat": {"id": field("chat_id")},
                        "document": {"file_name": filename},
                    }})
                try:
                    payload = json.loads(raw or b"{}")
                except json.JSONDecodeError:
                    payload = {}
                method = self.path.rstrip("/").split("/")[-1]
                if method.startswith("bot"):
                    method = method.split(":", 1)[-1] if ":" not in method else method
                # path shape: /bot<token>/<method>
                method = self.path.rstrip("/").split("/")[-1]

                if method == "getMe":
                    return self._reply({"ok": True, "result": {
                        "id": 123456, "is_bot": True, "first_name": "Nexa Test Bot",
                        "username": "nexa_test_bot", "can_join_groups": True,
                        "can_read_all_group_messages": False,
                    }})

                if method == "getUpdates":
                    offset = payload.get("offset")
                    with state.lock:
                        pending = [u for u in state.updates if offset is None or u["update_id"] >= offset]
                    return self._reply({"ok": True, "result": pending})

                if method == "sendMessage":
                    raw_markup = payload.get("reply_markup")
                    markup: Any = None
                    if raw_markup is not None:
                        if not isinstance(raw_markup, str):
                            # The real Bot API refuses a dict here ("Bad Request: can't parse
                            # reply_markup JSON object") — the markup must be sent as a JSON string.
                            return self._reply({"ok": False, "error_code": 400, "description":
                                                "Bad Request: can't parse reply_markup JSON object"}, 400)
                        try:
                            markup = json.loads(raw_markup)
                        except json.JSONDecodeError:
                            return self._reply({"ok": False, "error_code": 400, "description":
                                                "Bad Request: can't parse reply_markup JSON object"}, 400)
                    message_id = state.next_message_id()
                    record = {"chat_id": payload.get("chat_id"), "text": payload.get("text", ""),
                              "reply_markup": markup, "parse_mode": payload.get("parse_mode"),
                              "message_id": message_id}
                    with state.lock:
                        state.sent.append(record)
                    return self._reply({"ok": True, "result": {
                        "message_id": message_id, "chat": {"id": payload.get("chat_id")},
                        "text": payload.get("text", ""),
                    }})

                if method in ("editMessageText", "editMessageReplyMarkup"):
                    raw_markup = payload.get("reply_markup")
                    markup = None
                    if isinstance(raw_markup, str):
                        try:
                            markup = json.loads(raw_markup)
                        except json.JSONDecodeError:
                            return self._reply({"ok": False, "error_code": 400, "description":
                                                "Bad Request: can't parse reply_markup JSON"}, 400)
                    with state.lock:
                        state.edits.append({"chat_id": payload.get("chat_id"),
                                            "message_id": payload.get("message_id"),
                                            "text": payload.get("text", ""), "reply_markup": markup})
                    return self._reply({"ok": True, "result": {"message_id": payload.get("message_id")}})

                if method == "deleteMessage":
                    with state.lock:
                        state.deletes.append({"chat_id": payload.get("chat_id"),
                                              "message_id": payload.get("message_id")})
                    return self._reply({"ok": True, "result": True})

                if method == "answerCallbackQuery":
                    with state.lock:
                        state.callbacks.append({"id": payload.get("callback_query_id"),
                                                "text": payload.get("text", ""),
                                                "show_alert": payload.get("show_alert", False)})
                    return self._reply({"ok": True, "result": True})

                if method == "setMyCommands":
                    with state.lock:
                        state.commands = [dict(item) for item in (payload.get("commands") or [])]
                    return self._reply({"ok": True, "result": True})

                if method == "sendChatAction":
                    with state.lock:
                        state.actions.append(dict(payload))
                    return self._reply({"ok": True, "result": True})

                if method == "setWebhook":
                    state.webhook = payload.get("url")
                    return self._reply({"ok": True, "result": True, "description": "Webhook was set"})

                if method == "deleteWebhook":
                    state.webhook = None
                    return self._reply({"ok": True, "result": True})

                return self._reply({"ok": False, "error_code": 404, "description": f"unknown method {method}"}, 404)

        self._httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
        self.port = self._httpd.server_address[1]
        self._thread = threading.Thread(target=self._httpd.serve_forever, daemon=True)
        self._thread.start()
        return self.port

    def stop(self) -> None:
        if self._httpd is not None:
            self._httpd.shutdown()
            self._httpd.server_close()
        if self._thread is not None:
            self._thread.join(timeout=2)

    # -- test helpers ------------------------------------------------------
    def push_update(self, update: dict[str, Any]) -> None:
        with self.state.lock:
            self.state.updates.append(update)

    @property
    def sent(self) -> list[dict[str, Any]]:
        with self.state.lock:
            return list(self.state.sent)

    @property
    def actions(self) -> list[dict[str, Any]]:
        with self.state.lock:
            return list(self.state.actions)

    @property
    def commands(self) -> list[dict[str, Any]]:
        with self.state.lock:
            return list(self.state.commands)

    @property
    def edits(self) -> list[dict[str, Any]]:
        with self.state.lock:
            return list(self.state.edits)

    @property
    def deletes(self) -> list[dict[str, Any]]:
        with self.state.lock:
            return list(self.state.deletes)

    @property
    def documents(self) -> list[dict[str, Any]]:
        with self.state.lock:
            return list(self.state.documents)

    @property
    def callbacks(self) -> list[dict[str, Any]]:
        with self.state.lock:
            return list(self.state.callbacks)

    def next_update_id(self) -> int:
        return self.state.next_update_id()

    def next_message_id(self) -> int:
        return self.state.next_message_id()
