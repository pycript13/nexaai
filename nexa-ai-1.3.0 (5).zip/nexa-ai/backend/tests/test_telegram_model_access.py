"""Model selection in the bot must be honest about paid/locked models.

A paid model stays *visible* (so the user can see what exists), its usage
condition is printed next to it, a 🔒 marks what cannot be picked — and
tapping it explains why instead of switching behind a success message.
"""
from __future__ import annotations

from sqlalchemy import select

from app.models.telegram import TelegramLink
from app.services import telegram_sessions as session_service
from tests.conftest import create_provider_and_model, grant_credits
from tests.test_telegram_sessions import (  # noqa: F401  (fixture + helpers)
    telegram,
    _linked_account,
    _say,
    _state,
    _tap_and_read,
)


def _model_id(db, display_name: str) -> int:
    from app.models.provider import Model

    return db.scalars(select(Model).where(Model.display_name == display_name)).first().id


def test_paid_model_with_empty_balance_is_not_selected(user_client, db, telegram) -> None:  # noqa: F811
    create_provider_and_model(db, published=True, display_name="Paid Locked Model", access_tier="credit")
    create_provider_and_model(db, published=True, display_name="Free Open Model", access_tier="free",
                              model_id_str="free-model-1")
    tid = _linked_account(user_client, db, telegram)
    paid_id = _model_id(db, "Paid Locked Model")
    free_id = _model_id(db, "Free Open Model")

    # the list itself states the condition next to each model — walk every
    # page, the shared test DB may hold many published models by now
    result, sent = _say(db, telegram, "/models", telegram_user_id=tid)
    assert result == "models"
    listing = "\n".join(m["text"] for m in sent)
    for page_no in range(2, 40):
        if "Free Open Model" in listing and "Paid Locked Model" in listing:
            break
        # a page tap on an untracked message opens a fresh list message instead
        # of editing in place — collect from both channels
        _tap_and_read(db, telegram, f"models:{page_no}", telegram_user_id=tid)
        listing = ("\n".join(m["text"] for m in telegram.sent)
                   + "\n" + "\n".join(e["text"] for e in telegram.edits))
    free_block = listing.split("Free Open Model", 1)[1].split("▫️", 1)[0]
    paid_block = listing.split("Paid Locked Model", 1)[1].split("▫️", 1)[0]
    assert "رایگان" in free_block, "the free model's condition must be printed next to it"
    assert "موجودی اعتبار کافی نیست" in paid_block, "the paid model's condition must be printed next to it"

    # tapping the paid model: no switch, an explanation instead
    result, _ = _tap_and_read(db, telegram, f"model:{paid_id}", telegram_user_id=tid)
    assert result == "model_locked", result
    state = _state(db, tid)
    assert state.get("model_id") != paid_id, "a locked model must never become active"
    explanations = "\n".join(e["text"] for e in telegram.edits) + "\n".join(m["text"] for m in telegram.sent)
    assert "انتخاب نشد" in explanations and "کیف پول" in explanations

    # the free model still selects normally
    result, _ = _tap_and_read(db, telegram, f"model:{free_id}", telegram_user_id=tid)
    assert result == "model_selected", result
    assert _state(db, tid).get("model_id") == free_id


def test_paid_model_selects_once_the_user_has_credit(user_client, db, telegram) -> None:  # noqa: F811
    create_provider_and_model(db, published=True, display_name="Paid Open Model", access_tier="credit")
    grant_credits(db, user_client.email, 20.0)
    tid = _linked_account(user_client, db, telegram)
    paid_id = _model_id(db, "Paid Open Model")

    result, _ = _tap_and_read(db, telegram, f"model:{paid_id}", telegram_user_id=tid)
    assert result == "model_selected", result
    assert _state(db, tid).get("model_id") == paid_id
