"""Stop-generation + the Telegram file workspace.

The ⏹ button must exist *while* the model writes (attached to the generating message
from the first second) and tapping it must end the stream, keep the partial answer and
mark it stopped. Files: one unified list (uploads + model-made), nested detail view,
and ⬇️ delivers the real bytes into the chat as a document.
"""
from __future__ import annotations

import asyncio
import io

import pytest
from sqlalchemy import select

from app.models.files import StoredFile
from app.models.telegram import TelegramLink
from app.models.user import User
from app.services import files as file_service
from app.services import telegram as telegram_service
from tests.conftest import create_provider_and_model, grant_credits
from tests.test_telegram_sessions import (  # noqa: F401  (fixture + helpers)
    telegram,
    _linked_account,
    _say,
    _tap_and_read,
    _tap,
    _update,
)


def _idata(message) -> str:
    """Callback datas of one message ('' when it carries the reply bar instead)."""
    markup = message.get("reply_markup") or {}
    return " ".join(
        button.get("callback_data", "")
        for row in markup.get("inline_keyboard", []) for button in row
    )


def _store(db, user: User, name: str, body: bytes) -> StoredFile:
    return file_service.store_upload(db, user=user, data=body, filename=name, kind="upload")


def test_files_are_listed_nested_and_downloadable(user_client, db, telegram) -> None:  # noqa: F811
    tid = _linked_account(user_client, db, telegram)
    user = db.scalars(select(User).where(User.email == user_client.email)).first()
    record = _store(db, user, "notes.txt", b"hello telegram files")
    db.commit()

    result, sent = _tap_and_read(db, telegram, "menu:files", telegram_user_id=tid)
    assert result == "files"
    everywhere = " ".join(_idata(m) for m in sent) + " " + " ".join(_idata(e) for e in telegram.edits)
    assert f"file:{record.id}" in everywhere, "the file must be a tappable nested button"

    result, _ = _tap_and_read(db, telegram, f"file:{record.id}", telegram_user_id=tid)
    assert result == "file_detail"

    result, _ = _tap_and_read(db, telegram, f"filedl:{record.id}", telegram_user_id=tid)
    assert result == "file_sent"
    assert telegram.documents, "⬇️ must send the real file into the chat"
    assert telegram.documents[-1]["filename"] == "notes.txt"


def test_files_command_and_empty_state(user_client, db, telegram) -> None:  # noqa: F811
    tid = _linked_account(user_client, db, telegram)
    result, sent = _say(db, telegram, "/files", telegram_user_id=tid)
    assert result == "files"
    assert sent and "فایل" in sent[-1]["text"]


def test_stop_button_ends_a_live_generation(user_client, db, telegram, monkeypatch) -> None:  # noqa: F811
    create_provider_and_model(db, published=True, display_name="Stop Model")
    grant_credits(db, user_client.email, 20.0)
    tid = _linked_account(user_client, db, telegram)

    from app.services import ai as ai_service

    class _Event:
        def __init__(self, type_, data=None):
            self.type = type_
            self.data = data or {}

    async def fake_stream(*args, **kwargs):
        yield _Event("delta", {"text": "بخش اول پاسخ "})
        # hold the stream open until the ⏹ tap lands, like a slow provider would
        for _ in range(200):
            if telegram_service._ACTIVE_GENERATIONS.get(str(tid)) and \
                    telegram_service._ACTIVE_GENERATIONS[str(tid)].is_set():
                break
            await asyncio.sleep(0.05)
        yield _Event("delta", {"text": "بخش دوم که نباید برسد"})
        yield _Event("done", {"charged_micro": 0, "total_tokens": 3})

    monkeypatch.setattr(ai_service, "stream_chat", fake_stream)

    async def scenario() -> str:
        task = asyncio.create_task(
            telegram_service.handle_update(db, _update(telegram, "یک پاسخ بلند بده", telegram_user_id=tid)))
        # wait until the generation is registered and its message carries ⏹
        generating = []
        for _ in range(100):
            generating = [m for m in telegram.sent if "chat:stop" in _idata(m)]
            if str(tid) in telegram_service._ACTIVE_GENERATIONS and generating:
                break
            await asyncio.sleep(0.05)
        assert str(tid) in telegram_service._ACTIVE_GENERATIONS, "generation must be registered"
        assert generating, "the generating message must carry the ⏹ stop button from the start"
        stop_result = await telegram_service.handle_update(
            db, _tap(telegram, "chat:stop", telegram_user_id=tid))
        assert stop_result == "stop"
        return await asyncio.wait_for(task, timeout=10)

    result = asyncio.run(scenario())
    assert result == "stopped", result
    all_text = " ".join(m["text"] for m in telegram.sent) + " " + " ".join(
        e["text"] for e in telegram.edits)
    assert "متوقف شد" in all_text, "the finalised message must say it was stopped"
    assert str(tid) not in telegram_service._ACTIVE_GENERATIONS


def test_stop_when_idle_is_a_friendly_noop(user_client, db, telegram) -> None:  # noqa: F811
    tid = _linked_account(user_client, db, telegram)
    result, _ = _tap_and_read(db, telegram, "chat:stop", telegram_user_id=tid)
    assert result == "stop_idle"
