"""Round 13 — the Telegram bot as a real workspace: sessions per model, a nested fixed button bar.

What is proven here, layer by layer:

* ``app/services/telegram_sessions.py`` — pure session store: numbering, activation, the 20-session
  cap, fallback when the active session is closed, auto-titles, aggregates, settings defaults;
* ``app/services/telegram_menus.py`` — the fixed bottom bar, the label→action contract in both
  languages, paged model/session/variant/settings keyboards, the help topics;
* ``app/services/telegram.py`` — end to end through the **fake Telegram Bot API server** (real HTTP,
  *real* JSON ``reply_markup``, real platform chat pipeline, real ledger): the persistent keyboard is
  actually sent, a tapped label opens its section, sessions are per model and switchable, streaming
  charges the ordinary account, a long answer is split instead of truncated, a group chat is refused,
  and the published command list matches the documented one.

Nothing is mocked inside the platform: only the network edges (Telegram, the provider) are doubles.
"""
from __future__ import annotations

import asyncio
import json
import re
import uuid

import httpx
import pytest
from sqlalchemy import select

from app.core.config import settings
from app.models.provider import Model
from app.models.telegram import TelegramLink
from app.services import telegram as telegram_service
from app.services import telegram_menus as menus
from app.services import telegram_sessions as session_service
from tests.conftest import create_provider_and_model, grant_credits
from tests.tools.fake_telegram import FakeTelegramServer


@pytest.fixture()
def telegram(monkeypatch: pytest.MonkeyPatch):
    """The fake Bot API server, with the platform pointed at it."""
    server = FakeTelegramServer()
    port = server.start()
    monkeypatch.setattr(settings, "telegram_enabled", True)
    monkeypatch.setattr(settings, "telegram_bot_token", "123456:TEST-TOKEN")
    monkeypatch.setattr(settings, "telegram_bot_username", "nexa_test_bot")
    monkeypatch.setattr(settings, "telegram_api_base", f"http://127.0.0.1:{port}")
    monkeypatch.setattr(settings, "telegram_mode", "polling")
    yield server
    server.stop()


# ------------------------------------------------------------------ helpers -----
def _unique_id() -> int:
    return 600_000_000 + (uuid.uuid4().int % 300_000_000)


def _update(server: FakeTelegramServer, text: str, *, telegram_user_id: int, chat_type: str = "private") -> dict:
    return {
        "update_id": server.next_update_id(),
        "message": {
            "message_id": server.next_message_id(),
            "from": {"id": telegram_user_id, "is_bot": False, "first_name": "Tester", "username": "tester"},
            "chat": {"id": telegram_user_id, "type": chat_type},
            "date": 1_700_000_000,
            "text": text,
        },
    }


def _tap(server: FakeTelegramServer, data: str, *, telegram_user_id: int, message_id: int = 1) -> dict:
    return {
        "update_id": server.next_update_id(),
        "callback_query": {
            "id": str(server.next_update_id()),
            "from": {"id": telegram_user_id, "is_bot": False, "first_name": "Tester"},
            "message": {"message_id": message_id, "chat": {"id": telegram_user_id, "type": "private"},
                        "date": 1_700_000_000},
            "data": data,
        },
    }


def _deliver(db, server: FakeTelegramServer, update: dict) -> tuple[str, list[dict]]:
    """Handle one update in-process (the webhook path) and return its result plus what was sent.

    Going through ``handle_update`` directly keeps the assertion on the *result label* possible and,
    unlike ``process_updates``, lets an exception surface instead of being logged and swallowed.
    """
    before = len(server.sent)
    result = asyncio.run(telegram_service.handle_update(db, update))
    return result, server.sent[before:]


def _say(db, server: FakeTelegramServer, text: str, *, telegram_user_id: int, chat_type: str = "private"):
    return _deliver(db, server, _update(server, text, telegram_user_id=telegram_user_id, chat_type=chat_type))


def _tap_and_read(db, server: FakeTelegramServer, data: str, *, telegram_user_id: int):
    return _deliver(db, server, _tap(server, data, telegram_user_id=telegram_user_id))


def _linked_account(user_client, db, server: FakeTelegramServer) -> int:
    """Link a brand-new Telegram id through the one-time code and return that id."""
    telegram_user_id = _unique_id()
    code = user_client.post("/api/v1/telegram/link-code").json()["code"]
    result, _ = _say(db, server, f"/start {code}", telegram_user_id=telegram_user_id)
    assert result == "linked", result
    return telegram_user_id


def _link(db, telegram_user_id: int) -> TelegramLink:
    return db.scalars(select(TelegramLink).where(TelegramLink.telegram_user_id == telegram_user_id)).first()


def _state(db, telegram_user_id: int) -> dict:
    db.expire_all()
    link = _link(db, telegram_user_id)
    assert link is not None
    return dict(link.state or {})


def _keyboard(message: dict) -> dict:
    markup = message.get("reply_markup") or {}
    assert "keyboard" in markup, f"a message without a fixed keyboard was sent: {message['text'][:60]}"
    return markup


def _labels(markup: dict) -> list[str]:
    return [button["text"] for row in markup["keyboard"] for button in row]


def _inline(message: dict) -> list[list[dict]]:
    """The glass (inline) rows of a message — round 14 sections carry these, not a reply bar."""
    markup = message.get("reply_markup") or {}
    assert "inline_keyboard" in markup, f"message without glass buttons: {message['text'][:60]}"
    return markup["inline_keyboard"]


def _idata(message: dict) -> list[str]:
    return [button.get("callback_data", "") for row in _inline(message) for button in row]


def _number_of(server: FakeTelegramServer, text: str) -> int | None:
    """Read the printed number of a model from a /models listing."""
    for line in text.splitlines():
        if text and line:
            match = re.search(r"<b>(\d+)\.", line)
            if match:
                return int(match.group(1))
    return None


def _find_model_number(db, server: FakeTelegramServer, telegram_user_id: int, display_name: str) -> int:
    """Walk every page of /models until the model shows up, and return its printed number.

    The test database is shared by the whole suite, so the catalogue can hold dozens of models —
    the loop follows the page count the listing itself reports instead of assuming a small list.
    """
    page, pages = 1, 1
    while page <= pages and page <= 60:
        _result, sent = _say(db, server, f"/models {page}", telegram_user_id=telegram_user_id)
        listing = "\n".join(message["text"] for message in sent)
        counter = re.search(r"صفحه (\d+) از (\d+)", listing)
        if counter:
            pages = int(counter.group(2))
        for line in listing.splitlines():
            if display_name in line:
                number = re.search(r"<b>(\d+)\.", line)
                if number:
                    return int(number.group(1))
        page += 1
    raise AssertionError(f"{display_name} was not reachable through /models ({pages} pages)")


# ================================================================== sessions =====
def test_a_fresh_state_has_no_sessions_and_safe_defaults() -> None:
    state: dict = {}
    assert session_service.sessions(state) == []
    assert session_service.active(state) is None
    assert session_service.summary(state)["total"] == 0
    current = session_service.settings_of(state)
    assert current["language"] == "fa" and current["show_cost"] is True
    assert current["typing_indicator"] is True and current["history_depth"] > 0
    # An unknown stored value must never leak into the bot's behaviour.
    assert session_service.language({"settings": {"language": "xx"}}) == "fa"


def test_sessions_are_numbered_made_active_and_capped() -> None:
    state: dict = {}
    created = [
        session_service.create(state, model_id=1, model_name="M", conversation_id=100 + index, title=f"S{index}")
        for index in range(26)
    ]
    assert [row["id"] for row in created] == list(range(1, 27))
    rows = session_service.sessions(state)
    assert len(rows) == session_service.MAX_SESSIONS, "the cap must bound what is kept"
    assert session_service.active(state)["id"] == 26
    assert len({row["id"] for row in rows}) == len(rows), "ids must stay unique"


def test_activate_rename_and_touch_follow_the_session() -> None:
    state: dict = {}
    first = session_service.create(state, model_id=7, model_name="M", conversation_id=11)
    second = session_service.create(state, model_id=8, model_name="N", conversation_id=12)
    assert session_service.active(state)["id"] == second["id"] == 2

    session_service.activate(state, first["id"])
    assert session_service.active(state)["id"] == first["id"]
    # The legacy flat keys must follow, or the website would show the wrong thread.
    assert state["conversation_id"] == 11 and state["model_id"] == 7

    session_service.rename(state, first["id"], "  گزارش فروش  ")
    assert session_service.find(state, first["id"])["title"] == "گزارش فروش"
    session_service.touch(state, first["id"], messages=2, tokens=30, charged_micro=1_500)
    assert session_service.find(state, first["id"])["messages"] == 2
    assert session_service.summary(state)["charged_micro"] == 1_500


def test_closing_the_active_session_falls_back_to_the_same_model() -> None:
    state: dict = {}
    a = session_service.create(state, model_id=1, model_name="M", conversation_id=1)
    b = session_service.create(state, model_id=1, model_name="M", conversation_id=2)
    c = session_service.create(state, model_id=2, model_name="N", conversation_id=3)
    session_service.activate(state, b["id"])
    session_service.remove(state, b["id"])
    assert session_service.active(state)["id"] == a["id"], "the newest session of the same model is next"
    session_service.remove(state, a["id"])
    assert session_service.active(state)["id"] == c["id"], "then any remaining session"
    session_service.remove(state, c["id"])
    assert session_service.active(state) is None
    assert "conversation_id" not in state


def test_an_auto_title_is_taken_once_from_the_first_message() -> None:
    state: dict = {}
    row = session_service.create(state, model_id=1, model_name="M", conversation_id=1, title="M · 10:00")
    assert session_service.maybe_autotitle(state, row["id"], "   یک   سؤال مهم   ") is True
    assert session_service.find(state, row["id"])["title"] == "یک سؤال مهم"
    assert session_service.maybe_autotitle(state, row["id"], "سؤال دوم") is False
    assert session_service.find(state, row["id"])["title"] == "یک سؤال مهم"


def test_sessions_are_grouped_by_model() -> None:
    state: dict = {}
    session_service.create(state, model_id=1, model_name="A", conversation_id=1)
    session_service.create(state, model_id=2, model_name="B", conversation_id=2)
    session_service.create(state, model_id=1, model_name="A", conversation_id=3)
    assert len(session_service.for_model(state, 1)) == 2
    assert len(session_service.for_model(state, 2)) == 1
    assert session_service.latest_for_model(state, 1)["conversation_id"] == 3, "newest first"
    assert session_service.summary(state) == {"total": 3, "models": 2, "messages": 0, "tokens": 0,
                                              "charged_micro": 0}


def test_settings_ignore_unknown_keys() -> None:
    state: dict = {}
    session_service.update_settings(state, language="en", history_depth=24, nonsense="x")
    current = session_service.settings_of(state)
    assert current["language"] == "en" and current["history_depth"] == 24
    assert "nonsense" not in current


# ==================================================================== menus =====
def test_the_bottom_bar_is_fixed_and_every_section_offers_a_way_back() -> None:
    bars: set[str] = set()
    for section in ("main", "chat", "models", "sessions", "account", "settings", "help"):
        for language in ("fa", "en"):
            markup = menus.reply_keyboard(section, language)
            assert markup["is_persistent"] is True and markup["resize_keyboard"] is True
            labels = _labels(markup)
            # Round 15: the bar keeps only the two essentials — chat and the glass hub — so it
            # never mutates and never crowds the keyboard; sections live inside the hub.
            assert labels == [fa if language == "fa" else en for _a, fa, en in menus.BAR_SECTIONS], \
                (section, language, labels)
            assert max(len(row) for row in markup["keyboard"]) <= 2, "rows must stay thumb-sized"
            bars.add(json.dumps(markup, sort_keys=True, ensure_ascii=False))
    # One bar for every section and language pair of the same language: it never mutates (round 14).
    assert len(bars) == 2, "the bottom bar must be identical in every section"
    # ...and every section view still offers a way back — as a glass button, not a bar row.
    keyboards = [
        menus.models_inline([], {}, 1, 5, "fa")[0],
        menus.sessions_inline([], None, "fa"),
        menus.settings_inline({}),
        menus.help_inline("fa"),
        menus.account_inline("fa"),
        menus.variants_inline([], None, "fa"),
    ]
    for keyboard in keyboards:
        data = [button.get("callback_data") for row in keyboard["inline_keyboard"] for button in row]
        assert "nav:home" in data, data


def test_every_button_label_maps_back_to_an_action_in_both_languages() -> None:
    seen = 0
    for label, (action, section) in menus.LABEL_ACTIONS.items():
        resolved = menus.action_for_label(label)
        assert resolved == (action, section)
        canonical = telegram_service._ACTION_ALIASES.get(action, action)
        assert canonical == action or canonical.startswith(("menu:", "session:", "chat:", "help:", "nav:")), \
            f"the label {label!r} resolves to {canonical!r}, which the handler cannot route"
        seen += 1
    assert seen >= 50, "both languages must be covered"
    assert menus.action_for_label("یک پیام معمولی") is None


def test_the_model_list_paginates_and_ticks_the_active_model() -> None:
    models = [_FakeModel(index, f"Model {index}") for index in range(1, 26)]
    state: dict = {}
    session_service.create(state, model_id=1, model_name="Model 1", conversation_id=1)
    keyboard, page, pages = menus.models_inline(models, state, page=99, per_page=10, language="fa")
    assert (page, pages) == (3, 3), "an out-of-range page must be clamped, not crash"
    labels = [row[0]["text"] for row in keyboard["inline_keyboard"]]
    assert "21. Model 21" in " ".join(labels)
    first_page, page, pages = menus.models_inline(models, state, page=1, per_page=10, language="fa")
    first_labels = [row[0]["text"] for row in first_page["inline_keyboard"]]
    assert any(label.startswith("✅") for label in first_labels), "the active model must be ticked"
    assert len(keyboard["inline_keyboard"][-1]) == 2, "the last row carries new-session and menu"


def test_the_session_list_ticks_the_active_session() -> None:
    state: dict = {}
    rows = [session_service.create(state, model_id=1, model_name="M", conversation_id=index, title=f"S{index}")
            for index in range(1, 4)]
    keyboard = menus.sessions_inline(session_service.sessions(state), rows[-1]["id"], "fa")
    first_row = [row[0]["text"] for row in keyboard["inline_keyboard"]]
    assert any(label.startswith("✅ 3.") for label in first_row)
    assert any(button["callback_data"] == "session:close" for row in keyboard["inline_keyboard"] for button in row)


def test_the_settings_keyboard_reflects_what_is_stored() -> None:
    state: dict = {}
    session_service.update_settings(state, language="en", show_cost=False, history_depth=6)
    flat = [button for row in menus.settings_inline(state)["inline_keyboard"] for button in row]
    data = {button["callback_data"]: button["text"] for button in flat}
    assert data["settings:lang:en"].endswith("✅")
    assert data["settings:cost:toggle"].startswith("▫️")
    assert data["settings:history:short"].startswith("✅")


def test_help_and_section_texts_exist_in_both_languages() -> None:
    for language in ("fa", "en"):
        for section in menus.HELP_SECTIONS + ("main",):
            text = menus.help_text(section, language)
            assert len(text) > 60 and "/help" in text or section != "main"
        for section in ("main", "chat", "models", "sessions", "account", "settings", "help"):
            assert menus.section_intro(section, language).strip()


# ============================================================ end to end (bot) ===
def test_start_sends_the_fixed_bottom_bar_and_reads_the_account(user_client, db, telegram) -> None:
    telegram_user_id = _linked_account(user_client, db, telegram)
    before = len(telegram.sent)
    result, sent = _say(db, telegram, "/start", telegram_user_id=telegram_user_id)
    assert result == "welcome"
    assert sent, "the bot must answer /start"
    welcome = sent[0]
    assert "خوش آمدید" in welcome["text"] or "welcome" in welcome["text"].lower()
    markup = _keyboard(welcome)
    labels = _labels(markup)
    for label in ("💬 گفتگو", "🧭 منو"):
        assert label in labels, labels
    assert len(labels) == 2, f"the round-15 bar is exactly two buttons, got {labels}"
    # The greeting is the onboarding: it carries the commands and the account's real state.
    for command in ("/new", "/sessions", "/models", "/balance", "/help"):
        assert command in welcome["text"]
    # The inline actions of the same message must be a real inline keyboard.
    assert welcome["reply_markup"] and "keyboard" in welcome["reply_markup"]
    assert before < len(telegram.sent)


def test_a_tapped_bottom_button_opens_its_section_and_back_returns(user_client, db, telegram) -> None:
    telegram_user_id = _linked_account(user_client, db, telegram)

    result, sent = _say(db, telegram, "🧠 مدل‌ها", telegram_user_id=telegram_user_id)
    assert result == "models"
    data = _idata(sent[-1])
    assert any(item.startswith("model:") for item in data), data
    assert "nav:home" in data and "noop" in data, data
    assert "keyboard" not in (sent[-1].get("reply_markup") or {}), \
        "a section message must not re-send the bottom bar (Telegram keeps it)"
    assert _state(db, telegram_user_id)["section"] == "models"
    section_message_id = sent[-1]["message_id"]

    # Back is a glass button now: it deletes the section message and restores the bar.
    result, sent = _deliver(db, telegram, _tap(telegram, "nav:home", telegram_user_id=telegram_user_id,
                                               message_id=section_message_id))
    assert result == "menu"
    assert {"chat_id": telegram_user_id, "message_id": section_message_id} in telegram.deletes
    # Back lands on the glass hub: an inline card with every section one tap away (round 15).
    hub = sent[-1]
    assert "keyboard" not in (hub.get("reply_markup") or {}), "the hub is inline; the bar persists on its own"
    hub_data = [button.get("callback_data") for row in hub["reply_markup"]["inline_keyboard"] for button in row]
    for callback in ("menu:models", "menu:sessions", "menu:account", "menu:settings", "menu:help", "menu:new"):
        assert callback in hub_data, hub_data

    # The settings section keeps its own glass toggles, in the account's language.
    result, sent = _say(db, telegram, "⚙️ تنظیمات", telegram_user_id=telegram_user_id)
    assert result == "settings"
    data = _idata(sent[-1])
    assert "settings:lang:en" in data and "settings:cost:toggle" in data and "nav:home" in data


def test_sessions_are_per_model_and_switching_routes_the_next_message(user_client, db, telegram,
                                                                     mock_provider_transport) -> None:
    def handler(request):  # noqa: ANN001
        return httpx.Response(200, content=(
            'data: {"choices":[{"delta":{"content":"ok"},"finish_reason":null}]}\n\n'
            "data: [DONE]\n\n"
        ), headers={"content-type": "text/event-stream"})

    mock_provider_transport(handler)
    create_provider_and_model(db, published=True, display_name="Alpha Model")
    create_provider_and_model(db, published=True, display_name="Beta Model")
    grant_credits(db, user_client.email, 20.0)
    telegram_user_id = _linked_account(user_client, db, telegram)

    alpha = _find_model_number(db, telegram, telegram_user_id, "Alpha Model")
    beta = _find_model_number(db, telegram, telegram_user_id, "Beta Model")

    result, _ = _say(db, telegram, f"/use {alpha}", telegram_user_id=telegram_user_id)
    assert result == "model_selected"
    result, _ = _say(db, telegram, "پیام اول", telegram_user_id=telegram_user_id)
    assert result == "answer"
    first = _state(db, telegram_user_id)
    first_session = session_service.active(first)
    assert first_session["title"] == "پیام اول", "the first prompt titles the session"
    assert first_session["messages"] == 2, first_session

    result, _ = _say(db, telegram, f"/use {beta}", telegram_user_id=telegram_user_id)
    assert result == "model_selected"
    result, _ = _say(db, telegram, "پیام دوم", telegram_user_id=telegram_user_id)
    assert result == "answer"
    state = _state(db, telegram_user_id)
    rows = session_service.sessions(state)
    assert len(rows) == 2, rows
    assert {row["model_id"] for row in rows} == {row["model_id"] for row in rows}
    assert len({row["id"] for row in rows}) == 2
    beta_session = session_service.active(state)
    assert beta_session["id"] != first_session["id"]

    # Switching back must land on the first conversation again — and its memory with it.
    result, sent = _say(db, telegram, f"/switch {first_session['id']}", telegram_user_id=telegram_user_id)
    assert result == "session_switched"
    assert str(first_session["id"]) in sent[0]["text"]
    state = _state(db, telegram_user_id)
    assert session_service.active(state)["id"] == first_session["id"]
    result, _ = _say(db, telegram, "پیام سوم", telegram_user_id=telegram_user_id)
    assert result == "answer"
    state = _state(db, telegram_user_id)
    assert session_service.find(state, first_session["id"])["messages"] == 4
    assert session_service.find(state, beta_session["id"])["messages"] == 2, "chat did not leak between sessions"


def test_the_session_list_documents_and_switches_every_session(user_client, db, telegram) -> None:
    telegram_user_id = _linked_account(user_client, db, telegram)
    assert _say(db, telegram, "/new گزارش فروش", telegram_user_id=telegram_user_id)[0] == "session_created"
    assert _say(db, telegram, "/new تحلیل بازار", telegram_user_id=telegram_user_id)[0] == "session_created"

    result, sent = _say(db, telegram, "/sessions", telegram_user_id=telegram_user_id)
    assert result == "sessions"
    listing = "\n".join(message["text"] for message in sent)
    assert "گزارش فروش" in listing and "تحلیل بازار" in listing
    assert "✅" in listing, "the active session must be marked"
    data = _idata(sent[-1])
    assert "session:1" in data and "session:2" in data, data
    assert "session:rename:begin" in data and "session:close" in data, "active-session actions"

    # A tap on a session row switches to it, exactly like /switch — editing the list in place.
    listing_id = sent[-1]["message_id"]
    result, sent = _deliver(db, telegram, _tap(telegram, "session:1", telegram_user_id=telegram_user_id,
                                               message_id=listing_id))
    assert result == "session_switched"
    assert _state(db, telegram_user_id)["active_session_id"] == 1
    assert any(edit["message_id"] == listing_id for edit in telegram.edits), \
        "switching from the list must edit the list, not send a new message"


def test_rename_close_and_export(user_client, db, telegram, mock_provider_transport) -> None:
    def handler(request):  # noqa: ANN001
        return httpx.Response(200, content=(
            'data: {"choices":[{"delta":{"content":"پاسخ کوتاه"},"finish_reason":null}]}\n\n'
            "data: [DONE]\n\n"
        ), headers={"content-type": "text/event-stream"})

    mock_provider_transport(handler)
    create_provider_and_model(db, published=True, display_name="Export Model")
    grant_credits(db, user_client.email, 20.0)
    telegram_user_id = _linked_account(user_client, db, telegram)

    assert _say(db, telegram, "سؤال من", telegram_user_id=telegram_user_id)[0] == "answer"
    result, sent = _say(db, telegram, "/rename پروژه اردیبهشت", telegram_user_id=telegram_user_id)
    assert result == "session_renamed"
    assert _state(db, telegram_user_id)["sessions"][0]["title"] == "پروژه اردیبهشت"

    result, sent = _say(db, telegram, "/export", telegram_user_id=telegram_user_id)
    assert result == "export"
    transcript = "\n".join(message["text"] for message in sent)
    assert "سؤال من" in transcript and "پاسخ کوتاه" in transcript

    session_id = _state(db, telegram_user_id)["active_session_id"]
    result, sent = _say(db, telegram, "/close", telegram_user_id=telegram_user_id)
    assert result == "session_closed"
    state = _state(db, telegram_user_id)
    assert session_service.find(state, session_id) is None
    assert session_service.sessions(state) == []

    # With nothing active, the next message simply starts a new session.
    result, _ = _say(db, telegram, "پیام تازه", telegram_user_id=telegram_user_id)
    assert result == "answer"
    state = _state(db, telegram_user_id)
    assert len(session_service.sessions(state)) == 1
    assert session_service.sessions(state)[0]["messages"] == 2


def test_stats_reports_what_the_bot_really_spent(user_client, db, telegram, mock_provider_transport) -> None:
    def handler(request):  # noqa: ANN001
        return httpx.Response(200, content=(
            'data: {"choices":[{"delta":{"content":"چهار"},"finish_reason":null}]}\n\n'
            'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":5,"completion_tokens":3}}\n\n'
            "data: [DONE]\n\n"
        ), headers={"content-type": "text/event-stream"})

    mock_provider_transport(handler)
    create_provider_and_model(db, published=True, display_name="Stats Model")
    grant_credits(db, user_client.email, 20.0)
    telegram_user_id = _linked_account(user_client, db, telegram)
    assert _say(db, telegram, "یک پیام", telegram_user_id=telegram_user_id)[0] == "answer"

    result, sent = _say(db, telegram, "/stats", telegram_user_id=telegram_user_id)
    assert result == "stats"
    report = "\n".join(message["text"] for message in sent)
    assert "سشن‌ها" in report and "پیام‌ها" in report and "credits" in report
    state = _state(db, telegram_user_id)
    assert session_service.summary(state)["messages"] == 2
    assert session_service.summary(state)["charged_micro"] > 0, "the ledger, not a guess"


def test_settings_switch_the_language_and_the_cost_footer(user_client, db, telegram, mock_provider_transport) -> None:
    def handler(request):  # noqa: ANN001
        return httpx.Response(200, content=(
            'data: {"choices":[{"delta":{"content":"answer"},"finish_reason":null}]}\n\n'
            "data: [DONE]\n\n"
        ), headers={"content-type": "text/event-stream"})

    mock_provider_transport(handler)
    create_provider_and_model(db, published=True, display_name="Lang Model")
    grant_credits(db, user_client.email, 20.0)
    telegram_user_id = _linked_account(user_client, db, telegram)

    result, sent = _say(db, telegram, "🇬🇧 English", telegram_user_id=telegram_user_id)
    assert result == "settings"
    assert _state(db, telegram_user_id)["settings"]["language"] == "en"
    assert "Bot settings" in sent[-1]["text"]
    data = _idata(sent[-1])
    assert "settings:lang:fa" in data and "nav:home" in data, data

    result, sent = _say(db, telegram, "/help", telegram_user_id=telegram_user_id)
    assert result == "help"
    assert "Help" in sent[0]["text"] and "Models" in "\n".join(m["text"] for m in sent)

    # Turning the cost display off must remove the footer from the next answer.
    result, sent = _say(db, telegram, "💰 Show cost", telegram_user_id=telegram_user_id)
    assert result == "settings"
    assert _state(db, telegram_user_id)["settings"]["show_cost"] is False
    result, sent = _say(db, telegram, "hello", telegram_user_id=telegram_user_id)
    assert result == "answer"
    # the answer finalises the generating placeholder by edit
    answer = ([e["text"] for e in telegram.edits if "answer" in e["text"]] or [sent[-1]["text"]])[-1]
    assert "answer" in answer
    assert "credits" not in answer, "show_cost=off must hide the price footer"


def test_inline_menu_button_from_a_stranger_is_refused(user_client, db, telegram) -> None:
    stranger = _unique_id()
    result, sent = _tap_and_read(db, telegram, "menu:models", telegram_user_id=stranger)
    assert result == "callback_unlinked"
    assert not any("مدل" in message["text"] for message in sent)


def test_a_group_chat_is_refused(user_client, db, telegram) -> None:
    telegram_user_id = _linked_account(user_client, db, telegram)
    result, sent = _say(db, telegram, "/models", telegram_user_id=telegram_user_id, chat_type="group")
    assert result == "group_ignored"
    assert "خصوصی" in sent[0]["text"] or "private" in sent[0]["text"].lower()


def test_an_unknown_command_points_at_the_help(user_client, db, telegram) -> None:
    telegram_user_id = _linked_account(user_client, db, telegram)
    result, sent = _say(db, telegram, "/nope", telegram_user_id=telegram_user_id)
    assert result == "unknown_command"
    assert "/help" in sent[0]["text"]


def test_retry_repeats_the_last_prompt(user_client, db, telegram, mock_provider_transport) -> None:
    calls: list[dict] = []

    def handler(request):  # noqa: ANN001
        calls.append(json.loads(request.content.decode()))
        return httpx.Response(200, content=(
            'data: {"choices":[{"delta":{"content":"پاسخ"},"finish_reason":null}]}\n\n'
            "data: [DONE]\n\n"
        ), headers={"content-type": "text/event-stream"})

    mock_provider_transport(handler)
    create_provider_and_model(db, published=True, display_name="Retry Model")
    grant_credits(db, user_client.email, 20.0)
    telegram_user_id = _linked_account(user_client, db, telegram)

    assert _say(db, telegram, "شعر بگو", telegram_user_id=telegram_user_id)[0] == "answer"
    assert _say(db, telegram, "/retry", telegram_user_id=telegram_user_id)[0] == "answer"
    assert len(calls) == 2, "retry must really ask the provider again"
    assert calls[1]["messages"][-1]["content"] == "شعر بگو", "the same prompt is sent again"
    # It is a new turn inside the same session, so the previous exchange is part of the context.
    assert calls[1]["messages"][0]["content"] == "شعر بگو"


def _set_live_stream(db, telegram_user_id: int, enabled: bool) -> None:
    """Flip the round-16 live-stream setting for a linked account."""
    link = db.scalars(select(TelegramLink).where(TelegramLink.telegram_user_id == telegram_user_id)).first()
    assert link is not None
    state = telegram_service._state(link)
    session_service.update_settings(state, live_stream=enabled)
    telegram_service._save_state(db, link, state)


def test_a_long_answer_is_split_instead_of_truncated(user_client, db, telegram, mock_provider_transport) -> None:
    """With live streaming OFF the classic one-shot delivery must still split long answers."""
    head = "A" * 4_100
    tail = "TAIL-MARKER-9Z"

    def handler(request):  # noqa: ANN001
        payload = ('data: {"choices":[{"delta":{"content":"' + head + '"},"finish_reason":null}]}\n\n'
                   'data: {"choices":[{"delta":{"content":"' + tail + '"},"finish_reason":null}]}\n\n'
                   "data: [DONE]\n\n")
        return httpx.Response(200, content=payload, headers={"content-type": "text/event-stream"})

    mock_provider_transport(handler)
    create_provider_and_model(db, published=True, display_name="Long Model")
    grant_credits(db, user_client.email, 20.0)
    telegram_user_id = _linked_account(user_client, db, telegram)
    _set_live_stream(db, telegram_user_id, False)

    result, sent = _say(db, telegram, "یک متن بلند", telegram_user_id=telegram_user_id)
    assert result == "answer"
    answers = [message for message in sent if "A" in message["text"] or tail in message["text"]]
    assert len(answers) >= 2, "a >4000 character answer must be split, not cut"
    assert all(len(message["text"]) <= telegram_service.MAX_TELEGRAM_MESSAGE + 40 for message in answers)
    assert any(tail in message["text"] for message in answers), "the end of the answer must survive"
    assert "(1/2)" in answers[0]["text"] and "(2/2)" in answers[-1]["text"]


def test_the_published_command_list_matches_the_documented_one(user_client, db, telegram) -> None:
    result = asyncio.run(telegram_service.set_my_commands())
    assert result is not None
    published = {item["command"] for item in telegram.commands}
    # ``(?<![\w/<>])`` and two letters, so HTML tags such as <b> never look like a command.
    documented = set(re.findall(r"(?<![\w/<>])/([a-z]{2,})", menus.help_text("commands", "fa")))
    assert documented, "the help text must list the commands"
    missing = documented - published
    assert not missing, f"documented but not published to Telegram: {sorted(missing)}"
    for command in ("start", "menu", "new", "sessions", "switch", "rename", "close", "models", "use",
                    "variants", "balance", "usage", "stats", "settings", "export", "retry", "status",
                    "whoami", "help"):
        assert command in published, command
    assert len(published) <= 100, "Telegram's own limit on published commands"


class _FakeModel:
    """A stand-in with the two attributes the keyboards read (``id`` and ``display_name``)."""

    def __init__(self, identifier: int, name: str) -> None:
        self.id = identifier
        self.display_name = name


def test_state_changes_survive_a_fresh_read(user_client, db, telegram) -> None:
    """Regression: a session store that looks saved but is not (shallow-copy mutation).

    SQLAlchemy compares a JSON column by value. Writing back a *shallow* copy whose nested dictionaries
    were mutated in place compared equal to the loaded value, so the UPDATE was skipped and renames,
    switches and settings silently reverted on the next request.
    """
    telegram_user_id = _linked_account(user_client, db, telegram)
    assert _say(db, telegram, "/new نام اولیه", telegram_user_id=telegram_user_id)[0] == "session_created"
    assert _say(db, telegram, "/rename نام پایدار", telegram_user_id=telegram_user_id)[0] == "session_renamed"
    assert _say(db, telegram, "💳 حساب من", telegram_user_id=telegram_user_id)[0] == "account"
    assert _say(db, telegram, "/settings", telegram_user_id=telegram_user_id)[0] == "settings"
    assert _say(db, telegram, "💰 نمایش هزینه", telegram_user_id=telegram_user_id)[0] == "settings"

    from app.db.session import SessionLocal

    fresh = SessionLocal()
    try:
        link = fresh.scalars(select(TelegramLink)
                             .where(TelegramLink.telegram_user_id == telegram_user_id)).first()
        state = dict(link.state or {})
    finally:
        fresh.close()
    assert state["sessions"][0]["title"] == "نام پایدار"
    assert state["settings"]["show_cost"] is False
    assert state["section"] == "settings"


def test_the_session_keyboard_pages_through_the_whole_store() -> None:
    """Every stored session must be reachable by button — the store caps at 20, a page holds 10."""
    state: dict = {}
    for index in range(20):
        session_service.create(state, model_id=1, model_name="Alpha Model", conversation_id=100 + index,
                               title=f"session {index + 1}")
    rows = session_service.sessions(state)

    # the store lists newest-first, so page 1 holds sessions 20..11 and page 2 holds 10..1
    first = menus.sessions_inline(rows, rows[0]["id"], "fa")
    buttons = [button for row in first["inline_keyboard"] for button in row]
    texts = " ".join(button["text"] for button in buttons)
    assert "1/2" in texts, "a page counter must be visible"
    assert any(button["callback_data"] == "sessions:page:2" for button in buttons)
    assert "session 20" in texts and "session 11" in texts
    session_buttons = [button for button in buttons
                       if button["callback_data"].startswith("session:") and button["callback_data"][len("session:"):].isdigit()]
    assert len(session_buttons) == 10, "exactly one page of session buttons"

    second = menus.sessions_inline(rows, rows[0]["id"], "fa", page=2)
    second_buttons = [button for row in second["inline_keyboard"] for button in row]
    second_texts = " ".join(button["text"] for button in second_buttons)
    assert "2/2" in second_texts
    assert "session 10" in second_texts and "session 1" in second_texts, "the second page holds the rest of the store"
    assert not any(button["callback_data"] == "sessions:page:3" for button in second_buttons), "no page past the end"

    clamped = menus.sessions_inline(rows, None, "fa", page=99)
    clamped_texts = " ".join(button["text"] for row in clamped["inline_keyboard"] for button in row)
    assert "2/2" in clamped_texts, "out-of-range pages clamp"

    single = menus.sessions_inline(rows[:3], rows[0]["id"], "fa")
    assert not any(button["callback_data"].startswith("sessions:page:")
                   for row in single["inline_keyboard"] for button in row), "one page needs no pager"
