/**
 * «داده‌های من» — the former chat route is now the user's own data room:
 * how many conversations exist (open and archived/closed), how much of the
 * file workspace is used, and how many tokens/requests the last 30 days
 * cost — with a chart. Chatting itself lives in the Studio, one tap away
 * from every conversation listed here.
 */
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import { api } from "../api/client";
import type { Conversation, DashboardSummary, Paged } from "../api/types";
import { BarChart } from "../components/charts";
import { Icon } from "../components/icons";
import { Button, Card, ErrorNotice, Spinner, Stat } from "../components/ui";
import { fmtSize, type StorageBlock } from "../components/FilesCenter";
import { useI18n } from "../state/app";

export default function DataOverview(): JSX.Element {
  const { t } = useI18n();
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(true);
  const [activeCount, setActiveCount] = useState(0);
  const [closedCount, setClosedCount] = useState(0);
  const [messageTotal, setMessageTotal] = useState(0);
  const [recent, setRecent] = useState<Conversation[]>([]);
  const [storage, setStorage] = useState<StorageBlock | null>(null);
  const [summary, setSummary] = useState<DashboardSummary | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const [active, closed, recentPage, storageData, summaryData] = await Promise.all([
          api.get<Paged<Conversation>>("/api/v1/chat/conversations", { page_size: 1, archived: false }),
          api.get<Paged<Conversation>>("/api/v1/chat/conversations", { page_size: 1, archived: true }),
          api.get<Paged<Conversation>>("/api/v1/chat/conversations", { page_size: 100, archived: false }),
          api.get<StorageBlock>("/api/v1/files/storage/summary"),
          api.get<DashboardSummary>("/api/v1/dashboard/summary", { days: 30 }),
        ]);
        setActiveCount(active.pagination?.total ?? active.items.length);
        setClosedCount(closed.pagination?.total ?? closed.items.length);
        setRecent(recentPage.items.slice(0, 8));
        setMessageTotal(recentPage.items.reduce((sum, item) => sum + (item.message_count || 0), 0));
        setStorage(storageData);
        setSummary(summaryData);
      } catch (caught) {
        setError(caught);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const usedPct = storage ? Math.min(100, Math.round((storage.used_bytes / Math.max(1, storage.quota_bytes)) * 100)) : 0;
  const daily = (summary?.daily || []).map((point) => ({
    label: point.day.slice(5),
    value: point.requests,
  }));

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1>{t("data.title")}</h1>
          <p>{t("data.subtitle")}</p>
        </div>
        <div className="row">
          <Link className="btn" to="/app/studio">
            <Icon name="chat" size={15} /> {t("data.openStudio")}
          </Link>
        </div>
      </div>

      {error ? <ErrorNotice error={error} /> : null}
      {loading ? (
        <Spinner />
      ) : (
        <>
          <div className="grid grid--3">
            <Stat label={t("data.activeConversations")} value={activeCount} icon="chat" />
            <Stat label={t("data.closedConversations")} value={closedCount} icon="check" />
            <Stat label={t("data.messages")} value={messageTotal} icon="scroll" />
            <Stat
              label={t("data.files")}
              value={storage ? `${storage.file_count} / ${storage.max_files}` : "—"}
              icon="folder"
            />
            <Stat label={t("data.tokens30")} value={(summary?.kpis.tokens_window ?? 0).toLocaleString()} icon="bolt" />
            <Stat label={t("data.requests30")} value={summary?.kpis.requests_window ?? 0} icon="gauge" />
          </div>

          <div className="grid grid--2">
            <Card title={t("data.usageChart")}>
              {daily.length ? (
                <BarChart data={daily} height={170} />
              ) : (
                <p className="muted">{t("data.noUsage")}</p>
              )}
              <p className="muted small">{t("data.usageChartHint")}</p>
            </Card>

            <Card title={t("data.storage")}>
              {storage ? (
                <>
                  <div className="files-center__meter-row">
                    <span>
                      <strong>{fmtSize(storage.used_bytes)}</strong> / {storage.quota_mb} MB
                    </span>
                    <span className="muted">
                      {storage.file_count} / {storage.max_files} {t("studio.filesWord")}
                    </span>
                  </div>
                  <div className="files-center__bar">
                    <span style={{ width: `${usedPct}%` }} />
                  </div>
                  <p className="muted small">{t("data.storageHint")}</p>
                  <Link className="btn btn--subtle" to="/app/files">
                    <Icon name="folder" size={15} /> {t("data.openFiles")}
                  </Link>
                </>
              ) : (
                <p className="muted">—</p>
              )}
            </Card>
          </div>

          <Card title={t("data.recent")}>
            {recent.length === 0 ? (
              <p className="muted">{t("data.noConversations")}</p>
            ) : (
              <ul className="data-recent">
                {recent.map((conversation) => (
                  <li key={conversation.id}>
                    <Link to={`/app/studio?conversation=${conversation.id}`} className="data-recent__item">
                      <span className="data-recent__main">
                        <strong dir="auto">{conversation.title || `#${conversation.id}`}</strong>
                        {conversation.last_message_preview ? (
                          <span className="muted small" dir="auto">
                            {conversation.last_message_preview}
                          </span>
                        ) : null}
                      </span>
                      <span className="muted small">
                        {conversation.message_count ?? 0} {t("data.messagesWord")} ·{" "}
                        {new Date(conversation.updated_at).toLocaleDateString()}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
            <div className="row">
              <Link className="btn btn--subtle" to="/app/usage">
                <Icon name="chart-line" size={15} /> {t("data.openUsage")}
              </Link>
              <Link className="btn btn--subtle" to="/app/studio">
                <Icon name="expand" size={15} /> {t("data.openStudio")}
              </Link>
            </div>
          </Card>

          {summary && summary.top_models.length > 0 ? (
            <Card title={t("data.topModels")}>
              <ul className="data-recent">
                {summary.top_models.slice(0, 5).map((model) => (
                  <li key={model.name} className="data-recent__item">
                    <span className="data-recent__main">
                      <strong dir="auto">{model.name}</strong>
                    </span>
                    <span className="muted small">{model.requests}</span>
                  </li>
                ))}
              </ul>
            </Card>
          ) : null}
        </>
      )}
    </div>
  );
}
