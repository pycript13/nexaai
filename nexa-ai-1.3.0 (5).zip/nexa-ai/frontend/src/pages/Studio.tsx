/**
 * Chat Studio — the platform's one, professional chat workspace.
 *
 * The full chat feature set (sessions rail, model health with tap-to-recheck,
 * variants, message tools, attachments, voice input, stop/continue) lives in
 * the Chat workspace; the studio is that workspace presented as a dedicated,
 * full-height, mobile-first page. The old /app/chat route is now the user's
 * data room (DataOverview) — chatting happens here.
 */
import { Chat } from "./Chat";

export default function Studio(): JSX.Element {
  return (
    <div className="studio-shell">
      <Chat embedded />
    </div>
  );
}
