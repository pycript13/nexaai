/**
 * The unified file workspace — one panel for every file the user owns:
 * uploads and model-generated outputs from chat, coding, images and every
 * other module (one `files` API, one storage quota, admin-set MB + count
 * limits). Used as the global topbar drawer and inside the chat studio,
 * where a file can also be attached to the next message.
 */
import { useCallback, useEffect, useMemo, useState } from "react";

import { api, downloadFile } from "../api/client";
import { Icon, type IconName } from "./icons";
import { Button, ErrorNotice, Spinner } from "./ui";
import { useI18n } from "../state/app";

export type StoredFileItem = {
  id: number;
  kind: string;
  name: string;
  size_bytes: number;
  mime_type: string;
  created_at: string;
};

export type StorageBlock = {
  used_bytes: number;
  quota_bytes: number;
  quota_mb: number;
  file_count: number;
  max_files: number;
};

export const fmtSize = (bytes: number): string => {
  if (bytes >= 1073741824) return `${(bytes / 1073741824).toFixed(1)} GB`;
  if (bytes >= 1048576) return `${(bytes / 1048576).toFixed(bytes >= 10485760 ? 0 : 2)} MB`;
  if (bytes >= 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${bytes} B`;
};

const KIND_ICONS: Record<string, IconName> = {
  image: "image",
  document: "document",
  audio: "audio",
  video: "video",
  code: "code",
};

function iconFor(file: StoredFileItem): IconName {
  const mime = file.mime_type || "";
  if (mime.startsWith("image/")) return KIND_ICONS.image;
  if (mime.startsWith("audio/")) return KIND_ICONS.audio;
  if (mime.startsWith("video/")) return KIND_ICONS.video;
  if (mime.includes("pdf") || mime.startsWith("text/")) return KIND_ICONS.document;
  return "folder";
}

export function FilesWorkspace({
  onAttach,
  attachedIds,
}: {
  onAttach?: (file: StoredFileItem) => void;
  attachedIds?: number[];
}): JSX.Element {
  const { t } = useI18n();
  const [files, setFiles] = useState<StoredFileItem[]>([]);
  const [storage, setStorage] = useState<StorageBlock | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [query, setQuery] = useState("");
  const [kindFilter, setKindFilter] = useState("all");
  const [confirmDelete, setConfirmDelete] = useState<number | null>(null);

  const load = useCallback(async () => {
    const data = await api.get<{ items: StoredFileItem[]; storage: StorageBlock }>("/api/v1/files", { limit: 100 });
    setFiles(data.items || []);
    setStorage(data.storage || null);
  }, []);

  useEffect(() => {
    load()
      .catch(setError)
      .finally(() => setLoading(false));
  }, [load]);

  const upload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    setUploading(true);
    setError(null);
    try {
      const form = new FormData();
      form.append("file", file);
      await api.upload("/api/v1/files", form);
      await load();
    } catch (caught) {
      setError(caught);
    } finally {
      setUploading(false);
    }
  };

  const remove = async (id: number) => {
    if (confirmDelete !== id) {
      setConfirmDelete(id);
      return;
    }
    setConfirmDelete(null);
    try {
      await api.del(`/api/v1/files/${id}`);
      await load();
    } catch (caught) {
      setError(caught);
    }
  };

  const visible = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return files.filter((file) => {
      if (kindFilter !== "all" && file.kind !== kindFilter) return false;
      if (needle && !file.name.toLowerCase().includes(needle)) return false;
      return true;
    });
  }, [files, query, kindFilter]);

  const usedPct = storage ? Math.min(100, Math.round((storage.used_bytes / Math.max(1, storage.quota_bytes)) * 100)) : 0;

  return (
    <div className="files-center">
      {storage ? (
        <div className="files-center__meter">
          <div className="files-center__meter-row">
            <span>
              <strong>{fmtSize(storage.used_bytes)}</strong> / {storage.quota_mb} MB
            </span>
            <span className="muted">
              {storage.file_count} / {storage.max_files} {t("studio.filesWord")}
            </span>
          </div>
          <div className="files-center__bar">
            <span style={{ width: `${usedPct}%` }} />
          </div>
        </div>
      ) : null}

      <div className="files-center__tools">
        <label className="files-center__search">
          <Icon name="search" size={15} />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={t("files.search")}
            aria-label={t("files.search")}
          />
        </label>
        <label className="btn btn--subtle files-center__upload">
          <Icon name="upload" size={15} />
          {uploading ? t("studio.uploading") : t("files.upload")}
          <input type="file" hidden onChange={upload} disabled={uploading} />
        </label>
      </div>

      <div className="files-center__chips" role="group" aria-label={t("files.title")}>
        {[
          ["all", t("files.all")],
          ["upload", t("files.uploadedKind")],
          ["generated", t("files.generatedKind")],
        ].map(([value, label]) => (
          <button
            key={value}
            type="button"
            className={`chip ${kindFilter === value ? "chip--active" : ""}`}
            onClick={() => setKindFilter(value)}
          >
            {label}
          </button>
        ))}
      </div>

      {error ? <ErrorNotice error={error} /> : null}

      <div className="files-center__list">
        {loading ? (
          <Spinner />
        ) : visible.length === 0 ? (
          <p className="muted small files-center__empty">{t("files.empty")}</p>
        ) : (
          visible.map((file) => {
            const attached = attachedIds?.includes(file.id);
            return (
              <div key={file.id} className="files-center__row">
                <span className="files-center__icon" aria-hidden>
                  <Icon name={iconFor(file)} size={17} />
                </span>
                <span className="files-center__main">
                  <strong title={file.name}>{file.name}</strong>
                  <span className="muted small">
                    {file.kind === "generated" ? t("files.generatedKind") : t("files.uploadedKind")} ·{" "}
                    {fmtSize(file.size_bytes)} · {new Date(file.created_at).toLocaleDateString()}
                  </span>
                </span>
                {onAttach ? (
                  <button
                    type="button"
                    className={`iconbtn iconbtn--ghost ${attached ? "files-center__attached" : ""}`}
                    onClick={() => onAttach(file)}
                    aria-label={t("files.attach")}
                    title={attached ? t("files.attached") : t("files.attach")}
                  >
                    <Icon name={attached ? "check" : "attach"} size={15} />
                  </button>
                ) : null}
                <button
                  type="button"
                  className="iconbtn iconbtn--ghost"
                  onClick={() => void downloadFile(`/api/v1/files/${file.id}/download`, file.name)}
                  aria-label={t("action.download")}
                  title={t("action.download")}
                >
                  <Icon name="download" size={15} />
                </button>
                <button
                  type="button"
                  className={`iconbtn iconbtn--ghost ${confirmDelete === file.id ? "files-center__danger" : ""}`}
                  onClick={() => void remove(file.id)}
                  aria-label={t("action.delete")}
                  title={confirmDelete === file.id ? t("files.deleteConfirm") : t("action.delete")}
                >
                  <Icon name="trash" size={15} />
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

export function FilesCenter({ open, onClose }: { open: boolean; onClose: () => void }): JSX.Element | null {
  const { t } = useI18n();
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <>
      <button type="button" className="files-center__backdrop" aria-label={t("action.close")} onClick={onClose} />
      <aside className="files-center__drawer" aria-label={t("files.title")}>
        <div className="files-center__head">
          <strong>
            <Icon name="folder" size={17} /> {t("files.title")}
          </strong>
          <button type="button" className="iconbtn iconbtn--ghost" onClick={onClose} aria-label={t("action.close")}>
            <Icon name="close" size={16} />
          </button>
        </div>
        <FilesWorkspace />
      </aside>
    </>
  );
}
